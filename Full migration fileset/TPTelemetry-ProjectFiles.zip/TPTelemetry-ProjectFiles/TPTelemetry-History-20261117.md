# TP Telemetry: change history, 17 November 2026

The 17 November work (Initial D Arcade Stage Ver. 3 in Flycast, its own thread), newest first. Continues
`TPTelemetry-History-20261104-20261116.md`. The game notes (`FLYINITD3-flycast-`, `-states-`, `-capture-20261117.md`) have
the detail.

### 18 November: `ram_probe` back in FLYINITD3

* At Alexis's request, to test newer Flycast builds (`moregames.fly_id3_rows`, pack README, Game_Setup note). 1999 pass
  with the pack.

### 17 November (19:45): Initial D 3 wrapped up

* Her drift recording (19:33, RX-7, Akagi) and answers: `drift_angle` + in every right-hand drift (99%); her drifts
  peak at 18 to 21 degrees. Car_drift tuned to her target (0.6 to 0.65): ID6's curve made full at 45 degrees (top 0.62),
  and capped during a contact (a rail swung the angle to 32 degrees, reading 0.93). Surface codes named by her: 20
  ripple strip, 21 grooved concrete (`grooved_road`), 18 kerb with leaves and 32 kerb and gutter (both into `gutter`, with
  48 and 49); Car_off_road = gutter. Car_cornering from steering and speed (as ID0), so outputs are optional;
  `lampleader` and `lampcheckpoint` no longer tied to racing (held until the race is cleared, as ID0). `ram_probe`
  removed from the table. `Fly3Tests` covers both fixtures (16:57 race, 19:33 drifts). Compile check passed (mono). 1999
  pass with the pack, 770 without.

### 17 November (18:30): Initial D 3 ripple strips, drift angle, contact sides

* Recordings 7 to 9 and her requests: `rumble_strip` (surface code 20), `yaw`/`move_x`/`move_z` and `drift_angle` (from
  save states; sign unconfirmed), `kick_x`/`kick_y`, `contact_side`, `wall_contact`, `hit`; Car_impact, Car_wall_contact,
  Car_rumble_strip, Car_drift(_angle), all 0 outside a race; Max speed 205, Max revs 9000. 1993 pass with the pack.

### 17 November (17:30): Initial D 3 clocks checked in a whole race

* Recording 6 (16:57): `rt`, `race_clock`, `lap`, both checkpoints and `racing` to the finish line all right through the
  `@` chain in a new session. Rubbish as the race is cleared lit the lamps for half a second: `race_ok` added.
  `Fly3Tests.cs` and a fixture. 1989 pass with the pack, 770 without.

### 17 November (16:00): Initial D 3 clocks; plugin 0.18.2

* Her answers, a time trial save state and recordings through the finish and time up (end of
  `claude/FLYINITD3-capture-20261117.md`). **Plugin 0.18.2 / helper 0.17.1:** `@` offsets follow a game's 32-bit pointers
  inside an emulator's memory. FLYINITD3: `rt`, `race_clock`, `lap` through [0x0C8FF174]; `racing` ends when the clock
  stops; `lampcheckpoint`, `contact`, `gutter`. 1975 pass with the pack, 770 without.

### 17 November (15:00): Initial D 3 recordings 3 and 4

* `claude/FLYINITD3-capture-20261117.md`. Heap rows moved in other races (removed; the clocks need emulated-pointer
  chains, a plugin change, and a state from another race). New: `thr_revs`, `rpm_top`, `rev_limit`, `rpm_frac`,
  `throttle`, `steer`, `live`, `racing` (GO = gear leaves 0), `lampleader` (from the gap); Car_in_race, Car_throttle,
  Car_rpm_frac (commonrows FLYINITD3). Removing the FFB plugin's files stopped the outputs freeze. 1969 pass with the pack.

### 17 November (afternoon): Initial D 3 save states, first game rows

* Two recordings (`ram_probe` right on every sample; outputs off because Broadcast Digital Outputs freezes her game in
  the menus) and two save states: `claude/FLYINITD3-states-20261117.md`. Speed, revs, gear and ADVANTAGE found by value in
  the static car structure (0x0C900C2C, 0x0C900EA4, 0x0C900E88, 0x0C901650); clocks in heap memory (to be tested); 40
  candidate rows. New tools `sh4/flystate.py`, `sh4/sh4dis.py`. 1969 pass with the pack.

### 17 November: Initial D 3 in Flycast (FLYINITD3), first step

* Its own thread. From her `flycast.exe` (v2.5-219-g27a913fc0): the emulated RAM is `<main>+2840C90` -> + (game address &
  0x1FFFFFF) (`claude/FLYINITD3-flycast-20261117.md`; `moregames.fly_ram`). Profile: Process `flycast.exe`, `lamp0` to
  `lamp7`, `lamp_bits`, `ram_probe`. `initdv3e.zip` holds only the BIOS and keys (the program is on the GD-ROM), so no
  game values yet: asked for in-race save states. 1969 pass with the pack.
