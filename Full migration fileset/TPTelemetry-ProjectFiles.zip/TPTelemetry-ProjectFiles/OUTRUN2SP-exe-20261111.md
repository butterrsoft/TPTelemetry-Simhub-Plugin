# OutRun 2 SP SDX from the game's `jennifer`, 11 November 2026

Alexis attached `jennifer` (the game program) and asked for the same treatment as WMMT3DX+'s `main`. Rows are in the pack
(`moregames.py`, after the 2 November OR2 rows; `commonrows.py`); none of the new ones is checked in a recording yet.

## The file

* `jennifer`: 2,729,110 bytes, MD5 06734dceddc81b82fef314b090f563df. 32-bit Linux ELF, type EXEC, built with MontaVista
  GCC 3.3.1 (December 2003). Text from 0x08048000, `.data` 0x081FCD20, `.bss` 0x082642E0 to 0x0896AEC0.
* **Not stripped:** the full symbol table (12,558 symbols, 4,389 variables), C++ names with argument types. The debug
  information covers only start-up code, so structure layouts come from the code, not from types.
* BudgieLoader maps it at those addresses, so rows read absolute addresses (Module blank), as OR2 always has.

## What the existing rows are

| Row | Address | Game variable |
|---|---|---|
| `speed` | 0x08273DF0 | `car_work` +330 (the player's physics work, `tagCAR_WORK`, 0x900 bytes): not the speedo |
| `rpm`, `gear`, `surface`, `side_hit_dir`, `side_hit_count`, `crash_count`, `vel_*` | 0x0827A174 ... | the player's car record, `evwork_car` +3D4, +3C0, +400, +434, +43A, +5BD, +1AC |
| `in_race` | 0x08304ADC | `navipub_disp_flg`: the HUD's navigation display flag (on in races; `DispGoal` and `DispTimeUp` switch it off) |
| `in_menu` | 0x086749CA | inside `cs_master` (+14A) |
| `stage_timer` | 0x0830B748 | `game_timer` (frames, down) |
| `transmission`, `select_timer` | 0x082932C2, 0x082932B0 | `evwork_sel` +22, +10 |
| `steer` | 0x08670DC8 | `iowork` +8 |
| `ffb_wall`, `ffb_float` | 0x08273FAC, 0x08273AD4 | `car_work` +4EC, +14 |
| `ob_raceleader`, `ob_outputdata` | 0x0830430C, 0x08670E08 | `fight_param` +28C, `iowork` +48 |

`side_hit_count` (+43A) and `crash_count` (+5BD) are unaligned reads across byte fields, which is why they read odd
numbers (2 November). +43A and +43B are bytes `CheckShiftWarning` tests too.

## The car record (`tagEVWORK_CAR`, 24 of 0x10E0 bytes from `evwork_car` 0x08279DA0; the player is the first)

| Offset | Type | What | Evidence |
|---|---|---|---|
| +3A0 | float | speed, metres a frame | `CopyCarWork`: the length of the velocity; x 216.72 (60 x 3.6) for km/h |
| +3AC | int32 | speed x 216.72 (km/h, no car factor) | `CopyCarWork` |
| +3B0 | float | **the speedo's km/h** | `CopyCarWork`: +3A0 x 216.72 x the car's speedo factor (car data +1AB0), x 1.0101 and capped at 300 for some cars; `DispSpeedMeter` prints it with `%03d` times `change_mile` (0x0820BBB0: 1, or 0.6214 for mph) |
| +3C0 | int32 | gear | `AutoTransmission`, `ManuTransmission`, `DispGearPosition`; top gear at [+46C] +C40 |
| +3D4 | float | revs / 10 | `CalcRearWheels` |
| +54, +56 | int16 | front and rear slip angle, 65536 to a turn | `CalcTireDirection`: each the average of two tyres' angles in `car_work` (+43A/+346 front, +52E/+622 rear) |
| +DE6 | signed byte | drift window, frames | `RearGripCtrl`: 40 on a brake tap or a lift and re-press of the throttle (channels 9 throttle, 10 brake), down 1 a frame, kept open while the rear slip passes 0x2FF (4.2 degrees); 12 above 0x600. `HamIsDrift` = above 0 |
| +F18 | float | slipstream, 0 to 1 | `CheckSlipStream`; `DispSpeedMeter` shows the slipstream sign above 0.18 (with +172 within +/-1500) |
| +F28, +F2C, +F30 | int32 | SHIFT UP: frame count, showing, done | `CheckShiftWarning`: player car, no crash, not drifting, throttle 175 or more and no brake, speed (+3A0) over the gear's shift speed (+EC0 by gear): shows after 180 frames, stops at 480 |
| +4A4 | bits | crash motion: bit 0 running, bit 1 stiff, bits 2 to 6 kind (0 to 19), bits 7 to 9 reverse | `SetCrushMotion`, `CalcCrushMotion`; times from 0x081BDAC0 (1 to 3 s). Car hits (`SetCollisionImpactPlcar`) use kinds 7 and 3 |
| +480, +484 | float | crash motion time | `SetCrushMotion` |
| +64 | int32 | a car state `CheckGoal` needs non-zero and `CheckStageClear` needs not 1 (meaning not pinned) | |

## Race state and timing

* `current_mode` 0x08303CF4 (names from `GetModeStr`, table 0x081D34EC, 16 bytes each): 0 SYSTEM, 1 WARNING, 2 INFO,
  3 ADVERTISE (attract), 4 TITLE, 5 RATING, 6 ENTRY, 7 ADVEXIT, 8 ERROR, 9 MENU, 10 SELECTOR, 11 SELEXIT, 12 SELRESET,
  13 START, 14 RESTART, **15 GAME**, 16 GIVEUP, 17 GOAL, 18 TIMEUP, 19 LINK_TIMEUP, 20 RESULT, 21 CONTINUE, 22 ENDING,
  23 ROUTEMAP, 24 T_RANKING, 25 PASSWORD, 26 GAMEOVER, 27 GAMEEXIT, 28 GAMERESET, 29 G_NAMEENTRY.
* `observer_flag` 0x0830B740 (byte; cleared by `Observer_Init` and `Observer_Dest`): bit 0 time up (`CheckGameTimer`),
  bit 2 goal (`CheckGoal`: on the last stage, once the race's goal checks pass), bits 1 and 3 for one frame at a stage gate
  (`CheckStageClear`; `Observer_Ctrl` clears bits 1, 3, 5, 6 each frame).
* `over_state` 0x0830B8D4 (`CheckGameOver`): 0 racing, 1 goal, 2 time up, 5 time up in game mode 3.
* `game_mode` 0x08303D00 (`GetGameMode`); strings name OUTRUN MODE, QUEST MODE (Heart Attack), TIME ATTACK MODE.
* Clocks, frames at 60 a second, capped at 359,999: `game_timer` 0x0830B748 (stage time left, down), `total_timer`
  0x0830B74C (race, up), `now_lap_time` 0x0830B750 (this stage, up; reset at a stage gate), `prev_lap_time` 0x0830B754.
* `check_point_count` 0x0830B8CC (stage gates passed), `time_extend_count` 0x0830B8D0, `now_sector` 0x0830B8DC.
* Heart Attack: `heart_value_calc` 0x082FCD04 (`GetTrueHeartValue`), `heart_value_disp` 0x082FCD08.
* `pause_flag` 0x08303D09.

## Force feedback

`DrCtrlDataSet` and `DrCtrlMoveSend` drive the deluxe cabinet's wheel through the drive board (`strCtl` 0x0866C3E0):
coarse preset levels (4 to 15) chosen from the front slip angle, sent with `steerReqSendA`. Not a usable force signal; the
FFB Arcade Plugin's hook stays the source of the wheel force (USB capture).

## Rows added

`speed_kmh` (+3B0), `drift` (+DE6 between 1 and 127), `drift_angle` (+56 x 360 / 65536), unticked `front_slip`,
`slipstream`, `shift_warning`, unticked `crash_flags` with `crash_motion` and `crash_kind`, `main_mode`, `game_mode`,
unticked `observer_flag` with `goal`, `time_up`, `racing` (main_mode 15, no goal or time up), `stage`, `race_time`,
`stage_time`, unticked `last_stage_time`, `hearts`, `paused`. Common values: `car_in_race` = `racing`; `car_drift`
(ID6 weighting on the rear slip angle and `speed_kmh`) and `car_drift_angle`; no `car_grip_loss` row, so the plugin
uses Car_drift. Hits, walls, surfaces, speed, revs and gear keep their checked rows.

`Or2ReplayTests` feeds the four recordings' HUD flag in as main sequence 15 (no goal or time up), so the replays gate as
they did live: same results, 1737 tests pass with the pack.

## To settle in a recording

* `speed_kmh` against the speedo, and against `speed` x 0.7 (if it matches, `Car_speed` could move to km/h and Max speed
  to 280).
* The slip angle's sign (a right-hand drift should read +), and how `drift` follows her drifts.
* `racing` through the start, a stage gate and the finish line (or time up), and the attract mode.
* `crash_kind` numbers against what she sees (spins, flips, knocks); `game_mode` numbers per mode.
* SHIFT UP and slipstream against the screen.

Settled in Alexis's recording of 11 November 2026, 19:06 (`claude/OUTRUN2SP-capture-20261111.md`): all of the above,
except SHIFT UP (never shown) and the attract mode.

## Second pass (12 November 2026): for the next recordings

* **Car hit side.** `SetCollisionImpactPlcar` (0x08116EFE, player hits another car) first stores
  `CheckWhichSideColiHappen2(car)` in car **+10DE** (byte; absolute 0x0827AE7E). That function returns a bit mask: it
  walks the car's contact boxes (2 groups of 4 entries of 0x34 bytes from +510; the type at +1C maps 1 -> bit 1,
  3 -> bit 2, 2 -> bit 4, 0 -> bit 8) and, when none is set, takes `CheckWhichSideColiHappen`'s front/back result
  (bit 8 or 4) and side result (bit 2 or 1). That one first tests four words at car **+6C8, +6CC, +6D0, +6D4**
  (one pair reads as one side, the other pair the other). Which bit is left, right, front or rear is to match against
  marked hits. +10DE is also read by the linked-play driver change code; it may hold until the next hit. The same
  function sets the crash motion (kind 7 for a rear-end knock, as recorded) and raises car +43A (the wall-hit
  countdown byte) at car hits too.
* **Rev limit per car.** Car +46C points to the car's data. `CalcRearWheels` and `AccelOperation` compare the revs
  (+3D4, in tens) with car data **+1068** and **+1030** (floats, also in tens). +1068 is probably the limiter; the
  redline light on Alexis's car came on at 8,380 RPM (about 90% of Max revs 9300).
* **Course events.** `Observer_Ctrl` turns bits of 0x0830B744 (pairs: requested, done) into `observer_flag` 32 (the
  fork's easy arrow, confirmed) and 64 (nothing on screen in OutRun mode).
* `DispSpeedMeter` prints only the speed and the slipstream sign. (The rev dial, with its redline light, is drawn by
  `NaviPub_Disp`: see the third pass; the "3D dash" guess here was wrong.) `DispEasyInformation` draws the fork's easy
  arrow.

Rows added (unticked raw, recorded but unused): `hit_dir` (+10DE), `hit_box1` to `hit_box4` (+6C8 to +6D4),
`rev_limit` and `rev_1030` (car data +1068 and +1030 through `0827A20C`, x 10), `course_event` (0x0830B744).

## Third pass (12 November 2026): the rev dial and the hearts

* `NaviPub_Disp` draws the rev dial: frame = car **+3C4** (int, the revs smoothed 1/8 a frame toward the target in
  `CalcRearWheels`) / table[car **+0A**] x 180, capped at 179. The table (0x081D4260) holds 10,000 for all ten dial types;
  the sprite per type is at 0x081D4220. So each car has its own dial graphic, and the redline light is part of it. From
  Alexis's video on four cars the light comes on at about 8,270 revs (`shift_light`).
* `heart_value_calc` (0x082FCD04) keeps the hearts x 10,000 (172 hearts read 1,720,000).
* `game_mode`: 0 Time Attack, 1 OutRun, 2 Heart Attack, -1 in the menus.
* Car hits: contact words +6C8/+6CC = right, +6D0/+6D4 = left; +10DE bit 4 right, bit 8 left (checked against USB,
  `claude/OUTRUN2SP-capture-20261112.md`).
