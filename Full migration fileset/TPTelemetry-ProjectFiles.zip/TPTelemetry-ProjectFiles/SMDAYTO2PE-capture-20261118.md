# Daytona USA 2 Power Edition (SMDAYTO2PE): Alexis's recordings, 18 November 2026

Follows `SMDAYTO2PE-supermodel-20261118.md` (the addresses, found in the emulator). Three recordings with the 15:00 profile
(Max speed 350, Max revs 9500), USB capture and Supermodel's outputs on. She asked for effects to stay on in the rolling
start (they were).

| File | Course, car, gearbox | Her marks | End |
|---|---|---|---|
| 16:41 (SMDAYTO2PE-1) | Advanced (medium), NORMAL, manual | car hits; three on a drifting right hairpin | time up, TT 2:38.79, 12th |
| 16:47 (SMDAYTO2PE-2) | Expert (long), HARD, manual | some | time up, TT 2:27.07, 29th |
| 16:50 (SMDAYTO2PE-3) | Beginner (short), SPECIAL, automatic | three into the pits, three leaving on autodrive, three racing again | the finish line, TT 2:43.89, 23rd |

## What checked out

* `ram_probe` 2087778982 throughout. `playing`, `racing` (GO to time up or the line), `finished` (only the third),
  clocks, laps (the third: nine lines, last laps 17.8 to 18.8 s), lap times, positions.
* `countdown`: Beginner's rolling start (the game drives to 323 km/h) and the grid on Advanced and Expert (5.35 s,
  standing, revs to 9,089 on the throttle). Car_in_race covers both.
* `car_class`: 1 NORMAL, 2 HARD, 3 SPECIAL (EASY presumably 0).
* Inputs against USB: steering 0.92 to 0.98, throttle 0.76 to 0.95 (the game's throttle is 0 when it drives), brake 0.71
  to 0.81 (the game's brake byte reads in steps).
* Revs: NORMAL and HARD manual sit at 8,490 to 8,500 on the limiter (third gear: SMDAYTO2PE-1 lap 1 0:12.74 for 2.7 s,
  SMDAYTO2PE-2 lap 1 1:18.25 for 1.4 s); changing down to second at 266 and 291 km/h reads 10000 for 0.3 to 0.5 s (a
  ceiling). The SPECIAL automatic changes up at about 7,400 and reaches 7,680 in fourth at 329 km/h. **Max revs is now 8500**
  (one limiter for all; Car_rpm_frac clamps the 10000 moments to 1).
* Top speed 323 to 329 km/h; one sample read 436 km/h entering the pit lane (a glitch).
* **`contact_3c0` is car contact** (now `car_contact`, ticked; `car_touch` holds it 0.2 s): 0.002 to 0.55, with another
  car within 5 m every time, at her car-hit marks, never at walls. No side: in the emulator logs the touching car was
  ahead (4.4 m) or beside (1.7 to 2 m) on either side, and nothing near +0x3C0 follows the side cleanly (+0x3CC larger
  for left touches, overlapping).
* Wall hits by side: `hit_side` matched the wheel's kick over USB in most hits (the USB force runs about +-0.94 at a wall,
  + with walls on the right). The lap line and forks renumber the road strips, so all wheels at once read "off"; `edge_left`
  and `edge_right` now exclude each other.
* Drift angle sign: follows the steering in drifts (+ right), as in Scud; Beginner's left-hand bends read -.
* Force: the 0.1 s roll command against USB force, 0.19 to 0.24 (low, as before).

## Pit stop (SMDAYTO2PE-3)

Lap 6: the time left (34.89) stands still from 0:00.33 to 0:12.21 while the race clock runs; the game takes the throttle
and steering from the lap line, brakes to 33 km/h, stops (0:04.7 to 0:09.9), then drives out at a steady 167 km/h with the
time running, handing back at about 0:19.4 (the game's throttle follows hers again). The pit lane has its own strip numbers
(1085 to 1178; the lap is 0 to 571). New `pit_stop` = time left unchanged over 0.3 s while racing; `hit` is off then (it read
1 braking into the pit lane with cars close).

## Changes (17:05)

`car_contact`, `car_touch`; `hit`: 1 big crash, 0.4 to 1 touching a car (by how hard, 0.2 s), speed lost touching a wall
or car (not a car merely close any more); `pit_stop`; edges exclusive; Max revs 8500; notes say checked. In the Python
replay: 36, 38 and 31 hits in the three races (car touches the most). Tests: `D2peTests` adds the three recordings
(`capfixture.py` with PRE=SMDAYTO2PE): 2115 pass with the pack, 770 without.

## Asked (17:10)

SMDAYTO2PE-1 (Advanced):
1. Car hits at lap 1 0:05.11, 0:43.21 and 0:55.74 (her marks just after): which side of her car each time.
2. Lap 1 0:13.09: the hardest car touch of the race, unmarked: what happened.
3. Lap 2 0:05.00 to 0:05.49: the wheel at full left, then a big crash (314 to 154 km/h) before her three marks at 0:06.11:
   the drifting right hairpin? Which wall (reads left)?
4. Lap 2 0:23.25: a big crash reading the right-hand wall.
5. Lap 1 0:12.74: 8,490 in third for 2.7 s, the limiter? Where the needle sits. Lap 2 0:12.28: 10,000 for half a second
   changing down to second at 266 km/h.

SMDAYTO2PE-2 (Expert):
6. Lap 1 0:19.44 and 0:19.98: big crashes, left-hand wall then right?
7. Lap 1 1:12.84: a 3.3 s slide 30 degrees left with little steering; 2:14.81: a right drift growing from 56 to 82 degrees,
   then her mark at 2:17.82 (the angle swings through 175: a spin?).
8. Car hits at lap 1 0:04.96 and 0:07.93 (her marks): which side.

SMDAYTO2PE-3 (Beginner):
9. Pit stop as above: does control come back where her third set of marks is (0:21.02)? Effects run through the stop and the
   autodrive now (hits off while stopped): keep, or off while the game drives?
10. The SPECIAL automatic's change-up at about 7,400: where the needle sits.
11. Drift strength: lap 4 0:13.54, a left drift of 43 degrees (64 peak) reads 1.0; SMDAYTO2PE-1 lap 2 0:33.26, a right
    drift of 26 degrees reads 0.36. How strong each should feel.

## Her answers (17:35) and changes (17:50)

1. SMDAYTO2PE-1 lap 1 0:05.11 left rear, 0:43.21 right rear, 0:55.74 left rear. 2. 0:13.09 a hit on her mid right side
   (unmarked). 3. Lap 2 0:05.49: no curve, she steered hard left into the wall for a big crash (it reads left, correctly). The
   drifting right hairpin is lap 1 0:38.16 to 0:39.65, then she mounts the right-hand kerb (on it at 0:40.28).
   4. Lap 2 0:23.25: right-hand wall, her front right. 5. 8,490 is the limiter: about 8.2k on the dial; changing down
   4-3-2 for acceleration, the dial jumps to 8.8k at most (the 10000 reading).
6. SMDAYTO2PE-2 lap 1 0:19.44 left-hand wall, then thrown across almost head-on into the right-hand wall (both right).
   7. 1:12.84 a drift round a left turn; 2:14.81 a right drift growing, then the left-hand wall hard and a spin: **the
   drift's top angle (82 degrees) is 1.0**. 8. 0:04.96 front left, grinding along her left side; 0:07.93 front right,
   a smaller grind on her right.
9. SMDAYTO2PE-3 pit stop as described; keep effects on through it. 10. The SPECIAL automatic changes up at about 7.3k on
   the dial (no gear shown on screen); keep the effect. 11. Lap 4 0:13.54 drift about 0.8; SMDAYTO2PE-1 lap 2 0:33.26
   about 0.45. She wondered whether speed matters more in this game.
* Grid: keep effects on the grid, as Scud Race, revs at least from any standing start.

**The car-hit side is in the game's roll command:** at her four rear and side hits the game sent roll right (88, force
-0.56) for her left-rear hits and roll left (104, +0.56) for the right-rear and right-side hits, within 0.1 s of the
touch. The two front-corner hits sent 175 instead (not a roll; no side). The USB force at car touches is the FFB plugin
playing the same roll (about +-0.43).

Changes (17:50): `hit_side` for a car hit is the sign of `force` held from the roll command (needs -outputs=net), else the
wheels' side; Car_drift = ((|angle| - 10) / 72) ^ 0.6, clamped, times the speed part (full from 100 km/h): her points
read 0.46 (asked 0.45), 0.84 at 64 degrees (0.8) and 1 at 82 (1). Speed: all three drifts were at 260 to 295 km/h, so
the recordings can't show whether speed should count for more; the angle alone fits her three numbers. Car_throttle is
1 on the grid and in the rolling start (the engine follows the revs, as Scud). The fixtures now carry `out_RawDrive`
(`capfixture.py`), and the tests feed it: 2124 pass with the pack, 770 without.

Still open: car-hit side for front-corner hits (command 175); a slower drift to see whether speed should weigh more;
the Power Edition's other courses.

## Limiters by car (18:37 and 18:38, Mixed, manual)

She asked whether the cars keep their values in the same places: yes, one player record whatever the car; only
`car_class` changes. Two short recordings on the limiter:

* SMDAYTO2PE-4, EASY (class 0): first 7,455 to 7,880 (bouncing), second 7,500 to 7,640, third 7,544 to 7,610; 8,130 on
  the grid.
* SMDAYTO2PE-5, SPECIAL manual (class 3): second and third sit at 6,984 to 6,992 (third takes a while); first only
  reached 3,530; 7,298 on the grid. Its automatic (SMDAYTO2PE-3) changes up at about 7,400, above its manual limiter.

Changes (18:50): `rev_limit` by class (EASY 7650, NORMAL and HARD 8500, SPECIAL 7000) and `rpm_frac` = revs / rev_limit
(clamped 1.1; Car_rpm_frac clamps to 1), so the rev effects reach full on every car; the SPECIAL automatic reads full at
each change-up. Max revs stays 8500. `D2peTests.Limiters` replays both: 2134 pass with the pack, 770 without.


## The dial is not `rpm` (18:50)

Alexis, SMDAYTO2PE-5 (SPECIAL manual): at lap 1 0:01.947 in first the dial is stuck at 8.2k with the limiter light on
and the engine screaming (`rpm` read about 3,500 at 48 km/h); she changes up at about 0:02.105; second and third top out
at 7.4k on the dial, as the automatic (`rpm` 6,990 manual, about 7,400 automatic).

`rpm` (+0x1DC) is the wheels' revs: revs per km/h in each gear are the same on every car (first about 72, second 38,
third 26, fourth 21.6), so wheelspin and clutch slip don't show. Dial readings so far: NORMAL/HARD `rpm` 8,500 = 8.2k,
10000 = 8.8k; SPECIAL automatic 7,400 = 7.3k; SPECIAL manual 6,990 = 7.4k; SPECIAL first 3,500 = 8.2k (limiter).
In the emulator log (NORMAL, rolling start) +0x2C8 (float, radians a second) times 9.5493 matches `rpm` while driving,
holds 6,000 in the rolling start and 9,999 at the 10000 ceiling; +0x1E0 lags `rpm` across gear changes. Both added as
recorded rows (`engine_rpm`, `rpm_1e0`, 19:00) to compare with the dial in a SPECIAL manual launch. If one matches the
dial, Car_rpm and the limiters move to it.

## The rev counter found (18:57 recording, changes 19:10)

SMDAYTO2PE-6, Mixed, SPECIAL, manual, her marks on the limiters (dial as before). `engine_rpm` (+0x2C8) equals the old
`rpm` throughout: dropped. `rpm_1e0` (+0x1E0) is the rev counter: at the standing start it climbs to 8,500 by lap 1
0:01.72 and sits there to 0:02.04 while the wheels' revs are 2,960 to 3,620 (42 to 50 km/h): the dial stuck at 8.2k with
the limiter light; it meets the wheels' revs by 0:02.35, and lags a moment at each change up. Limiters in this recording:
first 8,500 (124 km/h), second 7,812 (182 km/h), third 7,793 (264 km/h; creeping up from 7,687). The same speeds in
SMDAYTO2PE-5 sat at 6,990 in second and third, so the revs at a gear's top speed vary between runs; she reads both as 7.4k.

Changes (19:10): `rpm` now reads +0x1E0 (the rev counter); the old +0x1DC is `rpm_wheels`; `rev_limit` EASY and SPECIAL
7650 (SPECIAL at the same place on the dial as NORMAL's 8,500 is to 8.2k, for her 7.4k), NORMAL and HARD 8500. Older
fixtures feed +0x1DC as `rpm` (they have nothing else); `capfixture.py` maps the 18:57 recording's columns. Tests: the
launch and the three limiters: 2140 pass with the pack, 770 without.
