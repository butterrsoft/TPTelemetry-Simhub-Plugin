# TP Telemetry: change history, 18 November 2026

The 18 November work (Scud Race and Daytona USA 2 Power Edition in Supermodel, their own thread; Sega World Drivers Championship from its exe, another), newest first. Continues
`TPTelemetry-History-20261117.md` (whose last entry, `ram_probe` back in FLYINITD3, is also 18 November).
`SMSCUD-supermodel-20261118.md` has the detail.

### 18 November, evening: Sega World Drivers Championship from its exe; plugin 0.19.0 (helper 0.18.0)

A separate thread (SWDC). Alexis attached `Todoroki-Win64-Shipping.exe` v2.30 (MD5 94ed0ba0..., UE 4.17). Detail in
`SWDC-exe-20261118.md`.
* The player's physics values are blueprint variables (not in the exe); the cheat table's speed2/gear2 go through UE's
  object name-hash map. The exe does hold `UCarLibrary`'s native per-car records, filled by the blueprints: data model
  Q = `[[[<main>+4B07438] + 278] + 10]`, your car number Q+16D0, records `[Q+2550]` (0x578 each), time left Q+2C18.
* **Plugin 0.19.0, helper 0.18.0**: indexed offsets `[rel]*size` (the chain reads an Int32 at the current address + rel and
  steps that many records on at the next pointer). Hex.IndexHop in Model.cs, MemorySource.Walk; the read plan carries it
  unchanged. README offsets doc and Changes.
* SWDC profile (`moregames.swdc_rows`, commonrows, gamesetup): your record's race state (2 racing, 3 finished) drives
  `in_race`; speedo km/h, revs, gear, brake, place, class place, lap, sector, sparks left/right, backfire, position and
  heading, drift angle from heading against travel; Car_speed in km/h (Max speed 230); the table's rows kept as
  fallbacks (`in_race_revs` was `in_race`). Not yet checked in a recording.
* Tests: indexed offsets in `PointerWalk`; the record path in `MemProfilesTests`; `SwdcReplayTests` allows the new rows
  missing from the 3 November recordings. 2162 pass with the pack, 777 without; compile check ok.
* Tools: `ue4/` (RIP-relative xrefs, function disassembly with strings, reflected properties, class sizes, native
  function tables, callers, SWDC's model slots and record fields).

### 18 November, 19:10: Daytona USA 2 PE, revs from the rev counter

* Her SPECIAL standing start (18:57): +0x1E0 is the rev counter (8,500 with the wheels spinning, the dial stuck at 8.2k),
  now `rpm`; +0x1DC is `rpm_wheels`; `engine_rpm` dropped (the same as +0x1DC). `rev_limit` EASY and SPECIAL 7650,
  NORMAL and HARD 8500. 2140 pass with the pack, 770 without.

### 18 November, 19:00: Daytona USA 2 PE, the dial is not `rpm`

* `rpm` follows the wheels (the SPECIAL's first-gear wheelspin reads 3,500 where the dial shows 8.2k). Two candidate rows
  recorded for the next capture: `engine_rpm` (+0x2C8 radians a second x 9.5493) and `rpm_1e0`. Tests unchanged (2134).

### 18 November, 18:50: Daytona USA 2 PE, a rev limit for each car class

* Two recordings on the limiter (Mixed, manual): EASY is class 0 and sits at 7,600 to 7,900; the SPECIAL manual at 6,990.
  `rev_limit` by class (7650, 8500, 8500, 7000) and `rpm_frac` from it. 2134 pass with the pack, 770 without.

### 18 November, 17:50: Daytona USA 2 PE, her answers

* Car-hit sides from the game's roll command (four of four; front-corner hits send 175, no side); crash sides confirmed;
  Car_drift fitted to her three points (0.45 at 26 to 30 degrees, 0.8 at 64, 1 at 82); Car_throttle 1 on the grid and in
  the rolling start; effects on through the pit stop; limiter 8,500 = 8.2k on the dial. Fixtures carry `out_RawDrive`.
  2124 pass with the pack, 770 without.

### 18 November, 17:10: Daytona USA 2 PE checked in Alexis's three recordings

* Advanced (NORMAL, manual), Expert (HARD, manual), Beginner (SPECIAL, automatic, pit stop, to the finish): race gate,
  clocks, laps, the grid and the rolling start (effects kept on there, as she asked), inputs against USB, car class.
* Changes: `contact_3c0` is car contact (`car_contact`, `car_touch`; no side); `hit` from car touches by strength, not a car
  merely close; `pit_stop` (time left still), no hits then; edges exclusive (the lap line renumbers the strips); Max revs
  8500 (the manual limiter). `D2peTests` adds the three recordings: 2115 pass with the pack, 770 without. Eleven questions
  (`SMDAYTO2PE-capture-20261118.md`). Tools: `capfixture.py` takes PRE=SMDAYTO2PE.

### 18 November, 15:00: Daytona USA 2 Power Edition (SMDAYTO2PE); Scud Race answers

* Alexis sent `dayto2pe.zip`, `daytona2.zip` and `dayto2pe.nv`, and asked to focus on the Power Edition alone. New
  profile `SMDAYTO2PE` (Supermodel folder; `SMDAYTONA2` unchanged): its values found in the emulator as Scud's were
  (`SMDAYTO2PE-supermodel-20261118.md`): in-game byte, time left, race clock, the car record at 0x501000 (speed, revs,
  gear, pedals, steering, movement, heading, crash timer, laps, lap times, position, road strips, near car); `racing`,
  `countdown`, `finished`, `time_extended`, `hit`, `wall_contact`, `drift`; force with Scud's 0.1 s hold (`short_force`);
  lamps. Car_ values from the start to the line or time up, 0 outside. Not yet checked in a recording.
* Scud Race: F40 rev limit 9040 (her TT 0:15.30); Car_throttle 1 on the grid so the engine follows the revs.
* Game_Setup.md: the "Outputs must be switched on, or nothing reads" line left off for emulator games read from memory
  (Initial D 3, Scud Race, Daytona 2 PE), where it was wrong.
* Tests: `D2peTests.cs` (two emulator logs: finish, time up) and two Scud checks: 2094 pass with the pack, 770 without.
  Pack 107 profiles. Tools: `aipath.py`, `autopilot.py` (`GAME=d2`, `UP`/`DOWN`), `runsm.sh` (`GAME`), `menu_d2mt.sh`.

### 18 November (13:45): Scud Race, her answers and a fifth recording; Daytona 2 needs its ROMs

* Car contact sides confirmed (F40 recording: ahead, left, right, left); wall hits by side right; REVERSE! at the
  `wrong_way` reading. `hit` 0.5 at a car's first touch; `light` (front wheels lifting over a crest) -> Car_airborne 0.5;
  Car_drift straight from 14 to 58 degrees from her two F40 points (0.9, 0.65); `grid` on Medium and Expert: Car_in_race,
  revs and gear before GO; F40 rev limit 9000 (guess); Scud's `force` lasts 0.1 s after a roll command (matches USB
  better). Verge lanes noted, not fixed. 2066 pass with the pack, 770 without.
* Her Daytona 2 PE recording used the SMSCUD profile: the RAM pointer works (ram_probe), nothing else lines up. Asked for
  `daytona2.zip` and `dayto2pe.zip`.

### 18 November (13:00): Scud Race checked in Alexis's four recordings

* Porsche and Viper (manual, Beginner night), McLaren (manual, Medium), F40 (automatic, Expert, pit stop); the Viper to the
  finish line. `ram_probe` right throughout; racing gate, clocks, laps, time extensions (26.67 s lap lines, 14.23 s
  checkpoints), steering and throttle against USB, gears checked. `SMSCUD-capture-20261118.md` has the detail.
* Changes: `racing` ends within 0.04 s of the clock stopping (the state's top byte, which is the finishing place less 1:
  `final_position`, `finished`); `pit_stop` (time left frozen); `airborne` from free fall in `move_y` (every jump mark);
  `car` (car record +0x105: 4 Porsche, 5 Viper, 6 F40, 7 McLaren, found in the emulator), `rev_limit` (7200, 7200, 9500
  guessed, 8500) and `rpm_frac`; Max revs 9500; `wheel_angle` was not the wheels' angle (now unticked `misc_2c4`), so
  Car_cornering from steering and speed; Car_drift full at 70 degrees, 0 going backwards; from the emulator, `car_contact`
  (+0x2F7: 0 left, 2 right, 3 ahead, 1 behind), `car_side`, `car_touch`, `near_car`; `hit` also from km/h lost while
  touching a wall or car; `wrong_way` from the strip numbers. `ScudTests` adds three of her recordings: 2056 pass with
  the pack, 770 without. Ten questions asked (end of the capture note).

### 18 November: Scud Race (SMSCUD) reads Supermodel's RAM

* Alexis sent `supermodel.exe` (0.4-dev, git 0b82a98, MD5 440c8330...) and `scud.zip` (Supermodel's `scudau`). The RAM
  pointer from the exe: `[[<main>+AE6280] + 8] + game address` (the PowerPC core's fetch regions); bytes at A ^ 3, 16-bit
  at A ^ 2. The game's values found by building the same Supermodel source on Linux with a logger patch and driving the
  Beginner course headless (an autopilot following the computer cars' paths), against screenshots.
* Profile (76 rows, Process `supermodel.exe`, 64-bit, Max speed 350, Max revs 7500): race phase and `racing` (3-2-1
  countdown to the finish line or time up), time left, race clock (frames / 57), laps, lap times, position, RETIRE,
  `time_extended`; speed, revs, gear, throttle, brake, steering, front wheels' angle; crash timer -> `hit`; wheels on
  other road strips -> `edge_left`/`edge_right`/`wall_contact`; drift angle from heading against movement, ID6's drift
  curve full at 45 degrees; lamps from outputs; five unticked candidates. Common values from memory, all 0 outside a race
  (`commonrows.py`). Force rows unchanged; SMDAYTONA2 and SMLEMANS24 unchanged.
* `ScudTests` (27 checks) replays three logs from the emulator through the profile: the finish line, time up, the left
  barrier. 2026 pass with the pack, 770 without. No plugin change (0.18.2, helper 0.17.1).
* Tools: `supermodel/` (the logger patch, run and key scripts, log reader, value finders, autopilot, fixture writer,
  PowerPC ROM tools). Not yet checked in one of Alexis's recordings.
