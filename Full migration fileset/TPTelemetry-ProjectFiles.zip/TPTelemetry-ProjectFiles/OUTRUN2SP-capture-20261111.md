# OutRun 2 SP recording, 11 November 2026 (19:06)

Alexis's first recording with the rows from the game's own variables (`claude/OUTRUN2SP-exe-20261111.md`). 392 s,
29 marks: the third-last is the finish line, the second-last well into the post-race menus, the last back at the title.
Lots of drifts, slipstream and wall hits (her note). Times are recording seconds; RT is the time left on screen, TT the
race clock.

## Race gate

| Time | main_mode | What |
|---|---|---|
| 21.15 | 11, then 13 (START) | the start sequence: car still, idling |
| 34.18 | 15 (GAME) | GO: `racing` and `Car_in_race` on |
| 96.83, 157.95, 219.38, 277.36 | | stage gates: observer_flag 10 (bits 2 and 8) for a frame, `stage` 2 to 5, `checkpoint`, the stage clock restarts, time added |
| 331.90 | 17 (GOAL) at 331.93 | finish line (her mark 332.07): `goal`, `racing` and `Car_in_race` off; race clock 4:55.75, RT 4.2 |
| 341.96 to 386.88 | 22 ending, 23 route map, 24 ranking, 25 password, 26 game over, 27 exit | |
| 386.90 | 2 | back towards the title |

`game_mode` read 1 throughout. The old `in_race` row (the HUD flag) ran 32.16 to 382.88, well into the menus, so
`racing` is the right gate.

observer_flag also set 64 and 32 for one frame twice in each stage, about 45 s and 13 s before the next gate (48.30
and 83.63 s in stage 1; 130.33, 143.26; 194.91, 205.48; 240.55, 263.81; 292.50 in stage 5). `Observer_Ctrl` sets them
from a course event byte (0x0830B744); not yet named.

## Speed

`speed_kmh` is the speedo: 1.018 x the speed row x 0.7 through the race (1.016 to 1.033 by speed band), top 312 km/h.
Since this recording `Car_speed` is `speed_kmh` (km/h) and Max speed is 280 km/h (Alexis's top, as before); the `speed`
row converts its game units to km/h (x 0.7) before dividing, so its fraction is unchanged, and `accel_g`, `g_fast` and
`hard_hit` now work in km/h.

## Drifts

`drift` (car +DE6) on 15 times, 2 to 10 s each at 213 to 307 km/h, with the rear slip angle peaking at 60 to 78
degrees either way (one short 0.7 s window at 4 degrees). `Car_drift` reached 1 in every real drift: OutRun's slides
are far deeper than Initial D's 50-degree full scale. Steering correlates only -0.25 with the angle (she counter-steers),
so the sign needs her video:

| Time | RT | TT | Angle |
|---|---|---|---|
| 93.31 | 42.8 | 0:57.18 | +66 |
| 133.10 | 61.0 | 1:36.97 | -75 |
| 225.78 | 69.3 | 3:09.65 | +72 |
| 285.43 | 50.7 | 4:09.30 | -60 |

The slip angle swings to 180 when the car is barely moving (before GO, after the crash at 296 s); the row now reads 0
under 10 km/h.

## Crashes and walls

`crash_flags` (car +4A4): bit 1 for the motion's first frame, bit 2 while it runs, bits 4 to 64 the kind, kept
afterwards. The old `crash_motion` (bit 1 only) lasted one frame; now bits 1 or 2:

| Time | RT | TT | Kind | Motion | What else |
|---|---|---|---|---|---|
| 108.01 | 86.1 | 1:11.88 | 7 (car hit) | 1.5 s | `hard_hit` 108.05 |
| 182.63 | 65.5 | 2:26.50 | 7 | 1.5 s | `crash` and `hard_hit` |
| 296.41 | 39.7 | 4:20.28 | 1 | 2.5 s | right-hand wall; the speedo fell 267 to 72 km/h in a frame and held 72 to 298.9 s, then 0 (the car put back) |

The speed row only falls 0.5 s after the speedo (as on 2 November), so `Car_impact` reached 1 at 296.95 s, not 296.41.
`Car_impact` is now 1 the moment a crash motion starts, held 0.3 s.

Wall hits (`wall_hit`, side): 63.16 left, 97.40 right, 153.44 left, 154.61 right, 296.41 right. `crash` (the game's
crash count) 12 times. Car_impact 0.5 to 1 at 18 hits in all.

## Slipstream, SHIFT UP

`slipstream` over 0.18 (where the speedo shows its sign) 50 times, 0.1 to 11.8 s (the longest 106.26 to 118.0 s, RT
87.8). `shift_warning` never set, though `transmission` read 1 (manual) in the race: to ask whether SHIFT UP showed.

## Marks

| Time | RT | Near it |
|---|---|---|
| 32.84 | 100.0 | before GO |
| 36.68 | 99.4 | just after GO, 14 km/h |
| 42.72 | 93.4 | rumble strip and off road 42.2 to 43.3 |
| 54.07, 56.84 | 82.0, 79.3 | slipstream 53.46 to 56.66 |
| 62.97, 63.92 | 73.2, 72.2 | crash 62.20, left wall 63.16, verge |
| 79.05 | 57.1 | rumble strip 78.86 |
| 88.33 | 47.8 | end of slipstream 80.0 to 88.2; off road 86.79 |
| 103.77, 107.09 | 90.3, 87.0 | slipstream; crash 105.88 |
| 108.34 | 85.8 | traffic crash, crash motion 108.01 |
| 126.90, 161.97 | 67.2, 86.2 | in slipstream |
| 182.77 | 65.3 | traffic crash 182.63 |
| 211.86, 214.02 | 36.2, 34.1 | off road 210.68, 213.33 |
| 220.02 | 75.1 | stage gate 219.38 |
| 229.52, 254.48 | 65.6, 40.6 | in drifts |
| 234.37, 258.96 | 60.8, 36.1 | slipstream |
| 262.54 | 32.6 | nothing found |
| 277.54 | 58.6 | stage gate 277.36 |
| 297.57 | 38.5 | wall crash 296.41 |
| 318.96 | 17.2 | slipstream 317.06 |
| 332.07 | 4.2 | finish line |
| 344.10, 388.47 | | menus, title |

## Profile changes

* `Car_speed` = `speed_kmh`; Max speed 280 km/h; `speed` row x 0.7 (unchanged fraction); `accel_g`, `g_fast` without
  the 0.7; `hard_hit` above 14 km/h.
* `crash_motion` = bits 1 or 2; `Car_impact` 1 at a crash motion's start.
* `drift_angle` 0 under 10 km/h.
* Notes marked checked: `speed_kmh`, `drift`, `crash_motion`, `racing`, `stage`, `race_time`, `stage_time`.
* `Or2GameTests` replays this recording (fixture in the game's units): Car_in_race 34.18 to 331.89 and not in the start
  sequence or menus, Car_speed top 312 km/h, the four gates, the three crash motions and kinds, Car_impact 1 at the
  wall crash, Car_drift in eight drifts, no slip angle under 10 km/h.

## Alexis's answers (21:07)

1. Drifts: 93.31 s a right turn (and a car hit on her front right a second in, the crash at 94.9 s); 133.10 s a left
   turn (past a rival, then an RV on her front right, the crash at 136.88 s); 225.78 s a right turn (crossing over a
   little at the end); 285.43 s a left turn. So + is a right-hand drift: confirmed.
2. Crashes: 108.01 s into the back of a truck, rear wheels off the ground; 182.63 s into the back of a bus, rear wheels
   off the ground; 296.41 s a massive crash against the right-hand wall, the car flying and flipping a few times. So
   kind 7 is the rear-end knock with the rear lifting, kind 1 the flip. New `crash_air` (Car_airborne): 0.5 for the
   first 0.6 s of a kind 7, 1 through a kind 1.
3. SHIFT UP: probably never shown; she never rode the redline. The redline light was on at TT 0:07.757 (43.88 s:
   8,740 RPM in third; she shifted at about 8,850). No rev-lamp variable found in the HUD code (`DispSpeedMeter`
   prints only the speed and the slipstream sign); the light is likely on the in-car dash model.
4. Slipstream matches.
5. 64 at 48.30 s: nothing on screen. 32 at 83.63 s: the "easy" arrow for the left side of the fork. New `fork_sign`
   (held 3 s).
6. Marks: 36.68 her attempt to mark the start; 79.05 a ripple strip; 126.90 slipstream on the rival car (faster than
   traffic, labelled); 161.97 slipstream; 262.54 not sure.
7. OutRun mode: `game_mode` 1.

Traffic-hit sides: with USB capture on, the plugin took them from the wheel force: her front-right hit at 136.88 s read
right; the one at 94.9 s read left for 0.07 s, then right. Without USB the game gives traffic hits no side that we read yet (`SetCollisionImpactPlcar` is the
place to look).

Tests: `Or2GameTests` also checks the drift signs, Car_airborne at the three crashes and `fork_sign`. 1784 pass.

## Alexis's answers (21:32)

1. The fork's easy arrow: 3 s sounds right, so `fork_sign` stays at 3 s.
2. The redline light comes on at TT 0:07.375: 8,380 RPM in third (between 8,370 at 7.367 and 8,390 at 7.383; about
   90% of Max revs 9300). New `shift_light` = `rpm * max_revs >= 8380`, as she asked. Set from her car and
   video, not the game's code; other cars may light at other revs.
3. Car_drift for this game alone: full at 75 degrees (`clamp((|angle| - 5) / 70)`, same eased curve and speed weighting).
   Only the OUTRUN2SP clause in `commonrows.py` changed; the pack diff showed no other profile touched. A 60-degree drift now
   reads 0.95, a 78-degree one 1.

`Or2GameTests` checks both. 1786 tests pass with the pack, 764 without.

## Open

1. What observer_flag bit 64 is (nothing on screen).
2. The traffic-hit side without USB capture (`SetCollisionImpactPlcar`).
3. Whether other cars' redline lights come on at other revs (`shift_light` is 8,380 for all).
4. Still to see: the attract mode; Heart Attack and Time Attack `game_mode` numbers.

## Test plan for the open points (12 November 2026)

The profile now records the raw rows for these (see `claude/OUTRUN2SP-exe-20261111.md`, second pass). Re-import it first.

* **Recording A** (USB capture on, OutRun mode, her usual car): about three clean side-swipes on traffic on each side
  and a couple of rear-end hits, each marked with its side; a mix of shallow and deep drifts, with the strength she'd
  want for a few; the TT when the redline light comes on in 2nd and 3rd. The wheel force gives each hit's side, so
  `hit_dir` and `hit_box*` can be matched to it, to give the side without USB.
* **Recording B**: one or two other cars (one low-revving, one high), short runs at full throttle through 1st to 3rd,
  the TT the redline light comes on, and a moment on the limiter in one gear. Then compare with `rev_limit`: if the
  light is always about 90% of it, `shift_light` follows each car.
* **Recording C**: a Heart Attack run (watch for anything at the `observer_flag` 64 moments, about 45 s before each
  gate: a task, a voice, a sound), a Time Attack run (`game_mode` numbers), then leave the game in attract mode for a
  few minutes (`racing` must stay 0). Taking the other side of a fork once shows whether the 32/64 moments move.
