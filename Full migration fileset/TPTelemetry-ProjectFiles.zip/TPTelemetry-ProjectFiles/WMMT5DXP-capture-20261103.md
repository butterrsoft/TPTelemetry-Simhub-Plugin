# WMMT5DX+ recording, 3 November 2026

`20261103-101336_WMMT5DXP.csv`: 36 s in a race, no markers, USB capture on, made with the Outputs script
rows ticked. Gears 2 to 6, 129 to 224 km/h, hits at about 4.0 to 5.0 s (a run of 0.5 kicks), 11.4, 18.8 and
25.2 s (221 to 153 km/h), throttle off at 35.4 s. Fixture `wmmt5dxp-20261103-101336.csv.gz` (raw reads,
`usb_throttle` for reference), replayed by `Wmmt5OutputsReplayTests`.

## The script's rows against the checked ones

| Row | Result |
|---|---|
| `speed2` | The same speed as `speed`: 0.3 to 0.85 km/h above it (median 0.59), as the whole number is rounded down; no lag (at the 25.2 s hit it dropped one sample sooner). Updates 60 times a second; `speed` changes about 7 times a second (only when it passes the next km/h). **Lines up.** |
| `rpm2` | Moves with `rpm` at the same moments (r 0.999) but on a wider scale: rpm2 = 1.285 x rpm - 1922 (sd 46 rpm). They agree near 6750; at the limiter in 2nd rpm2 reads 8700 where rpm reads 8270, and after the 25.2 s hit 4700 where rpm reads 5150. rpm2 holds steadier against road speed in 3rd to 5th (spread 0.5 to 0.7% against 0.7 to 0.8%). **Doesn't line up**: one of them is likely the tacho and the other the engine or the sound. |
| `race_time2` | The same clock as `race_time` to the frame. Both stood still for 0.15 s at 10.86 s (a game hitch). |
| `throttle` | Matched the G25's throttle over USB (r 0.997). `pedals_a` and `pedals_b` were identical all through. |
| `brake` | 0 (not used in the run). |
| `turbo` | 1.5 on full throttle, falling at hits and lifts, -0.5 off the throttle. |
| `distance` | Grew 1895 m; integrating speed2 gives 1899 m. |
| `place` | 1 throughout; order read 0, 1, 2, 3. Still to check in a race with rivals. |

`accel_g` from speed2 jittered 0.067 G when accelerating steadily in 6th (20 to 24 s), against 0.103 G
from `speed`.

## Changes (Alexis, 3 November 2026)

* `Car_speed` = `valid(speed2, speed) * max_speed`; `accel_g` (so `Car_accel_g`) from
  `valid(speed2, speed)`. The speed row stays. `valid()` falls back to it when speed2 can't be read (its
  pointer may be empty outside a race).
* `gear_raw` + `gear = gear_raw` merged into one `gear` memory row on all six WMMT5/6 profiles.
* **10:40, Alexis:** use rpm2 and race_time2 as well, keeping every row. `Car_rpm` =
  `valid(rpm2, rpm) * max_revs`, **Max revs 8900** (was 8250; the rpm2 limiter in 2nd, about 8700, is
  97.8%: the rev limiter effect is on at the limiter in 2nd and nowhere else in this run). `in_race` =
  `valid(race_time2, race_time) > 0 && maxw(delta(valid(race_time2, race_time)) > 0, 0.1)`. race_time2
  is back in the table (it had been dropped at 10:30). rpm2's formula is now
  `value < 0 ? 0 : value / max_revs` (the old `max(value, 0)` turned an unreadable value into 0, so the
  fallback to rpm never happened). The 1 November race fixture has no rpm2, so its test replays with
  Max revs 8250.

## Turbo, for later effects

The gauge reads 1.5 at full boost and dips to about 0.94 at every upshift (5.86, 8.81, 12.82, 16.46 s),
sags after a hit and takes about 4 s to come back (25.3 s), and drops to -0.5 within a fraction of a
second when the throttle is lifted (35.36 s): a blow-off moment.
