# STCC RAM log checks, 5 November 2026

Two logs from tptram.lua v2 (RAM2 0x200000-0x240000 and 0x500000-0x510000, 3072 dwords a frame, a full pass about every 0.47 s), each with Alexis's event list from video (marks at the exact frame; unmarked times approximate, on the log's timeline).

## Log 1: TPTRAM_stcc_20261105_170400

5810 frames over 104.7 s (os.clock).

| Mark | Log s | Her reading |
|---|---|---|
| 1 | 72.24 | race time 23, elapsed 16.605, 5th, revs ~4.5k, 97 km/h |
| 2 | 75.40 | race time 20, elapsed 19.479, 5th, revs <4k, 50 km/h |
| 3 | 78.69 | race time 17, elapsed 22.463, 5th, revs ~4.8k, 106 km/h |
| 4 | 84.79 | race time 12, elapsed 27.977, 5th, revs ~12.3k, 272 km/h |
| 5 | 85.20 | race time 11, elapsed 28.352, 5th, ~12.3k, 274 km/h |
| 6 | 86.96 | race time 10, elapsed 29.945, 5th, ~12.3k, 257 km/h |
| 7 | 95.63 | race time 2, elapsed 37.803, 5th, ~12.4k, 274 km/h (just before the finish) |

Unmarked: 38.1 name entry, 47.9 loading race, 52 driver view revving, 54 start, gear limits 126 (2nd), 157 (3rd), 208 (4th), 5th by ~61.5; 63-65 LHS kerb (kiss LHS wall ~64); 67 right turn skid onto RHS grass; ~83 RHS grass verge at ~266; ~90.2-90.4 three cones. Tacho: a bar from 4k to 14k; 14k+ at the 1st-gear limiter.

## Log 2: TPTRAM_stcc_20261105_202221

Marks (log s): 1 21.34 attract, 2 26.13 coin in, 3 43.86 name confirmed, 4 50.01 driver view + throttle, 5 52.82 race start, 6 61.27 (skid, RT 32, ET 7.701, 11.4k, 234), 7 65.04 (skid, ET 11.106, 11.4k, 225), 8 71.71 (end of left-turn skid after the RHS wall, ET 17.152, 9.8k, 185), 9 73.33 (out of skid, ET 18.620, 11.7k, 235), 10 76.00 (slight skid, ET 21.041, 11.7k, 241), 11 77.52 (skid, ET 22.416, 10k, 177), 12 82.89 (long right, screeching, ET 27.290, 12.2k, 257), 13 86.27 (finish line, ET 30.351, 12.3k, 277). Also: small skid in 3rd at ~157; rear wheels off ET 9.028-9.450; RHS wall just before ET 16.558; rear-right kerb ET 17.667.

host_state: 0, 1 at 15.9 (attract, also at coin-in), 5 at 28.0, 6 at 37.7, 7 at 38.2 (name entry), 9 at 46.6 (loading race onwards).

## Found (all in RAM2; TP Telemetry Base 1AA8F4, Offsets "200, <address>")

* **0x2022CC** Float: elapsed race time in seconds; stops at the finish.
* **0x2022EC** UInt16: time left in 1/64 s (2568 = 40 s at the start).
* **0x20462C** / **0x208934**: gear, 0 before the race, 1 to 5.
* **0x204634** UInt16: the speedo's km/h; freezes at the finish (display block 0x2046xx).
* **0x20893C** Float: speed, x 64 = km/h at every steady point; keeps reading after the finish. In skids it reads 5-10% above the speedo (M6 249 vs 234, M11 239 vs 214); equal on the straight (M13 278 = 278).
* **0x20463C** UInt16: the tacho's revs, x 1.2 = her bar readings; freezes at the finish. = 0.898 x 0x208914.
* **0x208914** Float: revs the tacho shows (x 1.078 = bar reading: 12.5-12.8k at the gear limits, 9.8-11.4k in skids, 12.3k flat out). **Now `rpm`**, Max revs 12700 (97% = 12320, reached on the limiter only).
* **0x208788** Float: engine revs: equal to 0x208914 on the grid, higher whenever the wheels spin (13130 at launch, ~12000 in skids where the tacho read 9.8-11.4k). Was `rpm`; now `rpm_engine`.
* **0x208886** UInt16: surface per wheel, one hex digit each: 2 road, 3 kerb, 4 grass (log 1; no surface change was caught in log 2, the kerb touches were brief). Digits 1 and 3 (0x4_4_) are the right wheels.
* **0x20AC70** Byte: 1 with any wheel off the road (log 1).
* **0x208950 / 58** (front) and **0x208960 / 68** (rear) Float: tyre slip angles, + in right-hand turns, 0 with wheels in the air. Rear: under 0.25 cornering, 0.3-0.45 slight skids (M6, M10, M12), 0.6-0.65 big ones (M7, M11), -0.45 in the left-turn skid (M8). `grip_loss` = clamp((abs(rear) - 0.2) / 0.4, 0, 1).
* **0x202094** host_state as above.

## Candidates (rows added so a recording can confirm them)

* **0x20AD90** `skid_flag`: 1 through stretches of skidding and tyre squeal in both logs (log 1: 67.0-68.4, 85.7-87.1, 93.1; log 2: 63.4-69.4, 70.8-73.2, 76.0-78.7).
* **0x20AC8C** `wall_flag`: 1 at 71.3-72.2 in log 2 (the RHS wall hit), never in log 1 (its wall kiss was brief).
* **0x20ACD4** `air_flag`: 14 at 62.92, 0 at 63.38 in log 2 (rear wheels off); never in log 1.
* 0x20AC80 / 0x20AC88: 0/1 in some skids and the rear-right kerb (log 2 65.25, 68.5, 72.2, 75.95, 77.3); 0x20ACC0 (0-32) / 0x20ACC4 (0/1): on at launches, gear changes, kerbs, skids and the jump (32 at 62.92): maybe tyre sound.
* 0x208790 Float: drive force? 0 off the throttle (log 1) and with the rear wheels in the air (log 2, 62.90).
* 0x2088F8 Float: heading in radians. 0x208784 / 0x208944: engine power or torque (0 off the throttle). 0x200A14 changed at the cones (log 1). Cones are objects at 0x213C00/D00/E00.

## Profile M2STCC (pack, 5 November evening)

Rows: speed, speed_kmh, rpm (0x208914 x 1.078 / max_revs), rpm_engine, rpm_display, gear, race_time, in_race = maxw(delta(race_time) > 0, 1), time_left, surfaces, rumble_strip, off_road, off_track, slip_front, grip_loss (reads 0x208960; tidy merged slip_rear into it), skid_flag, wall_flag, air_flag, host_state; FFB and lamps as before. MaxSpeed 270, MaxRevs 12700. 1440 tests pass; 46 variables, 0 errors.

Next: a TP Telemetry recording of STCC with USB capture (markers at skids, a wall hit, a jump, kerbs) to confirm the candidate flags at full rate, the force decode (hold vs FeedbackLength), and whether rpm or rpm_engine suits the engine effects better.
