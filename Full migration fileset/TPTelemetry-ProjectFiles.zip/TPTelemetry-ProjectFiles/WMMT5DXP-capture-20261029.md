# WMMT5DXP capture check, 29 October 2026

Recording `20261029-110840_WMMT5DXP.csv`: 78.9 s, 120 Hz, 15 markers (expansion joints; markers 6-8 a ripple strip). First real 64-bit game read through TPTelemetryHelper64 (plugin 0.9.0): attached the whole way, every memory row read.

## Sources

* Memory (through the helper): all rows live. speed Int32 whole km/h (115-215), rpm (limiter about 8500), race_time advances exactly 1:1 with the clock, gear 2-4, power 0 throughout, friction constant 0.496.
* USB capture (G25): live. FFB_force = collisions (same sign and size, a few samples later); FFB_spring = memory spring 1:1 (0.53 normal). No constant force at all outside collisions: WMMT5DX+ sends no cornering load to the wheel.
* TeknoParrot shared memory: connected but every slot 0. This game doesn't use it.
* OutputBlaster rows (lamps, ob_ffb1-4): empty, so outputs weren't reaching the plugin.

## collisions (FFB float) decoded

* **Joints:** short kicks of 0.2-0.3, size rising with speed (about 0.105 + 0.00086 × km/h: 0.227 at 138, 0.297 at 215). Extrapolated, 0.19 at 100 km/h and 0.16 at 60 km/h.
* **Ripple strip:** a steady train of joint-sized kicks (0.286-0.297) every 0.1 s, 48.6-50.5 s and 51.4-53.3 s. Markers 6-8 (52.05, 52.68, 53.01) fall in the second stretch.
* **Hits:** exactly ±0.5 (big crash at 55.57: +0.779, 193 to 117 km/h, spring to 0). 18 hits; speed losses up to 63 km/h (13.97, 67.37). Five -0.5 hits 0.27 s apart at 30.2-31.2 look like a scrape. Steering at the hit was mostly away from the hit's sign (+0.5 hits with steering left), which fits + = right but isn't confirmed.

## Marker match

Markers 1-5 and 10-15 each follow a joint by 0.09-0.32 s. Marker 9 (60.37) is 0.53 s after the joint at 59.84 (or 0.57 s before the +0.5 hit at 60.94). 17 more joints went unmarked.

## Problems and proposals

* **impact misreads slow joints:** the profile's band (joint if 0.209 to 0.311) came from the FFB plugin, but joints drop below 0.209 under about 120 km/h and would then count as impacts. Proposed: impact = |collisions| >= 0.35; road_joint = 0 < |collisions| < 0.35.
* **Ripple strip detector:** avg(joint kick present, 1 s) > 0.35 caught both strip stretches, and elsewhere only a 0.05 s blip inside the big crash (max 0.37 outside the strip). Needs more strips to confirm.
* **grip_loss** = abs(tire_slip) never passed 0.113. tire_slip is signed and follows steering (r = -0.47 with wheel steer); slides reach about 0.1. Scale by about 1/0.1, or use the spring dip (0.53 normal, 0.25-0.45 in slides, 0 in the crash) as on WMMT3.
* **gear:** went 4, 3, 2 between 36.7 and 37 s at 205-211 km/h, then 2, 3, 4 by 45.8 s. rpm/speed medians: 53.7 ("2"), 47.3 ("3"), 37.8 ("4"). Gear numbering unconfirmed (possibly 0-based).
* **accel_g** from whole-km/h speed: steady cruising std 0.09 G, peaks 0.28 G. Acceptable; crash read -20 G.
* The profile has no wheel_* (USB) rows, unlike WMMT3DXP, so FFB values don't appear in its table (they are in the recording and as TPTelemetry.FFB_* properties).

---

# Second recording: `20261029-174800_WMMT5DXP.csv`

46.6 s, about 123 Hz, 6 markers (6.69, 14.02, 18.09, 26.81, 38.89, 43.47). Plugin 0.11.0 profile, attached throughout. 100 to 140 km/h; race_time starts at 1.91 s.

Alexis's notes: ripple strip, right turn, mark 1 end of strip, up to 4th, left turn, up to 5th, mark 2 jump (rear wheels only), mark 3 crash into right-hand wall, down to 4th, up to 5th, down to 4th, mark 4 right-hand turn drifting over a ripple strip (no walls), up to 5th, left turn, quick right turn/drift, mark 5 right-hand wall, mark 6 left-hand wall.

## Sources

* USB capture: connected, no FFB traffic at all (second time). Device selection probably wrong.
* TeknoParrot shared memory: all 0, as before.
* Lamps (memory): lampview1 blinks (0.69 s on every 1 s) from race start; ob_outputdata2 was 240 throughout, so red, green, blue, white and side were all on. Interruption 0.

## Findings

* **Gear is stored one low.** Raw 2→3 at 6.30 (her "up to 4th"), 3→4 at 8.95 (5th), 4→3 at 20.05 (4th), 3→4 at 22.21 (5th), 4→3 at 26.48 (4th), 3→4 at 31.41 (5th). An unnoted 2→3→2 at 2.43/3.00. Pre-race it toggled 4↔5, then 0 for 0.05 s at the start. Fixed: gear_raw (unticked) + computed gear = gear_raw + 1.
* **Sign confirmed:** + = right. Mark 3 +0.5 (137→79 km/h), mark 5 +0.5 (139→90), mark 6 -0.5 (126→121).
* **Wall scraping:** after a hit the game holds 0.2 (same sign) while the car is pushed along the wall (18.11-19.51; 44.48-45.64), or sends 0.5 kicks about 0.1 s apart (43.08-44.4). The old rumble_strip rule flagged these as strips (18.46-20.16, 39.56-40.52, 45.16-46.29).
* **Strips missed by the old rule:** kicks are 0.042 s long at about 100 km/h (0.075 at 200), always about 0.1 s apart, so duty was 0.32 on the opening strip (rule needed 0.35) and 0.13 drifting at mark 4. Joints are 2-4 kicks.
* **Jump (mark 2):** spring dropped to 0 at 13.88-14.17 with no collision. Spring also drops to 0 in wall hits (with collision) and before the race.
* **tire_slip:** - turning or sliding right (right turn at 3-5 s about -0.03; mark 4 drift -0.12; quick right drift -0.09), + left (left turns about +0.005-0.009; after the left-hand wall +0.11).

## Profile changes (pack, all six WMMT5/6 profiles; generator tools/memgames.py)

* gear_raw (Byte, unticked) + gear = gear_raw + 1.
* road_joint: `abs(collisions) > 0.001 && abs(collisions) < 0.35 && maxw(abs(collisions) >= 0.35, 0.25) == 0 && minw(abs(collisions) > 0.001, 0.1) == 0 ? abs(collisions) : 0`
* rumble_strip: `maxw(avg(maxw(road_joint > 0, 0.07), 0.6) > 0.8, 0.3)` (fills the gaps between kicks, needs 80% of 0.6 s, holds 0.3 s). Opening strip 2.41-7.30, mark 4 28.10-28.68; old recording 49.06-50.96 and 51.92-53.76 only (no joint false alarms, including the 6-kick cluster at 70.1-70.5 near joint markers 13-14; fill 0.1 flagged that, so 0.07 it is).
* wall_contact (new, -1/0/1): `minw(maxw(abs(collisions) >= 0.35 || minw(abs(collisions) > 0.001, 0.1), 0.15), 0.3) ? valid(hold(sign(collisions), abs(collisions) > 0.001), 0) : 0`. New recording 18.39-19.66 (+), 39.19-40.03 (+), 43.39-45.80 (-); old recording only at the big crash (55.88-55.96).
* airborne (new, 0/1): `minw(race_time, 0.5) > 0 && maxw(spring, 0.05) < 0.01 && maxw(abs(collisions), 0.3) < 0.001`. New recording 13.94-14.17 only; old recording 45.13-45.23 (nothing noted there: possibly a crest). Guess until more jumps are checked.
* Notes: impact sign confirmed, collisions/spring/tire_slip notes rewritten.
* Tests: fixture `wmmt5dxp-20261029-174800.csv.gz` (raw memory columns only; gear column renamed gear_raw in both fixtures), Wmmt5ReplayTests now replays both; MemProfilesTests WMMT5DXP section reworked (kicks need zero ticks around them now). 536 passed with pack, 295 without.
