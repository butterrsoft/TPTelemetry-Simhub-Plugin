# Review of newer FFB/output binaries, 29 October 2026

Alexis supplied: FFB Blaster 29-10-2026 (x64 and x86), OutputBlaster v0.28, two FFB Arcade Plugin packages ("v2_0_0_51" and "v2_0_0_53"), then OutputBlaster v0.11 (x64 and x86) and a loose x64 OutputBlaster.dll with its ini. She only cares about 64-bit builds; FFB Blaster was to take precedence. Examined read-only; nothing run. She has no active TeknoParrot subscription.

## FFB Blaster (FFBBlaster64.dll / FFBBlaster.dll)

* Version 0.0.0.204, built 21 October 2026, "Force Feedback & Outputs". Exports `FFB_Blaster_Init`, `TPSetFFB`, `TPSetOutput`, `TPSetCRC`, `TPSetTitleID`: TeknoParrot drives it (hands it force feedback and outputs). Needs a TeknoParrot subscription (Hook Of The Reaper wiki), so it isn't running on Alexis's setup.
* **Protected with a commercial packer (VMProtect marker):** code sections empty on disk, 17 MB section at entropy 7.92 (x86: 7.99), one import per system DLL. No game list, addresses or logic are readable.
* **Not unpacked, deliberately:** that would mean circumventing the protection on a closed, paid TeknoParrot component, and nothing derived that way could go into a public plugin. No published source found.
* From public documentation: per-game `FFBBlaster.ini`; `OutputsSystem=1`, `NetOutputsTCPPort=8000` sends outputs over TCP 8000. Only relevant to subscribers.

## FFB Arcade Plugin packages

* Both DLLs report version 2.0.0.53.
* "v2_0_0_51" package: built 3 November 2025, 32-bit only (one DLL copied to 91 folders), = the public source head ("Fix cars crashes", 3 Nov 2025). Adds Cars, Hummer, DInput8Wrapper folders.
* "v2_0_0_53" package: built 31 July 2024; the only 64-bit plugin build (16 copies).
* Source changes since July 2024 touch only Hummer, Hummer Extreme and Cars (32-bit, all via code hooks). Nothing changed for the 64-bit games; the pack is current. Cars and Hummer stay out (hooks).
* The WMMT5DX+ force feedback on Alexis's wheel matches this plugin's WMMT5 logic (wheel force = collisions, spring = spring), so it is almost certainly what drove her wheel.

## OutputBlaster

| Build | Arch | Built | Notes |
|---|---|---|---|
| v0.28 | x86 only | 23 Sep 2026 | = public source head (all 314 titles/names in source). Can't load into 64-bit games. |
| v0.11 | x64 + x86 | 22 Jul 2024 | Boomslangnz's own build. Superset of the 2022 build (adds Arctic Thunder, Cruis'n Blast, Dead Heat, FNF, HOTD4, ID6 AA Updated, Jurassic Park, Daytona NSE and others). |
| loose DLL | x64 | 17 May 2022 | Built the day before "Add WMMT games" was committed; already has WMMT5 to 6R. Older ini format (no recoil keys). |

* WMMT code in OutputBlaster hasn't changed since May 2022 (WMMT5DXPlus.cpp only commit: 18 May 2022), and WMMT5DX+'s detection CRC (0x1BB6F051) is the same, so both x64 builds handle WMMT5DX+ identically. **Use v0.11 x64.** No x64 build newer than July 2024 was supplied; source changes since then don't touch 64-bit games' WMMT code.
* Setup for network outputs: `OutputsSystem=1` (both supplied inis have 0 = Windows messages for MameHooker), `NetOutputsTCPPort=8000`, `NetOutputsWithLF=0` (CR endings, which TP Telemetry handles), Enable Outputs in TeknoParrot. `Sleep` is only used by a few games (not WMMT).
* **What OutputBlaster does for WMMT5/6 (from source):** reads two lamp bytes and the four FFB floats, all relative to the exe:
  * WMMT5 `199F0CC/199F0CD`, 5DX `1C2F4F1/1C2F4F2`, 5DX+ `1FD55D1/1FD55D2`, 6 `1E60691/1E60692`, 6R `206D2B1/206D2B2` (no OutputBlaster support for 6RR).
  * Byte 1: View1 = bit 0x08, interruption button = 0x04. Byte 2: red 0x80, green 0x40, blue 0x20, side 0x10, white when byte 2 >= 0xE0.
  * FFB1-4 = the floats at the profile's tire_slip/spring/friction/collisions addresses × 100, so the profiles' `ob_ffb1-4` rows duplicate existing rows. The float addresses independently match the pack's for all five.
* **Pack-wide:** 54 of 61 OutputBlaster game files produce outputs purely from memory reads (5 hooks only, 2 both). Those outputs could become direct memory rows in the profiles, so lamps work without OutputBlaster at all.

## Outcome

No address changes. Proposals: WMMT5/6 lamps read directly from memory (and drop ob_ffb rows); possibly the same for every memory-only OutputBlaster game via an obnames.py extension.
