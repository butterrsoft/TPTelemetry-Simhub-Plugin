# WMMT3DX+ recordings, 1 November 2026 (15:49 and 15:54)

## First recording, 15:49

Recording `20261101-154943_WMMT3DXP.csv`: 47 seconds on the freeway, 5651 rows at about 120 Hz. No
video. Alexis's notes: top speed in this game is 220 km/h; the top revs in the data are the max revs;
markers follow either expansion joints or crashes.

## Speed, revs and gear

* All four speed candidates, all four revs candidates and all four gear candidates read the same
  throughout, as in the three 29 October captures and across a reboot. Kept speed1, revs1 and gears1
  as `speed`, `rpm` and `gear`; dropped the rest.
* Speed peaked at 230.5 km/h (Max speed is 220, as Alexis asked; the effects treat anything over as 1).
  Revs peaked at 8999 (the limiter), now Max revs.
* Gear is the gear in play (1 = first), 0 for the first 5.6 s before driving. Revs per km/h ran 102,
  70, 48, 39 and 33 in gears 1 to 5. Unlike WMMT5/6, it is not stored one low.

## Slot 9 (reflect)

| What | Slot 9 reads |
|---|---|
| Expansion joint | a pulse of 26 to 33 (of 63), under 0.1 s, bigger the faster you go (26 at about 100 km/h, 33 at 220); usually two about 0.07 s apart (front then rear wheels) |
| Hit on a wall or car | 63, + right, - left |
| Scraping along a wall | repeated 63s, or 25 held while the car is pushed along it |
| Unexplained | 39 in short runs at 23.0 to 23.35 s (between joint markers 13 and 14) |

Markers 1 to 13 and 15 to 20 follow joints; 14, 21 and 22 follow crashes:

* 24.06 s: right, 63, speed 228 to 68 km/h; then 25 held from 24.5 to 27.4 s (pushed along the
  right-hand wall).
* 42.76 s: right, 63, 223 to 166 km/h; 63 kicks to 44.0 s.
* 45.46 s: left, -63; kicks to the end.

The old rules (from the 29 October G25 capture) missed the left-hand crash and counted crashes as
road bumps, because they worked from `tp_force`, which hides slot 9 whenever slot 8 (centre) is set.

## New rows

* `impact_now = abs(tp_reflect) > 0.95`, `impact_dir = sign(tp_reflect)`; `impact`, `impact_side` as before.
* `reflect_held = minw(abs(tp_jvs9) == 25, 0.1)` (was `abs(tp_reflect) > 0.3` until the second recording, below)
* `wall_contact = minw(maxw(impact_now || reflect_held, 0.35), 0.3) ? valid(hold(sign(tp_reflect), impact_now || reflect_held), 0) : 0`
  (side from hits and held values only: a -29 joint pulse at 44.26 s, as the car left the right-hand wall, flipped it otherwise)
* `road_joint = abs(tp_reflect) > 0.3 && abs(tp_reflect) < 0.75 && maxw(impact_now, 0.25) == 0 && reflect_held == 0 && wall_contact == 0 ? abs(tp_reflect) : 0`
* `road_bump = clamp(road_joint / 0.52, 0, 1)`
* `car_impact = impact > 0 ? clamp(0.6 + (-long_g_fast - 1.5) / 20, 0.6, 1) : 0`, `car_wall_contact = wall_contact`

## Replayed through the plugin

`Wmmt3ReplayTests` replays the recording (fixture `wmmt3dxp-20261101-154943.csv.gz`) through the
pack profile:

* road_joint before all 19 joint markers; 41 pulses, 25 joints; none during crashes or along walls.
* impact before all three crash markers, sides right, right, left; nothing elsewhere.
* wall_contact 24.36 to 27.77 (+1), 43.07 to 44.38 (+1), 45.77 to 47.09 (-1); off elsewhere.
* Car_impact 1.00, 1.00, 0.94; Car_wall_right and Car_wall_left; Car_road_bump at every joint
  marker; Car_braking 1 in the big crash.


## Second recording, 15:54

Recording `20261101-155436_WMMT3DXP-2.csv`: 39 seconds, 4719 rows. The game detached at 37.07 s
(memory rows blank from there; TeknoParrot data carried on). Alexis's log, with what the data shows:

| Marker | Time | Log | Data |
|---|---|---|---|
| 1 | 4.69 | down through the gears to neutral, max revs | gear 5, 4, 3, 2, 1, then 0 from 4.0 s; revs 8891 |
| 2 | 7.58 | joint | -28 pair at 7.42 |
| 3 | 10.68 | joint | +30 at 10.62 |
| 4 | 13.39 | joint | -31 at 13.25 |
| 5 | 19.01 | crash into left-hand wall, scrape | -63 at 18.82 (221 to 192 km/h), -63 kicks to 19.95 |
| 6 | 22.84 | crash into right-hand wall, scrape | +63 at 22.56 (196 to 124 km/h in a frame, spring 0), 63 kicks and 25 held to 24.1 |
| 7 | 27.26 | possibly a joint | yes: -28 pair at 27.06 |
| 8 | 27.93 | possibly a joint | yes: -29 pair at 27.79 |
| 9 | 29.05 | joint | -32/-30 alternating with no gap for 0.23 s from 28.92 (two joints together) |
| 10 | 32.91 | joint | -32 at 32.85 |
| 11 | 35.54 | crash into left-hand wall, scrape | -63 at 35.49 (205 to 155 km/h), -63 kicks to 36.76 |

Findings:

* **Gear:** 0 is neutral. This car has six gears (sixth about 30 revs per km/h).
* **Candidates:** speed1 = speed2 and gears1 = gears2 always. speed4/speed5 and gears4/gears5 are the
  same record a frame earlier: they differ for one sample at each gear change and crash (up to 50 km/h
  at the 35.5 s crash). Revs candidates all identical. Keeping speed1/revs1/gears1 stands.
* **Marker 9** broke the first `reflect_held` rule (any value over 0.3 for 0.1 s): 0.23 s of 30s and
  32s would have read as a wall. The held value while scraping has always been exactly 25, so
  `reflect_held` now looks for 25 only. Joints seen so far are 26 to 33; one risk is a joint at low
  speed reading 25, but joint pulses are short (under 0.07 s), so the 0.1 s hold should still exclude them.
* Joints were also seen on the way down through the gears (1.99 s, 2.99 s), unmarked.
* Replay results: all 7 joint markers; impact left, right, left; wall_contact 19.12 to 19.94 (-1),
  a 0.08 s blip at 20.25 (-1, still on the wall), 22.86 to 24.40 (+1), 35.80 to the end (-1); never
  the wrong side; nothing between the walls. Car_impact 1 for the right-hand crash.

Both recordings are fixtures (`wmmt3dxp-20261101-154943.csv.gz`, `wmmt3dxp-20261101-155436.csv.gz`),
replayed by `Wmmt3ReplayTests`. 982 tests pass with the pack.

## Still to check

* Joints below about 100 km/h (do they stay away from 25, or at least short?).
* A light wall graze with no crash, and a drift (slot 8 set) over joints.
* What the 39 pulses at 23 s (first recording) were.
* The front/rear impact thresholds (1.5 G, 1.2 G) are still untuned; these recordings have speed, so
  they could be checked next.
