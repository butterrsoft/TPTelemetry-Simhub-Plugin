# Cheat tables, OutputBlaster-only games and emulators (2 November 2026)

Alexis supplied MasterRaver's TeknoParrot cheat tables (`TeknoParrot_Cheat_Tables_04.10.26`, AES zip,
password Raver1234; 60 tables plus a Cheat Engine guide; not made by her). She asked for: driving games
filtered for useful values; profiles for every driving game, TeknoParrot or not; the same from the FFB
Arcade Plugin and OutputBlaster, emulators included; an OR2 Legacy profile; and, where new data
differs from a profile, new rows with incremental names rather than overwriting.

Generator: `tools/moregames.py`, called by memgames.py after its own games (`moregames.add`) and,
for the hand-maintained WMMT3DXP, before oblamps (`moregames.add_hand`). Pack 47 to 107 profiles;
regenerating twice changes nothing. Plugin 0.13.3 (Flycast hex outputs). 1102 tests pass with the
pack.

## Tables: what was usable

Driving tables: Crazy Streets Thrill Drive 4, Cruis'n Blast 1.25, Hydro Thunder 1.01b (3 builds),
Initial D The Arcade S3 v2.1, S3 v2.31, S4 v2.5, S5 v3.10, S5 v3.21 (ARCADEZONE.CN), Initial D 8,
Initial D Zero v2.3, OutRun 2 SP SDX, Road Fighters 3D, Super Bikes 2, WMMT3DX+ Export, WMMT6, 6R, 6RR,
FANTASY 6RR, 6RR Plus v4.00.13, XTrial Racing. "Friction" is a light-gun game. Initial D "Season"
tables are Initial D The Arcade (ALLS), not Initial D 3; Initial D 3 is NAOMI 2 (Flycast, below).

* Values taken: speed/RPM ("output pointers") on IDTA S3 v2.31 and S5 v3.10; timers; gear, power,
  handling, accelerator and brake on WMMT6-6RR Plus; nitro on Cruis'n Blast, Thrill Drive 4; boosts on
  Super Bikes 2, Hydro Thunder; damage on Road Fighters 3D; steering and timers on ID Zero; OR2's
  velocity vector and timers (from Lua scripts writing absolute addresses).
* Ignored: cheats (AA/Lua scripts), points, tokens, cosmetics, names, titles, story progress. The
  tables' "Tachometer" entries are a cosmetic item, not revs.
* CE offsets are stored last-first in the XML; reversed to the plugin's base-outwards order.
* The 6R table's Speed/RPM entries are 6RR's addresses (copied?): added to 6R as speed2/rpm2, flagged.
  6RR's power/handling pointer is the same as 6R's (flagged). FANTASY 6RR = 6RR except its timer.
* Timers named `race_timer` (not `race_time`) on WMMT3DXP and WMMT6RRP: commonrows gates every
  effect on `race_time > 0`, and these are unchecked (the WMMT3 replays went silent until renamed).

## OutRun 2

*(16:10: the Legacy profile was removed at Alexis's request; see `claude/OR2-capture-20261102.md`.)*

`OUTRUN2SPLEGACY` "OutRun 2 SP SDX – Legacy" = the FFB/OutputBlaster rows, each noted as legacy (Alexis:
those sources were written for the legacy version). Both profiles get the table's rows and stay
identical until Alexis decides how to split them (don't remove anything without instructions):
(`select_timer` Int16 0x082932B0, `stage_timer` Int32 0x0830B748, `vel_x/y/z` 0x08279F4C/50/54,
`speed2` = velocity magnitude, game units). TeknoParrot has two profiles (or2spdlx Lindbergh, or2spdlxelf2
ElfLdr2), both BudgieLoader.exe.

## OutputBlaster games added (lamps only)

Battle Gear 4 (`BG4`), Harley-Davidson, MotoGP, FnF Drift, FnF SuperCars, Hummer, Hummer Extreme, Cars:
lamps translate from memory (their force feedback is hooks). Crazy Ride (64-bit) and Super Bikes 2 lamps
need OutputBlaster (condition / hook). Dead Heat Riders: TeknoParrot shared memory like Dead Heat but
spring / 500.

## Emulators

* **Model 2 Emulator** (`emulator_multicpu.exe`): FFB byte at exe+0x17285B (Daytona, Indy 500, STCC,
  Over Rev, Super GT 24h) or exe+0x174CF4 (Sega Rally); Daytona RAM via [[exe+1AA888]+100]: game state
  +10A4, track +1460, countdown +1850, cars in front +51EC. OutputBlaster lamps at RAM+0x824.
* **Supermodel** `RawDrive`, **MAME** `wheel`/`wheel_motor`/`digit0`/shaker and bank-motor outputs:
  decodes from the FFB plugin's MAMESupermodel.cpp per rom group.
* **Flycast** (Settings, Network, "Broadcast Digital Outputs", TCP 8000): `midiffb` (Initial D 1/2/3,
  Cycraft, Club Kart, King of Route 66, Sega Driving Simulator), `awffb` (Maximum Speed, Faster Than
  Speed), `m3ffb` (motor board: 18 Wheeler, F355; also Wave Runner GP, Tokyo Bus Guide), `lampN`, and
  `tachometer`/`speedometer` (Sega Driving Simulator). **Values are hex** (`%x`) with LF endings and a
  first line `game = <id>`: NetOutputsClient now switches to hex on that line (0.13.3; tests added).
  midiffb = (cmd << 16) | (b1 << 8) | b0; the FFB plugin's ffb[2] is the command.
* Not possible: MAME pattern-scan games, Hard Drivin',
  hook-only FFB games (FnF, Tokyo Cop, Gaelco Tuning Race, Wasteland Racers, Ring Riders, SR3 Other,
  Ford Racing Other).
* TeknoParrot runs NAOMI/Model 2/Model 3 through its own forks; whether they keep network outputs or
  the same memory layout is unknown.

## Values sheet

Updated copy: column A filled for 90 more rows (141 with a profile), and suggested columns: on-screen
timer, race position, nitro/boost count, damage meter.

## Follow-ups (14:30)

* Pack grouped into emulator folders (Teknoparrot, Flycast, MAME, Supermodel, Model 2 Emulator, PC).
* Demul dropped from the notes (obsolete).
* TeknoParrot's own emulators send network outputs when the game's Outputs setting is Network Outputs.
* WMMT6RR "outputs" block (RaceActive 0x04 ... FrameCounter 0x54, all 4-byte) is the output of the
  table author's CE script: waiting on where it lives and the script's source addresses.
