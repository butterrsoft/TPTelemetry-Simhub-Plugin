# GTI Club: Supermini Festa (GTICLUB3): exe review, 8 November 2026

Alexis sent `GTIclub.CT` (her Cheat Engine table) and `gti3japkey.exe` (TeknoParrot). Asked: are the CT addresses right, and
what else is in the exe for the profile. Advice only so far: no pack or plugin change made.

## The exe

* `gti3japkey.exe`, PE32, built 24 June 2009, SHA-1 05c3fec713122a3436133995259acbcbf8b957fc. Not packed.
* No relocations and no ASLR: always loads at 0x400000, so `<main>+X` and absolute `0x400000+X` are the same address.
* `.data` runs exe+379000 to exe+3047000 (only the first 0x168000 is in the file; the rest is BSS). Every CT base is a
  static in there.
* Konami e-Amusement build: imports libavs-win32.dll, libavs-win32-ea3.dll, libacio.dll (I/O board: lamps, coin, card),
  d3d9/d3dx9_37, dinput8. All game logic is in the exe; no other file is needed for telemetry.
* RTTI class names survive (CarObject, RaceObject, I_RaceStat, I_LimitTimeObj, I_Engine, I_PostCarHitObj, Aep_Race*
  HUD classes...). Found with capstone (linear disassembly), xrefs and RTTI vtables; scripts were throwaway.

## CT check (CE lists offsets last first; chains below are base outwards)

| CT rows | Chain | What it is | Verdict |
|---|---|---|---|
| speed3-1, revs1-1, gears1-1 (and 1-5) | `[exe+67FCC8]` + 648 / 640 / 644 | player car's dash: speedo, tacho, gear | Correct; best base |
| speed3-2/3-3, revs1-2/1-3, revs2-2/2-3, gears1-2/1-3/1-6/1-7 | `[exe+29BB8E0]` +8E8.. / `[exe+29BB8D0]` +948.. | same fields, via element 0 of a static array (256 x 0x4C20 at exe+29B7870; +0x4060 holds the car, +0x4070 car+0x60) | Same values; spare |
| revs2-1 | `[exe+67FCC8]+B8` | tacho before needle jitter (smoothed, max 500 rpm a frame) | Correct |
| speed1-1 / speed2-1 | `[exe+680460]+238` | race HUD (Aep_Race; Aep_RaceMeter at +188, field +B0) copy of the dash speedo | Correct; exists only during a race (pointer cleared after) |
| speed1-4/1-5/1-6 (2-2..2-4) | `[[exe+680468]+2BC]+238`, `[[exe+680468]+14]+238`, `[[exe+68046C]+C]+238` | same HUD field via other HUD objects (Aep_Sign...) | Duplicates |
| speed1-2/1-3 (2-5/2-6) | `[[exe+682044]+50]+C4C`, `[[exe+682040]+28]+258` | inside a resource/file slot table (0x16C-byte entries at exe+680800; slot 17, buffer pointers +14/+18) | Pointer-scan luck; drop |
| gears1-4 | `[exe+53F7EC]+57C` | exe+53F7EC = dash+C8 (set at 0x537D15), so dash+644 again | Duplicate |
| gears1-8 to 1-16 | `[exe+1359xxx]+A64` etc. | records 0xBC apart in a static block (exe+12E5240 onward) no code addresses directly | Unexplained; drop |
| revs2-4 | `[exe+549C48]+F38` | object at exe+549C48 holds a car pointer at +110; +F38 is never read or written by code | Drop |

## Player car (base `<main>+67FCC8`, which holds car + 0x300; offsets below are from that pointer)

Written once, at race set-up (0x55799F), for a car whose flag at exe+5493D8[index] is 0; never cleared, so stale between
races. Gate rows by race_state.

* +648 Float speedo as shown: true speed capped at 61.11 m/s (220 km/h), x 3.6, / 1.609 when the mph option is on.
* +64C Int32 1 = speedo in mph (copy of exe+67FCB4, the SPEED METER DISPLAY option).
* +640 Float tacho as shown (smoothed, adds needle wobble at idle). +B8 Float the same without the wobble.
* +174 Float engine revs per second: tacho target = +174 x 60 + word(+BC) x 15. Above 7500 the game adds 0 to 437 at
  random (limiter bounce), so the limiter is a fixed 7500 for every car. Engine RPM = value x 60 (Alexis prefers engine).
* +644 Int32 gear as shown: 1 up, -1 reverse (raw signed byte at +164; 0 shows as 1).
* +1A4 Float true speed, m/s (car+4A4; the force code uses it, and cuts the force below 10 km/h).
* +CB8 Int32 position, 0 = first (HUD shows +1, clamped 1 to 4; HUD+36E is the number of cars).
* +CBC Int32 laps completed (current lap = +1). +CC8 Byte 1 once finished.
* +CCC + 4n Int32 time of lap n+1, ms. +CE8 Int32 current lap timer, +1 per game update; the game turns it into ms as
  x 1000 / 30 (so 30 a second, unless the update runs faster: check against the screen).
* +238 Float angle (radians) that sets the steering force (x 57.3 / 50, capped 1); sign flips with +61C. Likely slip or
  steer angle: check.
* +42C, +430, +434, +438 Int32 surface per wheel: low byte the code, bit 0x100 skips the wheel (in the air?). Code 2
  rumbles (0.25 to 0.4, more with speed above 50 km/h), code 5 a fixed 0.15. Other codes unknown.
* +52C Byte event level 1 to 4 (vibration 0.3, 0.5, 0.7, 0.9).
* +1054 Float vibration level (0 to 1, fades by the frame time): hits 0.5 to 1.0, surfaces 0.15 to 0.4.
  +1058 Float hit impulse, cleared the same frame (0.5 most hits, 1.0 with speed zeroed in a full-stop crash).
  +1028 Int32 set to 90 at some hits (cooldown).
* +F1 Byte (car+3F1) 0 or 1, copied to the HUD: maybe AT/MT. Unknown.

## Race and statics

* Race state: `<main>+67FAC8`, offsets `2C8, 34`, Int32 (I_RaceStat; pointer cleared after the race). Names from the
  game's own table at exe+4DCFA0: 0 NONE, 1 START CAMERA, 2 START SYNC, 3 COUNT DOWN, 4 START RACE, 5 GO RACE,
  6 WAIT TIME UP, 7 GOAL WAIT SC, 8 TIME UP, 9 TIME UP SYNC, 10 RANK DISP SETUP, 11 RANK DISP SETUP END, 12 RANK DISP,
  13 RESULT DISP, 14 END RACE, 15 INTERRUPT GAME. Time left only counts in 5 to 7.
* Game mode: `<main>+67FAC8`, offset `90`, Int32 (race and the variety modes; values unmapped).
* Time left: `<main>+67FB98` Float seconds (counts down by the frame time in states 5 to 7, clamped at 0, eases up when
  time is added). Warning threshold 10 s (exe+4DE074). HUD gets it x 1000.
* Laps in the race: `<main>+549458` Int32 (3 by default; "RACE LAP MAX (country)" options).
* Frame time: `<main>+518BCC` Float.
* Force board packet, 4 bytes at `<main>+518CBC` (the pack reads it as absolute 918CBC): byte 0 force, signed -127 to
  127 (so `-signed8(value) / 127` gives + from the right as the FFB plugin does); byte 1 low 6 bits vibration 0 to 63
  (vibration level x 72); byte 2 vibration pattern code (10 to 16 rough road, 14 surface 5, 15 hits; holds its last
  value); byte 3 a constant 84 (exe+4DE0C4, likely centring). Max force tunable 200 (exe+4DE0C0), so the force often
  saturates at 127.
* in_menu `<main>+518E8E` (pack, from the FFB plugin): confirmed written by game code.
* Lamps: Int32 brightness 0 to 31 at `<main>+67E790` start, +794 action, +798 left, +79C right, +7A0 up, +7A4 down
  (matches OutputBlaster; the pack already reads them). `<main>+67E7A8` drives I/O lamp bit 1 at value + 23 when
  non-zero; code only ever zeroes it (test menu, maybe WIND UNIT). Not useful in a race.

## Next steps (not done)

* Add the rows above to the GTICLUB3 block in memgames.py (speed, rpm from +174 x 60, tacho, gear, race_state,
  in_race = state 5, time_left, position, lap, lap_time, surfaces, vibration level, hit), map car_ rows, regenerate.
* Ask Alexis for a recording with marks (start, each lap, a wall hit, cobbles/grass, finish) and her speedo at top
  speed for Max speed. Max revs 7500 (fixed limiter).
