# Sega World Drivers Championship: Alexis's recording of 19 November 2026 (SWDC-11)

`20261119-091525_SWDC-11.csv` (377.6 s, 23 marks), made with the 18 November pack (plugin 0.19.0): the menus, car
select, then a race from 35th of 45 to the finish line (16th), then the menus. USB capture on. Fixture
`swdc-20261119-091525.csv.gz` (90 to 378 s, raw values), checked by `SwdcReplayTests`. She also recorded the attract mode
(movies only, never a race): the revs and other columns didn't cut off there.

TT below is `race_secs`, the game's clock from the rolling start (recording time - 128.17 s).

## What the recording showed

* **The data model works throughout:** `player_no` 0 in the menus, 1 briefly at car select (97.99 to 110.08 s), 35 from
  112.16 s; `grid_no` = 35 and `player_ok` 1 from then to the results; `cars` always 45 (the array's size).
* **Race state:** 0 at car select; 1 from 118.21 s (course loading and the held countdown, revs frozen at 9326.67, the
  car not moving); **2 from 128.17 s, as the car starts moving at 97 km/h (the rolling start), TT 0:00.00**; 3 at
  324.47 s, TT 3:16.29, the finish line (her mark at 3:16.37). Then rubbish in the menus (car_state 83 once, with
  `player_ok` 0).
* **`kmh` is the speedo**: within 3 km/h of `speed_kmh` (the table's speed2 through her fit) on average, -2 at 40 to 80
  km/h, +4 at 160 to 200; top 224. `speedo_fit` 2.45 to 2.70 km/h a unit. `pos_kmh` (from the position, centimetres)
  is 3% under it.
* **`shift` = `gear2`** at every sample (gears 1 to 5).
* **`revs_game` is not the engine:** 0, 8000 and odd values (100s, 2000s) while `revs` ran 6,927 to 12,000. Renamed
  `revs_record`; Car_rpm is `revs` again. (`revs` sits at exactly 12000 on the limiter, so the old `in_race_revs`
  test flickered off there: removed.)
* **`brake`** follows the pedal (correlation 0.78 with USB brake).
* **Places:** `position` 35 to 16, `class_rank` 20 to 1.
* **Laps:** `lap` 0 from the rolling start to the start line (TT 0:25.36), 1, 2 at 1:28.87, 3 at 2:20.84, 4 at the
  finish 3:16.29: three laps. Sectors 1 to 3 (lines at 0:52.58, 1:13.58; 1:51.42, 2:09.87; 2:44.40, 3:04.30).
* **`time_left`** is a lap time limit: 300 at the rolling start, set to 180 at each lap line (1:28.87, 2:20.84).
* **Sparks:** only three times: right 0:54.05 to 0:54.53, left 0:54.16 to 0:54.65, left 1:51.83 to 1:52.32. None at
  the five big speed drops. Taken out of Car_wall_contact and the hit side until we know what they are.
* **Exhaust flames:** `afterfire` 127 as they start, then down 16 a frame: 22 times, mostly on lifts and shifts.
* **Drift angle:** + in right-hand turns (correlation 0.75 with the yaw rate, 0.56 with USB steering). 90% of the race
  under 12 degrees; slides of 40 to 55 degrees at 0:55.8, 1:36.2, 1:54.1, 2:28.4, 2:47.3 (all right-hand), -35 at 1:04.4
  and 1:06.3. Car_drift reached 1 in these.
* **Hits from the speed** (more than 4 G slowing): five, at 0:17.51 (175 to 143 km/h), 0:22.07 (150 to 130), 1:16.15
  (188 to 118), 1:25.50 (174 to 96), 2:26.55 (223 to 170). Many smaller events (her marks at the start, wheel kicks and
  sideways jolts in the car's position without speed loss) are still unexplained: questions below.

## Changes (19 November 2026)

* `in_race` = your record's race state 2 (`valid(player_ok, 0) && car_state == 2`): from the rolling start to the
  finish line, or a retire/time out. The old revs-and-spring fallback (`in_race_revs`) and `racing` removed.
* Every game value reads 0 outside the race (Alexis: telemetry from the rolling start to the line or time up): the
  table's `revs`, `speed2`, `gear2`, and every row from the record (`in_race ? value : 0`); position-based rows wait 0.3 s
  after the start. Every Car_ value except Car_in_race is wrapped in `in_race ? ... : 0`. The force feedback rows
  (`force`, `spring`, `vibration`) still show what the game sends the wheel, as the wheel gets it.
* Car_rpm = `revs`; Car_speed = `kmh`; Car_gear = `shift`; Car_wall_contact none (sparks not walls); Car_impact_side
  from the force kick only. `backfire` 0 to 1 from `afterfire`. Notes carry what the recording showed.

## Questions for Alexis (asked 19 November 2026)

For each, what happened (car contact, wall, kerb or verge, a drift, a spin), and which side of your car was hit:

1. TT 0:04.38: the car jolts sideways (pushed right) with no speed lost.
2. TT 0:06.17, 0:07.02, 0:08.43, 0:10.94, 0:14.42 (in the pack after the rolling start): almost nothing in the data,
   speed steady (a 0.8 G dip at 0:07.05), small wheel kicks.
3. TT 0:17.44: a big wheel kick and 175 to 143 km/h, then a sideways jolt at 0:18.36.
4. TT 0:21.97: 150 to 130 km/h with a sideways jolt.
5. TT 0:25.84 and 0:26.46: a jolt and a wheel kick, no speed lost.
6. TT 0:29.29 and 0:30.59: two jolts (pushed left), no speed lost; a wheel kick at 0:31.32.
7. TT 0:38.61 and 0:47.23: jolts, no speed lost.
8. TT 0:54.05 to 0:54.65: sparks on both sides, then a +43 degree slide in a right-hander at 0:55.81.
9. TT 1:04.40 to 1:07.0: two slides to -35 degrees (left-handers).
10. TT 1:10.11 and 1:12.98: wheel kicks, jolts at 1:11.45 and 1:12.97.
11. TT 1:16.05: 188 to 118 km/h with a jolt.
12. TT 1:25.40: 174 to 96 km/h with a jolt and a full wheel kick; another kick and jolt at 1:27.19.
13. TT 1:36.24: a +50 degree slide in a right-hander at 113 km/h.
14. TT 1:45.48 and 1:49.10 to 1:50.17: jolts and a full wheel kick at 180 to 200 km/h, no speed lost.
15. TT 1:51.83: sparks on the left, then a +40 degree slide at 1:54.05.
16. TT 2:26.55: 223 to 170 km/h, then a +55 degree slide at 2:28.39.
17. TT 2:47.30: a +46 degree slide, with a jolt at 2:47.50.
18. TT 2:57.07 and 3:01.17: only small slides (23 and 16 degrees) in the data.

Also: for the slides in 8, 9, 13, 15, 16 and 17, drifts or spins, and how strong Car_drift should be (0 to 1; they read
up to 1 now); whether the results showed 16th overall and 1st in your class (which class), and a time of 3:16.29; and
whether a lap time limit (180 s) shows anywhere on screen.

Next recording: the attract mode again with this pack, to confirm everything reads 0 there.

## Her answers (19 November 2026, 11:00)

1. 0:04.38 slight traction loss correcting right. 2. Nothing much (the wheel kicks are for immersion). 3. Front centre into a
car, grinding its rear bumper, then front right at 0:18.36. 4. Along the right kerb (painted), right wall at 0:21.97.
5. Left grass verge, left wall, on the verge until 0:28.22. 6. Car on front/front right, then another car front right.
7. Car front/front left about 0:38.00, on the left at 0:38.61; 0:47.23 a small traction loss turning left. 8. Exactly as
she downshifted; drift about 0.65. 9. Right-hander 0.6; left-hander 0.5 to 0.55. 10. Small traction loss correcting left;
car on front right. 11. Her sequence: 1:11.465 car front left; 1:12.398 to 1:12.882 left kerb strip; 1:12.965 car front
right; 1:14.115 right verge, slight anticlockwise rotation, off just before 1:14.682; 1:15.866 back on the verge; right
wall 1:16.083, grinding to 1:16.433; solid kerb from 1:16.833 (front lifts 1:17.083), back on the road 1:17.483.
12. Left verge and left wall; a car hits her right side as it passes (she's 8th of 20). 13. The slide ends crossing a
kerb; about 0.6. 14. Small traction loss correcting left; car front centre, then the same car on her rear right as she
passes (6th). 15. Downshifting to 3rd under braking seems to trigger the sparks; drift about 0.55. 16. A car on her left
just before, barely slowing; the speed loss is hard braking; drift about 0.75 max. 17. Asked for its value; 2:48.07 rear
right onto the hard kerb. 18. Small slides. Results show only "1st" (her class: GT300); no lap limit on screen (drop
it). A GT500 race next.

## Changes (19 November 2026, 11:00)

* **Car contacts and walls from the sideways shove:** from the position and heading, `vel_lat` and `jolt` (G, + pushed
  right). Every contact and wall hit she named shoved the car 4.3 to 10 G (plugin's slope) away from the side hit, apart
  from the head-on hit (0:17.44, caught by the speed) and a light left-wall tap (0:25.84, 3.4 G). Slips stay under 3.8 G;
  the slides' own swings (to 5.8 G) are left out by a 25 degree drift-angle gate. `car_contact` (over 4 G, held 0.3 s):
  twelve in her race, all real, sides all right; `contact_side`, `contact_strength` (0.4 to 1). Car_impact = the bigger
  of the contact and the speed-drop hit; Car_impact_side = the contact side. The game's wheel kicks are out of Car_impact
  (they come at slips too).
* `hit` needs 5 G while braking (hard braking reached 4.0 G at 223 km/h, TT 2:26.55).
* **Surfaces from the game's vibration command:** `verge` (pulses under 0.2, period 7 to 9) -> Car_off_road; `kerb`
  (about 0.4, period 34 to 43) -> Car_rumble_strip; braking/downshift judder (0.26 to 0.37, short period) stays only in
  Car_vibration. Painted kerbs give nothing.
* **Car_drift** = clamp((|angle| - 8) / 64 x min(km/h, 150) / 100, 0, 1), fitted to her six values (plugin: 0.66, 0.50,
  0.56, 0.62, 0.59, 0.70 for 0.65, 0.6, 0.5 to 0.55, 0.6, 0.55, 0.75); slide 17 reads 0.75; ordinary cornering under
  about 0.05; 0 for 0.5 s after a contact. Her 1:04 (0.6 at 31 degrees) and 1:06 (0.5 to 0.55 at 35) can't both fit a
  curve rising with the angle: the faster speed at 1:04 makes up only part of it.
* `position` is now the class place (GetClassRank, as her results showed), `overall` the place among all cars;
  `time_left` dropped (no lap limit on screen).
* Sparks: on downshifts under braking; notes only.

## For the GT500 recording

Anything that happens is useful; especially: car contacts on each side and from behind, a long grind along a wall, a
light wall tap, painted and solid kerbs, the grass verge, and whether the screen's place is the GT500 class place.

## SWDC-12 (19 November 2026, 11:30): a GT500 race

`20261119-113002_SWDC-12.csv` (102.4 s, no marks), the 11:00 pack: from car select (car 15) into a GT500 race from 15th,
recorded to TT 1:30.80 (no finish). Fixture `swdc-20261119-113002.csv.gz`. The screen shows the place "/20" with GT500.

* Race state 1 at 1.64 s, 2 (in race) at 11.60 s, the rolling start. Speed up to 263 km/h, revs 3,018 to 11,357.
* `position` (class) 15 to 1 and `overall` the same until TT 1:30.62, where class 4th was 5th overall (a car of the
  other class ahead, it seems): GT500 runs at the front.
* Checkpoints (sector and lap lines): TT 0:06.85 (lap 1), 0:20.64, 0:36.24, 0:48.61 (lap 2), 1:01.92, 1:17.23. The game
  has no time extensions; its lap time limit isn't shown. `checkpoint` (1 s pulse) now ticked for SimHub.
* Sixteen contacts (sideways shove over 4 G), five speed-drop hits (0:15.67 228 to 183 km/h at full throttle with no
  shove: head-on?; 0:21.65, 0:55.47, 1:03.84, 1:14.97 with shoves). Verge 1:25.74 to 1:28.98. No solid kerb.
* `contact_side` changed to the side of the biggest shove in the last 0.3 s (it took the last crossing, which a rebound
  can reverse: 0:21.67 read the wrong way round). At 0:19.05 and 1:03.11 the shoves go both ways (two hits, or caught
  between cars?).
* Slides: 0:24.87 to 0:25.62 (-45 degrees at 133 km/h, Car_drift 0.77); small ones read 0.22 to 0.34 at 0:31.49 (+21 at
  189 km/h), 0:42.09 (-23 at 191), 0:55.32 (-18 at 252, just before a contact), 1:05.21 (-20 at 143).

### Questions (asked 19 November 2026, 11:40)

1. Contacts and the side the data gives (R right, L left of your car): 0:08.30 R, 0:09.33 L, 0:10.93 R (hard),
   0:12.04 R, 0:12.96 L, 0:19.05 L then 0:19.37 R, 0:21.67 L, 0:27.88 R, 0:31.94 L, 0:35.66 R, 0:42.59 R, 0:55.46 R (hard),
   1:03.12 L and R several times, 1:14.98 R, 1:17.68 L, 1:30.28 L (hard). Wall or car, and is any side wrong?
2. 0:15.67: 228 to 183 km/h at full throttle with no sideways shove: a car hit head-on (into its rear)?
3. Slides: 0:24.87 reads 0.77 (45 degrees, 133 km/h): right? Were 0:31.49, 0:42.09 and 1:05.21 slides (0.27 to 0.34
   now), or just corrections?
4. 1:25.74 to 1:28.98: the grass verge? Any solid kerbs in this run?
5. At 1:30.62, did the screen show 4th?

### Her answers (19 November 2026, 12:24)

1. Contacts: 0:08.30 R car; 0:09.33 nothing visible (perhaps a car on her right rear); 0:10.93 R rear, car; 0:12.04
   nothing; 0:12.96 nothing at that moment: a car on her front centre at 0:12.569 and front right at 0:13.119; 0:19.05 L
   car (the next shove perhaps the same car, also L); 0:21.603 a car on her front left; 0:27.88 R car; 0:31.94 nothing
   (a slide); 0:35.66 R car; 0:42.59 a car from behind on the inside of a left-hander, pushing her to the outside; 0:55.46
   a light right-wall grind attempt (the game made it hard: leave it); 1:03.12 two cars, left then right, several hits;
   1:14.98 right wall; 1:17.68 nothing: right tyres onto the hard kerb at 1:17.992 (2nd, 135 km/h), then the right wall at
   1:18.158 (132 km/h); 1:30.28 hit from behind.
2. 0:15.67: into the back of a car (head-on). 3. 0:24.87 should be 0.7; 0:31.49, 0:42.09 and 1:05.21 were slides.
4. No grass verge on this course; solid kerbs at 0:16.669 (right tyres), 0:34.336 (left), 1:12.824 (left, a clear
   clockwise roll), 1:17.992 (right). 5. 4th at 1:30.461.
* Attract mode (with the 18 November profile): speed, gears, Car_in_race, Car_speed, Car_rpm, Car_gear all 0. After a
  race, back in the menus, the revs stayed over 11k: the 19 November profile reads `revs` 0 outside the race (checked in
  SWDC-11's replay).

### Changes (19 November 2026, 12:30)

* `contact_side` = the other way from the **first** shove over 4 G (re-armed after 0.25 s under 4 G): a rebound the
  other way, sometimes as big, follows each shove, so the biggest isn't always the first. GT300 race: 12 of 12 sides;
  GT500 race: 8 of 10 she could tell (0:42.59, pushed from the inside, reads R; 0:12.96 takes the front-centre car's
  shove). False contacts left in SWDC-12: 0:12.04, 0:31.94 (a slide at 21 degrees, under the 25 degree gate), 1:17.68
  (mounting the kerb: the shove is the kerb's), and 0:09.33 (unclear).
* Car_drift = 0.072 x (|angle| - 10)^0.6 x sqrt(min(km/h, 150) / 100), refitted with her seventh value: 0.65, 0.53,
  0.57, 0.64, 0.60, 0.69 for the GT300 slides (her 0.65, 0.6, 0.5 to 0.55, 0.6, 0.55, 0.75) and 0.70 for 0:24.87 (0.7).
* Tests: SWDC-12's sides and its 0.7 slide checked. 2211 pass with the pack, 777 without.

### Open (SWDC wrapped up, 19 November 2026: she is not making more recordings)

* Solid kerbs on the GT500 course send no vibration command (none at her four kerb times), so Car_rumble_strip stays 0
  there; roll rate (21 to 34 degrees a second at her kerbs) also rises at contacts and in corners, so it wasn't used.
* Hits from behind give a sideways shove too, with a side; a car pushing from the inside of a corner read the wrong side.
* Car_drift reads over 0.1 about 11% of a race (cornering at 12 to 20 degrees and above 150 km/h).
