# Sega Rally (srallyc) program ROM check, 8 November 2026

Alexis sent the `srallyc` romset. MAME 0.264 won't run it (missing the billboard device ROM epr-18022.ic2, segabill), so the program space was built from the ROM files using MAME's layout: maincpu = epr-17888c.12 (offset 0) and epr-17889c.13 (offset 2), 16-bit interleaved, 1 MB.

## Lamps

* The lamp port 0x01C0001E is addressed three times: STOS at 0x2300 (a 16-bit store, likely a clear at start-up), STOB at 0x26D0 (address word at 0x26D0), LDOB at 0x26D8. The same two byte-sized instructions as STCC, so the TPT_LAMP_PATCH scan (LDOB/STOB only) moves the lamps to 0x500824; the STOS keeps writing the port.
* Nothing addresses 0x500800-0x50083F directly, but the code clears work RAM from 0x500000 at boot (lda 0x500000 / lda 0xFFFF at 0x4E0) and stores pointers to buffers at 0x500000 and 0x504000 (into 0x20CAB0, code at 0x2A7C8) and 0x505000 (into 0x215380). RAM+824 sits inside the first buffer, so check with a recording that it stays 0 before using the patch.

## RAM use (absolute MEMB addresses)

* RAM2: 761 addresses, 0x200000-0x2197B0 (482 in 0x200000-0x20FFFF, 279 in 0x210000-0x21FFFF). None above 0x220000.
* Work RAM: 591 addresses, almost all 0x5A0000-0x5FD7EC (264 / 97 / 100 / 60 / 43 / 24 by 64 KB page from 0x5A0000), plus the buffer bases 0x500000, 0x504000, 0x505000.
* 0x20B0B0 (the time left srallyc.lua reads) is addressed 16 times with 32-bit LD/ST; 0x202098 (srallycb.lua's state) 46 times.

## Scripts changed

`SCRIPTS/srallyc.lua` and `srallycb.lua` now log RAM2 0x200000-0x220000, work RAM 0x5A0000-0x600000 and 0x500000-0x501000 (to watch RAM+824), 4096 words a frame (whole set about every 0.55 s). The srallycb regions assume Rev B lays out RAM like Rev C. M2-tests.md lamp section updated; pack Game_Setup and README notes updated.

Daytona: asked Alexis for the romset to check its RAM layout the same way (the daytona.lua script logs work RAM 0x500000-0x540000 and RAM2 0x200000-0x210000, a guess from the FFB plugin's addresses).
