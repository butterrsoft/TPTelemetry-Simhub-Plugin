# OutRun 2 SP recordings, 12 November 2026 (10:05 and 10:09)

Alexis's recordings with the raw rows of 12 November (`claude/OUTRUN2SP-exe-20261111.md`, second pass), following the
test plan at the end of `claude/OUTRUN2SP-capture-20261111.md`. USB capture on in both. Times are recording seconds; RT
the time left on screen, TT the race clock.

| Recording | What (her notes) |
|---|---|
| `20261112-100526_OUTRUN2SP-2` (124 s) | OutRun mode (`game_mode` 1), a different car with six gears, manual; marks near the start at the redline in each gear; lots of hits on other cars and drifts. Ends mid stage 2 |
| `20261112-100900_OUTRUN2SP-3` (411 s) | Time Attack with another car (redline marks, a mark when the time ran out and the game ended), back to the attract mode (triple marks where she'd expect racing values), then Heart Attack with another car (redline marks, a few hits and drifts) |

## Modes and gates

* `game_mode`: **0 Time Attack** (52.3 to 154.2 s), **1 OutRun** (the 10:05 recording, and 11 November), **2 Heart
  Attack** (from 330 s); -1 in the menus; the attract demo reads 0 or 1.
* Time Attack: `time_up` (observer bit 1) at 154.22 s, race clock 100.00, `racing` and Car_in_race off there; then
  main sequence 18 (TIME UP), 23 route map, 26 game over, 27 exit, 2, then 3/4 (attract and title).
* Attract mode 187.8 to 310.6 s (main sequence 3, title 4 between): `racing` and Car_in_race 0 throughout, every effect
  value 0. `Car_speed` and `Car_rpm` show the demo car (up to 294 km/h, 9,520 RPM): they aren't zeroed outside a race.
* Heart Attack: `racing` from 347.40 s.

## Car hits and their side (the main result)

USB capture gave the true side of each hit (the FFB plugin pushes from the side hit). Against it:

| Recording | Time | TT | `hit_dir` | Contact word | USB | Speed change |
|---|---|---|---|---|---|---|
| 10:05 | 40.04 | 0:28.13 | 8, 9, 8 | 3 then 4 | left | -16 |
| 10:05 | 42.30 | 0:30.40 | 4, 5, 4 | 2 then 1 | right | -16 |
| 10:05 | 45.32 | 0:33.42 | 8, 9, 8 | 3 then 4 | left | -9 |
| 10:05 | 74.85 | 0:48.92 | 10 | none | left | -27 |
| 10:05 | 81.93 | 0:56.00 | 2 | 2 | right | -30 |
| 10:05 | 92.88 | 1:06.95 | 6 | none | none | -33 at 306 km/h |
| 10:05 | 98.92 | 1:12.98 | 8 | 4 | left | +6 |
| 10:05 | 105.26 | 1:19.32 | 4 | 2 | right | -36 |
| 10:05 | 109.97 | 1:24.03 | 6 | none | right | -29 |
| 10:05 | 114.63 | 1:28.70 | 2 | 3 | left | -35 |
| 10:05 | 115.29 | 1:29.35 | 4, 5, 4 | 2 then 1 | right | +13 |
| 10:09 HA | 372.13 to 373.20 | 0:22.78 | 4, 5, 4 | 2, 1 | right | +8 |
| 10:09 HA | 397.27 to 398.00 | 0:47.92 | 2, 4, 5, 4 | 2, 1 | right | -12 |
| 10:09 HA | 400.07 | 0:50.72 | 5, 4 | 1 | none | +7 |
| 10:09 HA | 407.37 | 0:58.03 | 8, 9, 8 | 3 then 4 | left | +9 |

* Contact words `hit_box1`/`hit_box2` (car +6C8/+6CC) mean the right-hand side, `hit_box3`/`hit_box4` (+6D0/+6D4) the
  left; each is set for 0.02 to 1.4 s at the hit. `hit_dir` (car +10DE, held until the next hit): bit 4 right, bit 8
  left; bits 1 and 2 add something else (2 alone, at 81.93 and 114.63 s, came with a contact word that gave the side).
  Every car hit with a USB side matched.
* New `car_hit` (a contact word set, or `hit_dir` changing to non-zero; held 0.3 s) and `car_side` (+1 right from words
  1/2, -1 left from 3/4, else bit 4 or 8 of `hit_dir`). Car_impact now includes `car_hit`; Car_impact_side = `car_side`,
  else `wall_side`. Live, Car_impact had missed only the 92.88 s hit (no crash count, no USB push); `car_hit` catches it.
* The game also raises the wall-hit countdown (+43A) at car hits, so `wall_hit` fired at two of them (105.26, 400.07 s).

## Redline light

`rev_limit` (car data +1068 x 10) read 8,901 and `rev_1030` 1,571 (157.08 = 50 pi, in tens) on all three cars, so
either these cars share their engine data or these aren't per-car values. Revs per gear top out at 8,900 to 9,430
(9,810 in first at the start). Her marks are at the limiter (8,800 to 8,950), after the light. Where `shift_light`
(8,380) comes on, to check against her video:

| Recording | 2nd gear | 3rd gear |
|---|---|---|
| 10:05 OutRun | 17.00 s, TT 0:05.100 | 21.20 s, TT 0:09.300 |
| 10:09 Time Attack | 59.02 s, TT 0:04.783 | 62.42 s, TT 0:08.167 |
| 10:09 Heart Attack | 354.47 s, TT 0:05.117 | 357.07 s, TT 0:07.717 |

## Course events and hearts

* observer_flag 64 (with `course_event` 8) came 13 to 15 s into stage 1 in all three modes: 10:05 at 27.02 s (TT
  0:15.12, RT 84.9), Time Attack at 67.71 s (TT 0:13.47, RT 86.5), Heart Attack at 362.75 s (TT 0:13.40, RT 86.6);
  11 November at TT 0:12.17. 32 (the fork arrow) at 84.98 s (TT 0:59.05) in the 10:05 recording and 400.10 s (TT
  0:50.75) in Heart Attack.
* Heart Attack: `hearts` rose 0 to 1,720,000 at 383.40 s (TT 0:34.05, RT 65.9) and to 3,970,000 at 396.08 s (TT
  0:46.73, RT 53.2).

## Profile and tests

* `car_hit`, `car_side`; Car_impact and Car_impact_side use them. `game_mode` note names the modes; notes on `hearts`,
  observer bit 64 and `course_event`. Hit rows read through `valid()` so recordings without them aren't affected.
* Pack diff: only OUTRUN2SP.json (and the pack's docs) changed.
* `Or2GameTests` replays the 10:05 recording (new fixture `or2-20261112-100526.csv.gz`, in the game's units) without USB:
  all ten sided hits get the USB's side from the game alone, and the 92.88 s hit reads as a hit. 1799 tests pass with
  the pack, 764 without.

## Asked (12 November, 10:30)

1. The redline light at the TTs in the table above (2nd and 3rd gear in each recording), and which cars these were.
2. The 92.88 s hit (TT 1:06.95, RT 33.0): what hit her.
3. The observer 64 moment (13 to 15 s into stage 1) in Heart Attack (TT 0:13.40): a request from the passenger, a sound?
4. Heart Attack at TT 0:34.05 and 0:46.73: what the hearts showed.
5. Attract mode: Car_speed and Car_rpm still show the demo car (effects are off): fine as is?

## Alexis's answers (10:52 and 11:10)

1. **Cars:** 11 November the Testarossa (the classic); 10:05 the Enzo; 10:09 Time Attack the 250 GTO, Heart Attack the
   512 BB.
2. **Redline light** (from her video). My first TTs were the light carried over from the gear before for a frame or
   two after a shift (it goes off as the needle falls). Onsets:

   | Car | Gear | TT on | Revs then |
   |---|---|---|---|
   | Testarossa | 3rd | 0:07.375 | 8,370 |
   | Enzo | 1st | 0:03.15 | 8,930 (revs passed 8,270 at about 0:02.85) |
   | Enzo | 2nd | 0:05.863 | 8,270 |
   | 250 GTO | 1st | 0:03.388 | 8,270 |
   | 250 GTO | 2nd | 0:05.996 | 8,270 |
   | 512 BB | 1st | 0:03.355 | 8,260 |
   | 512 BB | 2nd | 0:06.328 | 8,260 |

   So one threshold fits nearly all: `shift_light` = revs >= 8,270 (it was 8,380 from the Testarossa alone; it now lights
   that car 0.1 s sooner). Modelling the needle's smoothing made the spread worse. The game draws a rev dial per car
   (`NaviPub_Disp`: frame = display revs (car +3C4, the revs smoothed 1/8 a frame) / 10,000 x 180, capped at 179; sprite
   by the car's dial type, car +0A; ten designs, all scaled to 10,000), so the light can differ a little by car. Alexis:
   it doesn't need to be perfect.
3. **92.88 s (10:05):** she ran straight into the back of another car. `hit_dir` 6 (bit 4 + bit 2), the same code as the
   front-right hit at 109.97 s, so it reads as a right-side hit; it can't be told apart.
4. **Observer 64 in Heart Attack** (TT 0:13.40): nothing much happens; the passenger's request may become active about
   half a second before. Left unnamed and unused.
5. **Hearts:** the two jumps are the finishes of the two challenges: 172 hearts, then 225 more (the display ticks up).
   `hearts` = value / 10,000 (0, 172, 397), ticked; new `challenge_won` (1 for 1 s when the total jumps).
6. **Attract mode:** `Car_speed` and `Car_rpm` should read 0 there like the effects (FFB in the menus is the FFB plugin's).
   For this game, `car_speed`, `car_rpm`, `car_gear` and `car_accel_g` are now `racing ? ... : 0`.

## Profile and tests (11:15)

* `shift_light` 8,270; `hearts` (x 1/10,000, ticked) and `challenge_won`; Car_speed/rpm/gear/accel_g 0 outside a race;
  notes on observer 64. Pack diff: only OUTRUN2SP.json and the pack's docs changed.
* New fixture `or2-20261112-100900.csv.gz` (`Or2GameTests.Modes`): game modes, Car_in_race GO to time up and in Heart
  Attack, nothing (not even Car_speed, Car_rpm, Car_gear) in the attract mode while the demo car drives, hearts 0/172/397,
  `challenge_won`, the GTO's and BB's redline light in 2nd, Heart Attack hit sides. The Enzo's light checked in
  `Traffic`, the Testarossa's and Car_speed/rpm after the line in the 11 November replay. 1811 tests pass with the pack,
  764 without.

## Open

1. Car_drift for OutRun's deep drifts (full at 75 degrees): by feel, with target strengths for a few marked drifts.
2. SHIFT UP: never shown (needs 3 s at nearly full throttle above the gear's shift speed).
3. Observer 64: no meaning found.
4. Per-car redline light, if 8,270 ever feels off on a car: the dial type (car +0A) and display revs (car +3C4) are the
   places to read.
