# Scud Race in Supermodel (SMSCUD): Alexis's recordings, 18 November 2026

Follows `SMSCUD-supermodel-20261118.md` (how Supermodel's RAM is read and how the values were found in the emulator).
Four recordings with the morning's profile (Max speed 350, Max revs 7500), USB capture and Supermodel's outputs on:

| File | Car, gearbox, course | Her marks | End |
|---|---|---|---|
| 12:09 (SMSCUD-1) | Porsche 911, manual, Beginner night | jumps, checkpoints, the time-over screen (12) | time up, TT 1:53.33, 33rd |
| 12:11 (SMSCUD-2) | McLaren F1, manual, Medium | jumps and some checkpoints (3); lots of drifting; turned round about 2/3 through | time up, TT 2:11.23, 29th |
| 12:14 (SMSCUD-3) | Ferrari F40, automatic, Expert | three into the pits, three when the stop was over, two others (checkpoints) | time up, TT 2:28.18, 20th |
| 12:21 (SMSCUD-4) | Dodge Viper, manual, Beginner night | jumps (3) | the finish line, TT 2:18.42, 21st |

## What checked out

* `ram_probe` 2087778982 throughout all four: the RAM pointer is right for her build.
* `racing`: from the Beginner rolling start's 3-2-1 (state 0x10400), or from GO on Medium and Expert, whose standing starts
  leave the state word at phase 4 throughout (no 0x10000 sequence), to the clock stopping. The state's top byte changes
  one or two samples after the clock stops, and is **the finishing place less 1** (0x20 = 33rd, 0x1C = 29th, 0x13 = 20th,
  0x14 = 21st; 0x10 = 17th in the emulator): `final_position`. It is kept into the attract mode and the next race, so
  `racing` now also needs the top byte unchanged since the race clock was 0, and the clock window is 0.1 s (was 0.25):
  racing ends within 0.04 s of the clock stopping.
* Time extensions: +26.67 s (1520 frames) at Beginner night's lap lines; +14.23 s (811 frames) at Medium and Expert
  checkpoints, two or three a lap. `time_extended` caught them all.
* Laps: Beginner night finishes after four laps (`lap` 5 at the line); Medium and Expert ran two laps before time up.
* Steering follows the wheel over USB (0.96 to 0.98), throttle 0.85 to 0.97; the game's brake reads nothing until the pedal
  is about half way down.
* Rev limits: Porsche 7200, Viper 7200, McLaren 8500 (where the revs sat, manual); the F40 (automatic) reached 9370 once.
  The car number byte, car record +0x105 (game address 0x181105), was then found in the emulator: 4 Porsche, 5 Viper,
  6 F40, 7 McLaren (selection on the car screen follows the wheel's position: hold steer right while pressing the
  accelerator). `rev_limit` and `rpm_frac` use it; the F40's 9500 is a guess. Max revs is now 9500.
* `engine_334` is the revs in radians a second (revs / 9.55); `speed_338` 0.86 x km/h.
* **Jumps:** in the air `move_y` falls by 0.00287 m a frame each frame (the game's gravity, about 9.5 m/s2), exactly, so
  `airborne` = the slope of `move_y` over 0.15 s within 0.03 of -0.165 for 0.1 s. Every jump mark (Beginner night three a
  lap at the same places, Medium) reads 1; smaller hops too, the same places each lap. `flag_38c` comes on at jumps but
  also elsewhere, in whole thirds of a second: not an airborne flag.
* **Pit stop** (Expert): the game takes the wheel (throttle and steering 0), the car stops and the time left stands still
  from TT 1:07.74 (in the pit lane, before her marks) to 1:24.42, while the race clock runs on: `pit_stop`. `area_388`
  dropped to about 5 at the pit exit.

## What didn't

* `wheel_angle` (car +0x2C4) followed the keys in the emulator but read -165 to 313 and nothing like the wheel in her
  recordings: renamed `misc_2c4`, unticked. Car_cornering now comes from `steer` and speed, as Initial D 3.
* The crash timer only fires at big crashes (100 km/h or more lost; one in the Porsche recording, three on Medium, seven on
  Expert). Ordinary wall hits and car hits don't set it.
* Drift angles reach 40 to 77 degrees in her slides (90th percentile 25 to 32 degrees in the drifting runs), so Car_drift
  full at 45 read 1 too often: now full at 70 degrees, and 0 above 120 (the car going backwards: reversing or spun round,
  which read 179).

## Added after the recordings (found in the emulator; not yet in a recording)

* `car_contact`, car record +0x2F7: 255 none; 0 a car on the left, 2 on the right, 3 ahead (nose into its tail), 1 behind,
  from where the touching car was in the emulator log (about 2 m to the side, 4 m ahead or behind). `car_side`,
  `car_touch`.
* `near_car`, car record +0x101 bit 4 (value 16): another car within about 5 m.
* `hit` now: 1 for a big crash; otherwise, touching a wall (`wall_contact`) or another car (`car_touch`) within 0.3 s,
  0.4 at 10 km/h lost in 0.25 s up to 1 at 46 km/h. `hit_side` from the touching car, else the wheels against the wall.
* `wrong_way`: the road strip number (`seg`) running backwards (an average of its change < -0.03 a sample) above 20 km/h.
  Fired once, Porsche at TT 1:35.14 after the big crash (her marks there); also in Expert's pit lane, whose strips are
  numbered differently. Not seen where she said she turned round on Medium.

## Tests

`ScudTests` replays three of her recordings (fixtures worked back to raw values, every second sample, marks kept:
`supermodel/capfixture.py`) and the three emulator logs: racing gates, TT at the line, finishing places, laps, time
extensions, airborne at her jump marks, the Viper's limiter, the pit stop, big crashes, car contact sides in the emulator.
2056 pass with the pack, 770 without.

## Asked (18 November 2026)

1. Porsche, TT 0:02.84 (RT 57.16): 35 km/h lost in 0.2 s at 316 km/h, no brake and no wall: a rival car hit? Which part
   of her car?
2. Porsche, TT 0:52.82 (RT 33.84) and 0:54.93 (RT 31.74): wall hits, right then left?
3. Porsche, TT 1:03.32 (RT 23.35): what happened (her mark; no jump there)?
4. Porsche, TT 1:35.14 (RT 18.19): REVERSE! on screen, after the spin at 1:31.88?
5. McLaren: the TT when REVERSE! showed after she turned round.
6. McLaren drift sign: the slide from TT 1:07.35 (RT 21.14, about 2 s) reads left; from 1:43.63 (RT 13.35) right.
7. F40: the rev counter's top, and where the needle sits when the gearbox changes up.
8. Whether effects should run in Beginner's rolling-start 3-2-1, where the game drives (they do now).
9. How strong Car_drift should be in her biggest slides (0.6 to 0.65 as Initial D, or full).
10. A next recording with car hits (now `car_contact`) and wall scrapes, noting the side.

## Her answers and a fifth recording (13:30, F40 manual, Beginner night)

1. TT 0:02.84 (Porsche): straight into the back of a rival. 2. 0:52.82 right-hand wall, 0:54.93 left. 3. TT 1:03.3: the
   jump taken slower, only the front wheels leave the ground, back down by 1:04.16 ("pronounced, if not so much as a jump").
   4. REVERSE! on screen at 1:35.14 (it flashes). 5. No other REVERSE!. 6. Drift signs right (left, then right).
   7. The F40's rev counter reads to 10k; the automatic changes up at 7.8k to 7.9k, the same each time (the game's value:
   7,760). 8. Keep effects in Beginner's rolling-start 3-2-1; on Medium and Expert, revs and gear during the grid countdown.
   9. F40 recording: the drift at TT 0:39.33 should read about 0.9, at 1:40.30 about 0.65; spread from those.
* Outputs (`-outputs=net`): the drive commands and lamps arrive in every recording. View3's lamp lights in races (View4
  once); Start and Leader never lit in these. The decoded `force` (held until the next roll command, as SMDAYTONA2 and
  SMLEMANS24 still do) matched the wheel force over USB poorly (correlation 0 to 0.4): the FFB plugin's roll forces stop
  between commands. For Scud only it now lasts 0.1 s after each roll command (0.15 to 0.8).
* Fifth recording, her events in order: `car_contact` read 3 (up the back of the car in front, TT 0:01.07), 0 (a car on
  her left, 0:02.68), 2 (right, 0:04.49), 0 (left, 0:05.63): the sides found in the emulator are right. The big crash and
  flip on the left-hand wall at 0:06.47 (crash timer, left); the left-hand wall at 0:15.82 and 0:20.68 (-1), the right-hand
  wall at 0:26.39 (+1). Car = 6 (F40). It reached 9,040 RPM.
* **The road strips come in lanes:** on Beginner night a strip number + about 716 is the verge beside it (+1641 and
  +926 also appear). Along the right-hand grass verge (0:11.2 to 0:13.1) the car's middle was on the verge lane, so the
  wheels still on the road read as off the strip: `wall_contact` read the left there. Not fixed: needs each course's
  lane layout (the strip count per lap is in the wrap: 737 Beginner day).

Changes (13:45): `hit` 0.5 for 0.2 s as another car first touches (side from it); `light` (falling at 0.7 g or more for
0.1 s: TT 1:03.3 reads 0.9 s), Car_airborne 0.5 for it; Car_drift straight from 14 to 58 degrees (0.90 and 0.65 at her
two points); `grid` (phase 4, no countdown, clock 0, time set): Car_in_race on, and only Car_rpm, Car_rpm_frac and
Car_gear run; F40 rev limit 9000 (guess); `force` 0.1 s (Scud only). `ScudTests` adds the fifth recording and checks for
each answer: 2066 pass with the pack, 770 without.

Still open: the F40's limiter (where the needle stops in manual); the verge; whether the engine effects should follow
the throttle on the grid (Car_throttle is still 0 before GO).

## Daytona USA 2 Power Edition recording (13:32)

Recorded with the SMSCUD profile: `ram_probe` read 2087778982, so the same RAM pointer works in Daytona 2 (same exe), but
every other memory row read one constant (Scud's addresses hold other things in Daytona 2). The outputs arrive
(RawDrive 41 commands, lamp bit 32). Daytona 2's own values need finding the same way as Scud's: Supermodel's
`dayto2pe` is a clone of `daytona2`, so both ROM zips are needed (and her NVRAM would skip the LINK ID step).


## Her answers (14:26) and changes (15:00)

* The F40's limiter is about 9k: at TT 0:15.30 in her fifth recording it reads 9,040 in first gear. `rev_limit` for car 6
  is now 9040 (was the 9000 guess), so `rpm_frac` reads 1 there (a test checks it).
* On the stationary grid (Medium and Expert) the rev effect should follow the revs. Car_throttle now reads 1 on the grid
  (`grid` true, before GO), so the engine effects run on the revs alone there; from GO it is the game's throttle again.
* Daytona USA 2 Power Edition is its own profile now: `SMDAYTO2PE-supermodel-20261118.md`.
