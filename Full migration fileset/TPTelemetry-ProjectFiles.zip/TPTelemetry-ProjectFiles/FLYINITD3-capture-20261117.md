# Initial D 3 in Flycast (FLYINITD3): recordings 3 and 4, 17 November 2026 (14:13 and 14:20)

Follows `claude/FLYINITD3-states-20261117.md`. Made with the afternoon profile (80 rows), Broadcast Digital Outputs on
(the FFB Arcade Plugin's files removed: that stopped the menu freezes, as guessed), USB capture on. Rows:
`moregames.fly_id3_game`; common rows in `commonrows.py`.

* **Recording 3** (286 s): Honda Civic, automatic, Time Trial, Irohazaka downhill, day, dry; no rival. She revs on the
  grid, brakes, coasts and stops before the first real corner, then goes again; gutters full of leaves; much drifting
  and hitting. Marks at 51.0, 53.75, 103.37, 168.96, 217.59, 218.17, 230.82, 278.22.
* **Recording 4** (218 s, cut off mid-race): Mazda RX-7 Savanna, manual, story mode, Akagi downhill, day, wet. Marks at
  56.0 (on the grid, revving), 62.53 (start), then 111.9, 161.49, 169.02, 170.0, 193.69. Gutters, drifting, car hits;
  she passes the rival, hits him, is hit from behind and passed again.

## Settled

* **The heap rows moved:** `rt` read 0 and `race_clock`, `lap`, `hud_*` read rubbish in both. Removed. The clocks need a
  pointer chain from a fixed address, and the pointers in the game's memory are 32-bit game addresses, which the
  plugin's chains can't follow yet (they read the host's 8-byte pointers). Candidates from one race (not trusted):
  [0x0C8FF174] + 0x418 -> + 8 for the time left, [0x0C8FF174] + 0x588 for the race clock, [0x0C8FF174] + 0x4FC -> the HUD
  block. Needs a state from another race to confirm, then a plugin change (an offset that follows an emulated pointer).
* **`speed`, `rpm`, `gear`, `gap`** read sensibly in both (static). `gear` is 0 on the grid and goes to 1 at GO in both
  (53.46 and 62.20; first movement 53.48 and 62.23; her start mark 62.53), manual and automatic. `gap` is 0 throughout
  the time trial and runs -111 to +8.3 in the story race (ahead 159.2 to 171.1 s).
* **0x0C900E9C is the revs the throttle asks for** (`thr_revs`): 0 with no car on the road, 800 pedal up, the rev limit
  pedal down (9000 Civic and GT-R, 7000 RX-7). Correlation with the pedal over USB 0.96; `throttle` made from it differs
  from the USB pedal by 0.02 on average.
* **0x0C900EA8 is revs / (rev limit + 500)** (`rpm_top`): revs / it = 9500.0 (Civic, GT-R) and 7500.0 (RX-7) on every
  sample. `rev_limit` = that, to the nearest 500, less 500.
* **Steering:** 0x0C900BB8 (float, -1 to 1, + left; correlation with USB steering -0.98) and 0x0C901688 (the raw input,
  0 to 16383, 8192 centred, higher left; -0.985). `steer` = -BB8.
* **`live`** = thr_revs > 0 (car on the road, from the grid). **`racing`** = live and gear > 0 (from GO). The end after
  the finish line is unknown: neither recording reaches it for certain (recording 3 ends 7.7 s after her last mark,
  where the speed falls from 114 to 0 in 1.3 s; revs still live at the end).
* **Lamps:** bit 3 blinks once a second (0.75 s on, 0.25 off) from the grid through the race, and was steady for 4.5 s
  in a menu in recording 4; bit 7 came on for 0.7 s at the start of recording 3. No bit follows the lead, so the leader
  lamp is made from the gap (`lampleader` = racing and gap >= 0; lit through a time trial).
* **`midiffb`** now arrives: commands 128, 132, 133, 134 (and 250 once in recording 3). Force up to 0.71 in the time
  trial and 0.38 in the story race: the game's own force is modest. Vibration (133) runs through the race at 1/127 with
  peaks to 0.37.
* The position rows are right (speed from them matches `speed_abs` within 0.2%); `dir_x`/`dir_z` follow the direction of
  travel (0.97 to 0.99).

## Candidates still open

* `contact_flag` (0x0C900B40), `contact_code` (B44, 0 to 3), `contact_level` (B48, 0 to 0.30): come on together at what
  look like hits and scrapes; the level tracks the game's vibration peaks.
* `wheel_a` to `wheel_d` (0x0C900A74 on): 16 on plain road; 48 (Akagi) or 49 (Irohazaka) for short spells, also 14, 18,
  28, 32, 57 and, at the end of recording 3, 22, 26, 27. a/b move together, c/d together.
* `progress` (B08) counts along the course. `wheel_kmh`, `eng_*`, `race_1710/1718/171c` were dropped (not speed; noise).
* No brake value yet (nothing follows the USB brake). Two direction vectors (`dir_*`, `dirb_*`) for a drift angle.

## Asked of Alexis

Events by TT (time since GO) in both recordings: what happened at each (wall, gutter, rival, which side). The Trueno
in-race save state from recording 1 and one new state from a time trial, to pin the clocks. A recording through the
finish line to the results.

## 15:22: her answers, a third save state, and recordings through the finish and time up

* **Her answers** (events asked by TT since GO). Recording 4 (RX-7, Akagi): 0:17.58 a left hairpin, hit the left apex
  gutter; 1:26.57 to 1:29.20 a right hairpin: a wall on her left, then the rear left on the guard rail twice, no
  contact with the rival; 1:37.02 a left hairpin: hit his rear with her front, then the left apex rail, perhaps her
  right rear on him; 1:51.32 a right hairpin exit: right front on the right wall; **he hit her from behind just before
  TT 1:45.27 and six or seven more times after**; from 2:31.64 she had stopped driving. Recording 3 (Civic,
  Irohazaka): 0:35.07 a left hairpin, front left on the left rail twice; 2:06.81 a failed shortcut over a left
  hairpin's apex, grinding on the rail (front left, front right, front left); another failed one near 2:26.52;
  successful shortcuts ending near 2:36.28, 2:41.75, 2:43.85 with a drop on to the road below; 3:44.86 **the finish
  line: the game brakes the car to a stop**. Attract mode: speed, revs and gear stay 0 (her own recording).
* **`contact` (0x0C900B40)** was on at each wall, rail and gutter-edge contact she described, and not once between TT
  1:38.5 and 1:51.3 where the rival hit her from behind: walls and rails, not cars. `contact_code` (B44) didn't line up
  with sides (left gutter 3; left wall 1 then 3; right wall 1; left rail 3 then 1). `contact_level` tracks the game's
  vibration peaks.
* **Gutter:** wheel code 48 (Akagi) and 49 (Irohazaka, leaves) at the apex gutters; `gutter` = any wheel 48 or 49.
  Wheel order not settled (a/b the front pair; a first at a left wall, d at a left gutter).
* **Steering sign confirmed** by which way the car turns: in the known left hairpin the heading turns one way and
  0x0C900BB8 is + with it (0.79 over the race), so the game's value is + left and `steer` (turned round) is + right.
* **0x0C900C3C** is -1 whenever the throttle is up, and after the line: drive, not the brake. No brake value yet.
* **Finish (recording "4" of 15:16, time trial, 17 s):** at the line the throttle request drops to 800 with her pedal
  still down, the car is braked from 114 km/h to 0 in 1.5 s and then idles (thr_revs 800, gear 1) through to the menus:
  `live` and gear > 0 stay on, so the first `racing` never ended. **Time up (recording 5, story mode, 19 s):** the same,
  idling in 3rd with the gap frozen at -854.79 m.
* **Save state `initdv3e_5`** (time trial; RECORD/DIFFERENCE panel; RT 27, TT 2:30.833, sections 0:52.878, 0:54.388 and
  0:43.566 running, 111 km/h, automatic, 4th): the race clock is again 0x0DF98C48 = 905000 and the game's pointer
  0x0C8FF174 again holds 0x0DF986C0; the timer object is elsewhere (0x0D9B7B40, was 0x0DAF0760) and the race object's
  +0x418 points to it; +0x4FC points to the HUD block (0x0DBF3600, was 0x0DCF6080). So: **[0x0C8FF174] + 0x418 -> + 8
  time left; [0x0C8FF174] + 0x588 race clock (+0x584 a frame behind); + 0x590 lap or section less one.** Both states have
  the race object at the same address, so the first pointer is still untested across sessions (recordings 3 and 4 show
  it does move): a recording with the new rows settles it.
* **Plugin 0.18.2, helper 0.17.1:** offsets written `@588` follow the game's 32-bit pointers inside the emulated RAM
  (`Hex.EmuHop`, `MemorySource.Walk`; the helper's read plan carries the flag). Tests in `Program.PointerWalk`.
* **Rows:** `rt`, `race_clock`, `lap` (`moregames.fly_ptr`); `racing` = live and gear > 0 and the race clock moving
  (falls back to the first two if the clock can't be read); `lampcheckpoint` = racing and the time left jumped up by
  more than 0.5 s, held 2 s; `contact`, `gutter`. 1975 tests pass with the pack, 770 without. The compile check
  (mono) was not run in this session.

## 16:57: a whole race with plugin 0.18.2 (recording 6): the clock rows hold

* 271 s, a story race of three laps from the menus through the finish and back to the menus; marks at GO (68.77), the
  two lap lines (141.69, 200.65) and the finish (259.11). A new Flycast session, so the first pointer is now tested
  across sessions.
* **`rt`, `race_clock`, `lap` read right through the `@` chain:** nothing in the menus (null pointer), 90 s and 0 on the
  grid from 57.95 s, the clock starting at GO (68.46; 0:00.33 at her mark), time left 17.08 to 77.07 at 141.58 and 18.23
  to 77.20 at 200.66 (0.1 s before and 0.01 s after her marks), laps 1, 2, 3, the clock stopping at the line at 259.23 on
  3:09.83 (her mark 259.11) with 19.13 s left. Lap times from the clock: 1:12.90, 0:58.87, 0:58.07.
* **`racing`** on at 68.46 and off at 259.23. **As the race is cleared away (269.16 to 269.82) the race object holds
  rubbish for about 0.6 s**, including one sample that looked sensible (lap 8, time left 0, clock 0.05), which lit
  `racing`, the leader lamp and the checkpoint lamp for half a second. Fixed: `race_ok` (lap 1 to 99, time left above 0
  and under 1000, clock 0 to 7200) gates `racing`, the clock's step must be under 0.5 s, and the checkpoint jump under
  300 s; the fallback to "live and in gear" is gone. So `racing` also ends at time up.
* Rev limit 8000 for this car; 199 km/h in 5th.
* **Steering sign** needs nothing more: the car's turn in a known left hairpin and the wheel over USB (0.98) agree that
  `steer` is + right; her answer 1 had been a guess from my wording.
* Test: `Fly3Tests.cs` with fixture `flyinitd3-20261117-165737.csv.gz` (every second sample, game units): GO, the line,
  the menus, the clocks, laps, both checkpoint lamps and nothing elsewhere, the leader lamp, rev limit, steering and
  throttle against USB. 1989 pass with the pack, 770 without.
* Asked: the results screen's total and lap times against 3:09.83, 1:12.90, 0:58.87, 0:58.07.

## 17:54: ripple strips, drift angle, contact sides, Max speed and revs (recordings 7, 8, 9)

* **Recordings:** 7 (17:34, 123 s; racing from 21.56 s, laps 1 and 2, codes 16, 18, 32, 49: Irohazaka-like), 8 (17:36,
  13 s, "braking test and finish": `racing` drops at 10.13 s as the time left reaches 0), 9 (17:50, 111 s; racing 13.40
  to 103.65 s, time up; codes 14, 16, 20, 21, 32, the same course as recording 6). `rt`, `race_clock`, `lap` right in
  all three; rev limit 8000 in all.
* **Surface codes under each wheel (0x0C900A74 on):** 16 plain road. **20 = ripple strip:** the only code the game shakes
  the wheel hard for (vibration 0.22 against 0.01 on road), all four wheels, short spells at speed: 48 spells in
  recording 6's three laps (first at TT 0:06.10, 0:08.00, 0:11.50), 16 in recording 9. 21: all four wheels, long spells
  (12 in recording 6, first TT 0:08.90), no shaking: another road surface. 32: mostly the front pair, with contact a
  third to half the time: the edge beside a rail. 18: Irohazaka (7 spells in recording 7, first TT 0:20.47). 48/49
  gutter. 14: one wheel against a rail. Asked her to confirm 20, 21, 32, 18.
* **Heading:** 0x0C9008C0 is the car's yaw in radians, running on past a full turn; (sin, cos) of it is the unit vector at
  0x0C900D10 (three states). 0x0C9008B0/8B8 is the distance moved last frame (x 216 = km/h in three states; follows the
  path within a degree in recordings). 0x0C900A14/A1C (the old `dir`) is not the heading (its big differences from the
  path come with contacts). **`drift_angle` = -(yaw - the angle of travel)**, + nose right of the path, taking yaw as
  rising in a left turn (the same sense as the path's angle in the known left hairpin). States give -7, -4 and 1
  degrees; **not recorded yet, so the sign is unconfirmed** (Car_drift uses only its size, ID6's weighting).
* **Contact side:** 0x0C900C48 (`kick_x`) is the sideways knock: - left, + right in six of seven contacts whose side she
  gave (L gutter -0.10, L wall -0.05, rear-L rail -0.11, R wall +0.19, L rail -0.27 and -0.25; one rear-L slide +0.18).
  0x0C900C4C (`kick_y`) lengthways: -0.26 for her nose into the rival's tail. Knocks only come with `contact`, so the
  flag covers the rival too; the hits from behind she saw around TT 1:45 show in nothing. `wall_contact` = contact x
  side (as guard rails, her instruction); `hit` = knock over 0.1, full at 0.3, with `hit_side`.
* **Common rows:** Car_impact/side (`hit`), Car_wall_contact, Car_rumble_strip, Car_drift, Car_drift_angle; every Car_
  value but Car_in_race reads 0 outside `racing`. **Max speed 205** (her figure). **Max revs 9000**: the highest rev
  limit seen; revs reach 100% of each car's limit under power (Civic 9000 of 9000) and up to 109% for a moment on a
  down-shift (RX-7 7642 of 7000; the 8000 car 8704). Car_rpm_frac uses each car's own limit, so Max revs only scales
  the plain `rpm` row.
* No brake row: she pointed out accel_g covers braking, as in the WMMT profiles.
* `Fly3Tests`: ripple strips (48 spells, the first at TT 0:06.10), wall contact values, Car_ values 0 after the line.
  1993 pass with the pack, 770 without.

## 19:37: her answers, the drift recording (11), and the wrap-up

* **Answers:** TT 0:06.10 on Myogi is a ripple strip (code 20 confirmed). Code 21 (Myogi, TT 0:08.90) is grooved concrete:
  lines pressed into the road along its length. Code 32 (Myogi, TT 0:25.43) is the right-hand kerb and gutter, a few
  rail hits but mostly wheels in the gutter. Code 18 on Irohazaka is the kerb with leaves (recording 7, TT 0:20.47, and
  0:27.80 after rail contacts: the contacts there read right at 0:26.03 to 0:26.43, then left at 0:26.97); treat as the
  leaves. Recordings 6 and 9 are Myogi, 7 Irohazaka.
* **Recording 11** (19:33, 38 s, RX-7, manual, Akagi, laps 1 to 2; drifts, no marks): `drift_angle` sign matches the
  turn (right-hand drifts +) in 99% of samples over 15 degrees; she steers into the drift (no countersteer). Drifts:
  +21.3 (TT 0:37.60, 91 km/h), -20.0 (0:41.57), +20.4 (0:47.57), -18.2 (0:51.00), -20.1 (0:35.23); at TT 0:31.67 a rail
  contact swung the angle to 32 to 36 degrees for a second (Car_drift read 0.93).
* **Car_drift:** she asked for 0.6 to 0.65 at most, in line with the other Initial D games (no shakers on this rig).
  ID6's curve with full at 45 degrees (x = (|angle| - 5) / 40) gives 0.62 at the top; `drift` = that, but during a
  contact never more than just before it (0.59 there).
* **Rows:** `gutter` = codes 18, 32, 48, 49; `grooved_road` = 21; Car_off_road = gutter; Car_cornering =
  clamp(ema(steer, 0.1) / 0.8 x sqrt(speed / 120)), hard bends 0.6 to 1 (no outputs needed); `lampleader` = live, race_ok,
  clock > 0 and gap >= 0 (held after the line until the race is cleared, as Initial D Zero's; lamps aren't tied to
  racing); `lampcheckpoint` gated on race_ok, not racing.
* **Outputs off loses:** `ffb_raw`, `ffb_cmd`, `ffb_str`, `force`, `spring`, `vibration`, `force_abs`, `force_smooth`,
  `force_kick`, `lamp0` to `lamp7`, `lamp_bits`, and Car_road_bump and Car_vibration (which read 0). Everything else is
  memory, including both made-up lamps.
* **`ram_probe` removed from the table** (it read 3509307139, 0xD12BD303, on every sample of eight recordings: game
  address 0x0C020000 through `<main>+2840C90`). To check the RAM pointer on another Flycast build, add a UInt32 row with
  Module `<main>`, Base offset `2840C90` (or the new build's), Offsets `20000`.
* Tests: `Fly3Tests.cs` now replays both fixtures (`flyinitd3-20261117-165737` and `-193351`): drift sign both ways,
  Car_drift top 0.58 to 0.66, the contact cap, Car_cornering's sign. Compile check (mono) passed. 1999 pass with the
  pack, 770 without.

## 18 November: `ram_probe` back in the table

* Alexis asked for it back, to test newer Flycast builds with: UInt32 at Module `<main>`, Base offset `2840C90`, Offsets
  `20000` (game address 0x0C020000). A steady 3509307139 (0xD12BD303) means the plugin reads the game's memory; 0 or a read
  error means the new build keeps its RAM pointer elsewhere. To find it: copy the new `flycast.exe` to `bin.exe`, run
  `exe/dis.py`, and look for the one place that does `lea reg, [rax + 0xc000000]` beside `add rax, 0xa000000`; the store
  after it is `mem_b.data`, the new base offset (FLYINITD3-flycast-20261117.md). Then change `FLY_RAM` in `moregames.py`.

## 19 November: Flycast v2.7-1 (the pointer moved)

Her recording of 12:39 with the new Flycast read nothing from any memory row; the new exe's pointer is `<main>+29D0C10`
(end of `FLYINITD3-flycast-20261117.md`). `FLY_RAM` changed; every other row unchanged. To confirm: `ram_probe` steady at
3509307139 in her next recording.
