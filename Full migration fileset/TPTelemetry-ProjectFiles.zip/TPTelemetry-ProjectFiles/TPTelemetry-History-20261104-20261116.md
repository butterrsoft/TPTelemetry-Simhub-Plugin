# TP Telemetry: change history, 4 to 16 November 2026

Moved out of the handover on 16 November 2026 to keep the handover short. Newest first. The per-game notes (`claude/<GAME>-...md`) have the detail; the 4 November reference (`TPTelemetry-Reference-20261104.md`, the old handover) has the history before this.


### 16 November (21:00): Initial D Zero cornering and lamps

* Alexis asked: Car_cornering from steering and speed (commonrows ID0V230), and lamps from race values (`lampleader` from
  the places, alone in time attack lit from GO; `lampcheckpoint` 2 s at each time extension). 1969 pass with the pack.

### 16 November (evening, later): Initial D Zero automatic revs; thread wrapped up

* A Silvia story race (automatic) with five rev counter readings: the counter shows P+B04 x 0.885 with an automatic;
  `rpm` uses that. Third fixture; 1962 pass with the pack, 764 without. Her FFB feel (kicky, weak) is the game's own force;
  effects don't depend on it. The profile works under segatools v5 or TeknoParrot (same exe, game memory only).

### 16 November (evening): Initial D Zero v2.30 recordings

* Two recordings and her answers: `claude/ID0V230-capture-20261116.md`. Checked: speed, revs, gear, steering and drift
  signs, race clock, checkpoints, places, contacts, wall sides, gutter, leaves, landings, ripple strips, the tutorial's demos.
* Fixed (moregames `id0_rows`): automatic revs (`rpm_auto`, P+B04); `rev_limit`/`rpm_frac` removed (P+B18 is the gauge's
  10000); `steer` + right; `rumble_strip` from the game's vibration level 5 (Irohazaka's painted strips share the surface
  sound); `gap`/`leader` only against a rival; `race_clock` 0 through the intro; Max speed 220, Max revs 8140. commonrows: no
  Car_rpm_frac. Tests: two fixtures, `Id0Tests.Recordings`; 1954 pass with the pack, 764 without.

### 16 November (afternoon): Initial D Zero v2.30 from its exe

* The first game worked in its own thread (`claude/TPTelemetry-Working-in-sections.md`). From her
  `InitialD0_DX11_Nu.exe` (v2.30, 64-bit) and MasterRaver's table: `claude/ID0V230-exe-20261116.md`.
* **Exe helpers read 64-bit exes** (Tools: `dis.py` writes `base.txt`; RIP-relative operands absolute; 8-byte pointers in
  `rawref.py`, `vtables.py`, `rtti.py`; `const.py` reads zero-filled .data and `q:` values).
* **ID0V230** (moregames `id0_rows`, commonrows, gamesetup, pack README): the ID6 engine's structures at their 64-bit
  offsets, both slots and yours; race and car state, game mode, race clock, time left, checkpoints, gap, speed, revs, rev
  limit, gear, pedals, steering, drift angle, ID6's event bits, surface sounds; Car_ values as ID6's plus Car_rpm_frac,
  0 outside a race. The table's Stage_Tmr is now `time_left`; its two other reads `menu_timer` and `hud_meter`. Works the same
  under segatools and TeknoParrot. Not yet recorded. Tests: `Id0Tests.cs`; 1914 pass with the pack, 764 without.

### 16 November (second update): GRID and Sega Rally 3 built from her answers; GRID.exe again; SR3 recording

* Her answers: `claude/GRID-capture-20261112.md` and `claude/SR3-capture-20261112.md` (end sections). GRID's TT on screen
  is `race_clock`; no damage in the arcade build; `car_contact` counts other cars' contacts too. SR3: two false hits (a big
  slide, jitter after a landing); WRONG WAY shows when reversing facing forward; **zero all race data outside a race,
  only force feedback and lamps in the menus**.
* **GRID** (memgames GRID block, commonrows): race rows ticked; `clock_moving`, `racing` (1 if the race can't be read),
  Car_in_race = `racing`; `steer` (+ right, from `steer_in`); `lap`, `final_lap`, `lap_line`; damage rows removed; raw
  `place0`-`place2`, `me`, `players`, `my_car` (HUD +C0 → +4 list), `game_mode`; `position`, `leader`. Exe note
  `claude/GRID-exe-20261116.md` (time left in StateRaceCountdown +3C, checkpoints +E8; no chain; CE plan).
* **SR3** (`moregames.add_sr3` now replaces rows in place; commonrows): Car_in_race = `racing` (`valid(player_state, 3) ==
  3`); `checkpoint` not at GO or the start line; `position` held 0.1 s; `wrong_way` gated; `hit` (hand-maintained row, now
  carried by `add_sr3`): drop > 3 + 0.05 × max(0, -prev(slope(mph, 0.2))) and not within 0.7 s of airborne.
* commonrows: SR3 and GRID wrap every car_ row but car_in_race in `racing ? (...) : 0`.
* Tests: GridReplayTests (ticked rows, no damage, Car_in_race, zeroing, `Twelfth` on fixture `grid-20261112-120036`),
  Sr3ReplayTests (`Sixteenth` on fixture `sr3-20261116-102408`). 1870 pass with the pack, 764 without. Pack diff: GRID.json,
  SR3.json, README, Game_Setup, Game_Formulas only; a second run changes nothing.

### 16 November: GRID and Sega Rally 3 recordings of 12 November (analysis only; no code or pack change)

* **GRID** (`claude/GRID-capture-20261112.md`): GRID-1 (469 s: attract, menus, race 1 with the test plan to TIME OVER,
  race 2 finished 2nd) and GRID-2 (attract only). `race_on` = GO until the race is cleared; `race_over` at TIME OVER and
  1.1 s after her line; `race_clock` stops at the pause and at `race_over` (steps of 1/120 s, so repeated reads);
  `race_laps` 3, `race_cars` 6; `car0_laps` counts her laps; `car0_lap_time` is car 0's race time, held at its finish.
  **Car 0 is the player** (`veh_id` 0; the game takes her controls at car 0's third line). `brake` = the pedal (0.95);
  `steer_in` + left (USB steering, -0.93). Damage rows 0, `dmg_state` 7 everywhere. Attract mode: nothing moves.
* Proposed GRID Car_in_race: `race_on && !race_over && car0_laps < race_laps && maxw(delta(race_clock) > 0, 0.1)`
  (with `valid()`); replayed: GO to the pause, after it to TIME OVER, GO to her line; off in the attract file. To build
  with a `steer` row (+ right) and the damage rows' fate once she answers.
* **SR3** (`claude/SR3-capture-20261112.md`): SR3-1 attract, SR3-2 (race A automatic, timed out; race B finished 2nd),
  SR3-3 (wrong way, GAME OVER). **All recorded with the old SR3 profile** (no `player_state` etc.): she must Delete Game
  and re-import SR3.json. Her paired marks match `airborne` at every jump (it starts about 0.4 s after takeoff). At the
  line the car leaves the scene (speed to 0 in one sample) and the revs freeze (6,767; 6,934 after GAME OVER); the gear
  row cycles 2 to 6 in the menus. Gear -1 in reverse as well as before the driver's view.
* Questions asked (end of each capture note): GRID pause and finish TT, lap times, damage seen, car contact sides, RT and
  position (needs `GRID.exe`); SR3 finishing time, race B hit sides, reversing and WRONG WAY, SR3-3 and SR3-1 marks,
  and whether SR3's Car_speed/rpm/gear should read 0 outside a race as on OutRun 2.

### 12 November (12:40): Sega Rally 3 from its exe

* Alexis attached `Rally.exe` (`claude/SR3-exe-20261112.md`) while recording GRID. RTTI only for the physics library; the
  game's own classes are named by their log strings. Six car records (0x1F18) from `Rally.exe+5DBAC8`; car 0 is the player
  (the game reads car 0's state directly; the revs row was already car 0 +3BC).
* New rows (`moregames.add_sr3`, replaced each run): `player_state`, `time_left`, `checkpoints`, `lap`, `laps_total`,
  `position`, `wrong_way`, unticked `game_mode`; calculated `racing`, `finished`, `checkpoint`, `final_lap`, `leader`.
  commonrows: SR3 Car_in_race = `racing`, or 1 when the state reads outside 1 to 5. Pack README (SR3 section, game table,
  finish-line list), Game_Setup.
* Not found: surfaces, water, wheels on the ground (the physics has RTTI; the next step is the car object's path to its
  `CVehicle`); a motion-seat driver is in the exe but not traced.
* Sr3ReplayTests checks the addresses and that the 2 November recording still replays (Car_in_race 1 throughout). 1830
  tests pass with the pack, 764 without. Test plan (seven steps) at the end of the exe note.

### 12 November (11:50): GRID from its exe

* Alexis attached `GRID.exe` (`claude/GRID-exe-20261112.md`). No class names, but the commentary's 160 named facts and
  the HUD element names map the structures. The profile's chain bases (`B1B100`, `B1B7F0`, `41CA50`, and what follows
  `A3FA34`) are heap layout, not globals: they stay as checked.
* The dial (`B1B100 -> 200 -> 120`) is the HUD's `dialinterface`: +258 points at the player's car physics, +280 is the
  brake beside the throttle (+27C), +210 points at the HUD, whose +1F8 is the race; the race's +21A0 holds its race
  clock object at +F8 (running +10, finished +11, laps +14, clock +28 in microseconds, cars +60, 0xC08-byte car records
  from +68, end rule +F1B0).
* Rows: `brake` (ticked); unticked raw `veh_id`, `hud_mode`, `race_on`, `race_over`, `race_clock`, `race_laps`,
  `race_cars`, `race_type`, `car0_on`, `car0_laps`, `car0_lap`, `car0_lap_time`, `steer_in`, `dmg_radiator`,
  `dmg_engine`, `dmg_gearbox`, `dmg_state`. Pack diff: only GRID.json, Game_Formulas, Game_Setup and the README.
* Four exe helpers added to `exe/` (`fstart.py`, `regs.py`, `cowrite.py`, `vtables.py`). GridReplayTests checks the new
  chains. 1821 tests pass with the pack, 764 without. Test plan (one recording, eight numbered steps) at the end of the
  exe note.

### 12 November (11:15): OutRun 2 answers; redline light, hearts, attract mode; ready to migrate

* Cars: Testarossa (11 Nov), Enzo (10:05), 250 GTO (Time Attack), 512 BB (Heart Attack). Her video put the redline light
  at 8,260 to 8,270 revs on the GTO, BB and Enzo (2nd) and 8,370 on the Testarossa: `shift_light` now 8,270 for all. The
  game draws a dial per car (car +0A dial type, car +3C4 smoothed display revs, all scaled to 10,000), so per-car
  thresholds are possible if ever needed.
* `hearts` = value / 10,000 (172, 397: the challenge finishes), ticked; `challenge_won` 1 s pulse.
* OUTRUN2SP only: Car_speed, Car_rpm, Car_gear, Car_accel_g read 0 outside a race (she asked: like the effects, in the
  attract mode and menus). The plugin itself still publishes those four ungated for other games (dashboards).
* The 92.88 s straight rear-end reads as a right-side hit (same side code as a front-right hit). Observer 64: nothing
  seen; left unused.
* New fixture `or2-20261112-100900.csv.gz` (`Or2GameTests.Modes`). 1811 tests pass with the pack, 764 without. All
  files served for a new chat.

### 12 November (10:30): OutRun 2 test recordings; car-hit side from the game

* Two recordings (`claude/OUTRUN2SP-capture-20261112.md`): 10:05 OutRun with traffic hits and USB; 10:09 Time Attack,
  attract mode, Heart Attack. **Car hits and their side now come from the game**: contact words car +6C8/+6CC = right,
  +6D0/+6D4 = left (set for a moment at the hit); side code car +10DE bit 4 right, bit 8 left (held). New `car_hit`,
  `car_side`; Car_impact includes car hits, Car_impact_side = car side else wall side. Matched USB at every sided hit.
* `game_mode` 0 Time Attack, 1 OutRun, 2 Heart Attack, -1 menus. Time up ends `racing` (observer bit 1); attract mode
  reads `racing` 0 (Car_speed and Car_rpm still show the demo car; effects 0).
* `rev_limit` read 8,901 on all three cars (shared engine data, or not per car). Observer 64 comes 13 to 15 s into stage
  1 in every mode. Heart Attack's `hearts` rose 0 -> 1,720,000 -> 3,970,000.
* New fixture `or2-20261112-100526.csv.gz` (`Or2GameTests.Traffic`). Hit rows use `valid()` so older fixtures (without
  them) aren't affected. 1799 tests pass with the pack, 764 without. Five questions asked (end of the capture note).

### 12 November (morning): OutRun 2 rows for the next recordings

* From `jennifer` (second pass in `claude/OUTRUN2SP-exe-20261111.md`): the side code the game stores at every hit on
  another car (car +10DE, from `CheckWhichSideColiHappen2`) and the contact words its side check reads (+6C8 to +6D4);
  each car's rev values from its car data (+1068, probably the limiter, and +1030, through car +46C); the course event
  byte behind observer_flag 32/64 (0x0830B744). Added as unticked raw rows (`hit_dir`, `hit_box1`-`4`, `rev_limit`,
  `rev_1030`, `course_event`): recorded, not used. The replay tests skip rows whose notes start "Raw".
* Test plan (three recordings) at the end of `claude/OUTRUN2SP-capture-20261111.md`. 1786 tests pass.

### 11 November (21:32): OutRun 2 redline light and drift scale; ready to migrate

* `shift_light` (OUTRUN2SP): on from 8,380 RPM, where Alexis saw the dash's redline light come on (TT 0:07.375 in third;
  about 90% of Max revs 9300). From her video, not the code.
* OUTRUN2SP's Car_drift is full at 75 degrees (Alexis: this game only); every other game keeps its curve (pack diff
  checked: only OUTRUN2SP.json, Game_Formulas, Game_Setup and the README changed). `fork_sign` 3 s confirmed.
* 1786 tests pass with the pack, 764 without. All four archives and this handover served for a new chat.

### 11 November (night, 21:07): OutRun 2 answers

* Drift sign confirmed (+ right). Crash kind 7 = into the back of a truck or bus with the rear wheels lifting, kind 1 =
  flying and flipping off a wall: new `crash_air` -> Car_airborne (0.5 for 0.6 s, 1 through a flip). observer_flag 32 =
  the fork's "easy" arrow (`fork_sign`, held 3 s); 64 shows nothing. game_mode 1 = OutRun mode. Slipstream matches.
  SHIFT UP never shown (she never held the redline); the redline light is likely on the 3D dash, not in the HUD code.
  1784 tests pass.

### 11 November (late night, later): WMMT3DX+ car-hit sides; OutRun 2 recording

* WMMT3DX+: her answers on the traffic hits show slot 9's car-hit sign (59) is opposite to walls: -59 right, +59 left
  (front-right nudges and traffic right, a truck along the left). New `car_side`; Car_impact_side = wall side or else
  `car_side`. No further capture needed for it. The dial is printed to 9k but the needle tops out at the 8k mark.
* OutRun 2 (19:06, `claude/OUTRUN2SP-capture-20261111.md`): `racing` runs GO 34.18 s to the line 331.90 s; the HUD flag
  ran into the menus. `speed_kmh` = 1.018 x speed x 0.7: Car_speed is now the speedo (km/h, Max speed 280; the speed
  row converts to km/h). `crash_motion` now bits 1 or 2 (bit 1 alone was a frame); Car_impact 1 at its start, 0.5 s
  before the speed row falls. `drift_angle` 0 under 10 km/h. 15 drifts at 60 to 78 degrees (Car_drift saturates).
* Tests: `Or2GameTests` (new fixture) and car-side checks in `Wmmt3GameTests`; 1781 pass with the pack.


### 11 November (late night): WMMT3DX+ answers and a traffic recording

* Her dial readings matched neither revs row: the meter's needle is 0.96 x rev rate + 0.04 on a dial to 8,000
  (`Get2DInfoMeter`). New `tacho`; `rpm` stays the engine with Max revs 10000; `rpm_ce` gone. She calls the time left
  RT and the race clock TT.
* Effects start at the countdown (the driver's view), not in the story mode's pre-race movie (34 to 43 s), which sets
  race state 1 for 0.2 s with the countdown held at 4. `in_race` = state 2, or 1 with the countdown under 3.99, while the
  race clock or countdown moves (a pause stops it).
* Signs confirmed (slip angle and steering + right). Rival nudges were her front right. Wall sides from slot 9 were right
  (I had misread them). Crests are light, not airborne: `light` (Car_airborne 0.3), `airborne` after 0.25 s.
* Traffic recording (20:15): her first eight marks are road joints. The game's car contact flag caught all 14 car hits;
  slot 9 gives car hits 59, under the 63 the impact formula needs, so they were missed live. New `hit_car` from the
  contact strength (sqrt of +CC over 15,000) into Car_impact. Slot 9's sign on car hits isn't the wall rule; raw push and
  matrix rows (`carhit_*`, `wallhit_*`, `mat_*`) added to find the side.
* `Wmmt3GameTests` replays both recordings (new fixtures in the game's units). 1757 tests pass with the pack.

### 11 November (night): WMMT3DX+ recordings with the new rows

* Three recordings (`claude/WMMT3DXP-capture-20261111.md`). Old profile: a race (time left freezes at the finish
  line) and the attract mode (no race code runs). New profile (18:36, story mode, C class, Hakone inbound, manual):
  speed and gear match the old meter rows; race state 2 from GO (47.68 s) to the line (263.76 s); time left, race clock,
  rival gap and leader behave; story mode leaves the time keeper's sections at 2 (rows unticked).
* Revs: the game's engine revs read ~1,250 above the old row (9,560 top, limiter 10,000). Asked for the tacho.
* New `load` (car +AE4, the vertical load factor the game's wheel spring is worked out from) and `airborne`
  (`minw(seq_active && load < 0.375, 0.1)`) -> `Car_airborne`. The spring went to 0 only over crests and at her jump
  (252.30 to 252.84 s).
* `wheel_slip` note fixed (negative = wheelspin). `speed_ce` and `gear_ce` removed; `add_wmmt3` drops them from an
  existing profile.

### 11 November (evening, later): OutRun 2 SP from the game's `jennifer`

* `jennifer` (32-bit Linux ELF, MontaVista GCC 3.3.1, 2003) still has its full symbol table. The existing rows are the
  player's car record (`evwork_car` 0x08279DA0, 24 records of 0x10E0), `car_work` (`speed` +330, not the speedo),
  `navipub_disp_flg` (the `in_race` row: the HUD's navigation flag), `game_timer`, `iowork`. Full table in
  `claude/OUTRUN2SP-exe-20261111.md`; rows in `moregames.py` after the 2 November OR2 rows.
* New: `speed_kmh` (car +3B0, the speedo), `drift` (+DE6), `drift_angle` (+56, rear slip, sign to confirm),
  `slipstream` (+F18), `shift_warning` (+F2C), `crash_motion`/`crash_kind` (+4A4), `main_mode` (0x08303CF4: 15 GAME,
  17 GOAL, 18 TIMEUP, 3 attract), `game_mode`, `goal`/`time_up` (`observer_flag` 0x0830B740 bits 2 and 0), `racing`,
  `stage`, `race_time`, `stage_time`; unticked `front_slip`, `last_stage_time`, `hearts`, `paused`.
* Common values: Car_in_race = `racing` (so OutRun 2 now stops at the finish line, and not in the attract mode),
  Car_drift (ID6 weighting) and Car_drift_angle; no car_grip_loss row (the plugin falls back to Car_drift).
* The wheel force stays with USB capture: the game drives the deluxe cabinet's wheel with coarse presets from the front
  slip angle (`DrCtrlDataSet`), not a usable signal.
* `Or2ReplayTests` feeds the old recordings' HUD flag in as main sequence 15: same results, 1737 tests pass.

### 11 November (evening): WMMT3DX+ from the game's `main`

* Alexis attached `main` from her WMMT3DX+ install (32-bit Linux ELF, EXEC, run by BudgieLoader at its own fixed
  addresses). **It keeps 61,106 named symbols**, so every global has a C++ name. Full table and evidence in
  `claude/WMMT3DXP-exe-20261111.md`; rows in `moregames.add_wmmt3`, common rows in `commonrows.py`.
* The car is `yt::CSeq::pMachine` (0x098138E4): +AE0 speed mm/s (x 0.0036 = the speedo), +2CC engine rad/s (x 60/2 pi),
  +300 gear (-1 R, 0 N), +2C4 -> +8C the car's limiter, +344 boost bar, +340 -> +44 the car's full boost, +368
  blow-off, +39C backfire counter, +AF8 slip angle (int16, 65536 a turn), +AFC wheel slip, +D4/+90 wall and car contact,
  +970 odometer mm. Controls `pIO` 0x098138E0 (+4 throttle, +8 brake, +0 steering flipped). Race state
  `yt::CState::eState` 0x09813A78 (2 = Run; 7 GoalWait from the finish line; 4 when the time runs out). The cheat table's
  "GTimer1" is `fTDec_Rest`, the time left (row renamed `time_left`). Time keeper 0x098138C8: race clock, sections.
* The old cheat-table rows were a copy of the HUD meter in BudgieLoader's memory (hence moving with TP updates); kept
  unticked as `speed_ce`, `rpm_ce`, `gear_ce`. `CSeq::End` frees the car without clearing the pointer: car rows are gated
  on `seq_active` (`CSeq::bIsInitialized`, 0x09813970).
* Common values: Car_in_race (race state 2, so WMMT3DX+ now stops at the finish line), Car_boost (turbo / full boost),
  Car_rpm_frac (the car's own limiter), Car_throttle, Car_drift and Car_drift_angle (ID6 weighting, to tune). Hits,
  walls, joints, grip loss and cornering stay on the checked TeknoParrot-slot formulas.
* `Wmmt3ReplayTests` now feeds the 1 November recordings into the new rows in the game's units and checks they match
  the old rows, with in_race on throughout. Pack README (WMMT3DXP section rewritten, finish-line list), Game_Setup.

### 11 November (late afternoon): Mario Kart recordings: Mario cup (v1.18), Bowser Jr cup (USA); finish-line rule

* v1.18 Mario cup course 1 (14:20, four laps, won) and USA Bowser Jr cup courses 3 (14:33) and 2 (15:12): place, laps and
  race time read in both versions (place is the HUD's, once a second; the game's clock is 16 ms a frame, 0.96 of real
  time). New fixtures and replay tests (`Mk118Tests.MarioCup`, `MkUsaTests.cs`). A 14:28 recording used the wrong profile.
* Her surfaces: Mario cup 0 rebound-ace road, 11 its verge, 13 glass, 10 boost rings, 14 sand, 12 pavement; Bowser Jr cup
  8 floorboards, 15 cloud, 5 checkerplate, 9 carpet, 2 metal grille (rumble strip), 0 boost ramps. `off_road`: verges and
  sand 1, planked bridge 0.5, wood 0.3 (her choice), else 0.
* Kart states 6 (item flip), 7 (bomb blast) and 11 (tumble) are spins; `hit_side` only in states 0 and 3, away from spins,
  threshold 0.06: all her left/right hits in the 15:12 race read right.
* The USA item lamp flashes: `item_held` bridges 0.25 s.
* **Finish line (Alexis: for all games):** BG4JP's Car_in_race now ends at race phase 8; the README lists which games stop
  at the line (GTI Club, ID6, BG4JP, both Mario Karts, SWDC, WMMT5DX+, Model 2 STCC and Sega Rally) and which need a
  recording through the finish (OutRun 2, Sega Rally 3, WMMT3DX+, Model 2 Daytona, GRID). Lamps checked: no profile ties a
  lamp row to racing, and the plugin never gates outputs.

### 11 November (afternoon): MKGPDX118 answers, v1.18 exe, attract recording

* Her answers (`claude/MKGPDX118-capture-20261111.md`, new section): Max speed 160 and Max revs 10000 set in both Mario
  Kart profiles. Surfaces on course 1 of the Donkey Kong cup: 3 yellow dirt road, 4 grassy verge, 7 water, 8 wood
  (mine-cart platform, ripple logs), 10 planked bridge, 12 tessellated pavement, 13 jungle floor; `off_road` grades them
  (grass/sand 1, bridge 0.5, wood 0.4, jungle 0.25). The three unexplained shakes were kart hits; new `hit_side`
  (Car_impact_side) from the knock to the slide against the 0.3 s before the hit, 0 in or just after a drift. The odd coins
  were real.
* v1.18 exe (same file as 9 November): place `8, CC, 1D4`, laps done `8, CC, 1E4` (both off `<main>+AAEEA0`), laps in the
  race `<main>+AAEE7C` `4, 10`, race time ms `<main>+AAEEA0` `4, 2C`; USA equivalents in its note. New `position`,
  `laps_done`, `laps_total`, `race_time`, `lap`, `final_lap`, `leader`, `place_gained`, `place_lost` in both profiles.
  Drift meter stage and LED digits still not found (`claude/MKGPDX118-exe-20261111.md`).
* Attract recording (menus only): the play demo runs race state 1, 4, 5, 6, 9 like a race, but the FFB plugin's in-race
  flag stays 0, so `racing` already keeps SimHub effects off until a real race, as she asked. Planks read terrain 8 with no
  force texture.
* Tests: Mk118Tests.cs checks hit sides, surfaces, Max speed; MemProfilesTests the new chains and the attract gate.

### 11 November (midday): MKGPDX118 recording

* Alexis's 10:57 recording (`claude/MKGPDX118-capture-20261111.md`, 48 marks, two laps of a 100cc Grand Prix race).
  Race state 6 = racing (GO to the line); the FFB plugin's in_race drops a sample at the lap line. **Kart +BC8 (the FFB
  plugin's force) is the sine of the drift angle**, as the USA code showed for its +2FC: new `drift_angle` (+ right) and
  `drift_strength` (ID6 weighting, gated by the drift flag) feed Car_drift. kart_state: 1 hop, 2 drifting, 3/5/10 item
  hits, 17/18 kite, 22 grid. `item` was the button lamp byte (bit 4 = item held). coins counts coins. Ripple strips flick
  terrain 3/8. Road reads 3 ("dirt"). Lamp words are LED colour levels.
* Both Mario Kart profiles get the new rows (`_mk_derived` in memgames.py); USA drift_angle sign flipped to match.

### 11 November (late morning): Mario Kart GP DX USA from the exe

* Alexis's USA `MK_AGP3_FINAL.exe` (7,033,856 bytes, built 8 November 2016, `USA1FF01`): the build the FFB plugin's USA
  addresses fit. Same structures as v1.18 at other addresses (`claude/MKGPDXUSA-exe-20261111.md` has the table): car list
  `<main>+B47B48` (+8 the kart), kart +958 speed, +95C revs, +29C slide, +34C state, +6B0 flags, +A8 physics; sound manager
  `<main>+B4F324` (+628 terrain, +658 on ground, +674/+676 drift and side); race manager `<main>+B47B28` (`38, C`, same states).
* **Kart +2FC (the FFB plugin's USA force) is the sine of the slide angle** (sideways axis . travel direction): new row
  `drift_angle` (degrees, side to confirm). So in USA `force`, and the car_cornering/car_road_bump stand-ins built on it,
  follow the slide, not a road force. v1.18 probably has the same field; needs its exe again.
* The I/O block is v1.18's moved up 0xCF880 (item and the shake word both land exactly), so the USA profile now reads
  v1.18's lamp words there (`fix_mkusa_lamps`): lamps without OutputBlaster, which has no USA build.
* The 4 November recording's empty rows: the addresses are right for this exe, so TP Telemetry was reading another
  `MK_AGP3_FINAL.exe` process; 0.18.1's newest-process rule should fix it.

### 10 November: ID6 drift weighting; BG4JP recordings; plugin 0.18.1

* **Plugin 0.18.1:** opens the newest process with the game's name, and moves to a newer one within 3 s if it starts
  while attached. BG4's stopped game.exe hung on and recording 5 (19:42) was read from it, frozen; probably the first
  recording's zeros too.
* **BG4JP nitro:** wall_contact bit 2 is a nitro burning (7 s), not rough ground: `boost` (Car_boost) from it, no
  Car_off_road. Finish: race phase 8 for a frame at the line, 9 rolling to a stop, 0 about 9 s later. Reverse is gear -1.
  Max speed 200 (Alexis). Details in `claude/BG4JP-capture-20261110.md`.
* **BG4JP Brake! confirmed (11 November, 08:56):** the car navigation's sign trigger came before every Brake! mark;
  `brake_warning` holds 1.5 s; `corner_ahead`, `corner_side`, `corner_sharpness` from the curve codes she named (1 hairpin R,
  2 medium R, 4 hairpin L, 5 medium L, 9 slight L, 6 snake L-R-L, 48 snake R-L). Second replay fixture.
* **BG4JP recording 8 (21:47) and Brake!:** wall bit 2 = the nitro, confirmed against the game's nitro timer. Brake! is
  the car navigation's second sign (`<main>+4B1758` → 3C → 48/4C; curve markers at +40/+44): `brake_warning` now reads
  it, to confirm in a recording. Recording 7's freeze was her pause. Her answers: every drift I flagged was a real slide.
* **BG4JP recording 7 (20:58):** drift angle from car +D0/+D8 (heading) against the position's slope (+ right-hand,
  following the wheel): Car_drift (ID6 weighting), Car_drift_angle, Car_grip_loss = max(drift, wheelspin). A second
  freeze (14 s): new `live` row gates racing and Car_in_race. Time up is race phase 11. Brake! is not car +CCC (the
  automatic brake assist, off for her); still to find. Replay test `Bg4Tests.cs` with its fixture.
* **MKGPDX118 second pass:** `race_state` (`<main>+AAEE80` → 38 → C; 6 = race; the attract demo uses it too), and
  unticked position and physics-vector rows for a drift angle. See `claude/MKGPDX118-exe-20261109.md`.
* **BG4JP recording 6 (20:38, with 0.18.1):** time_left (+60 s at the checkpoint) and lap (laps completed) checked;
  ground bit 128 = wheelspin (Car_grip_loss); Brake! = car +CCC bit 2 from the HUD code (`brake_warning`, not yet seen
  live); raw position and matrix rows recorded for a drift angle. Alexis says recording 2 had no nitro, though bit 2
  ran 7 s twice: asked her.

* **ID6 Car_drift reweighted (Alexis):** `(1 - (1 - x)^2) x sqrt(s)`, x = (|angle| - 5) / 45, s = (km/h - 20) / 80, both
  clamped 0 to 1. More weight on the angle, less on speed (full from 100 km/h now, still nothing under 20). Her four marked
  drifts replay at 0.48, 0.76, 0.85, 0.84 (her targets 0.5, 0.7, 0.84, 0.85; a product of an angle part and a speed part
  can't split her 39 and 50 degree hairpins at the same speed any further while keeping mark 5 at 0.84).
* **Keep this drift weighting in mind for the other Initial D games (Alexis, 10 November):** when ID4, ID5, ID0 or IDTA
  get a drift angle, start from the same curve (5 degree dead zone, full at 50, eased; speed from 20, full at 100, square root).
* BG4JP: the first recording read 0 everywhere (another `game.exe` was open); the second (15:08, Golf GTI) is checked
  (`claude/BG4JP-capture-20261110.md`): speed, revs, gears, positions, race phases (6 countdown, 7 racing), wall bits
  16/32 hit and 64/128 scrape, car bits 1 front, 2 right, 4 rear, 8 left. in_race stays 1 in the menus after a credit
  stops the attract demo, so Car_in_race needs `view != 12`. New rows `racing`, `contact`, `wall_touch`; Max revs 8000.
  From the exe: `time_left` (`<main>+4B1758` → 34 → 1C frames), `checkpoint`, `lap` (session +984), nitro (car +290 shots, +294 frames burning: `boost`); phase 8 finish, 10 time up.

### 9 November (night): Mario Kart GP DX v1.18 from the exe

* From Alexis's `MK_AGP3_FINAL.exe` v1.18 (`claude/MKGPDX118-exe-20261109.md`). The player's kart is
  `[<main>+AAEEA0]+8` (`clPlayerCar`): +AC4 speed, +AC8 engine revs (both what the engine sound follows), +3BC a signed
  slip value (0 while gripping; the drift flag is it not being 0), +48C state, +810 flags. `<main>+AC2A30` is the sound
  manager, not the kart: its +580 (the FFB plugin's speed) isn't a field the game fills, so it is kept unticked as
  `speed_snd`. `item` (+AC5C0D) is a JVS packet byte; `coins` has no code references.
* MKGPDX118 rows: speed and rpm from the kart, `drift_side`, unticked `slip`, `kart_state`, `kart_flags` for a capture;
  OutputBlaster's two lamp words read as Int32 (it reads a byte and tests bits up to 0xF0000000). Not yet recorded.

### 9 November (afternoon): two more ID6 recordings; plugin 0.18.0 (Car_drift)

* **Plugin 0.18.0:** common values `drift` and `drift_angle` (Car_drift 0 to 1, Car_drift_angle raw degrees, + pointing
  right of the path); Car_grip_loss falls back to the drift where a game has no grip_loss row (Alexis's choice); effect
  TP - Drift on seat shakers and motors (re-create and re-import the effect profiles). MKGPDX feeds car_drift.
* **ID6** (`claude/ID6-capture-20261109.md`, second half): Trueno (limiter 8140 again, screen reads 8k; 215 km/h) and a
  Civic time trial on Irohazaka. Max speed 220 (Alexis). Leaves (0x400), landings (0x100, latched: start only), guard rail
  right; ripple strips from the game's vibration level 10 (bit 0x200 never set). in_race works in time trial.
* **ID6 drift from the exe** (attached 15:05): physics P+7C4 is the drift angle (body yaw less travel direction, radians);
  `drift_angle` row in degrees, car_drift_angle and car_drift feed Car_drift and Car_grip_loss.
* **ID6 drifting recordings (15:23 RX-7 Akina, 15:43 Impreza Irohazaka wet):** sign confirmed (+ right-hand drift);
  car_drift = clamp((|angle| - 5) / 45) x clamp((km/h - 20) / 100) (speed weighting: Alexis, full from 120 km/h, none
  under 20). Hairpin drifts at about 70 km/h read 0.4 to 0.5. Her 15:43 mark 7 "left" read right (angle and steering): asked.
* Lesson: when a needed file is promised but not attached, stop and ask for it before carrying on; and a question to
  Alexis should say what to do, not only ask.

### 9 November: ID6 recording; plugin 0.17.2

* **Plugin 0.17.2 (bug fix, all games):** formulas with a window (`maxw`, `minw`, `avg`, `slope`) stuck after the game
  attached if the profile had been waiting for it: the clock restarted at 0 while the windows kept samples from the
  wait. In the ID6 recording `hit` read 1 for 32 s, `shift` 44 s, `accel_g` froze, so Car_impact read 1 throughout.
  Now the clock carries on at attach and a backwards clock restarts the formulas' state (TelemetryEngine `KeepClock`,
  `RestartSeries`; RemoteTests). Earlier analyses replayed raw reads, so their findings stand; live effects in SimHub
  were wrong for as long as the game had been waited for.
* **ID6** checked (`claude/ID6-capture-20261109.md`): speed (speedo, 1.5 km/h), rpm (the screen's revs; rpm_tacho is
  1.08 x rpm, not the screen), gear, brake (P+230), lamps, slot 0 in story. Max speed 240, Max revs 8140 (R32 GT-R
  limiter). Event bits 0x1/0x2 are the gutter (left/right), not drains; `hit` merges touches under 0.15 s apart (a
  grind is one hit): 17 contacts, each once. `countdown_live` (rolling start with live revs) feeds Car_in_race.
  Car_vibration scaled / 0.15. No drift, time left, laps or position yet.
* **Battle Gear 4 Tuned (BG4JP), from her game.exe** (`claude/BG4JP-exe-20261109.md`): checksum 0xBAFACA7B (the
  Tuned build the FFB plugin supports). Car records of 0x1BE0 from `<main>+42EA90`: +24C speed (speedo), +254 engine
  revs, +260 gear (Int32, -1 reverse: the old Byte row read 255), +18C position. New rows speed (speedo), rpm,
  race_phase, position, leader, my_car; the FFB plugin's speed kept as speed_ffb. Not yet recorded.
* gamesetup CHECKED now marks GTICLUB3 (missed on 8 November) and ID6. The pack README's checked-games line lists GTI,
  ID6 and the three Model 2 games.

### Plugin 0.17.1 (SimHub profiles)

* Effect profiles are written under SimHub's own names: `Any Game - TP Telemetry.siprofile` in `Bass Shakers\` and
  `Motors\` subfolders (old file names deleted). SimHub 9.13.3 refused the old ones.
* A note beside the button (and in SimHub_Effects.md): the profiles are for the whole plugin, made once per kind of
  hardware, not per game.
* Copy Commandlines: SimHub has no command for choosing a ShakeIt profile, so there is no third line (a note says so).
* 8 November: Game_Outputs.md's Model 2 section now explains which games' lamps OutputBlaster can see (Daytona only)
  and that no TP Telemetry Lua scripts are needed. No code change.

### MKGPDXUSA (4 November)

Analysed and parked ("forget MKDX for now"). Notes in `claude/MKGPDXUSA-capture-20261104.md`. Picked up again on
11 November from the exe (above).

### Model 2 Emulator (4 to 8 November)

emulator_multicpu.exe 1.1c, 32-bit. Any game address: Base `1AA8F4`, Offsets `<(A >> 16) * 16>, <A>` (page table;
e.g. `200, 202094`). `1AA888, 100, <offset>` reaches only work RAM at 0x500000. Notes per game: `M2STCC-20261104.md`,
`M2STCC-capture-20261105.md`, `M2STCC-capture-20261106.md`, `M2SRALLY-rom-20261108.md`, `M2DAYTONA-rom-20261108.md`,
`M2-captures-20261108.md` (Daytona and Sega Rally, with updates through the day).

* **STCC** (`M2STCC`): speed, engine revs (Alexis wants engine revs, not tacho), tacho revs, gear, race time, laps,
  time left, `checkpoint` (TIME EXTENDED timer), surfaces per wheel (kerb, grass), slip, airborne, wall hits (no side),
  lamps. Max speed 320, Max revs 12900. Checked in RAM logs of 5 and 6 November and recordings.
* **Daytona USA** (`M2DAYTONA`): speedo km/h, tacho revs, gear (0x5052CC + 1; manual and automatic), race time, lap
  time, last lap, laps, `checkpoint` (TIME EXTENSION, 2 s), surfaces per wheel, squeal (grip_loss), `hit` (walls and
  side-on contact; rear bumps only in the force), position (0 outside a race). Max speed 340, Max revs 8500.
* **Sega Rally** (`M2SRALLY`, srallyc): race state, speed (x 64 km/h), engine revs (8800 limiter; tacho = / 1.1), gear
  (manual and automatic), total and stage time, time left, `checkpoint` (from the time left jumping up during a race),
  position, `leader` (position 1, for a lamp), surfaces per wheel (0 tarmac, 2 dry dirt or sand, 3 wetter dirt,
  6 grass verge, 9 tarmac in the Forest tunnel), wheels on the ground and airborne, slip and grip_loss, `hit`
  (signed: + right, - left; holds the last value, so `hit_now` takes a change as the hit), rumble commands as
  vibration. Max speed 240, Max revs 8800.
* **Lamps:** Daytona's own emulator script moves its lamps to RAM+824 (where OutputBlaster's regular build and the
  lamp rows read). STCC and Sega Rally build a lamp byte in their own RAM (STCC 0x20B2E4, Sega Rally 0x20204C) and
  write it, with two input-select bits, to I/O port 0x01C0000A; the emulator keeps that port's last value at
  **exe+174CF0** (port handler 0x4C870C: port 0x0A -> 0x574CF0, port 0x08 -> 0x574CF4, Sega Rally's drive board).
  Alexis's special STCC build of OutputBlaster reads exactly that (Int32, bits 4 start, 128 leader, 8/16/32/64 view
  1-4) and lights her STCC leader lamp through MAMEHooker (serial to an Arduino Pro Micro), so the profiles' `rawlamps`
  read `<main>+174CF0` for both games. Sega Rally never lit a lead lamp, even leading in practice: its `leader` row
  (position 1) is the lead lamp. Her MAMEHooker STCC ini maps only LampLeader.
* **No TP Telemetry Lua scripts are needed.** The RAM logger (`tptram.lua`, kept in `claude/tools/` for future value
  hunting) and the per-game wrapper scripts are retired: Alexis keeps each game's own emulator script.
* **Credits:** ElSemi, SailorSat and Vincerplay (Model 2 Emulator and its scripts), in the pack README.

### GTI Club Supermini Festa (8 November, 17:30)

Alexis's CT plus a read of `gti3japkey.exe` (fixed base, not packed): `claude/GTICLUB3-exe-20261108.md` (addresses,
CT verdicts) and `claude/GTICLUB3-pack-20261108.md` (rows built, tests, what her first recording should settle).
GTICLUB3 now has speed, true speed, engine and tacho revs, gear, race state (game's own state names; in_race = 5),
time left, checkpoint, position, laps and lap times, surfaces per wheel, hits, car contact; Max revs 7500 (the game's
limiter). Car pointer `<main>+67FCC8` is stale between races, so car rows are gated by race state.

**Her recording (8 November, 20:30 revision):** `claude/GTICLUB3-capture-20261108.md`. Speed (always km/h, even with
the mph display), revs, tacho, gears, positions, laps and the finish all checked. Fixed: `time_left` now reads the race
display `[<main>+680460]+2C4` ms (the old address was the variety modes' timer; still to check), `in_race` ends at
`finished` (the game auto-drives in state 5 after the line), Max speed 160. Events now come from the game's jolt level
(pattern 15): 50 `landing` (Car_road_bump), 36 `car_hit`, 63 `crash`, 10 to 27 a wall or a kerb mount. A kerb mount
comes with a wheel already on the kerb, so `wall_hit` = a 10 to 27 jolt with no kerb under any wheel in the last 0.1 s
(`wall_jolt`), or one losing more than 8 km/h in 0.3 s (20:50 revision, after Alexis confirmed 99.42 s was her front
right into the RHS wall with no speed lost, and 148.20 s her rear right onto the LHS kerb); `hit` (Car_impact) = 1
crash or 0.5 + loss / 60. The countdown runs at 0.9 game seconds per real second and each checkpoint adds 16 s. `kerb` (surface code 2) feeds
Car_rumble_strip. No hit side found. `contact_timer`/`car_contact` removed (always 0).

### Initial D Arcade Stage 6 AA (8 November, 20:10)

From `InitialD6_GLW_RE_SBUU_dump.exe` (v1.2, no CT): `claude/ID6-exe-20261108.md`. ID6 (hand-maintained; rows from
moregames.py `add_id6`) now reads speed, engine and tacho revs, gear, pedals, race state (cRace+4, racing = 4) and the
car's event flags (walls and guard rails by side, car contact, landings, road joints, rumble strips, gutter, drains)
through `<main>+C6E210` -> race +20C -> car slot by the player's slot (+34); both slots read, the player's picked.
Lamps read memory for v1.0 and v1.2; other memory rows read 0 off v1.2 (build stamp check). Not yet recorded.

