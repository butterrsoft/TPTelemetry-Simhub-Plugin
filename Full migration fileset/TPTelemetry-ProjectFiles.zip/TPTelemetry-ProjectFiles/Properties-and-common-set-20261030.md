# SimHub properties: when they exist, when they read 0, and a common set (30 October 2026)

Checked against plugin 0.11.0 source (TPTelemetry.cs, TelemetryEngine.cs, Expressions.cs, NetOutputsClient.cs) and the pack (47 profiles, 853 ticked rows). Updated 31 October for plugin 0.12.0 (no Enabled box; Max speed / Max revs).

## When properties exist

* Every profile loaded (every file in `PluginsData\TPTelemetry\Profiles`) gets a SimHub property for each ticked row, `TPTelemetry.<PREFIX>_<row>`, whether or not it is or has ever been the active game. `Engine.Load` builds all profiles and `AttachProperties` attaches every ticked row.
* (0.11.0 only) A profile with its Enabled box unticked still published its ticked rows (reading 0); only `<PREFIX>_Connected` was left out. 0.12.0 removed the box and switches every profile on.
* A profile that isn't imported has no properties. Importing, adding or ticking a row adds the property at once.
* SimHub can't remove properties at runtime: deleting a profile, renaming a row or unticking it leaves the old property until SimHub restarts, reading null (blank), not 0.
* Global properties: `FFB_*`, `TP_jvs0-15`, `TP_connected`, `ActiveGame`, `SelectedGame`, `Recording` always exist. `Output_<name>` appears only once that output has been received since SimHub started.

## When a value reads 0 (other than a real 0)

The property delegate returns 0 whenever the row's value is NaN or infinite. That happens when:

1. **The profile isn't the active game.** Inactive profiles aren't evaluated. Changing the active game rebuilds every profile, so the previous game drops to 0 straight away rather than freezing.
2. **The game isn't attached:** process not running, 64-bit helper still starting, or helper failed (retries every 10 s). Memory rows are NaN; rows built on them mostly give NaN, so 0.
3. **The game exits:** all rows reset to NaN and time-series state restarts.
4. **A single read fails:** a null pointer in the chain, an unreadable address, or a module not loaded yet. Common in menus and before a race for pointer-chain rows.
5. **The row has a configuration error:** bad formula, reserved or duplicate name, refers to itself, depends on a row with an error, or a computed row with no formula. Stays 0 until fixed.
6. **The formula gives NaN or infinity:** division by zero, sqrt of a negative, log(0); `hold()` before its condition is first true (the pack wraps these in `valid(..., 0)`); `ema`, `slope`, `minw`, `maxw` fed NaN.
7. **A non-memory source is missing:** `tp_` rows with no TeknoParrot shared memory; `ffb_` rows with USB capture off or no commands decoded yet; `out_` rows until that output has been received since the last `mame_start` (which clears all outputs).
8. **Any settings change** (edit, tick, import, active game change) rebuilds every profile: values are NaN for one tick and every time-series function loses its history. Rows held with `hold()` (Sega Racing Classic, Daytona, Initial D force and spring) read 0 until the game next sends that command.

### Cases that read non-zero when 0 might be expected

* The formula engine treats NaN as true in `!=`, `&&`, `||` and the `?:` "else" branch gives a number, so some rows read 1 while the game isn't attached: `RF3D_active` (`ffb3 != 0 && ffb4 != 0`) and `DAYTONA3(NSE)_mirrored` (`... ? -1 : 1`).
* Profiles with no process (CRAZYTAXI, DEADHEAT, FORDRACING, ID6) report `_Connected` = true whenever they are active.
* TeknoParrot shared memory keeps its last values after a game exits (seen on WMMT3DXP capture 2), so `tp_` rows of an active profile can hold stale non-zero values.
* Outputs aren't cleared at `mame_stop`, only at the next `mame_start`, so lamps hold their last state between games.
* WMMT3DXP `grip_loss = clamp((1 - tp_spring) / 0.3, 0, 1)` reads 1 whenever TP is connected and slot 6 is 0 (before the race, or the slots aren't in use).

## Per-profile names and a common set

Every row is published under its profile's prefix only. There are no shared names, so a SimHub effect needs one property per game. A summed formula across prefixes works today (inactive profiles read 0) but is fragile because of the exceptions above.

Proposal (not built yet): the plugin also publishes a fixed list of common properties (say `TPTelemetry.Car_<name>`) taken from the connected profile's row of the same name, 0 when nothing is connected. Profiles opt in simply by having a row with that name, and must follow the agreed units and ranges.

### What the pack already has (ticked rows, by profile count)

* FFB family: force, force_abs, force_smooth, force_kick (34); spring (22); vibration (18); friction (7).
* Car state: speed (15), rpm (12), accel_g (12), gear (10), steer (4), race state as in_race (5), racing, playing, game_state.
* Hits: impact_side (11), impact (7), wall_contact (7), crash (2), hit, collision, car_hit, car_bump.
* Surface: rough_ground (4), rough, off_road, road_rumble, road_bump, road_joint (6), rumble_strip (6), terrain, in_water.
* Grip and air: grip_loss (8), skid, drift, cornering; airborne (6), landed (3), on_ground.
* Other: shift (2), boost (4).

### Naming and scale clashes to fix first

* `impact` is 0/1 on WMMT3DXP but signed -1 to 1 on WMMT5/6.
* `impact_side` is a ±1 flag on OUTRUN2SP, BG4JP and CRAZYTAXI, graded (hit_strength / 8) on GRID, and about ±0.5 to 0.78 on WMMT5/6.
* Rough surfaces have six names.
* **Speed:** units known only on WMMT5/6 and OUTRUN2SP (km/h) and probably BG4JP; unknown on MKGPDX, CRAZYTAXI, GRID, D1GP, SRG. Top speeds differ hugely between games (GTI Club vs F-Zero). The pack's speed rows come from the FFB Arcade Plugin's source, not OutputBlaster (OutputBlaster only has a speedo for H2Overdrive, via a hook).
* **rpm** (fixed in the pack 31 October): OutputBlaster sends RPM / 100 (DAYTONA3, DAYTONA3NSE, SEGARACINGCLASSIC, SR3, GRID truncated) and RPM / 10 (OUTRUN2SP). The pack's rpm rows now undo that and give real RPM, divided by Max revs.

### Speed and revs: done in plugin 0.12.0 (31 October 2026)

Alexis chose to normalise on the rows themselves: each profile has **Max speed** and **Max revs** boxes (formulas: `max_speed`, `max_revs`; blank = 1, minimum 1). The pack's `speed` rows are `value / max_speed` and `rpm` rows divide by `max_revs`, so they publish raw values until the boxes are set and 0 to 1 after. `accel_g` uses `speed * max_speed`. The separate `speed_frac` / `speed_kmh` idea below is superseded for now; a common `Car_` layer is still only a proposal.

### Speed and revs (direction discussed, 30 October 2026)

Alexis's concern: raw speed and rpm can't be common, because ranges (and mph vs km/h) differ by game and would throw off SimHub NCalc formulas. Approach discussed (she likes the "frac" values):

* **For effects and formulas, publish fractions:** speed / a fixed per-profile reference top speed, and rpm / redline, 0 to 1. Units cancel out. A fixed reference is preferred over a learned "highest seen" value, which would start low and over-read early in a session. On WMMT the redline varies by car, so one reference is approximate (fine for scaling effects).
* **For dashboards only, absolute values:** published only where the units are confirmed.
* **accel_g** stays common (G is comparable between games) but is computed from speed assuming km/h, so it's wrong wherever speed isn't km/h; it needs the same unit check. Effects should clamp it.
* Many speed-scaled effects may not need speed at all: on WMMT5DX+ the game's own joint kicks already grow with speed.

### Suggested common set

* Car (effects): speed and rpm with Max speed / Max revs set (0 to 1), gear (1 = first), accel_g, in_race (0/1).
* Events: impact (0 to 1, unsigned, held at least 0.15 s), impact_side (-1 to 1), wall_contact (-1/0/1, sustained), road_bump (0 to 1, short bumps and joints), rough_road (0 to 1, sustained rough surface or off-road), rumble_strip (0/1), grip_loss (0 to 1), airborne (0/1), landed (pulse), shift (pulse), boost (0/1).
* FFB: force, force_abs, force_smooth, force_kick, spring, vibration (already consistent because one generator writes them).

### Testing

Names show what exists; only recordings show whether a value means the same thing at the same size in each game. Only WMMT5DX+ and WMMT3DXP are verified. A standard calibration drive per game (idle on the grid, run through the gears to top speed, rough ground or joints, a wall each side, a car hit, a jump if the track has one, then quit to menu) with markers would check every common row in one recording, plus menu and post-exit behaviour. The run to top speed and the limiter also gives each profile's Max speed and Max revs, and the units, if Alexis notes the speedo reading at a marker. Alexis plans more testing.

## OutputBlaster RPM: public record

* OutputBlaster's public GitHub release notes for version 0.10 (17 November, year not shown; between the 2023 commits and the July 2024 v0.11 build) say "Added RPM to" Daytona Championship USA, its New Season Edition, Sega Rally 3, OutRun 2 SP and GRID. Commits: Sega Racing Classic 2022-11-23 ("Updates"), Daytona/SR3/OutRun 2 2023-04-06 ("add some RPM", "SR3 RPM"), GRID 2023-09-08, H2Overdrive outputs (incl. speedo digits) 2023-11-11. So RPM was public, though not in the README.
* Before TP Telemetry, these reached users as Windows messages (OutputsSystem=0) for MAMEHooker (or other output listeners), which could map the RPM value to a serial or Arduino device (gauge, shift light).

## Switching emulators from MAMEHooker to network outputs (for TP Telemetry / SimHub)

Now written up for users in the plugin's Game_Outputs.md (0.12.0). Plugin: outputs always on, 127.0.0.1:8000. It reads MAME's network protocol (`name = value` lines ending CR or CR LF; `mame_start`, `mame_stop`, `pause`).

* **MAME:** in mame.ini change `output windows` to `output network`. MAME runs its own TCP server on 8000 (CR line endings). No OutputBlaster needed. MAME uses one output provider, so MAMEHooker stops receiving outputs (bridges exist if both are needed).
* **Supermodel:** `-outputs=net` (values none, win, net; checked in trzy/Supermodel Main.cpp). Supermodel.ini keys: `OutputsTCPPort` (default 8000), `OutputsUDPBroadcastPort` (8001), `OutputsWithLF` (default off; CR is fine). No OutputBlaster needed. Older builds without network support reject `net`. Supermodel also sends a `tcp = 8000` line after `mame_start`, which will show up as an `Output_tcp` property (harmless).
* **Model 2 Emulator (M2Emu):** outputs come from OutputBlaster (its M2Emulator game file detects the game by window title; lamps only). Set `OutputsSystem=1` in that folder's OutputBlaster.ini (keep `NetOutputsTCPPort=8000`, `NetOutputsWithLF=0`).
* **TeknoParrot:** OutputBlaster.dll (v0.11 x64 for 64-bit games) plus OutputBlaster.ini with `OutputsSystem=1`, and Enable Outputs in TP. Most pack profiles now read lamps from memory, so this is only needed for the 49 leftover `out_` rows.
* Only one program can serve port 8000 at a time; fine with one game at a time.
* Output names: Supermodel and OutputBlaster share names (LampStart, LampView1...), since OutputBlaster's output code came from Supermodel. MAME's names are per driver.
