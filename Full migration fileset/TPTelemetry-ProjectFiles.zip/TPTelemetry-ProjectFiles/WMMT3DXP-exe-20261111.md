# WMMT3DX+ from the game's `main`, 11 November 2026

Alexis attached `main` from her WMMT3DX+ install and asked for its addresses for speed, revs and gears, and anything
else worthwhile. The rows are in the pack (`moregames.add_wmmt3`, `commonrows.py`); none are checked in a recording yet.

## The file

* `main`: 24,925,524 bytes, MD5 aac96862372ee774a14096792fc40c13. 32-bit Linux ELF, type EXEC (not position
  independent), built with gcc 4 against Boost 1.36 for Sega's Lindbergh-era Linux (rpath `/arcade/usr/...`).
* Loaded at its link addresses: text from 0x08048000, `.data` 0x09745000, `.bss` 0x097FD4A0 to 0x0994B468. An EXEC
  program has its absolute addresses baked into its code, so BudgieLoader must map it exactly there. TP Telemetry reads
  those addresses with Module blank, as OutRun 2 does (checked in recordings, 2 November).
* **It keeps its dynamic symbol table: 61,106 symbols, 12,668 of them variables, with C++ names.** The race code is
  namespace `yt::` (`CSeq`, `CMachine`, `CState`, `CTimeKeeper`, `CTransmission`, `CTurbo`, `CFire`, `CReactive`...).
* The cheat table's "GTimer1" (MasterRaver, absolute 0x09813A6C, the old `race_timer` row) is `yt::CState::fTDec_Rest`:
  the time left, not a race clock. The address matching shows her `main` is the Export build that table was made for.

## Why the old rows were BudgieLoader-relative

The cheat table's speed1 and gears1 (`BudgieLoader.exe+650A74` +AA8, +AB4) are a copy of the HUD's meter record:
`S2DInfoMeter` is 0x1C bytes (+8 speed km/h, +14 gear), the same stride as speed4/gears4 (+AC4, +AD0), which are the
copy a frame earlier (`clWorkSpace::updateRace` keeps the previous meter beside the current one each frame). That copy
lives in BudgieLoader's memory, so TeknoParrot updates move it (October 2026's did). The game's own variables don't move.

## The game's variables

`yt::CSeq` holds pointers to the race objects, all in `.bss`:

| Global | Address | Points to |
|---|---|---|
| `yt::CSeq::pMachine` | 0x098138E4 | the player's car (`yt::CMachine`) |
| `yt::CSeq::pIO` | 0x098138E0 | the player's controls (`yt::CIO`) |
| `yt::CSeq::pTimeKeeper` | 0x098138C8 | race clock and sections (`yt::CTimeKeeper`) |
| `yt::CSeq::pRivalCarAry` | 0x098138B4 (3 pointers) | CPU rival cars (`yt::CRivalCar`) |
| `yt::CSeq::pReactive` | 0x09813868 | the force feedback smoother (`yt::CReactive`) |
| `yt::CSeq::bIsInitialized` | 0x09813970 (byte) | 1 from `CSeq::Init` to `CSeq::End` |

**`CSeq::End` deletes the car and the other objects without clearing the pointers** (only `CSeq::Init` zeroes them,
before making new ones), so between races the pointers point at freed memory. Every car row is gated on
`seq_active` (`bIsInitialized`).

### The car (`yt::CMachine`, from `[0x098138E4]`)

| Offset | Type | What | Evidence |
|---|---|---|---|
| +AE0 | float | speed, mm/s | `CSeq::Get2DInfoMeter`: meter speed = +AE0 x 0.0036 (km/h). Written in `CMachine::DriveYaw`: sqrt(vx^2 + vz^2) of +AC8/+AD0, times +68. `Wedge(speed, 2777.8, 27777.8)` elsewhere is 10 to 100 km/h in mm/s |
| +2C4 | object | `CTransmission` (its first part is `CEngine`) | `CTransmission::Drive` and `CEngine::GetRevRate` are called with machine + 0x2C4 |
| +2CC | float | engine speed, rad/s (engine +8) | `GetRevRate` = clamp(+8 x 60 / 2 pi / limiter, 0, 1) |
| +2C4 -> +8C | float | the car's limiter, RPM (engine data) | the divisor in `GetRevRate` |
| +300 | int32 | gear: -1 reverse, 0 neutral, 1 up (transmission +3C) | `GetGearRatio`, `ATShift`, `MTShift` (manual: the shifter's position, clamped to the car's top gear); the meter shows it |
| +304 | int32 | the gear before (transmission +40) | |
| +340 | object | `CTurbo` | `CTurbo::Drive` called with machine + 0x340 |
| +344 | float | boost, bar (turbo +4) | meter boost needle = (0.5 + boost) x 0.4. Table `yt::CTurbo::fBoostTbl` (0x094410E0): 4 rows of 18 by rev rate, from -0.5 up to 0.6, 0.9, 1.2 or 1.5 |
| +340 -> +44 | float | this car's full boost (row entry 17) | `CTurbo::Init`: row = tuning level (0; 1 to 3 -> 1; 4 to 6 -> 2; over 6 -> 3) |
| +368 | byte | blow-off: set when the boost (over 0.2) drops more than 0.27 in a frame, cleared when it stops falling | `CTurbo::Drive`, turbo +28 |
| +36C | object | `CFire` (exhaust flame) | |
| +39C | int32 | fire counter (CFire +30): set to 38 or 35 on a sharp lift at high revs, down 1 a frame; the flame is at 26 | `CFire::Drive`, `CFire::GetFire` (counter == 0x1A), copied to +B40 each frame |
| +AF8 | int16 | slip angle, 65536 to a turn | `DriveYaw`: atan2(+AC8, +AD0) x `geo::CAngle::RAD2ANG`, through `CTire::GetTireInput` (folded to within 90 degrees when going backwards) |
| +AFC | float | wheel slip ratio: (wheel speed - car speed) / car speed | `CTire::GetTireInput` (STireInput +4) |
| +AF0 | float | smoothed slip, signed like +AF8; drives the centre force | `DriveYaw`; `Set_SE_Effect_Reactive`: centre = +AF0 x +48 x 0.75 |
| +90, +91 | bytes | car contact this frame, last frame | `CHit` at +90 (`CHit::Prep` clears +0 each frame); +CC strength |
| +D4, +D5 | bytes | wall contact this frame, last frame | `CHit::CourseHit` sets CHit +44; +110 strength; the contact normal at +104 (car frame via the matrix at +A4C gives the side) |
| +970 | float | odometer, mm (distance along the course) | `Get2DInfoRace`: distance to goal = goal mark - +970; course lengths are in mm (`Area_TkC1_In` 9,407,255) |
| +C84..+C90 | floats | the four force values: centre, spring, viscosity, reflect | `CSeq::Exec` passes machine + 0xC84 to `CReactive::Drive`; `clGameInput::ftb_update` sends them on (centre x 511, the rest x 127): TeknoParrot's slots 8, 6, 7, 9 |

`Set_SE_Effect_Reactive` also checks the course under the car each frame for gaps (`SAreaData::CheckGap`: the
expansion joints), zebra strips (`CheckZebra`) and guard rails (`CheckGuardRail`), but keeps the results in local
variables: they reach us only as reflect pulses and camera shakes. Zebra strips should show in slot 9 as well; not
yet seen in a recording.

### Controls (`yt::CIO`, from `[0x098138E0]`)

+0 steering (the input's sign flipped: -1 to 1), +4 throttle 0 to 1, +8 brake 0 to 1 (clamped in
`clInputDeviceJamma::handleEvents`), +C the shifter's gear.

### Race state and timing

* `yt::CState::eState` 0x09813A78 (names from `GetStateName`, table 0x09789700): 0 NONE, 1 CountDown, 2 Run,
  3 Retire, 4 SlowDown, 5 StopWait, 6 TimeUp, 7 GoalWait, 8 Goal, 9 Defeat, 10 Suspend.
  * Run -> GoalWait as the time keeper's sections passed reach its section count (the finish line), or a rival's
    finish in battles (`Ck_X_2_GoalWait`). Run -> SlowDown when the time left reaches 0; back to Run if time is
    added; SlowDown -> StopWait -> TimeUp. Retire after reversing 4 s with retiring allowed.
  * `CSeq::Exec` turns the wheel forces on in CountDown and Run, off in Retire, TimeUp, Goal, Defeat, Suspend.
  * `eState` isn't reset at the end of a race: gate on `seq_active`.
* `fTDec_Rest` 0x09813A6C time left, s; `fTDec_CountDown` 0x09813A68 the start countdown; `bReverseBuf` 0x09813A58
  (3 bytes, any set = going the wrong way, `IsReversing`); `fTInc_Reverse` 0x09813A5C.
* `CTimeKeeper` (`[0x098138C8]`): +0 sections to the goal, +4 their odometer marks, +8 extra time per section,
  +C race clock s (frozen at the final time at the finish), +10 split times, +14 sections passed, +1C extra time due.
* Rivals: `[0x098138B4]` +7F4 the first CPU rival's odometer (mm). Linked play uses `pLxRivalAry` (0x0981389C)
  instead, and `Get2DInfoBattle` counts the cars ahead.

## Rows added (all "Not yet checked in a recording")

`speed` (+AE0 x 0.0036 / Max speed), `rpm` (+2CC x 60 / 2 pi / Max revs), `gear` (+300), `rev_limit`, `rpm_frac`,
`shift_light` (over 0.86, where the game lights the meter's rev lamp), `turbo`, `turbo_max`, `blowoff`, `backfire`
(counter 1 to 26), `drift_angle` (-(+AF8) x 360 / 65536), `wheel_slip`, `wall_touch`, `car_touch` (and unticked
strengths), `odometer`, `rival_gap`, `leader`, `seq_active`, `race_state`, `in_race` (state 2), `time_left` (was
`race_timer`), `countdown`, `race_time`, `sections`, `sections_passed`, `checkpoint`, `reversing`, `throttle`,
`brake`, `steer`. The old rows stay unticked as `speed_ce`, `rpm_ce`, `gear_ce` for comparison.

Common values now: `car_in_race` = `in_race`; `car_boost` = turbo / turbo_max; `car_rpm_frac` = `rpm_frac`;
`car_throttle` = throttle; `car_drift` with ID6's weighting and `car_drift_angle`. Hits, walls, joints, grip loss and
cornering stay on the checked TeknoParrot-slot formulas.

`Wmmt3ReplayTests` feeds the 1 November recordings' speed, revs and gear into the new rows in the game's units
(km/h / 0.0036, RPM x 2 pi / 60) and checks they come out the same as the old rows, with `in_race` on throughout.
1737 tests pass with the pack, 764 without.

## Guesses to settle in a recording

* **The drift angle's sign.** Taken from the force: the centre force is +AF0 x +48 x 0.75 with +AF0 signed like
  +AF8, and on 29 October right-hand slides gave slot 8 about -50. That assumes +48 is positive.
* **Steering's sign** (+ right assumed from the usual JVS layout, then flipped as the game flips it).
* **The attract mode:** whether its replays run `CSeq` (if so, `in_race` would read 1 there).
* **WMMT drift weighting:** ID6's curve (5 to 50 degrees). WMMT slides are likely shallower.
* `wall_touch` and `car_touch` against the slot 9 hits; whether zebra strips show in slot 9.
* `checkpoint` and `time_left` in a mode with extra time; `rival_gap` in a story battle.
