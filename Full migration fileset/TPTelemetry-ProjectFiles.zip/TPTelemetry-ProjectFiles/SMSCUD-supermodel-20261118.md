# Scud Race in Supermodel (SMSCUD): Supermodel's RAM, the game's values, and notes for Daytona USA 2, 18 November 2026

**Later the same day her four recordings checked and changed the profile** (`SMSCUD-capture-20261118.md`): +2C4 is not
the wheels' angle, Car_cornering comes from `steer`, Car_drift is full at 70 degrees, Max revs 9500 with per-car rev
limits from the car number (+105), car contact (+2F7) and near car (+101) were added from the emulator, `airborne` from
free fall, and `racing` ends at the clock stop. The tables below are the morning's findings.

Alexis sent `supermodel.exe` and `scud.zip` and asked for the SMSCUD profile to be updated for data captures, keeping notes
on the exe for SMDAYTONA2 next. Pack rows: `moregames.py` (`sm_ram`, `sm_lamps`, `smscud_rows`); common rows in
`commonrows.py`; setup notes in `gamesetup.py`. Tools: `supermodel/` in the Tools archive.

## The files

* `supermodel.exe`: Supermodel 0.4-dev, git **0b82a98** (16 November 2026, "Model 1/2 renderer: always draw the frame in its
  own frame buffer"), 64-bit MinGW build, stripped, MD5 440c8330529f89714047740b9b45831e (11.5 MB). The source at that
  commit (github.com/trzy/Supermodel) matches it, so the exe can be read against the source.
* `scud.zip`: Supermodel loads it as **`scudau`** (Scud Race, Australia, Twin/DX): program ROMs epr-19731.17 to
  epr-19734.20. Supermodel patches crom 0x199DE8 to open the secret debug menu.
* The fixed program is 2 MB at 0xFFE00000 (the PowerPC resets to 0xFFF00100): epr-19734.20 gives bytes 0-1 of each 8,
  19733.19 bytes 2-3, 19732.18 bytes 4-5, 19731.17 bytes 6-7, each 16-bit word byte-swapped (`supermodel/buildcrom.py`).
  The code runs from ROM (0xFFF0xxxx); `r13` is the small-data base, **0x108000** (`lis r13, 0x11; addi r13, r13,
  -0x8000` at 0xFFF11540), so most globals are `d(r13)` with d from -0x8000 to 0x7FFF.

## Supermodel's emulated RAM (from the exe)

* The PowerPC core is a static `PPC_REGS ppc` in .bss. `ppc_change_pc` (the function printing "PowerPC is out of
  bounds. Halting emulation until reset.", at `<main>+14F9D0`) reads `ppc.cur_fetch` at `<main>+AE6270` (start, end,
  pointer at +8) and **`ppc.fetch` at `<main>+AE6280`**, a pointer to an array of 16-byte regions (start, end, pointer at +8).
* `CModel3` fills the regions at its +0x1A8 (`movabs rax, 0x7fffff00000000` at `<main>+6297E`: region 0 is 0 to
  0x7FFFFF with `ram` = CModel3+0x128; region 1 is 0xFF800000 up with `crom` = +0x130) and calls `ppc_set_fetch`
  (`<main>+1599D0`, `mov [<main>+AE6280], rcx`).
* So a game address A (0 to 0x7FFFFF) is **`[[<main>+AE6280] + 8] + A`**: a Memory row with Module `<main>`, Base offset
  `AE6280`, Offsets `8, <A>`. Process `supermodel.exe`, 64-bit (the helper).
* **Byte order:** the PowerPC is big-endian; Supermodel keeps RAM as 32-bit words in the PC's order (`Read32` is
  `*(UINT32 *)&ram[a]`, `Read16` is at `a ^ 2`, `Read8` at `a ^ 3`). So 32-bit ints and floats read as they are, a 16-bit
  value at A is read at A ^ 2 and a byte at A ^ 3 (`sm_ram` does this). Doubles would have their halves swapped.
* `ram_probe` reads game address 0x100 (exception code the game copies to RAM at power-on): **2087778982** (0x7C70FAA6),
  steady from the first second.
* **Another build:** find the string "PowerPC is out of bounds", the code using it is the end of `ppc_change_pc`; the
  first global it loads with `mov rbx, qword ptr [...]` before `mov r11, qword ptr [rbx + 8]` is `ppc.fetch`. Or find
  `movabs rax, 0x7fffff00000000` followed by `call` (`ppc_set_fetch`), whose one store is to `ppc.fetch`. The `@` offsets
  (plugin 0.18.2) would also work here, if a game keeps values behind its own pointers: the chain's first pointer is the
  region array, not RAM, so `@` would need the plugin to take the emulator base from the second step (not needed for
  Scud, whose values are at fixed addresses).
* Outputs: `CModel3::WriteInputs` sends port 0x10 as `RawDrive` (drive board) and port 0x14 as `LampStart` (4),
  `LampView1` to `LampView4` (8, 16, 32, 64), `LampLeader` (128) and `RawLamps`.

## How the values were found

No recordings: the analysis ran Supermodel itself. The source at 0b82a98 was built for Linux with a small patch
(`supermodel/tptanalysis.patch`: a per-frame log of chosen RAM ranges, whole-RAM dumps on a trigger file, a write watch
and a poke file), run headless under Xvfb with Mesa's software OpenGL (`-legacy3d -no-sound -no-dsb -no-threads`, about
47 frames a second while logging), and driven with `xdotool`. Screenshots every second gave the HUD (speed, time,
position, lap, lap clock) for each logged frame.

* With a fresh NVRAM the game stops at **CANCELLED / NETWORK BOARD NOT PRESENT**: in the test menu (Test = 6, Service = 5)
  GAME ASSIGNMENTS, LINK ID MASTER -> SINGLE. Alexis's own NVRAM will already be set.
* Menus: coin 3, start 1, accelerator Up picks the course, the car and the gearbox (steer right first for MANUAL).
* The car was driven by `supermodel/autopilot.py`: it records where the 39 computer cars go (their records sit after
  the player's, 0x300 apart) and steers the player's car at a point 30 frames ahead on the nearest one's path (Left or
  Right held), with timed events (brake, let go of the wheel, steer into a wall). The game's x/z make steering
  "right" the negative cross product (`SIGN -1`). It laps the Beginner course in about 36 to 42 s; with 60 s and 29.3 s
  per lap line that doesn't reach the finish, so for the finish run the time left was poked up once (`poke.txt`).
* Save states (F5, F7) restart a race in a second; the log carries on across them.

Logs (all on the Beginner course, Porsche 911, automatic; the manual menu choice didn't take): r1 attract mode and a
crash-filled race to time up; r2 two wrong-sign autopilot races (pinned on the left barrier), a full race with events to
time up (1'29"33), whole-RAM dumps with 24 screenshots (positions 40th to 22nd, lap 1 36.48 s); r5 power-on to the
finish line of four laps (2:31.70) and the attract mode. Fixtures from r2 and r5 are in the plugin's tests
(`ScudTests`).

## The game's values (game addresses; `sm_ram` adds the byte-order fix)

Race globals (r13 = 0x108000):

| Address | Type | What | Evidence |
|---|---|---|---|
| 0x10525C | UInt32 | race sequence: byte 1 (bits 8-15) phase 2 loading, 3 rolling-start camera shots, 4 driver's view (countdown 3-2-1 and race; stays 4 after); byte 2 = 1 until GO; top byte set at the finish (0x10) or time up (0x27, 0x25, 0x1D seen) and kept into the attract mode and the next race; 0 from power-on to the first race | every transition in four logs |
| 0x104010 | Int32 | time left, frames (57 a game second: 60 s = 3420); +1671 (29.3 s) at each Beginner lap line; held after the finish; -1 at time up | HUD 59 to 48 at ten screenshots |
| 0x10400C | Int32 | race clock (TT), frames from GO; stops at the finish and time up | 5092 frames = 1'29"33 and 8647 = 2:31.70 on the result screens (the game divides by 57) |
| 0x10404D | Byte | RETIRE count on the HUD | 0, 1, 2 |
| 0x1016EC | Int32 | not the lap (stayed 2 into lap 3) | |

The player's car record, game address 0x181000 (0x300 bytes; cars 1 to 39 follow at 0x300 apart, but the computer cars
leave most physics fields 0):

| Offset | Type | What | Evidence |
|---|---|---|---|
| +118 | Int32 | speed, km/h as the HUD shows it | 34 readings, 103 to 328 |
| +11C/+120/+124 | Float | position x, y, z (metres) | |
| +150 to +170 | Float | orientation matrix; forward = (+158, -+170) | travel direction from the position |
| +178/+17C/+180 | Float | movement in the last frame, x, y, z (m); x 57.5 x 3.6 = km/h | correlation 0.999 with the position's change |
| +198 | Byte | laps completed (lap = +1) | lap lines in r3 and r5 |
| +1B7 | Byte | crash timer: 28 at a hard wall hit (about 80 km/h lost at once), counting down; not set by scrapes | 4 hits |
| +1BF | Byte | brake 0 to 255 | key presses |
| +1C0 | Int32 | steering input -32766 (left) to 32766 | key presses (full lock with keys) |
| +1CC | Int32 | race clock at the last lap line (frames) | 2129, 4553, 6585, 8647 at the four lines of r5 |
| +1D0 / +1D2 | UInt16 | best lap / last lap (frames) | 2129, 2129 -> 2129, 2424 -> 2032, 2032 -> 2032, 2062 |
| +101 | Byte | bit 4 (16): another car within about 5 m (added after her recordings) | |
| +105 | Byte | car: 4 Porsche, 5 Viper, 6 F40, 7 McLaren (added after her recordings) | four emulator races |
| +1D4 | Byte | position, 0 = first | 13 screenshots, 40th to 22nd |
| +1E7 | Byte | throttle 0 to 255 (ramps with a key) | gas off and on |
| +23C | Int32 | gear 1 to 4 | automatic shifting |
| +244 (= +248) | Int32 | engine revs as the rev counter shows (dial 0 to about 7.4k) | 6246 a little past 6, 5244 a little past 5 |
| +258 | Float | about 60 to 67 on the road, to -76 at times; 0 in attract (candidate `grip_258`) | |
| +288 | Int32 | the strip of road under the car, counting up along the course (wraps at the lap line, 737 on Beginner) | |
| +28C/+290/+294/+298 | Int32 | the same for the front left, front right, rear left, rear right wheels: several hundred (about 735 to 1640) off the car's while that wheel is against a wall or barrier | right scrape: +290 and +298; left scrapes and the left barrier: +28C and +294 |
| +2C4 | Int32 | followed the keys (-25 to 25) but not her wheel in her recordings: not the wheels' angle | |
| +2F7 | Byte | touching car: 255 none, 0 left, 2 right, 3 ahead, 1 behind (added after her recordings) | the other car's place in the emulator log |
| +334 | Float | about revs / 9.5 (candidate `engine_334`) | |
| +338 | Float | 0.86 x km/h (candidate `speed_338`) | |
| +388 | Int32 | 1 to 300, changes along the course and at some scrapes (candidate `area_388`) | |
| +38C | Int32 | 0/1 in short spells, slower speeds; not car contact (candidate `flag_38c`) | never on with a car within 4 m |

Not found yet: wrong way (REVERSE! on screen; nothing in the car record or globals followed it), car-to-car contact,
grass and other surfaces, airborne (no jumps on Beginner; `move_y` is there for it), the manual gearbox, other courses
and cars. The attract mode's demo race drives the player's record with the computer's simplified model (physics fields
0), which is why `racing` gates everything.

Code addresses seen (for later digging): the time-left countdown at 0xFFF26B08 (`lwz r3, -0x3ff0(r13)`), the race clock
increment at 0xFFF26BC0, a lap-line block at 0xFFF26A84.

## The profile (76 rows)

Force rows (`out_RawDrive`, as before; Daytona 2 and Le Mans 24 unchanged), lamps from outputs (`lamp_start`,
`lamp_view1` to `lamp_view4`, `lamp_leader`, `lamp_bits`), and the memory rows above with: `phase`, `countdown`,
`racing` (phase 4 and the countdown, or the race clock moving: countdown to the finish line or time up), `lap_time`,
`time_extended` (2 s when the time left jumps up, not at the start), `drift_angle` (heading against the last frame's
movement, + right), `drift` (ID6's curve full at 45 degrees), `edge_left`/`edge_right` (a wheel's strip more than 300
off the car's), `wall_contact` (-1, 1, or 0 when neither or both, which hides the lap-line wrap), `hit` (the crash timer
jumping; 0.5 + km/h lost / 120) and `hit_side`. Common values: in race, speed, revs, gear, G, throttle, impact and side,
wall contact, drift and angle, grip loss (= drift), cornering (front wheels' angle / 20 x sqrt(speed / 120)), road
bump and vibration (outputs); all but Car_in_race 0 outside a race. Max speed 350 (the gearbox screen gives the
Porsche 337 automatic, 344 manual), Max revs 7500. 2026 tests pass with the pack (27 new in `ScudTests`), 770 without.

## To check in Alexis's first capture

1. `ram_probe` reads 2087778982 (the pointer is right for her build).
2. Speed and revs against the screen; gear with the manual gearbox.
3. Car_in_race from the countdown to the finish line, nothing in the attract mode (whether she wants the 3-2-1
   countdown included: the game drives the car then).
4. `wall_contact` and `hit` at scrapes and hits she marks (left and right), and whether car contact shows anywhere.
5. Drift angle and Car_drift in her drifts (Scud is a drifting game: the 45-degree full scale is a guess).
6. Grass or sand, jumps (Medium and Expert courses), REVERSE! (which candidate row moves).
7. Steering with her wheel (`steer` should follow it, not jump to full lock).

## Notes for Daytona USA 2 (SMDAYTONA2) next

* Same `supermodel.exe`, so the same RAM pointer (`<main>+AE6280`, +8) and byte order; `sm_ram` works as it is. The
  profile is made by the same loop in `moregames.py` (now `if pre == 'SMSCUD'`), so give Daytona 2 its own branch.
* Supermodel's `daytona2` is Step 2.1, `netboard` true like Scud (expect the same LINK ID fix with a fresh NVRAM),
  program ROMs epr-20861a.17 to epr-20864a.20 (Japan Rev A; `dayto2pe` is the Power Edition), the same interleave
  (offsets 0, 2, 4, 6 with byte swap; pass the names to `buildcrom.py`, highest-numbered first). Check which set her zip is
  (Supermodel's log names it).
* Expect the same kind of layout (AM2, a year later): an r13 small-data area, a race sequence word, frame clocks, a car
  record array. Find r13 from `lis r13` in the program; find speed by value from screenshots (the HUD's km/h), then the
  record's stride from the computer cars' positions near the player's at the rolling start.
* To repeat the method: build Supermodel 0b82a98 with `tptanalysis.patch` (about 1.5 min on two cores), copy `Config`,
  `Assets` and the ROM zip into a run folder, `Xvfb :99`, `runsm.sh`, then `drive.py` for the menus and screenshots,
  `findval.py`/`exactfull.py` on whole-RAM dumps, and `aipath.py` + `autopilot.py` (change the car record addresses) to
  drive laps. Her NVRAM file would save the test-menu step, and her Supermodel.ini the inputs.
* Disk: the per-frame log of 240 KB a frame fills about 12 MB a second; log only the ranges needed.
