# GTI Club Supermini Festa (GTICLUB3): pack rows, 8 November 2026

Follows `claude/GTICLUB3-exe-20261108.md` (the exe review: addresses and what each field is).

## Built, 8 November 2026 (17:30)

Pack: GTICLUB3 regenerated from memgames.py (block rewritten), commonrows.py (GTICLUB3 impact case; car_road_bump 0 row),
gamesetup.py (NOTES). Pack README: GTI Club row updated and a new "GTI Club Supermini Festa" section; Alexis's
`GTIclub.CT` added to `Teknoparrot/GTICLUB3/`. Only GTICLUB3.json, Game_Formulas.md, Game_Setup.md and README changed;
regenerating twice changes nothing. 67 rows. Max revs 7500; Max speed left blank (ask for her speedo at top speed).

Corrections to the notes above, found while building:
* car+1328 (dash+1028) is a countdown (-1 each update at 0x54517B) set to 90, 300 or 45 by the code at 0x548900 to
  0x549050, which handles **car-to-car contact** (two cars' +300 blocks, a contact counter at +1324 going 0, 1, 2 and a
  third-contact action: likely the variety battle modes). So `contact_timer` / `car_contact`, not wall hits.
* The vibration byte keeps its top two bits (`and 0xC0`): `vibration` now masks to 63 instead of the FFB plugin's
  `< 64` test (which would read 0 with either bit set). Top bits recorded as `ffb_flags` (unticked).

Rows (car = `<main>+67FCC8`; car values gated by `race_loaded` = race state 1 to 9, else 0):
speed (+648 / max_speed), true_speed (+1A4 x 3.6), speedo_mph (`<main>+67FCB4`), rpm (+174 x 60 / max_revs),
rpm_tacho (+B8), gear (+644), gear_stored (+164 signed, unticked), gearbox (+F1), race_state (67FAC8: 2C8, 34),
in_race (state 5), race_loaded (unticked), game_mode (67FAC8: 90), time_left (67FB98), checkpoint
(`in_race && maxw(delta(time_left) > 0.01, 1)`), hurry (last 10 s), position (+CB8 + 1), leader, laps_done (+CBC),
laps_total (549458), final_lap, finished (+CC8), lap_time (+CE8 / 30), lap1-7 (+CCC.., ms, unticked), last_lap,
surface1-4 (+42C..+438 raw), rough_ground (codes 2 and 5 without bit 256, quarter per wheel, moving), force_angle (+238),
contact_timer (+1028, unticked), car_contact, hit (`ffb_other == 15 && delta(vibration) > 0.1`, held 0.3 s, value
maxw(vibration)), accel_g from true_speed. car_: in_race, speed, rpm, gear, accel_g, impact = max(hit, car_contact x 0.5),
road_bump 0, off_road = rough_ground, cornering = force_smooth, vibration. No car_impact_side (USB fills the side).

Tests: new `tests/CoreTests/GtiClubTests.cs` feeds a made-up race (menus with stale car values, countdown, racing,
a +20 s time extension eased in, rough ground, a hit, a car touch, laps, time up) through the engine and the pack
profile: 19 checks. **1459 pass with the pack, 730 without.** Plugin code unchanged (still 0.17.1).

To learn from Alexis's first recording: whether states 6 and 7 are still driving; the lap timer's rate (30 a second?);
which surface codes are which ground and which wheel is which; what bit 256 means; force_angle (slip or steer?);
gearbox (AT/MT?); game_mode numbers; whether hit catches wall hits and nothing else; gear_stored at the start (neutral?);
the speedo at top speed (Max speed).
