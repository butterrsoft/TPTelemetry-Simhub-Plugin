# TP Telemetry: reference (the project handover of 4 November 2026, 14:15)

**Renamed 16 November 2026 from `TPTelemetry-Handover.md`. This is reference material, not the handover:** the current
handover is `TPTelemetry-Handover-20261116.md`. Open this for the architecture, formula language, design rules, licensing
notes and history to 4 November; its version numbers, test counts, file lists and "attach these" list are out of date.

This is a briefing for continuing work in a new thread (Hobart time). Alexis writes in Australian English and wants
the same back: no em dashes, first person, business-like but approachable, concise replies. She sends recordings
(CSV from the plugin's recorder, with marks and notes), Cheat Engine tables and FFB/OutputBlaster files; the job is to
analyse them against her notes, update the generators, profiles, plugin, tests and docs, then deliver the three zips
and sync the project docs (`claude/` in the claude.ai project). When she says "just advise", change nothing.

Attach these alongside it:

* `TPTelemetry.zip`: the plugin source, **version 0.17.0**, with its tests (WMMT5DX+, WMMT3DX+, OutRun 2, Sega Rally 3,
  SWDC and GRID recording fixtures), README and the four help files (Formula_Reference.md, USB_Capture.md,
  Game_Outputs.md, SimHub_Effects.md).
* `TPTelemetry-GameProfiles.zip`: the game profiles pack, 106 profiles in emulator folders, with README,
  **Game_Setup.md** (how to set up each game: index, what each needs) and Game_Formulas.md, released separately.
* `TP-Telemetry-game-values.csv`: the on-screen values sheet Alexis is filling in.
* `TP Telemetry - Bass Shakers.siprofile`, `TP Telemetry - Motors.siprofile`: sample effect profiles (the plugin
  writes its own).
* `TPTelemetry-ProjectFiles.zip`: every claude.ai project doc: this handover; capture notes
  `WMMT3DXP-capture-20261029.md`, `WMMT3DXP-capture-20261101.md`, `WMMT5DXP-capture-20261029.md`,
  `WMMT5DXP-capture-20261101.md`, `OR2-capture-20261102.md` (four recordings, the last with USB),
  `SR3-capture-20261102.md`, `WMMT5DXP-outputs-script-20261102.md`, `WMMT5DXP-capture-20261103.md`,
  `SWDC-table-20261103.md`, `SWDC-capture-20261103.md`, `GRID-capture-20261103.md` (3 and 4 November, revs);
  `Binaries-review-20261029.md`, `Properties-and-common-set-20261030.md`, `CheatTables-and-emulators-20261102.md`;
  and the generator scripts in `tools/` (memgames.py with moregames.py, obnames.py, obmem.py, oblamps.py,
  commonrows.py, tidytable.py, packlayout.py, gameformulas.py, gamesetup.py).

**Pack generator:** `python3 -I tools/memgames.py <pack copy>` regenerates every generated profile, README untouched,
Game_Formulas.md and Game_Setup.md rebuilt; a second run must change nothing. Work on a copy of the pack, diff, then
replace. Hand edits go in the generators (memgames.py game blocks, moregames.py `extend()`, commonrows.py car_ rows,
gamesetup.py NOTES/CHECKED), never in the JSON. Tests: `TPT_PROFILE_DIRS=<pack> dotnet run --no-restore` in
tests/CoreTests (**1437 pass with the pack, 727 without**); `sh tests/CompileCheck/compile-check.sh` (plugin, helper,
test target; needs mono-devel). Recordings store row *outputs*: undo formulas (x Max speed, x Max revs, x 37...)
when building a fixture. Cheat Engine .CT files list pointer offsets last first.

**Where things stand (4 November, late morning):**
* Checked against recordings: WMMT3DX+, WMMT5DX+, OutRun 2 SP, Sega Rally 3, SWDC, GRID (BG4JP against her FFB
  plugin files). Everything else in the pack is a starting point.
* USB capture works on her G25 and matched the decoded or game-derived force in every game checked (SR3, SWDC, OR2,
  GRID). 0.16.0 keeps the wheel found by name, fills a missing hit side from the wheel force, and records the Car_
  values SimHub got.
* GRID: speed (speedo km/h), revs, each car's limiter (rev_frac), gear (1 to 6, -1 reverse), throttle and shift
  lights all from the game's on-screen dial object (GRID.exe+B1B100 -> 200 -> 120 -> offset); Max speed 280 km/h;
  plugin 0.17.0 takes Car_rpm_frac from rev_frac, so Max revs (6900) only scales the rpm row. car_contact is a count.
  No in-race value (pausing freezes everything).
* Per-car limiters (learnt on GRID: 6500 to 8200 by car): every other game still has one Max revs set from one car, so in
  a car that revs differently the rev limiter effect fires early or late. WMMT5DX+ certainly varies by car (Max revs 8900
  suits her car); SR3, OR2 and SWDC are unknown (one car each). Test: a recording in a second car on the limiter; fix: a
  per-car limiter or rev fraction from Cheat Engine (as GRID's dial 3B4) feeding `car_rpm_frac` (plugin 0.17.0).
* Recordings (0.16.0 on) end with `Car_*` columns: what SimHub got, after gating and USB stand-in. Use them to check
  replays (`rec_Car_*` fixture columns).

**Waiting on Alexis:** MasterRaver's WMMT6RR Outputs script (in progress; credit him). Whether the wheel now stays
found after restarts (0.16.0). GRID: a race with plugin 0.17.0 and the dial rows (Car_rpm_frac, Car_throttle live), and
an in-race signal if one turns up (the dial structure had none). Whether to remove SWDC
speed1/gear1. TeknoParrot's own emulators' output names (for TP-prefixed Model 2/3 profiles).

**Next likely asks:** second-car recordings for per-car limiters (WMMT5DX+ first); a GRID in-race value; the WMMT5DX+ ideas left as notes
(blow-off, brake, place, shift feel); more SR3 and OR2 runs; USB-based rows for other hook games; the
lamps/LEDs/gauges step.

### 4 November 2026, 14:00: plugin 0.17.0 (car_rpm_frac); GRID from the on-screen dial

Alexis's Cheat Engine dumps showed the revs' structure is GRID's `dialinterface` (the dash). Four recordings with test
rows (13:15 fastest class with marks at known speeds and gears; 13:17 pausing; 13:18 reverse; 13:32 another car) confirmed:
298 speed m/s (x 3.6 = speedo exactly), 278 gear (1 to 6, 9 reverse), 3B4 revs / car limiter (capped 1; limiters 8000,
8200, 7000, 6500), 27C throttle, 254 shift lights (bits 1 and 256), 29C distance. 254/290 aren't in-race; pause freezes all.
Plugin 0.17.0: CommonValues source `rpm_frac` (Car_rpm_frac from it, else rpm / Max revs); README, SimHub_Effects.md;
CommonValuesTests. Pack: GRID block rewritten (old speed/gear unticked as wheel_speed/gear_abs), commonrows GRID
car_rpm_frac and car_throttle (COMMON gains rpm_frac), gamesetup GRID notes, README GRID section, GRID.CT updated, values
sheet. Fixtures and `GridReplayTests.Dial`; older GRID fixtures renamed. Details in `claude/GRID-capture-20261103.md`.

### 4 November 2026, 11:30: three GRID recordings with 0.16.0 and the revs rows

Details appended to `claude/GRID-capture-20261103.md`. USB matched (impact_side = wheel force a poll later in 88 to
94% of hit frames; the rest are hit edges, gear-change sines on top, and +0.03 car-contact rumble). Revs: both chains
agree; 1000 in menus, 0 while loading; limiters 8200 (GRID1 car), 7500 (GRID2, GRID3), 7000 (her table's car).
Speed/speedo ratio by car: 1.25 (fastest class), 1.0, 1.09. Gear read 1 all race in GRID2. car_contact counts 1 to
5. GRID3 mark 1 was the race start. Changes: memgames GRID Max speed 280 (Alexis), notes for speed, gear, rpm,
car_contact; gamesetup notes; pack README GRID section rewritten; values sheet. Fixture `grid-20261104-101302`
with `rec_Car_*` columns: `GridReplayTests.Fourth` checks the replay against what SimHub got live. No plugin change.

### 4 November 2026, 10:15: GRID revs from memory (Alexis's Cheat Engine table)

TeknoParrot has no Enable Outputs option for GRID, so OutputBlaster (hook at GRID.exe+51C720, RPM float at object
+2C) never loads. Alexis's CE table (`Teknoparrot/GRID/GRID.CT` in the pack): `fstp [esi+2C]` at GRID.exe+91C747;
engine object at +258 in the car structure, chains end 284 (or 5E0 via another structure); held through restarts,
a reboot, other car/track, repeated races. memgames GRID: `rpm` B1B100 200,120,284 and `rpm2` 41CA50 2B8,8,5E0
(Float, / max_revs), no ob_game (OutputBlaster's only GRID output was RPM), Max revs 6900 (redline; limiter 7000;
idle 636/1363). commonrows `car_rpm = valid(rpm, rpm2) * max_revs`. gamesetup GRID notes/CHECKED. GridReplayTests:
profile checks, rpm rows allowed missing from the 3 November fixture. Details appended to `claude/GRID-capture-20261103.md`.
CE .CT files list offsets last first (worth remembering when reading her tables).

### 4 November 2026, 09:30: plugin 0.16.0 (wheel kept, USB hit side, Car_ in recordings); OR2 20:48; Game_Setup.md

* **OR2 recording 20:48** (details appended to `claude/OR2-capture-20261102.md`; fixture `or2-20261103-204859`,
  `Or2ReplayTests.Fourth`): USB capture worked. Hook force = full side push at side-on wall/traffic hits, none at
  rear-end hits (truck, mark 2; mark 3), 0.55 on the sand divider (mark 1), 0.06 sine at gear changes, no steering
  force. Flip wall (mark 4, 84.77): side_hit_dir 0, wheel force -0.8 (left). Stand-in had filled road_bump (sand),
  cornering (blips, wrong) and vibration (0), not the side (OR2 has a car_impact_side row).
* **CommonValues (0.16.0):** hit with side 0 takes the side of a USB kick within `UsbSideSeconds` 0.3 (sets
  Car_usb). commonrows: OR2 and GRID `car_cornering = 0`. OR2 steer note: + right (G25 r 0.996).
* **ValueRecorder:** appends `Car_<output>` columns (all CommonValues.Outputs, from `Common.Get(i)`), written after
  Common.Update in the poll loop. RecorderTests check them.
* **USB device kept (Alexis asked: wheel lost, Find Devices needed):** FfbSettings gains `VendorId`, `ProductId`
  (learnt from the injected device descriptor). `FfbCapture.Apply` now only records `_wanted` and starts a 1 s
  watchdog (`Check`): lists devices (`Lister`), `Match` by name without "[n] " (prefers same hub and address,
  skips `_avoid`), starts USBPcapCMD; restarts after exits with backoff 2, 5, 10, 30 s; when quiet 5 s (no packets)
  re-lists at most every 30 s and follows a move; if started from the saved address without a list and the
  descriptor's IDs differ from the saved ones, avoids that address. Status "Waiting for <name>" when unplugged.
  `DeviceChanged` event -> plugin copies into Settings.Ffb and saves; CapturePanel shows the new address, Find
  Devices matches by name too, Find Devices tooltip. The FFB plugin's DeviceGUID is SDL's joystick GUID (VID/PID
  inside, e.g. 030000006d04000099c2...): explained in USB_Capture.md; USBPcap can't use it directly.
  FfbCaptureTests: Match cases, IDs learnt, restart after exit, moved address (16 -> 17), unplugged. WpfStubs
  ComboBox.IsDropDownOpen.
* **Game_Setup.md** (pack root, `tools/gamesetup.py`, run by memgames): head (set up the plugin first; USBPcap may
  be needed; OutputBlaster only where marked), tag legend, index table (game, profile, runs in, tags: TP shared
  memory, 64-bit, OutputBlaster, outputs, USB needed, USB adds, no car_ rows, checked), common steps per emulator,
  a section per game (process, OutputBlaster rows from `out_` use in TeknoParrot games, USB adds from missing
  car_impact/road_bump/cornering/vibration rows, Max speed/revs, curated NOTES, CHECKED). Linked from both READMEs.
* README: step 3 now starts with opening a new command prompt as administrator. Versions 0.16.0; README 0.16.0
  notes; USB_Capture.md "The wheel is found again by itself" and the hit-side rule.

### 3 November 2026, 21:15: GRID recording (20:21), USB matches

Details in `claude/GRID-capture-20261103.md`. FFB plugin Custom mode (`GRIDCustom.cpp`); the G25's USB force is
the plugin's formula from our own rows: `impact_side` (hit_strength / 8 by wall_side) one poll later in 828 of 872
hit frames; 0.49 sine at 32 of 32 gear changes; kerb sine w / 37. Skid/contact rumble not seen over USB. All marked
wall hits read the right side (+ right). Car contact side wrong at mark 4 (wall_side holds the last wall); car_contact
read 2 twice with a car on the right, 1 once: maybe the side, not confirmed (proposed using it, not built). Speed looks
like driven-wheel speed (clutch-drop jump, brake-lock dips, wheelspin flicks); peak 236 where the speedo showed about
257. Changes (memgames GRID block): notes "Checked in Alexis's recording of 3 November 2026"; Max speed 250; `accel_g`
slope 0.3 s, ema 0.15 s (wheelspin flick 17 G gone, locks still read hard braking). commonrows: GRID `car_road_bump = 0`
and `car_cornering = 0` (the force is only hits, gear sines and kerbs, so the USB stand-in would read gear changes as
bumps and wall force as cornering). Fixture `grid-20261103-202137` (USB force fed into `p.Ctx.Ffb`), `GridReplayTests`.
USB_Capture.md: caveat for effects-only forces. Pack README: GRID section, hook-games table row, checked-games lines.
Values CSV GRID row. No plugin code change (still 0.15.0).

### 3 November 2026, 20:45: plugin 0.15.0, the USB stand-in; BG4 files

* **USB stand-in (Alexis approved):** `CommonValues` fills `impact`, `impact_side`, `road_bump`, `cornering`,
  `vibration` (`UsbStandIns`) from the captured wheel force when the profile has no car_ row for them and
  `ffb[Connected] == 1` with a force reading: ema 0.15 s, kick = clamp(|force - ema| x 2), impact
  (kick - 0.5) x 2 above 0.5 with side sign(force), road_bump kick x 2 below, cornering = ema, vibration =
  rumble channel. Same as the pack's force-row rules. New output `Car_usb`. Setting
  `FfbSettings.UseForCommonValues` (default true), checkbox under the capture box in CapturePanel, applied
  in `ApplyFfb` to `Engine.Common.UsbStandIn`. A car_ row with formula `0` blocks it: commonrows gives SR3
  `car_road_bump = 0`. CommonValuesTests cover off, on, side, bump, rumble, gating, setting off, and a
  game's own row winning. USB_Capture.md section, README 0.15.0, SimHub_Effects.md, pack README updated.
  Compile check ok.
* **BG4 files** (d3d9.dll FFB plugin, ini GameId=13, OutputBlaster): Alexis's copy is Battle Gear 4 Tuned
  Japan (v2.07), the `BG4JP` profile. All seven addresses BG4JP reads (in_race 4A9508, contacts 42EBB1-3,
  shift 42ECF0, view 3F2654, speed 3F3000) are in her DLL and nothing more was found. The `BG4` profile is
  the export version (lamps only).

### 3 November 2026, 20:00: SWDC USB check; OR2 sources; USB for hook games (proposal)

* SWDC 19:30 recording, USB working: decoded force = wheel force (r 0.974, wheel a poll later, x 0.93);
  spring doesn't follow (FFB plugin's own spring). Fixture `swdc-20261103-193031`, checks in SwdcReplayTests.
* OR2 speed and gear come from the FFB Arcade Plugin's OutRun2Real/Fake.cpp (0x08273DF0 "speedo",
  0x0827A160 gear), revs from OutputBlaster's Outrun2SP.cpp (0x827A174). MasterRaver's OR2 table (Alexis
  sent it again) has only cheat scripts (car select timer 0x082932B0, stage timer 0x0830B748, velocity
  0x08279F4C/50/54): those became select_timer, stage_timer, vel_x/y/z.
* Proposal (built in 0.15.0, above): when the selected game has no car_ row for a force-based common value, the plugin
  works it out from the USB force (impact/road_bump from kicks, cornering from sustained force,
  vibration from rumble), so hook games (OR2's FFB, Cruis'n Blast, Cars, FnF, Hummer, MAME without
  force outputs) get those effects with USB capture on and nothing changes with it off. Per game,
  formulas can already mix: `ffb_*` read NaN with capture off, so `valid(usb_formula, memory_formula)`
  falls back. BG4 (export): the open-source FFB plugin has BG4JP only; Alexis has working FFB plugin
  files for BG4 to review.

### 3 November 2026, 19:30: plugin 0.14.0 (Car_throttle); WMMT5DX+ effects; SWDC recordings

* **Credit:** MasterRaver wrote the WMMT5DX+ Outputs script (moregames `OS` note, pack README, script
  doc). He's working on a WMMT6RR version.
* **Plugin 0.14.0:** new common source/output `throttle` (CommonValues.Sources and Outputs, commonrows
  COMMON). `Car_engine` x load, load = 1 without a car_throttle row, else 0.6 + 0.4 x throttle
  (`EngineOffThrottle`). Pitch unchanged. CommonValuesTests cover both. Compile check ok (mono-devel
  reinstalled in the sandbox: `apt-get install -y mono-devel`).
* **WMMT5DX+ (Alexis):** car_boost = clamp(turbo / 1.5, 0, 1); car_throttle = throttle; car_impact =
  max(game hit / 0.8, 0.5 + km/h lost in 0.3 s / 120) while the game's impact is non-zero (the 25.2 s
  hit reads 1, the light ones about 0.6). Blow-off, brake pedal, place, shift feel left as README notes.
* **SWDC recordings** (`claude/SWDC-capture-20261103.md`; fixtures swdc-20261103-175900 (80 s),
  -180418, -180640; `SwdcReplayTests`): v2.30. **No USB data** (activity 0): force not compared. TP slot 2
  = shift buttons (2 up, 1 down), unused. Loading revs 3000.0044 with speed 43.0/43.15 nonsense; countdown
  revs frozen 9326.5; finish: revs freeze at 30.00, spring to menu strength 30.02, speed nonsense 30.11.
  `in_race` = `revs > 3000 && maxw(delta(revs) != 0, 0.2) && minw(spring > 0.1, 0.1)` (spring 0.047 menu,
  0.17-0.99 driving): on 0.1-0.2 s after the rolling start, off at 30.01, never off while driving. `revs`
  raw unticked, `rpm` computed and gated; accel_g 0 for 0.3 s at race start. Hits: the game slows at a
  fixed 4.6-5.5 G for 0.1-0.4 s at every wall/car (10 hits); `hit` = slope(speed_kmh, 0.05) < -4 G;
  car_impact = max(force kick, 0.5 + km/h lost / 120), side only from force kicks. Car_vibration =
  vibration / 0.1 (game sends 0.016-0.11 on verges and wall grinds). speed1/gear1 nonsense in all
  recordings (kept unticked, asked). Speed changes at fixed rates (straight lines).

### 3 November 2026, 14:45: SWDC speed, revs and gear (Alexis's table)

Details in `claude/SWDC-table-20261103.md`. moregames `extend('SWDC')`: `rpm` (0 below 3000), `in_race` =
`rpm > 0`, `speed2`/`gear2` (her preferred; 0 until in_race), `speed1`/`gear1` unticked, `speed_kmh` =
2.0625 x raw + 0.005467 x raw² (17 speedo readings, within 2.5 km/h; raw isn't a fixed unit), `accel_g`
from speed_kmh. Max speed 87 (raw), Max revs 12200 (97% at about the 11800 redline). commonrows: SWDC
car_speed = speed2 raw, car_gear = gear2. Her CT is a test fixture (`swdc-20261103.CT`): MemProfilesTests
checks the rows read what the importer makes of it, plus the 3000-rev gate. Unverified in a recording.
1268 tests with the pack, 692 without.

### 3 November 2026, 11:30: WMMT5DX+ uses rpm2 and race_time2

* Alexis: Car_rpm from `valid(rpm2, rpm)` (commonrows WMMT5DXP case), **Max revs 8900** (memgames
  `wmmt(..., max_revs=8900)`; rpm2's limiter in 2nd about 8700); `in_race` from `valid(race_time2,
  race_time)` (moregames override); race_time2 restored. **No rows removed**: speed, rpm and race_time
  stay as fallbacks. rpm2 formula `value < 0 ? 0 : value / max_revs` (max() hid NaN, so no fallback).
  Tests: 1 November race replays with Max revs 8250 (no rpm2 in it); 3 November replay checks Car_rpm =
  rpm2, rev limiter only at the 2nd-gear limiter, in_race from race_time2 (blinks at a 0.15 s hitch at
  10.86 s, both clocks). 1254 tests with the pack, 692 without.
* Effects advised for 5DX+ (not built): turbo (boost feel and blow-off on lift), throttle-scaled engine
  load, brake pedal, place for lamps or overtake pulses, speed2-based hit strength. See the reply of
  3 November 11:30 and `claude/WMMT5DXP-capture-20261103.md` (turbo behaviour).

### 3 November 2026, 11:00: WMMT5DX+ recording; table order; merged rows

* **WMMT5DX+ 10:13 recording** (`claude/WMMT5DXP-capture-20261103.md`, fixture
  `wmmt5dxp-20261103-101336.csv.gz`, `Wmmt5OutputsReplayTests`): speed2 = speed + 0.3 to 0.85 km/h, no
  lag, 60 Hz: **Car_speed and accel_g now use `valid(speed2, speed)`** (commonrows WMMT5DXP case;
  moregames overrides accel_g). rpm2 = 1.285 x rpm - 1922 (sd 46): different scale, Car_rpm stays on rpm;
  asked which matches the tacho. race_time2 = race_time: removed. Throttle matched USB; distance matched
  the speed; turbo 1.5 / -0.5; place 1 (order 0-3).
* **Table order (Alexis, all games):** game values first (memory reads and rows from only tp_/out_/ffb_
  sources or the clock), speed then rpm then gear first; then calculated rows; then car_ rows. ob_ raw rows
  last among game values (oblamps re-inserts them each run, so this keeps regeneration stable).
* **Merged rows (Alexis):** a memory read used by only one stateless computed row that uses nothing else
  becomes that row (formula on `value`, computed row's name, tick and notes + " Raw: " + read's notes).
  WMMT5/6 gear done in `wmmt()` itself (one `gear` Byte row). The rest by the new step: BATMAN, H2OVERDRIVE,
  MKGPDX x3, SEGARACETV, SNOCROSS, SONICASR force; DAYTONA3 force_alt; H2OVERDRIVE spring; MKGPDX steer,
  hit; OUTRUN2SP steer; GRID road_rumble; M2DAYTONA position. Rows oblamps owns (ob_, out_, OutputBlaster
  notes) and car_ rows are never merged. Fixture columns renamed (WMMT5 gear_raw -> gear, OR2 steer_raw
  -> steer).
* **`tools/tidytable.py`** does both, run by memgames after commonrows (or `python3 tidytable.py <pack>`
  for hand edits). `TableOrderTests` checks every profile's order and that no alias or single-use read
  is left. Regenerating twice changes nothing. 1250 tests with the pack, 692 without.

### 2 November 2026, 20:30: SR3 answers; WMMT5DX+ Outputs script

* **SR3:** Max revs **7100**, Max speed **125 mph** (Alexis: a little room over the full effect; top
  130). The 6th-5th-6th in the water was her. Sr3ReplayTests checks Car_rev_limit is on 1 to 6% of the
  lap and Car_speed_frac reaches 1 only above 125 mph; MemProfilesTests' SR3 scale checks updated.
* **WMMT5DX+ "Output Blaster Support" script** (`Outputs_Script.txt`, Cheat Engine Lua, author not
  stated): it fills a block Cheat Engine allocates (the same RaceActive...FrameCounter layout as the
  WMMT6RR block), so the plugin reads its sources. Its race root `[wmn5r.exe+1FD11B0]` is the checked
  gear row's pointer (+398), so it's the 5DX+ build. Added in moregames.py `extend('WMMT5DXP')`:
  `speed2` (Float root+BEC, mm/s, `abs(value) * 0.0036 / max_speed`), `rpm2` (root+D94), `turbo`
  (root+3F0), `race_time2` (root+2E4), `throttle`/`brake` (bytes 0 and 2 of Int32 +1FD5904/+1FD5A14,
  0-85, higher copy; raw rows unticked), `distance` ((root+A78 - [root+158]+28) / 1000 m), `place`
  (first of four Int32 at +1FD17E0 that is 0). Left out: shift light (script constant), goal-based
  distances, rivals, story rank, after-fire (memory scan). Not mapped to common values until a
  recording checks them. Full list in `claude/WMMT5DXP-outputs-script-20261102.md`.
* Pack README updated (SR3 values, WMMT5DX+ rows). 1232 tests with the pack, 692 without.

### 2 November 2026, 20:00: Sega Rally 3 recording (19:22)

Details in `claude/SR3-capture-20261102.md`. 86 s, one lap on manual, 12 markers and notes, USB
capture on. Fixture `sr3-20261102-192249.csv.gz` (raw speed mph, stored gear, rpm, lamp byte, tp_
slots, plus `usb_force`/`usb_steer`/`usb_throttle` for reference), `Sr3ReplayTests`.

* **Confirmed:** speed mph (four speedo readings within 3 km/h; top 130 mph = 210 km/h); gear -1
  before the driver's view, 0 neutral on the grid, 1 to 6 (game puts it in 1st at the start); revs
  limiter about 6930, 7397 overrevved on a downshift, 0 on the grid until the throttle; slot 2 decode
  = the USB force (r 0.94, USB 0.017 s later), + from the right = + steering right. Force range
  -0.67 to +0.73 (commands 5-15, 21-30).
* **The force is steering plus road texture:** the force_kick stand-ins fired all the time (old
  Car_impact 372 times in the lap, Car_road_bump over 0.3 42% of it).
* **New rows:** `hit` = more than 3 mph lost in one game frame (speed updates at 30 Hz), above
  10 mph, not within 0.2 s of airborne, held 0.3 s: all eight wall contacts, nothing else (car brushes
  0.5 to 2.4 mph a frame, water drag and engine braking up to 2.4, not caught). `hit_side` = sign of
  the last non-zero force on the tick before the drop (the game kicks the wheel towards the side hit):
  6 of 7 walls, a rear right-hand hit read left. `airborne` = `minw(force == 0, 0.4)` above 60 mph:
  both jumps, nothing else (longest other gap at speed 0.27 s).
* **commonrows.py:** SR3 car_impact from `hit`, 0.5 to 1 by mph lost in a frame (`/ 40`), car_impact_side
  `hit_side`, car_airborne; **no car_road_bump for SR3** (`elif ffb and pre != 'SR3'`).
  **oblamps.py:** `RPM_CHECKED` / `rpm_note()` give a checked rpm note per OutputBlaster game (SR3 now).
* Max speed 110 / Max revs 6600 at first (with 6600 Car_rev_limit was on 44% of the lap); changed to
  125 / 7100 at 20:30.
* Pack README "Sega Rally 3" section; game values sheet SR3 row filled from the recording.
  Regenerating twice changes nothing. 1221 tests with the pack, 692 without. Plugin code unchanged.

### 1 November 2026, 16:45: WMMT5DX+ full race (recording 16:22)

Details in `claude/WMMT5DXP-capture-20261101.md`. Alexis didn't want to annotate a long recording, so
the events were found from the data. Fixture `wmmt5dxp-20261101-162221.csv.gz`, `Wmmt5ReplayTests.Race`.

* **Gear is NOT stored one low** (reverses 29 October): five-speed car, gear_raw reached 5, 0 =
  neutral (rolling start; revving at a standstill). `gear = gear_raw` on all six WMMT5/6 profiles.
* **New `in_race` row** (`race_time > 0 && maxw(delta(race_time) > 0, 0.1)`): the race clock stops at
  the finish line (355.52 s; holds 334.191 = 5:34.191 on the results screen) and stopped during a
  16 s freeze (44.4 to 60.6 s, cause unknown; asked Alexis). commonrows maps car_in_race to it.
  Before, results-screen gear changes (5, 4, 3, 2) would have pulsed Car_shift.
* **airborne** now allows joint-sized kicks (no hit or held contact in 0.5 s) and is gated by
  `minw(in_race, 0.5)`: seven crests found (spring 0, revs up 700 to 1700), unnoted.
* **Max speed 230** (Alexis; 249 seen), **Max revs 8250** (soft limiter 8035 to 8237 in gear);
  `profile()` in memgames.py now takes max_speed/max_revs.
* Low-speed joints 0.21 from 15 to 100 km/h, one kick per axle; all caught.
* Tests: 1022 pass with the pack, 682 without. Plugin code unchanged (tests and fixture only).
* **Checked against video (17:26):** the freeze was a pause; all seven airborne spans were crests or
  dips (two with the rear wheels off), so airborne = "the car goes light"; four short strips (5 or 6
  kicks) were missed, so `rumble_strip` is now `maxw(avg(maxw(road_joint > 0, 0.07), 0.45) > 0.85,
  0.3)` (about five kicks; 3 to 4 kick bursts are two joints); every hit was a wall (time trial, no
  traffic); gear 5 confirmed. The game's on-screen timer counts down from 200 and isn't race_time.
* **Plugin 0.13.1 (17:35):** Alexis wanted Landing on every crest but softer where the wheels stay
  down. Rev jump doesn't separate them (29 October jump: +320 only), time light does (wheels off
  0.17 to 0.5 s of airborne, wheels down 0.04 to 0.14 s). `CommonValues`: `Car_landed` = 0.4 + 0.6 x
  clamp(time airborne / 0.25 s) for its 0.25 s pulse (`LandedMin`, `LandedFullAir`); applies to all
  games. On the 1 November race: 186 s 1.0, 92 s 0.9, 303.5 s 0.8, 101.7 s 0.74, 192.8 s 0.57,
  308.3 s 0.5. 1028 tests pass with the pack.
* **SR3 (2 November):** Alexis's `SR3.CT` added by hand (SR3 isn't made by memgames; regenerating
  keeps the rows): `speed` Float `<main>+74B25C` (/ max_speed, units unconfirmed), `accel_g`,
  `gears1` Int32 [`<main>+30B324`]+F4, `gears2` Int32 [`<main>+3D2508`]+340, `gear = gears1`
  (provisional). CT "Revs" = `<main>+5DBE84`, the address `ob_rpmfloat` already reads. commonrows now
  gives SR3 car_speed, car_gear, car_accel_g. Needs a recording: units, which gear candidate, neutral.
  Alexis asked why lamp rows are computed: the reads are Byte rows (`ob_startbutton`, `ob_viewbutton`,
  unticked); each lamp is one bit, and one byte carries two lamps, so the lamps are bit tests. Type
  "Float" on computed rows means nothing (formulas give doubles; the column is hidden for them).
* **2 November, 10:30 (plugin 0.13.2, pack):**
  * SR3 from Alexis: speed is **mph** in memory whatever the screen shows, Max speed 110, Max revs
    6600; gear stored 0 reverse, 1 neutral, 2 first ... 7 sixth, so `gear` is now the memory row
    (gears1 address) with `value - 1` (-1 reverse, 0 neutral, 1 to 6); gears2 dropped; `accel_g`
    uses x 0.44704 (mph) instead of / 3.6.
  * **oblamps.py rewritten: no more rows than the outputs need** (Alexis's rule). An output whose
    read nothing else uses becomes a Memory row with a `value` formula; an output that is just a read
    hosts it and other outputs refer to it by name; only shared reads get unticked `ob_` rows;
    OutputBlaster's intermediate values are inlined (BG4's lookup tables make 400-650 character
    formulas). `unconvert()` first restores out_ rows from earlier runs (recognised by notes), so
    hand-maintained profiles (SR3, SRG, ARCTICTHUNDER, ID7, ID8, DEADHEAT) are redone too. Pack 1312
    to 1232 rows; regenerating twice changes nothing. Memory-row formulas may refer to other rows
    (dependency order covers all rows).
  * **SimHub effects panel:** live values line and "provides" line removed (Alexis). Ticks are two
    rows, "Bass Shaker:" Seat, Pedal box, Gas pedal, Brake pedal, Clutch pedal and "Shaker Motor:"
    the same plus Fans. `EffectHardware` gained MotorPedalBox/MotorGasPedal/MotorBrakePedal/
    MotorClutchPedal (`Motors` = seat motors); `PedalEffects(gas, brake, clutch, box)`; pedal effects
    now go only in their own kind's file. File names unchanged.
  * Tests: 1036 with the pack, 686 without; compile check ok.
* **2 November, 13:00 (plugin 0.13.3, pack 107 profiles):** MasterRaver's cheat tables, OutputBlaster-only
  games, Model 2 Emulator, Supermodel, MAME and Flycast; OR2 Legacy profile. Full notes in
  `claude/CheatTables-and-emulators-20261102.md`. Generator `tools/moregames.py` (called from memgames;
  `add_hand` for WMMT3DXP). NetOutputsClient reads Flycast's hex values after its `game =` line. Fans
  tick back to "Fans (as motors)". commonrows: WMMT5/6 mapping needs `collisions` (6RR Plus has none);
  OR2 legacy shares OR2's impact mapping. Unchecked timers are `race_timer`, never `race_time` (that
  name gates the effects). Wmmt3ReplayTests skips memory rows from cheat tables (not in the old
  recordings). 1102 tests with the pack, 692 without; compile check ok.
* **2 November, 14:30:** pack grouped by emulator: `<pack>/<Teknoparrot|Flycast|MAME|Supermodel|Model 2
  Emulator|PC>/<PREFIX>/<PREFIX>.json` (`tools/packlayout.py`: group(), path(), files(), migrate(); every
  script and the tests' `PackFiles.Find` use it). Demul dropped (Alexis: obsolete). OR2: (superseded at 16:10,
  Legacy removed) never remove OR2 rows without instructions. Flycast "Broadcast Digital Outputs" note in the
  pack README and plugin README. TeknoParrot's own emulators (TeknoModel1/2/3, Viper, Vegas... per
  TeknoParrotUI CabinetOutputSettings) send MAME-protocol network outputs when the game's Outputs
  setting is "Network Outputs" (port 8000, CR): documented in Game_Outputs.md; TP-prefixed profiles
  for those games wait on the output names (asked Alexis to check). WMMT6RR output block from the
  table author (offsets 0x04 to 0x54: RaceActive, Speed, RPM, Gear, Throttle, Brake, BrakeLight,
  ShiftLight, Place, Turbo, RaceTime, Distance...) not added: it is what a CE script writes, so asked
  where the block lives and whether the script's source addresses can be shared.
* **2 November, 16:10 (pack 106 profiles, plugin still 0.13.3):** OR2 Legacy profile removed (Alexis);
  only OUTRUN2SP stays. Two OR2 recordings analysed (15:38 with notes, 15:30 without): full notes in
  `claude/OR2-capture-20261102.md`. New rows wall_hit, wall_side, g_fast, hard_hit (30 G), off_road,
  rumble_strip, time_left, checkpoint; rpm now `* 10` (oblamps RAW_RPM_FACTOR); Car_impact = crash,
  wall_hit or hard_hit. Or2ReplayTests on both fixtures. 1159 tests with the pack, 692 without; compile
  check ok. Asked: speedo at top speed (raw 431), Max revs (about 9300 suggested), auto or manual.
* **2 November, 18:30:** Alexis answered (speedo about 300 at raw 431; Max speed 280 km/h; Max revs
  9300; manual). OR2 MaxSpeed 400 game units (0.7 km/h each), MaxRevs 9300; accel_g/g_fast x 0.7;
  hard_hit 21 G and speed > 20; wall_side from side_hit_dir in the last 0.4 s; unticked ffb_wall,
  ffb_float. Third recording (automatic, flip) added to Or2ReplayTests. **Recordings store row
  outputs, not raw reads**: when making a fixture, undo a row's formula (OR2 rpm was raw x 10). Her
  OR2 FFB files: FFB plugin 2.0.0.53 32-bit (31 July 2024), GameId 35 (Real: hooks the game's FFB);
  OutputBlaster 32-bit (18 October 2024); nothing new. 1172 tests with the pack, 692 without.
* **2 November, 18:30: USB capture and the pack.** No pack profile reads USB values (`ffb_force`
  etc.); every Car_ value comes from memory, TeknoParrot shared memory or network outputs, so USB
  capture off changes nothing. It matters only for hook-made force feedback (FFB plugin or FFB
  Blaster drive the wheel; nothing in memory or shared memory): OR2, Cruis'n Blast, Cars, FnF,
  Hummer and others. Those lack the force-based common values (road bump, wall scrape, cornering,
  grip loss, vibration; hits unless rebuilt, as OR2 does). Table per game in the pack README
  "Without USB capture (USBPcap)"; USB_Capture.md and the plugin README corrected (TeknoParrot's
  shared memory is used by some games only; WMMT5DX+ and OR2 leave it at 0).

### Where things are up to (31 October 2026, evening): 0.13.0, SimHub effects

* **Common values** (`Core/CommonValues.cs`): `TPTelemetry.Car_*`, 32 outputs worked out each tick
  from the selected game's `car_` rows (16 sources: in_race, speed, rpm, gear, accel_g, impact,
  impact_side, wall_contact, road_bump, rumble_strip, off_road, grip_loss, cornering, airborne, boost,
  vibration). Effect values are gated by car_in_race (missing row = "connected"); speed_frac and
  rpm_frac divide raw speed/revs by Max speed / Max revs and are 0 while blank; derived: engine
  (0.35 + 0.65 x rpm_frac), engine_hz (25 to 60), rev_limit (8 Hz stutter at 97%), road, shift (0.15 s
  pulse), landed (0.25 s pulse), impact_left/right (far side 30%), wall_left/right, braking (-G/1.5),
  accelerating (G/0.8), corner_left/right (+cornering = turning right = load on the left). Raw speed,
  rpm, gear, accel_g, impact_side, wall_contact, cornering are not gated (gauges). Prefix "Car" is refused.
* **Pack:** `tools/commonrows.py` (run by memgames after oblamps, before gameformulas) gives every
  profile its car_ rows (305 in all), unticked at the end. It owns only the 16 exact names (GRID's
  `car_hit` and BG4's `car_contact`/`car_bump` are the games' own rows). FFB-only games get approximate
  impact/impact_side/road_bump/cornering from force_kick, force and force_smooth.
* **SimHub effects** (`Core/SimHubProfiles.cs`, `UI/EffectsPanel.cs`, settings `Effects`): ticks for
  seat, pedal box, gas, brake, clutch, rumble motors, fans; **Create TP Effect Profiles** writes
  `PluginsData\TPTelemetry\SimHub effects\TP Telemetry - Bass Shakers.siprofile` and/or
  `... - Motors.siprofile`: "Any Game" (GameCode null) profiles named TP Telemetry, fixed ProfileIds,
  stable ContainerIds, IncludeOutputSettingsInProfile false. Layout copied from Alexis's SimHub 9.9.4
  exports (tests/CoreTests/fixtures/simhub-9.9.4-*.siprofile; the tests check every field is present).
  Formulas are only `[TPTelemetry.Car_x] * scale` (0 to 100); slots: Mono = FrontLeft, Left/Right =
  FrontLeft/FrontRight, Front/Rear = FrontLeft/RearLeft (as SimHub fills them). Engine effects use
  ForceFrequencies with `[TPTelemetry.Car_engine_hz]`. Pedal and fan effects carry
  AssignToChannelGroup + ChannelGroupName ("TP Gas pedal", "TP Brake pedal", "TP Clutch pedal",
  "TP Pedal box", "TP Fans"): SimHub plays named effects only on outputs in Custom channel map mode
  (seen in Alexis's screenshot: per-effect rows, corner sub-rows, Channel 1-8 ON/OFF).
* **Decisions (Alexis, 31 October):** one SimHub game for all TP games; profiles imported once; no
  motion (SimHub's Motion section takes no custom effects; documented as a future option, as are
  belt tensioners, ShakeIt Wind, lights/gauges/lamps); fans as ShakeIt Motors outputs (ShakeIt Wind
  has no custom effects and reads SimHub's own speed); G-forces as cues on shakers; Engine effect
  separate from Rev limiter, pitch rising more than strength, 50% default; seat effects unnamed,
  pedals named. Lamps/LEDs/gauges are the next step (OR2 leader lamp to a single Arduino output,
  dimmable lights too).
* **Untested in SimHub**: importing the generated files, effect names (Description) showing, named
  pedal effects appearing in the Custom channel map grid, the strengths. Ask Alexis to import and report.
* Help: SimHub_Effects.md (plugin). Tests: 938 pass with the pack (682 without).
* **1 November:** pedal effects renamed "TP - Pedal Gas: Engine", "TP - Pedal Brake: Braking",
  "TP - Pedal Clutch: Gear Change", "TP - Pedal Box: ..." (`SimHubProfiles.PedalEffects`) and put in
  **both** files (pedal shakers can be bass shakers or motors; a named effect is silent until mapped),
  so pedal ticks make the Motors file too. `Car_wall_left/right` now follow the size of
  `car_wall_contact` (0 to 1), not just its sign. The dummy profile has `test_cycle`, `test_ramp` and
  `car_` rows: in each minute Collision, Wall scrape (left), Rumble strip, Road bump and Off-road take
  10 s each, ramping 0 -> 1 -> 0 (peak at 5 s), then a gear change every second for 10 s.
* **Game values sheet** (sent to Alexis as TP-Telemetry-game-values.csv, 1 November): 266 TeknoParrot
  driving games (TeknoParrotUI metadata genre Racing/Racer, minus trains and horse racing, plus wheel
  games of other genres and NAOMI/System 32/Type Zero sets named from their MAME set names), column A
  the TP Telemetry prefix where one exists (55), B the TeknoParrot profile, C the game; row 3 headers
  for values read off the screen: speed units, top speed (= Max speed), redline/limiter (= Max revs),
  idle revs, number of gears, gearbox, varies by car, jumps, ripple strips, off-road, boost, notes.
  Alexis will fill it in; use it to set Max speed / Max revs and to judge which effects matter per game.
* **WMMT3DX+ recording, 1 November 15:49** (47 s freeway, 22 markers: 1-13 and 15-20 after joints, 14,
  21, 22 after crashes; no video). Now `tests/CoreTests/fixtures/wmmt3dxp-20261101-154943.csv.gz`
  (time_s, marker, speed, rpm, gear, tp_jvs0-15, tp_connected), replayed by `Wmmt3ReplayTests.cs`
  (Feed and Replay in Wmmt5ReplayTests are now internal and shared). Profile reworked by hand:
  * `speed1`/`revs1`/`gears1` renamed `speed` (`value / max_speed`), `rpm` (`value / max_revs`),
    `gear`; the other candidates removed (all agreed in four recordings). MaxSpeed 220 (Alexis: the
    game's top speed; 230.5 seen), MaxRevs 8999 (limiter in the data). Gear is the gear in play
    (revs per km/h 102, 70, 48, 39, 33), 0 before driving.
  * Slot 9 (reflect) rules: `impact_now = abs(tp_reflect) > 0.95` (63 = hit), `impact_dir =
    sign(tp_reflect)`; `reflect_held = minw(abs(tp_reflect) > 0.3, 0.1)` (25 held while pushed
    along a wall); `wall_contact = minw(maxw(impact_now || reflect_held, 0.35), 0.3) ?
    valid(hold(sign(tp_reflect), impact_now || reflect_held), 0) : 0` (side from hits/held only: a
    -29 joint pulse at 44.26 s flipped it when the hold took any pulse); `road_joint` = pulses 0.3 to
    0.75 not near a hit, held or wall; `road_bump = clamp(road_joint / 0.52, 0, 1)`.
  * Results: all 19 joint markers, 41 joint pulses = 25 joints (pairs ~0.07 s apart, front/rear
    wheels); crashes right 24.06 (228 -> 68 km/h), right 42.76, left 45.46; walls 24.36-27.77,
    43.07-44.38, 45.77-47.09. 39 pulses at 23.0-23.35 s are joint-sized, unexplained. Old rules missed
    the left crash and road_bump fired on crashes.
  * commonrows.py: WMMT3DXP uses the generic speed/rpm/gear mapping now; `car_impact = impact > 0 ?
    clamp(0.6 + (-long_g_fast - 1.5) / 20, 0.6, 1) : 0` (1.00, 1.00, 0.94 for the three crashes);
    new `car_wall_contact`. Tests: 965 pass with the pack, 682 without.
  * Alexis's SimHub formulas reading `WMMT3DXP_speed1` etc. need renaming (pack README says so).
* **WMMT3DX+ recording, 1 November 15:54** (39 s, with a marker log; fixture
  `wmmt3dxp-20261101-155436.csv.gz`, `Wmmt3ReplayTests.Second`): gear 0 = neutral; this car has six
  gears; speed4/5 and gears4/5 are the same record a frame earlier. Marker 9 was two joints with no gap
  (0.23 s of 30/32), which the first `reflect_held` rule read as a wall, so `reflect_held` is now
  `minw(abs(tp_jvs9) == 25, 0.1)` (the scrape value has always been exactly 25). Everything else held:
  7/7 joint markers (7 and 8, which she was unsure of, are joints), crashes left, right, left with
  wall_contact on the right side each time. 982 tests pass with the pack; plugin compile check ok.
  Full table in `claude/WMMT3DXP-capture-20261101.md`.
* **Files for the next chat** (all sent to Alexis on 1 November, 16:10): TPTelemetry.zip (plugin
  0.13.0 source, tests, help files), TPTelemetry-GameProfiles.zip (pack), TP-Telemetry-game-values.csv,
  the two sample .siprofile files, and the project docs (this handover, capture notes, Properties doc,
  Binaries review, tools/*.py).

### Where things were up to (31 October 2026, morning)

* **Plugin 0.12.0** (not yet run on Alexis's PC; compile-checked and 560 tests pass with the pack):
  the settings page was reworked for low resolutions (640×480, her 800×600 CRT, SimHub's licence
  banner). See "Settings page (0.12.0)" in section 2.
* **Max speed / Max revs** per profile (`max_speed`, `max_revs` in formulas; blank = 1, minimum 1).
  The pack's `speed` rows are now `value / max_speed` and `rpm` rows divide by `max_revs`, so
  they're raw by default and 0 to 1 once the boxes are set (Alexis's choice: normalise on the rows
  themselves). `accel_g` uses `speed * max_speed`. OutputBlaster-derived `rpm` rows are now real RPM
  (OutputBlaster sends RPM / 100, / 10 on OutRun 2). WMMT3DXP's candidates are untouched.
* **Help moved off the page** into Formula_Reference.md, USB_Capture.md, Game_Outputs.md (plugin)
  and **Game_Formulas.md** (pack, generated by `tools/gameformulas.py`).
* **Next likely asks:** Alexis checking 0.12.0's layout on SimHub at 640×480 and 800×600; more
  recordings; settling the common-property set (see the Properties doc).

**Rule: keep Game_Formulas.md current.** Whenever a profile's formulas change, most often after
examining a recording Alexis posts, regenerate the pack (`python3 memgames.py <pack>`, which runs
`oblamps.py`, `commonrows.py` and then `gameformulas.py`), or for a profile memgames doesn't make
(WMMT3DXP, SR3...) edit it and run `python3 commonrows.py <pack>`, `python3 tidytable.py <pack>` and
`python3 gameformulas.py <pack>` on their own. When a capture changes what a game can provide (a new speed address, a real collision
value), update its mapping in `commonrows.py` too, so the SimHub effects get the better value. Ship the regenerated Game_Formulas.md
with the pack. It is written from the profiles, so never edit it by hand.

### Where things were up to (29 October 2026)

* **Plugin 0.11.0** is current and has been run on Alexis's PC (0.9.0 onwards): the 64-bit helper
  works (HELPERTEST passed, WMMT5DX+ reads correctly), USB capture works on her G25, the USB-row
  toggle button is in, and profiles evaluate their non-memory rows while waiting for the game.
* **Pack:** 30 or so profiles now read their lamps and outputs straight from game memory (translated
  from OutputBlaster's code); 49 outputs still need OutputBlaster. WMMT5/6 were reworked twice
  today from two WMMT5DX+ recordings (see section 3). Only WMMT5DX+ and WMMT3DXP have been checked
  against real recordings; everything else is unverified.
* **Last thing done:** the second WMMT5DX+ recording (17:48) read gear as stored one low (reversed on 1 November), the
  ripple strip detector (missed strips, flagged walls), and added `wall_contact` and `airborne`.
  The plugin code didn't change; only the pack, the generator and the tests did.
* **Next likely asks from Alexis:** more recordings (Sega Rally 3, WMMT3 comparison, WMMT5DX+ jumps
  and low-speed joints), checking them against her notes, and release preparation.

**Writing style for everything:** Australian English, no em dashes, first person, business-like
but approachable. Notes, READMEs and replies should be plain and direct.

---

## 1. What the project is

TP Telemetry is a SimHub plugin by Alexis, intended for public release. It publishes telemetry for
TeknoParrot (TP) arcade games, and any other game, that have none of their own. Values come from
four sources:

1. **Game memory.** Addresses come from Cheat Engine tables or from the FFB Arcade Plugin's sources.
   Each address is a module, a base offset and a pointer chain.
2. **TeknoParrot shared memory** (`TeknoParrot_JvsState`). This holds the force feedback commands
   TP sends to the cabinet. It needs no setup and survives TP updates.
3. **Game outputs** (lamps, LEDs, RPM and so on), received over MAME's network output protocol.
   OutputBlaster sends these for TP games; MAME and Supermodel can send them too.
4. **USB force feedback capture** (optional). This decodes the force feedback a wheel receives,
   through USBPcap. It's for non-TP games, and for checking the decodes above.

Users can add formulas, including time-series ones such as acceleration, slope, ema and hold. A
settings page in SimHub lists, ticks on and off, and edits the variables. Games are selected from
launch-script command lines, because Alexis uses an arcade cabinet.

### Alexis's setup

* Windows 10 and SimHub 9.9.4, which is **32-bit**.
* A Logitech G25 wheel. She asked whether a G923 is good for PID; that was discussed.
* An arcade cabinet that launches games from scripts. AutoHotkey works, with a 5 second sleep.
* A home PC with two GPUs driving an HD CRT.
* She records test data and video herself and sends timelines of what happened when.

---

## 2. Architecture and key facts

### Build and environment

* C#, .NET Framework 4.8, `TPTelemetry.csproj`, plugin version 0.13.0 (helper 0.13.0 too).
* `src/TPTelemetryHelper64/TPTelemetryHelper64.csproj` (net48, x64 exe) is built by the plugin's
  build (ProjectReference, no assembly reference) and copied beside `TPTelemetry.dll` in the output
  and the SimHub folder. It links Core's Model, Log, Sources, ProcessMemory, ChildProcessJob and
  Remote files, with `TPT_HELPER` defined (which leaves `PluginSettings` out of Model.cs).
* The SimHub folder comes from the `SIMHUB_INSTALL_PATH` environment variable, or
  `-p:SimHubPath=`. A post-build step copies the DLL into SimHub (close SimHub first).
* `UseStubs=true` builds against stand-ins in `tests/SimHubStubs`, for CI or non-Windows machines.
* There's a `nuget.config`. The `Microsoft.NETFramework.ReferenceAssemblies` package was removed
  because it caused error NU1100 on her PC.
* **Tests:** `tests/CoreTests` is a net8.0 console app that compiles `src/TPTelemetry/Core/**`.
  * Run `dotnet run` there. Set `TPT_PROFILE_DIRS` to the pack folder to test the pack too.
  * 560 tests pass (with the pack; 313 without it), 31 October 2026. New in 0.12.0: `References`
    (max_speed/max_revs), `Launch` (clipboard text), and a WMMT5DX+ replay with Max speed 320 and
    Max revs 9000 checking speed/rpm scale and everything else (accel_g included) is unchanged.
  * Replays of real recordings: `fixtures/g25-wmmt3dxp.pcapng` (FfbFormulaTests, self-contained),
    and two WMMT5DX+ recordings run through the pack's WMMT5DXP profile by Wmmt5ReplayTests:
    `fixtures/wmmt5dxp-20261029.csv.gz` (11:08, freeway) and `wmmt5dxp-20261029-174800.csv.gz`
    (17:48, strip, jump, walls, gears). The fixtures hold only `time_s`, `marker` and the raw memory
    columns, named after the profile's memory rows (so the gear column is `gear_raw`).
  * In the cloud sandbox, NuGet was blocked. Restoring with
    `dotnet restore --source <empty folder>` and then `dotnet run --no-restore` worked.
  * The sandbox had no .NET: `apt-get install dotnet-sdk-8.0` worked.
* **Compile-checking against the real net48 API in the sandbox:** `apt-get install mono-devel`
  gives `/usr/lib/mono/4.8-api/` (the .NET Framework 4.8 reference assemblies, no WPF). Run Roslyn
  (`dotnet /usr/lib/dotnet/sdk/<ver>/Roslyn/bincore/csc.dll -noconfig -nostdlib`) with
  `-r:` mscorlib, System, System.Core (and for the plugin System.Xml, System.Xml.Linq, System.Xaml,
  WindowsBase, Microsoft.CSharp, every `Facades/*.dll`, the SDK's Newtonsoft.Json.dll, and a
  `SimHubStubs.dll` built from `tests/SimHubStubs/Stubs.cs` plus a small WPF stand-in file).
  * Helper: `-platform:x64 -target:exe -define:TPT_HELPER` over the linked files. Gives a PE32+ exe.
  * Plugin: everything except `UI/*.cs`, plus a one-line `SettingsControl` stand-in. The WPF
    stand-in only needs Application, TextWrapping, Thickness, Control, ContentControl, UserControl,
    TextBox, ImageSource, Drawing, DrawingImage, Brush(es), Pen, Geometry and GeometryDrawing.
  * All of this is scripted: `sh tests/CompileCheck/compile-check.sh` (plugin with the settings
    page, helper, test target). `tests/CompileCheck/WpfStubs.cs` stands in for WPF; extend it if the
    UI starts using new WPF members.
* Namespace is `TeknoTelemetry`; the plugin class is `TPTelemetry`. The namespace was renamed to
  avoid a clash with the class name.

### Main files

| File | Contents |
|---|---|
| `src/TPTelemetry/TPTelemetry.cs` | Plugin class: start-up, properties, actions, command-line parsing |
| `Core/Model.cs` | `VariableDef`, `GameProfile`, `PluginSettings`, `MemType`, `Names.Sanitise` (`+` becomes `P`) |
| `Core/ProcessMemory.cs` | `ReadProcessMemory`; Toolhelp module snapshot (`TH32CS_SNAPMODULE32`); `<main>` module; 32-bit-safe IntPtr conversion (`ToIntPtr`/`ToAddress`); `Target64BitException` (carries the PID); `OpenPid` for the helper; `IGameReader` |
| `Core/Sources.cs` | `MemorySource` walks the pointer chain each tick (`Walk` returns a `ReadStatus`, `Describe` gives the status text); `PlanSlot`; `IMemoryReader`; `SourceContext` (`Memory`, or `Remote` for the helper) |
| `Core/Remote/` | 64-bit helper: `ReadPlan` (text format), `ResultsBlock` (shared memory layout, writer, reader), `HelperProtocol` (pipe framing), `HelperServer` (the helper's loop), `HelperClient` (plugin side), `HelperLauncher` (starts the exe) |
| `Core/Ffb/FfbTableRows.cs` | The settings page's "Add FFB values to table" / "Remove FFB values from table" button: 12 `wheel_<channel>` rows, recognised by formula (`ffb_<channel>` alone) |
| `Core/ChildProcessJob.cs` | Kill-on-close job object, used for USBPcapCMD and the helper (was nested in FfbCapture) |
| `src/TPTelemetryHelper64/Program.cs` | The helper exe: arguments, creates block and pipe, runs `HelperServer` |
| `tests/HelperTestTarget64/` | A pretend 64-bit game (values behind a pointer chain at 0x7E00_0000_0000) and its HELPERTEST profile |
| `Core/TelemetryEngine.cs` | 120 Hz poll thread with `timeBeginPeriod`; formulas evaluated in dependency order; attaches to the process; recorder; FFB, TP and output sources |
| `Core/Expressions.cs` | Formula parser and its functions |
| `Core/ValueRecorder.cs` | CSV recorder with markers; stops itself after 15 minutes |
| `Core/CheatTableImporter.cs` | Imports `.CT` files. CE stores pointer offsets reversed, so the importer flips them |
| `Core/ProfileStore.cs` | Profiles saved as `SimHub\PluginsData\TPTelemetry\Profiles\<PREFIX>.json` |
| `Core/Ffb/` | `PcapStream` (pcap and pcapng), `FfbDecoders` (Logitech classic, Xbox 360, Xbox One, Raw, G25 inputs), `FfbCapture` (runs USBPcapCMD) |
| `Core/TeknoParrot/TpSharedMemory.cs` | Reads the shared memory `TeknoParrot_JvsState`: 64 bytes, 16 int32 slots |
| `Core/Outputs/NetOutputsClient.cs` | MAME network output client |
| `UI/SettingsControl.cs`, `VarRow.cs`, `CapturePanel.cs` | Settings page, built in code (no XAML). CapturePanel replaced FfbPanel and SourcesPanel in 0.12.0 |
| `Core/LaunchLines.cs` | The clipboard text for Copy Commandlines (AHK v1, AHK v2, .bat) |
| `profiles/DUMMY.json` | Test-signal profile, using `REPLACE_` stand-ins and example formulas |

Data lives in `SimHub\PluginsData\TPTelemetry\`: `Profiles\`, `Recordings\`, captures, and
`TPTelemetry.log`.

### Settings page (0.12.0)

Alexis's requirements: usable at 640×480 and on an 800×600 15 kHz CRT; SimHub's free version
takes about 200 px at the bottom for its licence banner; scroll both ways, or wrap.

* The whole page is a `ScrollViewer` (both scrollbars Auto) around a `StackPanel`. `FitPage()` sets
  the page width to max(600, viewport) so WrapPanels wrap above 600 px and the page scrolls sideways
  below, and sets the DataGrid's height to the viewport height left over, never under 180 px (the
  page scrolls then). It runs on size, viewport and page-height changes, and when the Capture section
  opens or closes. Checked by Alexis on SimHub (31 October): works, apart from a 0.12.0 bug fixed in
  0.12.1, where the table shrank but never grew back. Cause: a ScrollViewer stretches content
  shorter than the viewport to fill it, so the page's ActualHeight included empty space. Fix: the
  page is VerticalAlignment Top, and "everything but the table" is the sum of the other children's
  DesiredSize, not page ActualHeight minus table height. **Keep it that way.**
* Top bar: Game, Add Game, **Import…** (one button: .json profile or .CT table, by extension),
  **Export…**, Delete Game, Open Profiles Folder, **Copy Commandlines To Set Game/Profile**.
* Removed: the command-line boxes, the "Properties:" hint line (prefix errors now show in the status
  line), the **Enabled** box (every profile is forced Enabled on load and import; the JSON field
  stays for compatibility), Add acceleration from selected speed, the Formula reference section
  (summary now a tooltip on the Formula column heading), the TeknoParrot slot and live output value
  lines, the long notes, the outputs on/off box (outputs forced on at Init; port kept).
* Game fields: Display name, Property prefix, Process (narrow, scrolls), **Max speed**, **Max revs**
  (LostFocus or Enter; blank = null = 1; below 1 becomes 1; saved in the profile as `MaxSpeed`,
  `MaxRevs`).
* Table columns: Export, Name, Source, Type, Module, Base offset, Offsets, **Raw**, Formula, Output,
  Status, SimHub property, Notes. Raw sits before Formula (Alexis wants it, tied to normalising).
  Type, Base offset and Offsets are hidden (DataTrigger on `VarRow.ShowAddress`) on computed rows.
  **Show address columns** (setting `ShowAddressColumns`) hides Source, Type, Module, Base offset,
  Offsets. The last row is a fixed **Connected** row (`VarRow.Connected()`, `IsFixed`): shows
  True/False and `TPTelemetry.<PREFIX>_Connected`; editing is cancelled in `BeginningEdit`, Move,
  Duplicate and Remove refuse it, and table indexes stop at `Variables.Count`.
* Row buttons: Add Row (memory row), Duplicate, ▲, ▼, Remove, Show address columns.
* **Capture table values and FFB** expander (closed by default): Record Values / Mark Event / Open
  Recordings Folder and the bindable actions (StartRecording, StopRecording, RecordValues, Mark);
  `CapturePanel` (one status line "TeknoParrot: … · Outputs: … · USB: …, N commands/s", Outputs
  port, Poll rate, USB capture box, Wheel, Find Devices, Decoder, Record 60 s Capture, Open Captures
  Folder, USBPcapCMD path); Add/Remove FFB values to table; a line pointing at the help files.
* Copy Commandlines: three blocks, each "Activate, wait 5 s, -switchgame"; `;` note lines to delete;
  without a SimHub game selected, only the Activate line and a note. Windows line endings.
* WpfStubs.cs gained ScrollViewer members, ScrollBarVisibility, SizeChanged, ActualHeight,
  DataGridComboBoxColumn.ElementStyle, BeginningEdit, VisibilityProperty, IsEnabledProperty; its own
  `Key` enum was dropped (WindowsBase's is used).

### USB values in tables (0.10.0)

* Profiles no longer ship with USB capture rows (WMMT3DXP's `wheel_*` and `*_usb` rows and the
  dummy's `wheel_*` rows were removed). Alexis wanted them off the main tables.
* Under **Capture table values and FFB** (was Force feedback and outputs), a button adds the 12 USB
  values (force, spring, damper, friction, autocenter, rumble, rumble_large, rumble_small, steer,
  throttle, brake, clutch) to the viewed game's table as `wheel_<channel>` rows, adding only the
  missing ones. When all 12 are there it reads **Remove FFB values from table** and removes every
  row whose formula is just an `ffb_` channel (renamed ones too, never bigger formulas). Removal
  asks first. The label is refreshed by the page's live-view timer.

### Profiles and variables

* A profile has: Id, DisplayName, Prefix, ProcessName, Enabled (always true since 0.12.0),
  MaxSpeed and MaxRevs (nullable; 0.12.0) and Variables.
* SimHub properties are `TPTelemetry.<PREFIX>_<name>`, plus:
  * `<PREFIX>_Connected`
  * `ActiveGame` and `SelectedGame`
  * `FFB_*`, `TP_jvs0`..`TP_jvs15`, `TP_connected` and `TP_Status`
  * `Output_<name>`, `Outputs_Game`, `Outputs_Paused` and `Outputs_Status`
  * `Recording`
* Each variable has:
  * Name and Enabled (ticked rows are published; unticked rows are still evaluated).
  * Source: Memory or Computed.
  * Type: Float, Double, Int32, Int16, Byte, Int64, UInt32 or UInt16.
  * Module, BaseOffset (hex) and Offsets (hex, applied from the base outwards).
  * Formula (`value` is the raw read) and Notes.
* **Module values:**
  * A module name, e.g. `BudgieLoader.exe` or `jgt.dll`. Modules are rescanned at most once a
    second, for DLLs that load late.
  * `<main>` means the process's own exe, whatever it's called. Added in 0.8.0.
  * Empty means BaseOffset is an absolute address.
* A profile with ProcessName blank reads no memory (`Source()` returns None). Its
  shared-memory and output formulas run whenever it's the selected game.
* **0.11.0:** a profile with a process that isn't running yet (or whose 64-bit helper is still
  starting) still evaluates every tick (`EvaluateWaiting`): rows not needing memory update, memory
  rows are NaN with "not attached", Connected stays false. Before, nothing ran until attach.
* **Reserved names:** `value`, `x`, `dt`, `t`, `g`, `pi`, `max_speed`, `max_revs`, the FFB channel names (`ffb_force`,
  `ffb_spring`...), and anything starting `tp_` or `out_`. The grid refuses them; default new names
  are `new_value` and `new_calc`.

### Formula language

* **Operators:** `+ - * / % ^ < <= > >= == != && || !` and `cond ? a : b`. Numbers are decimal
  only (no hex literals).
* **Game settings (0.12.0):** `max_speed`, `max_revs` from the profile's boxes (`GameProfile.Reference`:
  blank, NaN or under 1 gives 1), set on `EvalContext` in `Engine.Build`.
* **Maths:** abs, sign, min, max, clamp, round, floor, ceil, sqrt, pow, exp, log, sin, cos, tan,
  atan2, hypot, if, deadzone, map, valid, wrap.
* **Stateful:**
  * `slope(e, window)`, `avg`, `ema(e, tau)`, `minw`, `maxw`, `delta`, `rate`, `prev`
  * `unwrap(angle, period)`, `integrate`
  * `hold(e, cond)`, which starts as NaN, so wrap it as `valid(hold(...), 0)`
* **Bits:** byte(v, n), bits(v, shift, count), band, bor, bxor, shl, shr, signed8, signed16.
* **Identifiers:**
  * `ffb_*` from USB capture
  * `tp_jvs0`..`tp_jvs15` and `tp_connected` from TP shared memory
  * `out_<Name>` for game outputs. Spaces become `_`, so `out_Intake_Left` works (0.8.0).
* Acceleration from km/h speed: `ema(slope(speed, 0.1), 0.05) / 3.6 / g`. This was tested
  against a two-point derivative and is far less noisy.

### Choosing the game from a launch script

* Activate a game with `SimHubWPF.exe -triggeraction TPTelemetry.Activate_<PREFIX>`. Use
  `TPTelemetry.Deactivate` to select no game.
* **Two separate commands are needed.** SimHub ignores a second command on the same line, so the
  settings page shows two copyable command boxes: one activates the TP game, the other runs
  `-switchgame` for SimHub's own game. The AHK example uses a 5 second sleep.
* The selected game is the one shown on the settings page; command line and Game list share it.
* **Bindable actions:** `TPTelemetry.RecordValues` (toggles recording), `StartRecording` and
  `StopRecording` (0.8.0), and `Mark` (numbers an event in the CSV). Bind them in SimHub's
  **Controls and events** to wheel buttons.

### TeknoParrot shared memory

* `TeknoParrot_JvsState`: 64 bytes, 16 int32 slots. TeknoParrotUI creates it
  (`MemoryMappedFile.CreateOrOpen(..., 64)`).
* The plugin **only opens it, read-only**, retrying every second until it exists.
  * Before 0.8.0 it created the mapping if it was absent. That was removed: an elevated SimHub
    creating it first could lock out a non-elevated TeknoParrot. **Never reintroduce it.**
* Most games use slot 2.
* WMMT3 (61), Dead Heat (62), D1GP (55) and SRG (54) use slots 6 to 9 for spring, viscosity,
  centre offset and reflect, each scaled by 1/63.
* Decodes per game are in the pack profiles. They were worked out from the FFB Arcade Plugin.

### Game outputs

* TCP 127.0.0.1:8000. Lines look like `name = value\r`, plus `mame_start`, `mame_stop` and `pause`.
* OutputBlaster needs `OutputsSystem=1` in `OutputBlaster.ini`, and **Enable Outputs** ticked in TP.
* OutputBlaster identifies PC games by a CRC of the exe's header, and Lindbergh (ELF) games by
  reading signature values at fixed 0x08xxxxxx addresses.
  * That could be used to identify the running game automatically. It isn't implemented; it's an
    idea.

### USB force feedback capture

* Runs `USBPcapCMD -d \\.\USBPcapN -o - --devices N --inject-descriptors` and parses the pcap
  stream. A job object kills USBPcapCMD when SimHub closes.
* Needs SimHub running as administrator and the USBPcap driver (installed with Wireshark, or on
  its own). Wireshark itself is not needed.
* **Logitech classic (G25)** commands:
  * `11 08 xx 80` is constant force; `13` is stop.
  * `41 0b` is a spring, with its clip at byte 6; `21 0c` is a damper.
  * Inputs: steering = ((b4<<6)|(b3>>2) - 8192) / 8192. Pedals are bytes 5 to 7, inverted.
* The Xbox 360 and Xbox One rumble decoders are written but untested.

### Direction convention

* **+ = force from the right.** That is the FFB Arcade Plugin's `DIRECTION_FROM_RIGHT` (+1);
  `DIRECTION_FROM_LEFT` is -1.
* On WMMT3 with a G25, + matched right-hand corners and right-side hits. This is verified for the
  USB capture only; for each game's tp_ and memory decodes it's still a hypothesis.

### Read-only guarantee (a design rule)

* **Games:** `OpenProcess` asks only for `PROCESS_VM_READ` plus query information (falling back
  to limited query). There's no all-access, no writes, no injection and no hooks.
* **TeknoParrot shared memory:** `OpenFileMapping`/`MapViewOfFile` with `FILE_MAP_READ` only.
* **Outputs:** a TCP client that only listens.
* **USB capture:** USBPcap copies traffic; nothing is sent to the wheel.
* **Files:** written only under `SimHub\PluginsData\TPTelemetry\`.
* **Programs:** starts USBPcapCMD and Explorer; kills only its own USBPcapCMD (via a job object).
* The README has a "What the plugin touches" section saying all this. **Keep it true, and keep
  the 64-bit helper to the same rules.**

### Licensing and credit

* **TeknoParrot itself is not open source.** Its core (TeknoParrot.dll, BudgieLoader, ElfLdr2,
  TeknoMacaw and the rest) is closed and proprietary, with some games behind a subscription.
* **Open-source parts:**
  * TeknoParrotUI (the launcher and game profiles) is GPL-3.0 (LICENSE checked).
  * OpenParrot ("Open Source version of TeknoParrot") is GPL-3.0 (LICENSE checked).
* **Reference projects:** the FFB Arcade Plugin and OutputBlaster, both by Boomslangnz (now
  credited as a TP developer), both GPL-3.0 (LICENSE files checked).
* **Only facts were taken from them** (addresses, encodings, output names). No code was copied.
  Both are credited in the READMEs.
* Alexis supplied the FFB plugin's binaries (FFBPluginGUI.exe, DLLs). She has no permission to
  redistribute them; they were examined for information only.
* Some TeknoParrot DLLs were inspected only to check which are 64-bit. Nothing from them is in
  the plugin.
* **Closest to copied material:**
  * the Chase H.Q. 2 and Wacky Races force lookup tables (numbers taken from the FFB plugin's
    switch statements)
  * the OutputBlaster output names
  * **the pack's memory-read output rows (29 October 2026):** about 254 formulas that
    `obmem.py` translated mechanically from OutputBlaster's game code (its reads, masks, if/else
    and lookup helpers, rewritten as TP Telemetry formulas). They contain no C code, but they
    follow its logic line for line, so they are closer to a derived work than bare addresses
    are. The pack README's "only facts are taken" understates this.
  * All of these are functional data and are credited. **Recommendation:** release the plugin
    and the pack under GPL-3.0 (or at least the pack), and change the pack README's wording to
    say the output rows are translated from OutputBlaster's code.
* The plugin and the helper themselves contain no copied code. The only third-party library is
  Newtonsoft.Json (MIT), referenced from SimHub's own copy.
* **Still to settle before public release:**
  * The plugin has no LICENSE file yet. GPL-3.0 is the simplest choice, given what it learned
    from GPL projects.
  * Who made `WMMT3DXPexp.CT`? If not Alexis, the pack needs the author's permission or the
    file removed.
* TP game profile facts (executable names, emulator types, bitness) came from TeknoParrotUI's
  `GameProfiles`, `GameSetup` and `Metadata` folders.
  * The teknogods repo couldn't be reached from the sandbox; the public fork
    `github.com/dyzt/TeknoParrotUI` (up to date as of October 2026) could be cloned.

---

## 3. Game profiles pack (`TPTelemetry-GameProfiles`)

There's one folder per prefix, holding `<PREFIX>.json` (plus a `.CT` for WMMT3DXP). The README has
a table per section.

### WMMT3DXP (Wangan Midnight Maximum Tune 3 DX+)

* Process `BudgieLoader.exe`, 32-bit, ElfLdr2. Addresses were updated for TP's October 2026
  release, which broke the old ones. Hand-maintained (not made by memgames.py).
* **Since 1 November:** `speed` (`+650A74` +AA8), `rpm` (`+B79C90` +D0), `gear` (`+650A74` +AB4);
  Max speed 220, Max revs 8999. The other candidates (behind `+A65294`, and revs at `+58BC0`,
  `+61BECC`, `+80E8B0`) were dropped; WMMT3DXPexp.CT still lists them.
* **Types:** gear is Int32 (she insisted). Speed and revs are Float.
* **TP shared memory rows:**
  * `tp_spring`, `tp_friction`, `tp_center` and `tp_reflect`
  * `tp_force = clamp(tp_jvs8 != 0 ? -tp_center : tp_reflect)`
  * `grip_loss`, `cornering`, `impact_dir`, `impact`, `impact_side`, and from 1 November
    `reflect_held`, `wall_contact`, `road_joint`, with `road_bump` from road_joint (see "Where things are up to")
* **USB rows** (`wheel_*` and the `_usb` versions; removed from the profile in 0.10.0, the
  button adds the `wheel_*` ones back) were verified against her G25 capture: 57
  seconds of freeway, joints, slides, a wall graze and three crashes.
  * grip_loss reads 0 driving straight and 0.85 to 0.95 in the slides.
  * road_bump reads 0.77 to 0.89 at expansion joints and under 0.3 in smooth cornering.
  * impact_side read all four wall contacts correctly, the graze included. It uses the stronger
    kick within 0.3 s.
  * There's a timeline offset of about 1.2 s between video and capture.
* **Speed-based rows:** `impact_front`, `impact_rear`, `impact_long` and `impact_long_abs`. They
  fire on speed changes beyond 1.5 G slowing or 1.2 G speeding up. **The thresholds are
  untested.**

### TP shared-memory profiles (no memory addresses)

SR3, ID6, ID7, ID8, FORDRACING, ARCTICTHUNDER, DEADHEAT, D1GP and SRG.

* D1GP and SRG also read speed from memory, so their Process is set (`game.exe` and `racing.exe`).
* SR3 also reads speed, gear and revs from memory (`Rally.exe`), and is the only one checked on a
  recording (2 November 2026): hits and airborne come from speed and the force, not force kicks.
  They now wait for that program to be running.

### Memory profiles from the FFB Arcade Plugin (0.8.0, all unverified on real games)

These 37 profiles read the same addresses as the FFB Arcade Plugin. Process names come from
TeknoParrotUI.

| Profile(s) | Process | Notes |
|---|---|---|
| OUTRUN2SP, ID4, ID4JP, ID5, RTUNED, SEGARACETV, CRUISNBLAST | `BudgieLoader.exe` | Lindbergh or ElfLdr2; absolute 0x08xxxxxx addresses |
| DAYTONA3, DAYTONA3NSE | `Daytona.exe` | Direction swaps on tracks 2 and 4 when game_state is 22 |
| MKGPDX110, MKGPDX118, MKGPDXUSA | `MK_AGP3_FINAL.exe` | Pointer chains; kart telemetry from the FFB plugin's "Custom" mode |
| H2OVERDRIVE, DIRTYDRIVIN, BATMAN, SNOCROSS | `sdaemon.exe` | Raw Thrills |
| SEGARACINGCLASSIC | `d1a.exe` | |
| GTICLUB3 | `gti3japkey.exe` | |
| KODRIVE | `M-DriveR_RingWide.exe` | Initial D style decode |
| SONICASR, CHASEHQ2, BG4JP | `game.exe` | |
| WACKYRACES | `Launcher.exe` | Unsure whether Launcher.exe is the game process itself |
| GRID | `GRID.exe` | |
| RF3D | `TeknoMacaw.exe` | Module `jgt.dll`. The FFB plugin's own code refers to `spice.exe`, which is for SpiceTools users |
| CRAZYTAXI | blank | Not a TP game; it's the PC release |
| ID0V131, ID0V211, ID0V230 | `InitialD0_DX11_Nu.exe` | **64-bit** |
| IDTA | `GameProject-Win64-Shipping.exe` | **64-bit** |
| SWDC | `Todoroki-Win64-Shipping.exe` | **64-bit**; detects v1.03 or v2.30 from an "SDDS" tag |
| WMMT5, WMMT5DX, WMMT5DXP | `wmn5r.exe` | **64-bit** |
| WMMT6, WMMT6R, WMMT6RR | `wmn6r.exe` | **64-bit** |

* **Decode notes:**
  * The Initial D family packs a command into a UInt32: byte 0 is the command (132 force, 134
    spring, 133 vibration, 128 full spring), byte 1 is direction or period, and a UInt16
    strength sits over the top half.
  * Chase H.Q. 2 and Wacky Races strip lamp bits from the output word, then look the code up in
    the FFB plugin's table.
  * WMMT5/6 have tire_slip, spring, friction and collisions floats; see "WMMT5 and WMMT6" below.
* **Games needing the FFB plugin running:** R-Tuned and Sonic only switch force feedback on when
  the FFB plugin writes to their memory. TP Telemetry only reads, so run both.
* **Writes other tools make (none are in TP Telemetry):**
  * The FFB Arcade Plugin writes to R-Tuned's and Sonic's memory to switch force feedback on.
  * OutputBlaster writes a byte in Sonic & Sega All-Stars Racing to switch its outputs on
    (`obmem.py` flags any write it finds; Sonic is the only one). The SONICASR output rows and
    the pack README say to run OutputBlaster or the FFB plugin as well if they stay 0.
  * FFB Blaster is packed, so what it writes is unknown.
  * Checked 29 October 2026: the plugin and helper open games with `PROCESS_VM_READ` plus query
    rights only, open `TeknoParrot_JvsState` with `FILE_MAP_READ` only, and call no write,
    protect, hook or remote-thread APIs. The only memory the helper creates and writes is its
    own results block (`Local\TPTelemetryHelper64_<id>`), which the plugin opens read-only.
* **Not done:**
  * Cars (its force feedback comes through code hooks, so there's nothing to read)
  * The original Mario Kart GP DX
  * Flying, shooting and bike games
  * The emulators (Demul, Model 2, MAME, Supermodel)
  * Initial D The Arcade Season 5 (IDTAS5), which has no FFB plugin addresses yet
* **Lamp rows:** see "Outputs from memory" in this section; only the leftovers are `out_*` rows.
* **Generator scripts** (all in the project under `claude/tools/`): `memgames.py` builds the 37
  memory profiles and then runs `oblamps.py` over the whole pack; `obnames.py` reads OutputBlaster's
  output names; `obmem.py` translates OutputBlaster's game code. They need these sources cloned to
  the paths the scripts expect (`../ffbsrc/repo` and `../refsrc/ob`, relative to the scripts'
  folder). `git clone https://github.com/Boomslangnz/<repo>.git` works from the sandbox shell.
  * `Boomslangnz/FFBArcadePlugin`
  * `Boomslangnz/OutputBlaster`
  * Run `python3 memgames.py <pack folder>`; it reproduces the pack exactly (checked again 31
    October 2026), and a second run changes nothing. It ends by running `oblamps.py` and then
    `gameformulas.py` (writes the pack's Game_Formulas.md).
  * 0.12.0 changes in the generators: `mem()` gives `speed` rows `value / max_speed` and `rpm` rows
    `value / max_revs` (with a note); `accel()` and WMMT's accel use `speed * max_speed`;
    `add_rows` now replaces same-named rows (D1GP, SRG); `oblamps.py` turns OutputBlaster's RPM
    (`X / 100`, `X / 10`) into `X / max_revs` (`unscale`), GRID's hook RPM into
    `out_RPM * 100 / max_revs`, and `fix_rpm_rows` converts already-converted `ob_rpm / 100` rows
    (SR3) the same way. The generic output note no longer says "0 to 100".
* **Outputs from memory (29 October 2026):** `obmem.py` parses each OutputBlaster game file's
  `WindowsLoop`: reads (ReadByte/Int32/Float32/IntPtr, relative = `<main>`, absolute, pointer
  chains, `GetModuleHandleA("x.dll")` modules), locals, `if/else` (to `?:`; outputs set on only
  some paths become `valid(hold(x, cond), 0)`), switch-return lookup helpers (to nested `?:`),
  `floor` etc., `!!(x & m)` to `band(x, m) != 0`, C integer division truncation, `MaxScaleOutput`
  as 100. Anything else (hooks, other helpers, statics, loops, `Outputs->GetValue`, outputs also set
  outside WindowsLoop) is refused and the output keeps its `out_` row. `oblamps.py` swaps each
  profile's `out_` rows in place (same names), adds unticked `ob_` raw/intermediate rows before
  them, reuses identical existing memory rows, drops FFB outputs that only copy or scale an
  existing row, and sets ProcessName where blank (TeknoParrotUI GameSetup names). 254 output rows
  read memory; 49 stay on OutputBlaster (Batman, Cruis'n Blast, Dead Heat, GRID, part of
  H2Overdrive: hooks/state; ID4JP: OB only knows the export version; ID6: two versions with
  different addresses). Every conversion was compared with its C line by eye. Unverified in games.
### WMMT5 and WMMT6 (checked on WMMT5DX+ only)

From two recordings on 29 October 2026 (details in `claude/WMMT5DXP-capture-20261029.md`). All
six profiles share `memgames.py` `wmmt()`, so they all got the same rows.

* `collisions` (the float the game sends the wheel; a G25 got exactly it over USB):
  * joints and ripple strips: kicks 0.042 s (about 100 km/h) or 0.075 s (about 200 km/h) long, sized
    about 0.105 + 0.00086 x km/h (0.20 at 100, 0.30 at 215). A joint is 2 to 4 kicks; a strip is a
    kick every 0.1 s for as long as you're on it.
  * hits: 0.5 (0.78 in a big crash). After a hit the game holds 0.2 while the car is pushed along
    the wall, or sends 0.5 kicks about 0.1 s apart while scraping.
  * **+ = right, - = left** (confirmed on three walls).
* `spring`: 0.53 driving, less in slides and hits, 0 in big hits, on a jump, and before the race.
* `tire_slip`: - turning or sliding right, + left; 0.04 in corners, up to 0.12 in slides.
* **Rows now:** `gear_raw` (unticked, Byte) and `gear = gear_raw` (1 November: not stored one low,
  0 = neutral); `in_race` (race clock advancing); `road_joint` (short kicks only, not within 0.25 s of a hit or held 0.1 s);
  `rumble_strip = maxw(avg(maxw(road_joint > 0, 0.07), 0.45) > 0.85, 0.3)` (1 November; was 0.6 / 0.8); `impact`,
  `impact_side`; new `wall_contact` (-1/0/1, 0.3 s of steady contact); new `airborne` (spring 0
  with no hit nearby, seen on one jump: a guess); `grip_loss`; `accel_g`; lamps from memory.
* Lamps from memory work on 5DX+: View 1 blinks once a second in a race; red/green/blue/white/side
  stayed on (second lamp byte 240 throughout); interruption 0. The interruption button is the red
  "Intrude Change" button for linked-cabinet VS battles (wanganmaxi-official.com FAQ).
* The other five versions are unverified; their gear is assumed to be stored as on 5DX+.

### Other pack notes

* SR3, ID7, ID8, ARCTICTHUNDER now have processes (`Rally.exe`, `InitialD7_GLW_RE_SBYD.exe`,
  `InitialD8_GLW_RE_SBZZ_redumped_.exe`, `snow.exe`). The Initial D names are dump file names and
  may differ on Alexis's PC.

---

## 4. Problems solved (so they aren't reintroduced)

* **NU1100 restore error:** removed the reference-assemblies package and added `nuget.config`.
* **SimHub froze when the plugin was enabled:** start-up is hardened, dialogs have an owner
  window, and the poll thread is lighter.
* **"Arithmetic overflow" on reads:** IntPtr conversion in 32-bit SimHub. Use
  `ToIntPtr`/`ToAddress`.
* **Name clashes:** the namespace and class were both `TPTelemetry`, and the formula engine's
  `Window` class clashed with WPF's. Renamed the namespace to `TeknoTelemetry` and the class to
  `SampleWindow`.
* **A row named "value" froze the live view:** reserved names are now refused, and the live view
  tolerates errors.
* **The dummy profile froze when a memory row was added:** a blank ProcessName now means no
  source.
* **Duplicate profile files:** files are named by prefix, duplicates are merged, and only
  known-stale files are deleted.
* **The command line changed the active game but not the page:** the active game and the game
  being viewed are now one and the same.
* **FFB rows showing "-":** capture wasn't on. Rows now say why they have no value.
* **impact_side misread the first crash:** it now takes the stronger kick within 0.3 s.
* **Thread crashes (0.8.0):** the outputs client and the FFB capture caught exceptions only while
  running. Stopping them while connected could throw from a background thread and crash SimHub.
  Both now catch everything.
* **Flaky test (0.8.0):** "time increases" in the recorder test failed under load. It now allows
  equal times.
* **WMMT5DX+ ripple strip detector (29 October):** a duty-cycle rule (`avg(kick, 1) > 0.35`) missed
  strips at 100 km/h (shorter kicks) and fired on wall scrapes (0.2 held). Now detected from kick
  spacing, with held contact excluded from `road_joint`. Don't go back to duty cycle.

---

## 4a. Lessons learned (29 October 2026)

**Working with Alexis's recordings**

* She sends a CSV plus a timeline of notes and numbered markers. Her markers usually land 0.1 to 0.3 s
  after the event (she presses after feeling it); on WMMT3 the video sat about 1.2 s off the
  capture. Allow for both.
* Her notes are reliable for what happened, but not exhaustive (unnoted joints, an unnoted 2-3-2
  gear change). Treat extra events in the data as normal, not as errors.
* Recordings run at about 120 Hz (8 ms). Columns are `<PREFIX>_<row>`, plus `FFB_*`, `TP_jvs*`,
  `time_s`, `marker`, `attached`.
* USB capture can be connected but silent: the USB device index moves after a reboot. Both of the
  last two WMMT5DX+ recordings had no FFB traffic. Ask her to re-check the device when FFB_* is empty.
* Before writing a detector, look at the shape of the signal: pulse length, spacing and how they
  change with speed, across every recording available. A threshold tuned on one recording at one
  speed failed on the next.
* Always replay the recording through the real engine with the real profile (the
  Wmmt5ReplayTests pattern) and turn her notes into checks. That caught the rules that only
  looked right in Python.

**Formula engine facts that matter for detectors**

* Every branch and operand is evaluated every tick (`?:`, `&&` and `||` don't short-circuit), so
  stateful functions inside conditions keep their history. Safe to nest.
* `minw`, `maxw`, `avg` and `slope` keep at least two samples (one at or past the window edge).
  On the very first tick after loading, a window holds one sample, so `minw(x > 0, 0.1)` reads as
  "held". Unit tests must tick zeros first (MemProfilesTests has a `Coll(value, seconds)` helper).
* `avg` is a sample average, not time-weighted; fine at a steady tick rate.
* Turning a memory row into a computed row with the same name keeps its SimHub property
  (`gear` is now `gear_raw + 1`). Use this to fix units without breaking dashboards.

**Pack and generator**

* Change profiles through `tools/memgames.py` (and `oblamps.py`), never by hand-editing the JSON:
  a regeneration would undo hand edits. Regenerate into a scratch copy of the pack, `diff -rq`
  against the real one, then copy across only the expected files.
* `memgames.py` needs `../refsrc/ob` and `../ffbsrc/repo` beside the tools folder (clones of
  Boomslangnz's OutputBlaster and FFBArcadePlugin).

**Sandbox**

* No .NET by default: `apt-get install dotnet-sdk-8.0 mono-devel`. NuGet is blocked: restore from an
  empty folder (`dotnet restore --source <empty>`), then `dotnet run --no-restore`. Deleting `obj`
  means restoring again.
* Zip the plugin without `obj` and `bin` (`zip -qr out/TPTelemetry.zip TPTelemetry -x '*/obj/*' '*/bin/*'`).
* Downloaded binaries go in their own folder and are only inspected, never run. FFB Blaster is
  VMProtect-packed and closed: don't try to unpack it.

---

### Lessons learned (2 to 4 November 2026)

* **Ask what a structure is before naming it.** The GRID "car structure" was the HUD dial (`dialinterface` strings
  in the dump). A HUD/dash object is a good place to look in any game: it holds speed in the speedo's units, gear as
  shown, revs, the needle fraction (per-car limiter) and shift lights, and its address rarely moves.
* **Speed may be wheel speed.** GRID's FFB-plugin speed showed wheelspin and brake locks and varied against the speedo
  by car. Check speed against her speedo notes at several speeds and in two cars before trusting a scale.
* **One Max revs doesn't fit every car.** Look for the car's limiter or a needle fraction; `car_rpm_frac` takes it.
* **Cheat Engine .CT files list pointer offsets last first.** A "must end with offset" pointer scan finds nothing when
  the value sits inside an embedded object; scan without the filter and read the final offsets (284 = 258 + 2C).
* **Recordings store row outputs.** Undo formulas when building fixtures (x Max speed, x Max revs, x 37...), and when a
  row is renamed in the profile, rename the old fixtures' columns too.
* **Old guesses get disproved; say so.** car_contact looked like a side on one recording and was a count on the next.
* **USB capture losing the wheel** was the USB address moving (G25 mode switch, replug, reboot). 0.16.0 finds the wheel
  again by name and restarts USBPcapCMD itself.
* **TeknoParrot only loads OutputBlaster for games with an Enable Outputs option.** Where a row needs OutputBlaster and
  the game has no such option, find the value in memory instead (GRID's revs).
* **Her working style:** "just advise" means change nothing; she wants all deliverables served each time, without
  unpacked copies of files already inside a zip; Australian English, no em dashes.

## 5. Still to do

### From 31 October (0.12.0)

* **Alexis to check the new settings page on her PC** at 640×480, 800×600 and 1920×1080: scrolling
  both ways, the table height, the Capture section, the Connected row, Copy Commandlines (paste
  into AHK v1, v2 and a .bat), Max speed / Max revs, and whether SimHub's licence banner covers the
  bottom of the page.
* Set Max speed / Max revs per game from recordings (a run to top speed and the limiter, noting the
  speedo reading at a marker, also confirms the speed units).
* Decide the common properties (see Properties-and-common-set doc). Alexis likes the fractions;
  the per-row normalising is the first step.
* README of the pack still says "only facts are taken" about the OutputBlaster-derived rows (see
  Licensing).

### Testing and confirmation (needs Alexis's hardware)

* **WMMT5/6** (WMMT5DX+ checked against two recordings, 29 October; see section 3):
   * Done: + = right, gear (stored value, 0 neutral; 1 November), joints from 15 to 240 km/h,
     strips, three walls, one jump, memory-read lamps, finish line and results screen, Max speed
     230 / Max revs 8250.
   * Still to confirm: `airborne` against noted crests (seven unnoted in the 1 November race, plus
     45.1 and 55.3 s on the freeway run); the 1 November freeze; `power`; the other five versions'
     addresses; the second lamp byte stayed 240 before and after the race.
   * A USB capture alongside the next one, to re-confirm collisions = wheel force at low speed.
* **WMMT3DXP** (details in `claude/WMMT3DXP-capture-20261029.md` and `-20261101.md`):
   * Done 1 November: slot 9 rework (impact, wall_contact, road_joint), candidates trimmed.
   * Record joints below about 100 km/h (a joint reading exactly 25 for 0.1 s would count as a wall),
     a light wall graze with no crash, and a drift (slot 8 non-zero) over joints. Video helps.
   * Tune impact_front/rear thresholds from the two 1 November recordings (they have speed).
   * Gear read 2 and 3 at up to 187 km/h in capture 3; ask whether it was a different car.
1. **Sega Rally 3:** done 2 November (19:22 recording): decode, + = right, speed mph, gear, revs,
   hits, hit side, airborne. Still to see: car brushes (too small for `hit`), more jumps (airborne is
   from two), automatic, another car (top speed and limiter), the checkpoint and lap line.
2. **WMMT3 comparison recording:**
   * tick USB capture, then record a drive with markers;
   * confirm `tp_force` matches `wheel_force`, sign and scale;
   * confirm the spring scale lines up.
3. **WMMT3 speed, revs and gear candidates:** done 1 November (speed1, revs1, gears1 kept).
4. **Front and rear impact thresholds** (1.5 G slowing, 1.2 G speeding up): tune them from a
   recording with speed in it. A speed reset at a restart may read as a frontal hit.
5. **Each memory profile in the pack:** confirm it attaches with the Process given, that values
   move, the direction sign, and units (speed is assumed to be km/h). Most uncertain:
   * Wacky Races (Launcher.exe)
   * Road Fighters 3D (TeknoMacaw.exe)
   * GRID's absolute gear address
   * Sega Racing Classic's ranges
6. **Lamp rows:** memory-read lamps confirmed on WMMT5DX+ (View 1 blinking, RGB/white/side lit).
   Check another game's next (Initial D Zero has a four-level pointer chain). For the leftovers, confirm OutputBlaster's outputs reach the plugin on
   Windows (64-bit games need OutputBlaster 0.11's x64 DLL, OutputsSystem=1); the outputs client
   hasn't been tested on real Windows yet. USB capture already confirmed on her PC (29 October).
7. **USB capture on her PC:** working (G25, after re-selecting the device following a reboot).
8. **Xbox 360 and Xbox One rumble decoders:** need someone with a pad to test.
9. **Drift detection:** a recording brief for this was deferred by Alexis.

### 64-bit helper (built in 0.9.0; working on Windows since 29 October)

SimHub is 32-bit, so it can't read 64-bit games (WMMT5 to 6RR, Initial D Zero, The Arcade, SWDC).
0.9.0 reads them through `TPTelemetryHelper64.exe`. As built:

* **Start:** `ProcessMemory.TryOpen` throws `Target64BitException` (with the PID) for a 64-bit
  game. If `Engine.RemoteMemoryFactory` is set (the plugin sets it when SimHub is 32-bit), the
  engine starts a `HelperClient` for that profile instead of showing the error. Nothing blocks the
  poll thread: launching and plan sending run on the client's worker thread; `Poll()` only copies
  the block.
* **Launch:** random GUID names for the pipe (`TPTelemetryHelper64_<id>`) and the block
  (`Local\TPTelemetryHelper64_<id>`), passed as `--parent --pipe --block --rows`. The helper
  creates the block, then the pipe; the plugin connects to the pipe (10 s limit), then opens the
  block read-only. The helper goes into a kill-on-close job object and inherits SimHub's elevation.
* **Read plan:** plain text (`TPTPLAN 1`, pid, process, hz, gen, then one tab-separated row per
  memory row: module, base hex, offsets hex, type), max 1024 rows. A row's index is its
  `MemorySource.PlanSlot`. Sent at start and on every edit (`SetPlan`); the helper keeps running
  across edits.
* **Pipe protocol:** 4-byte length + UTF-8. Helper sends `HELLO 1 <pid>`; plugin sends `PLAN\n...`
  (reply `OK <gen>` or `ERR ...`) or `STOP`. Closing the pipe also stops the helper.
* **Results block:** 256-byte header (magic `TPTH`, version, capacity, row count, plan generation,
  game state, game PID, helper PID, sequence, heartbeat, 200-byte UTF-8 message), then 24-byte rows
  (double value, int64 address, int32 status, int32 level). All header fields are int32 so the
  32-bit plugin can't tear them; rows are protected by the sequence (odd while writing).
  Results only count when their generation matches the latest plan sent.
* **Game states:** Opening, Attached, Exited (also when the PID now belongs to another program),
  Error (open failed; message says why).
* **Failure handling:** the client reports Failed if the helper exits, its heartbeat stops for 3 s,
  it doesn't start within 15 s, or it refuses a plan. The engine then detaches with "... (trying
  again in 10 s)" and starts a fresh helper after `RemoteRetryMs`. Game exit stops the helper; the
  next run gets a new one. Helpers are disposed on a thread-pool thread so the poll thread never
  waits.
* **Read-only:** `OpenProcess` with `PROCESS_VM_READ` plus query rights only (same `Open` code as
  the plugin). The helper writes only its own block and pipe, writes no files, and exits on STOP,
  pipe close, or SimHub exiting (checked once a second). README's "What the plugin touches" says so.
* **Tests (CoreTests/RemoteTests.cs):** plan round-trip and refusal, block round-trip, torn-write
  detection, message truncation, framing, then the real `HelperServer` and `HelperClient` in-process
  over a real named pipe and an anonymous memory map, against a fake 64-bit game: values above
  4 GB, statuses, edits, game exit, helper death, hung helper, missing exe, start-up timeout, and
  the engine end to end (attach, carry over an edit, exit, re-attach, retry after a dead helper,
  dispose). Also the HELPERTEST profile against a fake laid out like the test target.
* The pack's 64-bit rows now say "read through TPTelemetryHelper64.exe (plugin 0.9.0 or later)"
  (memgames.py `BIT64` updated to match).
* **Confirmed on Windows (29 October 2026):** HELPERTEST passed on Alexis's PC (module bases above
  4 GB, pointer chain, errors, exit and re-attach), then WMMT5DX+ read correctly for a 79 s drive.

### Recommendations

1. **Licence before release:** add a LICENSE (GPL-3.0 is the simplest, given the GPL references),
   and settle who wrote `WMMT3DXPexp.CT`.
2. **Give the pack a version and a changes list.** It changed three times on 29 October alone, and
   users can only update by deleting and re-importing a profile. A version in each profile's
   DisplayName or notes, or a `CHANGES.md`, would show whether they have the latest.
3. **A kick-counting function** (say `edges(cond, window)`, counting rising edges in a window)
   would make strip, joint and scrape rules simpler and independent of tick rate. Worth adding in
   the next plugin version if more games need it; the WMMT3DXP slot 9 rework would use it too.
4. **Port what worked on WMMT5 to WMMT3DXP:** a `wall_contact` row and the strip-by-spacing idea,
   on slot 9 (tp_reflect) directly.
5. **Ask for focused recordings,** one behaviour per run, with a USB capture ticked and checked:
   a few jumps and crests (airborne), joints at 60 to 100 km/h, a long wall scrape each side.
6. **Keep each recording as a fixture** (trimmed to raw columns, gzipped) with its notes turned
   into checks. They are the only ground truth the project has.
7. **Release prep:** a short first-run guide, screenshots, and a list of verified versus unverified
   games in the pack README.

### Other ideas raised

* **Identify the game automatically:** use OutputBlaster's method (exe header CRC, or ELF
  signatures for BudgieLoader) instead of relying only on launch scripts.
* **More than one process name per profile** (`a.exe;b.exe`), for games whose launcher differs
  between setups.
* **More profiles:** IDTAS5, and other games OutputBlaster supports but the FFB plugin doesn't.
* **Public release prep:** the release notes and versioning are there. Consider a changelog,
  screenshots, and a short "first run" guide in the README.

---

## 6. Answers already given to Alexis (don't re-explain unless asked)

* "USB capture" means the plugin's own capture tick box, which uses the USBPcap driver. It is
  not Wireshark.
* TeknoParrot shared memory needs no switch; it's always read.
* Recording and Mark are bound in SimHub's Controls and events. RecordValues toggles;
  StartRecording and StopRecording are explicit.
* The plugin needs no "activating" itself first; activating a game is enough.
* Importing a profile never overwrites an existing one; a clash gets a number added
  (WMMT3DXP2). To replace a profile, delete the old one first.
* Copying profiles by hand: back up `PluginsData\TPTelemetry\Profiles\` and close SimHub first.
  The build doesn't copy profiles.
* The README goes only inside the pack and the plugin zip, not sent as a separate file.
* She only cares about 64-bit builds of FFB Blaster, the FFB Arcade Plugin and OutputBlaster
  (the plugin runs on 64-bit Windows even though SimHub is 32-bit). FFB Blaster takes precedence
  where sources disagree, but it is packed and closed; no address changes came from the review.
  Use OutputBlaster v0.11 x64 for 64-bit games (`OutputsSystem=1`, port 8000).
* She has no active TeknoParrot subscription, so FFB Blaster isn't running on her setup; the FFB
  Arcade Plugin is what drives her wheel on WMMT5DX+.
* The WMMT5DX+ interruption button is the red Intrude Change button (linked-cabinet VS battles).
* (30-31 October) Properties exist for every imported profile's ticked rows whether or not it has
  ever been active; inactive or unattached rows read 0 (details in the Properties doc). Per-profile
  names only; a common set is proposed. Raw speed and revs can't be common (units and ranges differ),
  hence Max speed / Max revs. OutputBlaster's RPM was public (v0.10 release notes) but only in
  hundreds. MAME (`output network`) and Supermodel (`-outputs=net`) need no OutputBlaster; the
  Model 2 Emulator's outputs come from OutputBlaster (set `OutputsSystem=1` there). Going network
  means MAMEHooker stops getting that emulator's outputs. All of this is in Game_Outputs.md.
* Formula_Reference.md lives in the plugin (the language); Game_Formulas.md lives in the pack (each
  game's formulas), so each ships with what it describes (Alexis chose this, option C).
* The Record 60 s Capture button stays (for adding wheel support; USB_Capture.md explains why).
* The caveats (games that need the FFB plugin running, such as Sonic and R-Tuned; OutputBlaster
  set-up) are in the pack README.
