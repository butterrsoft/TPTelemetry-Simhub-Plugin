# MKGPDXUSA captures, 11 November 2026

Alexis's first USA recordings with plugin 0.18.1. All three read the USA game; the profile's addresses come from
`claude/MKGPDXUSA-exe-20261111.md`. Race time isn't on screen while racing in either Mario Kart, so times below are recording
times.

| Recording | What | Read |
|---|---|---|
| `20261111-142810_MKGPDX118-4` | USA game, but the v1.18 profile left selected | nothing from the game (as expected); only USB and JVS |
| `20261111-143354_MKGPDXUSA-1` | Bowser Jr cup course 3, three laps from 6th, 2nd at the line; 34 marks | everything |
| `20261111-151213_MKGPDXUSA-2` | Bowser Jr cup course 2, three laps, won; 20 marks | everything |

The two USA recordings are test fixtures (`mkgpdxusa-20261111-143354.csv.gz`, `mkgpdxusa-20261111-151213.csv.gz`, raw
reads from 40 s; `MkUsaTests.cs`). Her video of the first stopped early, so its questions went to the second.

## What the rows showed

* **Race:** race state 1 loading, 3 fly-over, 4/5 countdown, **6 GO to the line**, 7 after the line (the game drives), 9
  menus, then unreadable. The FFB plugin's race flag runs from GO to 2 s after the line (v1.18's ends at the line), so
  `racing` (state 6 with the flag) ends at the line. The menus were reached in both (253.6 s in the second).
* **Speed and revs** (kart +958, +95C): 168 km/h median, 236 at the most; revs 8270 median, up to 15,000 boosted. Max speed
  160 and Max revs 10000 as in v1.18. `speed_snd` (+558) is filled after all, like v1.18's, equal to speed half the time.
* **Steering:** `steer` matches `steer_jvs` (v1.18's byte moved with the I/O block) exactly; `steer_jvs` stays unticked.
* **Force / drift angle** (+2FC): the USB wheel force follows `force` (r = 0.97). In drifts with the angle over 10 degrees
  the sign agrees with `drift_side` (1 = left, angle negative) over 90% of the time: **+ right-hand**, as in v1.18.
* **Place, laps, race time:** 3 laps; place updates once a second; race time 153.242 s at the first race's line, 150.192 at
  the second's (16 ms a frame, 0.96 of real time). `race_timer_1c` is 250 s less the race time.
* **Kart states:** the same numbers as v1.18 (the exe's off-ground list is the same): 1 hop, 2 drift, 3 a bump (an item from
  behind), 17/18 glide, 22 grid. New: **7 a bomb blast** (thrown skyward spinning on several axes, 3 s; 123.1 and 134.8 s
  in the second recording), **11 tumbling in the air after an item** (3.2 s; 131.6 and 192.8 s in the first), 9 a steep
  drop after the glide on course 3 (101.5 s, 1.5 s).
* **Surfaces (her names, Bowser Jr cup courses 2 and 3):** 8 smooth floorboards (most of the lap; off-road 0.3 at her
  suggestion), 15 cloud (silky smooth; she first thought sand), 5 checkerplate metal, 9 carpet (the FFB plugin's list
  agrees), 2 separate sections of metal grille (a rumble strip, at her suggestion), 0 the boost ramps before each glide.
  Course 3 reads the same codes. Short checkerplate patches among the floorboards flick the code too, so they count as a
  rumble strip.
* **Lamps:** the moved lamp words change in the attract mode, the pre-race and the race, as on a cabinet (and as v1.18's
  do). The button byte's bit 8 (v1.18's driving lamp) only lights in the menus here. **The item lamp flashes** at times
  (gaps up to 0.17 s), so `item_held` now bridges 0.25 s.
* **Hits (second recording, her sides):** 78.1 left (passing a kart), 78.6 front right (a kart); 90.4 right, 93.5 front
  right; 146.6 front left, 148.2 an item from behind, 150.0 front right; 158.5 the right-hand wall, 159.3 a kart squeezing
  past on her right; 176.0 rear right (several); 187.5 an item bump; 213.2 the left track limit while airborne. `hit_side`
  reads every left/right one correctly and 0 for the item hits and the airborne one.

## Profile changes (memgames.py `_mk_derived`, shared by both versions)

* `spin` = states 6, 7, 10, 11; `knocked` adds 3 and 5. `hit_side` only in states 0 and 3, not within 0.5 s of a spin,
  threshold 0.06.
* `off_road`: verges (4, 11) and sand (14) 1, the planked bridge (10) 0.5, wood (8) 0.3; everything else 0.
* `rumble_strip`: code 2 (metal grille) as well as the flicking codes.
* `item_held` bridges the item lamp's flashes.
* Notes on race time (16 ms a frame), `race_timer_1c` (a 250 s countdown) and position (once a second).

## Still open

* The LED colour digits and the drift meter stage (as v1.18).
