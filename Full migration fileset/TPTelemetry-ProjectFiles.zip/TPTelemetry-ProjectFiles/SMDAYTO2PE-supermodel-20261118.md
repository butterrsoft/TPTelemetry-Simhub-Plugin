# Daytona USA 2 Power Edition in Supermodel (SMDAYTO2PE), 18 November 2026

A new profile, `SMDAYTO2PE` ("Daytona USA 2 Power Edition (Supermodel)"), in the pack's Supermodel folder. `SMDAYTONA2`
(force and lamps only, for the original Daytona USA 2) is unchanged. Alexis asked to focus on the Power Edition only.

## Files

* `supermodel.exe` 0.4-dev, git 0b82a98, MD5 440c8330529f89714047740b9b45831e (as Scud Race: `SMSCUD-supermodel-20261118.md`).
* `dayto2pe.zip` (Power Edition) with its parent `daytona2.zip`, and her NVRAM `dayto2pe.nv` (attached 18 November).
* The RAM pointer is Scud's: `[[<main>+AE6280] + 8] + game address`. Her Power Edition recording made with the SMSCUD
  profile read `ram_probe` (game address 0x100) as 2087778982, the same as Scud Race.

## Method

As Scud Race (the supermodel note): the same source with the logger patch, headless, ROM `GAME=dayto2pe.zip`, her NVRAM.
`menu_d2mt.sh` gets from the attract mode to a Beginner race with the NORMAL car and the manual gearbox (the wheel held
right while choosing). `aipath.py` and `autopilot.py` with `GAME=d2` drive along the computer cars' paths (`MANUAL=1 UP=8500`).
Three logged runs: d2 (menus and the start), d3 (from lap 4 with events: a poke of extra time, let go of the wheel, left,
right, brake; two big crashes; time up at TT 7914 frames), d4 (the whole race, eight laps, the finish 21st at TT 8788
frames, results, attract mode). Fixtures `smdayto2pe-emu-20261118-finish` and `-timeup` (tests `D2peTests.cs`).

## Game addresses

All in the PowerPC's view (bytes at A ^ 3, 16-bit at A ^ 2 in Supermodel's RAM; `sm_ram` does this).

| Value | Address | Notes |
|---|---|---|
| time left (RT) | 0x105010 Int32 | frames, 57 a second; 60 s (3420) at GENTLEMEN, START YOUR ENGINES; extended at lap lines; -1 at time up |
| race clock (TT) | 0x10500C Int32 | frames from GO; 7914 = TOTAL TIME 02'18"835 on the results (the screen counts thousandths its own way); the attract mode replays set it stepwise |
| in game | 0x1065E7 Byte | 255 from the course select to 3 frames after the clock stops (finish or time up); 0 in the attract mode, results, name entry |
| car records | 0x501000, 0x1000 each, 40 cars | the player first; Scud's layout moved |
| speed | +0x98 Int32 | km/h as on screen (14 readings, 93 to 275) |
| position x, y, z | +0x9C, +0xA0, +0xA4 Float | |
| matrix | +0xD0 | forward x +0xD8, forward z = -(+0xF0) |
| movement | +0xF8, +0xFC, +0x100 Float | metres a frame; against speed, correlation 0.999 |
| gear | +0x1D4 Int32 | 1 to 4 |
| revs | +0x1DC Int32 | (+0x1E0 the same); 8,500 on the manual limiter (her recordings; the emulator run's 9,480 in first gear wasn't seen in them); 10000 is a ceiling changing down too fast |
| steering | +0x140 Int32 | -32766 to 32766 |
| brake | byte +0x13F (word +0x13C) | 0 to 255 |
| throttle | byte +0x183 (word +0x180) | 0 to 255 |
| crash timer | byte +0x137 (word +0x134, 0x7F00xxxx) | 28 at a big crash (302 to 143 km/h into the wall, d3 frame 9159; again 10693), counting down |
| laps | u16 +0x118 | completed laps (8 after the finish); Int32 +0x10C stops at 7 |
| lap start | Int32 +0x168 | race clock at the last line |
| best lap, last lap | u16 +0x16C, +0x16E | frames (1062 = 18"626, 1088 = 19"085) |
| position | Byte +0x149 | 0-based (20 = 21st) |
| car class | Byte +0x85 | 1 NORMAL, 2 HARD, 3 SPECIAL (her recordings) |
| near car | Byte +0x81 bit 4 | another car within about 5 m, as Scud |
| road strips | Int32 +0x220 (centre), +0x224 FL, +0x228 FR, +0x22C RL, +0x230 RR | right wheels off the strip along the outside wall (d3, let go of the wheel) |
| car contact | Float +0x3C0 | how hard another car touches, 0.002 to 0.55, no side (her recordings: `car_contact`) |
| candidate speed | Float +0x2CC | 0.87 x km/h; unticked `speed_2cc` |

Not found: Scud's car-contact byte (+0x2F7 there) has no match here; a flag separating the rolling start's camera shots
(ROLLING START, AUTO DRIVE) from 3-2-1. No jumps on the oval, so no airborne row.

## Profile (generator: `moregames.d2pe_rows`, `commonrows` SMDAYTO2PE clauses; as of 17:10)

* `playing` = in-game byte 255; `countdown` = playing, clock 0, time left (the rolling start or the grid); `racing` =
  playing, time left, clock moving a frame at a time (held 0.1 s); `finished` = not playing, time left, clock set;
  `time_extended` for 2 s when RT jumps; `pit_stop` = time left unchanged over 0.3 s while racing.
* `hit`: 1 for a big crash (crash timer jumps); 0.4 to 1 touching another car (`car_contact`, by how hard, 0.2 s); speed
  lost while a wheel is off the strip or a car touches (0.4 at 10 km/h lost in 0.25 s, 1 at 46); never in a pit stop.
  `hit_side` from the wheels (edges exclusive); 0 for car hits.
* `drift_angle`, `drift`: Scud Race's formulas and scale (14 to 58 degrees); sign + right, as the steering shows.
* Force: Scud's 0.1 s hold after each roll command (`short_force`).
* Car_in_race from the start to the line or time up; every Car_ value 0 outside it. Max speed 350 (329 seen), Max revs
  8500 (the manual limiter).

Her recordings, changes and open questions: `SMDAYTO2PE-capture-20261118.md`.
