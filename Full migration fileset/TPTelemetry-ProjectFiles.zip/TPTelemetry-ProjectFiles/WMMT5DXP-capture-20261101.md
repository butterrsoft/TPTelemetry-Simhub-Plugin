# WMMT5DX+ recording, 1 November 2026 (16:22)

Recording `20261101-162221_WMMT5DXP.csv`: 396 s at 120 Hz, attached throughout, USB capture live
(G25). A whole race in a five-speed car. Alexis's notes: rolling start, braking almost to a stop,
then up through the gears; slowed to 80, 60, 40 and under 20 km/h to hit expansion joints; 249 km/h
or so top speed; markers loose (25 of them); finish line not marked. She asked for Max speed 230 and
Max revs from the recording. Fixture: `tests/CoreTests/fixtures/wmmt5dxp-20261101-162221.csv.gz`
(raw memory columns plus FFB_force, FFB_spring, FFB_steer), replayed by `Wmmt5ReplayTests.Race`.

## Timeline found in the data

| Time (s) | Race clock | What |
|---|---|---|
| 0 to 5.1 | 0 | before the start: spring 0, gear_raw 2, rpm 99999 for one sample at 1.1 s |
| 5.13 | starts | green light at 119 km/h; gear_raw drops to 0 (neutral), revs fall to idle |
| 5 to 11 | | braking 119 to 2 km/h (0.53 G average, 0.8 peak) |
| 12.5 to 12.9 | | revving to 8390 standing still in neutral (8437 peak), then 1st |
| 12.9 to 36.7 | | 1st to 5th: shifts at 53, 164, 194 and 213 km/h |
| 39.36 | | big left-hand hit, 223 to 128 km/h in one sample |
| 44.38 to 60.57 | frozen at 39.266 | the game froze for 16.2 s: speed 177 and revs 5780 held, View 1 lamp stuck on |
| 105 to 146 | | slow section: joints at 61, 63, 82, 48, 18, 15, 40 and 39 km/h (markers 10 to 13) |
| 143 to 146 | | down through 5, 4, 3, 2 to 1st, then a standing start in 1st |
| 173, 266 | | 240 km/h; strips at markers 14 to 17 and 21 to 24 |
| 336 to 338 | | 249 km/h top speed |
| **355.52** | **334.191** | **finish line**: speed and revs drop to 0 in one sample; the clock steps back to 334.191 (finishing time 5:34.191) and holds |
| 355.9 to 391 | held at 334.191 | results screen: gear_raw runs 5, 4, 3, 2; spring 0.53 |
| 390.5 | NaN | race data gone (back to the menus) |

## Findings

* **Gear is not stored one low.** The car has five gears and gear_raw reached 5. 0 is neutral: the
  rolling start leaves you in 0, and at 12.5 s the engine revved to 8390 with no speed in 0. So
  `gear = gear_raw`. The 29 October notes ("up to 4th" at raw 2 to 3) were off by one. The rpm
  per km/h is not constant within a gear (it drifts on the soft limiter and under load), so gear
  ratios can't settle this on their own.
* **Revs:** soft limiter. In 1st and 2nd the revs reach about 8035 and creep to 8237 while the car
  still accelerates; free revving in neutral reached 8437. The 29 October car topped out near 8500.
  **Max revs 8250** (97%, where Rev limiter comes on, is 8000). Idle about 1500.
* **Max speed 230** as Alexis asked (249 seen; Car_speed_frac is clamped at 1).
* **The race clock is the in-race signal:** it starts at the green light, stops at the finish and
  holds on the results screen, and stopped during the freeze. `race_time > 0` stayed true on the
  results screen, so gear changes there would have pulsed Car_shift. New row
  `in_race = race_time > 0 && maxw(delta(race_time) > 0, 0.1)` (the clock steps every second tick, at
  60 Hz). Off 0 to 5.13, 44.48 to 60.57 and from 355.62.
* **Low-speed joints:** 0.21 at every speed from 15 to 100 km/h (not falling as the 29 October fit
  suggested), each kick 0.033 s, one per axle: the front and rear kicks are 0.07 s apart at 200 km/h,
  0.13 to 0.17 at 60 to 80, 0.27 at 40 and 0.64 at 15 (a wheelbase of about 2.6 m). `road_joint`
  caught every one. Above 100 km/h joint size goes from 0.24 (160) to 0.27 (200 to 240). The FFB
  Arcade Plugin sends the wheel less at low speed (0.16 at 60, 0.07 at 15 km/h).
* **Crests:** the spring went to 0 seven times in the race with no hit before it (91.8 to 92.3,
  101.6, 186.2 to 186.8, 192.7, 303.5 to 303.7, 308.1 to 308.5 s). Each time the revs jumped 700 to
  1700 with speed flat or falling: the driven wheels lost grip, as over a crest. A joint-sized
  kick (0.25 to 0.29) usually came during or at the end of it, probably the landing. The old
  `airborne` rule refused any kick within 0.3 s, so it mostly missed these. New rule: `minw(in_race,
  0.5) > 0 && maxw(spring, 0.05) < 0.01 && maxw(abs(collisions) >= 0.35 || minw(abs(collisions) >
  0.001, 0.1), 0.5) == 0` (no hit or held contact in the last 0.5 s; joint kicks allowed). It also
  now fires at 55.32 to 55.40 s on the 29 October freeway run, just before the big crash, where the
  spring was 0 and the revs rose 7936 to 8203: the same signature. Unconfirmed: Alexis didn't note
  crests.
* **Hits:** 24 (0.5, and -0.754 at 210.27 s). No sustained wall scrapes, so `wall_contact` stayed 0.
* **Ripple strips:** `rumble_strip` on at all eight strip markers, 7 stretches in all. Five short
  runs of 5 or 6 kicks (182.2, 194.1, 218.8, 297.9, 308.3 s) weren't flagged; they could be short
  strips or close joints. At 220 to 240 km/h the strip kicks were 0.11 to 0.13 s apart (0.1 at
  lower speeds) and still detected.
* **tyre slip** is capped at 0.1125 by the game (1.9% of the race at the cap).
* **Braking and acceleration:** hard braking peaked at 1.2 G (Car_braking, -G/1.5, reads 0.8);
  launches reached 1.0 G (Car_accelerating full). No change made: Car_braking is plugin-wide.
* **Lamps:** first byte 1 before the start and on the results screen, 1/9 (View 1 blinking) in the
  race, 9 held during the freeze; second byte 240 throughout, results screen included.
* `power` read 0 again.

## Checked against the video (Alexis, 17:26)

Video time is within a second or two of recording time. The on-screen timer counts down from 200
(time is added during the race), so it is not `race_time`, which counts up.

| Recording | What the video shows |
|---|---|
| 44.4 to 60.6 s | Alexis paused the game |
| 91.8 to 92.3 | crest |
| 101.6 | crest, wheels down, then the wall hit |
| 186.2 to 186.8 | crest, rear wheels leave the ground |
| 192.7 | crest, wheels down |
| 303.5 to 303.7 | dip, rear wheels leave the ground meeting the far slope |
| 308.1 to 308.5 | crest, wheels down, small strip under the right-hand wheels as it lifts |
| 182.2, 194.1, 218.8, 297.9 | short ripple strips, no joints |
| 295.2 | slide, strip during the slide, then the wall |
| 200 | gear display shows 5 |
| 39.4 | left-hand wall (time trial, no traffic: every hit is a wall) |

So `airborne` is really "the car goes light": every one of the seven was a crest or dip, two with
the rear wheels off the ground (revs up 1260 to 1700) and four with them down (about 800). Kept as
one row; a split by the size of the rev jump is possible but rests on very few examples.

**Short strips:** 5 or 6 kicks over about 0.37 s, which the 0.6 s strip rule missed. Joints are one
kick per axle; two joints close together give 3 or 4 kicks over about 0.2 s (41.2, 165.6 to 167.6,
180.2, 181.1, 223.1, 292.1 s). New rule `maxw(avg(maxw(road_joint > 0, 0.07), 0.45) > 0.85, 0.3)`
needs about five kicks: catches all five short strips and the slide strip, none of the bursts, comes
on about 0.4 s into a strip. On 29 October it adds two six-kick runs of the same shape (11:08:
70.1 to 70.5 s, unmarked between joint markers 13 and 14; and 55.2 to 55.7 s, just before the big
crash) and stretches the 17:48 drift-over-strip to 30.06 s. Tests updated: 1022 pass with the pack.

## Pack changes (memgames.py `wmmt()`, all six WMMT5/6 profiles)

* `gear = gear_raw` (was `gear_raw + 1`); notes on 0 = neutral.
* New ticked row `in_race` (above); commonrows now maps `car_in_race = in_race != 0`.
* `airborne` rule above.
* Notes: rpm (soft limiter, pre-race nonsense), race_time (finish and freeze), tire_slip (cap),
  collisions and road_joint (0.21 at low speed, one kick per axle).
* `profile()` takes `max_speed`/`max_revs`; WMMT5DXP ships with MaxSpeed 230, MaxRevs 8250.
* Pack README WMMT5/6 section rewritten to match.

Tests: `Wmmt5ReplayTests.Race` (in_race, finish, freeze, no shift pulses on results, gears 0 to 5,
rev limiter in 1st/2nd and not in 5th, speed_frac, every low-speed joint, strip markers, two hits,
three crests, landing pulse); the 17:48 gear checks now expect 3rd/4th; MemProfilesTests stored
3 = 3rd. 1008 pass with the pack, 682 without.

## Still to check

* The freeze at 44.4 to 60.6 s was Alexis pausing the game (confirmed). Pausing stops the race
  clock, so `in_race` (and every gated effect) goes off while paused, as wanted.
* Landing on crests: Alexis wants it, but softer where the wheels stay down. Plugin 0.13.1 grades
  `Car_landed` by time airborne (0.4 after a brief lift, full after 0.25 s): 186 s 1.0, 92 s 0.9,
  303.5 s 0.8, 101.7 s 0.74, 192.8 s 0.57, 308.3 s 0.5. The rev jump wasn't usable (the 29 October
  jump, rear wheels off, raised the revs by only 320). Strengths to be judged in SimHub.
* Whether every WMMT5DX+ car stores the gear the same way (only two cars seen).
