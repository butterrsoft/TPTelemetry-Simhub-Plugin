# WMMT3DX+ recordings, 11 November 2026

Three recordings from Alexis on 11 November 2026. The first two were made with the old profile (cheat-table rows);
the third with the profile that reads the game's own variables (`claude/WMMT3DXP-exe-20261111.md`).

| Recording | Profile | What |
|---|---|---|
| `20261111-...-1` | old | a race; her last two marks are the finish line and the menus |
| `20261111-...-2` | old | the attract mode, 4.6 min |
| `20261111-183637_WMMT3DXP-3` | new | story mode, C class, Hakone inbound, manual, a different car; a jump at about 250 s; her last three marks are the finish line, the tuning menus and game over |

Times below are recording seconds; "left" is the game's time left (300 at GO).

## Recording 1 (old profile)

* Time left counted down from 64.0 s and froze at 286.67 s (80.77 left); her finish-line mark is 286.81 s, so the
  game stops the time at the line.
* Everything froze for 3.4 s at 98.98 to 102.38 s (not yet explained).
* 50 to 60 s: a drive before the race with time left at 3.0 (the same scene as recording 3's 34 to 43 s).

## Recording 2 (attract mode)

No race value changed in 4.6 minutes: the attract mode doesn't run the race code, so nothing gated on the race state
fires there.

## Recording 3 (new profile)

### Race gate

| Time | seq_active | race_state | What |
|---|---|---|---|
| 33.72 | 1 | | a drive starts (to 43.44) |
| 33.91 to 34.14 | | 1 then 0 | |
| 34.1 to 43.4 | 1 | 0 | a drive before the countdown: time left 3.0, race clock running from 0, starting at 120 km/h; she was on the throttle from 39.5 s and touched a wall at 40 s (53 km/h, first) |
| 43.45 | 1 | | the race proper |
| 43.6 | | 1 | countdown, rolling at ~119 km/h in fourth, throttle 0.64 |
| 47.68 | | 2 | GO: `in_race` and `Car_in_race` on |
| 263.76 | | 7, then 8 at 263.78 | finish line (her mark 263.70): `in_race` off |
| 276.35 | 0 | 0 | end of the drive |
| 326.15 | | | detached |

So the race gate does exactly what the code said: on at GO, off at the line, off in the countdown and menus.

### Speed, gear, revs

* `speed` (car +AE0 x 0.0036) matched the old `speed_ce` (the meter copy): median difference 0.1 km/h.
* `gear` (+300) matched `gear_ce` apart from a frame's lag at changes. At 103.3 s (left 244.4) `gear_ce` showed 6
  while `gear` held 5: the car looks to be a five-speed, so the meter copy shows the shifter, the game's row the gear.
* `rpm` (+2CC, rad/s x 60/2 pi) reads about 1,250 RPM above the old revs row right through (fit: game = 0.976 x old +
  1378). Highest 9,560 against the old row's 8,489; `rev_limit` 10,000; `rpm_frac` peaked at 0.956; `shift_light` on
  for 14% of the race. Revs per km/h are not in order by gear, so the gearing alone can't settle which is the tacho.

| Time | Left | Gear | km/h | Game revs | Old revs | Rev lamp |
|---|---|---|---|---|---|---|
| 45.00 | 300.00 (countdown) | 4 | 119 | 6,859 | 5,591 | |
| 48.33 | 299.35 | 2 | 106 | 9,430 | 8,341 | on |
| 147.00 | 200.71 | 4 | 138 | 8,557 | 7,367 | off |
| 248.60 | 99.14 | 4 | 136 | 8,934 | 7,783 | on |
| 252.80 | 94.93 | 5 | 141 | 9,323 | 8,219 | |

Asked Alexis for the tacho at these moments.

### Other rows

* `turbo` -0.5 to 1.2, `turbo_max` 1.2; `blowoff` 161 times, `backfire` 39.
* `wall_touch` 12 times in the race (111.07, 112.50, 113.15, 114.27, 116.32, 182.99, 195.32, 201.94, 239.41 and twice more there, 257.26); `car_touch` 40 times (55.33 s and 129.74 s with the rival
  1.9 and 3 m ahead).
* `reversing` stayed 0. `sections` and `sections_passed` read 2 throughout, so `checkpoint` never fired: story mode
  doesn't use the time keeper's sections (both rows now unticked).
* `rival_gap` -50 to +106 m; `leader` 82.6% of the race, two takes of the lead (behind at the start, ahead, passed,
  ahead again at about 130.5 s).
* `time_left` 300 to 83.98 at the line; `race_time` 216.06 at the line (time from GO).
* `throttle` and `brake` 0 to 1; `steer` -1 to 1.

### Slip angle and steering

`drift_angle` ran -37.8 to +29.1 degrees: 59 slides past 8 degrees, `Car_drift` 0.15 to 0.92. Against the wheel's
centre force it correlates -0.95 and against `steer` +0.71, so the sign is at least consistent with the force. Whether
+ is a right-hand drift (and steer + right) needs her video: 75.06 s (left 272.6) read +8 degrees with the wheel 0.82
right; 81.48 s (left 266.2) -8 degrees with the wheel full left, deepest -37.8 at about 83.7 s (left 264.0).

### Load on the tyres (new row, `load`, car +AE4)

The game works its wheel spring out from car +AE4 (spring = clamp(AE4 x 1.6 - 0.6)), a vertical load factor: 1 on the
flat, 0 in the air. The recorded spring (slot 6) went to 0 only over crests and at the jump, never with any contact:

| Time | Left | Spring 0 for | Notes |
|---|---|---|---|
| 50.45 to 50.65 | 297.2 | 0.20 s | crest (and a blip at 50.75) |
| 86.21 | 261.5 | a frame | |
| 197.82 | 149.9 | a frame | |
| 218.89 to 219.19 | 128.8 | 0.30 s | crest |
| 252.30 to 252.84 | 95.4 | 0.54 s | the jump: revs 7,411 to 9,362 with the wheels free, wheel slip to -0.31, no hit |
| 253.44 to 253.57, 255.24 to 255.40, 255.56 | 94 to 92 | short | bounces after it |

New rows: `load` (car +AE4) and `airborne` (`minw(seq_active && load < 0.375, 0.1)`), feeding `Car_airborne`. On this
recording that would have given 0.44 s at the jump and 0.2 and 0.1 s at the two crests.

`wheel_slip` (+AFC): about -0.09 cruising, more negative with wheelspin (-0.31 in the air, -0.54 against the wall at 239.4 s, -0.59 pulling away in first at 39.7 s), at most
+0.04 under braking. The earlier note (+ wheelspin) was wrong and is fixed.

### Marks (for reference)

| Time | Left | Near it |
|---|---|---|
| 55.56 | 292.1 | road joint; car contact 55.33; slide +13 |
| 59.76, 65.67, 73.73, 81.65, 83.70 | 288 to 264 | slides -22, +19, -26 (with a backfire), -17, -38 (at 81 km/h) |
| 99.35 | 248.3 | joint |
| 110.20 | 237.5 | joint, slide -14, rival leading |
| 112.65, 114.49, 116.45 | 235 to 231 | slot 9 hits from the left at 112.52, 113.15, 116.32; wall contact from 111.15; scrapes +1, -1, +1 |
| 123.60 | 224.1 | joint |
| 130.01, 130.55 | 217.7, 217.1 | car contact 129.74; back in the lead |
| 156.70 | 191.0 | joint |
| 161.10, 177.91, 191.56, 229.91 | 187 to 118 | slides +20, -27, +24 (with a joint), +29 |
| 239.62 | 108.1 | hit from the left at 239.43; slide -35 |
| 263.70 | 84.0 | finish line |
| 279.56 | | tuning menus |
| 311.90 | | game over, menus |

## Profile changes (11 November 2026, night)

* Added `load` and `airborne`; `Car_airborne` maps to `airborne`.
* Notes marked as checked in this recording: `speed`, `gear`, `in_race`, `time_left`, `race_time`, `rival_gap`,
  `leader`. `wheel_slip` note corrected.
* `sections` and `sections_passed` unticked (still read by `checkpoint`).
* `speed_ce` and `gear_ce` removed (the game's rows match them); `rpm_ce` kept unticked until the tacho is read.

## Alexis's answers (20:17)

1. Dial at 48.33, 147.0 and 252.8 s: about 7.6k, 6.8k and 7.5k. Neither the engine revs (9,430, 8,557, 9,323) nor
   the old row (8,341, 7,367, 8,219). The meter code (`yt::CSeq::Get2DInfoMeter`) sets the needle to
   0.96 x rev rate + 0.04 (5 x rate^2 + 0.05 under 0.1), rev rate = engine / this car's limiter (10,000): on a dial
   to 8,000 that is 7,560, 6,890 and 7,480. New row `tacho`; `rpm` stays the engine (Max revs 10000); `rpm_ce`
   removed. She calls the time left RT and the race clock TT (total time).
2. 34 to 43 s is the pre-race movie: effects from 43 s, where the driver's view starts (the countdown, race state 1,
   43.60 s). Same at 50 to 60 s in recording 1. The movie sets state 1 for 0.2 s at 33.9 s with the countdown held at
   4.0; the real countdown runs from 3.98. `in_race` is now state 2, or state 1 with the countdown under 3.99, and
   only while the race clock or countdown moves (0.25 s window), so a pause turns it off.
3. Signs right: right-hander at 75 s, left hairpin at 81 s. Steering + right too.
4. No traffic on Hakone: a 1-on-1 downhill. Both car contacts were her front right nudging the rival as she slid past.
   TeknoParrot's slot 9 read -59 for both (car hits read 59 of 63, under the 0.95 wall threshold).
5. Walls at 111 to 116 s: right (over a ripple strip in a left turn), left, right. These are 111.07 (+63), 112.50
   (-63) and 114.27 (+63): TeknoParrot's sides were right (my question misread them), and 116.32 (-63) is a fourth,
   on the left.
6. Crests: slightly light, more on the second, not airborne; a light effect is warranted. New `light` (load under
   0.5, held 0.1 s); `airborne` needs 0.25 s under 0.375 (the crests read 0.19 s and 0.08 s, the jump 0.48 s).
   `Car_airborne` 1 airborne, 0.3 light.
7. Recording 1's freeze was her pause.

## Recording 4 (20:15, old profile, traffic)

65 s, starting in the countdown (race state 1, countdown 3.82). Top speed 204 km/h in third; the rival 7 to 304 m
ahead. Her first eight marks (10.01 to 14.07 s) are road joints, one every 0.55 s at 200 km/h: `road_joint` caught
each. The rest are traffic hits and a truck shunting the car.

The game's car contact flag (+90) caught every hit, with its strength (+CC):

| Time | RT | TT | km/h | Strength | Speed change | Slot 9 |
|---|---|---|---|---|---|---|
| 19.30 | 284 | 0:15.467 | 204 | 6,309 | -25 | -59 |
| 19.81 to 20.65 | 284 | | 184 | 891 | rubbing | |
| 23.93 | 279 | 0:20.100 | 202 | 19,108 | -75 | -59 |
| 25.45 | 278 | 0:21.617 | 151 | 6,504 | 0 (sliding) | -59 |
| 25.95, then a right wall 26.08 | 277 | 0:22.117 | 149 | wall 13,517 | -29 | +63 |
| 30.36 | 273 | 0:26.533 | 169 | 4,464 | -15 | +59 |
| 30.73 to 33.62 | 273 | 0:26.900 | 157 | 983 | rubbing (slot 9 hits at 31.85, 32.55) | |
| 34.68 | 269 | | 176 | 655 | 0 | |
| 40.11 | 263 | 0:36.283 | 175 | 2,225 | -11 | +59 |
| 43.96 | 259 | 0:40.133 | 91 | 6,769 | +27 in a frame (hit from behind) | +59 |
| 50.08 to 51.75 | 253 | 0:46.249 | 57 | 15,026 | pushed along, braking | +59 |
| 52.86 to 53.85 | 250 | 0:49.033 | 112 | 2,260 | pushed along | +59 |
| 62.00 | 241 | 0:58.166 | 198 | 18,333 | -72 | -59 |
| 62.53 to 62.84 | 241 | 0:58.699 | 136 | 3,329 | -9 | -59 |

Live, `Car_impact` caught only the slot 9 wall-level hits (26.08, 31.85, 32.55): the profile's impact needs 63, and car
hits read 59. New `hit_car` = `maxw(car_touch ? clamp(sqrt(car_force / 15000), 0, 1) : 0, 0.15)` (a nudge 0.25, a swipe
0.4 to 0.65, a crash 1), added to `Car_impact`.

Slot 9's sign on car hits doesn't follow the wall rule (+ right): her two front-right nudges on the rival read -59, and
the hits from behind read +59. Raw rows added for the side (`carhit_*` +C0, `wallhit_*` +104: the push the game gives
the car, which `CMachine::HitReaction` and `WallReaction` turn with the matrix at +A4C; `mat_00`, `mat_01`, `mat_02`,
`mat_10`, `mat_20`), to work out from a recording with hits on known sides.

## Tests

`Wmmt3GameTests` replays recordings 3 and 4 (fixtures in the game's units, converted back from the recorded rows; `load`
from the spring slot): Car_in_race from the countdown (43.6 s) to the line and not in the movie, the tacho within 150 of
her readings, slide and steering signs, Car_airborne 1 at the jump and 0.3 at the crests, Car_impact at all 13 contact
starts, 1 for the two crashes and the truck, joints not hits. 1757 tests pass with the pack.

## Alexis's answers on recording 4 (20:42)

Where on her car each hit was, against TeknoParrot's slot 9 sign (59 of 63 on car hits):

| Time | Her answer | Slot 9 |
|---|---|---|
| 19.30 | front right | -59 |
| 23.93 | straight into the back of a truck | -59 |
| 25.45 | round the truck's left and hit it again on her front right | -59 |
| 30.36 | straight up the back of a car, grinding against it to RT 269 | +59 |
| 40.11 | a truck along her left side | +59 |
| 43.96 | slowed and hit by a truck from behind | +59 |
| 62.00 | straight up the back of a truck | -59 |

With her two front-right nudges on the rival in recording 3 (-59 both), every side hit reads the opposite way to wall
hits: -59 right, +59 left. Straight-on hits take the sign of whichever corner touched first; the hit from behind read
left. New `car_side` from it (held 0.15 s), and `Car_impact_side` = the wall side, or else `car_side`. So no capture is
needed for the side; the raw `carhit_*` rows stay unticked in case straight-on hits ever need sorting.

Dial: printed to 9,000 on this car and others, but the needle never gets there: its full travel ends at the 8,000
mark, which is what `tacho` uses. `Car_rpm` stays on the engine (her call). Course of recording 4 not known.

`Wmmt3GameTests` also checks the sides: right at 19.30 and 25.45 s, left at 40.11 s, right at both rival nudges.

## Open

1. A recording with the new profile when convenient, to confirm the countdown gate, the crest effect and car hits live.
2. The crest effect (0.3) and Car_drift for WMMT's shallower slides: by feel.
