# Daytona USA (daytona, Revision A) program ROM check, 8 November 2026

Built from the ROM files with MAME's layout: maincpu = epr-16722a.12 (offset 0) and epr-16723a.13 (offset 2), 16-bit interleaved, 256 KB (the range daytona.lua's lamp patch scans, 0x0-0x3FFFF). The main_data pair (epr-16724a.6 / 16725a.7) was scanned too: no RAM or lamp references, so no code there.

## RAM use (absolute MEMB addresses)

* RAM2: 373 addresses, nearly all 0x220000-0x23FFFF (147 in 0x22xxxx, 222 in 0x23xxxx; 4 below 0x220000).
* Work RAM: 0x500000-0x50FFFF 342 addresses (game state 0x5010A4 55 refs, time 0x5010D0 17, track 0x501460 76, countdown 0x501850 16; 0x5051EC has no absolute refs, it's reached through a base register), 0x530000 3, 0x540000 25 (link play), 0x5F0000-0x5FF400 92.
* Nothing addresses 0x500800-0x50083F directly (0x500824 is where daytona.lua moves the lamps).

## Lamps

The lamp port 0x01C0001E is addressed about 25 times, LDOB/STOB pairs from 0x1124 to 0x297B8 plus LD/ST pairs at 0x2C2DC and 0x2C454, all inside the 0x0-0x3FFFF range daytona.lua patches. That is why Daytona's lamps work at RAM+824 with the emulator's own script.

## Scripts changed

`SCRIPTS/daytona.lua` and `daytonas.lua` now log RAM2 0x220000-0x240000, work RAM 0x500000-0x510000 and 0x5F0000-0x600000, 4096 words a frame (whole set about every 16 frames, 0.3 s). The earlier guess (work RAM 0x500000-0x540000 and RAM2 0x200000-0x210000) missed both 0x22xxxx-0x23xxxx and 0x5Fxxxx. daytonas is assumed to match daytona.

## All three Model 2 games so far

| Game | RAM2 | Work RAM |
|---|---|---|
| STCC | 0x200000-0x219FFF (1070 addresses) | almost none (lda 0x520000) |
| Sega Rally (srallyc) | 0x200000-0x2197B0 (761) | 0x5A0000-0x5FD7EC (591), buffers at 0x500000/0x504000/0x505000 |
| Daytona (daytona) | 0x220000-0x23FFFF (369) | 0x500000-0x50FFFF (342), 0x5F0000-0x5FF400 (92), link 0x540000 |
