# WMMT5DX+ "Output Blaster Support" script, 2 November 2026

A Cheat Engine Lua script by **MasterRaver** (`Outputs_Script.txt`, supplied by Alexis; credited in the pack README). Every 25 ms it
reads race values from `wmn5r.exe`, writes them as 4-byte integers into a block it allocates
(symbol `WMMT5_Outputs`, offsets 0x04 to 0x54) and every fourth time to
`%APPDATA%\WMMT5DX_Outputs.txt`. This is the same layout as the WMMT6RR "outputs" block noted in
`CheatTables-and-emulators-20261102.md` (RaceActive 0x04 ... FrameCounter 0x54), which was not added
because the block is only what the script writes. The block moves every time, so the plugin can't
read it; the script's sources can be read directly instead.

The file says WMMT5DX, but its race structure pointer (`wmn5r.exe+1FD11B0`, gear at +0x348+0x50 =
+0x398) and car pointer (`+1F7D578` then +0x268) are exactly the WMMT5DXP profile's checked gear row
and its power row, so it is the 5DX+ build Alexis runs.

## Sources (root = pointer at wmn5r.exe+1FD11B0)

| Script output | Read | Added as |
|---|---|---|
| RaceActive | root pointer not null | not added (`in_race` is checked) |
| Speed | Float root+0xBEC, abs x 0.0036 = km/h (stored mm/s) | `speed2` = `abs(value) * 0.0036 / max_speed` |
| RPM | Float root+0xD94 | `rpm2` = `max(value, 0) / max_revs` |
| Gear | Int32 root+0x398 | already `gear_raw` (Byte, same address) |
| Throttle, Brake | Int32 wmn5r.exe+1FD5904 and +1FD5A14: byte 0 throttle, byte 2 brake, 0 to 0x55; the higher of the two | `pedals_a`, `pedals_b` (unticked), `throttle`, `brake` 0 to 1 |
| BrakeLight | brake > 0 | not added |
| ShiftLight | RPM >= 8000 (the script's own constant) | not added |
| Turbo | Float root+0x3F0 (shown x 100, -50 to 200) | `turbo` |
| RaceTime | Float root+0x2E4, seconds (sent in ms) | `race_time2` (feeds in_race from 3 November) |
| Distance | (Float root+0xA78 - Float [root+0x158]+0x28) / 1000, metres | `progress`, `start_ref` (unticked), `distance` |
| DistanceToGo, CourseLength | need a goal position typed in per course (default 12312741) | not added |
| FrameCounter | Int32 root+0xD4C | not added (could gate in_race) |
| StoryRank | Int32 [[wmn5r.exe+1F7D578]+0x268]+0xBC, 1 to 65 | not added (progress, not telemetry); the power row is +0xAC in the same structure |
| RivalCount, Advantage1-3 | pointers at +1FD1210/18/20, rival progress Float +0x898 | not added |
| Rival names | strings at +1F8DCF0, +1F8DEF0, +1F8E0F0 | not added |
| AfterFire | finds an object by scanning memory for its vtable (+0xF300E0), then +0x60/+0x68 | not possible (the plugin doesn't scan) |
| Place | Int32 x 4 at +1FD17E0: place = first slot holding 0 (the player) | `order1` to `order4` (unticked), `place` |

All in moregames.py (`extend('WMMT5DXP', ...)`), ticked except the raw reads. Unit checks in
MemProfilesTests on fake memory. Checked in a recording on 3 November (`WMMT5DXP-capture-20261103.md`):
speed2 lines up with speed and now feeds Car_speed and accel_g; rpm2 is a wider scale than rpm and
feeds Car_rpm (Max revs 8900); race_time2 feeds in_race; throttle matches the G25; distance matches the
speed. Still to check: brake, place with rivals.

MasterRaver is working on a 6RR version (Alexis, 3 November 2026).

Common values since 3 November: Car_boost = turbo / 1.5, Car_throttle = throttle (plugin 0.14.0: engine effects at 60% off the throttle), Car_impact also from the km/h lost. Ideas not built (in the pack README): turbo blow-off, brake pedal, place, shift feel.
