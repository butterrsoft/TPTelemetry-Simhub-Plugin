# Mario Kart Arcade GP DX (USA) (MKGPDXUSA): exe review, 11 November 2026

Alexis sent the USA `MK_AGP3_FINAL.exe` to see what the USA profile needs beyond the v1.18 work
(`claude/MKGPDX118-exe-20261109.md`). Inspected only, never run.

## The file

* PE32, preferred base 0x400000 but dynamic-base (DllCharacteristics 0x8140, as v1.18), not packed (code entropy 6.6),
  built 8 November 2016 07:07 UTC, **7,033,856 bytes**, SHA-1 ba198ccc554af9ad0ef5e6299b0c929797786761. Region string
  `USA1FF01`. (v1.18 is 7,432,704 bytes, built 2020.)
* Every address the FFB Arcade Plugin's USA mode reads is used by this exe's code in the expected way, so this is the build
  its USA addresses were made for. OutputBlaster has no USA build.
* RTTI: `clPlayerCar` (vtable 0x97220C), `clCarSoundManager` (0x969538), the ten `clRaceState*` classes, the attract demo
  loaders: the same classes as v1.18.

## Same structures, other places

| Value | v1.18 | USA |
|---|---|---|
| Car list (+8 = player's `clPlayerCar`) | `<main>+AAEEA0` | `<main>+B47B48` (0x48 bytes, made at 0x6F20DF; player car call 0x6F2105) |
| Kart speed (sound caps it at 400) | kart +AC4 | kart **+958** = `[[kart+A8]+6C]+718 x [[kart+A8]]+728` (0x63BF0C) |
| Engine revs (sound caps at 11000) | kart +AC8 | kart **+95C** = `[[kart+A8]]+724` |
| Slide value (0 while gripping) | kart +3BC | kart **+29C** |
| Kart state (1, 6, 7, 11, 18 off the ground) | kart +48C | kart **+34C** |
| Kart flags (bits 8, 64, 2048) | kart +810 | kart **+6B0** |
| Physics object | kart +CC | kart **+A8** |
| Sound slot, player flag | kart +320, +348 | kart +220, +248 |
| Sound manager | `<main>+AC2A30`, 0x6BC bytes, slots 0xF8 | `<main>+B4F324`, 0x678 bytes (made at 0x4ACFF2), slots 0xF0 |
| Ground type, first wheel pair | +66C | **+628** (0x485B90, same priority pick) |
| Wheel 1 on the ground | +69C | **+658** |
| Drift flag / drift side | +6B8 / +6BA | **+674 / +676** (slide value not 0 / below 0; feed at 0x647EE0) |
| FFB plugin's "speed" (not a field the feed fills) | +580 | +558 (slot 5 +A4 in both: same doubtful read) |
| Race manager (+38 state, its +C number) | `<main>+AAEE80` | `<main>+B47B28` (same ten states, switch at 0x6F2C10; the attract play demo's loader makes one too, 0x608E0A) |
| I/O (JVS) block | `<main>+AC5C00` | `<main>+B95480`: **v1.18's moved up 0xCF880** |

The engine-sound feed (0x647EE0) matches v1.18's line for line: same caps, same off-ground states, same flag bits.

## What the FFB plugin's USA rows turn out to be

* `force` (`B47B48`, `8, 2FC`): kart +2FC is **the sine of the slide angle**: the dot product of the kart's sideways axis
  (its matrix row at +4A8, flattened and normalised) with its direction of travel (`[[kart+A8]]+6C` → +1C/+20/+24,
  flattened and normalised; the forward axis +4C8 if not moving), worked out at 0x63CA52. That is why the 4 November
  recording's force sat at ±0.02 to 0.04 driving and swung to -0.95/+0.99 in the big hit at 28 s (the kart turned
  sideways). New row `drift_angle` = asin of it in degrees. Which side + is (the matrix's first row) needs a recording;
  past 90 degrees (a spin) it folds back. The previous frame's value is copied to +300.
* `speed` (sound manager +558): not filled by the feed, as v1.18's +580. Kept unticked as `speed_snd`.
* `terrain` +628, `on_ground` +658, `drift` +674: confirmed from the feed.
* `boost` (`B441C8` +3A4), `steer` (`B4F2E0` +125), `in_race` (`B486BC` chain): left as the FFB plugin reads them.
  `B4F2E0` is a big settings-like object with no direct +125 use, so v1.18's steering byte moved with the I/O block
  (`B9672D`) is recorded unticked as `steer_jvs` to compare.
* `item` (`B95480`+D) is the same JVS packet byte as v1.18's (the game writes 76 there, 0x810BB1). `hit` (`B96B74`) is at the
  same place in the I/O block as v1.18's shake word. `coins` (`B4E330`) has no direct references, as in v1.18.

## Why the 4 November recording read nothing

With this exe, `<main>+B47B48` and `<main>+B4F324` are set by the game (the sound manager at start-up, the car list for each
race), and the FFB plugin was plainly reading them in the game. So TP Telemetry was almost certainly looking at another
`MK_AGP3_FINAL.exe` process (one left running, or a stub), the same trouble two BG4 recordings had. Plugin 0.18.1 opens the
newest process and moves to a newer one, so a fresh recording should read.

## Profile changes (memgames.py `_mkusa`, moregames.py `fix_mkusa_lamps`, gamesetup.py)

* `speed` now reads kart +958 and `rpm` kart +95C (both feed Car_speed and Car_rpm); `drift_angle`, `drift_side` (+676),
  `race_state` (`B47B28`, `38, C`) ticked; unticked raw rows `slip`, `kart_state`, `kart_flags`, position
  (`kart_x/y/z`), travel vector (`travel_x/z`), the kart's sideways and forward axes (`side_x/z`, `heading_x/z`),
  `steer_jvs`, `speed_snd`.
* Lamps: v1.18's OutputBlaster rows (button byte, side/billboard word, under-lamp word, the last two as Int32) copied at
  +0xCF880: `B96834`, `B96B58`, `B96B68`. No OutputBlaster needed. Unverified.
* Car_drift and Car_grip_loss stay the drift flag; Car_drift_angle not fed until a recording settles the side. Note that
  `car_cornering` and `car_road_bump` come from `force`, which here is the slide, not a road force.
* MemProfilesTests: speed, revs, force and drift angle through the kart chain, a sine past -1 reads -90, drift flags, the
  moved lamp words, race state. **1665 pass with the pack, 764 without.**

## Later on 11 November: the exe is a modified build, and v1.18's findings carried over

* **Alexis's note:** this USA `MK_AGP3_FINAL.exe` is a modified version that uses more RAM, she thinks. Its header has the
  large-address flag (characteristics 0x122), so the game may use up to 4 GB rather than 2 GB; her v1.18 exe carries the
  same flag, so the header alone doesn't show what else was changed. The flag moves no code or data, so an unmodified USA
  exe of the same build should read the same; if another USA exe reads nothing, compare its size and SHA-1 with the ones
  above.
* **Place, laps and race time** (found in the v1.18 exe, then matched in this one by the HUD code that draws them):

| Value | v1.18 | USA |
|---|---|---|
| Place (1 to 6) | `<main>+AAEEA0` `8, CC, 1D4` | `<main>+B47B48` `8, A8, 1D0` |
| Laps done | `<main>+AAEEA0` `8, CC, 1E4` | `<main>+B47B48` `8, A8, 1DC` |
| Laps in the race | `<main>+AAEE7C` `4, 10` | `<main>+B47B24` `4, C` |
| Race time (ms) | `<main>+AAEEA0` `4, 2C` | `<main>+B47B48` `4, 2C` |
| Second ms timer (the HUD rounds it up; unticked) | `4, 1C` | `4, 1C` |

  The USA HUD code: 0x680AD0, 0x680B50, 0x6809D3, 0x6F7000.
* **From v1.18's recording, applied here too:** `drift_angle` + right-hand (asin of -force); Max speed 160 and Max revs
  10000; `racing` (race state 6 with the FFB plugin's in-race flag) gating the effects, so the attract demo (race state 6,
  flag 0) gives none; the derived rows (hop, gliding, spin, knocked, airborne, landed, rumble_strip, off_road with her
  surface codes, item_held, coins, hit_race, `hit_side`); new `position`, `laps_done`, `laps_total`, `race_time`, `lap`,
  `final_lap`, `leader`, `place_gained`, `place_lost`.
* MemProfilesTests: the new chains in both versions, and race state 6 without the in-race flag is not racing. **1702 pass
  with the pack, 764 without.**

## Checked in recordings (later on 11 November)

Two USA races (`claude/MKGPDXUSA-capture-20261111.md`) confirmed these addresses: speed, revs, steering, force and drift
angle (+ right-hand), drift side, race state, place, laps, race time, terrain, the lamp words. Still open: the LED colour
digits and the drift meter stage (as v1.18).
