# Working on TP Telemetry one game at a time (16 November 2026)

Alexis asked how to start a new chat per game with less to load, whether that saves usage, and whether profiles made in
different chats keep working with the plugin. Short answers: attach the four archives complete and the short handover;
the savings come from what a chat reads, not what is attached; and yes, profiles stay compatible as long as each chat
starts from the latest archives and chats on shared files don't run side by side.

## What a new game chat needs (Initial D Zero v2.30 as the example)

| Attach | Why |
|---|---|
| `TPTelemetry-Handover-20261116.md` | the working rules, files, pipeline, where each game stands, lessons, open items (24 KB; the history now lives in its own note) |
| `TPTelemetry.zip`, complete | the formula engine and the tests that check every profile loads and that the recordings still replay; the plugin itself if a game needs a new formula function or common value |
| `TPTelemetry-GameProfiles.zip`, complete | the generator rebuilds every generated profile and both generated docs (Game_Setup.md, Game_Formulas.md) on every run, and the hand-maintained profiles (Sega Rally 3 and others) only exist in the pack. A pack with only ID0V230 in it would come back with games missing and the docs cut down to what was there |
| `TPTelemetry-Tools.zip`, complete | ID0V230 is made by the generator (`memgames.py`'s Initial D block plus `moregames.py`), so the whole pipeline is needed: `memgames.py`, `moregames.py`, `oblamps.py`, `obmem.py`, `obnames.py`, `commonrows.py`, `tidytable.py`, `gameformulas.py`, `gamesetup.py`, `packlayout.py`; and `exe/` for reading the game's exe. `elf/`, `i960.py`, `tptram.lua` and `m2ramscan.py` aren't needed for ID0 but cost nothing unopened |
| The game's own files | `InitialD0_DX11_Nu.exe` (v2.30), your Cheat Engine table for it, and recordings with notes (course, car, gearbox, and what happened at each mark) |

**Project notes:** a chat started inside the claude.ai project can open any note there when it needs it, so the
ProjectFiles archive only matters for a chat outside the project. For ID0 the useful ones are
`Properties-and-common-set-20261030.md`, `ID6-exe-20261108.md` and `ID6-capture-20261109.md` (the Initial D lineage
and the drift weighting); the chat can read them on demand.

## Does it save usage?

Attached files cost nothing until they are opened: the archives are only unpacked and the files the work needs read.
What costs is what goes into the conversation, because everything read stays there and is carried on every later turn:

* **The handover.** The chat is asked to read it in full at the start. The 16 November split takes it from 61 KB to 24 KB
  (roughly 15,000 tokens down to 6,000), carried on every turn of the chat. This is the main saving, and it needs no
  trimming of the archives.
* **Notes for other games, the 4 November reference (`TPTelemetry-Reference-20261104.md`, 94 KB) and the history note (37 KB):** don't ask a chat to read
  these unless the work needs them.
* **The work itself:** disassembly listings, recording dumps and long test logs are most of a chat's cost. Short
  recordings with notes help most: fewer question rounds and less searching.
* **Chat length:** a fresh chat per game (or per stage of a game) keeps the carried context small.

Trimming the archives themselves (fewer profiles, fewer tools) would save almost nothing and break the pipeline, as above.

## Will older profiles work with the updated plugin?

Yes. A profile is a JSON table of rows (name, source, type, module, base and offsets, formula, notes) plus Max speed and
Max revs. The plugin has kept that format readable through every version so far, and the test suite loads every profile
in the pack and fails on any row that doesn't (`Profile X.json: N variables, 0 errors` in the test output), so a chat that
changes the plugin finds out at once if an older profile stops loading.

What to know:

* **Newer plugin, older profile: works.** A profile that doesn't use a newer feature simply doesn't have it (no Car_drift
  row means Car_drift reads 0, or the plugin's fallback).
* **Older plugin, newer profile: may not.** A row using a formula function or common value added in a later plugin shows a
  configuration error on that row in an older plugin. So install the plugin from the same delivery as the pack.
* **Updating a profile in SimHub:** Import never overwrites. Delete Game first, then Import (any rows you changed by hand
  are lost; Export a copy first). A recording made before you re-import reads the old rows (Sega Rally 3, 12 November).

## Keeping chats from stepping on each other

The generator scripts (`memgames.py`, `moregames.py`, `commonrows.py`, `gamesetup.py`), the pack README and the plugin
are shared by every game. So:

1. **One game chat at a time.** Start each chat from the latest delivered archives and handover, and finish it by having
   all four archives and the handover served. The next chat starts from those.
2. If two chats must run side by side, only one may change shared files; the other gives "just advise" or edits only its
   own game's rows, and its changes are carried into the next delivery by hand.
3. Each chat checks before changing anything that the unchanged scripts rebuild the pack exactly, and after its change
   that the pack diff shows only its game (and the generated docs).

## Can the plugin be carved up?

Not usefully. Profile work doesn't touch the SimHub side of the plugin (the UI and SimHub glue); the tests already build
only the engine core without SimHub. The archive's size is almost all recording fixtures for the replay tests, which
cost nothing unopened and which the tests need to pass. A cut-down copy would have to be kept in step with the
real one, which is extra work and a way for the two to drift apart.

## Other suggestions

* Say "analysis only" or "just advise" when that is all you want, and "build it" when you want the pack changed.
* With each recording: the course, car, gearbox and mode, and a short note per mark (or the TT of each event). Answers
  to a chat's numbered questions in one message, as you do, keep the rounds down.
* Attach the game's exe and Cheat Engine table at the start: reading the game's own code first has repeatedly been
  quicker than searching memory (WMMT3DX+, OutRun 2, Sega Rally 3).
* When a game is done or parked, the chat records what is open in the handover (as for GRID), so the next chat on it
  starts from there.
