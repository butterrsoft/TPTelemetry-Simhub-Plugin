# GTI Club Supermini Festa: Alexis's recording, 8 November 2026

Recording `20261108-182540_GTICLUB3.csv` (270 s, 37 marks; marks 21 and 22 aren't in her notes) with
`recording_notes_-_GTIclub.txt`. Race mode, intermediate course, manual gearbox, 3 laps, 4 cars. Speed display in mph.
The race ran 63.79 s (go) to 244.59 s (finish). Kept as the test fixture
`tests/CoreTests/fixtures/gti-20261108-182540.csv.gz` (raw memory values, worked back from the recorded row outputs),
replayed by `GtiClubTests.Recording`.

## What lined up

* `speed` (car +648) is **km/h even with the mph display**: /1.609344 gave her mph at every gear change (30, 30, 49, 56).
* `rpm_tacho` matched her tacho exactly (7058/7067, 6567, 6481, 6125). Engine `rpm` peaks at 7998 with the wheels in
  the air (her landing notes: 7625, 7937, 7562, 7812); about 1.5 s above 7500 in the whole race.
* Gear changes at 67.86, 69.66, 70.56, 84.39 s; gears 1 to 5; `gear_stored` equalled the dash all through; `gearbox` 1 (manual).
* Laps 67.049 / 56.764 / 56.903 s; `lap_time` / 30 matched (67.07 before the line). `laps_total` 3.
* Position 3 then 4 at the start, 3 near the end (her overtake really at 236.96 s).
* `finished` 1 at 244.59 s. `game_mode` 0. `in_menu` 1 in menus, 0 racing. `ffb_flags` always 0.
* Top speed 163 km/h (101 mph): Max speed set to 160.

## What was wrong (fixed 8 November)

* `time_left` (`<main>+67FB98`) read 0: that's I_LimitTimeObj, the variety modes' timer. The race's own time left is
  RaceObject +0x2B29FC4 (Int32 ms, 55000 at the start), but RaceObject is heap-allocated with no static pointer found.
  The race code copies it each frame to the race display: `[<main>+680460] + 2C4` (0x558A34, 0x55CC36). The profile
  now reads that / 1000. **To check in the next recording**; risk: I_RaceObj's own display writer (0x4A1D8D) might
  write the same field.
* `speedo_mph` (`<main>+67FCB4`) read 0: the race display's copy is `[<main>+680460] + 244` (set when struct
  0x3320CC0 == 1). Now unticked; not needed since `speed` is always km/h.
* `in_race` stayed 1 for 21 s after the finish: the game keeps state 5 and auto-drives (frozen 100 km/h, revs ~7800).
  Now `state == 5 && finished == 0`.
* `contact_timer` (car +1028) stayed 0: removed with `car_contact`.
* The old `hit` fired on landings and kerbs.

## The jolts (ffb_other == 15, vibration byte low 6 bits)

The game's jolt level identifies the event (byte = level × 72):

| Level | Event | Times (s) |
|---|---|---|
| 50 | landing | 70.46, 72.22, 78.56, 118.13, 125.00, 129.37, 133.36, 139.80, 175.71, 190.14, 196.64, 229.22, 231.39 |
| 36 | another car | 87.06, 93.76, 96.72, 150.00, 151.10, 167.73, 173.01, 180.84, 182.61, 185.94, 204.41, 215.51, 238.42, 242.89 |
| 63 | full-stop crash | 108.82 (her head-on barrier at 59 mph; 93 km/h lost; preceded by a 10 at 108.76) |
| 18 to 27, speed lost | wall | 74.22 (mark 12, LHS), 76.59 (mark 13, RHS), 82.92, 85.26, 92.79, 100.62, 140.43, 154.40, 164.13, 198.84, 213.51, 226.42, 233.96 |
| 18 to 27, no speed lost | mounting a kerb | 99.42, 148.20, 166.97, 227.58, 230.29, 232.86, 233.09 |

Wall speed loss: 8 to 48 km/h, sometimes arriving up to 0.2 s after the jolt (213.51, 226.42: kerb mount, then the wall).
`wall_hit` = a 10 to 27 jolt in the last 0.3 s and more than 8 km/h lost in 0.3 s. `hit` = 1 for a crash, else
0.5 + loss / 60 (0.5 to 1) for walls and cars. The wheel force and `force_angle` gave no consistent side at walls.

## Surfaces

* Low byte: 1 road, 2 kerb (every period of code 2 lines up with her kerb notes; patterns 11 to 14 rumble on it, higher
  the faster). Code 5 never appeared; code 0 only outside races. No airborne value found.
* Upper bits change as the wheels cross the lip of a jump, front pair then rear about 0.07 s apart, 0.4 to 0.7 s before
  the landing jolt: 0x2000000, 0x10000000, 0x4000000 in sequence at most jumps; 0x100000/0x200000/0x300000 and
  0x20000000 in some areas. Probably per-polygon tags; not used.

## The in-game timer, reconstructed from her notes

Her timer readings fit `timer = 112.41 + 16 × (checkpoints passed) - 0.9 × time_s` to within a frame or two: the
countdown starts at 55.00 at the go (63.79 s), runs at 0.9 game seconds per real second, and every checkpoint adds
exactly 16 s. Checkpoint times: 87.7, 93.82, 117.43, 130.89 (lap line), 148.06, 159.69, ~177 (mark 28), 187.67 (lap
line), mark 33, mark 35, 235.29. The lap timer, by contrast, runs at real time (lap 1 took 67.11 s real, 67.07 on the clock).

Unmarked jolts as sent to her (8 November, 20:40):
* 99.42 s: 67 mph, 3305, timer 54.93: exactly her "hit RHS wall" note. **She confirmed:** front right into the RHS
  wall, possibly also bottoming out in a dip at the foot of a small hill. No speed lost in 0.3 s (100.62 is the grind
  that followed).
* 148.20 s: 88 mph, 4332, timer 59.03. **She confirmed (timer 59.01):** in the long skidding right turn, the rear right
  touching the LHS kerb, car rolled noticeably left.
* 198.84 s: 77 mph falling to 71, 3837, timer 61.45 (assumes +16 s at the two checkpoints she didn't time). **She read
  61.44:** an LHS wall hit or an LHS kerb ride, nothing else. No wheel read kerb and 11 km/h was lost: kept as a wall.

**Revision (20:50):** a kerb jolt always came with a wheel already on the kerb (within the last 0.1 s), and 99.42 had
none (the kerb began 0.17 s later). `wall_hit` is now a 10 to 27 jolt with no kerb under any wheel in the last 0.1 s
(`wall_jolt`), or one losing more than 8 km/h within 0.3 s. Walls: the 14 above plus 99.42, 227.58 and 230.29 (the last
two unmarked, no kerb, no speed lost). Kerb jolts: 148.20, 166.97, 232.86, 233.09.

## Open questions for Alexis

* Time left and checkpoints: next recording will check the race display's copy (note the timer at a few marks).
* Which wheel is surface1 to 4: wheels 1/2 cross jump lips first, so they're the front pair.
