# GRID recordings, 12 November 2026 (12 November pack), analysed 16 November

`20261112-120036_GRID-1.csv` (469 s, 14 marks, no notes): attract mode, coins, menus, race 1 (the exe note's test
plan, then TIME OVER), menus, race 2 (positions changing, finished 2nd), menus, attract. `20261112-121012_GRID-2_attractmode_only.csv`
(196 s): attract mode only. Plugin 0.18.1, G25 USB capture on, so the wheel's steering and pedals are in both. Alexis
asked for questions by TT (the race clock on screen) rather than notes per mark.

## The race rows from the exe, read live

| Row | What it did |
|---|---|
| `race_on` | 0 in the attract mode and menus; 1 from GO (rec 71.08 and 239.41, the sample the car starts moving) until the race is cleared in the menus (196.46, 467.15), not at the line |
| `race_over` | 1 at TIME OVER (rec 174.03, TT 1:39.151) and 1.13 s after her line in race 2 (rec 439.34); 0 again when the race is cleared |
| `race_clock` | 0 until GO; steps of 1/120 s (the plugin sometimes reads the same frame twice); stood still for the pause (rec 113.32 to 118.53, TT 0:42.235) and from `race_over` (99.151, 199.919). It doesn't count the pause |
| `race_laps` | 1 in the menus, 3 once the race loads (53.12, 221.74) |
| `race_cars` | 2 in the menus and attract mode, 0 while loading, 6 in both races |
| `race_type` | 1 throughout, yet `race_over` came 1.1 s after the player's line, not when all six had finished |
| `car0_on` | same as `race_on` |
| `car0_lap` | -1 before the first line, 0 from 2.2 to 2.4 s after GO (the grid is behind the line), then 1, 2, 3 |
| `car0_laps` | 1 at rec 316.43 (TT 1:17.021), 2 at 375.87 (TT 2:16.449), 3 at 438.21 (TT 3:18.785): laps of 1:17.02, 0:59.43, 1:02.33 |
| `car0_lap_time` | not a lap time: the car's own race time, equal to `race_clock` until the car finishes, then held at its finish time (3:18.777) |
| `veh_id`, `hud_mode` | 0 throughout |

**Car 0 is the player.** `veh_id` (the car the dial follows) reads 0 all session; at car 0's third line (rec 438.21) the
game takes the car off her pedals (game throttle 0.03 against her pedal at 0.86 for the next 1.1 s, then the game drives
on its own: correlation 0.23 with her throttle, -0.14 with her steering); her mark at 376.19 is 0.32 s after car 0's
second line.

## Controls

* `brake` (ticked, dial +280): the G25's brake pedal (correlation 0.95 while racing, 1.0 at full). It also reads 1
  while the game holds the car after TIME OVER (pedal 0). **Checked.** Brakes from 168 km/h to a stop at TT 0:10.42 to
  0:13.72 and from 88 km/h at TT 0:17.18 to 0:19.13 (test plan step 3).
* `steer_in` (car physics +E30): opposite to the wheel (correlation -0.93; about -0.68 times the G25's -1 to 1
  position, 1.0 at full left lock). **+ is left**, settled from the USB steering, so no question needed.
* `throttle`: correlation 0.99 with the pedal while racing.

## Damage

`dmg_radiator`, `dmg_engine`, `dmg_gearbox` read 0 through both races, including race 1 TT 0:45.97 (LHS wall,
210 to 42 km/h, hit strength 4) and race 2 TT 0:42.84 (hit strength 7, the hardest). `dmg_state` reads 7 everywhere,
the menus included (NaN while a race loads). Either this build has no damage or the chain doesn't reach it: asked.

## Attract mode

GRID-2 and GRID-1's first 50 s: `race_on` 0, speed, revs and clock 0, no hits or contacts. Nothing in the profile moves
during the attract mode, so no effect could fire there even now.

## Hits and car contacts

Old rows as before (`hit_strength`, `wall_side`, `car_contact` a count). Race 1 (nobody near): TT 0:43.84 right wall
(3), 0:45.97 left wall (4, the hard hit), 1:09.19 left (2), 1:13.85 left (1), then reversing TT 1:11.8 to 1:15.5.
Race 2 car contacts (TT, peak count, `wall_side` at the start): 0:10.66 (2, +0.83 then -1; she stopped dead at 0:12.5
and reversed), 1:29.62 (2, +0.57, no hit strength), 2:06.02 (1, -0.49), 2:08.38 (1, -1), 2:22.83 (2, -1),
2:32.72 (5, +0.76), 2:38.53 (6, +1), 2:41.00 (3, -0.99), 2:44.63 (6, -0.49; strength 5 at 2:45.93), 2:48.79 (1, +0.34),
2:50.23 (3, +0.69). Sides asked, to see whether anything gives a car hit's side.

## Car_in_race (proposed, not built yet)

`car_in_race = valid(race_on, 0) == 1 && valid(race_over, 1) == 0 && valid(car0_laps, 0) < valid(race_laps, 0) &&
maxw(delta(race_clock) > 0, 0.1)`

Replayed on GRID-1: on 71.08 to 113.43 (pause), 118.54 to 174.03 (TIME OVER), 239.41 to 438.21 (her line, exactly
where the game takes the car); off all through GRID-2. The `maxw` bridges the repeated reads. Waiting on her answers
before building it (with the `steer` row, + right, and the damage rows' fate) in one pack change.

## Not found yet

* RT (time left) and the time extensions: no row. Race 1's TIME OVER came at TT 1:39.151.
* Position: the car records hold laps and each car's race time but no place. Both need `GRID.exe` again (the HUD's
  position element, which reads like `lapinterface`, and the arcade timer).

## Questions asked (16 November)

1. Pause screen TT (expect 0:42.23).
2. Race 2 finishing time on screen (expect 3:18.78) and lap times (1:17.02, 0:59.43, 1:02.33).
3. Any damage seen after race 1 TT 0:45.97 or race 2 TT 0:42.84; if not, the damage rows go.
4. Side of each race 2 car contact above.
5. Whether she wants RT, time extensions and position (needs `GRID.exe` attached again, plus RT at GO and each
   extension's TT in the next recording).

## Her answers (16 November 2026) and what changed

1. Pause screen TT **0:42.21** (race_clock 42.235: the screen lags a frame or two). `race_clock` is the TT.
2. Finish **3:18.77** (car0_lap_time held 3:18.777), lap 2 **0:59.42**, lap 3 **1:02.33** (from car0_laps: 0:59.43, 1:02.34).
   Lap 1 not shown on screen.
3. GRID arcade has no damage option: the damage rows are gone.
4. Car contacts (race 2): 0:10.66 her left rear (wall_side read +0.83, then -1); 1:29.62 dead-on into the back of a car;
   2:06.02 front left (-0.49); 2:08.38 rear left (-1); 2:22.83 front left (-1); **2:32.72 no touch at all** (she passed a
   pile-up of other cars cleanly, yet car_contact counted up to 5); 2:38.53 rear left (+1), then 2:38.90 front right; 2:41.00
   front left (-0.99); 2:44.63 front left (-0.49); 2:48.64 her front left into the RHS wall (+0.34); **2:50.23 no hit**
   (car_contact 3). So `car_contact` counts contacts between any cars, not only hers, and `wall_side` gave the side of five of
   her eight sided car hits (all front or rear left; the misses: rear left at 0:10.66 and 2:38.53, which read right, and the
   front right at 2:38.90, which read left). Car_impact needs `hit_strength` (her own
   car), so the phantom contacts don't fire effects; no car-hit side row yet.
5. She wants checkpoints, lap lines and position: `GRID.exe` attached again (`claude/GRID-exe-20261116.md`).

Built (16 November 2026): the race rows ticked and checked, `racing` → Car_in_race (with a clock-moving row and a
fallback of 1 if the race can't be read), `steer` (+ right), `lap`, `final_lap`, `lap_line`; raw `place0` to `place2`,
`me`, `players`, `my_car`, `game_mode`; `position`, `leader`. Every common value but Car_in_race reads 0 outside a race
(her answer on Sega Rally 3: only force feedback and lamps in the menus). New fixture `grid-20261112-120036.csv.gz`
(`GridReplayTests.Twelfth`). Time left: a Cheat Engine pointer scan asked (end of the exe note).
