# WMMT3DXP capture checks, 29 October 2026

## Capture 1: walls and drifts (`20261029-090856_WMMT3DXP.csv`)

39.5 s, 120 Hz, six markers. Checked against Alexis's event timeline.

### Sources in the recording

* Memory (speed, revs, gear candidates): working.
* TeknoParrot shared memory (slots 6 to 9): working.
* USB capture: FFB_connected = 1 but FFB_activity = 0, every decoded FFB_* and wheel_* field blank, FFB_raw0-7 frozen at 01 01 FF 03 03 31 10 6A. The wheel had moved in the USB device list after a reboot. Fixed for capture 3.

### Event match (all 14 events matched)

| Event | Time (s) | Data |
|---|---|---|
| Up to 3rd | 2.72 | gears 2 to 3, revs 8600 to 6950 |
| Up to 4th | 6.74 | gears 3 to 4 |
| M1 crash left wall | 7.34-8.40 | reflect -63/-25 pulses for about 1 s; speed only 121 to 116 |
| Slight drift right | 8.67-10.07 | spring down to 40, centre about -50 (tp_force +) |
| M2 hit right wall | 10.07 | reflect +63, centre -63, speed 122 to 105 |
| Turn left, kissing right wall | 10.07-11.87, 13.47-13.86 | reflect +25 held, more speed drops at 10.37 and 10.86; +63 kisses at 13.5 |
| Slight drift right, kiss left | 15.94-16.30, 16.14 | centre about -24; reflect -63; speed -4 |
| M3 hit right wall | 17.87 | reflect +, spring 5, speed 136 to 106; rebound +63 at 18.81 |
| Slight drift right, kiss left | 20.04-20.36, 20.67 | centre about -27; reflect -63 |
| M4 longer drift left | 26.54-28.80 | centre about +52 (tp_force -) for 2.3 s |
| M5 drift right, kiss left | 31.21-32.40, 32.04 | centre about -46; reflect -63, speed 127 to 110 |
| M6 turn left, hit right wall | 33.25-33.7, 33.77 | centre rising to +20 (left); reflect +63, speed 126 to 97 |
| Hit left wall | 35.94-38.10 | reflect -63/-25 held; speed 126 to 78, another drop at 37.19 |
| Head-on right wall | 39.44 | reflect +63, speed 124 to 55 in one sample |

Direction convention (+ = right) held for both centre (via tp_force = -centre) and reflect in every event.

### Findings

* **Slot 9 (reflect) carries wall contacts** with sign = side: 63 for hits and kisses, 25 held while scraping. (Capture 3 shows it also carries expansion joints, at 28 to 34.)
* **impact_side misses wall kisses during drifts** (16.14, 20.67, 32.04, all left kisses during right drifts) because tp_force uses centre whenever slot 8 is non-zero, hiding reflect. Proposed: base impact_side and a new wall_contact row on tp_reflect directly.
* **False impact at 1.74-1.97 s:** spring dropped to 17 in 2nd gear near the limiter with no centre or reflect; impact_now fired (spring < 0.5) with no side. Not in the event list; cause unknown.
* **impact_front** fired on every hit with speed loss, side hits included, with no false positives. It saturates at 3.5 G, but hits ran from -2 G to -37 G (head-on), so a wider scale would grade them. No rear hits, so impact_rear is untested.
* tp_spring reaches 67/63 (1.06); tp_friction stayed at 63 throughout.

## Capture 2 (`20261029-093243_WMMT3DXP.csv`)

119.5 s, no markers. Game memory detached at 2.0 s ("attached" 0, which the engine sets only when the process exits or the profile is deactivated); TP slots froze at the same moment and USB traffic stopped within a second. Not usable for joints. The first 2 s gave the first TP vs USB comparison: tp_force matched wheel_force in sign and scale (wheel about 17 ms behind, r = 0.90 at that lag); tp_spring matched wheel_spring apart from TP sending 64 to 67 of 63. Slot 9 read -90 once.

## Capture 3: freeway expansion joints (`20261029-093724_WMMT3DXP.csv`)

22.1 s, 12 markers (expansion joints; Alexis said one of 4, 5 or 6 was false). All sources live throughout.

### How a joint looks

* Slot 9 gives two short pulses (about 0.03 s each, 0.07 s apart) of the same sign, magnitude rising with speed: 28 at 130 km/h, 29 at 148, 30 at 167-179, 31 at 183, 34 at 184 (a longer four-pulse joint at 17.72). Spring stays at about 63-67. The wheel gets the same pulses one tick later (wheel_force = reflect / 63.5).
* Sign alternates between joints with no pattern, so joints have no direction.

### Marker match

| Marker | Time | Event | Delay |
|---|---|---|---|
| (unmarked) | | joint 1.26 (+28) | |
| 1 | 3.57 | joint 3.29 | 0.28 |
| 2 | 5.40 | joint 5.22 | 0.18 |
| 3 | 7.15 | joint 6.99 | 0.16 |
| 4 | 8.79 | joint 8.63 | 0.16 |
| 5 | 10.39 | joint 10.22 | 0.17 |
| (see 6) | | right wall 11.56 (+63) | |
| 6 | 12.03 | joint 11.89 (+30), masked; or the wall at 11.56 | 0.14 / 0.47 |
| 7 | 13.70 | joint 13.59 (+31), masked | 0.11 |
| 8 | 14.43 | nothing in any source | false mark |
| 9 | 15.54 | joint 15.46 | 0.08 |
| 10 | 17.19 | joint 17.02 | 0.17 |
| (unmarked) | | joint 17.72 (-34, four pulses) | |
| 11 | 18.94 | joint 18.72 | 0.22 |
| 12 | 20.27 | joint 20.02 | 0.25 |
| (unmarked) | | joint 21.89 | |

Joint spacing at a steady 180-185 km/h is about 1.6-1.7 s, which places joints at 11.9 and 13.6: the two masked ones. Marker 8 is the only one 0.73 s after the previous.

### Findings

* **road_bump (TP) and road_bump_usb agree exactly**: same 13 events, peaks within 0.01, about 10 ms apart.
* **Both miss joints while the game sends a centre force** (markers 6 and 7, during a gentle steer with centre 3 to 9). tp_force uses centre when slot 8 is non-zero, and the wheel itself only received the centre force then, so USB can't see them either. Slot 9 still carried both joints. A detector reading slot 9 directly catches all of them.
* **Separating joints from walls in slot 9:** joints 28-34 in short pulses with the spring up; walls 63 kicks, or 25 held while scraping, usually with the spring dropping. A threshold of 26-45 separated them in captures 1 and 3, but joints may fall to 25 or below under about 110 km/h. Needs a slower joint recording.
* **11.56 s: right-side wall contact** (Alexis is sure she hit a wall at least once). Reflect +63, spring 63 to 39 to 0 and back over 0.2 s, wheel_force +1, speed stepped 182.0 to 179.7 in one sample, then she unwound the steering from -0.29 to -0.10. impact_side and impact_side_usb both read +1. Matches the walls in capture 1.
* **Unmarked events checked:** 1.26 (+28 then -28, spring 67, speed rising), 17.72 (four -34 pulses over 0.26 s, spring 67, speed rising smoothly, steering still) and 21.89 (31, spring 67) all fit joints. The speed fall at 21.89 is smooth and follows a throttle lift at 21.77, not a step. 17.72 is the least certain, being longer than other joints, but showed none of the wall signs.
* **Rule so far:** every wall contact across captures 1 and 3 contains a 63 in slot 9 (scrapes add 25 between the 63s), and no joint has gone above 34.
* **Gear candidates:** gear read 2 then 3 (shift at 3.81 s, 149 km/h) up to 187 km/h. Revs/speed was 58.7 in "2" and 46.4 in "3", against 93.8, 75.5 and 65.4 for 2, 3 and 4 in capture 1. Either a different car, or the gear values are not the gear. To confirm.
* **Candidates after a reboot:** speed1 = speed2, revs1-4 and gears1-5 still agree (differences are sample timing); speed4/5 still one frame behind. All survive a restart, so one of each can be kept.
