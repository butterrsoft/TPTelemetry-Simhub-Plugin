# TP Telemetry: change history, 19 November 2026

Newest first. Continues `TPTelemetry-History-20261118.md`.

### 19 November, 15:00: plugin 0.21.0, USB capture decoders for more wheels, and Record Test Pattern

* Alexis (14:34) asked whether USB capture could cover more than Logitech without captures, which checked games need
  it, and how to capture other wheels (Fanatec, Thrustmaster and Moza at least). Advice: no checked game needs USB
  capture; on a wheel it only adds road bumps and cornering to Battle Gear 4 Tuned, and road bumps and some wall-hit
  sides to OutRun 2 SP. At 14:41 she asked for the decoders and the test pattern. The capture how-to was already in
  USB_Capture.md, so no new doc: that section is now "Capturing a racing wheel: adding or checking support".
* Plugin 0.21.0 (helper unchanged): `FfbWheelDecoders.cs` (Thrustmaster T300RS family, report 0x60, per-effect
  upload/play codes; Fanatec slot commands; Logitech HID++ 0x8123 download/state, learning the feature index and the
  slot from the wheel's answer), `PidDecoder.cs` (USB PID: Set Effect, Constant Force, Periodic, Ramp, Condition,
  Effect Operation, Block Free, Device Control; direction from the Set Effect's Direction collection),
  `HidDescriptor.cs` (a HID report descriptor parser), `WindowsHidPid.cs` (the layout from Windows' hid.dll on the
  PC; P/Invoke only). G29 (C24F) and G923 PS (C266, C267) on the classic decoder. Auto picks by USB ID (Moza 346E,
  Cammus 3416, Asetek 2433, Simucube, VRS, PXN, OpenFFBoard as USB PID). The pipeline also reads SET_REPORT control
  transfers and HID report descriptors, and passes the wheel's IN reports to decoders that want them.
* USBPcap's `--inject-descriptors` carries only the device and configuration descriptors (read in its source), not
  the HID report descriptor, so a USB PID wheel's layout comes from Windows, or a capture of the wheel being plugged
  in, or the shared layout guessed.
* `TPTelemetryFfbTest.exe` (new project): DirectInput test pattern (constant +25, +50, -25, -50%, sine 30% 10 Hz,
  spring, damper, friction 50%), log of each step's UTC time; Record Test Pattern on the settings page records 40 s
  and runs it. Its own process so a driver fault can't affect SimHub. Not yet run on a wheel.
* Written from the Linux drivers (hid-tmff2 GPL-3.0, hid-fanatecff GPL-2.0, hid-logitech-hidpp) and the USB PID
  specification: protocol facts only, no code taken. Every new decoder is marked not yet checked; signs need a capture.
* Tests: `WheelDecoderTests` (41 checks: auto-pick by ID; each protocol's packets as documented; a full USB PID
  descriptor parsed, delivered in a capture, reports over interrupt and SET_REPORT; the guessed layout). 2289 pass with
  the pack, 847 without; compile check ok (plugin, helper, test pattern, test target). Pack and tools unchanged.

### 19 November, 14:20: full property names in the common docs

* Alexis: the docs should give the name to use in SimHub. `Common_Properties.md`, `Common_Dashboard.md` and
  `Common_Lamps.md` now write every property in full (`TPTelemetry.Car_speed_kmh`, `TPTelemetry.Lamp_start`), each with a
  line on using them (`[TPTelemetry.Car_speed_kmh]` in NCalc, `$prop('TPTelemetry.Car_speed_kmh')` in JavaScript);
  Game_Setup.md's per-game lists the same (`gamesetup.py`). The docs test checks the full names. No other change.
  2248 pass with the pack, 806 without.

### 19 November, 14:10: plugin 0.20.0, common dashboard values and common lamps (every game)

* Alexis asked (13:12) whether every table row ends in the common values and the effect profiles (yes: `car_` rows ->
  `TPTelemetry.Car_...` -> the "TP -" effects, one profile for every game), and for common dashboard values and lamps
  so one dashboard and one LED set-up serve every game. Her answers (13:45): speed as two values, km/h and mph; the
  `lamp_` prefix; one lamp for all warnings.
* Plugin 0.20.0 (helper unchanged, 0.18.0), `CommonValues.cs`: new sources `speed_kmh`, `rev_limit_rpm`, `position`, `lap`,
  `laps_total`, `time_left`, `race_time`, `lap_time`, `brake`, `steer`, `gap`; new outputs `Car_speed_kmh`,
  `Car_speed_mph`, `Car_max_speed`, `Car_max_revs`, `Car_rev_limit_rpm` (else Max revs), `Car_rpm_dial` (rpm / Max revs,
  not gated), those race values, `Car_final_lap`, and the string `Car_gear_text` (R, N, 1...). Dashboard values are not
  gated by the plugin. 23 lamps from rows `lamp_<name>` as `TPTelemetry.Lamp_<name>`, 0 to 1, never gated; stand-ins
  for `view` (brightest view button), `leader` (racing in 1st), `shift` (Car_rpm_frac 0.9), `boost` (Car_boost 0.9),
  `brake` (Car_brake 0.1). Recordings get `Lamp_` columns. The prefix `Lamp` is reserved like `Car`.
* Pack (`commonrows.py`): `dash_rows` (added before each game's race gating, so SR3, GRID, SWDC, Initial D 3 and Zero,
  Scud Race and Daytona 2 PE read 0 outside a race as she asked) and `lamp_rows` (after it). `car_speed_kmh` only where
  the units are known (26: SR3's mph x 1.609344; Mario Kart's units taken as km/h; Crazy Taxi, D1GP, SRG, Flycast's
  driving simulator not). Coverage: position 12, lap 12, laps total 5, time left 20 (8 unchecked cheat-table timers),
  race time 19, lap time 6, brake 8, steer 8 (Mario Kart USA left out: sign unconfirmed), gap 3, rev limit 6; lamps
  start 45, view1 46, leader 25 (Model 2 Sega Rally's made one, as its own never lit), checkpoint 11, final lap 5,
  shift 5, warning 4 (WRONG WAY Scud/SR3, Brake! BG4JP, SHIFT UP OR2), boost 3, colours 11 to 13 (BG4JP's 0 to 100
  scaled), marquee 13, brake 1 (MotoGP). Battle Gear's Hazard and Key left per game.
* `moregames.py`: Supermodel's `lamp_start`... rows renamed `lampstart`, `lampview1`..., `lampleader` (as OutputBlaster
  names them), since `lamp_` is now the common prefix. `gamesetup.py`: each game's common dashboard values and lamps;
  dashboard rows don't count as effect rows for the "no car_ rows" tag.
* New help files in the plugin: `Common_Properties.md` (the values the effects are built from, with which effect
  reads which), `Common_Dashboard.md`, `Common_Lamps.md`; a test checks they name every property. README, SimHub_Effects.md,
  Game_Outputs.md, the pack README and the Tools README updated. Not a rename of SimHub_Effects.md: that stays the
  how-to (making, importing, channels), the new file the reference list.
* Tests: new CommonValues checks (km/h and mph, settings, dial, gear text, lamps and stand-ins, not gated), an SR3
  replay check of RT, TT, mph, laps, final lap, leader, warning and the made-up shift light; TableOrderTests and the
  SWDC 17:59 check know the new rows. 2248 pass with the pack, 806 without; compile check ok. Pipeline run twice:
  identical; only `car_`/`lamp_` rows added (and the Supermodel lamp renames) across 66 profiles.

### 19 November, 13:00: Initial D 3 for Flycast v2.7-1

* She updated Flycast to v2.7-1-g44e4c7b50 (MD5 d8db8f69...) and every FLYINITD3 memory row read nothing. From the new exe:
  `FLY_RAM` 2840C90 -> **29D0C10** (`moregames.py`; Game_Setup note, pack README). Only FLYINITD3's base offset changed (40
  rows); no other profile, no plugin change. 2211 pass with the pack. Not yet confirmed in a recording (`ram_probe`
  3509307139). Notes: end of `FLYINITD3-flycast-20261117.md`.

### 19 November, 12:30: SWDC wrapped up from her SWDC-12 answers

* `contact_side` from the first shove (a rebound the other way follows): 12/12 sides in GT300, 8/10 in GT500. Car_drift
  refitted with her seventh value (0.7 at 45 degrees, 133 km/h): 0.072 x (angle - 10)^0.6 x sqrt(km/h / 100, up to 150).
  Kerbs on the GT500 course send no vibration: Car_rumble_strip stays 0 there (open). Attract mode confirmed 0; the revs
  she saw stay high after a race were from the old profile. 2211 pass with the pack, 777 without. She is moving to a new
  chat; open items at the end of `SWDC-capture-20261119.md`.

### 19 November, 11:40: SWDC GT500 race (SWDC-12); checkpoint ticked

* Her GT500 race to TT 1:30.80: rolling start, class place = overall at the front (4th class, 5th overall once),
  checkpoints at six sector and lap lines, sixteen contacts, five speed-drop hits, the verge. Fixture
  `swdc-20261119-113002.csv.gz`; `SwdcReplayTests` checks the start, places, checkpoints and that every contact has a side.
* `checkpoint` (sector and lap lines, 1 s) ticked for SimHub: the game has no time extensions. `contact_side` from the
  biggest shove in the last 0.3 s (a rebound reversed one). Five questions (`SWDC-capture-20261119.md`).
* `swdc/capfixture.py` reads recordings made with the new row names. 2202 pass with the pack, 777 without.

### 19 November, 11:00: SWDC from her answers: contacts, surfaces, drift

* Car contacts and wall hits from the sideways shove the game gives the car (`jolt` from position and heading;
  `car_contact` over 4 G while not sliding, side and strength): all twelve she named found, sides right. Car_impact from
  contacts and speed-drop hits; the game's wheel kicks left out. `hit` needs 5 G while braking.
* Grass verge (Car_off_road) and solid kerbs (Car_rumble_strip) from the game's vibration command's strength and period.
* Car_drift fitted to her six slide values (within 0.1; one pair she gave can't both fit). `position` is the class place
  as the screen shows; `overall` the place among all cars; `time_left` dropped. Sparks come on downshifts under braking.
* Tests: SWDC-11 replay checks contacts and sides, hits, surfaces, drift values, places. 2196 pass with the pack, 777
  without; compile check ok. Plugin unchanged. `SWDC-capture-20261119.md` has her answers.

### 19 November, 09:30: Sega World Drivers Championship checked in her race (SWDC-11); values only in the race

* Alexis's recording `20261119-091525_SWDC-11.csv` (car select, a race from 35th to 16th, the menus) with plugin 0.19.0:
  the data model and the indexed offset work throughout. `SWDC-capture-20261119.md` has the detail and 18 questions.
* Confirmed: race state 1 through the countdown, 2 from the rolling start (TT 0:00.00, the car moving at 97 km/h), 3 at the
  finish line (TT 3:16.29); `kmh` is the speedo; `shift` = `gear2`; place, class place, laps, sectors, race clock; the
  lap time limit (`time_left`: 300, then 180 at each lap line); drift angle + in right-hand turns. Not the engine:
  the record's revs (now `revs_record`). Sparks only three times, not at the hits.
* Alexis: telemetry from the rolling start to the line or time up; in the attract mode the revs and other columns
  didn't cut off. Now `in_race` = race state 2 (the revs-and-spring fallback and `racing` removed), every game value
  reads 0 outside it (`revs`, `speed2`, `gear2`, every record row) and every Car_ value but Car_in_race is wrapped in
  `in_race`. Car_rpm = `revs`; Car_wall_contact and the spark hit side taken out. FFB rows unchanged.
* Tests: `SwdcReplayTests` replays SWDC-11 (in race once, rolling start to the line; every value 0 outside; Car_speed,
  gear and revs; laps, places, the clock; five hits; drift sign) and checks the 3 November recordings now read nothing
  (no car record) and the 19:30 USB force; `MemProfilesTests` updated. 2167 pass with the pack, 777 without; compile
  check ok. Plugin unchanged (0.19.0, helper 0.18.0).
* Archives: she asked why TPTelemetry.zip and the pack were smaller than hers. Nothing was removed: every file is there
  (146, 113, plus the new ones), only SWDC's files changed in content, and the uncompressed contents grew; the zips are
  smaller because they were written without the per-file extra fields (timestamps, owner) her copies carried.
* Tools: `swdc/capfixture.py` (a replay fixture from one of her SWDC recordings).
