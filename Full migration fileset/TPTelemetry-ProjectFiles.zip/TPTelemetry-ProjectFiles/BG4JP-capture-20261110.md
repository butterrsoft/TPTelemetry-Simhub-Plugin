# Battle Gear 4 Tuned (BG4JP): first recording, 10 November 2026

Recording `20261109-202732_BG4JP.csv` (262 s, 120 Hz) with Alexis's notes (31 marks): Citroën 2.0 VTS, 6-speed
manual (her shifter gave only 3rd, 4th and neutral, plus reverse), course 1, class S, one lap and a bit.

## Result: no game values

* `attached` was 1 throughout, but **every memory row read exactly 0 for the whole run** (not blank): speed, revs,
  gear, in_race, race_phase (a pointer chain, so its pointer was non-zero), position (0 + 1), contact flags, all lamps.
* The game itself was racing: the FFB Arcade Plugin inside it switched its spring on at 102.6 s (it does that from
  in_race, `<main>+4A9508`, the same address) and sent forces from 104 to 254 s (-0.87 at mark 13, her LHS wall hit).
  USB pedals line up with her notes (full brake at mark 26). So the addresses work in the game's process.
* Most likely TP Telemetry opened a different process called `game.exe` (a very common name; `ProcessMemory.TryOpen`
  takes the first match), whose memory at those addresses is zero. To check: the BG4JP status line on the settings page
  shows `Attached to game.exe (PID n)`; compare with the PIDs of game.exe in Task Manager > Details.
* Her notes still give: rev limit about 8k for this car (bouncing at 7.8k to 8k on the dash), 181 km/h at the 4th-gear
  limit, race time 124 s at the start and +45 s at the lap line, 6 cars.

## Next recording

Confirm the status PID matches the game (speed moving on the settings page) before recording. Then: an overtake and
being passed (position), contact with another car on each side, grass or gravel (the rough flag), wall hits each side,
reverse, a run with the automatic gearbox (all six gears), a top-speed run, and the finish through to the results.

## Second recording (15:08): live values, checked against her notes

Recording `20261110-150815_BG4JP.csv` (209 s, 120 Hz, 16 marks) with `recording_notes_-_BG4JP-2.txt`: attract demo,
credits, VW Golf GTI, 6-speed manual, course 23, standard direction, class S, four cars. The PID problem is gone.

* **Speed, revs, gear:** match her readings (mark 10: 75.7 km/h, 6160 rpm, 2nd against her 71 km/h, 6k, 2nd; mark 15:
  42.7 km/h, 2201 rpm against 43 km/h, 2.2k). The Golf's limiter is exactly 7500 (her Citroën's about 8000). Gear 0 is
  neutral; 1 to 6 as shown. `speed_ffb` is the same value as `speed`.
* **Position:** every change she noted is there (4th to 3rd at 69.0 s, back to 4th, 3rd at 114.8 s (her RT 76.06),
  2nd, 3rd, 2nd at 123.7 s, 1st at 127.3 s, then passed by two cars). It reads 1 in the countdown, before the first sort.
* **Race phase:** 1 to 5 in the 0.2 s the race loads (54.85 s), 6 the countdown (60.03 s), 7 from the green light
  (65.81 s), and it stays 7 afterwards.
* **in_race:** 0 in the attract demo while it drives, but **1 from the moment the credit froze the demo (4.75 s) all
  through the menus**, with the car values frozen (71.46 km/h, 6086 rpm). The FFB plugin's spring was on in the menus too.
  `view` (camera) is 12 in the demo and menus, 0 while loading, 1 then 2 as the camera swings into the cockpit, so
  Car_in_race is now `in_race && view != 12`, and the new `racing` row also needs race phase 7.
* **Wall flags (car +122):** 32 then 128 at each right-hand wall hit in her notes (72.2, 79.1, 88.95 s), 16 then 64 on
  the left (85.0, 99.0 s); a glance along the left wall (91.8 s, her RT 99.00) set 64 alone. So 16/32 are the moment of
  a hit (left/right) and 64/128 touching or scraping. Bit 4 was on for most of the race (off 105.2 to 113.7 s, stuck
  behind the car in 3rd); bit 2 (the FFB plugin's rough or boost effect) only after her notes end (173.6 to 189.5 s).
* **Car flags (car +123):** 1 when she hit the rear of the car ahead (106.46, 110.16, 112.18, 113.17 s, all in her notes),
  2 right and 4 rear when the car in 3rd hit her rear right (mark 12), 8 while scraping a car on her left (marks 13, 14,
  ending in 4 as she cleared it). So 1 front, 2 right, 4 rear, 8 left.
* Replayed with the new rows: 38 contact starts in the race, each matching a wall or car event in her notes or the flags.

Profile changes: `racing`, `contact`, `wall_touch` rows; Car_impact from any contact start (front and rear bumps included),
Car_wall_contact from the scrape bits; `leader` needs `racing`; `car_bump` is front or rear; Max revs 8000.

**Still to see:** the finish and results (race phases after 7), time left and the checkpoint extension (her RT jumped
by about 50 s between 115 and 129 s; not read yet), laps, rough ground with notes, top speed, reverse, other cars'
limiters, and the "Brake!" warning she'd like as a value: the game's `Scene/race/automatic_brake` overlay (number 7 in
its overlay table at 0x80DF5C); what turns it on isn't traced yet.

## Her answers (19:10) and the race time from the exe

* **The game froze for 26.4 s (133.05 to 159.46 s):** her wheel and pedals kept moving, but every game value, and the
  FFB plugin's force, held still. Game time after it = recording time minus 26.4 s more. Asked her what happened.
* **Checkpoint / lap line (course 23):** RT 119.61, TT 0:55.400, lap 1 0:55.378, 2nd, 7k, 79 km/h = **121.28 s** in the
  recording (79.9 km/h, about 7400 rpm, 2nd). Before it the clock read about 69.8, so the checkpoint added about 49.8 s.
  Game TT 0 = 65.88 s.
* **Her verge moment** (RT 63.06, TT 1:51.950, 3rd, 0.9k, 18 km/h) = **204.24 s** (3rd, 18 to 19 km/h, about 930 rpm).
  Wall bit 2 (rough ground) was off then: the game didn't count it as rough. Bit 2 was on at 173.62 to 180.57 s and
  182.51 to 189.51 s: TT 1:21.33 to 1:28.28 and 1:30.22 to 1:37.22, lap 2 time 0:25.95 to 0:32.90 and 0:34.84 to
  0:41.84 (RT about 93.7 to 86.7 and 84.8 to 77.8). Asked her what surface that is on her video. (Later: she saw slightly rougher, shadowed road; recording 3 showed
  bit 2 is the nitro, 7 s a shot, so these were two nitros.)
* **From the exe:** the race scene `<main>+4B1758` keeps the race timer task at +34; its +1C is the time left in frames
  (60 a second; the HUD timer gets it x 16.67 ms). The checkpoint code (0x4AFF30, at 0x4B0191) adds each checkpoint's
  seconds x 60; reaching 0 sets race phase 10 (time up, 0x4BA64D); a player's finish sets phase 8 (0x4B0076). The session
  `<main>+3F25DC` has a 0x980 block per player: +17C checkpoint crossed this frame, +17D lap line crossed, +160 checkpoint
  number, +984 lap, +A34 the player's race state (3 to 4 at the finish). New rows `time_left`, `checkpoint`, `lap`,
  `checkpoint_no` (unticked), for her next recording to confirm.
* **Nitro (0x47D510):** car +290 is the shots left; using one sets +294 to 420 frames (7 s), counting down. New rows
  `nitro_left`, `nitro_time` (unticked) and `boost` (racing and nitro_time > 0), which feeds Car_boost.

## Recordings 3 to 5 (19:15 to 19:42), and plugin 0.18.1

Recorded with the pack from before the 10 November BG4 rows, so no time_left, lap, nitro or racing columns yet.

* **3 (19:15), a fast car's time trial to the finish:** top speed 294 km/h, revs to 9000. Wall bit 2 was on for 7 s
  from 34.0, 91.04 and 100.74 s: her boost marks 1 (35.3) and 2 (91.8) and mark 3 (101.0). So **bit 2 is a nitro
  burning** (420 frames, as the exe's nitro timer), not rough ground, and recording 2's two "rough" stretches were
  nitros too. `rough` (Car_off_road) is gone; `boost` (Car_boost) is `racing` and bit 2. Her lap line at about 96 s
  (RT 26.03 to 116.01 at TT 1:19.000) = 96.7 s (go at 17.70 s). The finish: race phase 8 for one frame at 168.90 s
  (her mark 6 at 169.04), then 9 while the car rolls to a stop, 0 at 177.86 s; in_race 0 from the line. Reads failed
  from 187.83 s (she stopped the game). Bit 4 of the wall flags: on 21.0 to 46.6 s here, most of recording 2; unknown.
* **4 (19:23), reverse in a Trueno:** gear -1 at her marks 1, 2, 5, 6 and 0 at 3, 4, 7, 8 (the car didn't move in
  reverse). Reads failed at 34.09 s and came back at 36.6 s frozen (17.92 km/h, 700 rpm, neutral): the stopped game.
* **5 (19:42), Brake! warnings, drifting, checkpoints: no game values.** Every game row held recording 4's last values
  (17.92 km/h, 700 rpm, phase 7) for the whole 110 s while the FFB plugin sent live forces: TP Telemetry stayed on the
  previous game.exe, which had hung on after she stopped it. The same thing probably explains the first recording's zeros.
* **Plugin 0.18.1:** `ProcessMemory.TryOpen` opens the newest process with the name (`PickNewest`: latest start time,
  then higher PID), and the engine checks every 3 s while attached (`CheckNewerProcess`): a newer copy starting moves
  the profile to it. RemoteTests check the choice; the compile check passes.
* Max speed 200 km/h (Alexis: most races stay under it, and above 200 the cars barely steer).

## Recording 6 (20:38), plugin 0.18.1 and the new pack

Automatic gearbox, four cars, 132 s, 19 marks (Brake! warnings, drifts, one checkpoint). Live the whole way: the newest
game.exe was read.

* **time_left** counted down from 175 s; at her checkpoint (mark 13, 71.76 s) it jumped 113.25 to 173.23 (+60 s) at
  71.82 s, `checkpoint` on 71.82 to 73.84 s, and **lap** went 0 to 1 at the same frame (laps completed). The checkpoint
  is the lap line on this course. `checkpoint_no` (session +160) stayed 0: removed.
* **Nitro:** nitro_left 3 and nitro_time 0 throughout (not used), and wall bit 2 never set. Alexis says she didn't use a
  nitro in recording 2 either, yet bit 2 was on for exactly 7.0 s twice there (as at each of recording 3's boosts).
  Kept as boost; to compare with nitro_time in a recording with a nitro, and asked her whether a button might have fired one.
* **ground_contact (car +121):** 128 = wheelspin (on 1.9 s from the grid, 2 to 48 km/h; 2.8 and 3.3 s pulling away in
  1st after wall hits), 4, 8 and 32 each gear change (one frame), 32/64 alternating while revving on the grid. New row
  `wheelspin`, feeding Car_grip_loss.
* **Brake!** isn't in any row this recording read. From the exe: the race HUD (0x45E360, at 0x45E8BB) plays preloaded
  overlay 7 (`[<main>+4AD02C]+80`, automatic_brake.anm) while bit 2 of the player's car +CCC is set, fading 10 frames
  after; bit 1 plays overlay 8 (automatic_return) outside phase 9. New rows `assist_flags` (car 0 +CCC =
  `<main>+42F75C`), `brake_warning`, `return_warning`.
* **Drift:** no drift value yet. Unticked raw rows for the next recording: `pos_x`, `pos_z` (car +100, +108) and a guess
  at the car's matrix (`fwd_x`/`fwd_z` +F0/+F8, `right_x`/`right_z` +D0/+D8). If they hold unit vectors, a drift angle is
  atan2(velocity across, velocity along) from slope(pos).

## Her answers on wheelspin (21:05)

Events 1 to 4 of recording 6 (grid launch; pulling away at 19 km/h; after the left wall; after the right wall): no; yes;
yes, with skid marks; maybe a little. So ground bit 128 is wheelspin, though the grid launch sets it without visible spin.

## Recording 7 (20:58): drift angle, a second freeze, time up

Automatic, four cars, 288 s, 25 marks (Brake! and drifts, one checkpoint). She turned round to avoid a checkpoint and
drove the wrong way for a while, then turned back about 5 s before time up; the recording runs back to the attract mode.

* **Drift angle found:** car +100/+108 is the position in metres (its slope over speed is 1/3.6) and **+D0/+D8 a unit
  vector along the car's heading** (+F0/+F8 read 0: not the matrix guessed). The angle between heading and travel
  (from the position's slope over 0.1 s) has a median under 1 degree above 60 km/h, and reads 48 degrees at her
  40.0 s drift (wheel right), -34 at 132.3 s (wheel left), +21 at 140.9 s (wheel right), 70 at 236.3 s (a spin). The sign
  follows the wheel, as she says, so drift_angle = -atan2(v x h, v . h) in degrees, + right-hand. Car_drift uses ID6's
  weighting; Car_drift_angle the angle; Car_grip_loss the larger of drift and wheelspin.
* **A second freeze:** 15.3 to 29.3 s, every value held (race clock at 170.78) while her wheel moved. New row `live`
  (the race clock moved in the last 0.5 s, or can't be read): `racing` and Car_in_race need it.
* **Time up:** race phase 11 at 260.87 s (time left 0; not 10 as the code suggested), 0 at 265.86 s.
* **Checkpoint:** +60 s at 87.71 s (her mark at 87.65), lap 0 to 1 at the same frame.
* **Brake!:** car +CCC (`assist_flags`) stayed 0 through all her Brake! marks. Its only writer (0x47E680) runs when car
  +120 bit 1 is set and sets bits 2 and 8 when the car is over a course target speed: the game's automatic brake assist,
  apparently not on for her. Her Brake! is still to find; `car_flags` (+120) recorded for the next look.
* Her marks with no drift (Brake! by her notes): 38.25, 49.40, 60.84, 66.52, 72.76, 77.04, 77.48, 97.90, 107.09, 121.93,
  122.12, 131.05, 152.39, 158.69, 176.39, 241.60, 260.46 s. Several came with car contact or wall bits; no single bit matched.
* Fixture `bg4jp-20261110-205811.csv.gz` (raw reads, every second sample, her USB steering) and `Bg4Tests.cs`: freeze,
  checkpoint, time up, her three drifts and their signs, no drift at her Brake! marks, the sign following the wheel.

## Her answers on recording 7 (21:49), recording 8 (21:47) and the Brake! source

* Her answers on my ten unmarked drifts: every one was a slide: two smooth unplanned drifts round left turns, the two
  wheelspin pull-aways with skid marks, quick drifts ending in wall hits (several driving the wrong way), a skid to 90
  degrees parking against a wall to turn round (the -27 with the wheel full right), and a big left drift round a hairpin
  (the 70 degree spin at 236.3 s). So drift_angle catches slides of every kind, which suits Car_drift.
* The 15.3 to 29.3 s "freeze" was her pausing the game; the 15:08 one too, probably. `live` handles both.
* **Recording 8 (three nitros, marked):** nitro_left 3 at the start, then 2, 1, 0 at 16.18, 33.31 and 49.07 s;
  nitro_time 420 counting down at each; wall bit 2 on for exactly those spans. Bit 2 is the nitro, confirmed. Recording 2's
  two 7 s spans were nitros fired without her meaning to (or by a button mapped to it).
* **Brake!**, from her description (yellow italic, below "Extended Time!", above the curve markers): the car navigation
  (`CNaviTask`, the CARNAVI setting; course data drivedata/navi%sn.dat and %sr.dat for reverse). The race scene keeps it
  at +3C (0x4B6A12). Its update (0x4B8D00) walks the course's navi entries ahead of the car: the low 12 bits a curve sign
  (`navi_curve` +44, shown while +40 is 1; 7 hides it), the top four bits a second sign (+4C, shown while +48 is 1; 0x2000
  hides it), 0xE00/0xF00 switch the signs off and on. Brake! should be that second sign: new rows `navi_curve`,
  `navi_curve_on`, `navi_sign`, `navi_sign_on`, and `brake_warning` = racing and navi_sign_on. The car +CCC flags are the
  game's brake assist (`auto_brake`).

## Recording 9 (11 November, 08:56): Brake! confirmed

Six Brake! marks (she thinks she missed the first after the start). The car navigation's Brake! trigger (`navi_sign_on`,
one frame; `navi_sign` holds 4096) fired at 30.38, 42.49, 53.39, 60.09, 70.10, 82.64, 92.30 and 99.18 s: 0.5 to 0.8 s
before each of her six marks, plus 30.38 s (RT 182.9, the one she missed after the start) and 82.64 s (RT 190.8, just
after a checkpoint, no mark). `brake_warning` now holds 1.5 s from each trigger (asked her how long it stays on screen).
`navi_curve` holds the curve code until the next (3328 none): 1, 2, 4, 5, 6, 9 and 48 seen, each shown 2 to 3 s ahead of a
corner; `corner_ahead` is 1 while one shows. Asked her to match codes to markers. Fixture `bg4jp-20261111-085621.csv.gz`
(every sample, as the triggers last one frame) and Bg4Tests checks.

### Her readings of the curve markers (09:10)

1 hairpin right (also her extra at RT 142.41: code 1 from RT 143.8 to 141.4), 2 medium right (her extra at RT 186.70: code 2
from RT 187.8 to 185.6), 4 hairpin left, 5 medium left, 9 slight left, 6 snake left-right-left, 48 snake right-left. Brake!
did show just after the checkpoint (82.64 s). New rows `corner_side` (+1 right, -1 left, a snake by its first bend) and
`corner_sharpness` (1 hairpin, 0.6 medium or snake, 0.3 slight); codes not yet seen read 0 (likely a slight right and
other snakes). Still to ask: how long Brake! stays on screen (held 1.5 s for now).
