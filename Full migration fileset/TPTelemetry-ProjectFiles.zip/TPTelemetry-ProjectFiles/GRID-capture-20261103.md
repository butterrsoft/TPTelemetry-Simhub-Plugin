# GRID recording under TeknoParrot, 3 November 2026

`20261103-202137_GRID`: 120 s, 13 marks, FFB plugin in its Custom mode (`GRIDCustom.cpp`), G25 captured over
USB (working: activity up to 77). Fixture `grid-20261103-202137` (raw reads plus `usb_force`, `usb_rumble`,
`usb_steer`), replayed by `GridReplayTests` with the USB force fed through the common values.

## USB matches the FFB plugin exactly

The FFB plugin's Custom mode builds the force from values this profile already reads, and the G25 got it:

* **Wall hits**: constant force `hit_strength` / 8, from the right when `wall_side` > 0. The profile's
  `impact_side` is the same value: the wheel got it one USB poll later in 828 of 872 hit frames (95%; the rest
  are the first and last frames of a hit). Peaks matched to 0.002 (0.25, 0.375, 0.50, 0.75).
* **Gear changes**: a 0.49 sine for about 70 ms at every one (32 of 32).
* **Kerbs**: a small sine, `road_rumble` 1 or 2 of 37 giving 0.02 or 0.04 of force.
* After a hit the force holds about 0.17 s (0.125, the plugin's tail).
* Not seen over USB: the rumble the plugin sends for skids (> 12) and car contact (FFB_rumble 0 all run).
* No cornering or road-texture force at all, so the plugin's USB stand-in (0.15.0) would read each gear
  change as a road bump and a held wall force as cornering. GRID now has 0 rows for `car_road_bump` and
  `car_cornering`.

## Marks against the game values

| Mark (s) | Alexis's note | Game values |
|---|---|---|
| 1 (9.6) | driver view, revs maxed on throttle | speed 0, gear 0 |
| 2 (12.9) | race start, standing | speed 0 to 56 at 12.53 (clutch drop, wheelspin), gear 1 at 13.59 |
| 3 (26.9) | RHS wall at about 257 km/h, yaws anticlockwise | hit 26.80: strength 3, side + (right), 221 to 85; car_contact 1 too |
| (42 to 43) | RHS wall, drifting | hit 42.82: strength 2, side +, 120 to 62 |
| 4 (55.7) | opponent's LHS on my RHS | car_contact 2 at 55.03 to 55.56, strength 2 then 1 to 56.03; **side read left** (wall_side -1, so the FFB plugin also pushed from the left) |
| 5 (59.8) | LHS wall | hit 59.72: strength 3, side - |
| 6 (61.6) | RHS wall | hit 61.34: strength 4, side + |
| 7 (74.5) | right turn, no hit | nothing |
| (95.6) | LHS wall, front left, 254 km/h | hit 95.56: strength 2, side -, 216 to 204 |
| 8 (97.2) | RHS wall, yaws anticlockwise | hit 96.39: strength 6 (the hardest), side +, 202 to 86 |
| 9 (97.7) | drifting, scraping the wall | nothing: scrapes don't set hit_strength |
| 10 (105.1) | gentle left | car_contact 2 at 105.03 to 105.64, no strength; speed 175 to 162 in a frame |
| (108.5) | | hit 108.54: strength 2 for 0.8 s, side + for a frame, then - (wall_side 0.52 then -0.19) |
| 11 (110.0) | rear of an opponent; LHS wall; front right on his rear left | brakes locked from 109.65 (speed 150 to 0 at 109.90, then 80): no hit_strength or car_contact |
| 12 (111.6) | LHS touch or rear tyres on the kerb | wall_side to -1, skids 14, speed 8 to 10: no hit_strength |

So: every wall hit Alexis marked had the right side. Car contacts: car_contact read 2 at both contacts with a
car on her right (4 and probably 10), and 1 at mark 3 (no car noted), so it may be the side (1 left, 2 right).
Not confirmed; a recording with a car on the left would settle it, and then `car_contact` could give the side
of car hits (proposed, not built).

## Speed

* Peaked at 236 (straight before mark 7's LHS hit), where Alexis saw about 257 on the speedo; at mark 3 it read
  221 to 226 against her "about 257". km/h-like, but the ratio isn't settled.
* It behaves like driven-wheel speed: 0 to 56 in one frame at the clutch drop, 184 to 51 and back to 104 under a
  brake lock (53.6 s), 200 to 226 and back in 0.1 s at full throttle (22.7 s, wheelspin over a crest?).
* Max speed set to 250 (room over 236). `accel_g` now uses slope over 0.3 s and ema 0.15 s: the 22.7 s flick
  reads under 1 G (it was 17 G); brake locks still read hard braking (down to about -9 G).

## Other values

* Gear 0 before the start, 1 to 5.
* Skids 12 with grip, 13 to 16 in slides.
* wall_side keeps its last value between hits, and takes values like 0.47, 0.52, 0.66, 0.99, -0.15, -0.19 as
  well as +1 and -1.
* No `out_RPM` (OutputBlaster wasn't running), so revs and Max revs are still to do.
* Reads went blank from 116.6 s (the end of the session).

## Revs from memory (4 November 2026)

OutputBlaster gets GRID's RPM from a code hook (`GRID.exe+51C720`, a fastcall whose object holds the RPM float at +2C),
and TeknoParrot only loads OutputBlaster for games with an Enable Outputs option; GRID has none (only FFBBlaster). So
`out_RPM` never arrived. Alexis found the value with Cheat Engine instead (`GRID.CT`, now in the pack's GRID folder):

* Written by `fstp dword ptr [esi+2C]` at `GRID.exe+91C747`; ESI is the engine object, which sits at +258 in the car
  structure (so pointer chains end in 284; the "must end with 2C" pointer scan found nothing for that reason). CE's
  .CT lists offsets last first.
* Chains that held through TeknoParrot restarts, a reboot, another car and track and repeated races: the 284 family
  (`B1B100` 200,120,284; `5C76E4` 250,120,284 and 2DC,120,284; `73578C` 280,120,284) and the 5E0 family (`666F2C`
  220,8,5E0; `41CA50` and `5B2508` 2B8,8,5E0; `AE4F8` and `795DC8` 2F0,8,5E0). `5E45A8` A68,40,5E0 dropped out.
* Alexis: redline about 6900, limiter 7000, idle 636 or 1363 by car; the revs hold idle in the menus for a while
  before the start and after the finish.

Pack: `rpm` = `GRID.exe+B1B100` -> 200 -> 120 -> 284 (Float, / max_revs), `rpm2` = `GRID.exe+41CA50` -> 2B8 -> 8 ->
5E0, `car_rpm = valid(rpm, rpm2) * max_revs`, **Max revs 6900**; the OutputBlaster row is gone (GRID no longer passes
`'GRID'` as its OutputBlaster game). Not yet in a recording.

## Three recordings, 4 November 2026 (plugin 0.16.0, revs rows, USB capture)

`20261104-100725_GRID1` (96 s, 6 marks, no notes), `-101018_GRID2` (159 s, 7 marks, fastest car class),
`-101302_GRID3` (99 s, 3 marks). All have the new `Car_` columns. Fixture `grid-20261104-101302` (GRID3: raw reads,
`usb_*`, and the recorded `Car_rpm`, `Car_impact`, `Car_impact_side`, `Car_gear` as `rec_Car_*`), replayed by
`GridReplayTests.Fourth`: the replay matches what SimHub got live.

**USB matches.** `impact_side` was the G25's force one poll later in 89% (GRID1), 88% (GRID2) and 94% (GRID3) of hit
frames. The rest: the first and last frame of a hit, a gear-change sine on top of a hit (GRID1: 67 frames), and in
GRID2's pile-up the wheel got 0.03 more than hit_strength / 8 (-0.28 for -0.25, -0.41 for -0.38): the FFB plugin's
car-contact rumble adding in. Activity up to 105 commands/s.

**Revs.** Both chains read in all three (rpm and rpm2 differ only in 10 to 14 samples, when the game writes between
the two reads). 1000 in the menus and waiting at the start (GRID2, GRID3), 0 while a race loads (GRID1 first 3.8 s;
GRID2 after the finish). **Limiters by car: 8200 (GRID1), 7500 (GRID2, GRID3)**, 7000 for the car in Alexis's table.
At the limiter the revs cycle limiter, -5.7%, -11%. Idle about 1500 (GRID1), 1000 (GRID2, GRID3). With Max revs 6900,
Car_rev_limit fires from 6693, well before 7500 or 8200.

**Starts.** GRID2: revving from 10.18 (mark 1 at 10.61, the driver's view), moving at 14.2 (mark 2, 14.5). GRID3:
revving from 6.37 and held at the limiter; moving at 10.38, so **mark 1 (10.63) is the race start**. GRID1: moving
at 21.6.

**Speed against the speedo** (raw, as recorded with Max speed 250; Car_speed is raw):

| Recording | Alexis | Raw | Ratio |
|---|---|---|---|
| GRID2 mark 3 | about 282 | 221 to 227 | 1.25 |
| GRID2 mark 4 | about 299 | 233 to 242 | 1.25 |
| GRID2 mark 5 | about 190 | 146 to 152 | 1.27 |
| GRID2 mark 6 | about 309 | 249 to 258 | 1.21 |
| GRID2 top (mark 7, "331") | 331 | 337 peak at 71.8 s | (mark lag) |
| GRID3 top | 214 | 216 and 226 peaks | 0.95 to 1.0 |
| GRID3 mark 3 | 148 | 144 to 148 | 1.0 |
| 3 Nov | 257 | 236 | 1.09 |

So the speed row isn't the speedo's km/h, and the ratio depends on the car. **Max speed set to 280** (Alexis: a
middle for the car classes).

**Gear.** GRID1 and GRID3: 0 at the start, 1 to 5. **GRID2 (fastest class): 1 all race**, so the absolute gear
address doesn't work for every car.

**car_contact is a count**: it rises 1, 2, 3, 4, 5 in GRID2's pile-up (mark 4, 25.7 to 27.9 s) and counts back
down; GRID3 reached 3 (85.3 s). Not a side (the 3 November idea is wrong).

**Marks and hits** (hit_strength spans; side from wall_side; USB peak):
* GRID1: car contact on her left near the start (cc 1 at 23.5, 24.1; hits 25.77 and 26.97 to 27.8 with wall_side
  -1 at the left contact); walls 43.8 (-), 46.3 (-), 52.0 (-), 70.6 (+), 94.1 (+).
* GRID2: mark 4 pile-up from 25.69 (238 to 0, hs up to 3, cc up to 5; the car on her right read -1 first, then
  flipped); 28.84 front-right car hit (hs 4, +); RHS wall glances 34.1, 39.0 (+); 57.4 the RHS wall at 174 raw into
  the obstacle and spin (hs 5, sides both ways); 71.1 (mark 6, RHS wall, +); 78.2 (RHS wall after the long left,
  hs 6, +, 113 to 20); 81.9 (+).
* GRID3: 21.04 RHS wall (+), 21.23 contact on her left (wall_side -1, cc 1 then 2), 22.0 LHS wall (-), as noted;
  then 45.0 (-), 47.9 (+), 58.9 (+), 63.8 (+), 86.1 (-), 93.7 (-, hs 6), 97.7 (+).

Changes: Max speed 280; notes for speed (per-car ratio), gear (fails with some cars), car_contact (a count), rpm
(limiters by car). README GRID section rewritten. Values sheet GRID row.

**Ideas not built:** (1) find the car's limiter (or max RPM) in the engine object near the revs with Cheat Engine,
so the revs can be scaled per car and the rev limiter effect fires at each car's real limiter; (2) a gear and a real
speed in the same car structure (gear via the CE pointer route, since the absolute address fails for some cars);
(3) an in-race value (the engine effects idle in the menus): the revs read 1000 in the menus and 0 while loading,
so a pointer that's only valid in a race, or a race timer, would do.

## The on-screen dial (4 November 2026, afternoon)

Alexis dissected the structure around the revs in Cheat Engine (dumps at three cars and in the menu; `GRID.CT` in the
pack now holds the gear chains too). It is GRID's `dialinterface` object (the dash), created at load, so its address never
moved (0x34594C90). Offsets used, all via `GRID.exe+B1B100` -> 200 -> 120 -> offset:

| Offset | Type | Value | Evidence |
|---|---|---|---|
| 298 | Float | speed, m/s (x 3.6 = the speedo's km/h) | 95.7/156.2/211.7/265.3 vs noted 95/156/211/265 (13:15, fastest class, 1st to 4th on the limiter); 138.4 and 195.2 vs 138 and 196 (13:32 car); 61.3 in reverse (61), positive |
| 284 | Float | revs | (as before) stops at each car's limiter |
| 3B4 | Float | revs / this car's limiter, 0 to 1, never past 1 | rpm / frac = 8000.0 (fastest class, every sample 0.3 to 0.97), 8200.0 (13:32), 7000 and 6500 (Alexis's dumps) |
| 278 (= 274) | Byte | gear the dial shows: 1 to 6, 9 = reverse | 1st on the limiter 1, 2nd 2 at 156, 3rd 3 at 211, 4th 4 at 265; 9 while reversing; 1 at the start line. The old absolute gear is this minus 1 (0 = 1st; 0 in reverse) |
| 27C | Float | throttle as the game uses it | correlation 0.998 with the G25 pedal in two recordings, 0.73 in the third (the game cuts it at some shifts) |
| 254 (290 mirrors it, byte-swapped) | Int32 | shift lights: bit 0x1 and bit 0x100 | one lamp from about 85 to 88% of the limiter, both from about 95%, flashing at the limiter; off below 60% |
| 29C | Float | metres driven this race | rises with speed, 0 in the menus |
| 294 | Float | unknown | 2.5 to 2.8 on full throttle, about 1.3 at low revs, near 0 off the throttle |
| 370 | Float | tacho full scale | 8000 or 10000 by car (from 12000/10000/8000 at 21C to 224) |

254/290 were not an in-race flag after all (they're the shift lights). Pausing freezes every value (13:17 recording,
five pauses: nothing changed). No in-race value yet.

Changes: plugin **0.17.0** (`car_rpm_frac` source: Car_rpm_frac from the game's own fraction, falling back to rpm / Max
revs; CommonValuesTests). GRID profile: `speed` from 298 (km/h, Max speed 280 km/h), `gear` from 278 (`value >= 9 ? -1 :
value`), `rev_frac`, `rev_max` (hold of rpm / rev_frac), `throttle`, `shift_lights`, `distance`; `rpm2` kept; old rows
unticked as `wheel_speed` and `gear_abs`; `dial_294` and `tacho_scale` unticked; `accel_g` back to the standard smoothing
(the dial speed is smooth; hits still read -3 G and more). commonrows: GRID `car_rpm_frac = rev_frac`, `car_throttle =
throttle`. Fixtures `grid-20261104-131502` (fastest class), `-131816` (reverse), `-133227` (8200 car); the two older GRID
fixtures renamed `speed` -> `wheel_speed`, `gear` -> `gear_abs`, plus `gear` = gear_abs + 1. `GridReplayTests.Dial`.
