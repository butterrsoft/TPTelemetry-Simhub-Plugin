# STCC captures, 6 November 2026 (sent 8 November)

`TPTRAM_stcc_20261106_120650.txt` (RAM log) and `20261106-120707_M2STCC.csv` (TP Telemetry, about 120 Hz, USB capture on), marks pressed together through JoyToKey. A different car from the 5 November logs: 6 gears, 335 km/h top. Qualifying lap (marks 1-6), then a two-lap race with a rolling start (marks 7-11).

CSV marks (s): 1 5.71 title/attract, 2 40.88 grid revving, 3 43.76 start, 4 51.48 rear wheels in the air over the dip (ET 7.045), 5 59.20 after the hard RHS wall hit (ET 14.059), 6 74.08 finish (ET 27.555), 7 101.74 just after the rolling start, 8 105.47 grinding a car's rear bumper (ET 3.499), 9 106.58 almost free of it, 10 107.93 skidding back across a kerb (ET 5.748), 11 120.61 LHS wall impact (ET 17.230). RAM log marks (log s): 22.48, 57.72, 60.56, 68.25, 75.99, 90.88, 118.47, 122.26, 123.35, 124.74, 137.41.

## Confirmed at full rate

* All profile rows read every sample; marks match her ET readings to within a sample or two.
* **0x20ACD4** = frames with wheels off the ground, counting up: 1-19 over the dip (ET 6.84-7.19), 1-23 after the RHS wall hit (14.04-14.39; she put landing at 14.48), 1-17 after the LHS wall hit (17.34-17.59), and during the right-side lift on the kerb (5.19-5.33). Now `air_frames` → `airborne` (> 0) → Car_airborne and Car_landed.
* **0x20AC8C** = wall contact, 1 for a frame or two: RHS wall (13.87-13.95 before the big hit, 14.53 on landing), LHS wall (17.12-17.23, 17.70). No side; car-to-car grinding (ET 3.45-4.55) didn't set it. Now `wall_hit`; Car_impact = max(maxw(wall_hit, 0.2), the force-kick stand-in).
* The wheel force pushed the same way (negative) for the RHS and LHS wall hits, so it gives no hit side: Car_impact_side is 0 for STCC.
* **0x208886** surfaces: a digit 0 means that wheel is in the air (0x3030 with the right-hand wheels lifted on the kerb, 5.31). 0x3333 all four on the kerb; 0x4444 all on grass after the LHS wall hit; 0x2422/0x2424 the LHS grass patch.
* **0x20AD90** skid_flag: on through the skids, a little after grip_loss rises.
* grip_loss from the rear slip: 1.0 in the big qualifying slides (ET 4.8-5.2, 9.0-9.3), 0.3-0.6 in the race's drifting turns.
* **0x2022CC** race_time is the whole race (28.09 into lap 2), restarting at 0 for each race; in_race drops between qualifying and the race.
* Engine revs (0x208788) sit at about 12.8k on the limiter (p90 12806, p97 12834, max 13134).

## New

* **0x2061D4** = the "TIME EXTENDED" display timer: 158 at the line (log 149.63 s), down about 1 a frame to 0 by 152.42 (about 2.7 s; she saw it still up at lap ET 2.358). Never set in the three single-lap logs. Row `checkpoint` = value > 0, for a lamp.
* **0x2022F0** = laps completed (0 → 1 at the line). Row `laps_done`. Also 0x204640 (display, 0 → 1), 0x202568 (1 at the race start, 2 at the line).
* time_left jumped 17.23 → 35.09 at the line (+18 s).

## Profile changes (Alexis: effects from the engine revs)

* `rpm` = 0x208788 (engine) / max_revs; `rpm_tacho` = 0x208914 x 1.078 (raw). Max revs 12900 (97% = 12513: the limiter, and wheelspin there).
* Max speed 320 (tops 278 and 335 seen, two cars).
* `laps_done`, `checkpoint`, `wall_hit`, `airborne` (from air_frames), surfaces note (0 = in the air), commonrows M2STCC impact branch.
* 1440 tests pass; M2STCC 49 variables, 0 errors.

## Not found

* Car-to-car contact (no flag; grip_loss rose as the car yawed).
* The LHS kerb at ET 5.451 in qualifying didn't change the surface code (the car was sliding; maybe that kerb isn't a kerb surface).

## Delivered with this

M2-RAM-tools.zip: `M2-tests.md` (drive plans for Daytona and Sega Rally, the three-way recording method), generated scripts `SCRIPTS/{stcc,daytona,daytonas,srallyc,srallycb}.lua` (each runs `<rom>_orig.lua`, optional lamp patch, then tptram.lua with per-game regions: Daytona work RAM 0x500000-0x540000 + RAM2 0x200000-0x210000; Sega Rally and STCC RAM2 0x200000-0x240000 + work RAM 0x500000-0x510000).
