# Sega World Drivers Championship: Alexis's cheat table, 3 November 2026

`SWDC.CT` (Alexis): revs (Float, static `Todoroki-Win64-Shipping.exe+9EAF670`), and speed and gear in two
places each: speed1 Float [+9E29F58] 98, 10, 188; gears1 Int32 [+9E29F58] 98, 10, 238; speed2 Float
[+9D1AAE8] DD0, 20, 298; gears2 Int32 [+9D1AAE8] DD0, 20, 348 (offsets base first; the table lists
them last first). Copy kept as `tests/CoreTests/fixtures/swdc-20261103.CT`; a test checks the profile
rows read exactly what the importer makes of it.

## Alexis's notes

* Speed and gear read nonsense until the revs reach 3000 (the autodrive starts, before a session hands
  over control). Nothing should reach SimHub before then.
* With control, revs never go below 3000 (brake held at a standstill) and top out at 12000; redline
  about 11800.
* speed2 and gears2 seem slightly better. Raw speed tops out about 87.

## Speed against the speedo (17 readings)

| Raw | 0 | 3.2 | 4.8 | 12 | 15 | 20 | 27 | 33 | 34 | 39 | 46 | 52 | 62 | 70 | 73 | 85 | 87 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| km/h | 0 | 6 | 10 | 28 | 33 | 45 | 60 | 73 | 75 | 87 | 106 | 122 | 150 | 172 | 180 | 215 | 220 |

km/h per unit rises from about 2.1 to 2.5, so it isn't a fixed unit (mph would be 1.61, m/s 3.6).
Fits: straight line 2.434 x raw, out by up to 8.3 km/h; power 1.81 x raw^1.07, up to 6.1;
**2.0625 x raw + 0.005467 x raw², up to 2.5** (about reading error).

## Profile (moregames.py `extend('SWDC')`, commonrows SWDC case)

* `rpm` = `value >= 3000 ? value / max_revs : 0`; `in_race` = `rpm > 0`.
* `speed2` = `in_race ? value / max_speed : 0`, `gear2` = `in_race ? value : 0`; `speed1`, `gear1` the same,
  unticked, to compare.
* `speed_kmh` = the fitted curve; `accel_g` from it (the raw unit isn't one G can be worked out from).
* **Max speed 87** (raw), **Max revs 12200** (97% = 11834, about the redline; top 12000).
* Common values: Car_speed = raw speed2 (so speed_frac = raw / 87), Car_gear = gear2, Car_rpm, Car_accel_g,
  Car_in_race (gates the force-based effects too until 3000 revs).

## Answered (18:36)

* Version 2.30. No neutral or reverse in the game. Revs never go below 3000 with control; telemetry
  should start once the revs are above 3000 and stop when they stop moving (they freeze at the finish,
  where speed and gear go wrong). Recordings checked in `SWDC-capture-20261103.md`; the gating was
  reworked from them.
