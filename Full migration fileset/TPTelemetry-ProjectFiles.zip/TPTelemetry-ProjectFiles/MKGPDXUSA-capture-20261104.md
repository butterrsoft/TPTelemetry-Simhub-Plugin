# MKGPDXUSA capture check, 4 November 2026

Recording `20261104-135850_MKGPDXUSA.csv`: 49.5 s, about 120 Hz, attached the whole way, one marker at 15.24 s (race start; throttle from 14 s). USB capture (G25) and TeknoParrot shared memory both live.

## Memory rows

* **Empty the whole run (every pointer-chain row):** speed, force, steer, in_race, terrain, on_ground, drift, boost. All computed rows built on them are empty too.
* **Read, but 0 the whole run (the three fixed addresses):** hit (B96B74), coins (B4E330), item (B9548D). hit stayed 0 through the big USB hit at 28 s; coins and item never changed in a race of about 35 s. Treat as wrong, not quiet.
* Profile rows match the FFB Arcade Plugin source exactly (`MarioKartGPDXUSAReal.cpp`, `MarioKartGPDXUSACustom.cpp`); the user's `dinput8.dll` (1 Aug 2024) contains the same addresses. OutputBlaster has no USA build (CRCs for JP 1.10 and 1.18 only).

## Why it matters that the FFB plugin seems to work

* FFB_spring = 0.651 (166/255) from the first sample: the FFB plugin's SpringStrength=65 in the user's ini. So the FFB plugin (GameId 70, USA Real) is loaded in the game.
* FFB_force: 0 until the race starts, then ±0.02 to 0.04 while driving, -0.35 at 23 s, -0.95/+0.99 at 28 s. Real mode only sends a constant force when its read of `<main>`+B47B48 → +8 → +2FC is non-zero, so that chain looks valid inside the game, while TP Telemetry's read of the same chain fails at the first pointer.
* Open question: TP Telemetry attached to the wrong process or base (two MK_AGP3_FINAL.exe? `TryOpen` takes the first match), or a different build. To check: the Status column (hit row shows the address read; minus B96B74 = base used), Task Manager for two processes, Cheat Engine on `MK_AGP3_FINAL.exe+B47B48`, offsets 8, 2FC (float), and which TeknoParrot profile was launched (MKDXUSA or MKDXUSA106).

## TeknoParrot shared memory (works without memory addresses)

* tp_jvs3 = steering (r = 0.999 with the wheel), 129 at rest, 33 to 205.
* tp_jvs4 = gas, 0 to 255 (r = 0.99 with the throttle pedal).
* tp_jvs1 = buttons: 64 at rest, 68 (bit 4) while braking (622 of 854 braking samples).

## Plugin and profile problems found

* **car_in_race reads 1 when in_race is unreadable:** `in_race != 0` with NaN gives 1, so Car_in_race was 1 all run and effects weren't muted. 13 pack profiles use `x != 0` for car_in_race. Fix: `valid(in_race, 0) != 0` in the generator, or make comparisons with NaN give NaN.
* **USB stand-ins blocked by unreadable rows:** a game row that exists but reads NaN stops the USB stand-in (CommonValues `S()` only falls back when the row is missing). Car_impact stayed 0 through the 28 s hit; only Car_impact_side came from USB. Proposal: fall back to USB when the game's row is NaN.
* `hit` is a fixed address, so a wrong build reads 0 rather than blank, and hides the problem.
