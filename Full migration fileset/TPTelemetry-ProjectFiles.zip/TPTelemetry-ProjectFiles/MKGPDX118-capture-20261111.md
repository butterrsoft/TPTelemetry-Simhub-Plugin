# MKGPDX118 capture check, 11 November 2026

Recording `20261111-105714_MKGPDX118.csv` (plugin 0.18.1): 292.7 s at 120 Hz, attached throughout, USB capture on, 48 marks.
Alexis's notes: game start, 100cc Grand Prix as Mario, two laps from 6th, finish, auto-drive, menus. Race time (RT) on
screen = recording time - 78.55 s (GO).

## What the rows showed

* **race_state** (`<main>+AAEE80`, `38, C`): unreadable until 47.1 s; 1 at 47.1 (loading after the course is chosen),
  3 at 60.5 (fly-over, mark 1 at 65.6), 4 at 70.1 (behind the kart, mark 2), 5 at 73.4 (countdown), **6 at 78.54 (GO, mark 6)**,
  7 at 253.39 (the line, mark 47; the game then drives), 9 at 287.65 (menus), unreadable after. No attract play demo
  was recorded, so its race state is still unknown.
* **in_race** (the FFB plugin's chain): 1 from 78.55 to 253.38, but 0 for one sample at 169.64 (the lap line, mark 24).
  New row `racing` = race state 6 with in_race held 0.1 s; Car_in_race follows it.
* **speed** (kart +AC4): 140 to 150 racing at 100cc, 195 at the most without a boost, 217 boosted. **speed_snd** (+580)
  is filled after all: it follows speed a little behind (equal 56% of the time, within 5). Max speed not set yet.
* **rpm** (kart +AC8): 8000 to 9300 racing (99th percentile 9318), 12360 at the most, 4300 at the least. Max revs not set yet.
* **steer**: + right (right-hand drifts about +0.8).
* **force** (kart +BC8): about 0 driving straight, +0.45 to +0.71 in right-hand drifts, -0.3 to -0.78 in left-hand ones,
  swinging -1 to +1 five times a second in the spin-out at mark 11 while the kart travelled in a straight line. That is
  the sine of the angle between where the kart points and where it goes (as the USA exe's code works out its +2FC), and
  the USB wheel force matched it (r = 0.995): the FFB plugin sends it. New row **drift_angle** = asin(force) in degrees,
  + right-hand: right drifts 27 to 46, left 14 to 51 (median under 1 degree off a drift, 99% under 22).
* **slip** (+3BC): ±1 as a drift starts (+ right), easing towards 0 by 0.1 a second while it lasts (0.53 after 4.7 s).
  Neither the drift meter nor an angle.
* **drift** (sound +6B8): 18 drifts, from the hop to the release, every one in the notes. **drift_side** (+6BA): 1 = left
  (all seven left drifts).
* **kart_state** (+48C): 0 driving, 1 the hop into a drift (always 0.27 s), 2 drifting, 3 bumped up by an item while
  drifting (131.84, mark 17), 5 hit and flipped (143.28), 10 spun out (117.02, mark 11, 0.97 s), 17 kite launch (0.2 s),
  18 gliding (109.47 and 193.52, 4.4 s each), 22 on the grid.
* **kart_flags** (+810): 4 gliding, 4194304 for 0.2 s at each kite launch, 8388608 for about 3 s after the item hits at
  117.87 and 134.75 (recovering).
* **boost** (`<main>+AAD0BC` +3A4): the boost start, every mini-turbo she noted (marks 9, 14, 19, 22, 23, 26, 28, 31, 33, 35,
  36, 41) and the kite ramp; 1.5 to 1.7 s after a stage 1 drift, about 2.0 s stage 2, 2.3 s stage 3.
* **on_ground** (+69C): 0 in the hops, the spin-out and the glides, and for a frame (0.02 s) at each log of the ripple
  strips. New `airborne` (off the ground more than 0.1 s, not a hop) and `landed`, `hop`, `hop_landed`, `gliding`.
* **terrain** (+66C): 3 nearly all race (the ordinary road, "dirt" in the FFB plugin's list, so rough_ground and
  Car_off_road were on all race); the log strips flick 3/8 every 0.08 s (102.8 to 105.0 and 187.7 to 189.5: new
  `rumble_strip`, both strips and nothing else); 7 water (106.6, 191.0: her "through water?" at mark 30 was water); 0 in the
  air; 12 on the steps after each kite (114 to 119, 198 to 204); long stretches of 8 (137 to 150, 220 to 226), 13 and 10;
  4 for under 2 s at 165.2, 167.8, 177.9 and 248.5. Car_off_road now uses grass (4) and sand (14) only.
* **hit** (the shake word): walls, karts and items as noted (84.7 Wario, 117.0 spin-out, 120.2 Princess, 131.9 item,
  143.3 flip, 176.7 Princess, 204 to 210 the RHS wall and Luigi, 226.4 RHS wall, 231.8 LHS wall, 248.6 LHS wall, 251.1 to
  251.9 karts while giant), the kite launch (110.2) and landing (113.8), twice in the countdown (76.9, 77.7), and at 96.1,
  134.8/135.1 and 161.8 (not in the notes). New `hit_race` leaves the countdown out; Car_impact = hit_race or `knocked`.
* **coins** (`<main>+AB9110`): a coin counter, 0 to 20, up one per coin. Every coin in the notes, plus one at 117.65 (the
  spin-out), four at 218.95 to 219.25 and three at 250.95 to 251.20 (hitting karts while giant?). coin_pickup now on rises only.
* **item** (`<main>+AC5C0D`): exactly the button lamp byte (ob_buttondata) all recording, not an item. Bit 4 is the item
  button's lamp: lit from an item box until the item is used or lost (86.06 to 90.65, the red shell). Bit 8 is lit while
  driving in a race (off for hops, the spin-out and the glides). The `item` row is gone; new `item_held`, `item_got`,
  `item_gone`.
* **Lamp words** (side/billboard +AC72D8, under +AC72E8, as Int32): LED colour levels, 0 to 15 a hex digit, five digits in use in
  each (a rainbow cycling through them in the attract mode, other patterns in the race). OutputBlaster's masks don't fit
  them, so the on/off lamp rows flicker. Which digit is which LED needs the game's code.
* **phys_a/b/c** (`8, CC, 0, 7C`): (1, 0, 0) nearly always: not a velocity. Removed.

## Profile changes (memgames.py `_mk118`, `_mk_derived`; commonrows.py; moregames.py notes)

* New rows (v1.18, and the USA profile by the same code): racing, drift_angle, drift_strength (the angle with ID6's
  weighting, while the drift flag is on: right drifts 0.8 to 0.95, left 0.4 to 0.9, her "very slight" one 0.5), hop,
  gliding, spin, knocked, recovering, airborne, landed, hop_landed, rumble_strip, off_road, item_held, item_got,
  item_gone, hit_race.
* Common values: Car_in_race racing; Car_impact max(hit_race, knocked); Car_road_bump landings (1) and hop landings (0.5);
  Car_rumble_strip; Car_off_road grass and sand; Car_drift drift_strength; Car_drift_angle; Car_grip_loss max(drift, spin);
  Car_airborne airborne.
* MKGPDXUSA's drift_angle sign flipped to match (+ right-hand), by v1.18's recording.
* Test: Mk118Tests.cs replays the recording (fixture `mkgpdx118-20261111-105714.csv.gz`, raw reads from 40 s).
  **1680 pass with the pack, 764 without.**

## Alexis's answers, the v1.18 exe and the attract recording (later on 11 November)

* **Max speed 160, Max revs 10000** (her choice). Boosts go past both (217 and 12,600 at the most), so Car speed and revs
  pass 1 then.
* **Surfaces** (course 1 of the Donkey Kong cup): 3 the yellow dirt road, 4 the grassy verge, 7 water (also the shallow
  water over pavement at 125 to 127 s and over jungle floor at about 161 s), 8 wood (the old mine-cart railway platform
  and the ripple-strip logs), 10 the planked bridge, 12 tessellated pavement (up the steps, then 115 to 125 s), 13 jungle
  floor. `off_road` (Car_off_road): 1 grass and sand, 0.5 bridge, 0.4 wood, 0.25 jungle floor, 0 road, pavement and water,
  and not on the ripple strips. Sand (14 in the FFB plugin's list) waits for a beach course.
* **The unexplained shakes were hits:** i (96.1) Princess on her left, ii (134.8) Luigi on her right (Pac-Man on her left a
  moment later), iii (161.8) Luigi on her left in water over jungle floor. New `slide_at_hit`, `drift_at_hit`,
  `slide_kick`, **`hit_side`** (Car_impact_side): the knock to the kart's slide while the hit lasts, against the slide over
  the 0.3 s before it. Right for i, ii and the three walls and karts named earlier (96.05 and 248.64 left, 120.2 and
  134.77 right, 231.75 left); 0 for iii (too small a knock to read) and never the wrong way round at her ten other marked hits. Hits in
  a drift or just after one give 0 (the slide is unwinding then: a hit at 206.48 read right before that was added).
* **The coins** at 117.65 (1), 218.95 (4) and 250.95 (3) are real coins: `coins` and `coin_pickup` stand.
* **v1.18 exe** (`MK_AGP3_FINAL_-_v118.exe`, SHA-1 65aee49c2d409a6729972eae7380f7530de3de55, the same file as 9 November):
  place, laps and race time found (see MKGPDX118-exe-20261111.md). New rows `position`, `laps_done`, `laps_total`,
  `race_time` (seconds), unticked `race_timer_1c`, and computed `lap`, `final_lap`, `leader`, `place_gained`,
  `place_lost`. Not in this recording, so still to see in the next one (her place changed at i and ii, though the HUD
  lagged).
* **Attract recording** (`20261111-123730_MKGPDX118-2.csv`, 628.3 s, menus all the way, 3 marks): the play demo ran three
  times (153.6 to 200.6, 365.1 to 412.0, 576.0 to 622.9), each with race state 1, 4, 5, **6**, 9, like a real race. The FFB
  plugin's in-race flag stayed 0 all recording and `hit` never shook, so `racing` (race state 6 and the flag) stayed 0:
  no SimHub effects in the demo, which is what she asked for. The FFB Arcade Plugin itself still turns the wheel then
  (`force` reached ±1 in the demo); that comes from the FFB plugin, not this profile. Mark 1 (581.6, demo race) and mark 2
  (621.6, the planks) read terrain 8 with force about 0: the planks give no force texture to capture, but Car_off_road
  gives them 0.4 in a real race. Mark 3 (625.7, menus): race state unreadable, terrain 15. The demo courses read 12, 3, 8,
  15 and 0; 15 is a code course 1 doesn't use.
* Test: Mk118Tests.cs now checks hit sides, surfaces and Car speed over Max speed; MemProfilesTests checks the new chains
  in both versions and that race state 6 without the in-race flag gives no racing. **1702 pass with the pack, 764
  without.** MKGPDXUSA got every change above (its own addresses, see MKGPDXUSA-exe-20261111.md).

## Second recording (14:20): Mario cup course 1

`20261111-142048_MKGPDX118-3.csv`: 195.6 s, 31 marks, four laps from 6th, won. GO at 82.97 s, the line at 192.85.
Kept as the test fixture `mkgpdx118-20261111-142048.csv.gz` (raw reads from 45 s; `Mk118Tests.MarioCup`).

* **Laps:** `laps_total` 4 (2 before the race, left over from the last one); `laps_done` ticks at 112.57, 138.70, 167.82
  and 192.82 (the line). The FFB plugin's race flag dropped for a sample at the third line only.
* **Place:** 6th on the grid, 1st at the line; it changes on whole seconds (x.95), so it is the HUD's number, updated once
  a second (Alexis saw the HUD lag her real place in the first race too).
* **Race time:** 105.488 s at the line (lap lines 28.432, 53.520, 81.472). The game's clock adds 16 ms a frame, so it runs
  0.96 of real time (109.87 s). Race time isn't on screen while racing, so it can't be checked against the HUD.
  `race_timer_1c` is 250 s less the race time (a countdown; a time limit), kept unticked.
* **Surfaces (her names):** 0 the blue, stripy rebound-ace road; 11 its verge; 13 striped blue and gold glass (8 to 10 s
  each lap), ending in three boost rings (10, the flicks every 0.45 s) with sand (14) between and after them; 12 pavement
  (not like the tessellated pavement, same code). So **the codes are the game's surface kinds**, shared by surfaces that
  look different: 13 is both the jungle floor and this glass. `off_road`: 11 now 1 (a verge, like grass); 13 now 0 (the
  glass shouldn't rumble; the jungle floor loses its 0.25).
* **Events (hers):** 91.9 an item from behind kicked the rear wheels up (state 3); 100.2 the right-hand wall, 127.5 a kart
  on her right, 158.2 into the rear of a kart passing on her left; 110.9 to 113.4 an enemy item flipped her into the air
  spinning over and over (**state 6**, off the ground, a steady 94 km/h); 147.0 a kart on her left, 147.8 one on her
  right; 161.1 a banana peel spun her (state 10), then a hit on her right while spinning (162.3); 175.7 a kart on her left.
* **Changes:** `spin` and `knocked` include state 6; `hit_side` threshold 0.06 (catches the wall at 100.2), and 0 in
  spins, drops and glides (only states 0 and 3); 175.7 and 127.5 still read 0, never the wrong way round.

## Still to do

* A beach course, for the sand code (14 is sand on the Mario cup, so the code is known; her beach course would confirm it).
* From the exe, still not found: the drift meter stage (the boost length gives it: 1.5, 2.0, 2.3 s), and which digit of the
  lamp words is which LED.
