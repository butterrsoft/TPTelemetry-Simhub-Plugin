# Sega World Drivers Championship recordings, 3 November 2026

Four recordings, version 2.30, with the 14:45 profile (speed2, gear2, revs from Alexis's table):

| File | Length | Notes |
|---|---|---|
| `20261103-175900_SWDC-1` | 144 s (game closes at 77.0 s) | 10 marks, Alexis's notes (below) |
| `20261103-180231_SWDC-menus` | 4 s | menus: every value 0 |
| `20261103-180418_SWDC-start_race` | 69 s | loading, rolling start, race; 10 marks |
| `20261103-180640_SWDC-ends_with_finish` | 32 s | 3 marks; the last is the finish line |

Fixtures `swdc-20261103-175900` (first 80 s), `-180418`, `-180640` (raw reads; `revs` from the recorded
car_rpm, which kept full precision), replayed by `SwdcReplayTests`.

## USB capture: 19:30 recording (working)

`20261103-193031_SWDC`: 46 s mid-race, 4 marks, USB capture working (fixture `swdc-20261103-193031`).

* **Force matches**: the force decoded from memory against the force the G25 got: correlation 0.974 with the
  wheel one poll (about 8 ms) later; the wheel gets 0.93 x the game's force (the FFB plugin's strength
  settings). Same sign; + is steering right (0.85 against the wheel's steering), so + = force from the right.
* **Spring doesn't**: the wheel's spring (0 to 0.48) follows the game's spring command only loosely
  (correlation 0.47): the FFB plugin applies its own spring settings. Nothing uses the spring for an
  effect apart from in_race, which uses the game's command.
* Hits at 28.53 (198 to 132 km/h), 36.84 (190 to 125) and 41.91 (156 to 93); the wheel got only 0.35 to 0.39
  of force at them, so USB adds nothing for hits in this game. Elsewhere the speed fell at 3.3 G at most.

## USB capture: no data in the 17:59 to 18:06 recordings

USB capture was ticked (FFB_connected 1) but saw no wheel commands in any recording (activity 0, every
FFB_ value blank), so the force decoding couldn't be compared with what the wheel got. The capture may
need the wheel re-selected (Find Devices) after a reboot. TeknoParrot's slot 2 is not the force here:
it reads 2 for a moment at most upshifts and 1 at some downshifts (shift buttons, it seems).

## Revs, and when values are real

* Menus: revs 0, speed and gear 0.
* Session loading: revs exactly 3000.0044, speed reads 43.0 or 43.15 (about 99 km/h) and gear 1 then 2:
  nonsense.
* Countdown to the rolling start: revs frozen at 9326.4974 (two one-frame wobbles of under 0.1), speed
  still 43.15.
* Race: revs move every frame (still for 0.15 s at most); speed and gear real.
* Finish line: revs freeze at 30.00 s; the centring spring drops to the menu strength (0.047) at 30.02;
  speed jumps to 43.02 (99 km/h) at 30.11 and gear stays 6.
* Game closing: everything 0 (77.0 s in the first recording).

The centring spring the game sends is 0.047 in the menus, loading and countdown and from the finish,
and 0.17 to 0.99 while driving. So `in_race` = revs above 3000, revs changed in the last 0.2 s, and the
spring above 0.1 for 0.1 s. Results: on at 11.55 (race start about 11.4), 9.07 (8.85) and from the start
of the third; off at 77.03 and 30.01; never off while driving. Speed, gear and revs read 0 outside it.
accel_g is 0 for the first 0.3 s of a race so the speed coming on isn't a jolt.

`speed1` and `gear1` read nonsense in every recording (up to 10^38 and 2 billion). `speed2`/`gear2` are
the ones (gear 1 to 6; no neutral or reverse in the game). The speed changes at fixed rates, so it rises
and falls in straight lines.

## Hits

At every wall and car hit the game slows the car at a fixed 4.6 to 5.5 G (2.7 to 2.9 km/h a frame) for
0.1 to 0.4 s. Nothing else passed 2.9 G (grinding along a wall about 2 G).

| Recording | Time | km/h | Notes |
|---|---|---|---|
| 17:59 | 26.39 | 159 to 128 | RHS wall on the verge (marks 4/5); force kick +0.93 |
| 17:59 | 44.38 | 183 to 117 | LHS wall at 183 km/h (speed_kmh read 183) |
| 17:59 | 45.11 | no loss | RHS wall at 124 km/h "that doesn't seem to slow me down": force kick +0.64 only |
| 18:04 | 29.14 | 187 to 142 | rear of a car (mark 1 at 29.30) |
| 18:04 | 33.84 | 161 to 140 | rear of a car (mark 2 at 33.81) |
| 18:04 | 43.90 | 167 to 140 | around marks 4 to 6 (RHS wall grind, RHS rear of a car) |
| 18:04 | 50.11 | 181 to 124 | LHS wall (before mark 7) |
| 18:04 | 52.18 | 145 to 90 | RHS wall (mark 7 is "RHS wall impact") |
| 18:04 | 58.23 | 159 to 88 | RHS wall after mark 8 |
| 18:06 | 0.95, 3.59 | 208 to 170, 144 to 133 | not noted |
| 18:04 | 21.75 | 202 to 183 over 0.25 s | grinding along the LHS wall: about 2 G, not a hit; game vibration on |

The force kicks (the old force-based Car_impact) came at a few hits only, and their side didn't always
match the wall, so hits found from the speed have no side.

## Vibration

The game sends its vibration command (133) on grass verges and when grinding along a wall, at 0.016 to
0.11 (more the faster you go): 17:59 22.1 to 28.5 s (RHS strip and verge, marks 3 to 5), 29.8 to 33.4 s
(LHS verge), 55.2 to 61.7 s (marks 7 to 9); 18:04 21.75 to 22.4 s (wall grind). Not on the ripple strip
in the 18:04 run. Car_vibration now scales it so 0.1 reads 1.

## Profile changes

* `revs` (unticked raw), `in_race` (above), `rpm` = `in_race ? revs / max_revs : 0`; speed2, speed1, gear2,
  gear1 = 0 outside a race; `accel_g` held at 0 for 0.3 s; `hit` = more than 4 G slowing, held 0.3 s.
* Car_impact = max(force-kick hit, speed hit 0.5 + km/h lost / 120); Car_impact_side from force kicks only;
  Car_vibration = vibration / 0.1.

## Not found

Ripple strips, checkpoints, the finish line itself (other than the revs freezing).
