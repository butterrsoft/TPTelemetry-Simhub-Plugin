# Initial D Arcade Stage Ver. 3 in Flycast (FLYINITD3): Flycast's RAM and a recording profile, 17 November 2026

Alexis sent `flycast.exe` and `initdv3e.zip` and asked for the Initial D 3 profile to be updated for recordings (this
game only). Pack rows: `moregames.py` (`fly_ram`, `fly_id3_rows`); setup notes in `gamesetup.py`.

## What the files are

* `flycast.exe`: Flycast **v2.5-219-g27a913fc0**, 64-bit, MD5 d0def34950920645bce4acdfa21bb36e (19.1 MB, stripped).
* `initdv3e.zip`: the NAOMI 2 BIOS ROMs (`epr-236xx.ic27`), their EEPROMs and the security keys (`317-0384-com.pic` is
  this game's). **No game program:** Initial D 3 is a GD-ROM game (GDS-0033), so its code and data are on the CHD,
  encrypted with the key in the PIC. Nothing in the zip says where the game keeps speed, revs or gear.
* The FFB Arcade Plugin and OutputBlaster have no memory addresses for it either (the FFB plugin reads `midiffb` from
  Flycast's outputs; its Demul code scans for the same message).

## Flycast's emulated RAM (from the exe)

* The memory set-up function (around `<main>+140929`) takes `ram_base` (the global at `<main>+2253CE0`) and stores
  `ram_base + 0x04000000` (video RAM), `+ 0x20000000` (sound RAM), `+ 0x0A000000` (NAOMI 2's second graphics RAM) and
  **`ram_base + 0x0C000000` into `mem_b.data`, the global at `<main>+2840C90`**; the next field (+8) is the RAM size.
  Other code uses the same pair (`[ram_base] + address + 0x0C000000`, or `mem_b.data + address` when `ram_base` is null),
  so `mem_b.data` is right with or without Flycast's big address-space mapping.
* So a game address `0x0Cxxxxxx` (or its mirror `0x8Cxxxxxx`) is a Memory row with Module `<main>`, Base offset
  `2840C90`, Offsets `address & 0x1FFFFFF` (NAOMI 2: 32 MB; NAOMI: 16 MB, `& 0xFFFFFF`). `fly_ram(name, type, address,
  notes)` in `moregames.py` writes such a row. SH-4 is little-endian, so types read as they are.
* Build-specific: another Flycast build needs its own base offset. Find it again from the instruction pair
  `lea reg, [rax + 0xc000000]` / `add rax, 0xa000000` (one place in the exe); the store after it is `mem_b.data`.
* Process `flycast.exe`, read through the 64-bit helper. The game is still chosen in the Game list.

## Outputs (from the exe)

* The JVS board code (`<main>+929600` on) sends each changed output bit as `lamp<bit>`, bits 0 to 31; the first output
  byte is bits 0 to 7. Which bit is which lamp on this cabinet is not known yet.
* `midiffb` as before.

## The profile now (24 rows)

Force rows as before; `lamp0` to `lamp7` and `lamp_bits` (bits 0 to 15 in one number); `ram_probe` (UInt32 at game
address 0x0C020000, where NAOMI programs normally load: a steady non-zero number shows the memory read works). Process
`flycast.exe`. No speed, revs, gear or race values yet. 1969 tests pass with the pack.

## Next: the game program

Asked Alexis for Flycast save states made during a race instead of the CHD (over 200 MB): a state holds the whole 32 MB
of RAM, so the decrypted program and the live values together, at a fraction of the size. Three states in one race
(countdown; two moments at different speeds and gears), each with the speedo, gear, rev counter, RT and TT she sees when
the menu opens, plus the course, car and gearbox. With those: find the program's speed, revs and gear by value, then
read the code around them (SH-4) for the race state, clocks, checkpoints and events, as for the other games.

## 19 November 2026: Flycast v2.7-1-g44e4c7b50

Alexis updated Flycast; a recording with the profile (12:39) read nothing from memory on any row, `ram_probe` included,
while the outputs (`midiffb`, lamps) still arrived and the process attached: the RAM pointer had moved. Her new
`flycast.exe`: **v2.7-1-g44e4c7b50**, 64-bit, 21.0 MB, MD5 d8db8f697e26e5384a186eb2c8b79289.

* The same set-up code, found the same way (`exe/dis.py`, then the one `lea rdx, [rax + 0xc000000]` beside
  `add rax, 0xa000000`): at `<main>+147DF9`. It stores `ram_base + 0x0C000000` through `rsi`, loaded from the pointer at
  `<main>+129D910`, which holds **`<main>+29D0C10` (mem_b.data)**. ram_base is `<main>+24236E0`. The fallback reads at
  `<main>+18EB37` and `+18EB87` (`[ram_base] + address + 0x0C000000`, or `[mem_b.data] + address` when ram_base is null)
  use the same two globals, as in v2.5.
* So `FLY_RAM` = `29D0C10` (v2.5-219-g27a913fc0: `2840C90`, ram_base `2253CE0`). Nothing else changes: the game's own
  memory is the same, so every offset and `@` chain stands.
* **How to do it next time:** in the old build the pointer to mem_b.data was at `<main>+10E4020`; in v2.7 at
  `<main>+129D910`. Read it with `exe/const.py q:<address>`; the value less 0x140000000 is the base offset. Only one
  profile can carry one build's offset: if she needs both builds, a second profile (another prefix) would be needed.
* Not yet confirmed in a recording: `ram_probe` should read a steady 3509307139.
