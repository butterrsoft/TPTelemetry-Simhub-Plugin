# Initial D 3 in Flycast (FLYINITD3): save states and the first game rows, 17 November 2026 (afternoon)

Follows `claude/FLYINITD3-flycast-20261117.md`. Alexis sent two recordings made with the first profile and two save
states. Tools: `sh4/flystate.py` (unpacks a state), `sh4/sh4dis.py` (SH-4 disassembly from the RAM image). Pack rows:
`moregames.fly_id3_game`.

## The recordings (first profile; Broadcast Digital Outputs off)

* `20261117-123811_FLYINITD3-1.csv` (315 s; Trueno, manual, Akina Lake, vs Iggy) and `20261117-125110_FLYINITD3-2.csv`
  (839 s; GT-R, manual, same course and rival; pauses where she made save states). 120 samples a second.
* **`ram_probe` read 3509307139 (0xD12BD303) on every sample of both:** the plugin reads Flycast's emulated RAM through
  `<main>+2840C90`. (The states hold 03 C7 2B D1 there: the first byte pair differs in the saved copy, the rest matches.)
* `ffb_raw` and the lamps are 0 throughout: she had Broadcast Digital Outputs off, because with it on the game freezes
  in the menus as soon as she turns the wheel to a new selection, with or without SimHub. USB capture's `FFB_force` is
  live in both, so Flycast drives her wheel itself. The FFB Arcade Plugin's files are in the folder too (no
  OutputBlaster). Best guess, not tested: with outputs on, the FFB plugin starts driving the wheel as well and the two
  clash. To test: outputs on with the FFB plugin's files renamed. The memory rows don't need the outputs.

## Save states

* Format (Flycast v2.5): `FLYSAVE1`, time, version 0x353, a PNG screenshot (640 x 479, the HUD at the moment of saving),
  then RZIP (zlib chunks of 1 MB) unpacking to 92.5 MB. The game's 32 MB of RAM starts at 0x3829337 of the unpacked state
  (found from pointers to strings; the BIOS's copy of the game header is at RAM+0x1F400).
* `initdv3e_3.state`: RT 37, TT 1:52.183, ADVANTAGE -86.2 m, 174 km/h, 4th, about 9,300 revs, lap 2 at 0:31.536
  (lap 1 1:20.646).
* `initdv3e_4.state`: RT 48, TT 2:40.883, ADVANTAGE +2.1 m, 202 km/h, 5th, about 8,650 revs, lap 3 at 0:17.388
  (lap 2 1:02.848). (Her other guess for this one, RT 35 / TT 2:53.683, was a different moment.)

## Found by value (both states agree with the screen)

| Value | Game address | Type | Notes |
|---|---|---|---|
| speed | 0x0C900C2C | float, m/s | x 3.6 = 174.88 and 202.87; the speedo shows the whole number below. 0x0C900C28 is a second speed beside it |
| revs | 0x0C900EA4 | float | 9280 and 8651 (the HUD's own copy is slightly smoothed: 9291, 8650). 0x0C900EA0 a second value (9159, 8502) |
| gear | 0x0C900E88 (also +4, +8) | int | 4 and 5; 0x0C900DE4 is gear less one |
| ADVANTAGE | 0x0C901650 | float, m | -86.35 and 2.40 |
| time left | 0x0DAF0768 (heap) | int, 1/6000 s | 226700 and 288500: a timer object (vtable 0x0C38143C, step -100 a frame) |
| race clock | 0x0DF98C48 (heap; +44 is one frame behind) | int, 1/6000 s | 673200 and 965400 |
| lap index | 0x0DF98C50 (heap) | int | 1 and 2 |
| HUD block | 0x0DCF6084 (heap) | | +0 time left, +8 gear, +18 TT, +1C.. lap times, +50 km/h, +54 revs, +60 ADVANTAGE |

* **Static:** the player's car is a fixed structure, about 0x0C9008A4 to 0x0C9017F8; the game's code loads 0x0C900954,
  0x0C900F00, 0x0C900E88, 0x0C900EA4 and 0x0C901650 as constants (code around 0x0C157000 to 0x0C15F000). A second copy of
  much of it sits 0x510 higher (0x0C900F00 on). A small static block at 0x0C2FB3A0 has copies of gear and revs (code at
  0x0C0C4000), and another car-like block at 0x0CAA9864 on (code at 0x0C15A000 to 0x0C15F000).
* **Heap:** the clocks and the HUD block are in allocated memory (0x0D......), reached through objects, not a fixed
  pointer I could find yet (the static table at 0x0C8FF170 to 0x0C8FF1DC points at neighbouring objects only). The
  addresses are the same in both states, but both are one race. A recording in another race shows whether they hold.
  If they move: find the code that reads the timer (constructor literals at 0x0C039EEC and 0x0C039F34) and its owner.
* The game loads more code into the heap (many `rts` around 0x0D400000 and 0x0DD00000 to 0x0DF00000).

## The profile now (80 rows)

`speed` (km/h), `rpm`, `gear`, `accel_g`, `gap`, so Car_speed, Car_rpm, Car_gear and Car_accel_g; `rt`, `race_clock`,
`lap` and three HUD copies (heap); 40 unticked candidate rows from the car structure and nearby (possible throttle,
brake, steering, sideways speed, wheel speed, what each wheel is on, position and heading, counters), each with its two
state values in its note. No Car_in_race yet. Max speed and Max revs not set. 1969 tests pass with the pack.

## Asked of Alexis

A recording with this profile and the video in step: a race in a different car on a different course (to test the heap
rows), with a standing start, a few seconds each of full throttle, coasting and braking in a straight line, a kerb or
strip, a wall scrape each side, a car contact and a drift each way.
