using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

// TPTelemetryFfbTest.exe: plays a fixed pattern of force feedback effects on a wheel through DirectInput, the way
// games do, while TP Telemetry records the USB traffic. Each effect's start and stop time goes to a log beside the
// capture, so every USB command can be matched to a known force. A separate program so that a driver fault can never
// take SimHub down. Forces stay at 50% or less: direct drive bases are strong.
//
//   TPTelemetryFfbTest.exe [--vid 346E --pid 0004] --log <file.txt>
//
// Written from the DirectInput 8 documentation; not yet run against a real wheel.
namespace TeknoTelemetry.FfbTest
{
    static class Program
    {
        static StreamWriter _log;
        static readonly Stopwatch Clock = Stopwatch.StartNew();

        static void Log(string s)
        {
            string line = $"{DateTime.UtcNow:yyyy-MM-ddTHH:mm:ss.fffZ}\t{Clock.Elapsed.TotalSeconds:0.000}\t{s}";
            Console.WriteLine(line);
            _log?.WriteLine(line); _log?.Flush();
        }

        [STAThread]
        static int Main(string[] args)
        {
            int vid = 0, pid = 0; string logPath = null;
            for (int i = 0; i + 1 < args.Length; i++)
            {
                if (args[i] == "--vid") vid = Convert.ToInt32(args[++i], 16);
                else if (args[i] == "--pid") pid = Convert.ToInt32(args[++i], 16);
                else if (args[i] == "--log") logPath = args[++i];
            }
            try
            {
                if (logPath != null) _log = new StreamWriter(logPath, false);
                Log("TP Telemetry force feedback test pattern" + (vid != 0 ? $" for {vid:X4}:{pid:X4}" : ""));
                return Run(vid, pid);
            }
            catch (Exception e) { Log("error: " + e); return 2; }
            finally { _log?.Dispose(); }
        }

        static int Run(int vid, int pid)
        {
            var hinst = Marshal.GetHINSTANCE(typeof(Program).Module);
            var iid = typeof(IDirectInput8W).GUID;
            int hr = DirectInput8Create(hinst, 0x0800, ref iid, out IntPtr diPtr, IntPtr.Zero);
            if (hr < 0) { Log($"DirectInput8Create failed {hr:X8}"); return 1; }
            var di = (IDirectInput8W)Marshal.GetObjectForIUnknown(diPtr);

            // the force feedback game controller with the wheel's vendor and product, or the first one
            Guid found = Guid.Empty; string name = null;
            EnumDevicesCallback cb = (inst, ctx) =>
            {
                var instance = Marshal.PtrToStructure<Guid>(inst + 4);
                int product = Marshal.ReadInt32(inst + 20);   // guidProduct.Data1 = MAKELONG(vendor, product)
                bool match = vid == 0 || ((product & 0xFFFF) == vid && ((product >> 16) & 0xFFFF) == pid);
                if (match && found == Guid.Empty) { found = instance; name = Marshal.PtrToStringUni(inst + 4 + 16 + 16 + 4 + 260 * 2); }
                return found == Guid.Empty ? 1 : 0;
            };
            hr = di.EnumDevices(DI8DEVCLASS_GAMECTRL, cb, IntPtr.Zero, DIEDFL_ATTACHEDONLY | DIEDFL_FORCEFEEDBACK);
            GC.KeepAlive(cb);
            if (found == Guid.Empty) { Log("no force feedback wheel found" + (vid != 0 ? $" with ID {vid:X4}:{pid:X4}" : "")); return 1; }
            Log("wheel: " + name);

            hr = di.CreateDevice(ref found, out IntPtr devPtr, IntPtr.Zero);
            if (hr < 0) { Log($"CreateDevice failed {hr:X8}"); return 1; }
            var dev = (IDirectInputDevice8W)Marshal.GetObjectForIUnknown(devPtr);

            // data format: just the X axis (the wheel), which is also the force feedback axis
            IntPtr xGuid = Marshal.AllocHGlobal(16); Marshal.StructureToPtr(GUID_XAxis, xGuid, false);
            var obj = new DIOBJECTDATAFORMAT { pguid = xGuid, dwOfs = 0, dwType = DIDFT_AXIS | DIDFT_ANYINSTANCE, dwFlags = 0 };
            IntPtr objs = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(DIOBJECTDATAFORMAT))); Marshal.StructureToPtr(obj, objs, false);
            var fmt = new DIDATAFORMAT { dwSize = Marshal.SizeOf(typeof(DIDATAFORMAT)), dwObjSize = Marshal.SizeOf(typeof(DIOBJECTDATAFORMAT)),
                                         dwFlags = DIDF_ABSAXIS, dwDataSize = 4, dwNumObjs = 1, rgodf = objs };
            hr = dev.SetDataFormat(ref fmt);
            if (hr < 0) { Log($"SetDataFormat failed {hr:X8}"); return 1; }

            using (var window = new System.Windows.Forms.Form())
            {
                hr = dev.SetCooperativeLevel(window.Handle, DISCL_EXCLUSIVE | DISCL_BACKGROUND);
                if (hr < 0) { Log($"SetCooperativeLevel failed {hr:X8}"); return 1; }
                var off = new DIPROPDWORD { dwSize = 20, dwHeaderSize = 16, dwObj = 0, dwHow = 0, dwData = 0 };
                dev.SetProperty(new IntPtr(9) /* DIPROP_AUTOCENTER */, ref off);
                hr = dev.Acquire();
                if (hr < 0) { Log($"Acquire failed {hr:X8} (close any game or tool using the wheel)"); return 1; }
                Log("acquired; auto-centre off. Keep a hand on the wheel.");
                Thread.Sleep(2000);

                var axes = Marshal.AllocHGlobal(4); Marshal.WriteInt32(axes, 0);          // DIJOFS_X
                var dirs = Marshal.AllocHGlobal(4); Marshal.WriteInt32(dirs, 1);
                var param = Marshal.AllocHGlobal(32);
                DIEFFECT Effect(int size) => new DIEFFECT
                {
                    dwSize = Marshal.SizeOf(typeof(DIEFFECT)), dwFlags = DIEFF_CARTESIAN | DIEFF_OBJECTOFFSETS, dwDuration = INFINITE,
                    dwGain = 10000, dwTriggerButton = DIEB_NOTRIGGER, cAxes = 1, rgdwAxes = axes, rglDirection = dirs,
                    cbTypeSpecificParams = size, lpvTypeSpecificParams = param,
                };

                void Step(string label, Guid type, int[] values, Action<IDirectInputEffect, DIEFFECT> during = null)
                {
                    for (int i = 0; i < 8; i++) Marshal.WriteInt32(param, i * 4, i < values.Length ? values[i] : 0);
                    var eff = Effect(values.Length * 4);
                    int r = dev.CreateEffect(ref type, ref eff, out IntPtr ePtr, IntPtr.Zero);
                    if (r < 0) { Log($"{label}: CreateEffect failed {r:X8}"); return; }
                    var e = (IDirectInputEffect)Marshal.GetObjectForIUnknown(ePtr);
                    Log("start\t" + label);
                    e.Start(1, 0);
                    if (during != null) during(e, eff); else Thread.Sleep(2500);
                    e.Stop();
                    Log("stop\t" + label);
                    e.Unload();
                    Marshal.ReleaseComObject(e);
                    Thread.Sleep(1000);
                }

                // constant force: one effect, its level changed while it plays (as games do)
                Step("constant force +25%, +50%, then -25%, -50% (1.5 s each)", GUID_ConstantForce, new[] { 2500 }, (e, eff) =>
                {
                    foreach (int level in new[] { 2500, 5000, -2500, -5000 })
                    {
                        Marshal.WriteInt32(param, level);
                        e.SetParameters(ref eff, DIEP_TYPESPECIFICPARAMS);
                        Log("level\t" + level / 100 + "%");
                        Thread.Sleep(1500);
                    }
                });
                Step("sine 30%, 10 Hz", GUID_Sine, new[] { 3000, 0, 0, 100000 });              // magnitude, offset, phase, period (us)
                Step("spring 50%", GUID_Spring, new[] { 0, 5000, 5000, 10000, 10000, 0 });   // offset, +coeff, -coeff, +sat, -sat, deadband
                Step("damper 50%", GUID_Damper, new[] { 0, 5000, 5000, 10000, 10000, 0 });
                Step("friction 50%", GUID_Friction, new[] { 0, 5000, 5000, 10000, 10000, 0 });

                dev.Unacquire();
                Log("done");
            }
            Marshal.ReleaseComObject(dev);
            Marshal.ReleaseComObject(di);
            return 0;
        }

        #region DirectInput 8
        const int DI8DEVCLASS_GAMECTRL = 4, DIEDFL_ATTACHEDONLY = 1, DIEDFL_FORCEFEEDBACK = 0x100;
        const int DIDFT_AXIS = 0x3, DIDFT_ANYINSTANCE = 0x00FFFF00, DIDF_ABSAXIS = 1, DISCL_EXCLUSIVE = 1, DISCL_BACKGROUND = 8;
        const int DIEFF_CARTESIAN = 0x10, DIEFF_OBJECTOFFSETS = 0x2, DIEB_NOTRIGGER = -1, INFINITE = -1, DIEP_TYPESPECIFICPARAMS = 0x100;
        static readonly Guid GUID_XAxis = new Guid("A36D02E0-C9F3-11CF-BFC7-444553540000");
        static readonly Guid GUID_ConstantForce = new Guid("13541C20-8E33-11D0-9AD0-00A0C9A06E35");
        static readonly Guid GUID_Sine = new Guid("13541C23-8E33-11D0-9AD0-00A0C9A06E35");
        static readonly Guid GUID_Spring = new Guid("13541C27-8E33-11D0-9AD0-00A0C9A06E35");
        static readonly Guid GUID_Damper = new Guid("13541C28-8E33-11D0-9AD0-00A0C9A06E35");
        static readonly Guid GUID_Friction = new Guid("13541C2A-8E33-11D0-9AD0-00A0C9A06E35");

        [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int EnumDevicesCallback(IntPtr instance, IntPtr context);

        [StructLayout(LayoutKind.Sequential)] struct DIOBJECTDATAFORMAT { public IntPtr pguid; public int dwOfs, dwType, dwFlags; }
        [StructLayout(LayoutKind.Sequential)] struct DIDATAFORMAT { public int dwSize, dwObjSize, dwFlags, dwDataSize, dwNumObjs; public IntPtr rgodf; }
        [StructLayout(LayoutKind.Sequential)] struct DIPROPDWORD { public int dwSize, dwHeaderSize, dwObj, dwHow, dwData; }
        [StructLayout(LayoutKind.Sequential)]
        struct DIEFFECT
        {
            public int dwSize, dwFlags, dwDuration, dwSamplePeriod, dwGain, dwTriggerButton, dwTriggerRepeatInterval, cAxes;
            public IntPtr rgdwAxes, rglDirection, lpEnvelope; public int cbTypeSpecificParams; public IntPtr lpvTypeSpecificParams; public int dwStartDelay;
        }

        [DllImport("dinput8.dll")]
        static extern int DirectInput8Create(IntPtr hinst, int version, ref Guid riid, out IntPtr ppvOut, IntPtr outer);

        // Methods in vtable order, up to the last one used.
        [ComImport, Guid("BF798031-483A-4DA2-AA99-5D64ED369700"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IDirectInput8W
        {
            [PreserveSig] int CreateDevice(ref Guid guid, out IntPtr device, IntPtr outer);
            [PreserveSig] int EnumDevices(int devType, EnumDevicesCallback cb, IntPtr context, int flags);
        }

        [ComImport, Guid("54D41081-DC15-4833-A41B-748F73A38179"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IDirectInputDevice8W
        {
            [PreserveSig] int GetCapabilities(IntPtr caps);
            [PreserveSig] int EnumObjects(IntPtr cb, IntPtr context, int flags);
            [PreserveSig] int GetProperty(IntPtr prop, IntPtr header);
            [PreserveSig] int SetProperty(IntPtr prop, ref DIPROPDWORD header);
            [PreserveSig] int Acquire();
            [PreserveSig] int Unacquire();
            [PreserveSig] int GetDeviceState(int size, IntPtr data);
            [PreserveSig] int GetDeviceData(int size, IntPtr data, IntPtr count, int flags);
            [PreserveSig] int SetDataFormat(ref DIDATAFORMAT format);
            [PreserveSig] int SetEventNotification(IntPtr ev);
            [PreserveSig] int SetCooperativeLevel(IntPtr hwnd, int flags);
            [PreserveSig] int GetObjectInfo(IntPtr info, int obj, int how);
            [PreserveSig] int GetDeviceInfo(IntPtr info);
            [PreserveSig] int RunControlPanel(IntPtr hwnd, int flags);
            [PreserveSig] int Initialize(IntPtr hinst, int version, ref Guid guid);
            [PreserveSig] int CreateEffect(ref Guid type, ref DIEFFECT effect, out IntPtr created, IntPtr outer);
        }

        [ComImport, Guid("E7E1F7C0-88D2-11D0-9AD0-00A0C9A06E35"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface IDirectInputEffect
        {
            [PreserveSig] int Initialize(IntPtr hinst, int version, ref Guid guid);
            [PreserveSig] int GetEffectGuid(out Guid guid);
            [PreserveSig] int GetParameters(IntPtr effect, int flags);
            [PreserveSig] int SetParameters(ref DIEFFECT effect, int flags);
            [PreserveSig] int Start(int iterations, int flags);
            [PreserveSig] int Stop();
            [PreserveSig] int GetEffectStatus(out int status);
            [PreserveSig] int Download();
            [PreserveSig] int Unload();
        }
        #endregion
    }
}
