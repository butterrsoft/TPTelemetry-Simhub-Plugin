using System;
using System.IO;

namespace TeknoTelemetry.Core
{
    /// <summary>
    /// Plain text diagnostics at SimHub\PluginsData\TPTelemetry\TPTelemetry.log.
    /// Kept small: the file is restarted when it passes 1 MB.
    /// </summary>
    public static class Log
    {
        static readonly object Sync = new object();
        public static string FilePath { get; set; }

        public static void Info(string msg) => Write("INFO ", msg);
        public static void Error(string msg, Exception e = null) => Write("ERROR", e == null ? msg : msg + ": " + e);

        static void Write(string level, string msg)
        {
            var path = FilePath;
            if (path == null) return;
            try
            {
                lock (Sync)
                {
                    var fi = new FileInfo(path);
                    if (fi.Exists && fi.Length > 1024 * 1024) fi.Delete();
                    File.AppendAllText(path, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} {level} [{System.Threading.Thread.CurrentThread.ManagedThreadId}] {msg}{Environment.NewLine}");
                }
            }
            catch { /* logging must never break the plugin */ }
        }
    }
}
