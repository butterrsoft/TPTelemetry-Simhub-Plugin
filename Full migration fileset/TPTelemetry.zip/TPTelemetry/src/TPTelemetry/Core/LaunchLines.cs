using System;
using System.Collections.Generic;

namespace TeknoTelemetry.Core
{
    /// <summary>
    /// The text "Copy Commandlines To Set Game/Profile" puts on the clipboard: the lines a launch
    /// script runs to select a game in TP Telemetry and in SimHub, for AutoHotkey v1, AutoHotkey v2
    /// and a batch file. Lines starting with ";" are notes for the user to delete.
    ///
    /// Two commands with a wait between: SimHub acts only on the first command in one run, and
    /// ignores -switchgame while it's still starting up.
    /// </summary>
    public static class LaunchLines
    {
        public const int WaitSeconds = 5;

        /// <param name="simHubExe">Full path of SimHubWPF.exe.</param>
        /// <param name="action">The TP Telemetry action, e.g. TPTelemetry.Activate_WMMT5DXP.</param>
        /// <param name="displayName">The game's display name, for the notes.</param>
        /// <param name="simHubGame">SimHub's selected game code; empty if none, which leaves out the second command.</param>
        public static string Build(string simHubExe, string action, string displayName, string simHubGame)
        {
            simHubGame = (simHubGame ?? "").Trim();
            bool both = simHubGame != "";
            var game = simHubGame.Contains(" ") ? "\"" + simHubGame + "\"" : simHubGame;
            var tpArgs = "-triggeraction " + action;
            var shArgs = "-switchgame " + game;
            var exe = "\"" + simHubExe + "\"";
            var l = new List<string>
            {
                $"; ===== TP Telemetry launch lines for {displayName} =====",
                "; DELETE every line that starts with a semicolon (these notes, and the block headings),",
                "; and keep only the block for your kind of script: AutoHotkey v1, AutoHotkey v2 or a batch file (.bat).",
                "; Put the lines in your launch script before the line that starts the game.",
                ";   First line: selects " + displayName + " in TP Telemetry. It starts SimHub if it isn't running.",
            };
            if (both)
            {
                l.Add($";   Wait:       gives SimHub {WaitSeconds} seconds to finish starting. Make it longer if SimHub is slow to start.");
                l.Add(";   Last line:  switches SimHub's own game (its effects and dashboards) to " + simHubGame + ".");
                l.Add(";   They must be separate commands: SimHub only acts on the first command each time it's run.");
                l.Add("; SimHub has no command for choosing a ShakeIt effects profile, so there's no line for it.");
                l.Add("; Select the TP Telemetry profile in ShakeIt once while SimHub has " + simHubGame + " selected.");
            }
            else
            {
                l.Add("; No SimHub game was selected when these were copied, so the line that switches SimHub's own game is missing.");
                l.Add("; Select the game in SimHub, then copy again to get it.");
            }

            l.Add(";");
            l.Add("; ---- AutoHotkey v1 ----");
            l.Add($"Run, {exe} {tpArgs}");
            if (both) { l.Add($"Sleep, {WaitSeconds * 1000}"); l.Add($"Run, {exe} {shArgs}"); }

            l.Add(";");
            l.Add("; ---- AutoHotkey v2 ----");
            l.Add($"Run '{exe} {tpArgs}'");
            if (both) { l.Add($"Sleep {WaitSeconds * 1000}"); l.Add($"Run '{exe} {shArgs}'"); }

            l.Add(";");
            l.Add("; ---- Batch file (.bat) ----");
            l.Add($"start \"\" {exe} {tpArgs}");
            if (both) { l.Add($"timeout /t {WaitSeconds} /nobreak >nul"); l.Add($"start \"\" {exe} {shArgs}"); }

            return string.Join("\r\n", l) + "\r\n";
        }
    }
}
