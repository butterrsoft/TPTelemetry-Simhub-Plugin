using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using TeknoTelemetry.Core.Ffb;

namespace TeknoTelemetry.Core
{
    /// <summary>
    /// Writes every variable of the selected game, plus the FFB channels and (0.16.0) the common values
    /// SimHub got (Car_ columns, after gating and the USB stand-in), to a CSV file at the
    /// plugin's poll rate, for working out formulas in a spreadsheet. A "marker" column numbers
    /// events flagged with Mark (bindable to a wheel button).
    /// </summary>
    public sealed class ValueRecorder : IDisposable
    {
        readonly StreamWriter _w;
        readonly System.Diagnostics.Stopwatch _clock = System.Diagnostics.Stopwatch.StartNew();
        readonly string _profileId;
        readonly TimeSpan _maxLength;
        int _marksRequested, _marksWritten;
        string[] _columns;
        string[] _varNames = new string[0];
        ProfileState _mappedFor;
        int[] _map = new int[0];

        public string Path { get; }
        public string GamePrefix { get; }
        public double Seconds => _clock.Elapsed.TotalSeconds;
        public int Marks => Volatile.Read(ref _marksRequested);
        public long Rows { get; private set; }
        public bool Finished { get; private set; }

        readonly string[] _outputNames;

        public ValueRecorder(string path, GameProfile profile, TimeSpan maxLength, string[] outputNames = null)
        {
            _outputNames = outputNames ?? new string[0];
            Path = path;
            _profileId = profile?.Id;
            GamePrefix = profile == null ? "" : Names.Sanitise(profile.Prefix);
            _maxLength = maxLength;
            Directory.CreateDirectory(System.IO.Path.GetDirectoryName(path));
            _w = new StreamWriter(new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.Read), new UTF8Encoding(false), 1 << 16);
        }

        /// <summary>Flags an event; it appears as the next number in the marker column. Any thread.</summary>
        public int Mark() => Interlocked.Increment(ref _marksRequested);

        /// <summary>Writes one row. Called on the poll thread after each sample.</summary>
        internal void Write(ProfileState game, double[] ffb, double[] tp = null, Func<string, double> output = null, CommonValues common = null)
        {
            if (Finished) return;
            if (_columns == null)
            {
                _varNames = game?.Vars.Select(v => v.PropertyName).ToArray() ?? new string[0];
                _columns = new[] { "time_s", "marker", "attached" }.Concat(_varNames)
                    .Concat(Enumerable.Range(0, FfbChannels.Count).Select(i => "FFB_" + FfbChannels.Names[i]))
                    .Concat(Enumerable.Range(0, TeknoParrot.TpChannels.Count).Select(i => "TP_" + TeknoParrot.TpChannels.Identifier(i).Substring(3)))
                    .Concat(_outputNames.Select(n => "Output_" + n))
                    .Concat(CommonValues.Outputs.Select(o => "Car_" + o.Name))
                    .Concat(CommonValues.Lamps.Select(o => CommonValues.LampPropertyPrefix + o.Name)).ToArray();
                _w.WriteLine(string.Join(",", _columns));
            }
            var sb = new StringBuilder(256);
            sb.Append(Seconds.ToString("0.0000", CultureInfo.InvariantCulture)).Append(',');
            int req = Volatile.Read(ref _marksRequested);
            if (req > _marksWritten) { _marksWritten = req; sb.Append(req); }
            sb.Append(',').Append(game != null && game.Connected ? '1' : '0');
            if (!ReferenceEquals(game, _mappedFor))
            {
                // the game's variables were re-applied (an edit): find each column again by name
                _mappedFor = game;
                _map = _varNames.Select(n => game == null ? -1 : Array.FindIndex(game.Vars, v => v.PropertyName == n)).ToArray();
            }
            for (int i = 0; i < _varNames.Length; i++) { sb.Append(','); if (_map[i] >= 0) Num(sb, game.Vars[_map[i]].Output); }
            for (int i = 0; i < FfbChannels.Count; i++) { sb.Append(','); Num(sb, ffb != null && i < ffb.Length ? ffb[i] : double.NaN); }
            for (int i = 0; i < TeknoParrot.TpChannels.Count; i++) { sb.Append(','); Num(sb, tp != null && i < tp.Length ? tp[i] : double.NaN); }
            foreach (var n in _outputNames) { sb.Append(','); Num(sb, output?.Invoke(n) ?? double.NaN); }
            for (int i = 0; i < CommonValues.Outputs.Length; i++) { sb.Append(','); Num(sb, common?.Get(i) ?? double.NaN); }
            for (int i = 0; i < CommonValues.Lamps.Length; i++) { sb.Append(','); Num(sb, common?.GetLamp(i) ?? double.NaN); }
            _w.WriteLine(sb.ToString());
            Rows++;
            if (_clock.Elapsed > _maxLength) Finish();
        }

        internal bool IsFor(ProfileState p) => p != null && p.Def.Id == _profileId;

        static void Num(StringBuilder sb, double v)
        {
            if (double.IsNaN(v) || double.IsInfinity(v)) return; // empty cell
            sb.Append(v.ToString("0.######", CultureInfo.InvariantCulture));
        }

        internal void Finish()
        {
            if (Finished) return;
            Finished = true;
            try { _w.Flush(); _w.Dispose(); } catch { }
            Log.Info($"Recording saved: {Path} ({Rows} rows, {Marks} markers)");
        }

        public void Dispose() => Finish();
    }
}
