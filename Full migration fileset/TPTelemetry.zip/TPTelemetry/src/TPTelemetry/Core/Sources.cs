using System;
using System.Collections.Generic;
using System.Linq;

namespace TeknoTelemetry.Core
{
    /// <summary>What a raw source can see each tick. Later sources (force feedback capture)
    /// will add their own channels here rather than changing the engine.</summary>
    public sealed class SourceContext
    {
        public IMemoryReader Memory;
        /// <summary>Values read by the 64-bit helper, when the game is 64-bit and SimHub is 32-bit.
        /// Used only while <see cref="Memory"/> is null.</summary>
        public IRemoteValues Remote;
    }

    /// <summary>Outcome of walking one memory row. Shared with the 64-bit helper, which sends
    /// these codes back through its results block.</summary>
    public enum ReadStatus
    {
        None = 0,
        Ok = 1,
        ModuleNotLoaded = 2,
        NullPointer = 3,
        CantRead = 4,
    }

    /// <summary>One memory row's result: value, the address it was read from (or the address that
    /// failed), the outcome, and for <see cref="ReadStatus.NullPointer"/> the chain level.</summary>
    public struct RowResult
    {
        public double Value;
        public long Address;
        public ReadStatus Status;
        public int Detail;
    }

    /// <summary>Row results supplied by the 64-bit helper, by plan slot.</summary>
    public interface IRemoteValues
    {
        /// <returns>false while the helper has no current result for that slot.</returns>
        bool TryGet(int slot, out RowResult result);
    }

    /// <summary>Read access to a game's memory (implemented by <see cref="ProcessMemory"/>; faked in tests).</summary>
    public interface IMemoryReader
    {
        bool TryGetModuleBase(string module, out long baseAddr);
        bool TryReadPointer(long address, out long value);
        bool TryReadValue(long address, MemType type, out double value);
    }

    /// <summary>Produces a raw value for one variable each tick.</summary>
    public interface IRawSource
    {
        /// <returns>false if no value this tick; <paramref name="status"/> says why.</returns>
        bool TryRead(SourceContext ctx, out double value, out string status);
    }

    /// <summary>Formula-only variables have no raw value.</summary>
    public sealed class NoSource : IRawSource
    {
        public static readonly NoSource Instance = new NoSource();
        public bool TryRead(SourceContext ctx, out double value, out string status)
        {
            value = double.NaN; status = null; return true;
        }
    }

    /// <summary>module + base offset, then follows a pointer chain, then reads a value.
    /// The chain is re-walked every tick because the game reallocates objects between races.</summary>
    public sealed class MemorySource : IRawSource
    {
        public string Module { get; }
        public long BaseOffset { get; }
        public IReadOnlyList<long> Offsets { get; }
        public MemType Type { get; }
        public long LastAddress { get; private set; }
        /// <summary>This row's index in the 64-bit helper's read plan; -1 if it isn't in one.</summary>
        public int PlanSlot { get; internal set; } = -1;

        public MemorySource(string module, long baseOffset, IReadOnlyList<long> offsets, MemType type)
        {
            Module = (module ?? "").Trim().Trim('"');
            BaseOffset = baseOffset; Offsets = offsets ?? new long[0]; Type = type;
        }

        /// <summary>Builds from a variable definition; throws FormatException with a readable message.</summary>
        public static MemorySource From(VariableDef v)
        {
            if (!Hex.TryParse(v.BaseOffset, out var b))
                throw new FormatException($"Base offset '{v.BaseOffset}' is not hex");
            if (!Hex.TryParseList(v.Offsets, out var offs, out var err))
                throw new FormatException("Offsets: " + err);
            if (string.IsNullOrWhiteSpace(v.Module) && b <= 0)
                throw new FormatException("Set a module, or an absolute address");
            return new MemorySource(v.Module, b, offs, v.Type);
        }

        public bool TryRead(SourceContext ctx, out double value, out string status)
        {
            value = double.NaN;
            var pm = ctx.Memory;
            if (pm == null)
            {
                var remote = ctx.Remote;
                if (remote == null) { status = "not attached (is the game's Process set, and is it running?)"; return false; }
                if (PlanSlot < 0) { status = $"not read: the 64-bit helper takes at most {Remote.ReadPlan.MaxRows} memory rows per game"; return false; }
                if (!remote.TryGet(PlanSlot, out var r)) { status = "waiting for the 64-bit helper"; return false; }
                if (r.Status == ReadStatus.Ok) { value = r.Value; LastAddress = r.Address; }
                status = Describe(r.Status, Module, r.Address, r.Detail);
                return r.Status == ReadStatus.Ok;
            }

            var s = Walk(pm, out value, out var addr, out var level);
            if (s == ReadStatus.Ok || s == ReadStatus.CantRead) LastAddress = addr;
            status = Describe(s, Module, addr, level);
            return s == ReadStatus.Ok;
        }

        /// <summary>Resolves the module, follows the pointer chain and reads the value.
        /// <paramref name="address"/> is the value's address, or the address that failed.</summary>
        public ReadStatus Walk(IMemoryReader pm, out double value, out long address, out int level)
        {
            value = double.NaN; level = 0;
            if (Module.Length == 0) address = BaseOffset;
            else
            {
                if (!pm.TryGetModuleBase(Module, out var mb)) { address = 0; return ReadStatus.ModuleNotLoaded; }
                address = mb + BaseOffset;
            }

            long emuBase = 0;   // where the emulated machine's memory starts in the emulator: the first pointer of the chain
            long index = 0;     // "[-E80]*578" (0.19.0): records to skip at the next pointer
            bool followed = false;
            for (int i = 0; i < Offsets.Count; i++)
            {
                if (Hex.IsIndexHop(Offsets[i]))
                {
                    // The game's own index (1 for its first record, say), read beside the pointer to the records.
                    if (!pm.TryReadValue(address + Hex.IndexOffset(Offsets[i]), MemType.Int32, out var n) || double.IsNaN(n))
                    { level = i + 1; return ReadStatus.NullPointer; }
                    index += (long)n * Hex.IndexStride(Offsets[i]);
                    continue;
                }
                if (Hex.IsEmuHop(Offsets[i]))
                {
                    // "@588" (0.18.2): a 32-bit address of the emulated machine (Flycast's game), which lands at
                    // the emulated memory's start + its low 25 bits. 0 is a null pointer there too.
                    if (i == 0 || !pm.TryReadValue(address, MemType.UInt32, out var g) || g == 0) { level = i + 1; return ReadStatus.NullPointer; }
                    address = emuBase + ((long)g & Hex.EmuMask) + (Offsets[i] & ~Hex.EmuHop);
                    continue;
                }
                if (!pm.TryReadPointer(address, out var p)) { level = i + 1; return ReadStatus.NullPointer; }
                if (!followed) { emuBase = p; followed = true; }
                address = p + Offsets[i] + index;
                index = 0;
            }

            if (!pm.TryReadValue(address, Type, out value)) { value = double.NaN; return ReadStatus.CantRead; }
            return ReadStatus.Ok;
        }

        /// <summary>Status text for the settings grid, the same whether the plugin or the helper read the row.</summary>
        public static string Describe(ReadStatus s, string module, long address, int level)
        {
            switch (s)
            {
                case ReadStatus.Ok: return $"0x{address:X}";
                case ReadStatus.ModuleNotLoaded: return $"{module} not loaded";
                case ReadStatus.NullPointer: return $"null/unreadable pointer at level {level} (0x{address:X})";
                case ReadStatus.CantRead: return $"can't read 0x{address:X}";
                default: return "no result yet";
            }
        }

        internal Remote.ReadPlanRow ToPlanRow() =>
            new Remote.ReadPlanRow { Module = Module, BaseOffset = BaseOffset, Offsets = Offsets.ToArray(), Type = Type };
    }
}
