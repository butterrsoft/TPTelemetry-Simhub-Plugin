using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace TeknoTelemetry.Core
{
    public class ImportResult
    {
        public GameProfile Profile { get; set; }
        public List<string> Warnings { get; } = new List<string>();
    }

    /// <summary>
    /// Reads Cheat Engine .CT tables into a <see cref="GameProfile"/>.
    ///
    /// Address forms understood:
    ///   "Module.exe"+0106A79C    module-relative (stable, preferred)
    ///   Module.dll+76027B0       same, unquoted
    ///   FFAFF3B0                 absolute (imported but disabled: usually changes every launch)
    ///
    /// Cheat Engine writes pointer offsets in the XML in reverse order of application
    /// (the first &lt;Offset&gt; is the last one applied). They are reversed here so that
    /// <see cref="VariableDef.Offsets"/> reads base-first.
    /// </summary>
    public static class CheatTableImporter
    {
        static readonly Regex ModuleAddr = new Regex(
            "^\\s*\"?(?<mod>[^\"+]+?\\.(exe|dll))\"?\\s*\\+\\s*(?<off>(0x)?[0-9A-Fa-f]+)\\s*$",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

        static readonly Regex AbsAddr = new Regex("^\\s*(0x)?[0-9A-Fa-f]+\\s*$", RegexOptions.Compiled);

        public static ImportResult ImportFile(string path)
        {
            var name = Path.GetFileNameWithoutExtension(path);
            return Import(File.ReadAllText(path), name);
        }

        public static ImportResult Import(string xml, string tableName)
        {
            var result = new ImportResult();
            var doc = XDocument.Parse(xml);
            var profile = new GameProfile
            {
                DisplayName = tableName,
                Prefix = Names.Sanitise(Regex.Replace(tableName ?? "GAME", "[-_ ]?wip$", "", RegexOptions.IgnoreCase)),
            };

            var root = doc.Root?.Element("CheatEntries");
            if (root == null)
            {
                result.Warnings.Add("No <CheatEntries> found in table.");
                result.Profile = profile;
                return result;
            }

            var exeCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var entry in Flatten(root))
            {
                var desc = ((string)entry.Element("Description") ?? "").Trim().Trim('"');
                var addr = (string)entry.Element("Address");
                var ceType = (string)entry.Element("VariableType");
                if (string.IsNullOrWhiteSpace(addr)) continue; // group header or script

                var type = MemTypes.FromCheatEngine(ceType);
                if (type == null)
                {
                    result.Warnings.Add($"'{desc}': type '{ceType}' not supported, skipped.");
                    continue;
                }

                var v = new VariableDef
                {
                    Name = Unique(Names.Sanitise(string.IsNullOrEmpty(desc) ? "var" : desc), used),
                    Type = type.Value,
                    Source = SourceKind.Memory,
                };

                var m = ModuleAddr.Match(addr);
                if (m.Success)
                {
                    v.Module = m.Groups["mod"].Value.Trim();
                    Hex.TryParse(m.Groups["off"].Value, out var off);
                    v.BaseOffset = Hex.Format(off);
                    if (v.Module.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
                        exeCounts[v.Module] = exeCounts.TryGetValue(v.Module, out var c) ? c + 1 : 1;
                }
                else if (AbsAddr.IsMatch(addr))
                {
                    Hex.TryParse(addr, out var abs);
                    v.Module = "";
                    v.BaseOffset = Hex.Format(abs);
                    v.Enabled = false;
                    v.Notes = "Absolute address from CE; likely changes between launches.";
                    result.Warnings.Add($"'{desc}': absolute address {addr.Trim()} imported but disabled.");
                }
                else
                {
                    result.Warnings.Add($"'{desc}': address '{addr}' uses symbols or arithmetic this plugin can't resolve, skipped.");
                    continue;
                }

                var offsets = entry.Element("Offsets")?.Elements("Offset")
                    .Select(o => ((string)o ?? "").Trim())
                    .Where(o => o.Length > 0)
                    .ToList() ?? new List<string>();
                offsets.Reverse(); // CE stores last-applied first
                var parsed = new List<string>();
                bool bad = false;
                foreach (var o in offsets)
                {
                    if (Hex.TryParse(o, out var ov)) parsed.Add(Hex.Format(ov));
                    else { bad = true; result.Warnings.Add($"'{desc}': offset '{o}' is not plain hex, skipped entry."); break; }
                }
                if (bad) continue;
                v.Offsets = string.Join(", ", parsed);

                profile.Variables.Add(v);
            }

            // The process is normally the .exe that module-relative entries point at.
            profile.ProcessName = exeCounts.OrderByDescending(kv => kv.Value).Select(kv => kv.Key).FirstOrDefault() ?? "";
            if (profile.ProcessName == "")
                result.Warnings.Add("Couldn't infer the process name; set it on the profile.");

            result.Profile = profile;
            return result;
        }

        static IEnumerable<XElement> Flatten(XElement cheatEntries)
        {
            foreach (var e in cheatEntries.Elements("CheatEntry"))
            {
                yield return e;
                var children = e.Element("CheatEntries");
                if (children != null)
                    foreach (var c in Flatten(children)) yield return c;
            }
        }

        static string Unique(string name, HashSet<string> used)
        {
            var n = name;
            int i = 2;
            while (!used.Add(n)) n = name + "_" + i++;
            return n;
        }
    }
}
