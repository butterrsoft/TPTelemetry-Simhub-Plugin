using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;

namespace TeknoTelemetry.Core.Remote
{
    /// <summary>
    /// The 64-bit helper's work, kept here so the tests can run it in-process. Reads read plans
    /// from the control stream, opens the game read-only, walks every row's pointer chain at the
    /// plan's poll rate, and publishes the results to the block. Never writes to the game.
    /// Stops on STOP, when the plugin closes the pipe, or when the parent process has gone.
    /// </summary>
    public sealed class HelperServer
    {
        readonly Stream _control;
        readonly ResultsWriter _out;
        readonly Func<int, string, IGameReader> _open;
        readonly object _planLock = new object();
        ReadPlan _plan;
        MemorySource[] _sources = new MemorySource[0];
        volatile bool _running = true;

        /// <summary>Checked about once a second; the helper stops when it returns false.</summary>
        public Func<bool> ParentAlive { get; set; } = () => true;
        /// <summary>Called on any unexpected error (the helper has no log of its own).</summary>
        public Action<string> OnError { get; set; }
        public int HelperPid { get; }

        public HelperServer(Stream control, UnmanagedMemoryAccessor block, int capacity, int helperPid,
                            Func<int, string, IGameReader> opener)
        {
            _control = control;
            _open = opener;
            HelperPid = helperPid;
            _out = new ResultsWriter(block, capacity, helperPid);
        }

        /// <summary>Blocks until stopped.</summary>
        public void Run()
        {
            var poll = new Thread(PollLoop) { IsBackground = true, Name = "TPTelemetryHelper64 poll" };
            poll.Start();
            try
            {
                HelperProtocol.Write(_control, $"HELLO {HelperProtocol.Version} {HelperPid}");
                while (_running)
                {
                    var msg = HelperProtocol.Read(_control);
                    if (msg == null) break; // plugin closed the pipe
                    if (msg == "STOP") break;
                    if (msg.StartsWith("PLAN\n", StringComparison.Ordinal))
                    {
                        ReadPlan plan;
                        try { plan = ReadPlan.Parse(msg.Substring(5)); }
                        catch (FormatException e) { HelperProtocol.Write(_control, "ERR " + e.Message); continue; }
                        if (plan.Rows.Count > _out.Capacity) { HelperProtocol.Write(_control, "ERR too many rows"); continue; }
                        var sources = plan.Rows.Select(r => new MemorySource(r.Module, r.BaseOffset, r.Offsets, r.Type)).ToArray();
                        lock (_planLock) { _plan = plan; _sources = sources; }
                        HelperProtocol.Write(_control, "OK " + plan.Generation);
                        continue;
                    }
                    HelperProtocol.Write(_control, "ERR unknown command");
                }
            }
            catch (IOException) { /* pipe broken: the plugin has gone */ }
            catch (ObjectDisposedException) { }
            catch (Exception e) { OnError?.Invoke("Control: " + e); }
            finally
            {
                _running = false;
                poll.Join(2000);
            }
        }

        public void Stop()
        {
            _running = false;
            try { _control.Dispose(); } catch { }
        }

        void PollLoop()
        {
            IGameReader game = null;
            int gamePid = 0;
            var state = GameState.Opening;
            string message = "";
            long nextOpenMs = 0, nextParentCheckMs = 0;
            var rows = new RowResult[_out.Capacity];
            var sw = Stopwatch.StartNew();
            double next = 0;

            try
            {
                while (_running)
                {
                    ReadPlan plan; MemorySource[] sources;
                    lock (_planLock) { plan = _plan; sources = _sources; }
                    long now = sw.ElapsedMilliseconds;

                    if (now >= nextParentCheckMs)
                    {
                        nextParentCheckMs = now + 1000;
                        bool alive;
                        try { alive = ParentAlive(); } catch { alive = true; }
                        if (!alive) { Stop(); break; }
                    }

                    int count = 0;
                    if (plan != null)
                    {
                        // A different game (new PID) means starting over.
                        if (plan.Pid != gamePid)
                        {
                            game?.Dispose(); game = null;
                            gamePid = plan.Pid; state = GameState.Opening; message = ""; nextOpenMs = 0;
                        }

                        if (game == null && state != GameState.Exited && now >= nextOpenMs)
                        {
                            nextOpenMs = now + 1000; // after an error, try again once a second
                            try
                            {
                                game = _open(plan.Pid, plan.ProcessName);
                                if (game == null) { state = GameState.Exited; message = $"{plan.ProcessName} (PID {plan.Pid}) is no longer running"; }
                                else { state = GameState.Attached; message = ""; }
                            }
                            catch (Exception e) { state = GameState.Error; message = e.Message; }
                        }

                        if (game != null && game.HasExited)
                        {
                            game.Dispose(); game = null;
                            state = GameState.Exited; message = $"{plan.ProcessName} exited";
                        }

                        if (game != null)
                        {
                            count = Math.Min(sources.Length, rows.Length);
                            for (int i = 0; i < count; i++)
                            {
                                try
                                {
                                    var s = sources[i].Walk(game, out var v, out var addr, out var level);
                                    rows[i] = new RowResult { Value = v, Address = addr, Status = s, Detail = level };
                                }
                                catch (Exception e)
                                {
                                    rows[i] = new RowResult { Value = double.NaN, Status = ReadStatus.CantRead };
                                    OnError?.Invoke("Row " + i + ": " + e.Message);
                                }
                            }
                        }
                    }

                    _out.Publish(plan?.Generation ?? -1, state, gamePid, message, rows, count);

                    double period = 1000.0 / (plan?.PollHz ?? 120);
                    next += period;
                    var t = sw.Elapsed.TotalMilliseconds;
                    if (next < t - period * 5) next = t;
                    var wait = next - t;
                    Thread.Sleep(wait >= 1 ? (int)wait : 0);
                }
            }
            catch (Exception e) { OnError?.Invoke("Poll: " + e); Stop(); }
            finally { game?.Dispose(); }
        }
    }
}
