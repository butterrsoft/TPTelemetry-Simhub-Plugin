using System;
using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.IO.Pipes;

namespace TeknoTelemetry.Core.Remote
{
    /// <summary>
    /// Starts TPTelemetryHelper64.exe (Windows). The plugin picks fresh random names for the pipe and
    /// the results block and passes them on the command line; the helper creates both, the plugin
    /// connects to the pipe and opens the block read-only. The helper goes into a job object so it
    /// ends with SimHub, at SimHub's own elevation (it inherits SimHub's token).
    /// </summary>
    public static class HelperLauncher
    {
        public const string ExeName = "TPTelemetryHelper64.exe";
        public const string PipePrefix = "TPTelemetryHelper64_";
        public const string BlockPrefix = @"Local\TPTelemetryHelper64_";

        public static Func<IHelperTransport> ForExe(string exePath) => () => Launch(exePath);

        static IHelperTransport Launch(string exe)
        {
            var dir = Path.GetDirectoryName(exe);
            if (!File.Exists(exe))
                throw new FileNotFoundException($"{ExeName} is missing. It has to sit beside TPTelemetry.dll in {dir}.");
            if (!Environment.Is64BitOperatingSystem)
                throw new PlatformNotSupportedException("this is 32-bit Windows, which can't run 64-bit games anyway");

            var id = Guid.NewGuid().ToString("N");
            string pipeName = PipePrefix + id, blockName = BlockPrefix + id;
            int me;
            using (var self = Process.GetCurrentProcess()) me = self.Id;
            var psi = new ProcessStartInfo(exe, $"--parent {me} --pipe {pipeName} --block {blockName} --rows {ReadPlan.MaxRows}")
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                WorkingDirectory = dir,
            };
            var proc = Process.Start(psi);
            ChildProcessJob job = null;
            try { job = new ChildProcessJob(); job.Add(proc); }
            catch (Exception e) { Log.Error("Job object for the 64-bit helper (it will still stop when SimHub closes the pipe)", e); }
            Log.Info($"Started {ExeName} (PID {proc.Id})");

            NamedPipeClientStream pipe = null;
            MemoryMappedFile mmf = null;
            try
            {
                // Overlapped, so closing it cancels a read that is waiting on a hung helper.
                pipe = new NamedPipeClientStream(".", pipeName, PipeDirection.InOut, PipeOptions.Asynchronous);
                var sw = Stopwatch.StartNew();
                while (true)
                {
                    try { pipe.Connect(250); break; }
                    catch (TimeoutException) { }
                    if (proc.HasExited) throw new InvalidOperationException($"{ExeName} stopped at start-up (exit code {proc.ExitCode})");
                    if (sw.ElapsedMilliseconds > 10000) throw new TimeoutException($"{ExeName} didn't answer within 10 seconds");
                }
                // The helper creates the block before it opens the pipe, so it exists now.
                mmf = MemoryMappedFile.OpenExisting(blockName, MemoryMappedFileRights.Read);
                var view = mmf.CreateViewAccessor(0, 0, MemoryMappedFileAccess.Read);
                return new Transport(proc, job, pipe, mmf, view);
            }
            catch
            {
                pipe?.Dispose(); mmf?.Dispose();
                try { if (!proc.HasExited) proc.Kill(); } catch { }
                job?.Dispose(); proc.Dispose();
                throw;
            }
        }

        sealed class Transport : IHelperTransport
        {
            readonly Process _proc;
            readonly ChildProcessJob _job;
            readonly NamedPipeClientStream _pipe;
            readonly MemoryMappedFile _mmf;
            readonly MemoryMappedViewAccessor _view;

            public Transport(Process proc, ChildProcessJob job, NamedPipeClientStream pipe, MemoryMappedFile mmf, MemoryMappedViewAccessor view)
            { _proc = proc; _job = job; _pipe = pipe; _mmf = mmf; _view = view; }

            public Stream Control => _pipe;
            public UnmanagedMemoryAccessor Block => _view;
            public bool Alive { get { try { return !_proc.HasExited; } catch { return false; } } }

            public void Dispose()
            {
                try { _pipe.Dispose(); } catch { }
                try { if (!_proc.WaitForExit(500)) _proc.Kill(); } catch { }
                try { _view.Dispose(); _mmf.Dispose(); } catch { }
                _job?.Dispose();
                _proc.Dispose();
            }
        }
    }
}
