using System;
using System.IO;
using System.Text;
using System.Threading;

namespace TeknoTelemetry.Core.Remote
{
    /// <summary>What the helper knows about the game.</summary>
    public enum GameState
    {
        /// <summary>No plan yet, or still opening the game.</summary>
        Opening = 0,
        Attached = 1,
        /// <summary>The game exited (or the PID no longer belongs to it).</summary>
        Exited = 2,
        /// <summary>The helper couldn't open the game; the message says why.</summary>
        Error = 3,
    }

    /// <summary>
    /// Layout of the helper's named shared-memory block. The helper is the only writer; the plugin
    /// opens it read-only. Every field is 4 bytes or a whole row, and the 32-bit plugin reads 32-bit
    /// fields only, so no read can tear except the rows, which the sequence number protects:
    /// the writer makes it odd, writes, then makes it even again; a reader keeps a copy only if the
    /// number was even and unchanged across the copy.
    ///
    ///   0  int32  magic 'TPTH'          28  int32  helper PID
    ///   4  int32  layout version        32  int32  sequence (odd while writing)
    ///   8  int32  capacity (rows)       36  int32  heartbeat (+1 every poll)
    ///  12  int32  row count             40  int32  message length (bytes)
    ///  16  int32  plan generation       44  UTF-8  message (up to 200 bytes)
    ///  20  int32  game state           256  rows: 24 bytes each
    ///  24  int32  game PID                    double value, int64 address, int32 status, int32 detail
    /// </summary>
    public static class ResultsLayout
    {
        public const int Magic = 0x48545054; // "TPTH"
        public const int Version = 1;
        public const int HeaderSize = 256;
        public const int RowSize = 24;
        public const int MessageMax = 200;

        internal const int OffMagic = 0, OffVersion = 4, OffCapacity = 8, OffRowCount = 12, OffGeneration = 16,
            OffGameState = 20, OffGamePid = 24, OffHelperPid = 28, OffSequence = 32, OffHeartbeat = 36,
            OffMessageLen = 40, OffMessage = 44;

        public static long Size(int capacity) => HeaderSize + (long)capacity * RowSize;
        internal static long RowOffset(int i) => HeaderSize + (long)i * RowSize;
    }

    /// <summary>The helper's side: publishes a whole set of results at once.</summary>
    public sealed class ResultsWriter
    {
        readonly UnmanagedMemoryAccessor _a;
        public int Capacity { get; }
        int _seq, _heartbeat;
        readonly byte[] _msg = new byte[ResultsLayout.MessageMax];

        public ResultsWriter(UnmanagedMemoryAccessor a, int capacity, int helperPid)
        {
            if (a.Capacity < ResultsLayout.Size(capacity)) throw new ArgumentException("Results block too small for " + capacity + " rows");
            _a = a; Capacity = capacity;
            _a.Write(ResultsLayout.OffSequence, 1);
            _a.Write(ResultsLayout.OffVersion, ResultsLayout.Version);
            _a.Write(ResultsLayout.OffCapacity, capacity);
            _a.Write(ResultsLayout.OffRowCount, 0);
            _a.Write(ResultsLayout.OffGeneration, -1);
            _a.Write(ResultsLayout.OffGameState, (int)GameState.Opening);
            _a.Write(ResultsLayout.OffGamePid, 0);
            _a.Write(ResultsLayout.OffHelperPid, helperPid);
            _a.Write(ResultsLayout.OffHeartbeat, 0);
            _a.Write(ResultsLayout.OffMessageLen, 0);
            Thread.MemoryBarrier();
            _a.Write(ResultsLayout.OffMagic, ResultsLayout.Magic); // last: readers ignore the block until it's set
            _seq = 2;
            Thread.MemoryBarrier();
            _a.Write(ResultsLayout.OffSequence, _seq);
        }

        public void Publish(int generation, GameState state, int gamePid, string message, RowResult[] rows, int count)
        {
            count = Math.Max(0, Math.Min(count, Math.Min(Capacity, rows?.Length ?? 0)));
            _a.Write(ResultsLayout.OffSequence, ++_seq); // odd: writing
            Thread.MemoryBarrier();
            _a.Write(ResultsLayout.OffRowCount, count);
            _a.Write(ResultsLayout.OffGeneration, generation);
            _a.Write(ResultsLayout.OffGameState, (int)state);
            _a.Write(ResultsLayout.OffGamePid, gamePid);
            int n = Utf8Truncate(message ?? "", _msg);
            _a.Write(ResultsLayout.OffMessageLen, n);
            _a.WriteArray(ResultsLayout.OffMessage, _msg, 0, n);
            for (int i = 0; i < count; i++)
            {
                long o = ResultsLayout.RowOffset(i);
                _a.Write(o, rows[i].Value);
                _a.Write(o + 8, rows[i].Address);
                _a.Write(o + 16, (int)rows[i].Status);
                _a.Write(o + 20, rows[i].Detail);
            }
            _a.Write(ResultsLayout.OffHeartbeat, ++_heartbeat);
            Thread.MemoryBarrier();
            _a.Write(ResultsLayout.OffSequence, ++_seq); // even: done
        }

        /// <summary>Encodes into <paramref name="buf"/>, cutting at a character boundary.</summary>
        static int Utf8Truncate(string s, byte[] buf)
        {
            var bytes = Encoding.UTF8.GetBytes(s);
            int n = Math.Min(bytes.Length, buf.Length);
            while (n > 0 && n < bytes.Length && (bytes[n] & 0xC0) == 0x80) n--; // don't split a character
            Array.Copy(bytes, buf, n);
            return n;
        }
    }

    /// <summary>A consistent copy of the block.</summary>
    public sealed class ResultsSnapshot
    {
        public int Generation = -1;
        public GameState State;
        public int GamePid, HelperPid, Heartbeat, RowCount;
        public string Message = "";
        public RowResult[] Rows = new RowResult[0];
    }

    /// <summary>The plugin's side: copies the block when it isn't mid-write.</summary>
    public sealed class ResultsReader
    {
        readonly UnmanagedMemoryAccessor _a;
        readonly byte[] _msg = new byte[ResultsLayout.MessageMax];

        public ResultsReader(UnmanagedMemoryAccessor a) { _a = a; }

        /// <summary>False if the block isn't set up yet, or kept changing while being copied (try again next tick).</summary>
        public bool TryRead(ResultsSnapshot into, int attempts = 4)
        {
            if (_a.Capacity < ResultsLayout.HeaderSize || _a.ReadInt32(ResultsLayout.OffMagic) != ResultsLayout.Magic) return false;
            if (_a.ReadInt32(ResultsLayout.OffVersion) != ResultsLayout.Version) return false;
            int capacity = _a.ReadInt32(ResultsLayout.OffCapacity);
            if (capacity < 0 || _a.Capacity < ResultsLayout.Size(capacity)) return false;

            for (int attempt = 0; attempt < attempts; attempt++)
            {
                int s1 = _a.ReadInt32(ResultsLayout.OffSequence);
                if ((s1 & 1) != 0) { Thread.Yield(); continue; }
                Thread.MemoryBarrier();

                int count = Math.Max(0, Math.Min(capacity, _a.ReadInt32(ResultsLayout.OffRowCount)));
                if (into.Rows.Length < count) into.Rows = new RowResult[Math.Max(count, 16)];
                into.RowCount = count;
                into.Generation = _a.ReadInt32(ResultsLayout.OffGeneration);
                into.State = (GameState)_a.ReadInt32(ResultsLayout.OffGameState);
                into.GamePid = _a.ReadInt32(ResultsLayout.OffGamePid);
                into.HelperPid = _a.ReadInt32(ResultsLayout.OffHelperPid);
                into.Heartbeat = _a.ReadInt32(ResultsLayout.OffHeartbeat);
                int n = Math.Max(0, Math.Min(ResultsLayout.MessageMax, _a.ReadInt32(ResultsLayout.OffMessageLen)));
                _a.ReadArray(ResultsLayout.OffMessage, _msg, 0, n);
                for (int i = 0; i < count; i++)
                {
                    long o = ResultsLayout.RowOffset(i);
                    into.Rows[i].Value = _a.ReadDouble(o);
                    into.Rows[i].Address = _a.ReadInt64(o + 8);
                    into.Rows[i].Status = (ReadStatus)_a.ReadInt32(o + 16);
                    into.Rows[i].Detail = _a.ReadInt32(o + 20);
                }

                Thread.MemoryBarrier();
                if (_a.ReadInt32(ResultsLayout.OffSequence) == s1)
                {
                    into.Message = Encoding.UTF8.GetString(_msg, 0, n);
                    return true;
                }
            }
            return false;
        }
    }
}
