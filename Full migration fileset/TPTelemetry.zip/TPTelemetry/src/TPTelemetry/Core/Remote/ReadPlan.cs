using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace TeknoTelemetry.Core.Remote
{
    /// <summary>One memory row for the 64-bit helper: where to start, the pointer chain and the type.</summary>
    public sealed class ReadPlanRow
    {
        public string Module = "";
        public long BaseOffset;
        public long[] Offsets = new long[0];
        public MemType Type = MemType.Float;
    }

    /// <summary>
    /// What the plugin asks the 64-bit helper to read: the game's PID and name, the poll rate, and
    /// every memory row of the profile in order (a row's index is its slot in the results block).
    /// Sent once, and again after every edit. Plain text, one row per line, so the helper needs
    /// no JSON library.
    /// </summary>
    public sealed class ReadPlan
    {
        /// <summary>Rows per game. The results block has this many slots.</summary>
        public const int MaxRows = 1024;
        const string Header = "TPTPLAN 1";

        public int Pid;
        public string ProcessName = "";
        public int PollHz = 120;
        /// <summary>Set by the plugin on every send, so stale results can be told apart.</summary>
        public int Generation;
        public List<ReadPlanRow> Rows = new List<ReadPlanRow>();

        public ReadPlan WithTarget(int pid, int generation)
        {
            var c = (ReadPlan)MemberwiseClone();
            c.Pid = pid; c.Generation = generation;
            return c;
        }

        public string Serialise()
        {
            var sb = new StringBuilder();
            sb.Append(Header).Append('\n');
            sb.Append("pid=").Append(Pid.ToString(CultureInfo.InvariantCulture)).Append('\n');
            sb.Append("process=").Append(Clean(ProcessName)).Append('\n');
            sb.Append("hz=").Append(PollHz.ToString(CultureInfo.InvariantCulture)).Append('\n');
            sb.Append("gen=").Append(Generation.ToString(CultureInfo.InvariantCulture)).Append('\n');
            foreach (var r in Rows)
            {
                sb.Append("row\t").Append(Clean(r.Module)).Append('\t')
                  .Append(r.BaseOffset.ToString("X", CultureInfo.InvariantCulture)).Append('\t')
                  .Append(string.Join(",", (r.Offsets ?? new long[0]).Select(o => o.ToString("X", CultureInfo.InvariantCulture)))).Append('\t')
                  .Append(r.Type.ToString()).Append('\n');
            }
            return sb.ToString();
        }

        /// <summary>Throws FormatException on anything it doesn't understand.</summary>
        public static ReadPlan Parse(string text)
        {
            var lines = (text ?? "").Replace("\r", "").Split('\n');
            if (lines.Length == 0 || lines[0] != Header) throw new FormatException("Not a read plan (or a newer version)");
            var plan = new ReadPlan();
            for (int i = 1; i < lines.Length; i++)
            {
                var line = lines[i];
                if (line.Length == 0) continue;
                if (line.StartsWith("row\t", StringComparison.Ordinal))
                {
                    var f = line.Split('\t');
                    if (f.Length != 5) throw new FormatException($"Line {i + 1}: a row needs module, base, offsets and type");
                    if (plan.Rows.Count >= MaxRows) throw new FormatException($"More than {MaxRows} rows");
                    if (!long.TryParse(f[2], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var b))
                        throw new FormatException($"Line {i + 1}: base '{f[2]}' is not hex");
                    var offs = new List<long>();
                    foreach (var o in f[3].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        if (!long.TryParse(o, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var ov))
                            throw new FormatException($"Line {i + 1}: offset '{o}' is not hex");
                        offs.Add(ov);
                    }
                    if (!Enum.TryParse<MemType>(f[4], false, out var type) || !Enum.IsDefined(typeof(MemType), type))
                        throw new FormatException($"Line {i + 1}: unknown type '{f[4]}'");
                    plan.Rows.Add(new ReadPlanRow { Module = f[1], BaseOffset = b, Offsets = offs.ToArray(), Type = type });
                    continue;
                }
                int eq = line.IndexOf('=');
                if (eq < 0) throw new FormatException($"Line {i + 1}: can't read '{line}'");
                var key = line.Substring(0, eq); var val = line.Substring(eq + 1);
                switch (key)
                {
                    case "pid": plan.Pid = Int(val, i); break;
                    case "process": plan.ProcessName = val; break;
                    case "hz": plan.PollHz = Math.Max(10, Math.Min(1000, Int(val, i))); break;
                    case "gen": plan.Generation = Int(val, i); break;
                    default: break; // later versions may add keys
                }
            }
            return plan;
        }

        static int Int(string s, int line)
        {
            if (!int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out var v))
                throw new FormatException($"Line {line + 1}: '{s}' is not a number");
            return v;
        }

        static string Clean(string s) => (s ?? "").Replace("\t", " ").Replace("\r", " ").Replace("\n", " ");
    }
}
