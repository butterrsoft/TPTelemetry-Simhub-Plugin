using System;
using System.IO;
using System.Text;

namespace TeknoTelemetry.Core.Remote
{
    /// <summary>
    /// Control channel between the plugin and the helper (a named pipe). Each message is a 4-byte
    /// little-endian length and then that many bytes of UTF-8.
    ///
    ///   helper -> plugin, once on connecting:  HELLO 1 &lt;helper pid&gt;
    ///   plugin -> helper:  PLAN\n&lt;read plan&gt;      reply: OK &lt;generation&gt;  or  ERR &lt;reason&gt;
    ///   plugin -> helper:  STOP                     (the helper exits; closing the pipe does the same)
    /// </summary>
    public static class HelperProtocol
    {
        public const int Version = 1;
        public const int MaxMessage = 1 << 20;

        public static void Write(Stream s, string message)
        {
            var body = Encoding.UTF8.GetBytes(message ?? "");
            if (body.Length > MaxMessage) throw new InvalidOperationException("Message too long for the helper");
            var buf = new byte[4 + body.Length];
            buf[0] = (byte)body.Length; buf[1] = (byte)(body.Length >> 8); buf[2] = (byte)(body.Length >> 16); buf[3] = (byte)(body.Length >> 24);
            Array.Copy(body, 0, buf, 4, body.Length);
            s.Write(buf, 0, buf.Length);
            s.Flush();
        }

        /// <summary>Null when the other end has closed the pipe.</summary>
        public static string Read(Stream s)
        {
            var head = new byte[4];
            if (!ReadExactly(s, head, 4)) return null;
            int len = head[0] | head[1] << 8 | head[2] << 16 | head[3] << 24;
            if (len < 0 || len > MaxMessage) throw new InvalidDataException("Bad message length from the other end of the helper pipe");
            var body = new byte[len];
            if (!ReadExactly(s, body, len)) return null;
            return Encoding.UTF8.GetString(body);
        }

        static bool ReadExactly(Stream s, byte[] buf, int n)
        {
            int got = 0;
            while (got < n)
            {
                int r = s.Read(buf, got, n - got);
                if (r <= 0) return false;
                got += r;
            }
            return true;
        }
    }
}
