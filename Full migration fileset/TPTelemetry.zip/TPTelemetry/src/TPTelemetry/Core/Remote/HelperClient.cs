using System;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace TeknoTelemetry.Core.Remote
{
    public enum RemoteState { Starting, Running, GameExited, Failed }

    /// <summary>Memory reads done by another process (the 64-bit helper), as the engine sees them.</summary>
    public interface IRemoteMemory : IRemoteValues, IDisposable
    {
        /// <summary>Starts reading the game in <paramref name="plan"/> (Pid set). Doesn't block.</summary>
        void Start(ReadPlan plan);
        /// <summary>Replaces the rows after an edit; same game. Doesn't block.</summary>
        void SetPlan(ReadPlan plan);
        /// <summary>Takes this tick's results. Call once per tick, before reading rows.</summary>
        RemoteState Poll();
        /// <summary>Why it's starting or failed, or what the game state is.</summary>
        string Message { get; }
        int GamePid { get; }
    }

    /// <summary>A started helper: its control pipe and its results block (read-only view).</summary>
    public interface IHelperTransport : IDisposable
    {
        Stream Control { get; }
        UnmanagedMemoryAccessor Block { get; }
        bool Alive { get; }
    }

    /// <summary>
    /// The plugin's side of the 64-bit helper. Starting the helper and sending plans happen on a
    /// worker thread, so the poll thread never waits; <see cref="Poll"/> only copies the results
    /// block. Results count only when they belong to the latest plan sent (by generation).
    /// Any failure is final for this client: the engine disposes it and starts a new one later.
    /// </summary>
    public sealed class HelperClient : IRemoteMemory
    {
        readonly Func<IHelperTransport> _launch;
        readonly object _sync = new object();
        readonly object _writeLock = new object();
        readonly AutoResetEvent _wake = new AutoResetEvent(false);
        readonly ResultsSnapshot _snap = new ResultsSnapshot();
        readonly Stopwatch _sinceStart = new Stopwatch(), _sinceBeat = new Stopwatch();

        Thread _worker;
        IHelperTransport _t;
        ResultsReader _reader;
        ReadPlan _pending;
        int _generation;
        volatile bool _disposed, _connected;
        volatile string _failure;
        bool _haveSnap;
        int _lastBeat = int.MinValue;

        /// <summary>How long the helper may take to start and connect.</summary>
        public TimeSpan StartTimeout { get; set; } = TimeSpan.FromSeconds(15);
        /// <summary>How long without a new heartbeat before the helper counts as hung.</summary>
        public TimeSpan StallTimeout { get; set; } = TimeSpan.FromSeconds(3);

        public string Message { get; private set; } = "Starting the 64-bit helper";
        public int GamePid { get; private set; }

        public HelperClient(Func<IHelperTransport> launcher) { _launch = launcher; }

        public void Start(ReadPlan plan)
        {
            if (_worker != null) throw new InvalidOperationException("Already started");
            GamePid = plan.Pid;
            Queue(plan);
            _sinceStart.Start();
            _worker = new Thread(Work) { IsBackground = true, Name = "TPTelemetry helper client" };
            _worker.Start();
        }

        public void SetPlan(ReadPlan plan) => Queue(plan.WithTarget(GamePid, 0));

        void Queue(ReadPlan plan)
        {
            lock (_sync)
            {
                _generation++;
                _pending = plan.WithTarget(plan.Pid, _generation);
            }
            _wake.Set();
        }

        void Work()
        {
            try
            {
                var t = _launch();
                lock (_sync)
                {
                    if (_disposed) { t.Dispose(); return; }
                    _t = t;
                }
                var hello = HelperProtocol.Read(t.Control);
                if (hello == null || !hello.StartsWith("HELLO ", StringComparison.Ordinal))
                    throw new InvalidDataException("unexpected greeting: " + (hello ?? "(closed)"));
                var parts = hello.Split(' ');
                if (parts.Length < 2 || parts[1] != HelperProtocol.Version.ToString())
                    throw new InvalidDataException($"helper speaks version {(parts.Length > 1 ? parts[1] : "?")}, plugin speaks {HelperProtocol.Version}: reinstall both together");
                _reader = new ResultsReader(t.Block);
                _connected = true;

                while (!_disposed)
                {
                    ReadPlan p;
                    lock (_sync) { p = _pending; _pending = null; }
                    if (p == null) { _wake.WaitOne(500); continue; }
                    lock (_writeLock) HelperProtocol.Write(t.Control, "PLAN\n" + p.Serialise());
                    var reply = HelperProtocol.Read(t.Control);
                    if (reply == null) throw new IOException("the helper closed the connection");
                    if (!reply.StartsWith("OK", StringComparison.Ordinal)) throw new InvalidDataException("the helper refused the read plan: " + reply);
                }
            }
            catch (Exception e)
            {
                if (!_disposed)
                {
                    _failure = "64-bit helper: " + e.Message;
                    Log.Error("64-bit helper", e);
                }
            }
        }

        public RemoteState Poll()
        {
            if (_failure != null) { Message = _failure; return RemoteState.Failed; }
            if (!_connected)
            {
                if (_sinceStart.Elapsed > StartTimeout) { _failure = "64-bit helper: didn't start in time"; Message = _failure; return RemoteState.Failed; }
                Message = "Starting the 64-bit helper";
                return RemoteState.Starting;
            }
            if (!_t.Alive) { _failure = "The 64-bit helper exited unexpectedly"; Message = _failure; return RemoteState.Failed; }

            if (_reader.TryRead(_snap))
            {
                _haveSnap = true;
                if (_snap.Heartbeat != _lastBeat) { _lastBeat = _snap.Heartbeat; _sinceBeat.Restart(); }
            }
            if (!_haveSnap)
            {
                if (_sinceStart.Elapsed > StartTimeout) { _failure = "64-bit helper: no results"; Message = _failure; return RemoteState.Failed; }
                Message = "Starting the 64-bit helper";
                return RemoteState.Starting;
            }
            if (_sinceBeat.Elapsed > StallTimeout) { _failure = "The 64-bit helper stopped responding"; Message = _failure; return RemoteState.Failed; }

            switch (_snap.State)
            {
                case GameState.Attached: Message = ""; return RemoteState.Running;
                case GameState.Exited: Message = _snap.Message; return RemoteState.GameExited;
                case GameState.Error: Message = _snap.Message; return RemoteState.Failed;
                default: Message = "Starting the 64-bit helper"; return RemoteState.Starting;
            }
        }

        public bool TryGet(int slot, out RowResult result)
        {
            result = default(RowResult);
            if (!_haveSnap || _snap.State != GameState.Attached || slot < 0 || slot >= _snap.RowCount) return false;
            if (_snap.Generation != Volatile.Read(ref _generation)) return false; // results for an older plan
            result = _snap.Rows[slot];
            return true;
        }

        public void Dispose()
        {
            IHelperTransport t;
            lock (_sync) { if (_disposed) return; _disposed = true; t = _t; }
            _wake.Set();
            if (t != null)
            {
                try { lock (_writeLock) HelperProtocol.Write(t.Control, "STOP"); } catch { }
                try { t.Dispose(); } catch (Exception e) { Log.Error("Stopping the 64-bit helper", e); }
            }
        }
    }
}
