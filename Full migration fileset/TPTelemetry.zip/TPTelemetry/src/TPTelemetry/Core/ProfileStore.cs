using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace TeknoTelemetry.Core
{
    /// <summary>
    /// One JSON file per game in a folder, so profiles can be shared by copying a single file.
    /// Default folder: SimHub\PluginsData\TPTelemetry\Profiles
    /// </summary>
    public sealed class ProfileStore
    {
        public string Folder { get; }
        public string SettingsPath => Path.Combine(Path.GetDirectoryName(Folder) ?? Folder, "settings.json");

        static readonly JsonSerializerSettings Json = new JsonSerializerSettings
        {
            Formatting = Formatting.Indented,
            Converters = { new StringEnumConverter() },
            NullValueHandling = NullValueHandling.Ignore,
        };

        public ProfileStore(string folder)
        {
            Folder = folder;
            Directory.CreateDirectory(Folder);
        }

        // Which file each profile was loaded from, by Id, so renamed or duplicate files get tidied.
        readonly Dictionary<string, string> _sourceFile = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        readonly HashSet<string> _stale = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        readonly HashSet<string> _removedIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Loads every profile in the folder. If two files hold the same game (same Id, e.g. a copy
        /// dropped in by hand next to the plugin's own save), the newer file wins and the older is
        /// removed at the next save.
        /// </summary>
        public List<GameProfile> LoadAll(List<string> errors = null)
        {
            var chosen = new Dictionary<string, (GameProfile p, DateTime t, string file)>(StringComparer.OrdinalIgnoreCase);
            var order = new List<string>();
            foreach (var f in Directory.GetFiles(Folder, "*.json").OrderBy(f => f, StringComparer.OrdinalIgnoreCase))
            {
                try
                {
                    var p = ReadProfile(f);
                    if (p == null) continue;
                    var t = File.GetLastWriteTimeUtc(f);
                    if (chosen.TryGetValue(p.Id, out var prev))
                    {
                        var keepNew = t > prev.t;
                        var loser = keepNew ? prev.file : f;
                        _stale.Add(loser);
                        Log.Info($"{Path.GetFileName(f)} and {Path.GetFileName(prev.file)} are the same game; using {Path.GetFileName(keepNew ? f : prev.file)}, the older copy goes at the next save");
                        if (!keepNew) continue;
                    }
                    else order.Add(p.Id);
                    chosen[p.Id] = (p, t, f);
                }
                catch (Exception e) { errors?.Add($"{Path.GetFileName(f)}: {e.Message}"); }
            }
            foreach (var kv in chosen) _sourceFile[kv.Key] = kv.Value.file;
            return order.Select(id => chosen[id].p).ToList();
        }

        public static GameProfile ReadProfile(string path)
        {
            var p = JsonConvert.DeserializeObject<GameProfile>(File.ReadAllText(path), Json);
            if (p == null) return null;
            if (string.IsNullOrEmpty(p.Id)) p.Id = Guid.NewGuid().ToString("N");
            p.Variables = p.Variables ?? new List<VariableDef>();
            return p;
        }

        public static void WriteProfile(GameProfile p, string path)
        {
            var tmp = path + ".tmp";
            File.WriteAllText(tmp, JsonConvert.SerializeObject(p, Json));
            if (File.Exists(path)) File.Delete(path);
            File.Move(tmp, path);
        }

        /// <summary>Call when the user deletes a game, so its file is removed at the next save.</summary>
        public void MarkRemoved(string id) { if (!string.IsNullOrEmpty(id)) _removedIds.Add(id); }

        /// <summary>
        /// Writes every profile as {Prefix}.json. Removes only files this store knows are out of date:
        /// a game's previous file after a prefix change, older duplicate copies, and deleted games.
        /// Anything else in the folder is left alone.
        /// </summary>
        public void SaveAll(IEnumerable<GameProfile> profiles)
        {
            var list = profiles.ToList();
            var keep = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in list)
            {
                var path = Path.GetFullPath(PathFor(p, list));
                WriteProfile(p, path);
                keep.Add(path);
                if (_sourceFile.TryGetValue(p.Id, out var old) && !keep.Contains(Path.GetFullPath(old)))
                    _stale.Add(old);
                _sourceFile[p.Id] = path;
            }
            foreach (var id in _removedIds)
                if (_sourceFile.TryGetValue(id, out var f)) _stale.Add(f);

            foreach (var f in _stale.ToList())
            {
                if (keep.Contains(Path.GetFullPath(f))) { _stale.Remove(f); continue; }
                try { if (File.Exists(f)) File.Delete(f); _stale.Remove(f); }
                catch (Exception e) { Log.Error("Couldn't remove old profile file " + f, e); }
            }
            foreach (var id in _removedIds) _sourceFile.Remove(id);
            _removedIds.Clear();
        }

        /// <summary>{Prefix}.json, or {Prefix}_{first 6 of Id}.json if two games share a prefix.</summary>
        public string PathFor(GameProfile p, IEnumerable<GameProfile> all = null)
        {
            string Safe(GameProfile g) => new string((string.IsNullOrWhiteSpace(g.Prefix) ? "game" : g.Prefix.Trim())
                .Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c).ToArray());
            var name = Safe(p);
            bool clash = all != null && all.Any(o => o.Id != p.Id && string.Equals(Safe(o), name, StringComparison.OrdinalIgnoreCase));
            return Path.Combine(Folder, clash ? $"{name}_{p.Id.Substring(0, Math.Min(6, p.Id.Length))}.json" : name + ".json");
        }

        public PluginSettings LoadSettings()
        {
            try
            {
                if (File.Exists(SettingsPath))
                    return JsonConvert.DeserializeObject<PluginSettings>(File.ReadAllText(SettingsPath), Json) ?? new PluginSettings();
            }
            catch { }
            return new PluginSettings();
        }

        public void SaveSettings(PluginSettings s) => File.WriteAllText(SettingsPath, JsonConvert.SerializeObject(s, Json));

        public static string ToJson(GameProfile p) => JsonConvert.SerializeObject(p, Json);
        public static GameProfile Clone(GameProfile p) => JsonConvert.DeserializeObject<GameProfile>(ToJson(p), Json);
    }
}
