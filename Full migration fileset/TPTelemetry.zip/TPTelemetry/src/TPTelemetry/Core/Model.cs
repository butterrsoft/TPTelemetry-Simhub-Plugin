using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace TeknoTelemetry.Core
{
    /// <summary>Where a variable's raw value comes from.</summary>
    public enum SourceKind
    {
        /// <summary>Read from game memory via module + offset + pointer chain.</summary>
        Memory = 0,
        /// <summary>No raw value; output is the formula alone (e.g. acceleration from speed).</summary>
        Computed = 1,
        // Force feedback values are read in formulas as ffb_force, ffb_spring, ... (see Core/Ffb).
    }

    /// <summary>Memory data types, named to match Cheat Engine.</summary>
    public enum MemType
    {
        Float = 0,
        Double = 1,
        Int32 = 2,   // CE "4 Bytes"
        Int16 = 3,   // CE "2 Bytes"
        Byte = 4,    // CE "Byte"
        Int64 = 5,   // CE "8 Bytes"
        UInt32 = 6,
        UInt16 = 7,
    }

    public static class MemTypes
    {
        public static int Size(MemType t)
        {
            switch (t)
            {
                case MemType.Float: return 4;
                case MemType.Double: return 8;
                case MemType.Int32: return 4;
                case MemType.UInt32: return 4;
                case MemType.Int16: return 2;
                case MemType.UInt16: return 2;
                case MemType.Byte: return 1;
                case MemType.Int64: return 8;
                default: return 4;
            }
        }

        public static double Decode(MemType t, byte[] b)
        {
            switch (t)
            {
                case MemType.Float: return BitConverter.ToSingle(b, 0);
                case MemType.Double: return BitConverter.ToDouble(b, 0);
                case MemType.Int32: return BitConverter.ToInt32(b, 0);
                case MemType.UInt32: return BitConverter.ToUInt32(b, 0);
                case MemType.Int16: return BitConverter.ToInt16(b, 0);
                case MemType.UInt16: return BitConverter.ToUInt16(b, 0);
                case MemType.Byte: return b[0];
                case MemType.Int64: return BitConverter.ToInt64(b, 0);
                default: return double.NaN;
            }
        }

        /// <summary>Maps a Cheat Engine VariableType string. Returns null if unsupported.</summary>
        public static MemType? FromCheatEngine(string ceType)
        {
            switch ((ceType ?? "").Trim().ToLowerInvariant())
            {
                case "float": return MemType.Float;
                case "double": return MemType.Double;
                case "4 bytes": return MemType.Int32;
                case "2 bytes": return MemType.Int16;
                case "byte": return MemType.Byte;
                case "8 bytes": return MemType.Int64;
                default: return null;
            }
        }
    }

    /// <summary>One value exposed to SimHub.</summary>
    public class VariableDef
    {
        /// <summary>Short name, e.g. "speed". Exported as {Prefix}_{Name}.</summary>
        public string Name { get; set; } = "new_var";

        /// <summary>When false the variable is still read and evaluated (for the live preview and
        /// for other formulas) but is not published to SimHub.</summary>
        public bool Enabled { get; set; } = true;

        public SourceKind Source { get; set; } = SourceKind.Memory;
        public MemType Type { get; set; } = MemType.Float;

        /// <summary>Module the base offset is relative to, e.g. "BudgieLoader.exe" or "TeknoParrot.dll".
        /// "&lt;main&gt;" means the process's own executable, whatever its name.
        /// Empty means BaseOffset is an absolute address (unstable across restarts).</summary>
        public string Module { get; set; } = "";

        /// <summary>Hex, no prefix needed, e.g. "0106A79C".</summary>
        public string BaseOffset { get; set; } = "0";

        /// <summary>Pointer offsets in hex, comma separated, in the order they are applied
        /// (first = nearest the base). Empty = read directly at module + base offset.</summary>
        public string Offsets { get; set; } = "";

        /// <summary>Optional formula. For memory variables, "value" is the raw read.
        /// Empty means output = raw value.</summary>
        public string Formula { get; set; } = "";

        public string Notes { get; set; } = "";

        public VariableDef Clone() => (VariableDef)MemberwiseClone();
    }

    /// <summary>One game (one process) and its variables.</summary>
    public class GameProfile
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");
        public string DisplayName { get; set; } = "New game";

        /// <summary>Property prefix, e.g. "WMMT3DXP" gives WMMT3DXP_speed.</summary>
        public string Prefix { get; set; } = "GAME";

        /// <summary>Process to attach to, e.g. "BudgieLoader.exe".</summary>
        public string ProcessName { get; set; } = "";

        /// <summary>Kept so older profile files still load. Since 0.12.0 every profile is enabled:
        /// the game selected on the settings page (or by command line) is the one read.</summary>
        public bool Enabled { get; set; } = true;

        /// <summary>Top speed for this game, in the units of its speed row. Formulas read it as
        /// max_speed, so speed / max_speed runs 0 to 1. Blank (null) means 1, giving the raw value.</summary>
        public double? MaxSpeed { get; set; }

        /// <summary>Redline for this game, in the units of its revs row. Formulas read it as
        /// max_revs. Blank (null) means 1, giving the raw value.</summary>
        public double? MaxRevs { get; set; }

        /// <summary>The smallest top speed or redline allowed; blank counts as this.</summary>
        public const double MinReference = 1;

        /// <summary>The value formulas see for max_speed or max_revs: blank, invalid or too small gives 1.</summary>
        public static double Reference(double? v) =>
            v is double d && !double.IsNaN(d) && !double.IsInfinity(d) && d >= MinReference ? d : MinReference;

        public List<VariableDef> Variables { get; set; } = new List<VariableDef>();
    }

#if !TPT_HELPER // the 64-bit helper links this file but has no settings
    public class PluginSettings
    {
        public int PollRateHz { get; set; } = 120;
        public bool SanitisePropertyNames { get; set; } = true;

        /// <summary>Prefix of the one game whose profile may read memory (set from the command line
        /// or the settings page). Empty = every enabled profile attaches to its process when it runs.</summary>
        public string ActiveGame { get; set; } = "";

        /// <summary>Force feedback capture (one wheel, shared by all games).</summary>
        public global::TeknoTelemetry.Core.Ffb.FfbSettings Ffb { get; set; } = new global::TeknoTelemetry.Core.Ffb.FfbSettings();

        /// <summary>Game outputs (lamps etc.) received over MAME's network output protocol.</summary>
        public global::TeknoTelemetry.Core.Outputs.OutputsSettings Outputs { get; set; } = new global::TeknoTelemetry.Core.Outputs.OutputsSettings();

        /// <summary>Read TeknoParrot's shared memory (tp_jvs0..15).</summary>
        public bool TeknoParrotSharedMemory { get; set; } = true;

        /// <summary>The hardware ticked under SimHub effects, for the effect profiles.</summary>
        public global::TeknoTelemetry.Core.EffectHardware Effects { get; set; } = new global::TeknoTelemetry.Core.EffectHardware();

        /// <summary>Settings page: show the Source, Type, Module, Base offset and Offsets columns.</summary>
        public bool ShowAddressColumns { get; set; } = true;

        /// <summary><see cref="ActiveGame"/> value meaning no profile reads memory.</summary>
        public const string NoGame = "-";
    }
#endif

    public static class Names
    {
        static readonly Regex Ident = new Regex("^[A-Za-z_][A-Za-z0-9_]*$", RegexOptions.Compiled);

        public static bool IsValidIdentifier(string s) => !string.IsNullOrEmpty(s) && Ident.IsMatch(s);

        /// <summary>Makes a string safe for SimHub property names and formula identifiers.
        /// "+" becomes "P" (WMMT3DX+ → WMMT3DXP), other illegal characters become "_".</summary>
        public static string Sanitise(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "_";
            var chars = s.Trim().Replace("+", "P").Select(c => char.IsLetterOrDigit(c) && c < 128 || c == '_' ? c : '_').ToArray();
            var r = new string(chars);
            if (char.IsDigit(r[0])) r = "_" + r;
            return r;
        }

        public static string PropertyName(GameProfile p, VariableDef v, bool sanitise)
        {
            var prefix = sanitise ? Sanitise(p.Prefix) : p.Prefix;
            var name = sanitise ? Sanitise(v.Name) : v.Name;
            return prefix + "_" + name;
        }
    }

    public static class Hex
    {
        public static bool TryParse(string s, out long value)
        {
            value = 0;
            if (s == null) return false;
            s = s.Trim();
            bool neg = false;
            if (s.StartsWith("-")) { neg = true; s = s.Substring(1).Trim(); }
            else if (s.StartsWith("+")) s = s.Substring(1).Trim();
            if (s.StartsWith("0x", StringComparison.OrdinalIgnoreCase)) s = s.Substring(2);
            if (s.Length == 0) return false;
            if (!ulong.TryParse(s, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out var u)) return false;
            value = neg ? -(long)u : (long)u;
            return true;
        }

        public static bool TryParseList(string s, out List<long> values, out string error)
        {
            values = new List<long>();
            error = null;
            if (string.IsNullOrWhiteSpace(s)) return true;
            foreach (var part in s.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                // "@588" (0.18.2): the pointer at this step is a 32-bit address inside an emulator's memory (see EmuHop).
                if (part.StartsWith("@"))
                {
                    if (!TryParse(part.Substring(1), out var e) || e < 0 || e >= EmuHop)
                    { error = $"'{part}' is not @ and a hex number"; return false; }
                    if (values.Count == 0) { error = $"'{part}' can't come first: the first offset follows the emulator's own pointer to the game's memory"; return false; }
                    values.Add(EmuHop | e);
                    continue;
                }
                // "[-E80]*578" (0.19.0): an index into an array of records, read from the game's own memory (see IndexHop).
                if (part.StartsWith("["))
                {
                    int close = part.IndexOf(']');
                    if (close < 0 || close + 1 >= part.Length || part[close + 1] != '*'
                        || !TryParse(part.Substring(1, close - 1), out var rel) || rel < int.MinValue || rel > int.MaxValue
                        || !TryParse(part.Substring(close + 2), out var stride) || stride <= 0 || stride > IndexStrideMax)
                    { error = $"'{part}' is not [hex offset]*hex record size"; return false; }
                    values.Add(IndexHop | (stride << 32) | (rel & 0xFFFFFFFFL));
                    continue;
                }
                if (!TryParse(part, out var v)) { error = $"'{part}' is not a hex number"; return false; }
                values.Add(v);
            }
            // An index must be followed by an ordinary offset: the pointer it indexes into.
            for (int i = 0; i < values.Count; i++)
                if (IsIndexHop(values[i]) && (i + 1 >= values.Count || IsIndexHop(values[i + 1]) || IsEmuHop(values[i + 1])))
                { error = "an [offset]*size index must be followed by an ordinary offset (the pointer to the records)"; return false; }
            return true;
        }

        /// <summary>Marks an offset written "[-E80]*578" (0.19.0): the chain reads an Int32 at the current address plus the
        /// bracketed offset (before following the pointer there), and the next step lands that many records of the given
        /// size further on. For a game's array of per-car records indexed by its own player number (Sega World Drivers
        /// Championship, 18 November 2026). Bits 32 to 55 hold the record size, bits 0 to 31 the offset (signed).</summary>
        public const long IndexHop = 2L << 56;
        public const long IndexStrideMax = 0xFFFFFF;
        public static bool IsIndexHop(long offset) => (offset >> 56) == 2;
        public static long IndexStride(long offset) => (offset >> 32) & IndexStrideMax;
        public static long IndexOffset(long offset) => (int)(offset & 0xFFFFFFFFL);

        /// <summary>Marks an offset written "@588" (0.18.2): at that step the chain reads a 32-bit address of the emulated
        /// machine (a game inside Flycast), not one of the emulator's own pointers. The offset is the low bits.</summary>
        public const long EmuHop = 1L << 56;
        /// <summary>The emulated memory an "@" pointer can address: its low 25 bits (32 MB, NAOMI 2; NAOMI and Dreamcast
        /// have 16 MB at the same place), so 0x0C......, 0x8C...... and 0xAC...... all land on the same byte.</summary>
        public const long EmuMask = 0x1FFFFFF;
        public static bool IsEmuHop(long offset) => (offset >> 56) == 1;

        public static string Format(long v) => v < 0 ? "-" + (-v).ToString("X") : v.ToString("X");
    }
}
