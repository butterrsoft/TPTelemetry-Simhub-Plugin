using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace TeknoTelemetry.Core.TeknoParrot
{
    /// <summary>Values TeknoParrot publishes for every game, readable in formulas as tp_jvs0 .. tp_jvs15.</summary>
    public static class TpChannels
    {
        public const int SlotCount = 16;
        public const int Connected = SlotCount;   // tp_connected
        public const int Count = SlotCount + 1;

        public static int? FromIdentifier(string ident)
        {
            if (ident == null) return null;
            if (ident.Equals("tp_connected", StringComparison.OrdinalIgnoreCase)) return Connected;
            if (ident.StartsWith("tp_jvs", StringComparison.OrdinalIgnoreCase) &&
                int.TryParse(ident.Substring(6), out var n) && n >= 0 && n < SlotCount && ident.Substring(6) == n.ToString())
                return n;
            return null;
        }

        public static string Identifier(int i) => i == Connected ? "tp_connected" : "tp_jvs" + i;
    }

    /// <summary>
    /// TeknoParrot's shared memory block "TeknoParrot_JvsState": 64 bytes, read here as sixteen 32-bit
    /// signed values. TeknoParrot's arcade I/O emulation writes the game's force feedback board
    /// commands into it (slot 2 for most games; slots 6-9 for WMMT3DX+, Dead Heat, D1GP and Storm
    /// Racer G). Layout as documented by the open-source FFB Arcade Plugin; this is our own reader.
    /// Read-only: nothing is ever written.
    /// </summary>
    public sealed class TpSharedMemory : IDisposable
    {
        public const string MappingName = "TeknoParrot_JvsState";
        const int Size = 64;

        IntPtr _map, _view;
        long _nextTryMs;
        readonly System.Diagnostics.Stopwatch _clock = System.Diagnostics.Stopwatch.StartNew();
        public string Status { get; private set; } = "Not looked for yet";
        public bool IsOpen => _view != IntPtr.Zero;

        /// <summary>Fills slots and the connected flag. Called on the poll thread.</summary>
        public void Snapshot(double[] into)
        {
            if (!IsOpen) TryOpen();
            if (!IsOpen)
            {
                for (int i = 0; i < into.Length; i++) into[i] = double.NaN;
                if (into.Length > TpChannels.Connected) into[TpChannels.Connected] = 0;
                return;
            }
            for (int i = 0; i < TpChannels.SlotCount && i < into.Length; i++) into[i] = Marshal.ReadInt32(_view, i * 4);
            if (into.Length > TpChannels.Connected) into[TpChannels.Connected] = 1;
        }

        void TryOpen()
        {
            if (_clock.ElapsedMilliseconds < _nextTryMs) return;
            _nextTryMs = _clock.ElapsedMilliseconds + 1000;
            if (Environment.OSVersion.Platform != PlatformID.Win32NT) { Status = "Windows only"; return; }
            try
            {
                // Open only, read-only. Never create it: if SimHub runs as administrator and makes the
                // mapping first, a TeknoParrot running without administrator rights can't open it.
                // TeknoParrot creates it (64 bytes) when a game starts; until then, retry each second.
                _map = OpenFileMapping(FILE_MAP_READ, false, MappingName);
                if (_map == IntPtr.Zero)
                {
                    var err = Marshal.GetLastWin32Error();
                    Status = err == 2 ? "Waiting for a TeknoParrot game"
                           : err == 5 ? "TeknoParrot's shared memory exists but Windows refused access: run SimHub as administrator"
                           : "Couldn't open TeknoParrot's shared memory: " + new Win32Exception(err).Message;
                    return;
                }
                _view = MapViewOfFile(_map, FILE_MAP_READ, 0, 0, new UIntPtr(Size));
                if (_view == IntPtr.Zero)
                {
                    Status = "Couldn't read TeknoParrot's shared memory: " + new Win32Exception(Marshal.GetLastWin32Error()).Message;
                    CloseHandle(_map); _map = IntPtr.Zero;
                    return;
                }
                Status = "Connected to TeknoParrot's shared memory";
                Log.Info("TeknoParrot shared memory: " + Status);
            }
            catch (Exception e) { Status = "Error: " + e.Message; }
        }

        public void Dispose()
        {
            if (_view != IntPtr.Zero) { UnmapViewOfFile(_view); _view = IntPtr.Zero; }
            if (_map != IntPtr.Zero) { CloseHandle(_map); _map = IntPtr.Zero; }
        }

        const uint FILE_MAP_READ = 0x0004;
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern IntPtr OpenFileMapping(uint access, bool inherit, string name);
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr MapViewOfFile(IntPtr map, uint access, uint offHigh, uint offLow, UIntPtr bytes);
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool UnmapViewOfFile(IntPtr view);
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool CloseHandle(IntPtr h);
    }
}
