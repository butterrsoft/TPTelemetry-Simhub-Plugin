using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using TeknoTelemetry.Core.Expressions;

namespace TeknoTelemetry.Core
{
    /// <summary>Live state of one variable. Written by the poll thread, read by SimHub and the UI.</summary>
    public sealed class VarState
    {
        public VariableDef Def { get; internal set; }
        public string PropertyName { get; internal set; }
        public int Slot { get; internal set; }

        double _raw = double.NaN, _out = double.NaN;
        public double Raw { get => Volatile.Read(ref _raw); internal set => Volatile.Write(ref _raw, value); }
        public double Output { get => Volatile.Read(ref _out); internal set => Volatile.Write(ref _out, value); }

        /// <summary>Address or error from the last read, or a formula/config error.</summary>
        public string Status { get; internal set; } = "";
        public bool HasConfigError { get; internal set; }

        internal IRawSource Source;
        internal Formula Formula;
    }

    public sealed class ProfileState
    {
        public GameProfile Def { get; internal set; }
        public string Prefix { get; internal set; }
        public VarState[] Vars { get; internal set; } = new VarState[0];
        public bool Connected { get; internal set; }
        /// <summary>Enabled, and either no active game is set or this is it.</summary>
        public bool Active { get; internal set; }
        public string Status { get; internal set; } = "";
        public double SampleRateHz { get; internal set; }

        internal int[] Order = new int[0];
        internal double[] Slots = new double[0];
        internal ProcessMemory Memory;
        /// <summary>The 64-bit helper reading this game, when the game is 64-bit and SimHub isn't.</summary>
        internal Remote.IRemoteMemory Remote;
        /// <summary>Every memory row, for the helper. A row's index is its MemorySource.PlanSlot.</summary>
        internal Remote.ReadPlan Plan = new Remote.ReadPlan();
        internal readonly Stopwatch Clock = new Stopwatch();
        internal double LastT;
        internal long NextAttachMs;
        internal long NextNewerCheckMs;
        internal int TickCount;
        internal double RateWindowStart;
        internal int RateWindowTicks;
        internal readonly EvalContext Ctx = new EvalContext();
        internal readonly SourceContext SrcCtx = new SourceContext();
    }

    /// <summary>
    /// Polls every enabled game profile on a dedicated thread at a fixed rate, independent of
    /// SimHub's own update loop, so derivatives (acceleration) use accurate timestamps.
    /// </summary>
    public sealed class TelemetryEngine : IDisposable
    {
        readonly object _sync = new object();
        volatile ProfileState[] _profiles = new ProfileState[0];
        Dictionary<string, VarState> _byProperty = new Dictionary<string, VarState>(StringComparer.OrdinalIgnoreCase);
        Dictionary<string, ProfileState> _byConnectedProp = new Dictionary<string, ProfileState>(StringComparer.OrdinalIgnoreCase);
        Thread _thread;
        volatile bool _running;
        /// <summary>Time base for attach retries (NextAttachMs).</summary>
        readonly Stopwatch _attachClock = Stopwatch.StartNew();
        int _pollHz = 120;
        bool _sanitise = true;
        string _activeGame = "";

        // Force feedback: filled once per poll (FfbSource), read by formulas on the same thread.
        readonly double[] _ffb = Enumerable.Repeat(double.NaN, Ffb.FfbChannels.Count).ToArray();
        readonly double[] _ffbPublished = Enumerable.Repeat(double.NaN, Ffb.FfbChannels.Count).ToArray();

        // Value recording (CSV)
        readonly object _recLock = new object();
        volatile ValueRecorder _recorder;
        public ValueRecorder Recorder => _recorder;

        /// <summary>Starts recording the selected game's values and the FFB channels to a CSV in
        /// <paramref name="folder"/>. Stops by itself after <paramref name="maxMinutes"/>.</summary>
        public ValueRecorder StartRecording(string folder, double maxMinutes = 15)
        {
            lock (_recLock)
            {
                _recorder?.Finish();
                var game = _profiles.FirstOrDefault(p => p.Active && p.Def.Enabled);
                var name = $"{DateTime.Now:yyyyMMdd-HHmmss}_{(game == null ? "FFB" : game.Prefix)}.csv";
                _recorder = new ValueRecorder(System.IO.Path.Combine(folder, name), game?.Def, TimeSpan.FromMinutes(maxMinutes),
                                              OutputNames?.Invoke()?.ToArray() ?? new string[0]);
                Log.Info("Recording values to " + _recorder.Path);
                return _recorder;
            }
        }

        public void StopRecording()
        {
            lock (_recLock) { _recorder?.Finish(); _recorder = null; }
        }

        /// <summary>Numbers an event in the recording's marker column. Returns 0 if not recording.</summary>
        public int Mark() => _recorder?.Mark() ?? 0;

        void WriteRecording()
        {
            var rec = _recorder;
            if (rec == null) return;
            lock (_recLock)
            {
                if (_recorder != rec) return;
                try
                {
                    rec.Write(_profiles.FirstOrDefault(rec.IsFor), _ffb, _tp, OutputSource, Common);
                    if (rec.Finished) _recorder = null;
                }
                catch (Exception e) { Log.Error("Recording", e); rec.Finish(); _recorder = null; }
            }
        }

        /// <summary>The common values (TPTelemetry.Car_*), worked out from the selected game's car_ rows each tick.</summary>
        public CommonValues Common { get; } = new CommonValues();

        /// <summary>Supplies force feedback channel values each poll (null = none).</summary>
        public Action<double[]> FfbSource { get; set; }

        // TeknoParrot shared memory, filled once per poll like FFB
        readonly double[] _tp = Enumerable.Repeat(double.NaN, TeknoParrot.TpChannels.Count).ToArray();
        readonly double[] _tpPublished = Enumerable.Repeat(double.NaN, TeknoParrot.TpChannels.Count).ToArray();
        public Action<double[]> TpSource { get; set; }
        public double TpValue(int i) => Interlocked.CompareExchange(ref _tpPublished[i], 0, 0);

        /// <summary>Game outputs by name (lamps etc.); NaN if unknown.</summary>
        public Func<string, double> OutputSource { get; set; }
        /// <summary>Output names to include in recordings (taken when a recording starts).</summary>
        public Func<IEnumerable<string>> OutputNames { get; set; }

        /// <summary>Latest FFB channel value for SimHub properties (any thread).</summary>
        public double FfbValue(int channel) => Interlocked.CompareExchange(ref _ffbPublished[channel], 0, 0);

        public void CopyFfb(double[] into)
        {
            for (int i = 0; i < into.Length && i < _ffbPublished.Length; i++) into[i] = FfbValue(i);
        }

        /// <summary>Overridable for tests and for future source kinds.</summary>
        public Func<VariableDef, IRawSource> SourceFactory { get; set; } = DefaultSourceFactory;

        /// <summary>Overridable for tests. Returns null when the process isn't running.</summary>
        public Func<string, ProcessMemory> ProcessOpener { get; set; } = ProcessMemory.TryOpen;
        /// <summary>The newest running process with a name (PID), checked every few seconds while attached: when a newer
        /// copy of the game starts (an old one can hang on after being closed), the profile moves to it.</summary>
        public Func<string, int?> NewestProcess { get; set; } = ProcessMemory.NewestPid;
        internal const int NewerProcessCheckMs = 3000;

        /// <summary>Makes a reader for 64-bit games (the plugin supplies one that starts
        /// TPTelemetryHelper64.exe). Null: 64-bit games show the "SimHub is 32-bit" error.</summary>
        public Func<Remote.IRemoteMemory> RemoteMemoryFactory { get; set; }

        /// <summary>How long to wait before starting a new helper after one failed.</summary>
        public int RemoteRetryMs { get; set; } = 10000;

        /// <summary>Raised (on the caller's thread of Load) with every property name that should exist.</summary>
        public event Action<IReadOnlyCollection<string>> PropertiesChanged;

        public static IRawSource DefaultSourceFactory(VariableDef v)
        {
            switch (v.Source)
            {
                case SourceKind.Memory: return MemorySource.From(v);
                case SourceKind.Computed: return NoSource.Instance;
                default: throw new NotSupportedException($"Source {v.Source} not supported yet");
            }
        }

        // Lock-free so the settings page never waits on the poll thread.
        public IReadOnlyList<ProfileState> Profiles => _profiles;

        public string ConnectedPropertyName(GameProfile p) => (_sanitise ? Names.Sanitise(p.Prefix) : p.Prefix) + "_Connected";

        /// <summary>Rebuilds everything from definitions. Keeps process handles for unchanged
        /// process names; time-series state restarts.</summary>
        public void Load(IEnumerable<GameProfile> defs, PluginSettings settings)
        {
            _pollHz = Math.Max(10, Math.Min(1000, settings?.PollRateHz ?? 120));
            _sanitise = settings?.SanitisePropertyNames ?? true;
            var ag = (settings?.ActiveGame ?? "").Trim();
            _activeGame = ag == "" ? "" : ag == PluginSettings.NoGame ? PluginSettings.NoGame : Names.Sanitise(ag);

            var built = defs.Select(Build).ToArray();
            var byProp = new Dictionary<string, VarState>(StringComparer.OrdinalIgnoreCase);
            var byConn = new Dictionary<string, ProfileState>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in built)
            {
                if (p.Def.Enabled) byConn[ConnectedPropertyName(p.Def)] = p; // false while inactive
                foreach (var v in p.Vars)
                {
                    if (byProp.ContainsKey(v.PropertyName))
                    {
                        v.Status = $"Duplicate property name {v.PropertyName}";
                        v.HasConfigError = true;
                        continue;
                    }
                    byProp[v.PropertyName] = v;
                }
            }

            lock (_sync)
            {
                // carry over open process handles
                foreach (var old in _profiles)
                {
                    var match = built.FirstOrDefault(n => n.Memory == null && n.Remote == null && n.Active &&
                        string.Equals(n.Def.ProcessName, old.Def.ProcessName, StringComparison.OrdinalIgnoreCase));
                    if (match != null && old.Memory != null && !old.Memory.HasExited)
                    {
                        match.Memory = old.Memory; match.SrcCtx.Memory = old.Memory;
                        match.Connected = true; match.Status = old.Status;
                        match.Clock.Start();
                        old.Memory = null;
                    }
                    else if (match != null && old.Remote != null)
                    {
                        // Keep the helper running and send it the edited rows.
                        match.Remote = old.Remote; match.SrcCtx.Remote = old.Remote;
                        match.Connected = old.Connected; match.Status = old.Status;
                        if (old.Connected) match.Clock.Start();
                        match.Remote.SetPlan(match.Plan);
                        old.Remote = null; old.SrcCtx.Remote = null;
                    }
                    old.Memory?.Dispose();
                    DisposeRemote(old);
                }
                _profiles = built;
                _byProperty = byProp;
                _byConnectedProp = byConn;
            }

            var names = byProp.Where(kv => kv.Value.Def.Enabled).Select(kv => kv.Key)
                .Concat(byConn.Keys).ToList();
            PropertiesChanged?.Invoke(names);
        }

        ProfileState Build(GameProfile def)
        {
            var ps = new ProfileState
            {
                Def = def,
                Prefix = _sanitise ? Names.Sanitise(def.Prefix) : def.Prefix,
            };
            var vars = def.Variables.Select((v, i) => new VarState
            {
                Def = v,
                Slot = i,
                PropertyName = Names.PropertyName(def, v, _sanitise),
            }).ToArray();

            var slotByName = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var vs in vars)
            {
                var key = Names.Sanitise(vs.Def.Name);
                if (Formula.IsReservedName(key) ||
                    key.Equals("Connected", StringComparison.OrdinalIgnoreCase))
                {
                    Fail(vs, $"'{vs.Def.Name}' is a reserved name");
                    continue;
                }
                if (slotByName.ContainsKey(key)) { Fail(vs, $"Another variable is already called '{vs.Def.Name}'"); continue; }
                slotByName[key] = vs.Slot;
            }

            foreach (var vs in vars)
            {
                if (vs.HasConfigError) continue;
                try { vs.Source = SourceFactory(vs.Def); }
                catch (Exception e) { Fail(vs, e.Message); continue; }

                var f = (vs.Def.Formula ?? "").Trim();
                if (f.Length > 0)
                {
                    try
                    {
                        vs.Formula = Formula.Compile(f, n => slotByName.TryGetValue(Names.Sanitise(n), out var s) ? s : (int?)null);
                        if (vs.Formula.Dependencies.Contains(vs.Slot))
                            Fail(vs, "Formula refers to itself; use prev(), ema() etc. instead");
                        else if (vs.Def.Source == SourceKind.Computed && vs.Formula.UsesValue)
                            Fail(vs, "Computed variables have no 'value'; refer to other variables by name");
                    }
                    catch (FormulaException e) { Fail(vs, "Formula: " + e.Message); }
                }
                else if (vs.Def.Source == SourceKind.Computed) Fail(vs, "Computed variable needs a formula");
            }

            ps.Vars = vars;
            ps.Order = TopoOrder(vars);
            ps.Plan = new Remote.ReadPlan { ProcessName = def.ProcessName ?? "", PollHz = _pollHz };
            foreach (var vs in vars)
            {
                if (vs.HasConfigError || !(vs.Source is MemorySource ms)) continue;
                if (ps.Plan.Rows.Count >= Remote.ReadPlan.MaxRows) continue; // PlanSlot stays -1; the row says why
                ms.PlanSlot = ps.Plan.Rows.Count;
                ps.Plan.Rows.Add(ms.ToPlanRow());
            }
            ps.Slots = Enumerable.Repeat(double.NaN, vars.Length).ToArray();
            ps.Ctx.Slots = ps.Slots;
            ps.Ctx.Ffb = _ffb;
            ps.Ctx.Tp = _tp;
            ps.Ctx.Output = n => OutputSource?.Invoke(n) ?? double.NaN;
            ps.Ctx.MaxSpeed = GameProfile.Reference(def.MaxSpeed);
            ps.Ctx.MaxRevs = GameProfile.Reference(def.MaxRevs);
            ps.Active = def.Enabled && (_activeGame == "" || string.Equals(_activeGame, ps.Prefix, StringComparison.OrdinalIgnoreCase));
            ps.Status = !def.Enabled ? "Disabled"
                : !ps.Active ? (_activeGame == PluginSettings.NoGame ? "Not reading: no game is active" : $"Not reading: the active game is {_activeGame}")
                : "Waiting for " + (string.IsNullOrWhiteSpace(def.ProcessName) ? "(no process set)" : def.ProcessName);
            return ps;
        }

        static void Fail(VarState v, string msg) { v.Status = msg; v.HasConfigError = true; v.Formula = null; }

        /// <summary>Dependency order; variables in a cycle get an error and are left out.</summary>
        static int[] TopoOrder(VarState[] vars)
        {
            var order = new List<int>();
            var mark = new int[vars.Length]; // 0 new, 1 visiting, 2 done, 3 cyclic
            bool Visit(int i)
            {
                if (mark[i] == 2) return true;
                if (mark[i] == 1 || mark[i] == 3) return false;
                mark[i] = 1;
                bool ok = true;
                var deps = vars[i].Formula?.Dependencies ?? (IReadOnlyCollection<int>)new int[0];
                foreach (var d in deps)
                {
                    if (vars[d].HasConfigError) { ok = false; continue; }
                    if (!Visit(d)) ok = false;
                }
                if (!ok)
                {
                    mark[i] = 3;
                    if (!vars[i].HasConfigError) Fail(vars[i], "Depends on a variable with an error, or a circular reference");
                    return false;
                }
                mark[i] = 2; order.Add(i);
                return true;
            }
            for (int i = 0; i < vars.Length; i++) if (!vars[i].HasConfigError) Visit(i);
            return order.ToArray();
        }

        /// <summary>Value for a SimHub property delegate. Null for unknown or disabled variables
        /// (e.g. after a rename, until SimHub restarts); 0 while the game isn't running.</summary>
        public object GetPropertyValue(string propertyName)
        {
            var map = _byProperty;
            if (map.TryGetValue(propertyName, out var v))
            {
                if (!v.Def.Enabled) return null;
                var o = v.Output;
                return double.IsNaN(o) || double.IsInfinity(o) ? 0.0 : o;
            }
            if (_byConnectedProp.TryGetValue(propertyName, out var p)) return p.Connected;
            return null;
        }

        public string ActiveGamePrefix
        {
            get { foreach (var p in _profiles) if (p.Connected) return p.Prefix; return ""; }
        }

        #region Polling
        public void Start()
        {
            if (_running) return;
            _running = true;
            _thread = new Thread(Run) { IsBackground = true, Name = "TPTelemetry poll" };
            _thread.Start();
        }

        public void Stop()
        {
            _running = false;
            _thread?.Join(2000);
            _thread = null;
        }

        void Run()
        {
            bool timerRes = false;
            try { timerRes = timeBeginPeriod(1) == 0; } catch { /* not on Windows */ }
            var sw = Stopwatch.StartNew();
            double next = 0;
            try
            {
                while (_running)
                {
                    double period = 1000.0 / _pollHz;

                    // Looking for the game process can be slow (it enumerates every process),
                    // so it happens outside the lock and never holds up the settings page.
                    try
                    {
                        var src = FfbSource;
                        if (src != null)
                        {
                            src(_ffb);
                            for (int i = 0; i < _ffb.Length; i++) Interlocked.Exchange(ref _ffbPublished[i], _ffb[i]);
                        }
                    }
                    catch (Exception e) { Log.Error("FFB snapshot", e); FfbSource = null; }

                    try
                    {
                        var tps = TpSource;
                        if (tps != null)
                        {
                            tps(_tp);
                            for (int i = 0; i < _tp.Length; i++) Interlocked.Exchange(ref _tpPublished[i], _tp[i]);
                        }
                    }
                    catch (Exception e) { Log.Error("TeknoParrot snapshot", e); TpSource = null; }

                    foreach (var p in _profiles)
                    {
                        try { TryAttach(p, _attachClock.ElapsedMilliseconds); }
                        catch (Exception e) { p.Status = "Error: " + e.Message; }
                    }

                    lock (_sync)
                    {
                        foreach (var p in _profiles)
                        {
                            try { Tick(p); }
                            catch (Exception e)
                            {
                                if (p.Status != "Error: " + e.Message) Log.Error("Tick " + p.Prefix, e);
                                p.Status = "Error: " + e.Message;
                            }
                        }
                        try { Common.Update(_profiles.FirstOrDefault(p => p.Active), sw.Elapsed.TotalSeconds); }
                        catch (Exception e) { Log.Error("Common values", e); }
                    }

                    WriteRecording();

                    // Sleep (with 1 ms timer resolution) rather than spin, so the thread costs
                    // next to no CPU. Jitter of a millisecond or so doesn't matter: every sample
                    // carries its own timestamp.
                    next += period;
                    var now = sw.Elapsed.TotalMilliseconds;
                    if (next < now - period * 5) next = now; // fell behind (e.g. debugger); don't burst
                    var wait = next - now;
                    Thread.Sleep(wait >= 1 ? (int)wait : 0);
                }
            }
            finally
            {
                if (timerRes) try { timeEndPeriod(1); } catch { }
            }
        }

        /// <summary>Called outside the lock. Opens the game process when it's due.</summary>
        internal void TryAttach(ProfileState p, long nowMs)
        {
            if (p.Active && p.Memory != null && p.Def.Source() == ProfileSource.Process) CheckNewerProcess(p, nowMs);
            if (!p.Active || p.Memory != null || p.Remote != null || p.Def.Source() != ProfileSource.Process) return;
            if (nowMs < p.NextAttachMs) return;
            p.NextAttachMs = nowMs + 1000;

            ProcessMemory pm;
            try { pm = ProcessOpener(p.Def.ProcessName); }
            catch (Target64BitException e) when (RemoteMemoryFactory != null)
            {
                StartRemote(p, e.Pid);
                return;
            }
            catch (Exception e)
            {
                if (p.Status != e.Message) Log.Error("Attach " + p.Def.ProcessName, e);
                p.Status = e.Message;
                return;
            }
            if (pm == null) { p.Status = "Waiting for " + p.Def.ProcessName; return; }

            lock (_sync)
            {
                // The profile may have been replaced by a settings change meanwhile.
                if (Array.IndexOf(_profiles, p) < 0 || p.Memory != null) { pm.Dispose(); return; }
                p.Memory = pm; p.SrcCtx.Memory = pm;
                p.Connected = true;
                p.Status = $"Attached to {p.Def.ProcessName} (PID {pm.Pid}, {(pm.Is32Bit ? "32" : "64")}-bit)";
                KeepClock(p);
            }
            Log.Info(p.Status);
        }

        /// <summary>Called outside the lock. If a newer process with the game's name has started since this profile
        /// attached (Alexis, 10 November 2026: Battle Gear 4 left a stopped game.exe behind, and the next race was read
        /// from it, frozen), lets go of the old one so the next attach takes the newest.</summary>
        void CheckNewerProcess(ProfileState p, long nowMs)
        {
            if (nowMs < p.NextNewerCheckMs) return;
            p.NextNewerCheckMs = nowMs + NewerProcessCheckMs;
            int? newest;
            try { newest = NewestProcess?.Invoke(p.Def.ProcessName); }
            catch (Exception) { return; }
            var old = p.Memory;
            if (newest == null || old == null || newest.Value == old.Pid) return;
            lock (_sync)
            {
                if (p.Memory != old) return;
                p.Memory = null; p.SrcCtx.Memory = null;
                Detach(p, $"A newer {p.Def.ProcessName} started (PID {newest.Value}); moving to it");
            }
            old.Dispose();
            p.NextAttachMs = 0;
            Log.Info($"{p.Def.ProcessName}: PID {old.Pid} replaced by the newer PID {newest.Value}");
        }

        /// <summary>Called outside the lock. Starts a helper for a 64-bit game; it connects in the background.</summary>
        void StartRemote(ProfileState p, int pid)
        {
            Remote.IRemoteMemory r;
            try
            {
                r = RemoteMemoryFactory();
                r.Start(p.Plan.WithTarget(pid, 0));
            }
            catch (Exception e)
            {
                p.Status = "64-bit helper: " + e.Message;
                Log.Error("Starting the 64-bit helper", e);
                p.NextAttachMs += RemoteRetryMs;
                return;
            }
            lock (_sync)
            {
                if (Array.IndexOf(_profiles, p) < 0 || p.Remote != null) { DisposeAsync(r); return; }
                p.Remote = r; p.SrcCtx.Remote = r;
                p.Status = $"Starting the 64-bit helper for {p.Def.ProcessName} (PID {pid})";
            }
            Log.Info(p.Status);
        }

        /// <summary>Called by Tick, inside the lock. Returns true when the game can be read this tick.</summary>
        bool TickRemote(ProfileState p)
        {
            var r = p.Remote;
            var state = r.Poll();
            switch (state)
            {
                case Remote.RemoteState.Running:
                    if (!p.Connected)
                    {
                        p.Connected = true;
                        p.Status = $"Attached to {p.Def.ProcessName} (PID {r.GamePid}, 64-bit, through {Remote.HelperLauncher.ExeName})";
                        KeepClock(p);
                        Log.Info(p.Status);
                    }
                    return true;

                case Remote.RemoteState.Starting:
                    if (p.Connected) Detach(p, r.Message);
                    else p.Status = r.Message;
                    return false;

                case Remote.RemoteState.GameExited:
                    DisposeRemote(p);
                    Detach(p, "Game exited; waiting for " + p.Def.ProcessName);
                    Log.Info(p.Def.ProcessName + " exited (64-bit helper)");
                    return false;

                default: // Failed
                    var why = string.IsNullOrEmpty(r.Message) ? "64-bit helper failed" : r.Message;
                    DisposeRemote(p);
                    Detach(p, why + $" (trying again in {RemoteRetryMs / 1000} s)");
                    Log.Info("64-bit helper for " + p.Def.ProcessName + ": " + why);
                    p.NextAttachMs = _attachClock.ElapsedMilliseconds + RemoteRetryMs;
                    return false;
            }
        }

        static void DisposeRemote(ProfileState p)
        {
            var r = p.Remote;
            p.Remote = null; p.SrcCtx.Remote = null;
            if (r != null) DisposeAsync(r);
        }

        /// <summary>Stopping the helper can take a moment; never hold up the poll thread for it.</summary>
        static void DisposeAsync(IDisposable d) =>
            ThreadPool.QueueUserWorkItem(_ => { try { d.Dispose(); } catch (Exception e) { Log.Error("Stopping the 64-bit helper", e); } });

        internal void Tick(ProfileState p)
        {
            if (!p.Active) { p.Connected = false; return; }

            if (p.Remote != null)
            {
                if (TickRemote(p)) EvaluateTick(p, p.Clock.Elapsed.TotalSeconds);
                else EvaluateWaiting(p);
                return;
            }

            if (p.Memory != null && p.Memory.HasExited)
            {
                p.Memory.Dispose(); p.Memory = null; p.SrcCtx.Memory = null;
                Detach(p, "Game exited; waiting for " + p.Def.ProcessName);
                Log.Info(p.Def.ProcessName + " exited");
            }

            if (p.Memory == null && p.Def.Source() == ProfileSource.Process) { EvaluateWaiting(p); return; }
            else if (p.Def.Source() == ProfileSource.None && !p.Connected)
            {
                p.Connected = true; p.Clock.Restart(); p.Status = "Running (no process)";
            }

            EvaluateTick(p, p.Clock.Elapsed.TotalSeconds);
        }

        /// <summary>The game isn't attached (yet): rows that don't need its memory (TeknoParrot, outputs,
        /// USB capture, formulas on those) keep updating; memory rows read blank and say why.
        /// Connected stays false.</summary>
        static void EvaluateWaiting(ProfileState p)
        {
            if (!p.Clock.IsRunning) p.Clock.Start();
            EvaluateTick(p, p.Clock.Elapsed.TotalSeconds);
        }

        /// <summary>On attaching, the profile's clock carries on from the waiting ticks (0.17.2). Restarting it at 0 left
        /// the windows (maxw, minw, slope, avg) holding samples stamped later than the new time, so they never let go of
        /// them until the clock caught up: a hit or shift row stuck at 1, accel_g frozen, for as long as the game was
        /// waited for (seen in an ID6 recording, 9 November 2026).</summary>
        static void KeepClock(ProfileState p)
        {
            if (!p.Clock.IsRunning) p.Clock.Start();
        }

        /// <summary>Starts every formula's time-series state again (windows, ema, prev, hold...).</summary>
        static void RestartSeries(ProfileState p)
        {
            foreach (var v in p.Vars)
                if (v.Formula != null) v.Formula = Formula.Compile(v.Formula.Source, ReSlot(p));
        }

        /// <summary>One sample: read every raw value, then evaluate formulas in dependency order.</summary>
        internal static void EvaluateTick(ProfileState p, double t)
        {
            var ctx = p.Ctx;
            // Time must never run backwards inside the formulas' windows: if it does (the clock was reset), start them again.
            if (p.TickCount > 0 && t < p.LastT)
            {
                RestartSeries(p);
                p.TickCount = 0; p.RateWindowStart = t; p.RateWindowTicks = 0;
            }
            ctx.T = t;
            ctx.Dt = p.TickCount == 0 ? 0 : Math.Max(0, t - p.LastT);
            p.LastT = t;
            p.TickCount++;
            if (t - p.RateWindowStart >= 1)
            {
                p.SampleRateHz = (p.TickCount - p.RateWindowTicks) / (t - p.RateWindowStart);
                p.RateWindowStart = t;
                p.RateWindowTicks = p.TickCount;
            }

            foreach (var v in p.Vars)
            {
                if (v.HasConfigError || v.Source == null) { v.Raw = double.NaN; continue; }
                double raw; string status; bool ok;
                try { ok = v.Source.TryRead(p.SrcCtx, out raw, out status); }
                catch (Exception e) { ok = false; raw = double.NaN; status = "Read error: " + e.Message; }
                if (ok)
                {
                    v.Raw = raw;
                    if (status != null) v.Status = status;
                    else if (v.Def.Source == SourceKind.Computed) v.Status = "OK";
                }
                else { v.Raw = double.NaN; v.Status = status; }
            }

            for (int i = 0; i < p.Slots.Length; i++) p.Slots[i] = double.NaN;
            foreach (var idx in p.Order)
            {
                var v = p.Vars[idx];
                double o;
                if (v.Formula != null)
                {
                    ctx.Value = v.Raw;
                    try { o = v.Formula.Evaluate(ctx); }
                    catch (Exception e) { o = double.NaN; v.Status = "Formula: " + e.Message; }
                    if (v.Formula.UsesFfb)
                        v.Status = ctx.Ffb != null && ctx.Ffb[Ffb.FfbChannels.Connected] == 1
                            ? (double.IsNaN(o) ? "No value yet: no FFB commands decoded (wheel's decoder set to Raw?)" : "OK")
                            : NoFfb;
                    else if (v.Formula.UsesTp && !(ctx.Tp != null && ctx.Tp[TeknoParrot.TpChannels.Connected] == 1))
                        v.Status = NoTp;
                    else if (v.Formula.OutputNames.Count > 0 && double.IsNaN(o))
                    {
                        var missing = v.Formula.OutputNames.FirstOrDefault(n => double.IsNaN(ctx.Output?.Invoke(n) ?? double.NaN));
                        if (missing != null) v.Status = $"No output '{missing}' yet: is the game sending outputs? (see Capture table values and FFB, and Game_Outputs.md)";
                    }
                }
                else o = v.Raw;
                p.Slots[idx] = o;
                v.Output = o;
            }
        }

        static void Detach(ProfileState p, string status)
        {
            p.Connected = false;
            p.Status = status;
            p.Clock.Reset();
            foreach (var v in p.Vars) { v.Raw = double.NaN; v.Output = double.NaN; }
            // restart time-series state on next attach
            RestartSeries(p);
            p.LastT = 0; p.TickCount = 0; p.RateWindowStart = 0; p.RateWindowTicks = 0;
        }

        internal const string NoTp = "No TeknoParrot data: TeknoParrot's shared memory isn't available (is TeknoParrot running? See Capture table values and FFB)";
        internal const string NoFfb = "No force feedback data: switch on USB capture in 'Capture table values and FFB' below the table, and check its status line (USB_Capture.md)";

        static Func<string, int?> ReSlot(ProfileState p)
        {
            var map = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var v in p.Vars) map[Names.Sanitise(v.Def.Name)] = v.Slot;
            return n => map.TryGetValue(Names.Sanitise(n), out var s) ? s : (int?)null;
        }

        [DllImport("winmm.dll")] static extern uint timeBeginPeriod(uint ms);
        [DllImport("winmm.dll")] static extern uint timeEndPeriod(uint ms);
        #endregion

        public void Dispose()
        {
            Stop();
            StopRecording();
            lock (_sync)
            {
                foreach (var p in _profiles)
                {
                    p.Memory?.Dispose();
                    var r = p.Remote; p.Remote = null;
                    try { r?.Dispose(); } catch (Exception e) { Log.Error("Stopping the 64-bit helper", e); }
                }
                _profiles = new ProfileState[0];
            }
        }
    }

    enum ProfileSource { Process, None }

    static class ProfileExt
    {
        /// <summary>A profile with no process (like the dummy) runs without attaching to anything:
        /// formulas keep updating, and memory rows report that there's no process to read.</summary>
        public static ProfileSource Source(this GameProfile p) =>
            string.IsNullOrWhiteSpace(p.ProcessName) ? ProfileSource.None : ProfileSource.Process;
    }
}
