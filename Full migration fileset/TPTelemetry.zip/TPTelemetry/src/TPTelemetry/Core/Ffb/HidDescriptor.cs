using System;
using System.Collections.Generic;
using System.Linq;

namespace TeknoTelemetry.Core.Ffb
{
    /// <summary>One data field of a HID report, from the device's report descriptor.</summary>
    public sealed class HidField
    {
        public int ReportId;
        /// <summary>Bit position from the start of the report data (after the report ID byte, when there is one).</summary>
        public int BitOffset;
        public int BitSize, Count;
        public long LogicalMin, LogicalMax;
        /// <summary>An array field holds indexes into <see cref="Usages"/> (logical minimum = the first); a variable
        /// field holds one value per usage.</summary>
        public bool IsArray, IsConstant;
        /// <summary>Full usages (page &lt;&lt; 16 | id), one per element for variables, the selectable list for arrays.</summary>
        public List<uint> Usages = new List<uint>();
        /// <summary>Usages of the collections the field sits in, outermost first.</summary>
        public uint[] Collections = new uint[0];
    }

    /// <summary>
    /// A HID report descriptor, parsed into the fields of its output reports (the ones the host sends,
    /// where force feedback commands go). Follows the HID 1.11 item rules: global items carry over,
    /// local items reset after each main item, Push/Pop save the globals.
    /// </summary>
    public sealed class HidReportLayout
    {
        public readonly List<HidField> Output = new List<HidField>();
        public bool UsesReportIds { get; private set; }

        public IEnumerable<HidField> FieldsOf(int reportId) => Output.Where(f => f.ReportId == reportId);

        sealed class Globals
        {
            public uint Page; public long LogMin, LogMax; public int Size, Count, ReportId;
            public Globals Clone() => (Globals)MemberwiseClone();
        }

        public static HidReportLayout Parse(byte[] d)
        {
            var layout = new HidReportLayout();
            var g = new Globals();
            var stack = new Stack<Globals>();
            var usages = new List<uint>();
            uint? usageMin = null;
            var collections = new List<uint>();
            var bitPos = new Dictionary<int, int>();   // output bit position per report ID
            int i = 0;
            while (i < d.Length)
            {
                byte prefix = d[i++];
                if (prefix == 0xFE) // long item: skip it
                {
                    if (i + 1 >= d.Length) break;
                    i += 2 + d[i];
                    continue;
                }
                int size = prefix & 3; if (size == 3) size = 4;
                int type = (prefix >> 2) & 3, tag = prefix >> 4;
                if (i + size > d.Length) break;
                uint u = 0; for (int k = 0; k < size; k++) u |= (uint)d[i + k] << (8 * k);
                long s = size == 1 ? (sbyte)u : size == 2 ? (short)u : size == 4 ? (int)u : 0;
                i += size;
                switch (type)
                {
                    case 0: // main
                        switch (tag)
                        {
                            case 0x8: case 0xB: // input, feature: no output fields, but locals reset
                                break;
                            case 0x9: // output
                            {
                                if (g.ReportId != 0) layout.UsesReportIds = true;
                                bitPos.TryGetValue(g.ReportId, out int pos);
                                bool isConst = (u & 1) != 0, isVar = (u & 2) != 0;
                                var f = new HidField
                                {
                                    ReportId = g.ReportId, BitOffset = pos, BitSize = g.Size, Count = g.Count,
                                    LogicalMin = g.LogMin, LogicalMax = g.LogMax, IsArray = !isVar, IsConstant = isConst,
                                    Collections = collections.ToArray(),
                                };
                                f.Usages.AddRange(usages);
                                if (!isConst) layout.Output.Add(f);
                                bitPos[g.ReportId] = pos + g.Size * g.Count;
                                break;
                            }
                            case 0xA: // collection
                                collections.Add(usages.Count > 0 ? usages[0] : 0);
                                break;
                            case 0xC: // end collection
                                if (collections.Count > 0) collections.RemoveAt(collections.Count - 1);
                                break;
                        }
                        usages = new List<uint>(); usageMin = null;
                        break;
                    case 1: // global
                        switch (tag)
                        {
                            case 0x0: g.Page = u; break;
                            case 0x1: g.LogMin = s; break;
                            case 0x2: g.LogMax = s; break;
                            case 0x7: g.Size = (int)u; break;
                            case 0x8: g.ReportId = (int)u; break;
                            case 0x9: g.Count = (int)u; break;
                            case 0xA: stack.Push(g.Clone()); break;
                            case 0xB: if (stack.Count > 0) g = stack.Pop(); break;
                        }
                        break;
                    case 2: // local
                        uint Full(uint v) => size == 4 ? v : (g.Page << 16) | v;
                        switch (tag)
                        {
                            case 0x0: usages.Add(Full(u)); break;
                            case 0x1: usageMin = Full(u); break;
                            case 0x2:
                                if (usageMin.HasValue)
                                    for (uint x = usageMin.Value; x <= Full(u) && usages.Count < 4096; x++) usages.Add(x);
                                usageMin = null;
                                break;
                        }
                        break;
                }
            }
            // A logical maximum written in fewer bytes than it needs reads negative (0xFF as -1): treat such a
            // range as unsigned, as Windows and Linux do.
            foreach (var f in layout.Output)
                if (f.LogicalMax < f.LogicalMin) f.LogicalMax = (long)((ulong)f.LogicalMax & ((1UL << Math.Min(32, Math.Max(1, f.BitSize))) - 1));
            return layout;
        }

        /// <summary>Reads one element of a field from a report as sent (report ID byte first when the
        /// descriptor uses report IDs). Signed when the logical minimum is negative.</summary>
        public long Read(HidField f, int index, byte[] report)
        {
            int start = (UsesReportIds ? 8 : 0) + f.BitOffset + index * f.BitSize;
            ulong v = 0;
            for (int b = 0; b < f.BitSize; b++)
            {
                int bit = start + b, byteAt = bit >> 3;
                if (byteAt >= report.Length) break;
                if ((report[byteAt] >> (bit & 7) & 1) != 0) v |= 1UL << b;
            }
            if (f.LogicalMin < 0 && f.BitSize > 0 && f.BitSize < 64 && (v & (1UL << (f.BitSize - 1))) != 0)
                return (long)(v | ~((1UL << f.BitSize) - 1));
            return (long)v;
        }
    }
}
