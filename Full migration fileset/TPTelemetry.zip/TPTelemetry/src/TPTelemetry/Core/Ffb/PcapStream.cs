using System;
using System.Collections.Generic;
using System.IO;

namespace TeknoTelemetry.Core.Ffb
{
    /// <summary>One USB transfer from a USBPcap capture.</summary>
    public sealed class UsbPacket
    {
        public double Time;          // seconds, capture clock
        public bool FromDevice;      // USBPcap "info" bit 0: completion travelling device -> host
        public int Bus, Device;
        public byte Endpoint;        // bit 7 set = IN endpoint
        public byte Transfer;        // 0 isochronous, 1 interrupt, 2 control, 3 bulk
        public int Stage = -1;       // control transfers: 0 setup, 1 data, 2 status, 3 complete (-1 for others)
        public byte[] Payload;
        public byte[] Record;        // the whole capture record, for re-recording

        /// <summary>Data the host sent to the device (what FFB commands are).</summary>
        public bool IsHostToDeviceData => !FromDevice && (Endpoint & 0x80) == 0 && Payload.Length > 0;
    }

    /// <summary>
    /// Reads a USBPcap capture from a stream as it arrives: classic pcap (what USBPcapCMD writes)
    /// or pcapng (what Wireshark saves). Link type 249, LINKTYPE_USBPCAP.
    /// </summary>
    public sealed class PcapStreamReader
    {
        const uint PcapMagic = 0xA1B2C3D4, PcapMagicNs = 0xA1B23C4D, NgSectionHeader = 0x0A0D0D0A;
        readonly Stream _s;
        bool _ng, _swap, _nanos;
        readonly List<int> _ngLinkTypes = new List<int>();
        readonly List<double> _ngTsUnit = new List<double>();
        int _linkType;

        /// <summary>The file header (pcap) or section and interface blocks (pcapng), so a
        /// recording can start mid-stream and still be a valid file.</summary>
        public byte[] Preamble { get; private set; } = new byte[0];
        public bool IsPcapNg => _ng;

        public PcapStreamReader(Stream s) { _s = s; }

        public void ReadHeader()
        {
            var magicBytes = ReadExactly(4);
            var magic = BitConverter.ToUInt32(magicBytes, 0);
            if (magic == NgSectionHeader)
            {
                _ng = true;
                var rest = ReadNgBlockAfterType(magicBytes);
                Preamble = rest;
                return;
            }
            if (magic == PcapMagic || magic == PcapMagicNs) _swap = false;
            else if (Swap(magic) == PcapMagic || Swap(magic) == PcapMagicNs) { _swap = true; magic = Swap(magic); }
            else throw new InvalidDataException("Not a pcap or pcapng stream");
            _nanos = magic == PcapMagicNs;
            var hdr = ReadExactly(20);
            _linkType = (int)U32(hdr, 16);
            var pre = new byte[24];
            Buffer.BlockCopy(magicBytes, 0, pre, 0, 4); Buffer.BlockCopy(hdr, 0, pre, 4, 20);
            Preamble = pre;
            if (_linkType != 249) throw new InvalidDataException($"Capture link type {_linkType}, expected USBPcap (249)");
        }

        /// <summary>Next USB packet, or null at end of stream.</summary>
        public UsbPacket Next()
        {
            while (true)
            {
                if (_ng)
                {
                    var typeBytes = TryRead(4);
                    if (typeBytes == null) return null;
                    var block = ReadNgBlockAfterType(typeBytes);
                    var p = ParseNgBlock(block);
                    if (p != null) return p;
                }
                else
                {
                    var rh = TryRead(16);
                    if (rh == null) return null;
                    uint sec = U32(rh, 0), frac = U32(rh, 4), incl = U32(rh, 8);
                    if (incl > 16 * 1024 * 1024) throw new InvalidDataException("Corrupt capture record");
                    var data = ReadExactly((int)incl);
                    var rec = new byte[16 + incl];
                    Buffer.BlockCopy(rh, 0, rec, 0, 16); Buffer.BlockCopy(data, 0, rec, 16, (int)incl);
                    var p = ParseUsb(data, sec + frac * (_nanos ? 1e-9 : 1e-6), rec);
                    if (p != null) return p;
                }
            }
        }

        byte[] ReadNgBlockAfterType(byte[] typeBytes)
        {
            var lenBytes = ReadExactly(4);
            if (BitConverter.ToUInt32(typeBytes, 0) == NgSectionHeader)
            {
                // byte order is given by the magic that follows
                var bom = ReadExactly(4);
                _swap = BitConverter.ToUInt32(bom, 0) != 0x1A2B3C4D;
                var len = (int)U32(lenBytes, 0);
                var body = ReadExactly(len - 12);
                var blk = Concat(typeBytes, lenBytes, bom, body);
                _ngLinkTypes.Clear(); _ngTsUnit.Clear();
                return blk;
            }
            var blen = (int)U32(lenBytes, 0);
            if (blen < 12 || blen > 16 * 1024 * 1024) throw new InvalidDataException("Corrupt pcapng block");
            var rest = ReadExactly(blen - 8);
            return Concat(typeBytes, lenBytes, rest);
        }

        UsbPacket ParseNgBlock(byte[] b)
        {
            uint type = U32(b, 0);
            if (type == NgSectionHeader) { Preamble = b; return null; }
            if (type == 1) // interface description
            {
                _ngLinkTypes.Add(U16(b, 8));
                double unit = 1e-6;
                int j = 16;
                while (j + 4 <= b.Length - 4)
                {
                    int code = U16(b, j), ln = U16(b, j + 2);
                    if (code == 0) break;
                    if (code == 9 && ln >= 1)
                    {
                        int v = b[j + 4];
                        unit = (v & 0x80) != 0 ? Math.Pow(2, -(v & 0x7f)) : Math.Pow(10, -v);
                    }
                    j += 4 + ((ln + 3) & ~3);
                }
                _ngTsUnit.Add(unit);
                Preamble = Concat(Preamble, b);
                return null;
            }
            if (type == 6) // enhanced packet
            {
                int iface = (int)U32(b, 8);
                if (iface >= _ngLinkTypes.Count || _ngLinkTypes[iface] != 249) return null;
                ulong ts = ((ulong)U32(b, 12) << 32) | U32(b, 16);
                int cap = (int)U32(b, 20);
                var data = new byte[cap];
                Buffer.BlockCopy(b, 28, data, 0, cap);
                return ParseUsb(data, ts * _ngTsUnit[iface], b);
            }
            return null;
        }

        static UsbPacket ParseUsb(byte[] d, double t, byte[] record)
        {
            if (d.Length < 27) return null;
            int hl = BitConverter.ToUInt16(d, 0);
            int dlen = (int)BitConverter.ToUInt32(d, 23);
            if (hl < 27 || hl > d.Length) return null;
            dlen = Math.Max(0, Math.Min(dlen, d.Length - hl));
            var payload = new byte[dlen];
            Buffer.BlockCopy(d, hl, payload, 0, dlen);
            return new UsbPacket
            {
                Time = t,
                FromDevice = (d[16] & 1) != 0,
                Bus = BitConverter.ToUInt16(d, 17),
                Device = BitConverter.ToUInt16(d, 19),
                Endpoint = d[21],
                Transfer = d[22],
                Stage = d[22] == 2 && hl >= 28 ? d[27] : -1,
                Payload = payload,
                Record = record,
            };
        }

        uint U32(byte[] b, int o) { var v = BitConverter.ToUInt32(b, o); return _swap ? Swap(v) : v; }
        int U16(byte[] b, int o) { var v = BitConverter.ToUInt16(b, o); return _swap ? (ushort)((v >> 8) | (v << 8)) : v; }
        static uint Swap(uint v) => (v >> 24) | ((v >> 8) & 0xff00) | ((v << 8) & 0xff0000) | (v << 24);

        static byte[] Concat(params byte[][] parts)
        {
            int n = 0; foreach (var p in parts) n += p.Length;
            var r = new byte[n]; int o = 0;
            foreach (var p in parts) { Buffer.BlockCopy(p, 0, r, o, p.Length); o += p.Length; }
            return r;
        }

        byte[] TryRead(int n)
        {
            var buf = new byte[n]; int got = 0;
            while (got < n)
            {
                int r = _s.Read(buf, got, n - got);
                if (r <= 0) { if (got == 0) return null; throw new EndOfStreamException(); }
                got += r;
            }
            return buf;
        }

        byte[] ReadExactly(int n) => TryRead(n) ?? throw new EndOfStreamException();
    }
}
