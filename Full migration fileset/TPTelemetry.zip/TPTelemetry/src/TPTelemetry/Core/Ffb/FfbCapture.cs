using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace TeknoTelemetry.Core.Ffb
{
    /// <summary>Saved FFB settings (part of the plugin settings).</summary>
    public class FfbSettings
    {
        public bool Enabled { get; set; }
        /// <summary>USBPcap root hub, e.g. \\.\USBPcap1.</summary>
        public string Interface { get; set; } = "";
        /// <summary>USB device address on that hub, as Wireshark shows it in [brackets].</summary>
        public int Device { get; set; }
        /// <summary>What USBPcap calls the device, e.g. "[16] Logitech G25 Racing Wheel USB". The name (without
        /// the [address]) is how the plugin finds the wheel again when Windows gives it a new address (0.16.0).</summary>
        public string DeviceName { get; set; } = "";
        /// <summary>USB vendor and product IDs, learnt from the device when capture starts (0 = not yet).
        /// The FFB plugin's DeviceGUID (SDL's joystick GUID) is made from the same IDs.</summary>
        public int VendorId { get; set; }
        public int ProductId { get; set; }
        public FfbDecoderChoice Decoder { get; set; } = FfbDecoderChoice.Auto;
        /// <summary>Leave empty to find USBPcapCMD.exe automatically.</summary>
        public string UsbPcapCmdPath { get; set; } = "";
        /// <summary>Work out the force-based common values (Car_impact, Car_road_bump, Car_cornering,
        /// Car_vibration) from the captured wheel force for games that have no rows for them (0.15.0).</summary>
        public bool UseForCommonValues { get; set; } = true;
    }

    public sealed class UsbDeviceChoice
    {
        public string Interface, Display;
        public int Device;
        public string Label => FfbCapture.DeviceLabel(Display);
        public override string ToString() => $"{Display}  ({Interface.Replace(@"\\.\", "")})";
    }

    /// <summary>
    /// Runs USBPcapCMD (from the USBPcap driver, also installed by Wireshark) to capture what is sent
    /// to one USB device, and decodes it into FFB channels. Needs administrator rights, like the
    /// driver itself.
    /// </summary>
    public sealed class FfbCapture : IDisposable
    {
        readonly object _sync = new object();
        Process _proc;
        Thread _reader;
        FfbPipeline _pipe;
        FfbSettings _running;
        volatile bool _stopping;
        volatile string _status = "Off";
        volatile bool _connected;
        ChildProcessJob _job;

        // Keeping the wheel (0.16.0): what the user chose, a watchdog that (re)starts capture, and the
        // device found again by name when Windows gives it a new USB address.
        FfbSettings _wanted;
        Timer _watch;
        int _checking;
        DateTime _nextTry = DateTime.MinValue, _nextLook = DateTime.MinValue, _connectedSince = DateTime.MaxValue;
        int _failures;
        long _lastPacketTicks;
        bool _verified;            // the address came from a device list (not just the saved settings)
        string _avoid;             // "hub|address" that turned out to be a different device
        static readonly System.Diagnostics.Stopwatch Clock = System.Diagnostics.Stopwatch.StartNew();

        /// <summary>Raised (on a background thread) when the device's address, name or IDs change, so the
        /// settings can be saved. Carries a copy of the settings capture is now using.</summary>
        public event Action<FfbSettings> DeviceChanged;

        /// <summary>How the watchdog lists devices; tests can replace it.</summary>
        public Func<string, Tuple<List<UsbDeviceChoice>, string>> Lister = exe =>
        {
            var l = ListDevices(exe, out var err);
            return Tuple.Create(l, err);
        };

        /// <summary>Seconds without a packet from the device before checking whether it moved.</summary>
        public double SilenceSeconds { get; set; } = 5;

        // recording (own lock so start/stop never waits on a file write)
        readonly object _recSync = new object();
        FileStream _rec;
        DateTime _recUntil;
        byte[] _preamble = new byte[0];
        public string RecordingPath { get; private set; }

        public string CapturesFolder { get; set; }
        public string Status => _status;
        public bool IsRecording => _rec != null;
        public string DecoderName => _pipe?.DecoderName ?? "";
        public bool IsCapturing => _connected;

        /// <summary>Latest values (NaN while not capturing).</summary>
        public void Snapshot(double[] into)
        {
            var p = _pipe;
            if (p == null || !_connected) { for (int i = 0; i < into.Length; i++) into[i] = double.NaN; if (into.Length > FfbChannels.Connected) into[FfbChannels.Connected] = 0; return; }
            p.Snapshot(into, true);
        }

        #region Finding USBPcapCMD and devices
        static string _cachedExe; static DateTime _cachedAt;

        /// <summary>Automatic search, repeated at most every 10 s (it walks folders).</summary>
        public static string FindUsbPcapCmdCached()
        {
            if (DateTime.UtcNow - _cachedAt > TimeSpan.FromSeconds(10)) { _cachedExe = FindUsbPcapCmd(null); _cachedAt = DateTime.UtcNow; }
            return _cachedExe;
        }

        public static string FindUsbPcapCmd(string configured)
        {
            if (!string.IsNullOrWhiteSpace(configured) && File.Exists(configured.Trim().Trim('"'))) return configured.Trim().Trim('"');
            // SimHub is 32-bit, so %ProgramFiles% is the x86 folder: check the 64-bit one too.
            var roots = new[] { Environment.GetEnvironmentVariable("ProgramW6432"), Environment.GetEnvironmentVariable("ProgramFiles"),
                                Environment.GetEnvironmentVariable("ProgramFiles(x86)") }
                .Where(r => !string.IsNullOrEmpty(r)).Distinct(StringComparer.OrdinalIgnoreCase);
            foreach (var root in roots)
            {
                foreach (var dir in new[] { Path.Combine(root, "USBPcap"), Path.Combine(root, "Wireshark", "extcap") })
                {
                    try
                    {
                        if (!Directory.Exists(dir)) continue;
                        var hit = Directory.GetFiles(dir, "USBPcapCMD.exe", SearchOption.AllDirectories).FirstOrDefault();
                        if (hit != null) return hit;
                    }
                    catch { }
                }
            }
            return null;
        }

        /// <summary>Lists devices on every USBPcap hub (runs USBPcapCMD; takes a second or two).</summary>
        public static List<UsbDeviceChoice> ListDevices(string exe, out string error)
        {
            error = null;
            var list = new List<UsbDeviceChoice>();
            if (exe == null) { error = UsbPcapMissing; return list; }
            var ifaces = ParseExtcap(RunTool(exe, "--extcap-interfaces", out var e1), "interface")
                .Select(d => d.TryGetValue("value", out var v) ? v : null).Where(v => v != null).ToList();
            if (ifaces.Count == 0) { error = "USBPcapCMD found no USBPcap hubs" + (e1 != null ? ": " + e1 : ". Is the USBPcap driver installed (and the PC restarted since)?"); return list; }
            foreach (var iface in ifaces)
            {
                var cfg = ParseExtcap(RunTool(exe, $"--extcap-interface {iface} --extcap-config", out _), "value");
                foreach (var v in cfg)
                {
                    // devices are enabled entries with a numeric value; their interfaces are children
                    if (!v.TryGetValue("value", out var val) || !int.TryParse(val, out var addr)) continue;
                    if (v.TryGetValue("enabled", out var en) && en == "false") continue;
                    v.TryGetValue("display", out var disp);
                    list.Add(new UsbDeviceChoice { Interface = iface, Device = addr, Display = disp ?? $"[{addr}]" });
                }
            }
            if (list.Count == 0) error = "No devices listed. Run SimHub as administrator: USBPcap needs it.";
            return list;
        }

        static readonly Regex AddressPrefix = new Regex(@"^\s*\[[^\]]*\]\s*", RegexOptions.Compiled);

        /// <summary>The device's name without USBPcap's [address] in front: "Logitech G25 Racing Wheel USB".</summary>
        public static string DeviceLabel(string display) => AddressPrefix.Replace(display ?? "", "").Trim();

        /// <summary>Finds the chosen device in a fresh list: by name, preferring the same hub and address.
        /// Without a saved name, only the same hub and address will do. Null if it isn't there.</summary>
        public static UsbDeviceChoice Match(IList<UsbDeviceChoice> list, string iface, int device, string name, string avoid = null)
        {
            var label = DeviceLabel(name);
            var ok = list.Where(d => avoid == null || avoid != d.Interface + "|" + d.Device).ToList();
            if (label == "") return ok.FirstOrDefault(d => d.Interface == iface && d.Device == device);
            var same = ok.Where(d => string.Equals(d.Label, label, StringComparison.OrdinalIgnoreCase)).ToList();
            return same.FirstOrDefault(d => d.Interface == iface && d.Device == device)
                ?? same.FirstOrDefault(d => d.Interface == iface) ?? same.FirstOrDefault();
        }

        public const string UsbPcapMissing =
            "USBPcapCMD.exe not found. Install USBPcap (or Wireshark with its USBPcap option), restart the PC, or set its path below.";

        static string RunTool(string exe, string args, out string error)
        {
            error = null;
            try
            {
                using (var p = Process.Start(new ProcessStartInfo(exe, args)
                {
                    UseShellExecute = false, CreateNoWindow = true,
                    RedirectStandardOutput = true, RedirectStandardError = true,
                }))
                {
                    var outTask = p.StandardOutput.ReadToEndAsync();
                    var errTask = p.StandardError.ReadToEndAsync();
                    if (!p.WaitForExit(10000)) { try { p.Kill(); } catch { } error = "timed out"; }
                    var err = errTask.Wait(1000) ? errTask.Result : "";
                    if (!string.IsNullOrWhiteSpace(err)) error = err.Trim();
                    return outTask.Wait(1000) ? outTask.Result : "";
                }
            }
            catch (Exception e) { error = e.Message; return ""; }
        }

        static readonly Regex ExtcapField = new Regex(@"\{(?<k>[a-z]+)=(?<v>[^}]*)\}", RegexOptions.Compiled);

        /// <summary>Parses Wireshark extcap lines like: value {arg=99}{value=16}{display=[16] Logitech G25}.</summary>
        public static List<Dictionary<string, string>> ParseExtcap(string text, string kind)
        {
            var r = new List<Dictionary<string, string>>();
            foreach (var line in (text ?? "").Split('\n'))
            {
                var l = line.Trim();
                if (!l.StartsWith(kind + " ", StringComparison.Ordinal)) continue;
                var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (Match m in ExtcapField.Matches(l)) d[m.Groups["k"].Value] = m.Groups["v"].Value;
                r.Add(d);
            }
            return r;
        }
        #endregion

        #region Start / stop
        /// <summary>Starts, restarts or stops capture to match the settings. Capture starts a moment later,
        /// on a background thread: it finds the device first (by name, in case its USB address changed),
        /// and from then on restarts capture whenever it stops and follows the device to a new address.</summary>
        public void Apply(FfbSettings s)
        {
            lock (_sync)
            {
                var w = _wanted;
                bool same = w != null && s != null && s.Enabled && w.Interface == s.Interface && w.Device == s.Device &&
                            DeviceLabel(w.DeviceName) == DeviceLabel(s.DeviceName) && w.Decoder == s.Decoder && w.UsbPcapCmdPath == s.UsbPcapCmdPath;
                if (same) return;
                StopLocked();
                _wanted = null;
                if (s == null || !s.Enabled) { _status = "Off"; return; }
                if ((string.IsNullOrWhiteSpace(s.Interface) || s.Device <= 0) && DeviceLabel(s.DeviceName) == "") { _status = "Choose a device (Find devices)"; return; }
                if (FindUsbPcapCmd(s.UsbPcapCmdPath) == null) { _status = UsbPcapMissing; return; }
                _wanted = Copy(s);
                _failures = 0; _avoid = null;
                _nextTry = DateTime.MinValue;
                _status = $"Looking for {Name(_wanted)} ...";
                if (_watch == null) _watch = new Timer(_ => Check(), null, 0, 1000);
                else _watch.Change(0, 1000);
            }
        }

        static FfbSettings Copy(FfbSettings s) => new FfbSettings
        {
            Enabled = s.Enabled, Interface = s.Interface, Device = s.Device, DeviceName = s.DeviceName, Decoder = s.Decoder,
            UsbPcapCmdPath = s.UsbPcapCmdPath, UseForCommonValues = s.UseForCommonValues, VendorId = s.VendorId, ProductId = s.ProductId,
        };

        static string Name(FfbSettings s) { var l = DeviceLabel(s.DeviceName); return l == "" ? $"device [{s.Device}]" : l; }

        static readonly int[] Backoff = { 2, 5, 10, 30 };

        /// <summary>The watchdog, once a second: starts capture when it isn't running, checks a quiet device
        /// is still where it was, and learns the device's IDs.</summary>
        internal void Check()
        {
            if (Interlocked.Exchange(ref _checking, 1) == 1) return;
            try { CheckOnce(); }
            catch (Exception e) { Log.Error("FFB watchdog", e); }
            finally { Volatile.Write(ref _checking, 0); }
        }

        void CheckOnce()
        {
            var w = _wanted;
            if (w == null) return;
            var exe = FindUsbPcapCmd(w.UsbPcapCmdPath);
            if (exe == null) { _status = UsbPcapMissing; return; }
            var now = DateTime.UtcNow;
            bool running; Process proc; FfbPipeline pipe;
            lock (_sync) { if (_wanted != w) return; proc = _proc; pipe = _pipe; running = proc != null && !HasExited(proc); }

            if (running)
            {
                if (!_connected) return;
                if (now - _connectedSince > TimeSpan.FromSeconds(10)) _failures = 0;
                // The device's IDs, from its descriptor at the start of capture.
                if (pipe != null && pipe.VendorId != 0)
                {
                    if (w.VendorId != 0 && (w.VendorId != pipe.VendorId || w.ProductId != pipe.ProductId) && !_verified)
                    {
                        // started from the saved address without a device list, and something else is there now
                        Log.Info($"FFB capture: [{w.Device}] is {pipe.VendorId:X4}:{pipe.ProductId:X4}, not {w.VendorId:X4}:{w.ProductId:X4}; looking for {Name(w)}");
                        lock (_sync) { if (_wanted != w) return; _avoid = w.Interface + "|" + w.Device; StopLocked(); _nextTry = now; }
                        return;
                    }
                    if (w.VendorId != pipe.VendorId || w.ProductId != pipe.ProductId)
                    {
                        w.VendorId = pipe.VendorId; w.ProductId = pipe.ProductId;
                        Raise(w);
                    }
                }
                // Quiet for a while: has Windows moved the device (a G25 switching modes, a replug)?
                double quiet = (Clock.ElapsedTicks - Interlocked.Read(ref _lastPacketTicks)) / (double)System.Diagnostics.Stopwatch.Frequency;
                if (quiet > SilenceSeconds && now >= _nextLook)
                {
                    _nextLook = now.AddSeconds(30);
                    var r = Lister(exe);
                    if (r.Item1.Count == 0) return; // can't list: leave it running
                    var found = Match(r.Item1, w.Interface, w.Device, w.DeviceName);
                    if (found != null && (found.Interface != w.Interface || found.Device != w.Device))
                    {
                        Log.Info($"FFB capture: {Name(w)} moved from [{w.Device}] to [{found.Device}]");
                        lock (_sync) { if (_wanted != w) return; StopLocked(); _nextTry = now; }
                    }
                }
                return;
            }

            if (now < _nextTry) return;
            var wait = Backoff[Math.Min(_failures, Backoff.Length - 1)];
            _failures++;
            _nextTry = now.AddSeconds(wait);

            // Find the device again: the same name on any hub, preferring the saved address.
            var listed = Lister(exe);
            UsbDeviceChoice target;
            bool verified = listed.Item1.Count > 0;
            if (verified)
            {
                target = Match(listed.Item1, w.Interface, w.Device, w.DeviceName, _avoid);
                if (target == null)
                {
                    _status = $"Waiting for {Name(w)}: not on any USB hub. Is it plugged in? Trying again in {wait} s.";
                    return;
                }
            }
            else
            {
                // no list (not administrator, or USBPcap busy): try the saved address
                if (string.IsNullOrWhiteSpace(w.Interface) || w.Device <= 0) { _status = "Couldn't list USB devices: " + listed.Item2; return; }
                target = new UsbDeviceChoice { Interface = w.Interface, Device = w.Device, Display = w.DeviceName };
            }

            if (target.Interface != w.Interface || target.Device != w.Device || (verified && target.Display != w.DeviceName))
            {
                if (target.Device != w.Device || target.Interface != w.Interface)
                    Log.Info($"FFB capture: found {Name(w)} at [{target.Device}] on {target.Interface} (was [{w.Device}])");
                bool moved = target.Device != w.Device || target.Interface != w.Interface;
                w.Interface = target.Interface; w.Device = target.Device; w.DeviceName = target.Display;
                if (moved) { w.VendorId = 0; w.ProductId = 0; }   // relearnt from the device
                Raise(w);
            }
            lock (_sync)
            {
                if (_wanted != w) return;
                _verified = verified;
                _running = w;
                StartLocked(exe);
            }
        }

        static bool HasExited(Process p) { try { return p.HasExited; } catch { return true; } }

        void Raise(FfbSettings w)
        {
            try { DeviceChanged?.Invoke(Copy(w)); }
            catch (Exception e) { Log.Error("FFB device changed", e); }
        }

        void StartLocked(string exe)
        {
            _stopping = false;
            _pipe = new FfbPipeline(_running.Decoder, _running.Device);
            var args = $"-d {_running.Interface} -o - --devices {_running.Device} --inject-descriptors";
            try
            {
                _proc = Process.Start(new ProcessStartInfo(exe, args)
                {
                    UseShellExecute = false, CreateNoWindow = true,
                    RedirectStandardOutput = true, RedirectStandardError = true,
                });
                // If SimHub closes or crashes, Windows ends the capture too.
                try { _job = _job ?? new ChildProcessJob(); _job.Add(_proc); } catch (Exception e) { Log.Error("FFB job object", e); }
                var proc = _proc;
                var errBuf = new StringBuilder();
                proc.ErrorDataReceived += (o, e) => { if (e.Data != null) lock (errBuf) errBuf.AppendLine(e.Data); };
                proc.BeginErrorReadLine();
                _reader = new Thread(() => ReadLoop(proc, errBuf)) { IsBackground = true, Name = "TPTelemetry FFB capture" };
                _reader.Start();
                _status = $"Starting capture on {_running.DeviceName} ...";
                Log.Info($"FFB capture: {exe} {args}");
            }
            catch (Exception e)
            {
                _status = "Couldn't start USBPcapCMD: " + e.Message;
                Log.Error("FFB start", e);
                _proc = null;
            }
        }

        void ReadLoop(Process proc, StringBuilder errBuf)
        {
            try
            {
                var reader = new PcapStreamReader(proc.StandardOutput.BaseStream);
                reader.ReadHeader();
                _preamble = reader.Preamble;
                _connected = true;
                _connectedSince = DateTime.UtcNow;
                Interlocked.Exchange(ref _lastPacketTicks, Clock.ElapsedTicks);
                _status = $"Capturing {_running?.DeviceName}";
                UsbPacket p;
                while (!_stopping && (p = reader.Next()) != null)
                {
                    Interlocked.Exchange(ref _lastPacketTicks, Clock.ElapsedTicks);
                    _pipe.OnPacket(p);
                    var rec = _rec;
                    if (rec != null)
                    {
                        lock (_recSync)
                        {
                            if (_rec != null)
                            {
                                _rec.Write(p.Record, 0, p.Record.Length);
                                if (DateTime.UtcNow > _recUntil) StopRecordingLocked();
                            }
                        }
                    }
                    _status = $"Capturing {_running?.DeviceName}  ·  {_pipe.DecoderName}";
                }
            }
            catch (Exception e)
            {
                // Stopping kills USBPcapCMD under the reader, which can throw here: never let that escape
                // the thread, or it takes SimHub down with it.
                if (!_stopping) Log.Error("FFB capture stream", e);
            }
            _connected = false;
            if (!_stopping)
            {
                string err; lock (errBuf) err = errBuf.ToString().Trim();
                try { if (proc.WaitForExit(500) && string.IsNullOrEmpty(err)) err = "USBPcapCMD exited with code " + proc.ExitCode; } catch { }
                int wait = Backoff[Math.Min(_failures, Backoff.Length - 1)];
                _status = "Capture stopped: " + (string.IsNullOrEmpty(err) ? "no data" : err) +
                          $". Looking for the device again in {wait} s (USBPcap needs SimHub to run as administrator).";
                Log.Error("FFB capture ended: " + err);
            }
        }

        void StopLocked()
        {
            _stopping = true;
            StopRecording();
            var p = _proc; _proc = null;
            if (p != null)
            {
                try { if (!p.HasExited) p.Kill(); } catch { }
                try { p.Dispose(); } catch { }
            }
            _reader?.Join(1000);
            _reader = null;
            _connected = false;
            _connectedSince = DateTime.MaxValue;
            _running = null;
        }
        #endregion

        #region Recording
        /// <summary>Records what's captured to a .pcap file Wireshark can open, for adding support
        /// for other wheels. Stops by itself after <paramref name="seconds"/>.</summary>
        public string StartRecording(int seconds) => StartRecording(seconds, "");

        string StartRecording(int seconds, string suffix)
        {
            lock (_recSync)
            {
                if (!_connected) throw new InvalidOperationException("Start capture first.");
                StopRecordingLocked();
                Directory.CreateDirectory(CapturesFolder);
                var name = Regex.Replace(_running?.DeviceName ?? "device", @"[^\w\-]+", "_").Trim('_');
                RecordingPath = Path.Combine(CapturesFolder, $"{DateTime.Now:yyyyMMdd-HHmmss}_{name}{suffix}.{(_preamble.Length > 24 ? "pcapng" : "pcap")}");
                _rec = new FileStream(RecordingPath, FileMode.CreateNew, FileAccess.Write);
                _rec.Write(_preamble, 0, _preamble.Length);
                _recUntil = DateTime.UtcNow.AddSeconds(seconds);
                Log.Info("FFB recording to " + RecordingPath);
                return RecordingPath;
            }
        }

        public void StopRecording() { lock (_recSync) StopRecordingLocked(); }

        public const string TestPatternExe = "TPTelemetryFfbTest.exe";
        public bool IsTestPatternRunning { get { var p = _testPattern; return p != null && !HasExited(p); } }
        Process _testPattern;

        /// <summary>Records the USB traffic while TPTelemetryFfbTest.exe plays a fixed force feedback pattern on the wheel
        /// (0.21.0), with each step's time in a log beside the capture. Returns the capture's path.</summary>
        public string StartTestPattern()
        {
            if (IsTestPatternRunning) throw new InvalidOperationException("The test pattern is already running.");
            var exe = Path.Combine(Path.GetDirectoryName(typeof(FfbCapture).Assembly.Location) ?? "", TestPatternExe);
            if (!File.Exists(exe)) throw new FileNotFoundException(TestPatternExe + " isn't beside the plugin: copy it from the plugin download.");
            var path = StartRecording(40, "_testpattern");
            int vid = _pipe?.VendorId ?? 0, pid = _pipe?.ProductId ?? 0;
            var args = (vid != 0 ? $"--vid {vid:X4} --pid {pid:X4} " : "") + $"--log \"{Path.ChangeExtension(path, ".txt")}\"";
            _testPattern = Process.Start(new ProcessStartInfo(exe, args) { UseShellExecute = false, CreateNoWindow = true });
            Log.Info($"FFB test pattern: {exe} {args}");
            return path;
        }

        void StopRecordingLocked()
        {
            var r = _rec; _rec = null;
            if (r != null) { try { r.Dispose(); Log.Info("FFB recording saved: " + RecordingPath); } catch { } }
        }
        #endregion

        public void Dispose()
        {
            lock (_sync) { _wanted = null; StopLocked(); }
            _watch?.Dispose(); _watch = null;
            _job?.Dispose();
        }
    }
}
