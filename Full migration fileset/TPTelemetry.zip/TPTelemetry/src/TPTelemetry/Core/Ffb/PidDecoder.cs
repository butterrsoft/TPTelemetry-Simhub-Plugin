using System;
using System.Collections.Generic;
using System.Linq;

namespace TeknoTelemetry.Core.Ffb
{
    /// <summary>One USB PID report read into usages (Physical Interface Device page, 0x0F).</summary>
    public sealed class PidReport
    {
        /// <summary>The report's own usage: 0x21 Set Effect, 0x5F Set Condition, 0x6E Set Periodic, 0x73 Set Constant
        /// Force, 0x74 Set Ramp Force, 0x77 Effect Operation, 0x90 Block Free, 0x95 Device Control, 0x7D Device Gain.</summary>
        public int Kind;
        public readonly Dictionary<int, double> Values = new Dictionary<int, double>();
        /// <summary>Each value's logical range, for scaling.</summary>
        public readonly Dictionary<int, (long Min, long Max)> Ranges = new Dictionary<int, (long, long)>();
        /// <summary>Usages chosen in array fields: the effect type, the operation, the device control.</summary>
        public readonly HashSet<int> Selected = new HashSet<int>();
        /// <summary>The effect's direction in degrees, when the report gives one.</summary>
        public double? Direction;

        public double Get(int usage) => Values.TryGetValue(usage, out var v) ? v : double.NaN;
        /// <summary>A value over its range: -1 to 1 for signed fields, 0 to 1 for unsigned ones.</summary>
        public double Norm(int usage)
        {
            if (!Values.TryGetValue(usage, out var v)) return double.NaN;
            if (!Ranges.TryGetValue(usage, out var r)) return v;
            double span = Math.Max(Math.Abs((double)r.Min), Math.Abs((double)r.Max));
            return span <= 0 ? 0 : Math.Max(-1, Math.Min(1, v / span));
        }
    }

    /// <summary>Turns a USB PID output report into a <see cref="PidReport"/>.</summary>
    public interface IPidReportSource
    {
        /// <summary>Where the layout came from, for the status line.</summary>
        string LayoutName { get; }
        bool TryRead(byte[] report, out PidReport r);
    }

    public static class PidUsages
    {
        public const int SetEffect = 0x21, EffectBlockIndex = 0x22, EffectType = 0x25, Gain = 0x52, Direction = 0x57,
                         SetEnvelope = 0x5A, SetCondition = 0x5F, PositiveCoefficient = 0x61, NegativeCoefficient = 0x62,
                         PositiveSaturation = 0x63, SetPeriodic = 0x6E, Magnitude = 0x70, SetConstantForce = 0x73,
                         SetRampForce = 0x74, RampStart = 0x75, EffectOperationReport = 0x77, OpStart = 0x79, OpStartSolo = 0x7A,
                         OpStop = 0x7B, DeviceGainReport = 0x7D, DeviceGain = 0x7E, BlockFree = 0x90, DeviceControlReport = 0x95,
                         DisableActuators = 0x98, StopAll = 0x99, Reset = 0x9A;
        public const int Constant = 0x26, Ramp = 0x27, Square = 0x30, Sine = 0x31, Triangle = 0x32, SawUp = 0x33, SawDown = 0x34,
                         Spring = 0x40, Damper = 0x41, Inertia = 0x42, Friction = 0x43;
        public static readonly int[] EffectTypes = { Constant, Ramp, Square, Sine, Triangle, SawUp, SawDown, Spring, Damper, Inertia, Friction };
        public static readonly HashSet<int> ReportKinds = new HashSet<int>
            { SetEffect, SetEnvelope, SetCondition, SetPeriodic, SetConstantForce, SetRampForce, EffectOperationReport, DeviceGainReport, BlockFree, DeviceControlReport, 0x96 };
        public const uint Page = 0x0F;
    }

    /// <summary>Reads PID reports with the layout from the wheel's own HID report descriptor.</summary>
    public sealed class DescriptorPidSource : IPidReportSource
    {
        readonly HidReportLayout _layout;
        public DescriptorPidSource(HidReportLayout layout) { _layout = layout; }
        public string LayoutName => "layout from the wheel";

        public static bool LooksLikePid(HidReportLayout l) =>
            l.Output.Any(f => f.Collections.Any(c => c >> 16 == PidUsages.Page && (c & 0xFFFF) == PidUsages.SetConstantForce) ||
                              f.Usages.Any(u => u >> 16 == PidUsages.Page && (u & 0xFFFF) == PidUsages.Magnitude));

        public bool TryRead(byte[] report, out PidReport r)
        {
            r = null;
            if (report == null || report.Length == 0) return false;
            int id = _layout.UsesReportIds ? report[0] : 0;
            var fields = _layout.FieldsOf(id).ToList();
            if (fields.Count == 0) return false;
            r = new PidReport();
            foreach (var f in fields)
                foreach (var c in f.Collections.Reverse())
                    if (c >> 16 == PidUsages.Page && PidUsages.ReportKinds.Contains((int)(c & 0xFFFF))) { r.Kind = (int)(c & 0xFFFF); goto found; }
            found:
            if (r.Kind == 0x96) r.Kind = PidUsages.DeviceControlReport;
            foreach (var f in fields)
            {
                bool inDirection = f.Collections.Any(c => c == (PidUsages.Page << 16 | PidUsages.Direction));
                for (int k = 0; k < f.Count; k++)
                {
                    long v = _layout.Read(f, k, report);
                    if (f.IsArray)
                    {
                        long idx = v - f.LogicalMin;
                        if (v != 0 && idx >= 0 && idx < f.Usages.Count && f.Usages[(int)idx] >> 16 == PidUsages.Page)
                            r.Selected.Add((int)(f.Usages[(int)idx] & 0xFFFF));
                        continue;
                    }
                    if (inDirection)
                    {
                        // the first direction instance (X): degrees over the field's range
                        if (k == 0 && r.Direction == null && f.LogicalMax > f.LogicalMin)
                            r.Direction = (v - f.LogicalMin) * 360.0 / (f.LogicalMax - f.LogicalMin + 1);
                        continue;
                    }
                    if (f.Usages.Count == 0) continue;
                    uint u = f.Usages[Math.Min(k, f.Usages.Count - 1)];
                    if (u >> 16 != PidUsages.Page) continue;
                    int us = (int)(u & 0xFFFF);
                    if (!r.Values.ContainsKey(us)) { r.Values[us] = v; r.Ranges[us] = (f.LogicalMin, f.LogicalMax); }
                }
            }
            return r.Kind != 0;
        }
    }

    /// <summary>
    /// The layout most USB PID wheels share (report IDs 1 Set Effect, 3 Condition, 4 Periodic, 5 Constant Force,
    /// 6 Ramp, 10 Effect Operation, 11 Block Free, 12 Device Control, 13 Device Gain), for when the wheel's own
    /// descriptor isn't available. A guess: constant force and starting and stopping are the parts most wheels agree on.
    /// </summary>
    public sealed class GuessedPidSource : IPidReportSource
    {
        public string LayoutName => "layout guessed";
        static readonly int[] TypeOrder = { PidUsages.Constant, PidUsages.Ramp, PidUsages.Square, PidUsages.Sine, PidUsages.Triangle,
                                            PidUsages.SawUp, PidUsages.SawDown, PidUsages.Spring, PidUsages.Damper, PidUsages.Inertia, PidUsages.Friction };

        static void Put(PidReport r, int usage, long v, long min, long max) { r.Values[usage] = v; r.Ranges[usage] = (min, max); }
        static short S16(byte[] b, int o) => (short)(b[o] | (b[o + 1] << 8));

        public bool TryRead(byte[] b, out PidReport r)
        {
            r = new PidReport();
            if (b == null || b.Length < 3) return false;
            Put(r, PidUsages.EffectBlockIndex, b[1], 1, 40);
            switch (b[0])
            {
                case 1:
                    r.Kind = PidUsages.SetEffect;
                    if (b[2] >= 1 && b[2] <= TypeOrder.Length) r.Selected.Add(TypeOrder[b[2] - 1]);
                    return true;
                case 3:
                    r.Kind = PidUsages.SetCondition;
                    if (b.Length >= 9) { Put(r, PidUsages.PositiveCoefficient, S16(b, 5), -10000, 10000); Put(r, PidUsages.NegativeCoefficient, S16(b, 7), -10000, 10000); }
                    return true;
                case 4:
                    r.Kind = PidUsages.SetPeriodic;
                    if (b.Length >= 4) Put(r, PidUsages.Magnitude, b[2] | (b[3] << 8), 0, 10000);
                    return true;
                case 5:
                    r.Kind = PidUsages.SetConstantForce;
                    if (b.Length >= 4) Put(r, PidUsages.Magnitude, S16(b, 2), -10000, 10000);
                    else Put(r, PidUsages.Magnitude, (sbyte)b[2], -127, 127);
                    return true;
                case 6:
                    r.Kind = PidUsages.SetRampForce;
                    if (b.Length >= 4) Put(r, PidUsages.RampStart, S16(b, 2), -10000, 10000);
                    return true;
                case 10:
                    r.Kind = PidUsages.EffectOperationReport;
                    if (b[2] == 1) r.Selected.Add(PidUsages.OpStart); else if (b[2] == 2) r.Selected.Add(PidUsages.OpStartSolo); else if (b[2] == 3) r.Selected.Add(PidUsages.OpStop);
                    return true;
                case 11: r.Kind = PidUsages.BlockFree; return true;
                case 12:
                    r.Kind = PidUsages.DeviceControlReport;
                    r.Values.Clear();
                    if (b[1] >= 1 && b[1] <= 6) r.Selected.Add(0x96 + b[1]);
                    return true;
            }
            return false;
        }
    }

    /// <summary>
    /// The standard USB force feedback protocol (USB PID): Moza, Simucube, VRS, Cammus, Asetek, PXN, OpenFFBoard and
    /// others. Windows' own driver sends the game's DirectInput effects as PID reports. The report layout differs per
    /// wheel, so it comes from the wheel: from Windows (on the PC running SimHub), or from the report descriptor if the
    /// capture sees the wheel plugged in; failing both, the layout most wheels share is assumed. Effects are held per
    /// effect block index, from Set Effect (type), Set Constant Force, Set Periodic, Set Ramp Force and Set Condition,
    /// and started and stopped by Effect Operation. Written from the USB PID specification; not yet checked against a
    /// capture from a real wheel.
    /// </summary>
    public sealed class UsbPidDecoder : IFfbDecoder, IFfbDescriptorSink
    {
        IPidReportSource _src;
        public UsbPidDecoder(IPidReportSource source = null) { _src = source ?? new GuessedPidSource(); }
        public string Name => "USB PID (Moza, Simucube, VRS, Cammus...) · " + _src.LayoutName;

        /// <summary>Vendor IDs of wheels known to use USB PID (any product), and single products.</summary>
        public static readonly HashSet<int> VendorIds = new HashSet<int> { 0x346E /* Moza */, 0x3416 /* Cammus */, 0x2433 /* Asetek */ };
        public static readonly HashSet<(int, int)> Products = new HashSet<(int, int)>
        {
            (0x16D0, 0x0D5A), (0x16D0, 0x0D61), (0x16D0, 0x0D60), (0x16D0, 0x0D5F),   // Simucube 1, 2 Sport, Pro, Ultimate
            (0x0483, 0xA355),                                                         // VRS DirectForce Pro
            (0x1209, 0xFFB0),                                                         // OpenFFBoard
            (0x11FF, 0x3245), (0x11FF, 0x1212), (0x11FF, 0x1112), (0x11FF, 0x1211), (0x36E6, 0x400F), // PXN
        };
        public static bool IsPidWheel(int vid, int pid) => VendorIds.Contains(vid) || Products.Contains((vid, pid));

        sealed class Effect { public int Type; public double Level = double.NaN, Coeff, Gain = 1, Dir = 1; public bool Playing; }
        readonly Dictionary<int, Effect> _fx = new Dictionary<int, Effect>();

        public void SetReportDescriptor(byte[] d)
        {
            try
            {
                var l = HidReportLayout.Parse(d);
                if (DescriptorPidSource.LooksLikePid(l)) _src = new DescriptorPidSource(l);
            }
            catch (Exception e) { Log.Error("USB PID descriptor", e); }
        }

        Effect Fx(int i) { if (!_fx.TryGetValue(i, out var e)) _fx[i] = e = new Effect(); return e; }

        public void OnCommand(byte[] b, double time)
        {
            if (!_src.TryRead(b, out var r)) return;
            int idx = (int)r.Get(PidUsages.EffectBlockIndex);
            switch (r.Kind)
            {
                case PidUsages.SetEffect:
                {
                    var e = Fx(idx);
                    foreach (var t in PidUsages.EffectTypes) if (r.Selected.Contains(t)) e.Type = t;
                    double g = r.Norm(PidUsages.Gain); if (!double.IsNaN(g)) e.Gain = Math.Abs(g);
                    if (r.Direction is double deg)
                    {
                        // force along X is the direction's sine (0 = north): 90 pushes one way, 270 the other; a wheel that
                        // leaves the direction at 0 or 180 counts as + or -
                        double s = Math.Sin(deg * Math.PI / 180), c = Math.Cos(deg * Math.PI / 180);
                        e.Dir = Math.Abs(s) >= 0.5 ? s : Math.Sign(c == 0 ? 1 : c);
                    }
                    break;
                }
                case PidUsages.SetConstantForce: Fx(idx).Level = r.Norm(PidUsages.Magnitude); if (Fx(idx).Type == 0) Fx(idx).Type = PidUsages.Constant; break;
                case PidUsages.SetPeriodic: Fx(idx).Level = Math.Abs(r.Norm(PidUsages.Magnitude)); break;
                case PidUsages.SetRampForce: Fx(idx).Level = r.Norm(PidUsages.RampStart); break;
                case PidUsages.SetCondition:
                {
                    double p = r.Norm(PidUsages.PositiveCoefficient), n = r.Norm(PidUsages.NegativeCoefficient);
                    if (double.IsNaN(p) && double.IsNaN(n)) break;
                    Fx(idx).Coeff = Math.Max(double.IsNaN(p) ? 0 : Math.Abs(p), double.IsNaN(n) ? 0 : Math.Abs(n));
                    break;
                }
                case PidUsages.EffectOperationReport:
                    if (r.Selected.Contains(PidUsages.OpStartSolo)) foreach (var e in _fx.Values) e.Playing = false;
                    if (r.Selected.Contains(PidUsages.OpStart) || r.Selected.Contains(PidUsages.OpStartSolo)) Fx(idx).Playing = true;
                    else if (r.Selected.Contains(PidUsages.OpStop)) Fx(idx).Playing = false;
                    break;
                case PidUsages.BlockFree: _fx.Remove(idx); break;
                case PidUsages.DeviceControlReport:
                    if (r.Selected.Contains(PidUsages.StopAll) || r.Selected.Contains(PidUsages.Reset) || r.Selected.Contains(PidUsages.DisableActuators))
                        foreach (var e in _fx.Values) e.Playing = false;
                    if (r.Selected.Contains(PidUsages.Reset)) _fx.Clear();
                    break;
            }
        }

        public void Fill(double[] ch)
        {
            double force = 0, spring = 0, damper = 0, friction = 0, vib = 0;
            foreach (var e in _fx.Values.Where(x => x.Playing))
            {
                double lv = double.IsNaN(e.Level) ? 0 : e.Level;
                switch (e.Type)
                {
                    case PidUsages.Constant: case PidUsages.Ramp: force += lv * e.Gain * e.Dir; break;
                    case PidUsages.Spring: spring = Math.Max(spring, e.Coeff * e.Gain); break;
                    case PidUsages.Damper: case PidUsages.Inertia: damper = Math.Max(damper, e.Coeff * e.Gain); break;
                    case PidUsages.Friction: friction = Math.Max(friction, e.Coeff * e.Gain); break;
                    case 0: break;
                    default: vib = Math.Max(vib, Math.Abs(lv) * e.Gain); break;
                }
            }
            ch[FfbChannels.Force] = Math.Max(-1, Math.Min(1, force));
            ch[FfbChannels.Spring] = spring;
            ch[FfbChannels.Damper] = damper;
            ch[FfbChannels.Friction] = friction;
            ch[FfbChannels.Autocenter] = double.NaN;
            ch[FfbChannels.Rumble] = vib;
            ch[FfbChannels.RumbleLarge] = ch[FfbChannels.RumbleSmall] = double.NaN;
        }
    }
}
