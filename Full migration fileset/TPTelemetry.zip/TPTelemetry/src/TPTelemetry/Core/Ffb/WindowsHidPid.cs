using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace TeknoTelemetry.Core.Ffb
{
    /// <summary>
    /// Reads a USB PID wheel's output reports with Windows' own HID parser (hid.dll), which knows the wheel's report
    /// layout from its descriptor. Used on the PC running SimHub, so no capture of the wheel being plugged in is needed.
    /// Only calls plain Windows functions (no COM); any failure just means the decoder falls back to another layout.
    /// </summary>
    public sealed class WindowsHidPidSource : IPidReportSource
    {
        public string LayoutName => "layout from Windows";

        readonly IntPtr _preparsed;
        readonly int _reportLength;
        readonly List<HIDP_VALUE_CAPS> _values;
        readonly List<HIDP_BUTTON_CAPS> _buttons;
        readonly HIDP_LINK_COLLECTION_NODE[] _nodes;

        WindowsHidPidSource(IntPtr preparsed, int reportLength, List<HIDP_VALUE_CAPS> values, List<HIDP_BUTTON_CAPS> buttons, HIDP_LINK_COLLECTION_NODE[] nodes)
        {
            _preparsed = preparsed; _reportLength = reportLength; _values = values; _buttons = buttons; _nodes = nodes;
        }

        /// <summary>The PID layout of a connected wheel, or null (not Windows, not found, not a PID wheel).</summary>
        public static WindowsHidPidSource TryOpen(int vendorId, int productId)
        {
            if (Environment.OSVersion.Platform != PlatformID.Win32NT || vendorId == 0) return null;
            try { return Open(vendorId, productId); }
            catch (Exception e) { Log.Error("USB PID layout from Windows", e); return null; }
        }

        static WindowsHidPidSource Open(int vid, int pid)
        {
            HidD_GetHidGuid(out Guid hidGuid);
            IntPtr set = SetupDiGetClassDevs(ref hidGuid, IntPtr.Zero, IntPtr.Zero, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
            if (set == new IntPtr(-1)) return null;
            try
            {
                var iface = new SP_DEVICE_INTERFACE_DATA { cbSize = Marshal.SizeOf(typeof(SP_DEVICE_INTERFACE_DATA)) };
                for (int i = 0; SetupDiEnumDeviceInterfaces(set, IntPtr.Zero, ref hidGuid, i, ref iface); i++)
                {
                    string path = DevicePath(set, ref iface);
                    if (path == null) continue;
                    var src = TryDevice(path, vid, pid);
                    if (src != null) return src;
                }
            }
            finally { SetupDiDestroyDeviceInfoList(set); }
            return null;
        }

        static string DevicePath(IntPtr set, ref SP_DEVICE_INTERFACE_DATA iface)
        {
            SetupDiGetDeviceInterfaceDetail(set, ref iface, IntPtr.Zero, 0, out int size, IntPtr.Zero);
            if (size <= 0) return null;
            IntPtr buf = Marshal.AllocHGlobal(size);
            try
            {
                Marshal.WriteInt32(buf, IntPtr.Size == 8 ? 8 : 6);   // cbSize of SP_DEVICE_INTERFACE_DETAIL_DATA_W
                if (!SetupDiGetDeviceInterfaceDetail(set, ref iface, buf, size, out _, IntPtr.Zero)) return null;
                return Marshal.PtrToStringUni(buf + 4);
            }
            finally { Marshal.FreeHGlobal(buf); }
        }

        static WindowsHidPidSource TryDevice(string path, int vid, int pid)
        {
            IntPtr h = CreateFile(path, 0, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
            if (h == new IntPtr(-1)) return null;
            IntPtr pre = IntPtr.Zero;
            try
            {
                var attr = new HIDD_ATTRIBUTES { Size = Marshal.SizeOf(typeof(HIDD_ATTRIBUTES)) };
                if (!HidD_GetAttributes(h, ref attr) || attr.VendorID != vid || attr.ProductID != pid) return null;
                if (!HidD_GetPreparsedData(h, out pre)) return null;
                if (HidP_GetCaps(pre, out HIDP_CAPS caps) != HIDP_STATUS_SUCCESS || caps.NumberOutputValueCaps == 0) return Free(pre);

                ushort nv = caps.NumberOutputValueCaps, nb = caps.NumberOutputButtonCaps, nl = caps.NumberLinkCollectionNodes;
                var values = new HIDP_VALUE_CAPS[nv];
                if (HidP_GetValueCaps(HIDP_OUTPUT, values, ref nv, pre) != HIDP_STATUS_SUCCESS) return Free(pre);
                var buttons = new HIDP_BUTTON_CAPS[Math.Max((int)nb, 1)];
                if (nb > 0 && HidP_GetButtonCaps(HIDP_OUTPUT, buttons, ref nb, pre) != HIDP_STATUS_SUCCESS) nb = 0;
                var nodes = new HIDP_LINK_COLLECTION_NODE[Math.Max((int)nl, 1)];
                int nlInt = nl;
                if (HidP_GetLinkCollectionNodes(nodes, ref nlInt, pre) != HIDP_STATUS_SUCCESS) return Free(pre);

                var vlist = values.Take(nv).ToList();
                if (!vlist.Any(v => v.UsagePage == PidUsages.Page)) return Free(pre);   // not a force feedback (PID) device
                return new WindowsHidPidSource(pre, caps.OutputReportByteLength, vlist, buttons.Take(nb).ToList(), nodes.Take(nlInt).ToArray());
            }
            finally { CloseHandle(h); }
        }

        static WindowsHidPidSource Free(IntPtr pre) { if (pre != IntPtr.Zero) HidD_FreePreparsedData(pre); return null; }

        int KindOf(ushort link)
        {
            for (int guard = 0; guard < 16 && link < _nodes.Length; guard++)
            {
                var n = _nodes[link];
                if (n.LinkUsagePage == PidUsages.Page && PidUsages.ReportKinds.Contains(n.LinkUsage))
                    return n.LinkUsage == 0x96 ? PidUsages.DeviceControlReport : n.LinkUsage;
                if (link == 0) break;
                link = n.Parent;
            }
            return 0;
        }

        bool InDirection(ushort link)
        {
            for (int guard = 0; guard < 16 && link < _nodes.Length; guard++)
            {
                var n = _nodes[link];
                if (n.LinkUsagePage == PidUsages.Page && n.LinkUsage == PidUsages.Direction) return true;
                if (link == 0) break;
                link = n.Parent;
            }
            return false;
        }

        public bool TryRead(byte[] report, out PidReport r)
        {
            r = null;
            if (report == null || report.Length == 0) return false;
            byte id = report[0];
            var buf = new byte[Math.Max(_reportLength, report.Length)];
            Buffer.BlockCopy(report, 0, buf, 0, report.Length);
            r = new PidReport();
            foreach (var v in _values.Where(c => c.ReportID == id))
            {
                if (r.Kind == 0) r.Kind = KindOf(v.LinkCollection);
                ushort first = v.IsRange != 0 ? v.UsageMin : v.Usage;
                if (InDirection(v.LinkCollection))
                {
                    if (r.Direction == null && HidP_GetUsageValue(HIDP_OUTPUT, v.UsagePage, v.LinkCollection, first, out uint dv, _preparsed, buf, buf.Length) == HIDP_STATUS_SUCCESS
                        && v.LogicalMax > v.LogicalMin)
                        r.Direction = (dv - v.LogicalMin) * 360.0 / (v.LogicalMax - v.LogicalMin + 1);
                    continue;
                }
                if (v.UsagePage != PidUsages.Page) continue;
                if (HidP_GetUsageValue(HIDP_OUTPUT, v.UsagePage, v.LinkCollection, first, out uint raw, _preparsed, buf, buf.Length) != HIDP_STATUS_SUCCESS) continue;
                long val = raw;
                if (v.LogicalMin < 0 && v.BitSize > 0 && v.BitSize < 32 && (raw & (1u << (v.BitSize - 1))) != 0) val = (int)(raw | ~((1u << v.BitSize) - 1));
                if (!r.Values.ContainsKey(first)) { r.Values[first] = val; r.Ranges[first] = (v.LogicalMin, v.LogicalMax); }
            }
            foreach (var b in _buttons.Where(c => c.ReportID == id && c.UsagePage == PidUsages.Page))
            {
                if (r.Kind == 0) r.Kind = KindOf(b.LinkCollection);
                int n = 32;
                var list = new ushort[n];
                if (HidP_GetUsages(HIDP_OUTPUT, b.UsagePage, b.LinkCollection, list, ref n, _preparsed, buf, buf.Length) != HIDP_STATUS_SUCCESS) continue;
                for (int k = 0; k < n; k++) if (list[k] != 0) r.Selected.Add(list[k]);
            }
            return r.Kind != 0;
        }

        #region Windows API
        const int DIGCF_PRESENT = 0x2, DIGCF_DEVICEINTERFACE = 0x10, FILE_SHARE_READ = 1, FILE_SHARE_WRITE = 2, OPEN_EXISTING = 3, HIDP_OUTPUT = 1;
        const int HIDP_STATUS_SUCCESS = 0x00110000;

        [StructLayout(LayoutKind.Sequential)]
        struct SP_DEVICE_INTERFACE_DATA { public int cbSize; public Guid InterfaceClassGuid; public int Flags; public IntPtr Reserved; }

        [StructLayout(LayoutKind.Sequential)]
        struct HIDD_ATTRIBUTES { public int Size; public ushort VendorID, ProductID, VersionNumber; }

        [StructLayout(LayoutKind.Sequential)]
        struct HIDP_CAPS
        {
            public ushort Usage, UsagePage, InputReportByteLength, OutputReportByteLength, FeatureReportByteLength;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 17)] public ushort[] Reserved;
            public ushort NumberLinkCollectionNodes, NumberInputButtonCaps, NumberInputValueCaps, NumberInputDataIndices,
                          NumberOutputButtonCaps, NumberOutputValueCaps, NumberOutputDataIndices,
                          NumberFeatureButtonCaps, NumberFeatureValueCaps, NumberFeatureDataIndices;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct HIDP_VALUE_CAPS
        {
            public ushort UsagePage; public byte ReportID, IsAlias; public ushort BitField, LinkCollection, LinkUsage, LinkUsagePage;
            public byte IsRange, IsStringRange, IsDesignatorRange, IsAbsolute, HasNull, Reserved;
            public ushort BitSize, ReportCount, R2a, R2b, R2c, R2d, R2e;
            public uint UnitsExp, Units; public int LogicalMin, LogicalMax, PhysicalMin, PhysicalMax;
            public ushort UsageMin, UsageMax, StringMin, StringMax, DesignatorMin, DesignatorMax, DataIndexMin, DataIndexMax;
            public ushort Usage => UsageMin;   // the NotRange union's Usage sits where Range's UsageMin does
        }

        [StructLayout(LayoutKind.Sequential)]
        struct HIDP_BUTTON_CAPS
        {
            public ushort UsagePage; public byte ReportID, IsAlias; public ushort BitField, LinkCollection, LinkUsage, LinkUsagePage;
            public byte IsRange, IsStringRange, IsDesignatorRange, IsAbsolute;
            public ushort ReportCount, Reserved2;
            public uint Rs0, Rs1, Rs2, Rs3, Rs4, Rs5, Rs6, Rs7, Rs8;   // ULONG Reserved[9]
            public ushort UsageMin, UsageMax, StringMin, StringMax, DesignatorMin, DesignatorMax, DataIndexMin, DataIndexMax;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct HIDP_LINK_COLLECTION_NODE
        {
            public ushort LinkUsage, LinkUsagePage, Parent, NumberOfChildren, NextSibling, FirstChild;
            public uint Bits; public IntPtr UserContext;
        }

        [DllImport("hid.dll")] static extern void HidD_GetHidGuid(out Guid g);
        [DllImport("hid.dll")] static extern bool HidD_GetAttributes(IntPtr h, ref HIDD_ATTRIBUTES a);
        [DllImport("hid.dll")] static extern bool HidD_GetPreparsedData(IntPtr h, out IntPtr p);
        [DllImport("hid.dll")] static extern bool HidD_FreePreparsedData(IntPtr p);
        [DllImport("hid.dll")] static extern int HidP_GetCaps(IntPtr p, out HIDP_CAPS caps);
        [DllImport("hid.dll")] static extern int HidP_GetValueCaps(int type, [In, Out] HIDP_VALUE_CAPS[] caps, ref ushort len, IntPtr p);
        [DllImport("hid.dll")] static extern int HidP_GetButtonCaps(int type, [In, Out] HIDP_BUTTON_CAPS[] caps, ref ushort len, IntPtr p);
        [DllImport("hid.dll")] static extern int HidP_GetLinkCollectionNodes([In, Out] HIDP_LINK_COLLECTION_NODE[] nodes, ref int len, IntPtr p);
        [DllImport("hid.dll")] static extern int HidP_GetUsageValue(int type, ushort page, ushort link, ushort usage, out uint value, IntPtr p, byte[] report, int len);
        [DllImport("hid.dll")] static extern int HidP_GetUsages(int type, ushort page, ushort link, [In, Out] ushort[] list, ref int len, IntPtr p, byte[] report, int reportLen);
        [DllImport("setupapi.dll", SetLastError = true)] static extern IntPtr SetupDiGetClassDevs(ref Guid g, IntPtr enumerator, IntPtr parent, int flags);
        [DllImport("setupapi.dll", SetLastError = true)] static extern bool SetupDiEnumDeviceInterfaces(IntPtr set, IntPtr devInfo, ref Guid g, int index, ref SP_DEVICE_INTERFACE_DATA d);
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool SetupDiGetDeviceInterfaceDetail(IntPtr set, ref SP_DEVICE_INTERFACE_DATA d, IntPtr detail, int size, out int required, IntPtr devInfo);
        [DllImport("setupapi.dll")] static extern bool SetupDiDestroyDeviceInfoList(IntPtr set);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern IntPtr CreateFile(string name, int access, int share, IntPtr sec, int disposition, int flags, IntPtr template);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
        #endregion
    }
}
