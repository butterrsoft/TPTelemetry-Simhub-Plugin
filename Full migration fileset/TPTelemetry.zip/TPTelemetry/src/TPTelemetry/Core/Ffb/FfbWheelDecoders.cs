using System;
using System.Collections.Generic;
using System.Linq;

namespace TeknoTelemetry.Core.Ffb
{
    /// <summary>A decoder that also wants what the device sends back (HID++ answers with the slot an effect went to).</summary>
    public interface IFfbDeviceSink { void OnDeviceReport(byte[] payload, double time); }

    /// <summary>A decoder that needs the wheel's HID report descriptor (USB PID wheels), when the capture carries it.</summary>
    public interface IFfbDescriptorSink { void SetReportDescriptor(byte[] descriptor); }

    /// <summary>
    /// Thrustmaster T300RS family: T300RS (PS3 and PS4 modes), T248, TX, TS-XW, TS-PC, T-GT II (shows up as a T300).
    /// Commands go out as HID report 0x60 (64 bytes). Effects are uploaded per effect id (byte 2, from 1) and started or
    /// stopped by id; one code byte says what each packet is. Layout as documented by the Linux hid-tmff2 driver (its
    /// author matched the Windows driver's packets); written from that description and not yet checked against a capture.
    /// </summary>
    public sealed class ThrustmasterDecoder : IFfbDecoder
    {
        public string Name => "Thrustmaster (T300RS, T248, TX, TS-XW, TS-PC)";

        public static readonly HashSet<int> ProductIds = new HashSet<int> { 0xB66E, 0xB66F, 0xB66D, 0xB696, 0xB669, 0xB692, 0xB689 };

        enum Kind { None, Constant, Periodic, Ramp, Spring, Resistance }
        sealed class Effect { public Kind Kind; public double Level, Coeff; public bool Playing; }
        readonly Dictionary<int, Effect> _fx = new Dictionary<int, Effect>();
        double _autocenter = double.NaN;

        Effect Fx(int id) { if (!_fx.TryGetValue(id, out var e)) _fx[id] = e = new Effect(); return e; }
        static short S16(byte[] b, int o) => o + 1 < b.Length ? (short)(b[o] | (b[o + 1] << 8)) : (short)0;
        static int U16(byte[] b, int o) => o + 1 < b.Length ? b[o] | (b[o + 1] << 8) : 0;

        public void OnCommand(byte[] b, double time)
        {
            if (b == null || b.Length < 4 || b[0] != 0x60) return;
            if (b[1] != 0x00)
            {
                // set-up commands: 08 03 = auto-centre strength (0 to 0xFFFF); 02 = gain; 08 04 = auto-centre on
                if (b[1] == 0x08 && b[2] == 0x03 && b.Length >= 5) _autocenter = U16(b, 3) / 65535.0;
                return;
            }
            var e = Fx(b[2]);
            switch (b[3])
            {
                case 0x6A: // constant force, upload or change: level at 4 (the Windows driver's range is about +-16384)
                    e.Kind = Kind.Constant; e.Level = Math.Max(-1, Math.Min(1, S16(b, 4) / 16384.0)); break;
                case 0x6B: // upload a periodic effect (magnitude, offset, phase, period) or a ramp (slope, centre, 0, duration)
                    bool ramp = U16(b, 8) == 0 && U16(b, 10) != 0 && U16(b, 10) == U16(b, 24);
                    if (ramp) { e.Kind = Kind.Ramp; e.Level = Math.Max(-1, Math.Min(1, S16(b, 6) / 16384.0)); }
                    else { e.Kind = Kind.Periodic; e.Level = Math.Min(1, Math.Abs(S16(b, 4)) / 32767.0); }
                    break;
                case 0x6E: // change a periodic effect (type 0F) or a ramp (type 0B)
                    if (b.Length > 4 && b[4] == 0x0F) { e.Kind = Kind.Periodic; e.Level = Math.Min(1, Math.Abs(S16(b, 5)) / 32767.0); }
                    else if (b.Length > 4 && b[4] == 0x0B) { e.Kind = Kind.Ramp; e.Level = Math.Max(-1, Math.Min(1, S16(b, 7) / 16384.0)); }
                    break;
                case 0x64: // upload a condition: coefficients at 4 and 6; type at 28 (06 spring, 07 damper, friction or inertia)
                    e.Kind = b.Length > 28 && b[28] == 0x06 ? Kind.Spring : Kind.Resistance;
                    e.Coeff = Math.Min(1, Math.Max(Math.Abs(S16(b, 4)), Math.Abs(S16(b, 6))) / 32767.0); break;
                case 0x4C: // change a condition: coefficients again, type as uploaded
                    if (e.Kind != Kind.Spring) e.Kind = Kind.Resistance;
                    e.Coeff = Math.Min(1, Math.Max(Math.Abs(S16(b, 4)), Math.Abs(S16(b, 6))) / 32767.0); break;
                case 0x89: // play (41) or stop
                    e.Playing = b.Length > 4 && b[4] == 0x41; break;
            }
        }

        public void Fill(double[] ch)
        {
            double force = 0, spring = 0, resist = 0, vib = 0;
            foreach (var e in _fx.Values.Where(x => x.Playing))
                switch (e.Kind)
                {
                    case Kind.Constant: case Kind.Ramp: force += e.Level; break;
                    case Kind.Periodic: vib = Math.Max(vib, e.Level); break;
                    case Kind.Spring: spring = Math.Max(spring, e.Coeff); break;
                    case Kind.Resistance: resist = Math.Max(resist, e.Coeff); break;
                }
            ch[FfbChannels.Force] = Math.Max(-1, Math.Min(1, force));
            ch[FfbChannels.Spring] = spring;
            ch[FfbChannels.Damper] = resist;          // damper, friction and inertia share one packet type
            ch[FfbChannels.Friction] = double.NaN;
            ch[FfbChannels.Autocenter] = _autocenter;
            ch[FfbChannels.Rumble] = vib;
            ch[FfbChannels.RumbleLarge] = ch[FfbChannels.RumbleSmall] = double.NaN;
        }
    }

    /// <summary>
    /// Fanatec wheel bases (CSL Elite, CSL DD, DD Pro, ClubSport DD, Podium DD1 and DD2, ClubSport V2 and V2.5, CSR Elite) in
    /// PC mode. Seven-byte commands, each setting one slot: byte 0 = slot &lt;&lt; 4 | 1 (| 2 switches the slot off), byte 1 =
    /// the effect: 08 constant force (byte 2, 0x80 = none; on newer bases a 16-bit level in bytes 2-3 with byte 6 = 01),
    /// 0B spring (strength byte 6), 0C damper, inertia or friction (slots 2, 3, 4). F8 09 01 03 sets the rim's rumble.
    /// Layout as documented by the Linux hid-fanatecff driver; not yet checked against a capture from Fanatec's own driver.
    /// </summary>
    public sealed class FanatecDecoder : IFfbDecoder
    {
        public string Name => "Fanatec (CSL, DD, ClubSport, Podium)";

        public static readonly HashSet<int> ProductIds = new HashSet<int> { 0x0001, 0x0004, 0x0005, 0x0006, 0x0007, 0x0011, 0x0020, 0x0E03, 0x0197 };

        readonly double[] _slot = new double[5];   // constant level, spring, damper, inertia, friction
        double _rumble;

        static bool IsCommand(byte[] b, int o) =>
            b.Length >= o + 7 && (b[o] == 0xF8 || b[o] == 0xF5 ||
                ((b[o] >> 4) <= 4 && ((b[o] & 0x0F) == 0x01 || (b[o] & 0x0F) == 0x03) && (b[o + 1] == 0x08 || b[o + 1] == 0x0B || b[o + 1] == 0x0C)));

        public void OnCommand(byte[] b, double time)
        {
            if (b == null) return;
            // the command may follow a report ID byte
            int o = IsCommand(b, 0) ? 0 : IsCommand(b, 1) ? 1 : -1;
            if (o < 0) return;
            byte c0 = b[o], c1 = b[o + 1];
            if (c0 == 0xF8)
            {
                if (c1 == 0x09 && b[o + 2] == 0x01 && b[o + 3] == 0x03) _rumble = Math.Max(b[o + 4], Math.Max(b[o + 5], b[o + 6])) / 255.0;
                return;
            }
            if (c0 == 0xF5) return;
            int slot = c0 >> 4;
            bool off = (c0 & 0x02) != 0;
            double v;
            switch (c1)
            {
                case 0x08:
                    v = b[o + 6] == 0x01 ? ((b[o + 2] | (b[o + 3] << 8)) - 0x8000) / 32768.0 : (b[o + 2] - 0x80) / 128.0;
                    _slot[0] = off ? 0 : Math.Max(-1, Math.Min(1, v)); break;
                case 0x0B:
                    if (slot < 5) _slot[slot] = off ? 0 : b[o + 6] / 255.0; break;
                case 0x0C:
                    int k = Math.Max(b[o + 2], b[o + 4]);
                    v = k <= 15 ? k / 15.0 : k / 255.0;
                    if (slot < 5) _slot[slot] = off ? 0 : v; break;
            }
        }

        public void Fill(double[] ch)
        {
            ch[FfbChannels.Force] = _slot[0];
            ch[FfbChannels.Spring] = _slot[1];
            ch[FfbChannels.Damper] = Math.Max(_slot[2], _slot[3]);
            ch[FfbChannels.Friction] = _slot[4];
            ch[FfbChannels.Autocenter] = double.NaN;
            ch[FfbChannels.Rumble] = _rumble;
            ch[FfbChannels.RumbleLarge] = ch[FfbChannels.RumbleSmall] = double.NaN;
        }
    }

    /// <summary>
    /// Logitech wheels that use HID++ 2.0 for force feedback: G920, G923 Xbox edition, G PRO, RS50. Messages are HID++
    /// long reports (11 or 12, device index, feature index, function &lt;&lt; 4 | software id, parameters). The force
    /// feedback feature (0x8123) has its own index on each wheel, so the decoder takes the feature that carries effect
    /// downloads. Function 2 downloads an effect (byte 4 slot, 0 = new; byte 5 type: 00 constant, 01-05 periodic, 06 spring,
    /// 07 damper, 08 friction, 09 inertia, 0A ramp; level big-endian at bytes 10-11), function 3 plays (02) or stops (01)
    /// a slot, function 4 frees it, function 1 resets all. The wheel answers a new download with its slot. Layout as
    /// documented by the Linux hid-logitech-hidpp driver; not yet checked against a capture.
    /// </summary>
    public sealed class LogitechHidppDecoder : IFfbDecoder, IFfbDeviceSink
    {
        public string Name => "Logitech HID++ (G920, G923 Xbox, G PRO, RS50)";

        public static readonly HashSet<int> ProductIds = new HashSet<int> { 0xC262, 0xC26D, 0xC26E, 0xC272, 0xC268, 0xC276 };

        sealed class Effect { public int Type; public double Level, Coeff; public bool Playing; }
        readonly Dictionary<int, Effect> _slots = new Dictionary<int, Effect>();
        readonly Queue<Effect> _awaitingSlot = new Queue<Effect>();
        int _feature = -1;

        static bool IsHidpp(byte[] b) => b != null && b.Length >= 7 && (b[0] == 0x11 || b[0] == 0x12);
        static short S16BE(byte[] b, int o) => o + 1 < b.Length ? (short)((b[o] << 8) | b[o + 1]) : (short)0;

        public void OnCommand(byte[] b, double time)
        {
            if (!IsHidpp(b)) return;
            int feat = b[2], func = b[3] >> 4;
            if (_feature < 0)
            {
                // learn the force feedback feature: the one carrying effect downloads with a known effect type
                // (an effect download is 14 to 20 bytes of parameters after the 4-byte header)
                if (func == 2 && b.Length >= 18 && (b[5] & 0x7F) <= 0x0A) _feature = feat;
                if (_feature < 0) return;
            }
            if (feat != _feature) return;
            switch (func)
            {
                case 1: _slots.Clear(); _awaitingSlot.Clear(); break;
                case 2:
                {
                    int slot = b[4], type = b[5] & 0x7F;
                    var e = slot != 0 && _slots.TryGetValue(slot, out var old) ? old : new Effect();
                    e.Type = type;
                    if ((b[5] & 0x80) != 0) e.Playing = true;   // autostart
                    if (type == 0x00 || type == 0x0A) e.Level = Math.Max(-1, Math.Min(1, S16BE(b, 10) / 32767.0));
                    else if (type >= 0x01 && type <= 0x05) e.Level = Math.Min(1, Math.Abs(S16BE(b, 10)) / 32767.0);
                    else if (type >= 0x06 && type <= 0x09)
                        e.Coeff = Math.Min(1, Math.Max(Math.Abs(S16BE(b, 12)), b.Length > 19 ? Math.Abs(S16BE(b, 18)) : 0) / 32767.0);
                    if (slot != 0) _slots[slot] = e; else _awaitingSlot.Enqueue(e);
                    break;
                }
                case 3:
                    if (_slots.TryGetValue(b[4], out var p)) p.Playing = b[5] == 0x02;
                    break;
                case 4: _slots.Remove(b[4]); break;
            }
        }

        public void OnDeviceReport(byte[] b, double time)
        {
            // the answer to a new download carries the slot it went to
            if (!IsHidpp(b) || b[2] != _feature || (b[3] >> 4) != 2 || _awaitingSlot.Count == 0) return;
            if (b[4] != 0) _slots[b[4]] = _awaitingSlot.Dequeue();
        }

        public void Fill(double[] ch)
        {
            double force = 0, spring = 0, damper = 0, friction = 0, vib = 0;
            foreach (var e in _slots.Values.Where(x => x.Playing))
                switch (e.Type)
                {
                    case 0x00: case 0x0A: force += e.Level; break;
                    case 0x06: spring = Math.Max(spring, e.Coeff); break;
                    case 0x07: case 0x09: damper = Math.Max(damper, e.Coeff); break;
                    case 0x08: friction = Math.Max(friction, e.Coeff); break;
                    default: vib = Math.Max(vib, e.Level); break;
                }
            ch[FfbChannels.Force] = Math.Max(-1, Math.Min(1, force));
            ch[FfbChannels.Spring] = spring;
            ch[FfbChannels.Damper] = damper;
            ch[FfbChannels.Friction] = friction;
            ch[FfbChannels.Autocenter] = double.NaN;
            ch[FfbChannels.Rumble] = vib;
            ch[FfbChannels.RumbleLarge] = ch[FfbChannels.RumbleSmall] = double.NaN;
        }
    }
}
