using System;
using System.Collections.Generic;
using System.Linq;

namespace TeknoTelemetry.Core.Ffb
{
    /// <summary>
    /// The USB force feedback values as rows in a game's table (wheel_force = ffb_force and so on).
    /// Game profiles don't ship with them; the settings page adds or removes them on request.
    /// A row counts as one of these when it's a computed row whose formula is just the channel
    /// (ffb_force), whatever it's called, so renamed rows are still recognised and user rows are
    /// never touched.
    /// </summary>
    public static class FfbTableRows
    {
        /// <summary>The channels offered: forces, rumble, and the wheel's own steering and pedals.
        /// Not activity, connected or the raw bytes, which are diagnostics.</summary>
        public static readonly int[] Channels =
        {
            FfbChannels.Force, FfbChannels.Spring, FfbChannels.Damper, FfbChannels.Friction, FfbChannels.Autocenter,
            FfbChannels.Rumble, FfbChannels.RumbleLarge, FfbChannels.RumbleSmall,
            FfbChannels.Steer, FfbChannels.Throttle, FfbChannels.Brake, FfbChannels.Clutch,
        };

        public static string DefaultName(int channel) => "wheel_" + FfbChannels.Names[channel];

        /// <summary>The channel a row shows, or -1 if it isn't one of these rows.</summary>
        public static int ChannelOf(VariableDef v)
        {
            if (v == null || v.Source != SourceKind.Computed) return -1;
            var f = (v.Formula ?? "").Trim();
            foreach (var ch in Channels)
                if (string.Equals(f, FfbChannels.Identifier(ch), StringComparison.OrdinalIgnoreCase)) return ch;
            return -1;
        }

        public static int CountPresent(GameProfile p) =>
            p == null ? 0 : p.Variables.Select(ChannelOf).Where(c => c >= 0).Distinct().Count();

        public static bool AllPresent(GameProfile p) => p != null && CountPresent(p) == Channels.Length;

        public static VariableDef MakeRow(int channel, string name) => new VariableDef
        {
            Name = name,
            Enabled = true,
            Source = SourceKind.Computed,
            Type = MemType.Float,
            Formula = FfbChannels.Identifier(channel),
            Notes = "From USB capture (all games): " + FfbChannels.Descriptions[channel] +
                    ". Shows - unless USB capture is on. Added by 'Add FFB values to table'.",
        };

        /// <summary>Appends a row for each channel not already shown. Returns how many were added.</summary>
        public static int AddMissing(GameProfile p)
        {
            var have = new HashSet<int>(p.Variables.Select(ChannelOf).Where(c => c >= 0));
            int added = 0;
            foreach (var ch in Channels)
            {
                if (have.Contains(ch)) continue;
                p.Variables.Add(MakeRow(ch, UniqueName(p, DefaultName(ch))));
                added++;
            }
            return added;
        }

        /// <summary>Removes every row that just shows a USB channel. Returns how many were removed.</summary>
        public static int RemoveAll(GameProfile p) => p.Variables.RemoveAll(v => ChannelOf(v) >= 0);

        static string UniqueName(GameProfile p, string baseName)
        {
            var n = baseName; int i = 2;
            while (p.Variables.Any(v => string.Equals(Names.Sanitise(v.Name), Names.Sanitise(n), StringComparison.OrdinalIgnoreCase)))
                n = baseName + "_" + i++;
            return n;
        }
    }
}
