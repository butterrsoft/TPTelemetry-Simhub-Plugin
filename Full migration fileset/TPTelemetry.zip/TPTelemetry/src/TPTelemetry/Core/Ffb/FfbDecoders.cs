using System;
using System.Collections.Generic;
using System.Linq;

namespace TeknoTelemetry.Core.Ffb
{
    /// <summary>Values published from force feedback capture. Order matters: it's the index into
    /// the channel array. Formulas use these as ffb_force, ffb_spring, ...</summary>
    public static class FfbChannels
    {
        public const int Force = 0, Spring = 1, Damper = 2, Friction = 3, Autocenter = 4, Rumble = 5,
                         RumbleLarge = 6, RumbleSmall = 7, Steer = 8, Throttle = 9, Brake = 10, Clutch = 11,
                         Activity = 12, Connected = 13, Raw0 = 14, RawCount = 8;
        public static readonly int Count = Raw0 + RawCount;

        public static readonly string[] Names = BuildNames();
        static string[] BuildNames()
        {
            var n = new List<string> { "force", "spring", "damper", "friction", "autocenter", "rumble", "rumble_large", "rumble_small",
                                       "steer", "throttle", "brake", "clutch", "activity", "connected" };
            for (int i = 0; i < RawCount; i++) n.Add("raw" + i);
            return n.ToArray();
        }

        public static readonly string[] Descriptions =
        {
            "constant force on the wheel, -1 to 1 (0 when none)",
            "centring spring strength, 0 to 1",
            "damper strength, 0 to 1",
            "friction strength, 0 to 1",
            "the wheel's own auto-centre strength, 0 to 1",
            "rumble or vibration strength, 0 to 1 (strongest motor; 1 while a wheel vibration effect plays)",
            "large (low-frequency) rumble motor, 0 to 1",
            "small (high-frequency) rumble motor, 0 to 1",
            "steering position read from the wheel, -1 full left to 1 full right (G25 so far)",
            "throttle pedal read from the wheel, 0 to 1 (G25 so far)",
            "brake pedal read from the wheel, 0 to 1 (G25 so far)",
            "clutch pedal read from the wheel, 0 to 1 (G25 so far)",
            "commands sent to the wheel per second",
            "1 while capturing from the device",
            "bytes of the last command (raw0 to raw7), for working out unsupported wheels",
        };

        /// <summary>Formula identifier for a channel, e.g. "ffb_force".</summary>
        public static string Identifier(int i) => "ffb_" + Names[i];

        public static int? FromIdentifier(string ident)
        {
            if (ident == null || !ident.StartsWith("ffb_", StringComparison.OrdinalIgnoreCase)) return null;
            var n = ident.Substring(4);
            for (int i = 0; i < Names.Length; i++)
                if (string.Equals(Names[i], n, StringComparison.OrdinalIgnoreCase)) return i;
            return null;
        }
    }

    /// <summary>Turns commands sent to a wheel into channel values.</summary>
    public interface IFfbDecoder
    {
        string Name { get; }
        void OnCommand(byte[] payload, double time);
        /// <summary>Writes Force..RumbleSmall (others are filled in by the capture).</summary>
        void Fill(double[] channels);
    }

    /// <summary>Unknown wheels: no interpretation, only activity and raw bytes.</summary>
    public sealed class RawDecoder : IFfbDecoder
    {
        public string Name => "Raw (bytes only)";
        public void OnCommand(byte[] payload, double time) { }
        public void Fill(double[] c)
        {
            for (int i = FfbChannels.Force; i <= FfbChannels.RumbleSmall; i++) c[i] = double.NaN;
        }
    }

    /// <summary>
    /// Logitech "classic" force feedback protocol: G25, G27, Driving Force GT / Pro / EX, Momo,
    /// Formula Force. Seven-byte commands to the interrupt OUT endpoint. The wheel holds up to four
    /// effects in slots; the first byte is (slot mask &lt;&lt; 4) | command. Layout as documented by the
    /// Linux hid-lg4ff driver and Logitech's classic protocol notes, and checked against a G25
    /// capture from WMMT3DX+.
    /// </summary>
    public sealed class LogitechClassicDecoder : IFfbDecoder
    {
        public string Name => "Logitech classic (G25, G27, G29, G923 PS, DFGT, DFP, Momo)";

        /// <summary>USB product IDs of wheels that use this protocol (vendor 046D).</summary>
        public static readonly HashSet<int> ProductIds = new HashSet<int>
        {
            0xC293, // Formula Force GP
            0xC294, // Driving Force / Formula Force EX (compatibility mode for most Logitech wheels)
            0xC295, // Momo Force
            0xC298, // Driving Force Pro
            0xC299, // G25
            0xC29A, // Driving Force GT
            0xC29B, // G27
            0xCA03, // Momo Racing
            0xCA04, // Formula Vibration Feedback
            0xC24F, // G29 (PS3/PC mode; 0.21.0, the same protocol as in the Linux lg4ff driver, not yet checked)
            0xC266, // G923 for PlayStation and PC (0.21.0, not yet checked)
            0xC267, // G923 for PlayStation and PC, PC mode (0.21.0, not yet checked)
        };

        // effect types (second byte)
        const byte Constant = 0x00, Spring = 0x01, Damper = 0x02, AutoSpring = 0x03,
                   Variable = 0x08, Ramp = 0x09, HiSpring = 0x0B, HiDamper = 0x0C, HiAutoSpring = 0x0D, Friction = 0x0E;

        sealed class Slot { public bool Loaded, Playing; public byte[] P = new byte[7]; public int Index; }
        readonly Slot[] _slots = Enumerable.Range(0, 4).Select(i => new Slot { Index = i }).ToArray();
        double _autocenter;      // from the wheel's own auto-centre commands
        bool _autocenterOn;

        public void OnCommand(byte[] b, double time)
        {
            if (b == null || b.Length < 2) return;
            byte c = b[0];

            // auto-centre and extended commands
            if (c == 0xFE)
            {
                // FE 0D k1 k2 clip: auto-centre strength (FE 03 on the Formula Force EX)
                if ((b[1] == 0x0D || b[1] == 0x03) && b.Length >= 5) _autocenter = b[4] / 255.0;
                return;
            }
            if (c == 0xF8) return; // extended: range, mode switch, LEDs

            int mask = c >> 4, cmd = c & 0x0F;
            switch (cmd)
            {
                case 0x0: Download(mask, b, play: null); break;   // download, keep play state
                case 0x1: Download(mask, b, play: true); break;   // download and play
                case 0x2: SetPlay(mask, true); break;
                case 0x3: SetPlay(mask, false); break;
                case 0x4: _autocenterOn = true; break;            // default spring on
                case 0x5: _autocenterOn = false; break;           // default spring off
                case 0x8: Download(mask, b, play: null); break;   // refresh a playing effect
            }
        }

        void Download(int mask, byte[] b, bool? play)
        {
            foreach (var s in _slots)
            {
                if ((mask & (1 << s.Index)) == 0) continue;
                Array.Clear(s.P, 0, s.P.Length);
                Buffer.BlockCopy(b, 0, s.P, 0, Math.Min(7, b.Length));
                s.Loaded = true;
                if (play.HasValue) s.Playing = play.Value;
            }
        }

        void SetPlay(int mask, bool on)
        {
            foreach (var s in _slots) if ((mask & (1 << s.Index)) != 0) s.Playing = on && s.Loaded;
        }

        static double Level(byte v) => Math.Max(-1, Math.Min(1, (v - 0x80) / 127.0));

        public void Fill(double[] ch)
        {
            double force = 0, spring = 0, damper = 0, friction = 0, vib = 0, slotAuto = 0;
            foreach (var s in _slots)
            {
                if (!s.Playing) continue;
                var p = s.P;
                switch (p[1])
                {
                    case Constant: force += Level(p[2 + s.Index]); break; // one level byte per slot
                    case Variable: force += Level(p[2]); break;           // L1
                    case Ramp: force += Level(p[2]); break;               // approximation: start level
                    case Spring:
                    case HiSpring: spring = Math.Max(spring, p[6] / 255.0); break; // clip = maximum spring force
                    case Damper: damper = Math.Max(damper, Math.Max(p[2] & 7, p[4] & 7) / 7.0); break;
                    case HiDamper: damper = Math.Max(damper, Math.Max(p[2] & 15, p[4] & 15) / 15.0); break;
                    case Friction: friction = Math.Max(friction, p[4] / 255.0); break;
                    case AutoSpring:
                    case HiAutoSpring: slotAuto = Math.Max(slotAuto, p[4] / 255.0); break;
                    default: vib = 1; break; // square, triangle, sawtooth, trapezoid: amplitude not decoded yet
                }
            }
            ch[FfbChannels.Force] = Math.Max(-1, Math.Min(1, force));
            ch[FfbChannels.Spring] = spring;
            ch[FfbChannels.Damper] = damper;
            ch[FfbChannels.Friction] = friction;
            ch[FfbChannels.Autocenter] = Math.Max(slotAuto, _autocenterOn ? _autocenter : 0);
            ch[FfbChannels.Rumble] = vib;
            ch[FfbChannels.RumbleLarge] = double.NaN; // wheels have no separate motors
            ch[FfbChannels.RumbleSmall] = double.NaN;
        }
    }

    /// <summary>
    /// Wired Xbox 360 controllers and the many wheels, pads and arcade sticks that use the same
    /// "XInput" USB protocol. Rumble only: report 00 08 00 large small 00 00 00.
    /// Layout as in the Linux xpad driver; not yet checked against a capture.
    /// </summary>
    public sealed class Xbox360Decoder : IFfbDecoder
    {
        public string Name => "Xbox 360 / XInput rumble";
        double _large, _small;
        public void OnCommand(byte[] b, double time)
        {
            if (b.Length >= 5 && b[0] == 0x00 && b[1] == 0x08) { _large = b[3] / 255.0; _small = b[4] / 255.0; }
        }
        public void Fill(double[] c)
        {
            for (int i = FfbChannels.Force; i <= FfbChannels.Autocenter; i++) c[i] = double.NaN;
            c[FfbChannels.RumbleLarge] = _large; c[FfbChannels.RumbleSmall] = _small;
            c[FfbChannels.Rumble] = Math.Max(_large, _small);
        }
    }

    /// <summary>
    /// Wired Xbox One / Series controllers and devices using their "GIP" protocol. Rumble command:
    /// 09 00 seq 09 00 0F leftTrigger rightTrigger strong weak duration delay repeat.
    /// Layout as in the Linux xpad driver; not yet checked against a capture.
    /// </summary>
    public sealed class XboxOneDecoder : IFfbDecoder
    {
        public string Name => "Xbox One / Series rumble";
        double _large, _small;
        public void OnCommand(byte[] b, double time)
        {
            if (b.Length >= 10 && b[0] == 0x09 && b[3] == 0x09)
            {
                // motor levels as sent by Windows' driver are 0 to 100 (percent)
                _large = Math.Min(1, b[8] / 100.0);
                _small = Math.Min(1, b[9] / 100.0);
            }
        }
        public void Fill(double[] c)
        {
            for (int i = FfbChannels.Force; i <= FfbChannels.Autocenter; i++) c[i] = double.NaN;
            c[FfbChannels.RumbleLarge] = _large; c[FfbChannels.RumbleSmall] = _small;
            c[FfbChannels.Rumble] = Math.Max(_large, _small);
        }
    }

    /// <summary>
    /// The wheel's own reports (steering and pedals) travel in the same capture. Layouts differ per
    /// model and mode, so only models checked against a capture are decoded.
    /// </summary>
    public static class WheelInputDecoder
    {
        /// <returns>false if this model's report layout isn't known.</returns>
        public static bool TryDecode(int vid, int pid, byte[] b, out double steer, out double throttle, out double brake, out double clutch)
        {
            steer = throttle = brake = clutch = double.NaN;
            // Logitech G25 in native mode: 11-byte report; steering 14 bits in bytes 3 (top 6 bits)
            // and 4; pedals in bytes 5-7, 255 = released.
            if (vid == 0x046D && pid == 0xC299 && b.Length == 11)
            {
                int pos = (b[4] << 6) | (b[3] >> 2);
                steer = (pos - 8192) / 8192.0;
                throttle = (255 - b[5]) / 255.0;
                brake = (255 - b[6]) / 255.0;
                clutch = (255 - b[7]) / 255.0;
                return true;
            }
            return false;
        }
    }

    public enum FfbDecoderChoice { Auto = 0, LogitechClassic = 1, Raw = 2, Xbox360 = 3, XboxOne = 4, Thrustmaster = 5, Fanatec = 6, LogitechHidpp = 7, UsbPid = 8 }

    public static class FfbDecoderFactory
    {
        /// <summary>Microsoft (045E) product IDs. Third-party XInput devices have their own IDs:
        /// choose the decoder by hand for those.</summary>
        static readonly HashSet<int> Xbox360Ids = new HashSet<int> { 0x028E };
        static readonly HashSet<int> XboxOneIds = new HashSet<int> { 0x02D1, 0x02DD, 0x02E3, 0x02EA, 0x0B00, 0x0B12, 0x0B13 };

        /// <summary>Finds a USB PID wheel's report layout (on Windows, from Windows' HID parser). Tests replace it.</summary>
        public static Func<int, int, IPidReportSource> PidLayout = (v, p) => WindowsHidPidSource.TryOpen(v, p);

        static IFfbDecoder NewPid(int vendorId, int productId) => new UsbPidDecoder(vendorId == 0 ? null : PidLayout?.Invoke(vendorId, productId));

        public static IFfbDecoder Create(FfbDecoderChoice choice, int vendorId, int productId)
        {
            switch (choice)
            {
                case FfbDecoderChoice.LogitechClassic: return new LogitechClassicDecoder();
                case FfbDecoderChoice.Raw: return new RawDecoder();
                case FfbDecoderChoice.Xbox360: return new Xbox360Decoder();
                case FfbDecoderChoice.XboxOne: return new XboxOneDecoder();
                case FfbDecoderChoice.Thrustmaster: return new ThrustmasterDecoder();
                case FfbDecoderChoice.Fanatec: return new FanatecDecoder();
                case FfbDecoderChoice.LogitechHidpp: return new LogitechHidppDecoder();
                case FfbDecoderChoice.UsbPid: return NewPid(vendorId, productId);
                default:
                    if (vendorId == 0x046D && LogitechClassicDecoder.ProductIds.Contains(productId)) return new LogitechClassicDecoder();
                    if (vendorId == 0x046D && LogitechHidppDecoder.ProductIds.Contains(productId)) return new LogitechHidppDecoder();
                    if (vendorId == 0x044F && ThrustmasterDecoder.ProductIds.Contains(productId)) return new ThrustmasterDecoder();
                    if (vendorId == 0x0EB7 && FanatecDecoder.ProductIds.Contains(productId)) return new FanatecDecoder();
                    if (UsbPidDecoder.IsPidWheel(vendorId, productId)) return NewPid(vendorId, productId);
                    if (vendorId == 0x045E && Xbox360Ids.Contains(productId)) return new Xbox360Decoder();
                    if (vendorId == 0x045E && XboxOneIds.Contains(productId)) return new XboxOneDecoder();
                    return new RawDecoder();
            }
        }
    }

    /// <summary>
    /// Feeds USB packets from one device into a decoder and keeps the channel values.
    /// Single-threaded: call from the capture thread, read with <see cref="Snapshot"/>.
    /// </summary>
    public sealed class FfbPipeline
    {
        readonly FfbDecoderChoice _choice;
        readonly int _device;
        IFfbDecoder _decoder;
        readonly Queue<double> _recent = new Queue<double>();
        readonly double[] _ch = new double[FfbChannels.Count];
        readonly object _sync = new object();
        double _lastTime;
        readonly Func<double> _clock;

        public int VendorId { get; private set; }
        public int ProductId { get; private set; }
        public string DecoderName => _decoder?.Name ?? "waiting for device";
        public long Commands { get; private set; }

        /// <param name="device">USB device address to follow, or 0 for any.</param>
        /// <param name="clock">Seconds, for the commands-per-second count. Defaults to a stopwatch.</param>
        public FfbPipeline(FfbDecoderChoice choice, int device, Func<double> clock = null)
        {
            _choice = choice; _device = device;
            if (clock == null) { var sw = System.Diagnostics.Stopwatch.StartNew(); clock = () => sw.Elapsed.TotalSeconds; }
            _clock = clock;
            if (choice != FfbDecoderChoice.Auto) _decoder = FfbDecoderFactory.Create(choice, 0, 0);
            for (int i = 0; i < _ch.Length; i++) _ch[i] = double.NaN;
        }

        public void OnPacket(UsbPacket p)
        {
            if (_device != 0 && p.Device != _device) return;
            _lastTime = p.Time;

            // Device descriptor (injected at capture start): pick the decoder from vendor/product.
            if (p.Transfer == 2 && p.FromDevice && p.Payload.Length >= 12 && p.Payload[0] == 0x12 && p.Payload[1] == 0x01)
            {
                VendorId = p.Payload[8] | (p.Payload[9] << 8);
                ProductId = p.Payload[10] | (p.Payload[11] << 8);
                if (_choice == FfbDecoderChoice.Auto) lock (_sync) _decoder = FfbDecoderFactory.Create(_choice, VendorId, ProductId);
                return;
            }

            // Control transfers (0.21.0): output reports some wheels take as SET_REPORT, and the HID report descriptor
            // (a USB PID wheel's layout) when the capture sees the wheel being plugged in.
            if (p.Transfer == 2)
            {
                if (!p.FromDevice && p.Payload.Length >= 8 && (p.Stage == 0 || p.Stage < 0 && (p.Payload[0] == 0x21 || p.Payload[0] == 0x81)))
                {
                    byte rt = p.Payload[0], req = p.Payload[1], hi = p.Payload[3];
                    _pendingDescriptor = rt == 0x81 && req == 0x06 && hi == 0x22;
                    _pendingSetReport = rt == 0x21 && req == 0x09 && (hi == 2 || hi == 3);
                    if (_pendingSetReport && p.Payload.Length > 8)
                    {
                        _pendingSetReport = false;
                        var rep = new byte[p.Payload.Length - 8];
                        Buffer.BlockCopy(p.Payload, 8, rep, 0, rep.Length);
                        Command(rep, p.Time);
                    }
                    return;
                }
                if (!p.FromDevice && _pendingSetReport && p.Payload.Length > 0) { _pendingSetReport = false; Command(p.Payload, p.Time); return; }
                if (p.FromDevice && _pendingDescriptor && p.Payload.Length > 0)
                {
                    _pendingDescriptor = false;
                    if (_decoder == null) lock (_sync) _decoder = FfbDecoderFactory.Create(_choice, VendorId, ProductId);
                    if (_decoder is IFfbDescriptorSink sink) lock (_sync) sink.SetReportDescriptor(p.Payload);
                    return;
                }
                return;
            }

            // the wheel's own input report: steering and pedals
            if (p.FromDevice && (p.Endpoint & 0x80) != 0 && p.Transfer == 1 && p.Payload.Length > 0)
            {
                if (_decoder is IFfbDeviceSink dev) lock (_sync) dev.OnDeviceReport(p.Payload, p.Time);
                if (WheelInputDecoder.TryDecode(VendorId, ProductId, p.Payload, out var st, out var th, out var br, out var cl))
                    lock (_sync)
                    {
                        _ch[FfbChannels.Steer] = st; _ch[FfbChannels.Throttle] = th;
                        _ch[FfbChannels.Brake] = br; _ch[FfbChannels.Clutch] = cl;
                    }
                return;
            }

            if (!p.IsHostToDeviceData) return; // FFB goes over interrupt/bulk OUT (or SET_REPORT, above)
            Command(p.Payload, p.Time);
        }

        bool _pendingDescriptor, _pendingSetReport;

        void Command(byte[] payload, double time)
        {
            if (_decoder == null) lock (_sync) _decoder = FfbDecoderFactory.Create(_choice, VendorId, ProductId);
            lock (_sync) _decoder.OnCommand(payload, time);
            Commands++;

            lock (_sync)
            {
                _recent.Enqueue(_clock());
                _decoder.Fill(_ch);
                for (int i = 0; i < FfbChannels.RawCount; i++)
                    _ch[FfbChannels.Raw0 + i] = i < payload.Length ? payload[i] : double.NaN;
            }
        }

        /// <summary>Copies current values (thread-safe).</summary>
        public void Snapshot(double[] into, bool connected)
        {
            int recent;
            lock (_sync)
            {
                var now = _clock();
                while (_recent.Count > 0 && now - _recent.Peek() > 1.0) _recent.Dequeue();
                recent = _recent.Count;
                if (_decoder != null && Commands == 0) _decoder.Fill(_ch);
                Array.Copy(_ch, into, Math.Min(into.Length, _ch.Length));
            }
            if (into.Length > FfbChannels.Activity) into[FfbChannels.Activity] = recent;
            if (into.Length > FfbChannels.Connected) into[FfbChannels.Connected] = connected ? 1 : 0;
        }

        public double LastPacketTime => _lastTime;
    }
}
