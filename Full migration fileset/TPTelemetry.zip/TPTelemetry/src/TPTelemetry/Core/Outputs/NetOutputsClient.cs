using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace TeknoTelemetry.Core.Outputs
{
    public class OutputsSettings
    {
        public bool Enabled { get; set; } = true;
        public string Host { get; set; } = "127.0.0.1";
        public int Port { get; set; } = 8000;
    }

    /// <summary>
    /// Client for MAME's network output protocol ("-output network" in MAME; also OutputBlaster for
    /// TeknoParrot games with OutputsSystem=1, Supermodel, and Flycast with "Broadcast Digital Outputs"
    /// on, which sends hexadecimal values after a "game = id" line). The server sends text lines
    /// "name = value" ending in CR (or CR LF), plus "mame_start = game", "mame_stop = 1" and
    /// "pause = 0/1". Outputs are lamps, LEDs, motors, digit displays and the like, 0-255 or 0/1.
    /// </summary>
    public sealed class NetOutputsClient : IDisposable
    {
        readonly ConcurrentDictionary<string, double> _values = new ConcurrentDictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        // "Intake_Left" -> "Intake Left": names with spaces, as formulas have to write them
        readonly ConcurrentDictionary<string, string> _bySafeName = new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        Thread _thread;
        volatile bool _stop;
        volatile TcpClient _client;
        OutputsSettings _settings = new OutputsSettings();

        public string Status { get; private set; } = "Off";
        public string Game { get; private set; } = "";
        public bool Paused { get; private set; }
        public bool Connected { get; private set; }

        /// <summary>Raised (on the client thread) the first time an output name is seen.</summary>
        public event Action<string> NewOutput;

        /// <summary>Value of an output, NaN if it hasn't been sent (yet).</summary>
        /// <summary>Value of an output, by its name as the game sends it ("Intake Left") or as formulas
        /// and SimHub properties spell it ("Intake_Left").</summary>
        public double Get(string name)
        {
            if (name == null) return double.NaN;
            if (_values.TryGetValue(name, out var v)) return v;
            return _bySafeName.TryGetValue(name, out var raw) && _values.TryGetValue(raw, out v) ? v : double.NaN;
        }

        public IReadOnlyList<KeyValuePair<string, double>> All() =>
            _values.OrderBy(kv => kv.Key, StringComparer.OrdinalIgnoreCase).ToList();

        public void Apply(OutputsSettings s)
        {
            s = s ?? new OutputsSettings();
            bool restart = _thread == null || s.Enabled != _settings.Enabled || s.Host != _settings.Host || s.Port != _settings.Port;
            _settings = new OutputsSettings { Enabled = s.Enabled, Host = s.Host, Port = s.Port };
            if (!restart) return;
            StopThread();
            if (!_settings.Enabled) { Status = "Off"; return; }
            _stop = false;
            _thread = new Thread(Run) { IsBackground = true, Name = "TPTelemetry outputs" };
            _thread.Start();
        }

        void Run()
        {
            while (!_stop)
            {
                try
                {
                    Status = $"Looking for outputs on {_settings.Host}:{_settings.Port}";
                    using (var c = new TcpClient())
                    {
                        _client = c;
                        var ar = c.BeginConnect(_settings.Host, _settings.Port, null, null);
                        if (!ar.AsyncWaitHandle.WaitOne(1500) || !c.Connected) { c.Close(); Sleep(2000); continue; }
                        c.EndConnect(ar);
                        Connected = true;
                        Status = $"Connected to {_settings.Host}:{_settings.Port}";
                        Log.Info("Outputs: " + Status);
                        HexValues = false;
                        ReadLines(c.GetStream());
                    }
                }
                catch (Exception e)
                {
                    // Stopping closes the socket under ReadLines, which throws here: never let that escape the
                    // thread, or it takes SimHub down with it.
                    if (!_stop) Status = "Outputs connection lost: " + e.Message;
                }
                finally
                {
                    Connected = false;
                    _client = null;
                }
                if (!_stop) { Game = ""; Sleep(2000); }
            }
        }

        void ReadLines(Stream s)
        {
            var buf = new byte[4096];
            var line = new StringBuilder();
            while (!_stop)
            {
                int n = s.Read(buf, 0, buf.Length);
                if (n <= 0) { Status = "The game closed its outputs"; return; }
                for (int i = 0; i < n; i++)
                {
                    char ch = (char)buf[i];
                    if (ch == '\r' || ch == '\n')
                    {
                        if (line.Length > 0) Handle(line.ToString());
                        line.Clear();
                    }
                    else if (line.Length < 512) line.Append(ch);
                }
            }
        }

        /// <summary>True once the server has said it is Flycast (a "game = id" line): Flycast sends its
        /// values in hexadecimal ("awffb = 1a"), where MAME, Supermodel and OutputBlaster send decimal.</summary>
        public bool HexValues { get; private set; }

        /// <summary>Handles one protocol line. Public for tests.</summary>
        public void Handle(string line)
        {
            int eq = line.IndexOf('=');
            if (eq <= 0) return; // e.g. "id:Name" lines
            var name = line.Substring(0, eq).Trim();
            var val = line.Substring(eq + 1).Trim();
            switch (name.ToLowerInvariant())
            {
                case "mame_start":
                    Game = val; Paused = false; _values.Clear(); _bySafeName.Clear();
                    Status = $"Connected: {val}";
                    Log.Info("Outputs: game " + val);
                    return;
                case "mame_stop":
                    Status = "Game stopped"; Game = "";
                    return;
                case "pause":
                    Paused = val == "1";
                    return;
                case "game":
                    // Flycast's first line ("game = INITIAL D Ver.3" or a rom id); its values are hexadecimal.
                    Game = val; Paused = false; HexValues = true; _values.Clear(); _bySafeName.Clear();
                    Status = $"Connected (Flycast): {val}";
                    Log.Info("Outputs: Flycast game " + val);
                    return;
            }
            double v;
            if (HexValues)
            {
                if (!long.TryParse(val, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out var h)) return;
                v = h;
            }
            else if (!double.TryParse(val, NumberStyles.Float, CultureInfo.InvariantCulture, out v)) return;
            bool isNew = !_values.ContainsKey(name);
            if (isNew) _bySafeName[Names.Sanitise(name)] = name;
            _values[name] = v;
            if (isNew) { try { NewOutput?.Invoke(name); } catch (Exception e) { Log.Error("NewOutput " + name, e); } }
        }

        void Sleep(int ms)
        {
            for (int t = 0; t < ms && !_stop; t += 100) Thread.Sleep(100);
        }

        void StopThread()
        {
            _stop = true;
            try { _client?.Close(); } catch { }
            _thread?.Join(2000);
            _thread = null;
            Connected = false;
        }

        public void Dispose() => StopThread();
    }
}
