using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using TeknoTelemetry.Core.Ffb;

namespace TeknoTelemetry.Core
{
    /// <summary>
    /// The common values every game feeds, published as TPTelemetry.Car_&lt;name&gt; whichever game is
    /// selected, so one set of SimHub effects (the "TP Telemetry" profile) works for every game.
    ///
    /// A game provides them through rows named car_&lt;source&gt; (e.g. car_impact, car_speed), usually
    /// unticked, whose formulas map the game's own rows onto an agreed meaning and range (see
    /// <see cref="Sources"/>). This class turns those into the published values: it gates event values
    /// by car_in_race, divides speed and revs by the game's Max speed and Max revs (silent when those are
    /// blank), and works out pulses (gear change, landing), the rev limiter stutter and left/right sides.
    /// A game without a particular row reads 0 for everything built on it.
    /// Since 0.20.0 also dashboard values (speed in km/h and mph, clocks, laps, position, pedals; never gated) and the common
    /// lamps, published as TPTelemetry.Lamp_&lt;name&gt; from rows named lamp_&lt;name&gt;, whatever the race state.
    /// </summary>
    public sealed class CommonValues
    {
        /// <summary>The rows a game can provide, without the car_ prefix, and what they must hold.</summary>
        public static readonly (string Name, string Meaning)[] Sources =
        {
            ("in_race", "1 while racing (not menus or attract mode). If missing: 1 while the game is attached"),
            ("speed", "speed in the game's own units (raw, not divided by Max speed)"),
            ("rpm", "engine revs (raw RPM, not divided by Max revs)"),
            ("gear", "gear, 1 = first (0 or less = neutral or reverse)"),
            ("accel_g", "forward G: + speeding up, - slowing down"),
            ("impact", "a hit, 0 to 1 (about 0.6 for an ordinary hit, 1 for a big crash)"),
            ("impact_side", "side of the hit: -1 left to 1 right, 0 unknown or straight on"),
            ("wall_contact", "-1 scraping a wall on the left, 1 on the right, 0 none (in between: how hard)"),
            ("road_bump", "short bumps and joints, 0 to 1"),
            ("rumble_strip", "1 on a ripple strip or kerb"),
            ("off_road", "rough ground or off the track, 0 to 1"),
            ("grip_loss", "sliding, 0 gripping to 1"),
            ("cornering", "cornering load, -1 to 1: + turning right, - turning left"),
            ("airborne", "1 while in the air"),
            ("boost", "boost or nitro, 0 to 1"),
            ("vibration", "the game's own rumble or vibration command, 0 to 1"),
            ("throttle", "throttle pedal, 0 to 1. If missing, the engine effects don't change with the throttle"),
            ("rpm_frac", "revs as a fraction of the car's own limiter, 0 to 1 (0.17.0). If missing: revs / Max revs"),
            ("drift", "drifting: how far sideways the car is going, 0 gripping to 1 a big drift (0.18.0). If missing: |drift_angle| / 40 degrees"),
            ("drift_angle", "drift angle, degrees: between where the car points and where it is going, + pointing right of its path (0.18.0)"),
            // dashboard values (0.20.0): shown as the game gives them, never gated by in_race
            ("speed_kmh", "speed in km/h (the profile converts from the game's units). If missing: Car_speed_kmh and Car_speed_mph read 0"),
            ("rev_limit_rpm", "this car's rev limit, RPM. If missing: Max revs"),
            ("position", "race position, 1 = first; 0 when there is none"),
            ("lap", "the lap you are on, 1 = the first lap; 0 when there is none"),
            ("laps_total", "laps in the race; 0 when unknown"),
            ("time_left", "time left on the clock (RT), seconds"),
            ("race_time", "the race clock (TT), seconds from GO"),
            ("lap_time", "the current lap's (or stage's) time, seconds"),
            ("brake", "brake pedal, 0 to 1"),
            ("steer", "steering, -1 full left to 1 full right"),
            ("gap", "distance to the rival, metres: + ahead, - behind"),
        };

        /// <summary>Published values, without the Car_ prefix. Raw ones (speed, rpm, gear, accel_g,
        /// impact_side, wall_contact, cornering, drift_angle) aren't gated, for gauges and dashboards; everything else
        /// is 0 outside a race.</summary>
        public static readonly (string Name, string Meaning)[] Outputs =
        {
            ("in_race", "1 while racing"),
            ("speed", "speed, raw (the game's units)"),
            ("rpm", "engine RPM, raw"),
            ("gear", "gear"),
            ("accel_g", "forward G, raw"),
            ("speed_frac", "speed / Max speed, 0 to 1 (0 while Max speed is blank)"),
            ("rpm_frac", "revs / Max revs, 0 to 1 (0 while Max revs is blank)"),
            ("engine", "engine vibration strength: 0 when off, 0.35 at idle rising to 1 at Max revs; off the throttle 60% of that (games with a throttle value)"),
            ("engine_hz", "engine vibration pitch, 25 Hz at idle to 60 Hz at Max revs"),
            ("rev_limit", "rev limiter stutter: pulses 8 times a second at 97% of Max revs and above"),
            ("road", "road texture: speed_frac, cut while airborne"),
            ("shift", "1 for 0.15 s after a gear change"),
            ("impact", "hit, 0 to 1"),
            ("impact_left", "hit felt on the left: the full hit for a left or unknown side, 30% for a right-hand hit"),
            ("impact_right", "hit felt on the right: the full hit for a right or unknown side, 30% for a left-hand hit"),
            ("impact_side", "side of the last hit, -1 to 1, raw"),
            ("wall_contact", "-1, 0 or 1, raw"),
            ("wall_left", "scraping a wall on the left, 0 to 1"),
            ("wall_right", "scraping a wall on the right, 0 to 1"),
            ("road_bump", "bumps and joints, 0 to 1"),
            ("rumble_strip", "1 on a ripple strip"),
            ("off_road", "rough ground, 0 to 1"),
            ("grip_loss", "sliding, 0 to 1; a game with no slip value of its own gives its drift here too (0.18.0)"),
            ("drift", "drifting, 0 to 1 (0.18.0)"),
            ("drift_angle", "drift angle, degrees, + pointing right of the car's path, raw (0.18.0)"),
            ("braking", "braking cue: slowing at 1.5 G or more reads 1"),
            ("accelerating", "acceleration cue: speeding up at 0.8 G or more reads 1"),
            ("cornering", "cornering load, -1 to 1, raw"),
            ("corner_left", "cornering load felt on the left (turning right), 0 to 1"),
            ("corner_right", "cornering load felt on the right (turning left), 0 to 1"),
            ("airborne", "1 while in the air"),
            ("landed", "pulse for 0.25 s after landing: 0.4 after a brief lift, rising to 1 after 0.25 s or more in the air"),
            ("boost", "boost, 0 to 1"),
            ("vibration", "the game's own rumble, 0 to 1"),
            ("throttle", "throttle pedal, 0 to 1 (0 for games without one)"),
            ("usb", "1 while some of these come from the force a wheel got over USB, because the game has no value for them"),
            // dashboard values (0.20.0): not gated by in_race (a profile may still read 0 outside a race, as the game or Alexis wants)
            ("speed_kmh", "speed, km/h (0 for a game whose speed units aren't known)"),
            ("speed_mph", "speed, mph (Car_speed_kmh / 1.609344)"),
            ("max_speed", "the game's Max speed setting (in the units of Car_speed; 0 while blank)"),
            ("max_revs", "the game's Max revs setting, RPM (0 while blank)"),
            ("rev_limit_rpm", "this car's rev limit, RPM, where the game gives it; else Max revs"),
            ("rpm_dial", "revs / Max revs, 0 to 1, for a rev counter's needle (0 while Max revs is blank)"),
            ("position", "race position, 1 = first (0 when there is none)"),
            ("lap", "the lap you are on, 1 = the first lap"),
            ("laps_total", "laps in the race (0 when unknown)"),
            ("final_lap", "1 on the final lap (the same as Lamp_final_lap)"),
            ("time_left", "time left (RT), seconds"),
            ("race_time", "race clock (TT), seconds"),
            ("lap_time", "the current lap's or stage's time, seconds"),
            ("brake", "brake pedal, 0 to 1"),
            ("steer", "steering, -1 full left to 1 full right"),
            ("gap", "distance to the rival, metres: + ahead, - behind"),
        };

        /// <summary>Common lamps (0.20.0): a profile's rows named lamp_&lt;name&gt; are published as TPTelemetry.Lamp_&lt;name&gt;, 0 to 1,
        /// whatever the race state (a cabinet lights its lamps in the attract mode and menus too). A game without a row reads 0, or
        /// the stand-in given here.</summary>
        public static readonly (string Name, string Meaning)[] Lamps =
        {
            ("start", "the Start button"),
            ("view", "any view (camera) button. If missing: whichever of view1 to view4 is brightest"),
            ("view1", "view button 1"),
            ("view2", "view button 2"),
            ("view3", "view button 3"),
            ("view4", "view button 4"),
            ("select_up", "menu select button up"),
            ("select_down", "menu select button down"),
            ("select_left", "menu select button left"),
            ("select_right", "menu select button right"),
            ("action", "the cabinet's extra button (WMMT's interruption button, GTI Club's action button)"),
            ("leader", "in the lead (the game's own leader lamp, or made from the position). If missing: racing in 1st place, for a game with Car_position"),
            ("checkpoint", "a checkpoint passed or time extended, held 1 to 2 s"),
            ("final_lap", "on the final lap"),
            ("shift", "shift or over-rev light. If missing: racing at 90% of the car's limiter or more (Car_rpm_frac 0.9)"),
            ("warning", "any on-screen warning: WRONG WAY, Brake!, SHIFT UP"),
            ("boost", "boost or nitro. If missing: Car_boost 0.9 or more"),
            ("red", "the cabinet's main red lamp or LED"),
            ("green", "the cabinet's main green lamp or LED"),
            ("blue", "the cabinet's main blue lamp or LED"),
            ("white", "the cabinet's main white lamp or LED"),
            ("marquee", "billboard, marquee, side or seat lighting"),
            ("brake", "brake light. If missing: Car_brake 0.1 or more"),
        };

        /// <summary>The force-based values a game's missing rows can be worked out from the USB capture of the
        /// force sent to the wheel (0.15.0): the same rules the pack uses for games whose only force is the
        /// wheel force (force kicks for hits and bumps, the sustained force for cornering, the rumble motors).</summary>
        public static readonly string[] UsbStandIns = { "impact", "impact_side", "road_bump", "cornering", "vibration" };
        public const double UsbSmoothSeconds = 0.15, UsbKickAt = 0.5;
        /// <summary>A game hit without a side (impact_side 0) takes the side of a USB force kick up to this
        /// many seconds before or during it (0.16.0; OutRun 2's wall hit side is sometimes 0).</summary>
        public const double UsbSideSeconds = 0.3;

        /// <summary>Fill missing force-based values from the USB capture (setting "Use the wheel's force for
        /// effects a game has no values for", on by default). Has no effect while USB capture is off.</summary>
        public bool UsbStandIn { get; set; } = true;

        public const string RowPrefix = "car_";
        public const string PropertyPrefix = "Car_";
        public const string LampRowPrefix = "lamp_";
        public const string LampPropertyPrefix = "Lamp_";
        /// <summary>Lamp stand-ins (0.20.0): the shift light at this share of the car's limiter, the boost lamp at this boost, the
        /// brake light at this much brake.</summary>
        public const double ShiftLampAt = 0.9, BoostLampAt = 0.9, BrakeLampAt = 0.1;
        public const double KmhPerMph = 1.609344;
        public const double RevLimitAt = 0.97;
        public const double ShiftSeconds = 0.15, LandedSeconds = 0.25;
        /// <summary>Landing strength: LandedMin after the briefest lift, 1 after LandedFullAir seconds or more in the air.</summary>
        public const double LandedMin = 0.4, LandedFullAir = 0.25;
        public const double EngineIdle = 0.35, EngineLowHz = 25, EngineHighHz = 60;
        /// <summary>Engine load: the engine effects run at this share of their strength with the throttle off,
        /// rising to full at full throttle (only for games with a car_throttle row).</summary>
        public const double EngineOffThrottle = 0.6;
        /// <summary>A drift angle this big or more reads Car_drift 1 (games that give an angle but no drift row; 0.18.0).</summary>
        public const double DriftFullAngle = 40;

        readonly double[] _out = new double[Outputs.Length];
        readonly double[] _lamp = new double[Lamps.Length];
        int[] _lampSrc = new int[Lamps.Length];
        volatile string _gearText = "";
        readonly Dictionary<string, int> _outIndex = Outputs.Select((o, i) => (o.Name, i)).ToDictionary(x => x.Name, x => x.i, StringComparer.OrdinalIgnoreCase);

        // per profile: which var holds each car_ source (-1 = none)
        ProfileState _for;
        int[] _src = new int[Sources.Length];
        // state for pulses
        double _lastGear = double.NaN, _shiftUntil = double.NegativeInfinity, _landedUntil = double.NegativeInfinity;
        bool _wasAirborne;
        // USB stand-in state
        double _usbSmooth = double.NaN, _usbLastT = double.NaN, _usbKickSide, _usbKickT = double.NegativeInfinity;
        double _airSince = double.NaN, _landedStrength;

        public static int OutputIndex(string name) => Array.FindIndex(Outputs, o => o.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

        /// <summary>Latest value of an output (any thread). 0 when there's no value.</summary>
        public double Get(int i) => Interlocked.CompareExchange(ref _out[i], 0, 0);
        public double Get(string name) => _outIndex.TryGetValue(name, out var i) ? Get(i) : 0;
        public static int LampIndex(string name) => Array.FindIndex(Lamps, o => o.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        /// <summary>Latest value of a common lamp (any thread), 0 to 1.</summary>
        public double GetLamp(int i) => Interlocked.CompareExchange(ref _lamp[i], 0, 0);
        public double GetLamp(string name) { int i = LampIndex(name); return i < 0 ? 0 : GetLamp(i); }
        /// <summary>The gear as a dashboard shows it (0.20.0): "R" below 0, "N" at 0, else the number; "" for a game with no gear.</summary>
        public string GearText => _gearText;

        /// <summary>Works out every value from the selected game's car_ rows. Call once per tick, after
        /// the game's rows are evaluated. <paramref name="p"/> null (no game selected) zeroes everything.</summary>
        public void Update(ProfileState p, double t)
        {
            var v = new double[Outputs.Length];
            var lv = new double[Lamps.Length];
            if (p == null) { _for = null; Reset(); Publish(v, lv, ""); return; }
            if (!ReferenceEquals(p, _for)) { Map(p); Reset(); }

            // USB stand-in: the force the wheel got, smoothed and split into kicks as the pack's force rows do.
            var ffb = p.Ctx.Ffb;
            double uf = UsbStandIn && ffb != null && ffb.Length > FfbChannels.Connected && ffb[FfbChannels.Connected] == 1 ? ffb[FfbChannels.Force] : double.NaN;
            var usbVal = new Dictionary<string, double>();
            if (double.IsNaN(uf) || double.IsInfinity(uf)) _usbSmooth = double.NaN;
            else
            {
                double dt = double.IsNaN(_usbLastT) ? 0 : Math.Max(0, t - _usbLastT);
                _usbSmooth = double.IsNaN(_usbSmooth) ? uf : _usbSmooth + (1 - Math.Exp(-dt / UsbSmoothSeconds)) * (uf - _usbSmooth);
                double kick = Math.Max(0, Math.Min(1, Math.Abs(uf - _usbSmooth) * 2));
                usbVal["impact"] = kick > UsbKickAt ? (kick - UsbKickAt) / (1 - UsbKickAt) : 0;
                usbVal["impact_side"] = kick > UsbKickAt ? Math.Sign(uf) : 0;
                if (kick > UsbKickAt && uf != 0) { _usbKickSide = Math.Sign(uf); _usbKickT = t; }
                usbVal["road_bump"] = kick <= UsbKickAt ? kick / UsbKickAt : 0;
                usbVal["cornering"] = Math.Max(-1, Math.Min(1, _usbSmooth));
                double rumble = ffb[FfbChannels.Rumble];
                usbVal["vibration"] = double.IsNaN(rumble) ? 0 : rumble;
            }
            _usbLastT = t;
            bool usbUsed = false;


            double S(string name)
            {
                int k = Array.FindIndex(Sources, s => s.Name == name);
                int idx = _src[k];
                if (idx < 0)
                {
                    if (usbVal.TryGetValue(name, out var u)) { usbUsed = true; return u; }
                    return double.NaN;
                }
                var x = p.Vars[idx].Output;
                return double.IsInfinity(x) ? double.NaN : x;
            }
            double Z(double x) => double.IsNaN(x) ? 0 : x;
            double Clamp01(double x) => double.IsNaN(x) ? 0 : Math.Max(0, Math.Min(1, x));

            bool connected = p.Connected;
            double inRaceRaw = S("in_race");
            bool inRace = connected && (_src[0] < 0 || (!double.IsNaN(inRaceRaw) && inRaceRaw != 0));
            double gate = inRace ? 1 : 0;

            double speed = S("speed"), rpm = S("rpm"), gear = S("gear"), accel = S("accel_g");
            double maxSpeed = p.Def.MaxSpeed is double ms && ms >= GameProfile.MinReference ? ms : double.NaN;
            double maxRevs = p.Def.MaxRevs is double mr && mr >= GameProfile.MinReference ? mr : double.NaN;
            double speedFrac = double.IsNaN(maxSpeed) ? 0 : Clamp01(Math.Abs(Z(speed)) / maxSpeed) * gate;
            // A game that knows each car's limiter gives car_rpm_frac (0.17.0), so the rev limiter and engine effects
            // follow every car; otherwise revs over the game's Max revs.
            double rpmFracRow = S("rpm_frac");
            double rpmFrac = !double.IsNaN(rpmFracRow) ? Clamp01(rpmFracRow) * gate
                           : double.IsNaN(maxRevs) ? 0 : Clamp01(Z(rpm) / maxRevs) * gate;
            double airborne = Clamp01(S("airborne")) * gate;
            double throttleRaw = S("throttle");
            double load = double.IsNaN(throttleRaw) ? 1 : EngineOffThrottle + (1 - EngineOffThrottle) * Clamp01(throttleRaw);

            // gear change pulse: a change between two real gears (or to/from neutral) while racing
            if (!double.IsNaN(gear) && !double.IsNaN(_lastGear) && gear != _lastGear && inRace) _shiftUntil = t + ShiftSeconds;
            if (!double.IsNaN(gear)) _lastGear = gear;
            // landing pulse
            bool air = airborne > 0.5;
            if (air && !_wasAirborne) _airSince = t;
            if (_wasAirborne && !air && inRace)
            {
                // a longer time in the air lands harder (WMMT5DX+: crests with the wheels down 0.1 s or less, rear wheels off 0.2 to 0.5 s)
                double flight = double.IsNaN(_airSince) ? 0 : t - _airSince;
                _landedStrength = LandedMin + (1 - LandedMin) * Math.Max(0, Math.Min(1, flight / LandedFullAir));
                _landedUntil = t + LandedSeconds;
            }
            _wasAirborne = air;

            double impact = Clamp01(S("impact")) * gate;
            double side = Z(S("impact_side"));
            // a hit the game gives no side for: the side of the wheel force's kick, if the USB capture saw one
            if (impact > 0 && side == 0 && UsbStandIn && !double.IsNaN(uf) && t - _usbKickT <= UsbSideSeconds) { side = _usbKickSide; usbUsed = true; }
            double wall = Z(S("wall_contact"));
            double cornering = Math.Max(-1, Math.Min(1, Z(S("cornering"))));
            // drifting (0.18.0): the game's own drift row, else the size of its drift angle; and where the game has no slip
            // value of its own, its drift is the grip loss too (Alexis, 9 November 2026)
            double driftAngle = S("drift_angle"), driftRow = S("drift");
            double drift = (!double.IsNaN(driftRow) ? Clamp01(driftRow) : double.IsNaN(driftAngle) ? 0 : Clamp01(Math.Abs(driftAngle) / DriftFullAngle)) * gate;
            double gripRow = S("grip_loss");
            double grip = !double.IsNaN(gripRow) ? Clamp01(gripRow) * gate : drift;

            void Set(string n, double x) => v[_outIndex[n]] = double.IsNaN(x) || double.IsInfinity(x) ? 0 : x;
            Set("in_race", gate);
            Set("speed", Z(speed));
            Set("rpm", Z(rpm));
            Set("gear", Z(gear));
            Set("accel_g", Z(accel));
            Set("speed_frac", speedFrac);
            Set("rpm_frac", rpmFrac);
            Set("engine", rpmFrac > 0 ? (EngineIdle + (1 - EngineIdle) * rpmFrac) * load : 0);
            Set("engine_hz", EngineLowHz + (EngineHighHz - EngineLowHz) * rpmFrac);
            Set("rev_limit", rpmFrac >= RevLimitAt && ((long)Math.Floor(t * 16)) % 2 == 0 ? 1 : 0);
            Set("road", speedFrac * (1 - airborne));
            Set("shift", t < _shiftUntil ? gate : 0);
            Set("impact", impact);
            Set("impact_left", side > 0 ? impact * 0.3 : impact);
            Set("impact_right", side < 0 ? impact * 0.3 : impact);
            Set("impact_side", side);
            Set("wall_contact", wall);
            Set("wall_left", Clamp01(-wall) * gate);
            Set("wall_right", Clamp01(wall) * gate);
            Set("road_bump", Clamp01(S("road_bump")) * gate);
            Set("rumble_strip", Clamp01(S("rumble_strip")) * gate);
            Set("off_road", Clamp01(S("off_road")) * gate);
            Set("grip_loss", grip);
            Set("drift", drift);
            Set("drift_angle", Z(driftAngle));
            Set("braking", Clamp01(-Z(accel) / 1.5) * gate);
            Set("accelerating", Clamp01(Z(accel) / 0.8) * gate);
            Set("cornering", cornering);
            Set("corner_left", Math.Max(0, cornering) * gate);
            Set("corner_right", Math.Max(0, -cornering) * gate);
            Set("airborne", airborne);
            Set("landed", t < _landedUntil ? _landedStrength * gate : 0);
            Set("boost", Clamp01(S("boost")) * gate);
            Set("vibration", Clamp01(S("vibration")) * gate);
            Set("throttle", Clamp01(throttleRaw) * gate);
            Set("usb", usbUsed ? 1 : 0);

            // dashboard values (0.20.0): as the game gives them, not gated
            double kmh = S("speed_kmh");
            Set("speed_kmh", Math.Abs(Z(kmh)));
            Set("speed_mph", Math.Abs(Z(kmh)) / KmhPerMph);
            Set("max_speed", Z(maxSpeed));
            Set("max_revs", Z(maxRevs));
            double limit = S("rev_limit_rpm");
            Set("rev_limit_rpm", !double.IsNaN(limit) && limit > 0 ? limit : Z(maxRevs));
            Set("rpm_dial", double.IsNaN(maxRevs) ? 0 : Clamp01(Z(rpm) / maxRevs));
            double position = Z(S("position"));
            Set("position", position);
            Set("lap", Z(S("lap")));
            Set("laps_total", Z(S("laps_total")));
            Set("time_left", Z(S("time_left")));
            Set("race_time", Z(S("race_time")));
            Set("lap_time", Z(S("lap_time")));
            double brake = Clamp01(S("brake"));
            Set("brake", brake);
            Set("steer", Math.Max(-1, Math.Min(1, Z(S("steer")))));
            Set("gap", Z(S("gap")));

            // common lamps (0.20.0): never gated; a few stand-ins made from the values above
            double L(string name)
            {
                int k = LampIndex(name), idx = _lampSrc[k];
                if (idx < 0) return double.NaN;
                var x = p.Vars[idx].Output;
                return double.IsNaN(x) || double.IsInfinity(x) ? 0 : Clamp01(x);
            }
            for (int k = 0; k < Lamps.Length; k++) lv[k] = Z(L(Lamps[k].Name));
            void Stand(string name, double x) { int k = LampIndex(name); if (_lampSrc[k] < 0) lv[k] = Clamp01(x); }
            Stand("view", new[] { "view1", "view2", "view3", "view4" }.Max(n => lv[LampIndex(n)]));
            Stand("leader", inRace && _src[SourceIndex("position")] >= 0 && position == 1 ? 1 : 0);
            Stand("shift", rpmFrac >= ShiftLampAt ? 1 : 0);
            Stand("boost", v[_outIndex["boost"]] >= BoostLampAt ? 1 : 0);
            Stand("brake", brake >= BrakeLampAt ? 1 : 0);
            Set("final_lap", lv[LampIndex("final_lap")]);

            string gearText = _src[SourceIndex("gear")] < 0 || double.IsNaN(gear) ? "" : gear < 0 ? "R" : gear == 0 ? "N" : Math.Round(gear).ToString(System.Globalization.CultureInfo.InvariantCulture);
            Publish(v, lv, gearText);
        }

        static int SourceIndex(string name) => Array.FindIndex(Sources, s => s.Name == name);

        void Map(ProfileState p)
        {
            _for = p;
            for (int k = 0; k < Sources.Length; k++)
            {
                var want = RowPrefix + Sources[k].Name;
                _src[k] = Array.FindIndex(p.Vars, x => !x.HasConfigError && string.Equals(Names.Sanitise(x.Def.Name), want, StringComparison.OrdinalIgnoreCase));
            }
            for (int k = 0; k < Lamps.Length; k++)
            {
                var want = LampRowPrefix + Lamps[k].Name;
                _lampSrc[k] = Array.FindIndex(p.Vars, x => !x.HasConfigError && string.Equals(Names.Sanitise(x.Def.Name), want, StringComparison.OrdinalIgnoreCase));
            }
        }

        void Reset()
        {
            _lastGear = double.NaN; _shiftUntil = _landedUntil = double.NegativeInfinity; _wasAirborne = false; _airSince = double.NaN; _landedStrength = 0; _usbSmooth = double.NaN; _usbLastT = double.NaN; _usbKickSide = 0; _usbKickT = double.NegativeInfinity;
        }

        void Publish(double[] v, double[] lv, string gearText)
        {
            for (int i = 0; i < v.Length; i++) Interlocked.Exchange(ref _out[i], v[i]);
            for (int i = 0; i < lv.Length; i++) Interlocked.Exchange(ref _lamp[i], lv[i]);
            _gearText = gearText;
        }

        /// <summary>Which car_ rows a profile has (for the settings page and docs).</summary>
        public static IEnumerable<string> ProvidedBy(GameProfile p) =>
            Sources.Select(s => s.Name).Where(n => p.Variables.Any(v => string.Equals(Names.Sanitise(v.Name), RowPrefix + n, StringComparison.OrdinalIgnoreCase)));

        /// <summary>Which lamp_ rows a profile has (0.20.0).</summary>
        public static IEnumerable<string> LampsProvidedBy(GameProfile p) =>
            Lamps.Select(s => s.Name).Where(n => p.Variables.Any(v => string.Equals(Names.Sanitise(v.Name), LampRowPrefix + n, StringComparison.OrdinalIgnoreCase)));
    }
}
