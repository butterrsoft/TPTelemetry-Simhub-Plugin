using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace TeknoTelemetry.Core
{
    /// <summary>
    /// Read-only access to another process's memory. Opened with PROCESS_VM_READ only,
    /// never writes.
    ///
    /// Module lookup uses Toolhelp32 with TH32CS_SNAPMODULE32 because if SimHub is 64-bit and
    /// most TeknoParrot games are 32-bit: System.Diagnostics.Process.Modules only lists the
    /// 64-bit WOW64 modules in that case, so "BudgieLoader.exe"+X would never resolve.
    /// </summary>
    /// <summary>A game process the helper can read: memory access plus whether it's still running.</summary>
    public interface IGameReader : IMemoryReader, IDisposable
    {
        bool HasExited { get; }
    }

    /// <summary>The game is 64-bit and this process is 32-bit (SimHub), so it has to be read
    /// through the 64-bit helper. Carries the PID that was found.</summary>
    public sealed class Target64BitException : InvalidOperationException
    {
        public int Pid { get; }
        public string ProcessName { get; }
        public Target64BitException(int pid, string processName)
            : base("Target is 64-bit but SimHub is running as 32-bit; can't read it.")
        { Pid = pid; ProcessName = processName; }
    }

    public sealed class ProcessMemory : IGameReader
    {
        public int Pid { get; }
        public string ProcessName { get; }
        public bool Is32Bit { get; }
        public int PointerSize => Is32Bit ? 4 : 8;

        IntPtr _handle;
        readonly Dictionary<string, long> _modules = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        long _mainBase;

        /// <summary>Module name meaning the process's own executable, whatever it's called. Lets a profile
        /// use addresses relative to the game's exe before anyone knows the exe's name.</summary>
        public const string MainModule = "<main>";
        readonly byte[] _buf = new byte[8];
        readonly Stopwatch _lastRescan = new Stopwatch();

        ProcessMemory(int pid, string name, IntPtr handle, bool is32)
        {
            Pid = pid; ProcessName = name; _handle = handle; Is32Bit = is32;
        }

        /// <summary>Finds a running process by name ("BudgieLoader.exe" or "BudgieLoader") and opens it.
        /// When several are running (an old copy of the game can hang on after it was closed), opens the
        /// newest. Returns null if not running. Throws Win32Exception if it is running but can't be opened
        /// (usually: the game runs as administrator and SimHub doesn't).</summary>
        public static ProcessMemory TryOpen(string processName)
        {
            var pid = NewestPid(processName);
            return pid == null ? null : Open(pid.Value, processName, "SimHub");
        }

        /// <summary>The PID of the newest running process with this name, or null if none is running.</summary>
        public static int? NewestPid(string processName)
        {
            if (string.IsNullOrWhiteSpace(processName)) return null;
            var bare = Path.GetFileNameWithoutExtension(processName.Trim());
            var procs = Process.GetProcessesByName(bare);
            try
            {
                var found = new List<(int Pid, DateTime? Start)>();
                foreach (var p in procs)
                {
                    // HasExited and StartTime need query rights. A game running as administrator refuses them to
                    // a non-admin SimHub, so keep it (start unknown) and let OpenProcess give the clear error.
                    try { if (p.HasExited) continue; }
                    catch (Win32Exception) { }
                    catch (InvalidOperationException) { continue; }
                    DateTime? start = null;
                    try { start = p.StartTime; } catch (Exception) { }
                    found.Add((p.Id, start));
                }
                return PickNewest(found);
            }
            finally
            {
                foreach (var p in procs) p.Dispose();
            }
        }

        /// <summary>Picks the newest process: the latest start time; ones whose start time can't be read come
        /// after those that can (ties go to the higher PID). Null for none.</summary>
        public static int? PickNewest(IEnumerable<(int Pid, DateTime? Start)> procs)
        {
            int? best = null; DateTime? bestStart = null;
            foreach (var (pid, start) in procs)
            {
                bool better = best == null
                    || (start.HasValue && (!bestStart.HasValue || start.Value > bestStart.Value
                                           || (start.Value == bestStart.Value && pid > best.Value)))
                    || (!start.HasValue && !bestStart.HasValue && pid > best.Value);
                if (better) { best = pid; bestStart = start; }
            }
            return best;
        }

        /// <summary>Opens a process the plugin already found, by PID (the 64-bit helper uses this).
        /// Returns null if it has gone, or if the PID now belongs to a different program.</summary>
        public static ProcessMemory OpenPid(int pid, string processName)
        {
            try
            {
                using (var p = Process.GetProcessById(pid))
                {
                    var bare = Path.GetFileNameWithoutExtension((processName ?? "").Trim());
                    if (!string.Equals(p.ProcessName, bare, StringComparison.OrdinalIgnoreCase)) return null;
                }
            }
            catch (ArgumentException) { return null; }          // not running
            catch (InvalidOperationException) { return null; }  // exited meanwhile
            var pm = Open(pid, processName, "the 64-bit helper");
            if (pm.HasExited) { pm.Dispose(); return null; }
            return pm;
        }

        /// <summary>Read and query rights only. Throws <see cref="Target64BitException"/> when the game is
        /// 64-bit and this process is 32-bit.</summary>
        static ProcessMemory Open(int pid, string processName, string reader)
        {
            var h = Native.OpenProcess(Native.PROCESS_VM_READ | Native.PROCESS_QUERY_INFORMATION, false, pid);
            if (h == IntPtr.Zero)
                h = Native.OpenProcess(Native.PROCESS_VM_READ | Native.PROCESS_QUERY_LIMITED_INFORMATION, false, pid);
            if (h == IntPtr.Zero)
            {
                var err = Marshal.GetLastWin32Error();
                throw new Win32Exception(err, err == 5
                    ? $"{processName} is running, but Windows won't let {reader} read it: the game is running as administrator and SimHub isn't. Run SimHub as administrator too."
                    : $"Can't open {processName} (PID {pid}): {new Win32Exception(err).Message}");
            }

            bool is32 = !Environment.Is64BitOperatingSystem
                        || (Native.IsWow64Process(h, out var wow) && wow);
            if (is32 == false && !Environment.Is64BitProcess)
            {
                Native.CloseHandle(h);
                throw new Target64BitException(pid, processName);
            }
            var pm = new ProcessMemory(pid, processName, h, is32);
            pm.RefreshModules();
            return pm;
        }

        public bool HasExited
        {
            get
            {
                if (_handle == IntPtr.Zero) return true;
                if (!Native.GetExitCodeProcess(_handle, out var code)) return true;
                return code != Native.STILL_ACTIVE;
            }
        }

        public void RefreshModules()
        {
            _modules.Clear();
            _mainBase = 0;
            var snap = Native.CreateToolhelp32Snapshot(Native.TH32CS_SNAPMODULE | Native.TH32CS_SNAPMODULE32, (uint)Pid);
            if (snap == Native.INVALID_HANDLE_VALUE) return; // can fail transiently while the process is starting
            try
            {
                var me = new Native.MODULEENTRY32W { dwSize = (uint)Marshal.SizeOf(typeof(Native.MODULEENTRY32W)) };
                if (!Native.Module32FirstW(snap, ref me)) return;
                do
                {
                    // Toolhelp lists the executable first.
                    if (_mainBase == 0) _mainBase = ToAddress(me.modBaseAddr);
                    if (!_modules.ContainsKey(me.szModule))
                        _modules[me.szModule] = ToAddress(me.modBaseAddr);
                } while (Native.Module32NextW(snap, ref me));
            }
            finally { Native.CloseHandle(snap); }
        }

        public IReadOnlyDictionary<string, long> Modules => _modules;

        public bool TryGetModuleBase(string module, out long baseAddr)
        {
            if (string.Equals(module, MainModule, StringComparison.OrdinalIgnoreCase))
            {
                if (_mainBase == 0 && (!_lastRescan.IsRunning || _lastRescan.ElapsedMilliseconds >= 1000))
                {
                    _lastRescan.Restart();
                    RefreshModules();
                }
                baseAddr = _mainBase;
                return baseAddr != 0;
            }
            if (_modules.TryGetValue(module, out baseAddr)) return true;
            // Late-loaded DLLs (TeknoParrot.dll is injected after start): rescan, at most once a second.
            if (_lastRescan.IsRunning && _lastRescan.ElapsedMilliseconds < 1000) return false;
            _lastRescan.Restart();
            RefreshModules();
            return _modules.TryGetValue(module, out baseAddr);
        }

        public bool TryRead(long address, int size, byte[] into)
        {
            if (_handle == IntPtr.Zero || address <= 0) return false;
            if (IntPtr.Size == 4 && address > uint.MaxValue) return false; // unreachable from 32-bit SimHub
            return Native.ReadProcessMemory(_handle, ToIntPtr(address), into, new IntPtr(size), out var read)
                   && read.ToInt64() == size;
        }

        public bool TryReadPointer(long address, out long value)
        {
            value = 0;
            if (!TryRead(address, PointerSize, _buf)) return false;
            value = Is32Bit ? BitConverter.ToUInt32(_buf, 0) : BitConverter.ToInt64(_buf, 0);
            return value != 0;
        }

        public bool TryReadValue(long address, MemType type, out double value)
        {
            value = double.NaN;
            int size = MemTypes.Size(type);
            if (!TryRead(address, size, _buf)) return false;
            value = MemTypes.Decode(type, _buf);
            return true;
        }

        // SimHub 9.x is a 32-bit process, where IntPtr is a signed 32-bit number. Game addresses
        // above 0x7FFFFFFF (common: TeknoParrot games are large-address-aware) must be converted
        // bit-for-bit, or new IntPtr(long) throws OverflowException and ToInt64() goes negative.
        static IntPtr ToIntPtr(long address) =>
            IntPtr.Size == 4 ? new IntPtr(unchecked((int)(uint)address)) : new IntPtr(address);

        static long ToAddress(IntPtr p) =>
            IntPtr.Size == 4 ? unchecked((long)(uint)p.ToInt32()) : p.ToInt64();

        public void Dispose()
        {
            if (_handle != IntPtr.Zero) { Native.CloseHandle(_handle); _handle = IntPtr.Zero; }
        }

        static class Native
        {
            public const uint PROCESS_VM_READ = 0x0010;
            public const uint PROCESS_QUERY_INFORMATION = 0x0400;
            public const uint PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;
            public const uint TH32CS_SNAPMODULE = 0x00000008;
            public const uint TH32CS_SNAPMODULE32 = 0x00000010;
            public const uint STILL_ACTIVE = 259;
            public static readonly IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1);

            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern IntPtr OpenProcess(uint access, bool inherit, int pid);

            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern bool ReadProcessMemory(IntPtr hProcess, IntPtr baseAddress, [Out] byte[] buffer, IntPtr size, out IntPtr read);

            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern bool CloseHandle(IntPtr h);

            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern bool IsWow64Process(IntPtr hProcess, out bool wow64);

            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern bool GetExitCodeProcess(IntPtr hProcess, out uint code);

            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern IntPtr CreateToolhelp32Snapshot(uint flags, uint pid);

            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
            public struct MODULEENTRY32W
            {
                public uint dwSize;
                public uint th32ModuleID;
                public uint th32ProcessID;
                public uint GlblcntUsage;
                public uint ProccntUsage;
                public IntPtr modBaseAddr;
                public uint modBaseSize;
                public IntPtr hModule;
                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string szModule;
                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string szExePath;
            }

            [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
            public static extern bool Module32FirstW(IntPtr snap, ref MODULEENTRY32W me);

            [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
            public static extern bool Module32NextW(IntPtr snap, ref MODULEENTRY32W me);
        }
    }
}
