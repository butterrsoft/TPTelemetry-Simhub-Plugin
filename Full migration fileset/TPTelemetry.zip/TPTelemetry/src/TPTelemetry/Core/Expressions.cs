using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace TeknoTelemetry.Core.Expressions
{
    /// <summary>Per-tick inputs to a formula.</summary>
    public sealed class EvalContext
    {
        /// <summary>Raw value read for the variable being evaluated (NaN for computed variables).</summary>
        public double Value;
        /// <summary>Seconds since the previous tick.</summary>
        public double Dt;
        /// <summary>Seconds since the game was attached. Monotonic, high resolution.</summary>
        public double T;
        /// <summary>Current-tick outputs of all variables in the profile, by slot.</summary>
        public double[] Slots;
        /// <summary>Force feedback channels (see FfbChannels), or null/NaN when not capturing.</summary>
        public double[] Ffb;
        /// <summary>TeknoParrot shared memory slots (see TpChannels), or null/NaN when unavailable.</summary>
        public double[] Tp;
        /// <summary>Looks up a game output (lamp etc.) by name; NaN if unknown.</summary>
        public Func<string, double> Output;
        /// <summary>The game's top speed and redline (max_speed, max_revs); 1 when not set.</summary>
        public double MaxSpeed = 1, MaxRevs = 1;
    }

    public class FormulaException : Exception
    {
        public int Position { get; }
        public FormulaException(string msg, int pos) : base(pos >= 0 ? $"{msg} (at character {pos + 1})" : msg) { Position = pos; }
    }

    /// <summary>
    /// A compiled formula. Instances hold state for time-series functions (slope, ema, ...),
    /// so each variable gets its own instance and it must be evaluated exactly once per tick.
    /// </summary>
    public sealed class Formula
    {
        readonly Node _root;
        public string Source { get; }
        public IReadOnlyCollection<int> Dependencies { get; }
        public bool UsesValue { get; }
        /// <summary>True if the formula reads any ffb_ channel.</summary>
        public bool UsesFfb { get; }
        public bool UsesTp { get; }
        /// <summary>Output names the formula reads (out_...).</summary>
        public IReadOnlyCollection<string> OutputNames { get; }

        Formula(string src, Node root, HashSet<int> deps, bool usesValue, bool usesFfb, bool usesTp, HashSet<string> outputs)
        {
            Source = src; _root = root; Dependencies = deps; UsesValue = usesValue; UsesFfb = usesFfb;
            UsesTp = usesTp; OutputNames = outputs;
        }

        public double Evaluate(EvalContext ctx) => _root.Eval(ctx);

        public static readonly string[] ReservedNames = { "value", "x", "dt", "t", "pi", "g", "true", "false", "max_speed", "max_revs" };

        /// <summary>Names a variable can't have: formula keywords and the ffb_ channels.</summary>
        public static bool IsReservedName(string name) =>
            ReservedNames.Contains(name ?? "", StringComparer.OrdinalIgnoreCase) || Ffb.FfbChannels.FromIdentifier(name) != null ||
            TeknoParrot.TpChannels.FromIdentifier(name) != null ||
            (name ?? "").StartsWith("out_", StringComparison.OrdinalIgnoreCase);

        public static readonly string FunctionHelp =
            "value / x  raw memory value      dt  seconds since last sample      t  seconds since attach\n" +
            "Operators: + - * / % ^  < <= > >= == !=  && || !  cond ? a : b\n" +
            "Maths: abs sign min max clamp(v,lo,hi) round(v[,digits]) floor ceil sqrt pow exp log\n" +
            "       sin cos tan atan2(y,x) hypot(a,b) if(c,a,b) deadzone(v,d) map(v,inLo,inHi,outLo,outHi) valid(v,fallback)\n" +
            "       wrap(angle,period) e.g. wrap(a - b, 360) gives the difference between two headings in -180..180\n" +
            "Time series (stateful): slope(expr,window_s) avg(expr,window_s) ema(expr,tau_s)\n" +
            "       minw(expr,window_s) maxw(expr,window_s) delta(expr) rate(expr) prev(expr)\n" +
            "       unwrap(angle,period) removes the jump at 360 -> 0 so slope() works on headings\n" +
            "       integrate(expr) running total of expr x seconds, e.g. distance from speed\n" +
            "       hold(expr, condition) the last value of expr from when condition was true\n" +
            "Constants: pi, g (9.80665)\n" +
            "Game settings: max_speed, max_revs (the boxes above the table; 1 when blank), e.g. value / max_speed\n" +
            "Force feedback (when capturing): ffb_force ffb_spring ffb_damper ffb_friction ffb_autocenter\n" +
            "       ffb_rumble ffb_rumble_large ffb_rumble_small ffb_steer ffb_throttle ffb_brake ffb_clutch\n" +
            "       ffb_activity ffb_connected ffb_raw0..ffb_raw7\n" +
            "TeknoParrot shared memory: tp_jvs0..tp_jvs15 (32-bit values) tp_connected\n" +
            "Game outputs (lamps etc.): out_<name>, e.g. out_LampStart\n" +
            "Bits: byte(v,n) bits(v,shift,count) band bor bxor shl shr signed8 signed16\n" +
            "Example: longitudinal G from km/h speed:  ema(slope(speed, 0.1), 0.05) / 3.6 / g";

        /// <param name="slotOf">Maps variable names in the same profile to slot indices.</param>
        public static Formula Compile(string source, Func<string, int?> slotOf)
        {
            var p = new Parser(source ?? "", slotOf);
            var root = p.ParseAll();
            return new Formula(source, root, p.Deps, p.UsesValue, p.UsesFfb, p.UsesTp, p.Outputs);
        }

        /// <summary>Lists identifiers in a formula without compiling (for validation messages).</summary>
        public static IEnumerable<string> Identifiers(string source)
        {
            return new Lexer(source ?? "").All().Where(t => t.Kind == TokKind.Ident).Select(t => t.Text);
        }

        #region Lexer
        enum TokKind { Num, Ident, Op, LParen, RParen, Comma, End }

        struct Token
        {
            public TokKind Kind; public string Text; public double Num; public int Pos;
            public override string ToString() => Kind == TokKind.End ? "end of formula" : $"'{Text}'";
        }

        sealed class Lexer
        {
            readonly string _s; int _i;
            public Lexer(string s) { _s = s; }

            public IEnumerable<Token> All()
            {
                while (true)
                {
                    var t = Next();
                    yield return t;
                    if (t.Kind == TokKind.End) yield break;
                }
            }

            public Token Next()
            {
                while (_i < _s.Length && char.IsWhiteSpace(_s[_i])) _i++;
                int start = _i;
                if (_i >= _s.Length) return new Token { Kind = TokKind.End, Pos = _i, Text = "" };
                char c = _s[_i];

                if (char.IsDigit(c) || (c == '.' && _i + 1 < _s.Length && char.IsDigit(_s[_i + 1])))
                {
                    if (c == '0' && _i + 1 < _s.Length && (_s[_i + 1] == 'x' || _s[_i + 1] == 'X'))
                    {
                        _i += 2;
                        while (_i < _s.Length && Uri.IsHexDigit(_s[_i])) _i++;
                        var hex = _s.Substring(start + 2, _i - start - 2);
                        if (hex.Length == 0) throw new FormulaException("Bad hex number", start);
                        return new Token { Kind = TokKind.Num, Num = Convert.ToInt64(hex, 16), Text = _s.Substring(start, _i - start), Pos = start };
                    }
                    while (_i < _s.Length && (char.IsDigit(_s[_i]) || _s[_i] == '.')) _i++;
                    if (_i < _s.Length && (_s[_i] == 'e' || _s[_i] == 'E'))
                    {
                        int save = _i; _i++;
                        if (_i < _s.Length && (_s[_i] == '+' || _s[_i] == '-')) _i++;
                        if (_i < _s.Length && char.IsDigit(_s[_i])) { while (_i < _s.Length && char.IsDigit(_s[_i])) _i++; }
                        else _i = save;
                    }
                    var text = _s.Substring(start, _i - start);
                    if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var d))
                        throw new FormulaException($"Bad number '{text}'", start);
                    return new Token { Kind = TokKind.Num, Num = d, Text = text, Pos = start };
                }
                if (char.IsLetter(c) || c == '_')
                {
                    while (_i < _s.Length && (char.IsLetterOrDigit(_s[_i]) || _s[_i] == '_')) _i++;
                    return new Token { Kind = TokKind.Ident, Text = _s.Substring(start, _i - start), Pos = start };
                }
                _i++;
                switch (c)
                {
                    case '(': return new Token { Kind = TokKind.LParen, Text = "(", Pos = start };
                    case ')': return new Token { Kind = TokKind.RParen, Text = ")", Pos = start };
                    case ',': return new Token { Kind = TokKind.Comma, Text = ",", Pos = start };
                }
                string two = _i < _s.Length ? new string(new[] { c, _s[_i] }) : null;
                if (two == "<=" || two == ">=" || two == "==" || two == "!=" || two == "&&" || two == "||")
                {
                    _i++;
                    return new Token { Kind = TokKind.Op, Text = two, Pos = start };
                }
                if ("+-*/%^<>!?:".IndexOf(c) >= 0)
                    return new Token { Kind = TokKind.Op, Text = c.ToString(), Pos = start };
                if (c == '=') throw new FormulaException("Use == for comparison", start);
                throw new FormulaException($"Unexpected character '{c}'", start);
            }
        }
        #endregion

        #region Parser
        sealed class Parser
        {
            readonly Lexer _lex;
            readonly Func<string, int?> _slotOf;
            Token _tok;
            public readonly HashSet<int> Deps = new HashSet<int>();
            public bool UsesValue, UsesFfb, UsesTp;
            public readonly HashSet<string> Outputs = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            public Parser(string s, Func<string, int?> slotOf)
            {
                _lex = new Lexer(s); _slotOf = slotOf; _tok = _lex.Next();
            }

            void Advance() => _tok = _lex.Next();
            bool IsOp(string op) => _tok.Kind == TokKind.Op && _tok.Text == op;

            void Expect(TokKind k, string what)
            {
                if (_tok.Kind != k) throw new FormulaException($"Expected {what} but found {_tok}", _tok.Pos);
                Advance();
            }

            public Node ParseAll()
            {
                if (_tok.Kind == TokKind.End) throw new FormulaException("Formula is empty", 0);
                var n = Ternary();
                if (_tok.Kind != TokKind.End) throw new FormulaException($"Unexpected {_tok}", _tok.Pos);
                return n;
            }

            Node Ternary()
            {
                var c = Or();
                if (IsOp("?"))
                {
                    Advance();
                    var a = Ternary();
                    if (!IsOp(":")) throw new FormulaException($"Expected ':' but found {_tok}", _tok.Pos);
                    Advance();
                    var b = Ternary();
                    return new IfNode(c, a, b);
                }
                return c;
            }

            Node Or()
            {
                var l = And();
                while (IsOp("||")) { Advance(); var r = And(); l = new Bin(l, r, (a, b) => (a != 0 || b != 0) ? 1 : 0); }
                return l;
            }

            Node And()
            {
                var l = Equality();
                while (IsOp("&&")) { Advance(); var r = Equality(); l = new Bin(l, r, (a, b) => (a != 0 && b != 0) ? 1 : 0); }
                return l;
            }

            Node Equality()
            {
                var l = Compare();
                while (IsOp("==") || IsOp("!="))
                {
                    bool eq = _tok.Text == "=="; Advance();
                    var r = Compare();
                    l = eq ? new Bin(l, r, (a, b) => a == b ? 1 : 0) : new Bin(l, r, (a, b) => a != b ? 1 : 0);
                }
                return l;
            }

            Node Compare()
            {
                var l = Additive();
                while (IsOp("<") || IsOp("<=") || IsOp(">") || IsOp(">="))
                {
                    var op = _tok.Text; Advance();
                    var r = Additive();
                    switch (op)
                    {
                        case "<": l = new Bin(l, r, (a, b) => a < b ? 1 : 0); break;
                        case "<=": l = new Bin(l, r, (a, b) => a <= b ? 1 : 0); break;
                        case ">": l = new Bin(l, r, (a, b) => a > b ? 1 : 0); break;
                        default: l = new Bin(l, r, (a, b) => a >= b ? 1 : 0); break;
                    }
                }
                return l;
            }

            Node Additive()
            {
                var l = Multiplicative();
                while (IsOp("+") || IsOp("-"))
                {
                    bool plus = _tok.Text == "+"; Advance();
                    var r = Multiplicative();
                    l = plus ? new Bin(l, r, (a, b) => a + b) : new Bin(l, r, (a, b) => a - b);
                }
                return l;
            }

            Node Multiplicative()
            {
                var l = Unary();
                while (IsOp("*") || IsOp("/") || IsOp("%"))
                {
                    var op = _tok.Text; Advance();
                    var r = Unary();
                    if (op == "*") l = new Bin(l, r, (a, b) => a * b);
                    else if (op == "/") l = new Bin(l, r, (a, b) => a / b);
                    else l = new Bin(l, r, (a, b) => a % b);
                }
                return l;
            }

            Node Unary()
            {
                if (IsOp("-")) { Advance(); var n = Unary(); return new Un(n, a => -a); }
                if (IsOp("+")) { Advance(); return Unary(); }
                if (IsOp("!")) { Advance(); var n = Unary(); return new Un(n, a => a == 0 ? 1 : 0); }
                return Power();
            }

            Node Power()
            {
                var b = Primary();
                if (IsOp("^")) { Advance(); var e = Unary(); return new Bin(b, e, Math.Pow); }
                return b;
            }

            Node Primary()
            {
                var t = _tok;
                switch (t.Kind)
                {
                    case TokKind.Num:
                        Advance();
                        return new Const(t.Num);
                    case TokKind.LParen:
                        Advance();
                        var inner = Ternary();
                        Expect(TokKind.RParen, "')'");
                        return inner;
                    case TokKind.Ident:
                        Advance();
                        if (_tok.Kind == TokKind.LParen) return Call(t);
                        return Identifier(t);
                    default:
                        throw new FormulaException($"Unexpected {t}", t.Pos);
                }
            }

            Node Identifier(Token t)
            {
                switch (t.Text.ToLowerInvariant())
                {
                    case "value":
                    case "x": UsesValue = true; return new ValueNode();
                    case "dt": return new DtNode();
                    case "t": return new TNode();
                    case "pi": return new Const(Math.PI);
                    case "g": return new Const(9.80665);
                    case "true": return new Const(1);
                    case "false": return new Const(0);
                    case "max_speed": return new MaxSpeedNode();
                    case "max_revs": return new MaxRevsNode();
                }
                var ffb = Ffb.FfbChannels.FromIdentifier(t.Text);
                if (ffb != null) { UsesFfb = true; return new FfbNode(ffb.Value); }
                var tp = TeknoParrot.TpChannels.FromIdentifier(t.Text);
                if (tp != null) { UsesTp = true; return new TpNode(tp.Value); }
                if (t.Text.StartsWith("out_", StringComparison.OrdinalIgnoreCase) && t.Text.Length > 4)
                {
                    var outName = t.Text.Substring(4);
                    Outputs.Add(outName);
                    return new OutputNode(outName);
                }
                var slot = _slotOf?.Invoke(t.Text);
                if (slot == null)
                    throw new FormulaException($"Unknown variable '{t.Text}'", t.Pos);
                Deps.Add(slot.Value);
                return new VarNode(slot.Value);
            }

            Node Call(Token name)
            {
                Advance(); // (
                var args = new List<Node>();
                if (_tok.Kind != TokKind.RParen)
                {
                    args.Add(Ternary());
                    while (_tok.Kind == TokKind.Comma) { Advance(); args.Add(Ternary()); }
                }
                Expect(TokKind.RParen, "')'");
                return Functions.Make(name.Text.ToLowerInvariant(), args, name.Pos);
            }
        }
        #endregion
    }

    #region Nodes
    abstract class Node { public abstract double Eval(EvalContext c); }

    sealed class Const : Node { readonly double _v; public Const(double v) { _v = v; } public override double Eval(EvalContext c) => _v; }
    sealed class ValueNode : Node { public override double Eval(EvalContext c) => c.Value; }
    sealed class DtNode : Node { public override double Eval(EvalContext c) => c.Dt; }
    sealed class TNode : Node { public override double Eval(EvalContext c) => c.T; }
    sealed class MaxSpeedNode : Node { public override double Eval(EvalContext c) => c.MaxSpeed; }
    sealed class MaxRevsNode : Node { public override double Eval(EvalContext c) => c.MaxRevs; }
    sealed class FfbNode : Node
    {
        readonly int _i; public FfbNode(int i) { _i = i; }
        public override double Eval(EvalContext c) => c.Ffb != null && _i < c.Ffb.Length ? c.Ffb[_i] : double.NaN;
    }
    sealed class TpNode : Node
    {
        readonly int _i; public TpNode(int i) { _i = i; }
        public override double Eval(EvalContext c) => c.Tp != null && _i < c.Tp.Length ? c.Tp[_i] : double.NaN;
    }
    sealed class OutputNode : Node
    {
        readonly string _name; public OutputNode(string n) { _name = n; }
        public override double Eval(EvalContext c) => c.Output != null ? c.Output(_name) : double.NaN;
    }
    sealed class VarNode : Node { readonly int _s; public VarNode(int s) { _s = s; } public override double Eval(EvalContext c) => c.Slots[_s]; }

    sealed class Un : Node
    {
        readonly Node _a; readonly Func<double, double> _f;
        public Un(Node a, Func<double, double> f) { _a = a; _f = f; }
        public override double Eval(EvalContext c) => _f(_a.Eval(c));
    }

    sealed class Bin : Node
    {
        // Both sides are always evaluated (no short-circuit) so that time-series functions
        // on either side keep sampling every tick.
        readonly Node _a, _b; readonly Func<double, double, double> _f;
        public Bin(Node a, Node b, Func<double, double, double> f) { _a = a; _b = b; _f = f; }
        public override double Eval(EvalContext c) { var x = _a.Eval(c); var y = _b.Eval(c); return _f(x, y); }
    }

    sealed class IfNode : Node
    {
        readonly Node _c, _a, _b;
        public IfNode(Node c, Node a, Node b) { _c = c; _a = a; _b = b; }
        public override double Eval(EvalContext ctx)
        {
            var c = _c.Eval(ctx); var a = _a.Eval(ctx); var b = _b.Eval(ctx);
            return c != 0 && !double.IsNaN(c) ? a : b;
        }
    }

    sealed class FuncNode : Node
    {
        readonly Node[] _args; readonly Func<double[], double> _f; readonly double[] _buf;
        public FuncNode(List<Node> args, Func<double[], double> f) { _args = args.ToArray(); _f = f; _buf = new double[_args.Length]; }
        public override double Eval(EvalContext c)
        {
            for (int i = 0; i < _args.Length; i++) _buf[i] = _args[i].Eval(c);
            return _f(_buf);
        }
    }

    /// <summary>Sliding window of (time, value) samples.</summary>
    sealed class SampleWindow
    {
        double[] _t = new double[64], _v = new double[64];
        int _head, _count;

        public int Count => _count;
        public double T(int i) => _t[(_head + i) % _t.Length];
        public double V(int i) => _v[(_head + i) % _v.Length];

        public void Clear() { _head = 0; _count = 0; }

        public void Add(double t, double v, double window)
        {
            if (_count == _t.Length) Grow();
            int idx = (_head + _count) % _t.Length;
            _t[idx] = t; _v[idx] = v; _count++;
            // keep one sample at or beyond the window edge so the span is never short
            while (_count > 2 && t - T(1) >= window) { _head = (_head + 1) % _t.Length; _count--; }
        }

        void Grow()
        {
            if (_t.Length >= 1 << 16) { _head = (_head + 1) % _t.Length; _count--; return; } // hard cap
            var nt = new double[_t.Length * 2]; var nv = new double[_v.Length * 2];
            for (int i = 0; i < _count; i++) { nt[i] = T(i); nv[i] = V(i); }
            _t = nt; _v = nv; _head = 0;
        }
    }

    /// <summary>Base for functions that keep history between ticks.</summary>
    abstract class Stateful : Node
    {
        protected readonly Node X;
        protected Stateful(Node x) { X = x; }
    }

    abstract class Windowed : Stateful
    {
        readonly Node _window;
        protected readonly SampleWindow W = new SampleWindow();
        protected Windowed(Node x, Node window) : base(x) { _window = window; }

        public sealed override double Eval(EvalContext c)
        {
            var x = X.Eval(c);
            var w = _window.Eval(c);
            if (double.IsNaN(x) || double.IsInfinity(x)) { W.Clear(); return double.NaN; }
            if (!(w > 0)) w = 1e-9;
            W.Add(c.T, x, w);
            return Compute();
        }

        protected abstract double Compute();
    }

    /// <summary>Least-squares slope (units per second) over the window. Much less noisy than a
    /// two-point difference, and tolerant of the game updating slower than we poll.</summary>
    sealed class Slope : Windowed
    {
        public Slope(Node x, Node w) : base(x, w) { }
        protected override double Compute()
        {
            int n = W.Count;
            if (n < 2) return 0;
            double t0 = W.T(0), st = 0, sv = 0;
            for (int i = 0; i < n; i++) { st += W.T(i) - t0; sv += W.V(i); }
            double mt = st / n, mv = sv / n, num = 0, den = 0;
            for (int i = 0; i < n; i++)
            {
                double dt = W.T(i) - t0 - mt;
                num += dt * (W.V(i) - mv);
                den += dt * dt;
            }
            return den > 1e-12 ? num / den : 0;
        }
    }

    sealed class Avg : Windowed
    {
        public Avg(Node x, Node w) : base(x, w) { }
        protected override double Compute()
        {
            double s = 0; for (int i = 0; i < W.Count; i++) s += W.V(i);
            return W.Count > 0 ? s / W.Count : 0;
        }
    }

    sealed class MinW : Windowed
    {
        public MinW(Node x, Node w) : base(x, w) { }
        protected override double Compute()
        {
            double m = double.PositiveInfinity; for (int i = 0; i < W.Count; i++) m = Math.Min(m, W.V(i));
            return m;
        }
    }

    sealed class MaxW : Windowed
    {
        public MaxW(Node x, Node w) : base(x, w) { }
        protected override double Compute()
        {
            double m = double.NegativeInfinity; for (int i = 0; i < W.Count; i++) m = Math.Max(m, W.V(i));
            return m;
        }
    }

    /// <summary>Exponential smoothing with time constant tau seconds (frame-rate independent).</summary>
    sealed class Ema : Stateful
    {
        readonly Node _tau; double _y; bool _init;
        public Ema(Node x, Node tau) : base(x) { _tau = tau; }
        public override double Eval(EvalContext c)
        {
            var x = X.Eval(c); var tau = _tau.Eval(c);
            if (double.IsNaN(x) || double.IsInfinity(x)) { _init = false; return double.NaN; }
            if (!_init || !(tau > 0)) { _y = x; _init = true; return _y; }
            var a = 1 - Math.Exp(-Math.Max(c.Dt, 0) / tau);
            _y += a * (x - _y);
            return _y;
        }
    }

    /// <summary>Makes an angle continuous: 350, 355, 2 (wrapped) becomes 350, 355, 362.</summary>
    sealed class Unwrap : Stateful
    {
        readonly Node _period; double _prev = double.NaN, _offset;
        public Unwrap(Node x, Node period) : base(x) { _period = period; }
        public override double Eval(EvalContext c)
        {
            var x = X.Eval(c); var p = _period.Eval(c);
            if (double.IsNaN(x) || double.IsInfinity(x) || !(p > 0)) { _prev = double.NaN; _offset = 0; return double.NaN; }
            if (!double.IsNaN(_prev))
            {
                var d = x - _prev;
                if (d > p / 2) _offset -= p;
                else if (d < -p / 2) _offset += p;
            }
            _prev = x;
            return x + _offset;
        }
    }

    /// <summary>Keeps the last value of expr from when the condition was true (NaN until then).</summary>
    sealed class Hold : Stateful
    {
        readonly Node _cond; double _held = double.NaN;
        public Hold(Node x, Node cond) : base(x) { _cond = cond; }
        public override double Eval(EvalContext c)
        {
            var x = X.Eval(c); var k = _cond.Eval(c);
            if (k != 0 && !double.IsNaN(k)) _held = x;
            return _held;
        }
    }

    /// <summary>Running total of expr x dt. Samples that aren't numbers are skipped.</summary>
    sealed class Integrate : Stateful
    {
        double _sum;
        public Integrate(Node x) : base(x) { }
        public override double Eval(EvalContext c)
        {
            var x = X.Eval(c);
            if (!double.IsNaN(x) && !double.IsInfinity(x) && c.Dt > 0) _sum += x * c.Dt;
            return _sum;
        }
    }

    sealed class Prev : Stateful
    {
        double _p = double.NaN;
        readonly int _mode; // 0 prev, 1 delta, 2 rate
        public Prev(Node x, int mode) : base(x) { _mode = mode; }
        public override double Eval(EvalContext c)
        {
            var x = X.Eval(c);
            var p = _p; _p = x;
            switch (_mode)
            {
                case 0: return p;
                case 1: return double.IsNaN(p) ? 0 : x - p;
                default: return double.IsNaN(p) || !(c.Dt > 0) ? 0 : (x - p) / c.Dt;
            }
        }
    }

    static class Functions
    {
        public static Node Make(string name, List<Node> a, int pos)
        {
            void Arity(int min, int max)
            {
                if (a.Count < min || a.Count > max)
                    throw new FormulaException(min == max
                        ? $"{name}() takes {min} argument{(min == 1 ? "" : "s")}, got {a.Count}"
                        : $"{name}() takes {min} to {max} arguments, got {a.Count}", pos);
            }

            switch (name)
            {
                // time series
                case "slope": case "deriv": Arity(2, 2); return new Slope(a[0], a[1]);
                case "avg": Arity(2, 2); return new Avg(a[0], a[1]);
                case "minw": Arity(2, 2); return new MinW(a[0], a[1]);
                case "maxw": Arity(2, 2); return new MaxW(a[0], a[1]);
                case "ema": case "smooth": Arity(2, 2); return new Ema(a[0], a[1]);
                case "prev": Arity(1, 1); return new Prev(a[0], 0);
                case "unwrap": Arity(2, 2); return new Unwrap(a[0], a[1]);
                case "integrate": Arity(1, 1); return new Integrate(a[0]);
                case "hold": Arity(2, 2); return new Hold(a[0], a[1]);
                // integer bits, for values that pack several fields into one number
                case "byte": Arity(2, 2); return F(a, v => Bits(v[0], (int)v[1] * 8, 8));
                case "bits": Arity(3, 3); return F(a, v => Bits(v[0], (int)v[1], (int)v[2]));
                case "band": Arity(2, 2); return F(a, v => (double)(U(v[0]) & U(v[1])));
                case "bor": Arity(2, 2); return F(a, v => (double)(U(v[0]) | U(v[1])));
                case "bxor": Arity(2, 2); return F(a, v => (double)(U(v[0]) ^ U(v[1])));
                case "shl": Arity(2, 2); return F(a, v => (double)((U(v[0]) << Math.Max(0, Math.Min(31, (int)v[1]))) & 0xFFFFFFFFL));
                case "shr": Arity(2, 2); return F(a, v => (double)(U(v[0]) >> Math.Max(0, Math.Min(31, (int)v[1]))));
                case "signed8": Arity(1, 1); return F(a, v => (double)(sbyte)(byte)(U(v[0]) & 0xFF));
                case "signed16": Arity(1, 1); return F(a, v => (double)(short)(ushort)(U(v[0]) & 0xFFFF));
                case "wrap": Arity(2, 2); return F(a, v => v[1] > 0 ? v[0] - v[1] * Math.Floor((v[0] + v[1] / 2) / v[1]) : v[0]);
                case "delta": Arity(1, 1); return new Prev(a[0], 1);
                case "rate": Arity(1, 1); return new Prev(a[0], 2);

                // stateless
                case "abs": Arity(1, 1); return F(a, v => Math.Abs(v[0]));
                case "sign": Arity(1, 1); return F(a, v => Math.Sign(v[0]));
                case "floor": Arity(1, 1); return F(a, v => Math.Floor(v[0]));
                case "ceil": Arity(1, 1); return F(a, v => Math.Ceiling(v[0]));
                case "sqrt": Arity(1, 1); return F(a, v => Math.Sqrt(v[0]));
                case "exp": Arity(1, 1); return F(a, v => Math.Exp(v[0]));
                case "log": Arity(1, 1); return F(a, v => Math.Log(v[0]));
                case "sin": Arity(1, 1); return F(a, v => Math.Sin(v[0]));
                case "cos": Arity(1, 1); return F(a, v => Math.Cos(v[0]));
                case "tan": Arity(1, 1); return F(a, v => Math.Tan(v[0]));
                case "pow": Arity(2, 2); return F(a, v => Math.Pow(v[0], v[1]));
                case "atan2": Arity(2, 2); return F(a, v => Math.Atan2(v[0], v[1]));
                case "hypot": Arity(2, 2); return F(a, v => Math.Sqrt(v[0] * v[0] + v[1] * v[1]));
                case "min": Arity(2, 16); return F(a, v => v.Min());
                case "max": Arity(2, 16); return F(a, v => v.Max());
                case "clamp": Arity(3, 3); return F(a, v => Math.Max(v[1], Math.Min(v[2], v[0])));
                case "round": Arity(1, 2); return F(a, v => v.Length > 1
                        ? Math.Round(v[0], (int)Math.Max(0, Math.Min(15, v[1])), MidpointRounding.AwayFromZero)
                        : Math.Round(v[0], MidpointRounding.AwayFromZero));
                case "if": Arity(3, 3); return new IfNode(a[0], a[1], a[2]);
                case "deadzone": Arity(2, 2); return F(a, v => Math.Abs(v[0]) <= v[1] ? 0 : v[0] - Math.Sign(v[0]) * v[1]);
                case "map": Arity(5, 5); return F(a, v => v[2] == v[1] ? v[3] : v[3] + (v[0] - v[1]) * (v[4] - v[3]) / (v[2] - v[1]));
                case "valid": Arity(2, 2); return F(a, v => double.IsNaN(v[0]) || double.IsInfinity(v[0]) ? v[1] : v[0]);
            }
            throw new FormulaException($"Unknown function '{name}'", pos);
        }

        static Node F(List<Node> a, Func<double[], double> f) => new FuncNode(a, f);

        /// <summary>A number as an unsigned 32-bit pattern (negative int32 values wrap, as stored).</summary>
        static long U(double v) => double.IsNaN(v) || double.IsInfinity(v) ? 0 : ((long)Math.Round(v)) & 0xFFFFFFFFL;

        static double Bits(double v, int shift, int count)
        {
            if (double.IsNaN(v)) return double.NaN;
            shift = Math.Max(0, Math.Min(31, shift)); count = Math.Max(1, Math.Min(32, count));
            return (U(v) >> shift) & ((1L << count) - 1);
        }
    }
    #endregion
}
