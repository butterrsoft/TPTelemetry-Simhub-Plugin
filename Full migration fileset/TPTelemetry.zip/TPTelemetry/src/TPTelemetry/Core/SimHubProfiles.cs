using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace TeknoTelemetry.Core
{
    /// <summary>Which kinds of hardware the user has, for the SimHub effect profiles (settings page ticks):
    /// the same five places for bass shakers and for shaker motors, plus fans (as motor outputs).
    /// The bass shaker names are the ones saved before 0.13.2; <see cref="Motors"/> is the seat motors.</summary>
    public class EffectHardware
    {
        // Bass shakers (Bass Shakers file)
        public bool Seat { get; set; } = true;
        public bool PedalBox { get; set; }
        public bool GasPedal { get; set; }
        public bool BrakePedal { get; set; }
        public bool ClutchPedal { get; set; }
        // Shaker motors (Motors file)
        public bool Motors { get; set; }
        public bool MotorPedalBox { get; set; }
        public bool MotorGasPedal { get; set; }
        public bool MotorBrakePedal { get; set; }
        public bool MotorClutchPedal { get; set; }
        public bool Fans { get; set; }

        public bool AnyPedal => PedalBox || GasPedal || BrakePedal || ClutchPedal;
        public bool AnyMotorPedal => MotorPedalBox || MotorGasPedal || MotorBrakePedal || MotorClutchPedal;
        public bool AnyBassShakers => Seat || AnyPedal;
        public bool AnyMotors => Motors || Fans || AnyMotorPedal;
    }

    /// <summary>
    /// Writes SimHub ShakeIt profiles (.siprofile, JSON) holding the "TP -" custom effects, built on the
    /// common values (TPTelemetry.Car_*), so they work for every game. One file per SimHub section: Bass
    /// Shakers (seat and pedal bass shakers) and ShakeIt Motors (seat and pedal shaker motors, and fans set up as motor
    /// outputs). The layout copies profiles exported from SimHub 9.9.4. The profiles are "Any Game"
    /// (no game code) and leave out output settings, so importing one never changes how a user's
    /// shakers are wired.
    ///
    /// Seat and motor effects have no output name, so they play on outputs in SimHub's ordinary channel
    /// modes. Pedal and fan effects carry an output name ("TP Gas pedal", "TP Fans"...), so they only
    /// play where the user maps that name to a channel, in SimHub's "Custom channel map" mode.
    /// </summary>
    public static class SimHubProfiles
    {
        public const string ProfileName = "TP Telemetry";
        /// <summary>SimHub's own name for an exported "Any Game" profile called TP Telemetry: "&lt;game&gt; - &lt;profile&gt;".
        /// SimHub 9.13 seems to take the game from the file name: the older "TP Telemetry - Bass Shakers.siprofile"
        /// imported there as an empty copy of the default profile, the identical file under this name properly. Both kinds share it, so each goes in its own folder.</summary>
        public const string FileName = "Any Game - TP Telemetry.siprofile";
        public const string BassFolder = "Bass Shakers", MotorsFolder = "Motors";
        public static readonly string BassFile = Path.Combine(BassFolder, FileName);
        public static readonly string MotorsFile = Path.Combine(MotorsFolder, FileName);
        // Names written before 0.17.1, removed when new files are written so they can't be imported by mistake.
        static readonly string[] OldFiles = { "TP Telemetry - Bass Shakers.siprofile", "TP Telemetry - Motors.siprofile" };
        public const string GasChannel = "TP Gas pedal", BrakeChannel = "TP Brake pedal", ClutchChannel = "TP Clutch pedal",
                            PedalBoxChannel = "TP Pedal box", FansChannel = "TP Fans";
        // Fixed, so a re-import is recognisably the same profile.
        static readonly Guid BassProfileId = new Guid("5d0b6f0e-7c1a-4f5e-9a51-7470b0a50001");
        static readonly Guid MotorsProfileId = new Guid("5d0b6f0e-7c1a-4f5e-9a51-7470b0a50002");

        /// <summary>One effect: a SimHub custom effect whose strength formulas read Car_ values.</summary>
        public sealed class Effect
        {
            public string Name;            // shown in SimHub, "TP - Collision"
            public string Mode = "Mono";   // SimHub spatialisation: Mono, Left/Right, Front/Rear
            public string A, B;            // Car_ value names (0 to 1): Mono = A; Left/Right = A left, B right; Front/Rear = A front, B rear
            public double ScaleA = 100, ScaleB = 100;
            public double Gain = 50;
            public int Hz = 40;            // bass shakers only
            public bool Noise;             // bass shakers: white noise (rough textures)
            public string HzFrom;          // bass shakers: Car_ value giving the pitch (forced frequency)
            public string Channel;         // output name, or null for the ordinary channel modes
            public string Purpose;         // for the docs
        }

        static string Prop(string car) => $"[TPTelemetry.{CommonValues.PropertyPrefix}{car}]";
        static string Formula(string car, double scale) => car == null ? "" : scale == 1 ? Prop(car) : $"{Prop(car)} * {scale.ToString(System.Globalization.CultureInfo.InvariantCulture)}";

        static Effect E(string name, string a, double gain, int hz, string purpose, string mode = "Mono", string b = null,
                        double scaleA = 100, double scaleB = 100, bool noise = false, string hzFrom = null, string channel = null) =>
            new Effect { Name = name, A = a, B = b, Mode = mode, Gain = gain, Hz = hz, Purpose = purpose, ScaleA = scaleA, ScaleB = scaleB, Noise = noise, HzFrom = hzFrom, Channel = channel };

        /// <summary>The Bass Shakers effects for the ticked hardware.</summary>
        public static List<Effect> BassEffects(EffectHardware hw)
        {
            var l = new List<Effect>();
            if (hw.Seat)
            {
                l.Add(E("TP - Collision", "impact_left", 80, 35, "Hits: a hard thump, stronger on the side that was hit.", "Left/Right", "impact_right"));
                l.Add(E("TP - Wall scrape", "wall_left", 60, 50, "Grinding while scraping along a wall, on that side.", "Left/Right", "wall_right", 60, 60, noise: true));
                l.Add(E("TP - Rumble strip", "rumble_strip", 60, 25, "A low buzz while on a ripple strip.", scaleA: 70));
                l.Add(E("TP - Road bump", "road_bump", 70, 30, "A thud for each expansion joint or bump."));
                l.Add(E("TP - Off-road", "off_road", 50, 28, "Rough, noisy rumble on rough ground or off the track.", scaleA: 70, noise: true));
                l.Add(E("TP - Gear change", "shift", 60, 40, "A short kick on each gear change."));
                l.Add(E("TP - Engine", "engine", 50, 40, "Engine vibration: the pitch rises from 25 to 60 Hz with the revs; the strength rises more gently. Needs Max revs.", hzFrom: "engine_hz"));
                l.Add(E("TP - Rev limiter", "rev_limit", 60, 32, "A stutter at 97% of Max revs and above."));
                l.Add(E("TP - Road (speed)", "road", 30, 45, "Faint road texture growing with speed; cut while airborne. Needs Max speed.", scaleA: 40, noise: true));
                l.Add(E("TP - Grip loss", "grip_loss", 50, 45, "Sliding: rough rumble, mostly at the rear.", "Front/Rear", "grip_loss", 40, 100, noise: true));
                l.Add(E("TP - Drift", "drift", 50, 30, "Drifting: a deep, smooth rumble at the rear that grows with the drift angle.", "Front/Rear", "drift", 30, 100));
                l.Add(E("TP - Braking and acceleration", "braking", 30, 20, "G-force cue: a low tone at the front under braking, at the rear under acceleration.", "Front/Rear", "accelerating"));
                l.Add(E("TP - Cornering", "corner_left", 30, 20, "G-force cue: a low tone on the outside of the turn.", "Left/Right", "corner_right"));
                l.Add(E("TP - Landing", "landed", 70, 30, "A thump when landing after being airborne."));
                l.Add(E("TP - Boost", "boost", 40, 55, "A rising buzz while boosting.", scaleA: 60));
                l.Add(E("TP - Game rumble", "vibration", 50, 40, "The game's own vibration commands, passed straight through."));
            }
            l.AddRange(PedalEffects(hw.GasPedal, hw.BrakePedal, hw.ClutchPedal, hw.PedalBox));
            return l;
        }

        /// <summary>Pedal effects, each on its pedal's own output, for the pedals ticked under one kind of
        /// hardware: the same effects for bass shakers and shaker motors (motors have no pitch, so there
        /// the engine effects are strength only).</summary>
        public static List<Effect> PedalEffects(bool gas, bool brake, bool clutch, bool box)
        {
            var l = new List<Effect>();
            if (gas)
            {
                l.Add(E("TP - Pedal Gas: Engine", "engine", 50, 40, "Engine vibration in the gas pedal (on bass shakers the pitch follows the revs).", hzFrom: "engine_hz", channel: GasChannel));
                l.Add(E("TP - Pedal Gas: Rev Limiter", "rev_limit", 60, 32, "Rev limiter stutter in the gas pedal.", channel: GasChannel));
                l.Add(E("TP - Pedal Gas: Wheelspin", "grip_loss", 40, 45, "Sliding felt through the gas pedal.", noise: true, channel: GasChannel));
            }
            if (brake)
            {
                l.Add(E("TP - Pedal Brake: Braking", "braking", 50, 30, "A hum that grows with braking force.", channel: BrakeChannel));
                l.Add(E("TP - Pedal Brake: Collision", "impact", 50, 35, "Hits felt through the brake pedal.", channel: BrakeChannel));
            }
            if (clutch)
            {
                l.Add(E("TP - Pedal Clutch: Gear Change", "shift", 70, 40, "A kick in the clutch pedal on each gear change.", channel: ClutchChannel));
                l.Add(E("TP - Pedal Clutch: Engine", "engine", 25, 40, "A quiet engine hum in the clutch pedal.", hzFrom: "engine_hz", channel: ClutchChannel));
            }
            if (box)
            {
                l.Add(E("TP - Pedal Box: Engine", "engine", 30, 40, "Engine vibration in the pedal box.", hzFrom: "engine_hz", channel: PedalBoxChannel));
                l.Add(E("TP - Pedal Box: Rev Limiter", "rev_limit", 40, 32, "Rev limiter stutter in the pedal box.", channel: PedalBoxChannel));
                l.Add(E("TP - Pedal Box: Braking", "braking", 40, 30, "Braking hum in the pedal box.", channel: PedalBoxChannel));
                l.Add(E("TP - Pedal Box: Gear Change", "shift", 50, 40, "Gear change kick in the pedal box.", channel: PedalBoxChannel));
                l.Add(E("TP - Pedal Box: Collision", "impact", 40, 35, "Hits felt in the pedal box.", channel: PedalBoxChannel));
            }
            return l;
        }

        /// <summary>The ShakeIt Motors effects for the ticked hardware.</summary>
        public static List<Effect> MotorEffects(EffectHardware hw)
        {
            var l = new List<Effect>();
            if (hw.Motors)
            {
                l.Add(E("TP - Collision", "impact_left", 80, 0, "Hits: a burst, stronger on the side that was hit.", "Left/Right", "impact_right"));
                l.Add(E("TP - Wall scrape", "wall_left", 50, 0, "Buzz while scraping along a wall, on that side.", "Left/Right", "wall_right", 60, 60));
                l.Add(E("TP - Rumble strip", "rumble_strip", 60, 0, "Buzz on a ripple strip.", scaleA: 70));
                l.Add(E("TP - Road bump", "road_bump", 60, 0, "A tap for each joint or bump."));
                l.Add(E("TP - Off-road", "off_road", 50, 0, "Rumble on rough ground.", scaleA: 70));
                l.Add(E("TP - Gear change", "shift", 60, 0, "A tick on each gear change."));
                l.Add(E("TP - Rev limiter", "rev_limit", 50, 0, "Rev limiter stutter."));
                l.Add(E("TP - Grip loss", "grip_loss", 40, 0, "Sliding.", "Front/Rear", "grip_loss", 40, 100));
                l.Add(E("TP - Drift", "drift", 40, 0, "Drifting, growing with the drift angle, mostly at the rear.", "Front/Rear", "drift", 30, 100));
                l.Add(E("TP - Landing", "landed", 70, 0, "A thump on landing."));
                l.Add(E("TP - Game rumble", "vibration", 50, 0, "The game's own vibration commands."));
            }
            if (hw.Fans)
            {
                l.Add(E("TP - Wind", "speed_frac", 100, 0, "Fan speed follows car speed. Needs Max speed.", channel: FansChannel));
                l.Add(E("TP - Wind: Boost gust", "boost", 50, 0, "A gust while boosting.", channel: FansChannel));
            }
            l.AddRange(PedalEffects(hw.MotorGasPedal, hw.MotorBrakePedal, hw.MotorClutchPedal, hw.MotorPedalBox));
            return l;
        }

        static Guid StableId(string kind, string name)
        {
            using (var md5 = MD5.Create())
                return new Guid(md5.ComputeHash(Encoding.UTF8.GetBytes("TPTelemetry/" + kind + "/" + name)));
        }

        static JObject Expr(string e) => new JObject { ["Expression"] = e ?? "" };

        static JObject Container(Effect e, bool bass)
        {
            // Formula slots per SimHub's spatialisation mode, as SimHub itself fills them.
            string fl = Formula(e.A, e.ScaleA), fr = "", rl = "", rr = "";
            if (e.Mode == "Left/Right") fr = Formula(e.B, e.ScaleB);
            else if (e.Mode == "Front/Rear") rl = Formula(e.B, e.ScaleB);
            var output = bass
                ? new JObject
                {
                    ["UsePrehemptiveMode"] = false,
                    ["Frequency"] = e.Hz,
                    ["UseHighFrequency"] = false,
                    ["HighFrequency"] = 50,
                    ["WhiteNoise"] = 10,
                    ["UseWhiteNoise"] = e.Noise,
                    ["FrequencyBasedOnPreFilter"] = false,
                    ["Harmonics"] = 0,
                    ["HoldMode"] = 1,
                }
                : new JObject();
            if (e.Channel != null) { output["AssignToChannelGroup"] = true; output["ChannelGroupName"] = e.Channel; }
            output["OutputType"] = bass ? "ToneOutput" : "VibrationOutput";
            var forced = bass && e.HzFrom != null;
            string hz = forced ? Prop(e.HzFrom) : "";
            return new JObject
            {
                ["ContainerType"] = "CustomEffectContainer",
                ["IsEnabled"] = true,
                ["Gain"] = e.Gain,
                ["Description"] = e.Name,
                ["FrontLeftFormula"] = Expr(fl),
                ["FrontRightFormula"] = Expr(fr),
                ["RearLeftFormula"] = Expr(rl),
                ["RearRightFormula"] = Expr(rr),
                ["ForceFrequencies"] = forced,
                ["FrontLeftFrequencyFormula"] = Expr(hz),
                ["FrontRightFrequencyFormula"] = Expr(forced && e.Mode == "Left/Right" ? hz : ""),
                ["RearLeftFrequencyFormula"] = Expr(forced && e.Mode == "Front/Rear" ? hz : ""),
                ["RearRightFrequencyFormula"] = Expr(""),
                ["AlwaysExecute"] = false,
                ["ContainerId"] = StableId(bass ? "bass" : "motors", e.Name).ToString(),
                ["AggregationMode"] = e.Mode,
                ["Filter"] = new JObject
                {
                    ["GammaValue"] = 1.0,
                    ["InputGain"] = 100.0,
                    ["MinimumForce"] = 0,
                    ["Threshold"] = 0,
                    ["FilterType"] = "GammaFilter",
                },
                ["Output"] = output,
            };
        }

        /// <summary>A whole .siprofile: an "Any Game" profile called TP Telemetry holding these effects.</summary>
        public static JObject Profile(IEnumerable<Effect> effects, bool bass) => new JObject
        {
            ["CarChoices"] = new JArray(),
            ["IncludeOutputSettingsInProfile"] = false,
            ["UnmuteEffectsAfterSimhubRestart"] = true,
            ["EffectsContainers"] = new JArray(effects.Select(e => Container(e, bass))),
            ["AutoCalibrationRatio2"] = 100,
            ["OutputMode"] = bass ? 1 : 0,
            ["GlobalGain"] = 50.0,
            ["UseProfileGain"] = false,
            ["LastLoaded"] = "0001-01-01T00:00:00",
            ["Name"] = ProfileName,
            ["ProfileId"] = (bass ? BassProfileId : MotorsProfileId).ToString(),
            ["GameCode"] = null,
            ["CarChoice"] = null,
        };

        /// <summary>Writes the files the ticked hardware needs into <paramref name="folder"/> and returns their paths
        /// (empty if nothing is ticked).</summary>
        public static List<string> Write(EffectHardware hw, string folder)
        {
            Directory.CreateDirectory(folder);
            var written = new List<string>();
            foreach (var old in OldFiles)
                try { File.Delete(Path.Combine(folder, old)); } catch (IOException) { } catch (UnauthorizedAccessException) { }
            void Save(string file, JObject o)
            {
                var path = Path.Combine(folder, file);
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                File.WriteAllText(path, o.ToString(Formatting.Indented), new UTF8Encoding(false));
                written.Add(path);
            }
            if (hw.AnyBassShakers) Save(BassFile, Profile(BassEffects(hw), true));
            if (hw.AnyMotors) Save(MotorsFile, Profile(MotorEffects(hw), false));
            return written;
        }
    }
}
