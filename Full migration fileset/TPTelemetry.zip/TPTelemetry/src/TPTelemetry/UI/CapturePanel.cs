using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Ffb;

namespace TeknoTelemetry.UI
{
    /// <summary>
    /// The sources every game shares, inside "Capture table values and FFB": one status line for
    /// TeknoParrot, game outputs and USB capture; the outputs port and poll rate; and the USB capture
    /// settings. Setup help is in USB_Capture.md and Game_Outputs.md rather than on the page.
    /// </summary>
    public sealed class CapturePanel : StackPanel
    {
        readonly TPTelemetry _plugin;
        readonly TextBlock _status = new TextBlock { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 6, 0, 2) };
        readonly TextBox _outPort = new TextBox { Width = 60, VerticalAlignment = VerticalAlignment.Center };
        readonly TextBox _pollHz = new TextBox { Width = 60, VerticalAlignment = VerticalAlignment.Center };
        readonly CheckBox _usbEnabled = new CheckBox { Content = "Capture force feedback sent to a wheel over USB", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 6, 0, 0) };
        readonly CheckBox _usbCommon = new CheckBox { Content = "Use the wheel's force for effects a game has no values for (hits, bumps, cornering, rumble)", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(18, 2, 0, 0) };
        readonly ComboBox _devices = new ComboBox { MinWidth = 260, VerticalAlignment = VerticalAlignment.Center };
        readonly ComboBox _decoder = new ComboBox { MinWidth = 200, VerticalAlignment = VerticalAlignment.Center };
        readonly TextBox _exe = new TextBox { MinWidth = 260, VerticalAlignment = VerticalAlignment.Center };
        readonly Button _record;
        readonly DispatcherTimer _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(150) };
        readonly double[] _ffb = new double[FfbChannels.Count];
        bool _loading;
        string _usbNote; DateTime _usbNoteUntil;

        sealed class DecoderItem
        {
            public FfbDecoderChoice Value; public string Label;
            public override string ToString() => Label;
        }

        FfbSettings S => _plugin.Settings.Ffb;

        public CapturePanel(TPTelemetry plugin)
        {
            _plugin = plugin;
            Margin = new Thickness(0, 4, 0, 0);

            Children.Add(_status);

            var settings = new WrapPanel();
            settings.Children.Add(Label("Outputs port", 0)); settings.Children.Add(_outPort);
            settings.Children.Add(Label("Poll rate (Hz)")); settings.Children.Add(_pollHz);
            Children.Add(settings);

            Children.Add(_usbEnabled);
            Children.Add(_usbCommon);
            var wheel = new WrapPanel();
            wheel.Children.Add(Label("Wheel", 0)); wheel.Children.Add(_devices);
            var find = Btn("Find Devices", FindDevices);
            find.ToolTip = "Lists the USB devices so you can choose your wheel. Needed once: the plugin remembers the wheel by name and " +
                           "finds it again by itself when Windows gives it a new USB address (a replug, a restart, a G25 switching modes).";
            wheel.Children.Add(find);
            wheel.Children.Add(Label("Decoder")); wheel.Children.Add(_decoder);
            Children.Add(wheel);

            var raw = new WrapPanel();
            _record = Btn("Record 60 s Capture", ToggleUsbRecording);
            _record.ToolTip = "Saves the raw USB traffic to your wheel for 60 seconds, for adding support for a wheel the decoders don't know " +
                              "(see USB_Capture.md).";
            raw.Children.Add(_record);
            var pattern = Btn("Record Test Pattern", RecordTestPattern);
            pattern.ToolTip = "Records the USB traffic while the plugin plays a fixed set of forces on the wheel (pushes left and right at 25% and " +
                              "50%, a vibration, spring, damper, friction: about 30 s). Close games first and keep a hand on the wheel. " +
                              "The capture and a log of each step's time go to the captures folder (see USB_Capture.md).";
            raw.Children.Add(pattern);
            raw.Children.Add(Btn("Open Captures Folder", () =>
            {
                Directory.CreateDirectory(_plugin.Ffb.CapturesFolder);
                Process.Start("explorer.exe", _plugin.Ffb.CapturesFolder);
            }));
            raw.Children.Add(Label("USBPcapCMD.exe")); raw.Children.Add(_exe);
            Children.Add(raw);

            _decoder.ItemsSource = new[]
            {
                new DecoderItem { Value = FfbDecoderChoice.Auto, Label = "Auto (by wheel model)" },
                new DecoderItem { Value = FfbDecoderChoice.LogitechClassic, Label = "Logitech classic (G25, G27, G29, G923 PS, DFGT, DFP, Momo)" },
                new DecoderItem { Value = FfbDecoderChoice.LogitechHidpp, Label = "Logitech HID++ (G920, G923 Xbox, G PRO, RS50)" },
                new DecoderItem { Value = FfbDecoderChoice.Thrustmaster, Label = "Thrustmaster (T300RS, T248, TX, TS-XW, TS-PC)" },
                new DecoderItem { Value = FfbDecoderChoice.Fanatec, Label = "Fanatec (CSL, DD, ClubSport, Podium)" },
                new DecoderItem { Value = FfbDecoderChoice.UsbPid, Label = "USB PID (Moza, Simucube, VRS, Cammus, Asetek, PXN)" },
                new DecoderItem { Value = FfbDecoderChoice.Xbox360, Label = "Xbox 360 / XInput rumble (wired)" },
                new DecoderItem { Value = FfbDecoderChoice.XboxOne, Label = "Xbox One / Series rumble (wired)" },
                new DecoderItem { Value = FfbDecoderChoice.Raw, Label = "Raw bytes only" },
            };
            LoadFromSettings();

            _outPort.LostFocus += (s, e) =>
            {
                if (int.TryParse(_outPort.Text, out var p) && p > 0 && p < 65536)
                {
                    if (p != _plugin.Settings.Outputs.Port) { _plugin.Settings.Outputs.Port = p; _plugin.ApplyOutputs(); }
                }
                else _outPort.Text = _plugin.Settings.Outputs.Port.ToString(CultureInfo.InvariantCulture);
            };
            _pollHz.LostFocus += (s, e) =>
            {
                if (int.TryParse(_pollHz.Text, out var hz) && hz >= 10 && hz <= 1000)
                {
                    if (hz != _plugin.Settings.PollRateHz) { _plugin.Settings.PollRateHz = hz; _plugin.Apply(); }
                }
                else _pollHz.Text = _plugin.Settings.PollRateHz.ToString(CultureInfo.InvariantCulture);
            };
            _usbEnabled.Checked += (s, e) => EditUsb(() => S.Enabled = true);
            _usbEnabled.Unchecked += (s, e) => EditUsb(() => S.Enabled = false);
            _usbCommon.Checked += (s, e) => EditUsb(() => S.UseForCommonValues = true);
            _usbCommon.Unchecked += (s, e) => EditUsb(() => S.UseForCommonValues = false);
            _decoder.SelectionChanged += (s, e) => EditUsb(() => S.Decoder = ((DecoderItem)_decoder.SelectedItem).Value);
            _devices.SelectionChanged += (s, e) => EditUsb(() =>
            {
                if (!(_devices.SelectedItem is UsbDeviceChoice d)) return;
                if (S.Interface != d.Interface || S.Device != d.Device || S.DeviceName != d.Display) { S.VendorId = 0; S.ProductId = 0; }
                S.Interface = d.Interface; S.Device = d.Device; S.DeviceName = d.Display;
            });
            _exe.LostFocus += (s, e) => EditUsb(() => S.UsbPcapCmdPath = _exe.Text.Trim().Trim('"'));

            _timer.Tick += (s, e) => { try { Refresh(); } catch (Exception ex) { _status.Text = ex.Message; } };
            Loaded += (s, e) => { _timer.Start(); Refresh(); };
            Unloaded += (s, e) => _timer.Stop();
        }

        void LoadFromSettings()
        {
            _loading = true;
            _outPort.Text = _plugin.Settings.Outputs.Port.ToString(CultureInfo.InvariantCulture);
            _pollHz.Text = _plugin.Settings.PollRateHz.ToString(CultureInfo.InvariantCulture);
            _usbEnabled.IsChecked = S.Enabled;
            _usbCommon.IsChecked = S.UseForCommonValues;
            _decoder.SelectedItem = ((IEnumerable<DecoderItem>)_decoder.ItemsSource).First(i => i.Value == S.Decoder);
            var current = string.IsNullOrEmpty(S.Interface) ? null
                : new UsbDeviceChoice { Interface = S.Interface, Device = S.Device, Display = string.IsNullOrEmpty(S.DeviceName) ? $"[{S.Device}]" : S.DeviceName };
            _devices.ItemsSource = current == null ? new List<UsbDeviceChoice>() : new List<UsbDeviceChoice> { current };
            _devices.SelectedItem = current;
            _exe.Text = S.UsbPcapCmdPath ?? "";
            _loading = false;
        }

        void EditUsb(Action change)
        {
            if (_loading) return;
            change();
            _plugin.ApplyFfb();
            Refresh();
        }

        /// <summary>Shows a message in place of the USB status for a few seconds.</summary>
        void UsbNote(string text, double seconds = 8) { _usbNote = text; _usbNoteUntil = DateTime.UtcNow.AddSeconds(seconds); Refresh(); }

        void FindDevices()
        {
            var exe = FfbCapture.FindUsbPcapCmd(S.UsbPcapCmdPath);
            if (exe == null) { UsbNote(FfbCapture.UsbPcapMissing, 15); return; }
            UsbNote("looking for USB devices...", 30);
            Task.Run(() =>
            {
                var list = FfbCapture.ListDevices(exe, out var err);
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    _loading = true;
                    // the chosen wheel, by name if Windows has given it a new address since
                    var keep = FfbCapture.Match(list, S.Interface, S.Device, S.DeviceName);
                    _devices.ItemsSource = list;
                    _devices.SelectedItem = keep;
                    _loading = false;
                    UsbNote(err ?? $"found {list.Count} USB devices. Choose your wheel; Logitech wheels usually show their name.", 15);
                    if (keep != null && (keep.Display != S.DeviceName || keep.Device != S.Device || keep.Interface != S.Interface))
                    {
                        if (keep.Device != S.Device || keep.Interface != S.Interface) { S.VendorId = 0; S.ProductId = 0; }
                        S.Interface = keep.Interface; S.Device = keep.Device; S.DeviceName = keep.Display;
                        _plugin.ApplyFfb();
                    }
                }));
            });
        }

        void RecordTestPattern()
        {
            var f = _plugin.Ffb;
            try
            {
                var path = f.StartTestPattern();
                UsbNote("playing the test pattern and recording to " + Path.GetFileName(path) + ": keep a hand on the wheel", 40);
            }
            catch (Exception e) { UsbNote("test pattern: " + e.Message, 15); }
        }

        void ToggleUsbRecording()
        {
            var f = _plugin.Ffb;
            if (f.IsRecording) { f.StopRecording(); Refresh(); return; }
            var path = f.StartRecording(60);
            UsbNote("recording raw USB traffic to " + Path.GetFileName(path), 60);
        }

        void Refresh()
        {
            var f = _plugin.Ffb;
            if (_usbNote != null && (DateTime.UtcNow > _usbNoteUntil || (_usbNote.StartsWith("recording") && !f.IsRecording))) _usbNote = null;

            // the capture found the wheel at a new address: show it
            if (!_devices.IsDropDownOpen && _devices.SelectedItem is UsbDeviceChoice sel && !string.IsNullOrEmpty(S.Interface) &&
                (sel.Interface != S.Interface || sel.Device != S.Device || sel.Display != S.DeviceName))
            {
                _loading = true;
                var list = (_devices.ItemsSource as IEnumerable<UsbDeviceChoice>)?.ToList() ?? new List<UsbDeviceChoice>();
                var now = list.FirstOrDefault(d => d.Interface == S.Interface && d.Device == S.Device && d.Display == S.DeviceName);
                if (now == null)
                {
                    now = new UsbDeviceChoice { Interface = S.Interface, Device = S.Device, Display = S.DeviceName };
                    list = list.Where(d => !(d.Interface == S.Interface && d.Device == S.Device)).ToList();
                    list.Add(now);
                }
                _devices.ItemsSource = list;
                _devices.SelectedItem = now;
                _loading = false;
            }
            _plugin.Engine.CopyFfb(_ffb);
            var usb = _usbNote ?? f.Status;
            if (_usbNote == null && _ffb[FfbChannels.Connected] == 1)
                usb += $", {_ffb[FfbChannels.Activity]:0} commands/s";

            var o = _plugin.Outputs;
            var outs = o.All().Count;
            var outText = o.Status + (o.Paused ? " (paused)" : "") + (outs > 0 ? $", {outs} output{(outs == 1 ? "" : "s")}" : "");

            var text = $"TeknoParrot: {_plugin.Tp.Status}   ·   Outputs: {outText}   ·   USB: {usb}";
            if (_status.Text != text) _status.Text = text;

            if (_exe.Text == "" && !_exe.IsKeyboardFocused)
            {
                var found = FfbCapture.FindUsbPcapCmdCached();
                _exe.ToolTip = found == null ? FfbCapture.UsbPcapMissing : "Found automatically: " + found;
            }
            _record.Content = f.IsRecording ? "Stop Recording" : "Record 60 s Capture";
            _record.IsEnabled = f.IsRecording || f.IsCapturing;
        }

        static TextBlock Label(string text, double left = 10) =>
            new TextBlock { Text = text, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(left, 0, 6, 0) };

        Button Btn(string text, Action onClick)
        {
            var b = new Button { Content = text, Margin = new Thickness(6, 2, 0, 2), Padding = new Thickness(8, 3, 8, 3) };
            b.Click += (s, e) =>
            {
                try { onClick(); }
                catch (Exception ex) { UsbNote(ex.Message); }
            };
            return b;
        }
    }
}
