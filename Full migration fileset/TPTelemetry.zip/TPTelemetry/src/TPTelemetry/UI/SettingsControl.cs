using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Expressions;

namespace TeknoTelemetry.UI
{
    /// <summary>
    /// Settings page shown in SimHub's left menu. Built in code (no XAML) so the project builds
    /// with nothing but the .NET SDK.
    /// </summary>
    public sealed class SettingsControl : UserControl
    {
        readonly TPTelemetry _plugin;
        readonly ObservableCollection<VarRow> _rows = new ObservableCollection<VarRow>();
        readonly ComboBox _games = new ComboBox { MinWidth = 200, DisplayMemberPath = nameof(GameProfile.DisplayName), VerticalAlignment = VerticalAlignment.Center };
        readonly TextBox _name = new TextBox { Width = 170, VerticalAlignment = VerticalAlignment.Center };
        readonly TextBox _prefix = new TextBox { Width = 100, VerticalAlignment = VerticalAlignment.Center };
        // Narrow on purpose: a long process name scrolls inside the box.
        readonly TextBox _process = new TextBox { Width = 120, VerticalAlignment = VerticalAlignment.Center };
        readonly TextBox _maxSpeed = new TextBox { Width = 60, VerticalAlignment = VerticalAlignment.Center };
        readonly TextBox _maxRevs = new TextBox { Width = 60, VerticalAlignment = VerticalAlignment.Center };
        readonly TextBlock _gameStatus = new TextBlock { Margin = new Thickness(0, 4, 0, 4), TextWrapping = TextWrapping.Wrap };
        readonly CheckBox _showAddress = new CheckBox { Content = "Show address columns", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 0, 0) };
        Button _recordBtn, _markBtn, _ffbRowsBtn;
        readonly TextBlock _ffbRowsNote = new TextBlock { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(4, 0, 0, 0), Opacity = 0.75, TextWrapping = TextWrapping.Wrap };
        readonly TextBlock _recStatus = new TextBlock { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 0, 0), TextWrapping = TextWrapping.Wrap };
        string _prefixError;
        // A message shown in place of the game's status for a few seconds (e.g. "Copied").
        string _notice; DateTime _noticeUntil;
        VarRow _connectedRow;
        DataGridColumn[] _addressColumns;

        /// <summary>Button labels and the recording line (time, markers, file).</summary>
        void RefreshRecording()
        {
            var r = _plugin.Engine.Recorder;
            _recordBtn.Content = r != null ? "Stop Recording" : "Record Values";
            _markBtn.IsEnabled = r != null;
            _recStatus.Text = r != null
                ? $"Recording {(r.GamePrefix == "" ? "FFB only" : r.GamePrefix)}: {r.Seconds:0} s, {r.Marks} marker{(r.Marks == 1 ? "" : "s")}  ·  {Path.GetFileName(r.Path)}"
                : "Saves every table row, FFB, TeknoParrot and outputs to a CSV file at the poll rate. Anything that can't be read is left blank.";
        }
        string _liveError;
        readonly DataGrid _grid;
        readonly StackPanel _page;
        readonly ScrollViewer _scroll;
        readonly DispatcherTimer _live = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(100) };
        readonly DispatcherTimer _debounce = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(500) };
        bool _loading;
        string _loadErrors;

        // Low resolutions (640x480, an 800x600 CRT) and SimHub's licence banner leave little room, so the
        // whole page scrolls both ways. Narrower than this, it scrolls sideways; wider, rows wrap to fit.
        const double MinPageWidth = 600;
        // The table fills the height that's left, but never gets shorter than this; the page scrolls instead.
        const double MinGridHeight = 180;
        const double PageMargin = 10;

        GameProfile Current => _games.SelectedItem as GameProfile;
        int VarCount => Current?.Variables.Count ?? 0;

        public SettingsControl(TPTelemetry plugin)
        {
            _plugin = plugin;
            _grid = BuildGrid();
            // Top: a ScrollViewer stretches content shorter than the window to fill it, which would hide how
            // much room is spare (the table could shrink but never grow back).
            _page = new StackPanel { Margin = new Thickness(PageMargin), VerticalAlignment = VerticalAlignment.Top };

            // ---- top bar: game selection and file actions
            var top = new WrapPanel { Margin = new Thickness(0, 0, 0, 4) };
            top.Children.Add(Label("Game", 0));
            top.Children.Add(_games);
            top.Children.Add(Btn("Add Game", NewGame));
            top.Children.Add(Btn("Import…", Import, "A profile (.json) or a Cheat Engine table (.CT)."));
            top.Children.Add(Btn("Export…", ExportProfile, "Save this game's profile as a .json file."));
            top.Children.Add(Btn("Delete Game", DeleteGame));
            top.Children.Add(Btn("Open Profiles Folder", () => Process.Start("explorer.exe", _plugin.Store.Folder)));
            top.Children.Add(Btn("Copy Commandlines To Set Game/Profile", CopyCommandLines,
                "Copies the lines a launch script runs to select this game in TP Telemetry and in SimHub, for AutoHotkey v1, " +
                "AutoHotkey v2 and batch files, with notes on using them."));
            _page.Children.Add(top);

            // ---- game fields
            var fields = new WrapPanel();
            fields.Children.Add(Label("Display name", 0)); fields.Children.Add(_name);
            fields.Children.Add(Label("Property prefix")); fields.Children.Add(_prefix);
            fields.Children.Add(Label("Process")); fields.Children.Add(_process);
            const string refTip = " Formulas use it as {0}, e.g. value / {0} runs 0 to 1. Leave blank for 1 (raw values). Smallest value 1.";
            var ms = Label("Max speed"); ms.ToolTip = "This game's top speed, in the units of its speed row." + string.Format(refTip, "max_speed");
            _maxSpeed.ToolTip = ms.ToolTip;
            var mr = Label("Max revs"); mr.ToolTip = "This game's redline, in the units of its revs row." + string.Format(refTip, "max_revs");
            _maxRevs.ToolTip = mr.ToolTip;
            fields.Children.Add(ms); fields.Children.Add(_maxSpeed);
            fields.Children.Add(mr); fields.Children.Add(_maxRevs);
            _page.Children.Add(fields);
            _page.Children.Add(_gameStatus);

            // ---- the table
            _page.Children.Add(_grid);

            // ---- row actions
            var actions = new WrapPanel { Margin = new Thickness(0, 4, 0, 0) };
            actions.Children.Add(Btn("Add Row", AddRow, "Adds a memory row below the selected one. Change Source to Computed for a formula row."));
            actions.Children.Add(Btn("Duplicate", Duplicate));
            actions.Children.Add(Btn("▲", () => Move(-1), "Move the selected row up"));
            actions.Children.Add(Btn("▼", () => Move(1), "Move the selected row down"));
            actions.Children.Add(Btn("Remove", RemoveVar));
            actions.Children.Add(_showAddress);
            _page.Children.Add(actions);

            // ---- capture: recording, the shared sources, USB capture
            var recRow = new WrapPanel { Margin = new Thickness(0, 4, 0, 0) };
            recRow.Children.Add(_recordBtn = Btn("Record Values", () => { _plugin.ToggleRecording(); RefreshRecording(); }));
            recRow.Children.Add(_markBtn = Btn("Mark Event", () => { _plugin.Mark(); RefreshRecording(); }));
            recRow.Children.Add(Btn("Open Recordings Folder", () =>
            {
                Directory.CreateDirectory(_plugin.RecordingsFolder);
                Process.Start("explorer.exe", _plugin.RecordingsFolder);
            }));
            recRow.Children.Add(_recStatus);
            var capture = new StackPanel();
            capture.Children.Add(recRow);
            capture.Children.Add(Note("To use wheel buttons, bind these in SimHub's Controls and events: TPTelemetry.StartRecording, " +
                                      "TPTelemetry.StopRecording, TPTelemetry.RecordValues (start or stop) and TPTelemetry.Mark (flags a moment in the recording)."));
            capture.Children.Add(new CapturePanel(_plugin));
            capture.Children.Add(FfbRowsRow());
            capture.Children.Add(Note("Help: Formula_Reference.md, USB_Capture.md and Game_Outputs.md (in the TP Telemetry download); " +
                                      "each game's formulas are explained in Game_Formulas.md in the game profiles pack."));
            var expander = new Expander
            {
                Header = "Capture table values and FFB",
                Margin = new Thickness(0, 6, 0, 0),
                IsExpanded = false,
                Content = capture,
            };
            _page.Children.Add(expander);
            expander.Expanded += (s, e) => FitPageSoon();
            expander.Collapsed += (s, e) => FitPageSoon();

            // ---- SimHub effects: hardware ticks and the effect profiles
            var effects = new Expander
            {
                Header = "SimHub effects",
                Margin = new Thickness(0, 6, 0, 0),
                IsExpanded = false,
                Content = new EffectsPanel(_plugin, () => Current),
            };
            _page.Children.Add(effects);
            effects.Expanded += (s, e) => FitPageSoon();
            effects.Collapsed += (s, e) => FitPageSoon();

            _scroll = new ScrollViewer
            {
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Content = _page,
            };
            Content = _scroll;
            _grid.Height = 300;
            _scroll.SizeChanged += (s, e) => FitPage();
            _scroll.ScrollChanged += (s, e) => { if (e.ViewportWidthChange != 0 || e.ViewportHeightChange != 0) FitPage(); };
            // Opening the capture section (or a status line wrapping) changes what's left for the table.
            _page.SizeChanged += (s, e) => { if (e.HeightChanged) FitPageSoon(); };

            // ---- wiring
            // The game shown is the game being read: choosing one here activates it, exactly as
            // its command line does, and the command line brings the page back to it.
            _games.SelectionChanged += (s, e) => { if (_loading) return; ShowProfile(); ActivateCurrent(); };
            _name.TextChanged += (s, e) => EditProfile(p => p.DisplayName = _name.Text, refreshCombo: true);
            _prefix.TextChanged += (s, e) => EditProfile(p =>
            {
                var wanted = _prefix.Text.Trim();
                if (_plugin.PrefixTaken(wanted, p))
                {
                    _prefixError = $"Another game already uses the prefix '{Names.Sanitise(wanted)}', so this one stays '{p.Prefix}'. Each game needs its own prefix: it's how the command line picks the game.";
                    return;
                }
                _prefixError = null;
                // renaming the active game's prefix keeps it active
                var was = Names.Sanitise(p.Prefix);
                p.Prefix = wanted;
                if (string.Equals(_plugin.Settings.ActiveGame, was, StringComparison.OrdinalIgnoreCase))
                    _plugin.Settings.ActiveGame = Names.Sanitise(p.Prefix);
            });
            _process.TextChanged += (s, e) => EditProfile(p => p.ProcessName = _process.Text.Trim().Trim('"'));
            WireReference(_maxSpeed, p => p.MaxSpeed, (p, v) => p.MaxSpeed = v);
            WireReference(_maxRevs, p => p.MaxRevs, (p, v) => p.MaxRevs = v);
            _showAddress.IsChecked = _plugin.Settings.ShowAddressColumns;
            ApplyAddressColumns();
            _showAddress.Checked += (s, e) => SetAddressColumns(true);
            _showAddress.Unchecked += (s, e) => SetAddressColumns(false);

            _debounce.Tick += (s, e) => { _debounce.Stop(); ApplyNow(); };
            _live.Tick += (s, e) =>
            {
                // Never let one bad refresh stop the live view for good: log it once and keep going.
                try { RefreshLive(); UpdateFfbRowsButton(); _liveError = null; }
                catch (Exception ex)
                {
                    if (_liveError != ex.Message) { _liveError = ex.Message; Log.Error("Live view", ex); }
                    _gameStatus.Text = "Live view error (see TPTelemetry.log): " + ex.Message;
                }
            };
            Loaded += (s, e) => { _live.Start(); _plugin.ActiveGameChanged += OnActiveGameChanged; OnActiveGameChanged(); FitPage(); };
            Unloaded += (s, e) =>
            {
                _live.Stop();
                _plugin.ActiveGameChanged -= OnActiveGameChanged;
                if (_debounce.IsEnabled) { _debounce.Stop(); ApplyNow(); }
            };

            ReloadGames(_plugin.ActiveProfile ?? _plugin.Profiles.FirstOrDefault());
            // No dialogs while SimHub is building the page: a modal box opened here can end up
            // hidden behind SimHub's window and freeze it. Problems go in the status line instead.
            if (_plugin.LoadErrors.Count > 0)
                _loadErrors = "Some profiles couldn't be loaded (see TPTelemetry.log): " + string.Join("; ", _plugin.LoadErrors);
        }

        /// <summary>Sizes the page to the visible area: at least MinPageWidth wide (scrolling sideways below
        /// that), and the table as tall as the space left, but at least MinGridHeight (the page scrolls below that).</summary>
        void FitPage()
        {
            var vw = _scroll.ViewportWidth; var vh = _scroll.ViewportHeight;
            if (!(vw > 0) || !(vh > 0) || double.IsInfinity(vw) || double.IsInfinity(vh)) return;
            var w = Math.Max(MinPageWidth, vw - 2 * PageMargin);
            if (double.IsNaN(_page.Width) || Math.Abs(_page.Width - w) > 0.5) _page.Width = w;
            // Everything but the table, at its own size (DesiredSize includes margins). Not the page's
            // ActualHeight, which can include stretched empty space.
            double others = 0;
            foreach (UIElement c in _page.Children) if (c != _grid) others += c.DesiredSize.Height;
            if (!(others > 0)) return;
            var h = Math.Max(MinGridHeight, Math.Floor(vh - 2 * PageMargin - others));
            if (double.IsNaN(_grid.Height) || Math.Abs(_grid.Height - h) > 1) _grid.Height = h;
        }

        /// <summary>FitPage once the layout has caught up with a change (a section opening, a line wrapping).</summary>
        void FitPageSoon() => Dispatcher.BeginInvoke(new Action(FitPage), DispatcherPriority.Loaded);

        /// <summary>A Max speed / Max revs box: blank means not set (formulas see 1); anything below 1 becomes 1.</summary>
        void WireReference(TextBox box, Func<GameProfile, double?> get, Action<GameProfile, double?> set)
        {
            void Commit()
            {
                var p = Current;
                if (p == null || _loading) return;
                var t = box.Text.Trim();
                double? v;
                if (t == "") v = null;
                else if (double.TryParse(t, NumberStyles.Float, CultureInfo.InvariantCulture, out var d) ||
                         double.TryParse(t, NumberStyles.Float, CultureInfo.CurrentCulture, out d))
                    v = double.IsNaN(d) || double.IsInfinity(d) ? get(p) : Math.Max(GameProfile.MinReference, d);
                else v = get(p); // not a number: put the old value back
                box.Text = FormatReference(v);
                if (v != get(p)) EditProfile(q => set(q, v), immediate: true);
            }
            box.LostFocus += (s, e) => Commit();
            box.KeyDown += (s, e) => { if (e.Key == System.Windows.Input.Key.Enter || e.Key == System.Windows.Input.Key.Return) Commit(); };
        }

        static string FormatReference(double? v) => v == null ? "" : v.Value.ToString("0.###", CultureInfo.InvariantCulture);

        void SetAddressColumns(bool show)
        {
            _plugin.Settings.ShowAddressColumns = show;
            ApplyAddressColumns();
            try { _plugin.Store.SaveSettings(_plugin.Settings); } catch (Exception e) { Log.Error("Save settings", e); }
        }

        void ApplyAddressColumns()
        {
            var v = _plugin.Settings.ShowAddressColumns ? Visibility.Visible : Visibility.Collapsed;
            foreach (var c in _addressColumns) c.Visibility = v;
        }

        /// <summary>Puts the launch-script lines for the game shown on the clipboard: AutoHotkey v1, v2 and a
        /// batch file, each running the TP Telemetry command, waiting for SimHub, then switching SimHub's game.
        /// Lines starting with ";" are notes to delete. Two commands, because SimHub acts only on the first
        /// command in one run and ignores -switchgame while it's still starting.</summary>
        void CopyCommandLines()
        {
            var p = Current ?? throw new InvalidOperationException("Select or add a game first.");
            var text = LaunchLines.Build(
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SimHubWPF.exe"),
                $"{_plugin.GetType().Name}.{TPTelemetry.ActivatePrefix}{Names.Sanitise(p.Prefix)}",
                p.DisplayName, _plugin.CurrentSimHubGame);
            Clipboard.SetText(text);
            Notice(_plugin.CurrentSimHubGame == ""
                ? "Copied, without the SimHub game line: no SimHub game is selected. Select the game in SimHub, then copy again."
                : $"Copied the launch lines for {p.DisplayName} (AutoHotkey v1, v2 and .bat). Delete the lines starting with ';' before use.");
        }

        void Notice(string text, double seconds = 6)
        {
            _notice = text; _noticeUntil = DateTime.UtcNow.AddSeconds(seconds);
            RefreshLive();
        }

        /// <summary>Message boxes owned by SimHub's window so they can't open hidden behind it.</summary>
        MessageBoxResult Show(string text, string caption = "TP Telemetry", MessageBoxButton buttons = MessageBoxButton.OK)
        {
            var owner = Window.GetWindow(this);
            return owner != null ? MessageBox.Show(owner, text, caption, buttons) : MessageBox.Show(text, caption, buttons);
        }

        #region Layout helpers
        static TextBlock Label(string text, double left = 10) =>
            new TextBlock { Text = text, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(left, 0, 6, 0) };

        static TextBlock Note(string text) =>
            new TextBlock { Text = text, Opacity = 0.75, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 4, 0, 0) };

        Button Btn(string text, Action onClick, string tip = null)
        {
            var b = new Button { Content = text, Margin = new Thickness(0, 2, 6, 2), Padding = new Thickness(8, 3, 8, 3) };
            if (tip != null) b.ToolTip = tip;
            b.Click += (s, e) =>
            {
                try { onClick(); }
                catch (Exception ex) { Show(ex.Message, "TP Telemetry"); }
            };
            return b;
        }

        DataGrid BuildGrid()
        {
            var g = new DataGrid
            {
                ItemsSource = _rows,
                AutoGenerateColumns = false,
                CanUserAddRows = false,
                CanUserDeleteRows = false,
                CanUserSortColumns = false,
                SelectionMode = DataGridSelectionMode.Single,
                HeadersVisibility = DataGridHeadersVisibility.Column,
                MinHeight = MinGridHeight,
            };

            g.Columns.Add(CheckColumn("Export", nameof(VarRow.Enabled)));
            g.Columns.Add(TextColumn("Name", nameof(VarRow.Name), 110));
            var source = new DataGridComboBoxColumn
            {
                Header = "Source",
                ItemsSource = Enum.GetValues(typeof(SourceKind)),
                SelectedItemBinding = new Binding(nameof(VarRow.Source)) { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
                ElementStyle = HiddenWhen(typeof(ComboBox), nameof(VarRow.IsFixed), true),
            };
            var type = new DataGridComboBoxColumn
            {
                Header = "Type",
                ItemsSource = Enum.GetValues(typeof(MemType)),
                SelectedItemBinding = new Binding(nameof(VarRow.Type)) { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
                // Computed rows are always Float, so their type is noise: show it on memory rows only.
                ElementStyle = HiddenWhen(typeof(ComboBox), nameof(VarRow.ShowAddress), false),
            };
            var module = TextColumn("Module", nameof(VarRow.Module), 110);
            var baseOffset = TextColumn("Base offset", nameof(VarRow.BaseOffset), 90, mono: true, memoryOnly: true);
            var offsets = TextColumn("Offsets", nameof(VarRow.Offsets), 90, mono: true, memoryOnly: true);
            _addressColumns = new DataGridColumn[] { source, type, module, baseOffset, offsets };
            foreach (var c in _addressColumns) g.Columns.Add(c);
            g.Columns.Add(TextColumn("Raw", nameof(VarRow.RawText), 80, readOnly: true, mono: true, centre: true));
            var formula = TextColumn("Formula", nameof(VarRow.Formula), 220, mono: true);
            // The function list lives in Formula_Reference.md; hovering the header shows a summary.
            formula.Header = new TextBlock
            {
                Text = "Formula",
                ToolTip = Formula.FunctionHelp + "\n\nRaw is the value read from memory; on a memory row, 'value' in the formula is that Raw value " +
                          "and Output is the result. Leave the formula empty to publish Raw.\nFull reference: Formula_Reference.md",
            };
            g.Columns.Add(formula);
            g.Columns.Add(TextColumn("Output", nameof(VarRow.OutputText), 80, readOnly: true, mono: true, centre: true));
            g.Columns.Add(TextColumn("Status", nameof(VarRow.Status), 180, readOnly: true));
            g.Columns.Add(TextColumn("SimHub property", nameof(VarRow.PropertyName), 220, readOnly: true));
            g.Columns.Add(TextColumn("Notes", nameof(VarRow.Notes), 160));

            // The Connected row at the end belongs to the plugin, not the profile: no editing it.
            g.BeginningEdit += (s, e) => { if (e.Row?.Item is VarRow r && r.IsFixed) e.Cancel = true; };

            // red text for rows with configuration errors
            var style = new Style(typeof(DataGridRow));
            var trigger = new DataTrigger { Binding = new Binding(nameof(VarRow.HasError)), Value = true };
            trigger.Setters.Add(new Setter(Control.ForegroundProperty, Brushes.OrangeRed));
            style.Triggers.Add(trigger);
            g.RowStyle = style;
            return g;
        }

        /// <summary>A cell style that hides the cell's content when the row's <paramref name="path"/> equals <paramref name="value"/>.</summary>
        static Style HiddenWhen(Type element, string path, object value, Style basedOn = null)
        {
            var st = basedOn ?? new Style(element);
            var t = new DataTrigger { Binding = new Binding(path), Value = value };
            t.Setters.Add(new Setter(VisibilityProperty, Visibility.Hidden));
            st.Triggers.Add(t);
            return st;
        }

        static DataGridTextColumn TextColumn(string header, string path, double width, bool readOnly = false, bool mono = false, bool memoryOnly = false, bool centre = false)
        {
            var c = new DataGridTextColumn
            {
                Header = header,
                Binding = new Binding(path) { Mode = readOnly ? BindingMode.OneWay : BindingMode.TwoWay },
                IsReadOnly = readOnly,
                Width = new DataGridLength(width),
            };
            Style es = null;
            if (mono)
            {
                es = new Style(typeof(TextBlock));
                es.Setters.Add(new Setter(TextBlock.FontFamilyProperty, new FontFamily("Consolas")));
            }
            // Raw and Output are centred so the live numbers stand apart from the Formula column beside them.
            if (centre)
            {
                es = es ?? new Style(typeof(TextBlock));
                es.Setters.Add(new Setter(HorizontalAlignmentProperty, HorizontalAlignment.Center));
            }
            // Base offset and offsets mean nothing on computed rows (they read "0" and ""), so hide them there.
            if (memoryOnly) es = HiddenWhen(typeof(TextBlock), nameof(VarRow.ShowAddress), false, es);
            if (es != null) c.ElementStyle = es;
            return c;
        }

        static DataGridColumn CheckColumn(string header, string path)
        {
            // a template column so a single click toggles (DataGridCheckBoxColumn needs two)
            var f = new FrameworkElementFactory(typeof(CheckBox));
            f.SetBinding(ToggleButton_IsChecked, new Binding(path) { Mode = BindingMode.TwoWay, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });
            f.SetBinding(IsEnabledProperty, new Binding(nameof(VarRow.IsEditable)) { Mode = BindingMode.OneWay });
            f.SetValue(HorizontalAlignmentProperty, HorizontalAlignment.Center);
            f.SetValue(VerticalAlignmentProperty, VerticalAlignment.Center);
            return new DataGridTemplateColumn { Header = header, CellTemplate = new DataTemplate { VisualTree = f } };
        }

        static readonly DependencyProperty ToggleButton_IsChecked = System.Windows.Controls.Primitives.ToggleButton.IsCheckedProperty;
        #endregion

        #region Profile list
        void ReloadGames(GameProfile select)
        {
            _loading = true;
            _games.ItemsSource = null;
            _games.ItemsSource = _plugin.Profiles;
            _games.SelectedItem = select ?? _plugin.Profiles.FirstOrDefault();
            _loading = false;
            ShowProfile();
            ActivateCurrent();
        }

        /// <summary>Makes the game on screen the active one (no-op if it already is).</summary>
        void ActivateCurrent()
        {
            var p = Current;
            _plugin.SetActiveGame(p == null ? PluginSettings.NoGame : Names.Sanitise(p.Prefix), "settings page");
        }

        void ShowProfile()
        {
            if (_loading) return;
            _loading = true;
            var p = Current;
            foreach (var box in new[] { _name, _prefix, _process, _maxSpeed, _maxRevs }) box.IsEnabled = p != null;
            _name.Text = p?.DisplayName ?? "";
            _prefix.Text = p?.Prefix ?? "";
            _process.Text = p?.ProcessName ?? "";
            _maxSpeed.Text = FormatReference(p?.MaxSpeed);
            _maxRevs.Text = FormatReference(p?.MaxRevs);
            _prefixError = null;
            _rows.Clear();
            _connectedRow = null;
            if (p != null)
            {
                foreach (var v in p.Variables) _rows.Add(new VarRow(v, Changed));
                _rows.Add(_connectedRow = VarRow.Connected()); // always last
            }
            _loading = false;
            RefreshLive();
        }

        void EditProfile(Action<GameProfile> edit, bool immediate = false, bool refreshCombo = false)
        {
            if (_loading || Current == null) return;
            edit(Current);
            if (refreshCombo) { var sel = Current; _loading = true; _games.Items.Refresh(); _games.SelectedItem = sel; _loading = false; }
            Changed(immediate);
        }

        /// <summary>A command line (or Deactivate) changed the game: show that game.</summary>
        void OnActiveGameChanged()
        {
            var target = _plugin.ActiveProfile;
            if (target != null && target != Current) ReloadGames(target);
            RefreshLive();
        }

        void NewGame()
        {
            var p = new GameProfile { DisplayName = "New game", Prefix = _plugin.UniquePrefix("GAME", null) };
            _plugin.Profiles.Add(p);
            ReloadGames(p);
            ApplyNow();
        }

        void DeleteGame()
        {
            var p = Current;
            if (p == null) return;
            if (Show($"Delete '{p.DisplayName}' and all its variables?", "TP Telemetry", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
            _plugin.Profiles.Remove(p);
            _plugin.Store.MarkRemoved(p.Id);
            ReloadGames(null);
            ApplyNow();
        }

        /// <summary>One Import button for both kinds of file: a profile (.json) or a Cheat Engine table (.CT).</summary>
        void Import()
        {
            var dlg = new OpenFileDialog
            {
                Filter = "Profiles and Cheat Engine tables (*.json, *.CT)|*.json;*.CT;*.ct|TP Telemetry profiles (*.json)|*.json|Cheat Engine tables (*.CT)|*.CT;*.ct",
                Title = "Import a profile or Cheat Engine table",
            };
            if (dlg.ShowDialog() != true) return;
            if (Path.GetExtension(dlg.FileName).Equals(".ct", StringComparison.OrdinalIgnoreCase)) ImportCheatTable(dlg.FileName);
            else ImportProfile(dlg.FileName);
        }

        void ImportCheatTable(string file)
        {
            var result = CheatTableImporter.ImportFile(file);
            result.Profile.Enabled = true;

            GameProfile target = result.Profile;
            if (Current != null)
            {
                var choice = Show(
                    $"Found {result.Profile.Variables.Count} values in {Path.GetFileName(file)}.\n\n" +
                    $"Yes: create a new game\nNo: add them to '{Current.DisplayName}'",
                    "Import Cheat Engine table", MessageBoxButton.YesNoCancel);
                if (choice == MessageBoxResult.Cancel) return;
                if (choice == MessageBoxResult.No)
                {
                    target = Current;
                    var names = target.Variables.Select(v => v.Name).ToList();
                    foreach (var v in result.Profile.Variables)
                    {
                        var n = v.Name; int i = 2;
                        while (names.Contains(n, StringComparer.OrdinalIgnoreCase)) n = v.Name + "_" + i++;
                        v.Name = n; names.Add(n);
                        target.Variables.Add(v);
                    }
                    // Keep the game's process; only fill it in if it was never set.
                    if (string.IsNullOrWhiteSpace(target.ProcessName) && result.Profile.ProcessName != "")
                        target.ProcessName = result.Profile.ProcessName;
                }
            }
            if (target == result.Profile)
            {
                target.Prefix = _plugin.UniquePrefix(target.Prefix, null);
                _plugin.Profiles.Add(target);
            }
            ReloadGames(target);
            ApplyNow();

            var msg = $"Imported {result.Profile.Variables.Count} values.";
            if (target == result.Profile)
                msg += $"\nProcess: {(target.ProcessName == "" ? "(not found, please set it)" : target.ProcessName)}\nPrefix: {target.Prefix} (change it to the name you want in SimHub)";
            if (result.Warnings.Count > 0) msg += "\n\n" + string.Join("\n", result.Warnings);
            Show(msg, "TP Telemetry");
        }

        void ImportProfile(string file)
        {
            var p = ProfileStore.ReadProfile(file) ?? throw new InvalidDataException("Not a profile file");
            p.Enabled = true; // every profile is enabled since 0.12.0
            p.Id = Guid.NewGuid().ToString("N"); // never overwrite an existing game
            var wanted = p.Prefix;
            p.Prefix = _plugin.UniquePrefix(p.Prefix, null);
            _plugin.Profiles.Add(p);
            ReloadGames(p);
            ApplyNow();
            if (!TPTelemetry.SamePrefix(wanted, p.Prefix))
                Show($"A game with the prefix '{Names.Sanitise(wanted)}' already exists, so this one was imported as '{p.Prefix}'.", "TP Telemetry");
        }

        void ExportProfile()
        {
            var p = Current;
            if (p == null) return;
            var dlg = new SaveFileDialog { Filter = "TP Telemetry profile (*.json)|*.json", FileName = Names.Sanitise(p.Prefix) + ".json" };
            if (dlg.ShowDialog() != true) return;
            ProfileStore.WriteProfile(p, dlg.FileName);
        }
        #endregion

        #region Variables
        VarRow Selected => _grid.SelectedItem as VarRow;

        /// <summary>The add/remove button for the USB force feedback rows, under USB capture.</summary>
        UIElement FfbRowsRow()
        {
            var row = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
            _ffbRowsBtn = Btn("Add FFB values to table", ToggleFfbRows);
            row.Children.Add(_ffbRowsBtn);
            row.Children.Add(_ffbRowsNote);
            UpdateFfbRowsButton();
            return row;
        }

        /// <summary>Label follows the game shown: Remove once every USB value has its row, otherwise Add.</summary>
        void UpdateFfbRowsButton()
        {
            if (_ffbRowsBtn == null) return;
            var p = Current;
            int have = Core.Ffb.FfbTableRows.CountPresent(p), all = Core.Ffb.FfbTableRows.Channels.Length;
            bool remove = p != null && have == all;
            _ffbRowsBtn.Content = remove ? "Remove FFB values from table" : "Add FFB values to table";
            _ffbRowsBtn.IsEnabled = p != null;
            _ffbRowsNote.Text = p == null ? "Select a game first."
                : remove ? $"The {all} USB values (wheel_force, wheel_spring, wheel_steer...) are rows in {p.DisplayName}'s table."
                : have > 0 ? $"{have} of {all} USB values are in {p.DisplayName}'s table; this adds the rest."
                : $"Adds the {all} USB values (wheel_force, wheel_spring, wheel_steer...) as rows in {p.DisplayName}'s table.";
        }

        void ToggleFfbRows()
        {
            var p = Current ?? throw new InvalidOperationException("Create or select a game first.");
            if (Core.Ffb.FfbTableRows.AllPresent(p))
            {
                if (Show($"Remove the {Core.Ffb.FfbTableRows.Channels.Length} USB force feedback rows from '{p.DisplayName}'?\n\n" +
                         "Rows of your own that use them in formulas will show an error until you add them back.",
                         "TP Telemetry", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
                Core.Ffb.FfbTableRows.RemoveAll(p);
            }
            else Core.Ffb.FfbTableRows.AddMissing(p);
            ShowProfile();
            ApplyNow();
            UpdateFfbRowsButton();
        }

        /// <summary>A new memory row (Source can be changed to Computed in the table).</summary>
        void AddRow() => AddVar(SourceKind.Memory);

        void AddVar(SourceKind kind, VariableDef template = null)
        {
            var p = Current ?? throw new InvalidOperationException("Create or select a game first.");
            var v = template ?? new VariableDef
            {
                Source = kind,
                Name = UniqueName(p, kind == SourceKind.Memory ? "new_value" : "new_calc"), // "value" is reserved in formulas
                Module = kind != SourceKind.Memory ? "" : string.IsNullOrWhiteSpace(p.ProcessName) ? ProcessMemory.MainModule : p.ProcessName,
                Formula = kind == SourceKind.Computed ? "0" : "",
            };
            // below the selected row; at the end of the game's rows (above Connected) otherwise
            int at = Selected != null && !Selected.IsFixed ? _rows.IndexOf(Selected) + 1 : p.Variables.Count;
            p.Variables.Insert(at, v);
            var row = new VarRow(v, Changed);
            _rows.Insert(at, row);
            _grid.SelectedItem = row;
            _grid.ScrollIntoView(row);
            ApplyNow();
        }

        void Duplicate()
        {
            var sel = Selected;
            if (sel == null || sel.IsFixed) throw new InvalidOperationException("Select one of the game's rows first.");
            var copy = sel.Def.Clone();
            copy.Name = UniqueName(Current, sel.Def.Name + "_copy");
            AddVar(copy.Source, copy);
        }

        void Move(int dir)
        {
            var row = Selected; var p = Current;
            if (row == null || p == null || row.IsFixed) return;
            int i = _rows.IndexOf(row), j = i + dir;
            if (j < 0 || j >= p.Variables.Count) return; // Connected stays last
            _rows.Move(i, j);
            p.Variables.RemoveAt(i); p.Variables.Insert(j, row.Def);
            _grid.SelectedItem = row;
            ApplyNow();
        }

        void RemoveVar()
        {
            var row = Selected; var p = Current;
            if (row == null || p == null) return;
            if (row.IsFixed) throw new InvalidOperationException("The Connected row belongs to the plugin and can't be removed.");
            if (Show($"Remove '{row.Name}'?", "TP Telemetry", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
            p.Variables.Remove(row.Def);
            _rows.Remove(row);
            ApplyNow();
        }

        static string UniqueName(GameProfile p, string baseName)
        {
            var n = baseName; int i = 2;
            while (p.Variables.Any(v => string.Equals(Names.Sanitise(v.Name), Names.Sanitise(n), StringComparison.OrdinalIgnoreCase))) n = baseName + "_" + i++;
            return n;
        }
        #endregion

        #region Apply and live view
        /// <summary>Text edits wait for a pause in typing; toggles and structural changes apply at once.</summary>
        void Changed(bool immediate)
        {
            if (_loading) return;
            if (immediate) { _debounce.Stop(); ApplyNow(); }
            else { _debounce.Stop(); _debounce.Start(); }
        }

        void ApplyNow()
        {
            try { _plugin.Apply(); }
            catch (Exception e) { _gameStatus.Text = "Couldn't save: " + e.Message; }
            RefreshLive();
        }

        void RefreshLive()
        {
            RefreshRecording();
            var p = Current;
            string status;
            ProfileState ps = null;
            if (p == null) status = "No games yet: click Add Game, or Import a profile or Cheat Engine table.";
            else
            {
                ps = _plugin.Engine.Profiles.FirstOrDefault(x => x.Def.Id == p.Id);
                status = ps == null ? "" : ps.Connected && ps.SampleRateHz > 0 ? $"{ps.Status}  ·  {ps.SampleRateHz:0} samples/s" : ps.Status;
                if (_plugin.Settings.ActiveGame == PluginSettings.NoGame)
                    status = "Stopped by TPTelemetry.Deactivate. Choose the game again here, or run its command line (Copy Commandlines).";
                var pfx = Names.Sanitise(p.Prefix);
                if (_prefixError != null) status = _prefixError + "\n" + status;
                else if (pfx != p.Prefix) status = $"'{p.Prefix}' has characters SimHub formulas can't use, so its properties start TPTelemetry.{pfx}_\n" + status;
            }
            if (_notice != null && DateTime.UtcNow < _noticeUntil) status = _notice;
            else _notice = null;
            if (_loadErrors != null) status += "\n" + _loadErrors;
            if (_gameStatus.Text != status) _gameStatus.Text = status;
            if (p == null) return;

            int n = p.Variables.Count;
            bool pending = _debounce.IsEnabled || ps == null || ps.Vars.Length != n;
            for (int i = 0; i < n && i < _rows.Count; i++)
            {
                try { _rows[i].UpdateLive(pending ? null : ps.Vars[i], ps?.Connected ?? false); }
                catch (Exception ex)
                {
                    // one row's problem mustn't freeze the others
                    if (_liveError != ex.Message) { _liveError = ex.Message; Log.Error($"Live view, row {_rows[i].Name}", ex); }
                }
            }
            _connectedRow?.UpdateConnected(ps?.Connected, ps == null ? null : _plugin.Engine.ConnectedPropertyName(p));
        }
        #endregion
    }
}
