using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using TeknoTelemetry.Core;

namespace TeknoTelemetry.UI
{
    /// <summary>
    /// "SimHub effects": tick the kinds of hardware you have, and one button writes SimHub profiles
    /// holding the TP effects for them (Bass Shakers, and ShakeIt Motors). Full steps: SimHub_Effects.md.
    /// </summary>
    public sealed class EffectsPanel : StackPanel
    {
        readonly TPTelemetry _plugin;
        readonly TextBlock _result = new TextBlock { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 4, 0, 0) };

        EffectHardware Hw => _plugin.Settings.Effects ?? (_plugin.Settings.Effects = new EffectHardware());
        string Folder => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PluginsData", "TPTelemetry", "SimHub effects");

        public EffectsPanel(TPTelemetry plugin, Func<GameProfile> current)
        {
            _plugin = plugin;
            Margin = new Thickness(0, 4, 0, 0);

            Children.Add(Note("Tick the hardware you have. The button writes SimHub profiles holding the \"TP -\" effects for it, which work " +
                              "in every game. Import them once in SimHub (ShakeIt Bass Shakers or ShakeIt Motors, Profiles manager, Import); " +
                              "SimHub_Effects.md has the steps, and how to give pedal shakers and fans their own channels."));

            var bass = new WrapPanel { Margin = new Thickness(0, 4, 0, 0) };
            bass.Children.Add(Label("Bass Shaker:"));
            bass.Children.Add(Tick("Seat", h => h.Seat, (h, v) => h.Seat = v));
            bass.Children.Add(Tick("Pedal box", h => h.PedalBox, (h, v) => h.PedalBox = v));
            bass.Children.Add(Tick("Gas pedal", h => h.GasPedal, (h, v) => h.GasPedal = v));
            bass.Children.Add(Tick("Brake pedal", h => h.BrakePedal, (h, v) => h.BrakePedal = v));
            bass.Children.Add(Tick("Clutch pedal", h => h.ClutchPedal, (h, v) => h.ClutchPedal = v));
            Children.Add(bass);
            var motors = new WrapPanel { Margin = new Thickness(0, 2, 0, 0) };
            motors.Children.Add(Label("Shaker Motor:"));
            motors.Children.Add(Tick("Seat", h => h.Motors, (h, v) => h.Motors = v));
            motors.Children.Add(Tick("Pedal box", h => h.MotorPedalBox, (h, v) => h.MotorPedalBox = v));
            motors.Children.Add(Tick("Gas pedal", h => h.MotorGasPedal, (h, v) => h.MotorGasPedal = v));
            motors.Children.Add(Tick("Brake pedal", h => h.MotorBrakePedal, (h, v) => h.MotorBrakePedal = v));
            motors.Children.Add(Tick("Clutch pedal", h => h.MotorClutchPedal, (h, v) => h.MotorClutchPedal = v));
            motors.Children.Add(Tick("Fans (as motors)", h => h.Fans, (h, v) => h.Fans = v));
            Children.Add(motors);

            Children.Add(Note("These profiles are for the whole plugin, not per game: whichever game is selected above, the button makes the same " +
                              "files. Make them once for each kind of hardware (one for Bass Shakers, one for Shaker Motors), and again only " +
                              "when you change the ticks or update the plugin."));

            var buttons = new WrapPanel { Margin = new Thickness(0, 4, 0, 0) };
            buttons.Children.Add(Btn("Create TP Effect Profiles", Create));
            buttons.Children.Add(Btn("Open Effect Profiles Folder", () => { Directory.CreateDirectory(Folder); Process.Start("explorer.exe", Folder); }));
            Children.Add(buttons);
            Children.Add(_result);
        }

        static TextBlock Label(string text) => new TextBlock { Text = text, FontWeight = FontWeights.SemiBold, Width = 100, Margin = new Thickness(0, 2, 6, 2), VerticalAlignment = VerticalAlignment.Center };

        CheckBox Tick(string label, Func<EffectHardware, bool> get, Action<EffectHardware, bool> set)
        {
            var c = new CheckBox { Content = label, IsChecked = get(Hw), Margin = new Thickness(0, 2, 14, 2), VerticalAlignment = VerticalAlignment.Center };
            c.Checked += (s, e) => { set(Hw, true); Save(); };
            c.Unchecked += (s, e) => { set(Hw, false); Save(); };
            return c;
        }

        void Save()
        {
            try { _plugin.Store.SaveSettings(_plugin.Settings); } catch (Exception e) { Log.Error("Save settings", e); }
        }

        void Create()
        {
            if (!Hw.AnyBassShakers && !Hw.AnyMotors) { _result.Text = "Tick at least one kind of hardware first."; return; }
            var files = SimHubProfiles.Write(Hw, Folder);
            var bass = Hw.AnyBassShakers ? SimHubProfiles.BassEffects(Hw).Count : 0;
            var motors = Hw.AnyMotors ? SimHubProfiles.MotorEffects(Hw).Count : 0;
            var lines = files.Select(f => f.EndsWith(SimHubProfiles.BassFile)
                ? $"{SimHubProfiles.BassFile} ({bass} effects): import in ShakeIt Bass Shakers"
                : $"{SimHubProfiles.MotorsFile} ({motors} effects): import in ShakeIt Motors");
            var named = Hw.AnyPedal || Hw.AnyMotorPedal || Hw.Fans;
            _result.Text = "Saved to the effect profiles folder:\n  " + string.Join("\n  ", lines) +
                           "\nIn SimHub: Profiles manager, Import, choose the file, then select the \"TP Telemetry\" profile. Delete an older TP Telemetry profile first." +
                           (named ? "\nPedal and fan effects play only where you map them, in Sound Output (or the Motors output), Custom channel map: see SimHub_Effects.md." : "");
            Log.Info("SimHub effect profiles written: " + string.Join(", ", files));
            Process.Start("explorer.exe", Folder);
        }

        static TextBlock Note(string text) => new TextBlock { Text = text, Opacity = 0.75, TextWrapping = TextWrapping.Wrap };

        Button Btn(string text, Action onClick)
        {
            var b = new Button { Content = text, Margin = new Thickness(0, 2, 6, 2), Padding = new Thickness(8, 3, 8, 3) };
            b.Click += (s, e) => { try { onClick(); } catch (Exception ex) { _result.Text = "Couldn't write the profiles: " + ex.Message; Log.Error("Effect profiles", ex); } };
            return b;
        }
    }
}
