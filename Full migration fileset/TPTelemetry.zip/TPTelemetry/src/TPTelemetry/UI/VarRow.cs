using System;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using TeknoTelemetry.Core;

namespace TeknoTelemetry.UI
{
    /// <summary>Grid row: edits a <see cref="VariableDef"/> and shows its live values.</summary>
    public sealed class VarRow : INotifyPropertyChanged
    {
        public VariableDef Def { get; }
        readonly Action<bool> _changed; // arg: structural (apply immediately)

        public VarRow(VariableDef def, Action<bool> changed) { Def = def; _changed = changed; }

        /// <summary>The fixed last row showing TPTelemetry.PREFIX_Connected. Not a variable: it can't be
        /// edited, moved, removed or unticked.</summary>
        public static VarRow Connected() => new VarRow(new VariableDef
        {
            Name = "Connected", Enabled = true, Source = SourceKind.Computed, Formula = "", Module = "", BaseOffset = "", Offsets = "",
            Notes = "Added by the plugin for every game: True while it is attached to the game's process, False otherwise. Can't be edited.",
        }, _ => { }) { IsFixed = true };

        public bool IsFixed { get; private set; }
        public bool IsEditable => !IsFixed;
        /// <summary>Show the Type, Base offset and Offsets cells (memory rows only).</summary>
        public bool ShowAddress => IsMemory && !IsFixed;

        /// <summary>Live value for the Connected row.</summary>
        internal void UpdateConnected(bool? connected, string propertyName)
        {
            var output = connected == null ? "" : connected.Value ? "True" : "False";
            var prop = string.IsNullOrEmpty(propertyName) ? "" : "TPTelemetry." + propertyName;
            if (output != OutputText) { OutputText = output; Raise(nameof(OutputText)); }
            if (prop != PropertyName) { PropertyName = prop; Raise(nameof(PropertyName)); }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        void Raise([CallerMemberName] string n = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));

        void Set<T>(T current, T value, Action<T> set, bool immediate = false, [CallerMemberName] string n = null)
        {
            if (IsFixed) { Raise(n); return; }
            if (Equals(current, value)) return;
            set(value);
            Raise(n);
            _changed(immediate);
        }

        public bool Enabled { get => Def.Enabled; set => Set(Def.Enabled, value, v => Def.Enabled = v, true); }
        public string Name
        {
            get => Def.Name;
            set
            {
                var n = (value ?? "").Trim();
                if (IsFixed) { Raise(nameof(Name)); return; }
                if (IsReserved(n))
                {
                    // refuse, and put the old name back in the cell
                    _nameError = $"'{n}' is reserved (it means something in formulas), so the name stayed '{Def.Name}'";
                    Raise(nameof(Name)); Raise(nameof(Status));
                    return;
                }
                _nameError = null;
                Set(Def.Name, n, v => Def.Name = v);
            }
        }
        string _nameError;

        static bool IsReserved(string n)
        {
            var key = Names.Sanitise(n);
            return TeknoTelemetry.Core.Expressions.Formula.IsReservedName(key)
                   || key.Equals("Connected", StringComparison.OrdinalIgnoreCase);
        }
        public SourceKind Source
        {
            get => Def.Source;
            set { Set(Def.Source, value, v => Def.Source = v, true); Raise(nameof(IsMemory)); Raise(nameof(ShowAddress)); }
        }
        public bool IsMemory => Def.Source == SourceKind.Memory;
        public MemType Type { get => Def.Type; set => Set(Def.Type, value, v => Def.Type = v); }
        public string Module { get => Def.Module; set => Set(Def.Module, (value ?? "").Trim().Trim('"'), v => Def.Module = v); }
        public string BaseOffset { get => Def.BaseOffset; set => Set(Def.BaseOffset, (value ?? "").Trim(), v => Def.BaseOffset = v); }
        public string Offsets { get => Def.Offsets; set => Set(Def.Offsets, (value ?? "").Trim(), v => Def.Offsets = v); }
        public string Formula { get => Def.Formula; set => Set(Def.Formula, (value ?? "").Trim(), v => Def.Formula = v); }
        public string Notes { get => Def.Notes; set => Set(Def.Notes, value ?? "", v => Def.Notes = v); }

        // live, read-only
        public string RawText { get; private set; } = "";
        public string OutputText { get; private set; } = "";
        public string Status { get; private set; } = "";
        public string PropertyName { get; private set; } = "";
        public bool HasError { get; private set; }

        internal void UpdateLive(VarState s, bool connected)
        {
            string raw = s == null || Def.Source == SourceKind.Computed ? "" : Fmt(s.Raw);
            string output = s == null ? "" : Fmt(s.Output);
            string status = _nameError ?? (s == null ? "(applying…)" : (!connected && !s.HasConfigError ? "" : s.Status));
            string prop = s == null ? "" : (Def.Enabled ? "TPTelemetry." + s.PropertyName : "(not exported)");
            bool err = s?.HasConfigError ?? false;

            if (raw != RawText) { RawText = raw; Raise(nameof(RawText)); }
            if (output != OutputText) { OutputText = output; Raise(nameof(OutputText)); }
            if (status != Status) { Status = status; Raise(nameof(Status)); }
            if (prop != PropertyName) { PropertyName = prop; Raise(nameof(PropertyName)); }
            if (err != HasError) { HasError = err; Raise(nameof(HasError)); }
        }

        static string Fmt(double v)
        {
            if (double.IsNaN(v)) return "-";
            if (double.IsInfinity(v)) return v > 0 ? "inf" : "-inf";
            var a = Math.Abs(v);
            if (a != 0 && (a >= 1e7 || a < 1e-3)) return v.ToString("G4", CultureInfo.InvariantCulture);
            return v.ToString("0.###", CultureInfo.InvariantCulture);
        }
    }
}
