using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Media;
using GameReaderCommon;
using SimHub.Plugins;
using TeknoTelemetry.Core;
using TeknoTelemetry.UI;

namespace TeknoTelemetry
{
    /// <summary>
    /// Publishes values read from TeknoParrot games' memory as SimHub properties,
    /// named TPTelemetry.{Prefix}_{Variable}, e.g. TPTelemetry.WMMT3DXP_speed.
    ///
    /// Reading runs on its own thread at PollRateHz regardless of which game SimHub has selected.
    /// </summary>
    [PluginDescription("Telemetry for TeknoParrot games that don't expose it, read from game memory")]
    [PluginAuthor("TPTelemetry")]
    [PluginName("TP Telemetry")]
    public class TPTelemetry : IPlugin, IDataPlugin, IWPFSettingsV2
    {
        public PluginManager PluginManager { get; set; }
        public ImageSource PictureIcon => Icon.Value;
        public string LeftMenuTitle => "TP Telemetry";

        internal List<GameProfile> Profiles { get; private set; } = new List<GameProfile>();
        internal PluginSettings Settings { get; private set; } = new PluginSettings();
        internal TelemetryEngine Engine { get; private set; }
        internal ProfileStore Store { get; private set; }
        internal TeknoTelemetry.Core.Ffb.FfbCapture Ffb { get; private set; }
        internal TeknoTelemetry.Core.TeknoParrot.TpSharedMemory Tp { get; private set; }
        internal TeknoTelemetry.Core.Outputs.NetOutputsClient Outputs { get; private set; }
        internal List<string> LoadErrors { get; } = new List<string>();

        readonly HashSet<string> _attached = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        readonly HashSet<string> _actions = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        /// <summary>Raised on the UI thread when the active game changes (command line or settings page).</summary>
        internal event Action ActiveGameChanged;

        internal const string ActivatePrefix = "Activate_";
        internal const string NoneAction = "Deactivate";

        /// <summary>The game being shown and read. Prefixes are unique, so this is at most one profile.</summary>
        internal GameProfile ActiveProfile => Profiles.FirstOrDefault(p => SamePrefix(p.Prefix, Settings.ActiveGame));

        internal static bool SamePrefix(string a, string b) =>
            !string.IsNullOrWhiteSpace(a) && !string.IsNullOrWhiteSpace(b) &&
            string.Equals(Names.Sanitise(a), Names.Sanitise(b), StringComparison.OrdinalIgnoreCase);

        /// <summary>True if another game already uses this prefix (compared as published, any case).</summary>
        internal bool PrefixTaken(string prefix, GameProfile except) =>
            Profiles.Any(p => p != except && SamePrefix(p.Prefix, prefix)) ||
            SamePrefix(prefix, "Car") || SamePrefix(prefix, "Lamp"); // TPTelemetry.Car_* and Lamp_* are the common values and lamps

        /// <summary>The wanted prefix, or the same with 2, 3, ... appended if it's taken.</summary>
        internal string UniquePrefix(string wanted, GameProfile except)
        {
            wanted = string.IsNullOrWhiteSpace(wanted) ? "GAME" : wanted.Trim();
            var p = wanted; int i = 2;
            while (PrefixTaken(p, except)) p = wanted + i++;
            return p;
        }

        /// <summary>Set if Init failed; the settings page shows it instead of the editor.</summary>
        internal string InitError { get; private set; }

        PluginManager _pm;

        /// <summary>SimHub's selected game code (DataCorePlugin.CurrentGame), e.g. AssettoCorsa or
        /// Custom_580b91a2-...; empty if none or unavailable.</summary>
        internal string CurrentSimHubGame
        {
            get
            {
                try { return (_pm ?? PluginManager)?.GetPropertyValue("DataCorePlugin.CurrentGame")?.ToString()?.Trim() ?? ""; }
                catch { return ""; }
            }
        }

        public void Init(PluginManager pluginManager)
        {
            _pm = pluginManager;
            // Nothing here may block or throw: SimHub calls Init on its UI thread.
            Engine = new TelemetryEngine();
            Ffb = new TeknoTelemetry.Core.Ffb.FfbCapture();
            Tp = new TeknoTelemetry.Core.TeknoParrot.TpSharedMemory();
            Outputs = new TeknoTelemetry.Core.Outputs.NetOutputsClient();
            try
            {
                var dataDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PluginsData", "TPTelemetry");
                Directory.CreateDirectory(dataDir);
                Log.FilePath = Path.Combine(dataDir, "TPTelemetry.log");
                Log.Info($"Init: plugin {GetType().Assembly.GetName().Version}, SimHub folder {AppDomain.CurrentDomain.BaseDirectory}, " +
                         $"{(Environment.Is64BitProcess ? "64" : "32")}-bit, thread {System.Threading.Thread.CurrentThread.ManagedThreadId}");

                Store = new ProfileStore(Path.Combine(dataDir, "Profiles"));
                Settings = Store.LoadSettings();
                Profiles = Store.LoadAll(LoadErrors);
                foreach (var e in LoadErrors) Log.Error("Profile load: " + e);
                // 0.12.0 removed the Enabled box: the selected game is the one read. Profiles saved
                // disabled by an older version would otherwise be stuck off with no way to turn them on.
                foreach (var p in Profiles) p.Enabled = true;
                Log.Info($"Init: {Profiles.Count} profile(s) loaded");

                // The command line selects a game by prefix, so prefixes must be unique.
                bool renamed = false;
                foreach (var p in Profiles.ToList())
                {
                    if (!PrefixTaken(p.Prefix, p) || Profiles.IndexOf(Profiles.First(o => SamePrefix(o.Prefix, p.Prefix))) == Profiles.IndexOf(p)) continue;
                    var was = p.Prefix;
                    p.Prefix = UniquePrefix(p.Prefix, p);
                    Log.Info($"'{p.DisplayName}' shared the prefix {was} with another game; renamed to {p.Prefix}");
                    renamed = true;
                }

                Engine.PropertiesChanged += AttachProperties;

                // 64-bit games: SimHub is 32-bit, so TPTelemetryHelper64.exe (beside this DLL) reads them.
                if (!Environment.Is64BitProcess)
                {
                    var here = Path.GetDirectoryName(GetType().Assembly.Location);
                    if (string.IsNullOrEmpty(here)) here = AppDomain.CurrentDomain.BaseDirectory;
                    var helperExe = Path.Combine(here, TeknoTelemetry.Core.Remote.HelperLauncher.ExeName);
                    var launch = TeknoTelemetry.Core.Remote.HelperLauncher.ForExe(helperExe);
                    Engine.RemoteMemoryFactory = () => new TeknoTelemetry.Core.Remote.HelperClient(launch);
                    Log.Info($"Init: 64-bit games are read through {helperExe}{(File.Exists(helperExe) ? "" : " (not found: copy it there)")}");
                }

                // Force feedback: one capture for all games, published as TPTelemetry.FFB_force etc.
                if (Settings.Ffb == null) Settings.Ffb = new TeknoTelemetry.Core.Ffb.FfbSettings();
                Ffb.CapturesFolder = Path.Combine(dataDir, "Captures");
                Engine.FfbSource = Ffb.Snapshot;
                for (int i = 0; i < TeknoTelemetry.Core.Ffb.FfbChannels.Count; i++)
                {
                    int ch = i;
                    this.AttachDelegate("FFB_" + TeknoTelemetry.Core.Ffb.FfbChannels.Names[ch], () =>
                    {
                        var v = Engine.FfbValue(ch);
                        return double.IsNaN(v) ? 0.0 : v;
                    });
                }
                this.AttachDelegate("FFB_Status", () => Ffb.Status);
                // The wheel found at a new USB address, or its IDs learnt: keep the settings in step (0.16.0).
                Ffb.DeviceChanged += d =>
                {
                    var s = Settings.Ffb;
                    s.Interface = d.Interface; s.Device = d.Device; s.DeviceName = d.DeviceName;
                    s.VendorId = d.VendorId; s.ProductId = d.ProductId;
                    try { Store?.SaveSettings(Settings); } catch (Exception e) { Log.Error("Save settings", e); }
                };
                ApplyFfb(save: false);

                // TeknoParrot shared memory: TPTelemetry.TP_jvs0 .. TP_jvs15, TP_connected
                if (Settings.TeknoParrotSharedMemory) Engine.TpSource = Tp.Snapshot;
                for (int i = 0; i < TeknoTelemetry.Core.TeknoParrot.TpChannels.Count; i++)
                {
                    int ch = i;
                    this.AttachDelegate("TP_" + TeknoTelemetry.Core.TeknoParrot.TpChannels.Identifier(ch).Substring(3), () =>
                    {
                        var v = Engine.TpValue(ch);
                        return double.IsNaN(v) ? 0.0 : v;
                    });
                }
                this.AttachDelegate("TP_Status", () => Tp.Status);

                // Game outputs: TPTelemetry.Output_<name>, added as each output first appears
                if (Settings.Outputs == null) Settings.Outputs = new TeknoTelemetry.Core.Outputs.OutputsSettings();
                Settings.Outputs.Enabled = true; // 0.12.0: always on (the settings page no longer has a switch)
                Engine.OutputSource = Outputs.Get;
                Engine.OutputNames = () => Outputs.All().Select(kv => kv.Key);
                Outputs.NewOutput += name => OnUiThread(() => AttachOutput(name));
                this.AttachDelegate("Outputs_Game", () => Outputs.Game);
                this.AttachDelegate("Outputs_Paused", () => Outputs.Paused);
                this.AttachDelegate("Outputs_Status", () => Outputs.Status);
                Outputs.Apply(Settings.Outputs);
                // Common values for SimHub effects that work in every game: TPTelemetry.Car_impact etc.
                for (int i = 0; i < CommonValues.Outputs.Length; i++)
                {
                    int k = i;
                    this.AttachDelegate(CommonValues.PropertyPrefix + CommonValues.Outputs[k].Name, () => Engine.Common.Get(k));
                }
                // 0.20.0: the gear as text for dashboards, and the common lamps (TPTelemetry.Lamp_start etc.)
                this.AttachDelegate(CommonValues.PropertyPrefix + "gear_text", () => Engine.Common.GearText);
                for (int i = 0; i < CommonValues.Lamps.Length; i++)
                {
                    int k = i;
                    this.AttachDelegate(CommonValues.LampPropertyPrefix + CommonValues.Lamps[k].Name, () => Engine.Common.GetLamp(k));
                }
                this.AttachDelegate("ActiveGame", () => Engine.ActiveGamePrefix);
                this.AttachDelegate("SelectedGame", () => Settings.ActiveGame ?? "");
                RegisterAction(NoneAction, PluginSettings.NoGame);
                RegisterAction("RecordValues", ToggleRecording);
                RegisterAction("StartRecording", () => { if (Engine.Recorder == null) ToggleRecording(); });
                RegisterAction("StopRecording", () => { if (Engine.Recorder != null) ToggleRecording(); });
                RegisterAction("Mark", Mark);
                this.AttachDelegate("Recording", () => Engine.Recorder != null);

                // When SimHub is started by a launch script, the -triggeraction may arrive before
                // our action exists. Read it from SimHub's own command line as well.
                ApplyCommandLine(Environment.GetCommandLineArgs());
                // There is always one selected game (or none, after Deactivate).
                if (string.IsNullOrWhiteSpace(Settings.ActiveGame))
                    Settings.ActiveGame = Profiles.Count > 0 ? Names.Sanitise(Profiles[0].Prefix) : PluginSettings.NoGame;
                Log.Info("Init: active game " + Settings.ActiveGame);
                Apply(save: renamed);
                Engine.Start();
                Log.Info("Init: done");
            }
            catch (Exception e)
            {
                InitError = e.ToString();
                Log.Error("Init failed", e);
            }
        }

        /// <summary>Pushes the current definitions to the engine (as copies, so edits in the UI
        /// never race the poll thread) and saves them.</summary>
        internal void Apply(bool save = true)
        {
            if (Store == null) return;
            lock (_applyLock)
            {
                Engine.Load(Profiles.Select(ProfileStore.Clone).ToList(), Settings);
                foreach (var p in Profiles) RegisterAction(ActivatePrefix + Names.Sanitise(p.Prefix), Names.Sanitise(p.Prefix));
                if (save)
                {
                    Store.SaveAll(Profiles);
                    Store.SaveSettings(Settings);
                }
            }
        }
        readonly object _applyLock = new object();

        /// <summary>Starts, restarts or stops FFB capture to match the settings, and saves them.</summary>
        internal void ApplyFfb(bool save = true)
        {
            try { Ffb.Apply(Settings.Ffb); }
            catch (Exception e) { Log.Error("FFB apply", e); }
            if (Engine != null) Engine.Common.UsbStandIn = Settings.Ffb.UseForCommonValues;
            if (save && Store != null) { try { Store.SaveSettings(Settings); } catch (Exception e) { Log.Error("Save settings", e); } }
        }

        /// <summary>Selects which game reads memory: a prefix, "" for any enabled game, or "-" for none.</summary>
        internal void SetActiveGame(string game, string why)
        {
            game = (game ?? "").Trim();
            if (string.Equals(Settings.ActiveGame ?? "", game, StringComparison.OrdinalIgnoreCase)) return;
            Settings.ActiveGame = game;
            Log.Info($"Active game -> {(game == "" ? "(auto)" : game == PluginSettings.NoGame ? "(none)" : game)} ({why})");
            Apply();
            ActiveGameChanged?.Invoke();
        }

        /// <summary>
        /// SimHub actions, triggered from a launch script with
        ///   SimHubWPF.exe -triggeraction TPTelemetry.Activate_WMMT3DXP
        /// (starts SimHub if needed, otherwise forwards to the running copy).
        /// </summary>
        void RegisterAction(string action, string game) =>
            RegisterAction(action, () => SetActiveGame(game, "action " + action));

        void RegisterAction(string action, Action run)
        {
            if (!_actions.Add(action)) return;
            try { this.AddAction(action, (a, b) => OnUiThread(run)); }
            catch (Exception e) { Log.Error("AddAction " + action, e); }
        }

        internal string RecordingsFolder => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PluginsData", "TPTelemetry", "Recordings");

        /// <summary>Starts or stops recording values to CSV. Bindable as TPTelemetry.RecordValues.</summary>
        internal void ToggleRecording()
        {
            if (Engine.Recorder != null) Engine.StopRecording();
            else Engine.StartRecording(RecordingsFolder);
            RecordingChanged?.Invoke();
        }

        /// <summary>Numbers an event in the recording. Bindable as TPTelemetry.Mark (e.g. a wheel button).</summary>
        internal void Mark()
        {
            var n = Engine.Mark();
            if (n > 0) Log.Info("Marker " + n);
            RecordingChanged?.Invoke();
        }

        internal event Action RecordingChanged;

        readonly HashSet<string> _outputProps = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        void AttachOutput(string name)
        {
            var safe = Names.Sanitise(name);
            if (!_outputProps.Add(safe)) return;
            try { this.AttachDelegate("Output_" + safe, () => { var v = Outputs.Get(name); return double.IsNaN(v) ? 0.0 : v; }); }
            catch (Exception e) { Log.Error("AttachDelegate Output_" + safe, e); }
        }

        internal void ApplyOutputs()
        {
            Outputs.Apply(Settings.Outputs);
            try { Store.SaveSettings(Settings); } catch (Exception e) { Log.Error("Save settings", e); }
        }

        void ApplyCommandLine(string[] args)
        {
            for (int i = 0; i + 1 < args.Length; i++)
            {
                if (!string.Equals(args[i], "-triggeraction", StringComparison.OrdinalIgnoreCase)) continue;
                var name = args[i + 1].Trim();
                var dot = name.IndexOf('.');
                if (dot >= 0)
                {
                    if (!name.Substring(0, dot).Equals(GetType().Name, StringComparison.OrdinalIgnoreCase)) continue;
                    name = name.Substring(dot + 1);
                }
                if (name.Equals(NoneAction, StringComparison.OrdinalIgnoreCase)) Settings.ActiveGame = PluginSettings.NoGame;
                else if (name.StartsWith(ActivatePrefix, StringComparison.OrdinalIgnoreCase)) Settings.ActiveGame = name.Substring(ActivatePrefix.Length);
                else continue;
                Log.Info("Command line: " + args[i + 1]);
                try { Store.SaveSettings(Settings); } catch (Exception e) { Log.Error("Save settings", e); }
            }
        }

        static void OnUiThread(Action a)
        {
            void Safe() { try { a(); } catch (Exception e) { Log.Error("Action", e); } }
            var d = System.Windows.Application.Current?.Dispatcher;
            if (d == null || d.CheckAccess()) Safe();
            else d.BeginInvoke(new Action(Safe));
        }

        void AttachProperties(IReadOnlyCollection<string> names)
        {
            // SimHub can't remove a property at runtime. Renamed or disabled variables keep their old
            // property (returning null) until SimHub restarts.
            foreach (var n in names)
            {
                if (!_attached.Add(n)) continue;
                var name = n;
                try { this.AttachDelegate(name, () => Engine.GetPropertyValue(name)); }
                catch (Exception e) { Log.Error("AttachDelegate " + name, e); }
            }
        }

        public void DataUpdate(PluginManager pluginManager, ref GameData data)
        {
            // Nothing to do here: values are produced by the engine's own thread and read by
            // SimHub through the delegates attached above.
        }

        public void End(PluginManager pluginManager)
        {
            Log.Info("End");
            Engine?.Dispose();
            Ffb?.Dispose();
            Outputs?.Dispose();
            Tp?.Dispose();
            try { Store?.SaveAll(Profiles); Store?.SaveSettings(Settings); }
            catch (Exception e) { Log.Error("Save on exit", e); }
        }

        public System.Windows.Controls.Control GetWPFSettingsControl(PluginManager pluginManager)
        {
            Log.Info("Settings page requested");
            if (InitError != null) return ErrorPage("TP Telemetry couldn't start:\n\n" + InitError);
            try { return new SettingsControl(this); }
            catch (Exception e)
            {
                Log.Error("Settings page failed", e);
                return ErrorPage("The TP Telemetry settings page failed to open:\n\n" + e);
            }
        }

        /// <summary>Shown instead of the editor if something went wrong, so SimHub keeps working.</summary>
        static System.Windows.Controls.Control ErrorPage(string text)
        {
            return new System.Windows.Controls.UserControl
            {
                Content = new System.Windows.Controls.TextBox
                {
                    Text = text + "\n\nDetails are also in SimHub\\PluginsData\\TPTelemetry\\TPTelemetry.log",
                    IsReadOnly = true,
                    TextWrapping = System.Windows.TextWrapping.Wrap,
                    Margin = new System.Windows.Thickness(10),
                },
            };
        }

        static readonly Lazy<ImageSource> Icon = new Lazy<ImageSource>(() =>
        {
            // A small gauge glyph, drawn so the plugin needs no resource files.
            var g = Geometry.Parse("M12,3 A9,9 0 1 0 21,12 A9,9 0 0 0 12,3 Z M12,5 A7,7 0 1 1 5,12 A7,7 0 0 1 12,5 Z M11,12 L16.5,7.5 L17.2,8.2 L12.7,13.7 Z");
            var d = new DrawingImage(new GeometryDrawing(Brushes.White, null, g));
            d.Freeze();
            return d;
        });
    }
}
