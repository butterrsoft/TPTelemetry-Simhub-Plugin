using System;
using System.Diagnostics;
using System.IO.MemoryMappedFiles;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Remote;

namespace TeknoTelemetry.Helper64
{
    /// <summary>
    /// TPTelemetryHelper64.exe: reads 64-bit games for the 32-bit SimHub plugin.
    ///
    /// Started by the plugin only, with:
    ///   --parent &lt;SimHub PID&gt; --pipe &lt;pipe name&gt; --block &lt;shared memory name&gt; --rows &lt;capacity&gt;
    ///
    /// Read-only, like the plugin: games are opened with PROCESS_VM_READ and query rights only.
    /// The only things it writes are its own shared memory block and pipe. It writes no files,
    /// and exits when the plugin closes the pipe, sends STOP, or SimHub exits.
    /// </summary>
    static class Program
    {
        static int Main(string[] args)
        {
            int parentPid = 0, rows = ReadPlan.MaxRows;
            string pipeName = null, blockName = null;
            for (int i = 0; i + 1 < args.Length; i += 2)
            {
                switch (args[i])
                {
                    case "--parent": int.TryParse(args[i + 1], out parentPid); break;
                    case "--pipe": pipeName = args[i + 1]; break;
                    case "--block": blockName = args[i + 1]; break;
                    case "--rows": int.TryParse(args[i + 1], out rows); break;
                }
            }
            if (parentPid <= 0 || string.IsNullOrEmpty(pipeName) || string.IsNullOrEmpty(blockName) ||
                !pipeName.StartsWith(HelperLauncher.PipePrefix, StringComparison.Ordinal) ||
                !blockName.StartsWith(HelperLauncher.BlockPrefix, StringComparison.Ordinal))
            {
                Console.Error.WriteLine("TPTelemetryHelper64 is started by the TP Telemetry SimHub plugin; it isn't meant to be run by hand.");
                return 2;
            }
            rows = Math.Max(1, Math.Min(ReadPlan.MaxRows, rows));

            Process parent;
            try { parent = Process.GetProcessById(parentPid); }
            catch (ArgumentException) { return 3; } // SimHub has already gone

            bool timerRes = false;
            try { timerRes = timeBeginPeriod(1) == 0; } catch { } // 1 ms sleeps, for an even poll rate

            try
            {
                using (var mmf = MemoryMappedFile.CreateNew(blockName, ResultsLayout.Size(rows), MemoryMappedFileAccess.ReadWrite))
                using (var block = mmf.CreateViewAccessor(0, ResultsLayout.Size(rows), MemoryMappedFileAccess.ReadWrite))
                using (var pipe = new NamedPipeServerStream(pipeName, PipeDirection.InOut, 1, PipeTransmissionMode.Byte, PipeOptions.Asynchronous))
                {
                    // Wait for the plugin to connect, but not for ever.
                    var ar = pipe.BeginWaitForConnection(null, null);
                    if (!ar.AsyncWaitHandle.WaitOne(15000) || HasExited(parent)) return 4;
                    pipe.EndWaitForConnection(ar);

                    int me;
                    using (var self = Process.GetCurrentProcess()) me = self.Id;
                    var server = new HelperServer(pipe, block, rows, me, (pid, name) => ProcessMemory.OpenPid(pid, name))
                    {
                        ParentAlive = () => !HasExited(parent),
                        OnError = msg => Console.Error.WriteLine(msg),
                    };
                    server.Run();
                }
                return 0;
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e);
                return 1;
            }
            finally
            {
                if (timerRes) try { timeEndPeriod(1); } catch { }
                parent.Dispose();
            }
        }

        static bool HasExited(Process p)
        {
            try { return p.HasExited; }
            catch { return false; } // can't tell (rights): rely on the pipe and the job object instead
        }

        [DllImport("winmm.dll")] static extern uint timeBeginPeriod(uint ms);
        [DllImport("winmm.dll")] static extern uint timeEndPeriod(uint ms);
    }
}
