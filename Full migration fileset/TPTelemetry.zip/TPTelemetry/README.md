# TP Telemetry (SimHub plugin)

Publishes values read from a game's memory as SimHub properties, for games with no telemetry of
their own. Built for TeknoParrot games, but it works with any Windows game it can be pointed at,
32-bit or 64-bit (see [64-bit games](#64-bit-games)). One plugin covers any number of games; each game is a **profile** with a
property prefix, so values appear as:

```
TPTelemetry.WMMT3DXP_speed1
TPTelemetry.WMMT3DXP_accel_g
TPTelemetry.WMMT3DXP_Connected     (true while the game process is attached; the last row of every table)
TPTelemetry.ActiveGame             (prefix of the game currently attached, or empty)
TPTelemetry.SelectedGame           (the game selected by command line or the Game list)
TPTelemetry.FFB_force              (force feedback sent to the wheel: see Force feedback capture)
TPTelemetry.Car_impact             (common values from whichever game is selected: see Common_Properties.md)
TPTelemetry.Car_speed_kmh          (common dashboard values: see Common_Dashboard.md)
TPTelemetry.Lamp_start             (common lamps: see Common_Lamps.md)
```

In NCalc: `[TPTelemetry.WMMT3DXP_speed1]`. In JavaScript: `$prop('TPTelemetry.WMMT3DXP_speed1')`.

More help, in this folder:

| File | Covers |
|---|---|
| [Formula_Reference.md](Formula_Reference.md) | the formula language: names, operators, functions, examples |
| [USB_Capture.md](USB_Capture.md) | installing USBPcap, capturing a wheel's force feedback, the supported wheels, capturing a racing wheel to add or check support (Record Test Pattern), recordings and what blank cells mean |
| [Game_Outputs.md](Game_Outputs.md) | lamps and other outputs from TeknoParrot, MAME, Supermodel, Flycast and the Model 2 Emulator |
| [SimHub_Effects.md](SimHub_Effects.md) | ready-made "TP -" effects for bass shakers, shaker motors (seat and pedals) and fans: making, importing and tuning them |
| [Common_Properties.md](Common_Properties.md) | the common `TPTelemetry.Car_...` values the SimHub effects are built from, and which effect reads which |
| [Common_Dashboard.md](Common_Dashboard.md) | common dashboard values: speed in km/h and mph, revs for a dial, gear as text, position, laps, clocks, pedals |
| [Common_Lamps.md](Common_Lamps.md) | common lamps (`TPTelemetry.Lamp_...`): start, view, leader, checkpoint, shift, warning, colour lamps and more |

How to set up each game (what it needs: TeknoParrot, OutputBlaster, an emulator's outputs, USB
capture) is in **Game_Setup.md**, and each game's own formulas are explained in **Game_Formulas.md**,
both in the game profiles pack.

## Build and install

1. Install the .NET SDK (8 or later) and close SimHub.
2. If SimHub isn't in `C:\Program Files (x86)\SimHub\` (check for `SimHubWPF.exe` there), tell the
   build where it is by setting the `SIMHUB_INSTALL_PATH` environment variable once, from a command
   prompt:

   ```
   setx SIMHUB_INSTALL_PATH "D:\path\to\your\SimHub\\"
   ```

   Keep the doubled backslash at the end.
3. Open a new command prompt as administrator (a new one, so it sees `SIMHUB_INSTALL_PATH` if you set
   it; as administrator, because the build copies into the SimHub folder, which Windows protects when
   it's under Program Files). In `src\TPTelemetry` run `dotnet build -c Release`. The build copies
   `TPTelemetry.dll` and `TPTelemetryHelper64.exe` (which reads 64-bit games) into the SimHub folder.
   If the copy is still blocked, copy both by hand from `bin\Release\net48\`. They must sit side by side.
4. Start SimHub, enable **TP Telemetry** when asked, and it appears in the left menu. If SimHub greys
   out, close it and reopen.
5. Load the dummy profile: click **Import…** and, from where you extracted
   `TPTelemetry.zip`, choose `profiles\DUMMY.json`. It needs no game (see below).
6. Game profiles (addresses for particular games) come separately, in `TPTelemetry-GameProfiles.zip`,
   so they can be updated without touching the plugin. Import them the same way.

7. Optional: for lamps and other outputs, see [Game_Outputs.md](Game_Outputs.md). For force feedback
   as your wheel receives it, see [USB_Capture.md](USB_Capture.md). The game profiles pack doesn't
   need it: see [TeknoParrot force feedback](#teknoparrot-force-feedback).

The build only installs the plugin DLL and its helper; it never touches profiles. To add profiles by copying files
instead of importing, **back up `SimHub\PluginsData\TPTelemetry\Profiles\` first**, close SimHub,
then copy the `.json` files in. A copied file with the same name replaces your profile, along with
any changes you've made to it in SimHub. Import is the safer route: it never overwrites an
existing game, and renames the prefix if it's already taken.

If the game runs as administrator, SimHub must too, or the status will say it can't open the process.

## 64-bit games

SimHub 9.x runs as a 32-bit program, and Windows won't let a 32-bit program read a 64-bit one. So
for 64-bit games (Wangan Midnight 5 and 6, Initial D Zero and The Arcade, Sega World Drivers
Championship, and any other you add) the plugin starts a small helper, `TPTelemetryHelper64.exe`,
which reads the game for it. There's nothing to set up: the profile is the same as for a 32-bit
game, and the plugin starts the helper by itself when it finds the game is 64-bit.

* The game's Status reads **Starting the 64-bit helper**, then **Attached to wmn5r.exe (PID …,
  64-bit, through TPTelemetryHelper64.exe)**. Rows show their address or error just as for 32-bit
  games.
* One helper runs per attached 64-bit game. It stops when the game exits, when you switch games,
  and when SimHub closes (Windows ends it even if SimHub crashes). If it stops unexpectedly, the
  plugin starts a new one after 10 seconds.
* Editing rows on the settings page sends the new rows to the running helper; it doesn't restart.
* It follows the same read-only rules as the plugin (see [What the plugin touches](#what-the-plugin-touches)).
* If the Status says `TPTelemetryHelper64.exe is missing`, copy it from `bin\Release\net48\` into
  the SimHub folder, beside `TPTelemetry.dll`.

How it works: the plugin sends the helper a list of the profile's memory rows (module, base,
offsets, type) over a named pipe, once and again after each edit. The helper walks every row's
pointer chain at the poll rate and puts the values and their status in a small shared memory block,
which the plugin reads on each tick. Reads are one tick (about 8 ms) behind at most.

### Trying it without a 64-bit game

`tests\HelperTestTarget64` is a tiny 64-bit program that holds known values behind a pointer chain
above 4 GB, where 32-bit SimHub can't reach. Import `tests\HelperTestTarget64\HELPERTEST.json`, run
`dotnet run -c Release` in that folder, and activate HELPERTEST in SimHub. The program's window says
what each row should show (`mz` reads 23117, `wave` swings from -1 to 1, `counter_rate` sits near 60,
and the two deliberately broken rows give their errors). Close the window and the values should
clear, with the Status saying **Game exited** for a moment and then **Waiting for HelperTestTarget64.exe**.

## Choosing the game from a launch script

One game is selected at a time. The selected game is the one shown on the TP Telemetry page and the
only one that reads memory. A launch script selects it through SimHub's command line, which starts
SimHub if it isn't running and otherwise passes the command to the running copy:

```
start "" "C:\Program Files (x86)\SimHub\SimHubWPF.exe" -triggeraction TPTelemetry.Activate_WMMT3DXP
```

The part after `Activate_` is the game's property prefix, so every game must have its own prefix;
the page won't let two games share one. Picking a game in the **Game** list does the same thing as
running its command.

### Copy Commandlines To Set Game/Profile

A launch script needs two commands: one selects the game in TP Telemetry, the other switches
SimHub's own game (its effects and dashboards). **Copy Commandlines To Set Game/Profile**, at the
top of the page, puts both on the clipboard for the game on screen, ready to paste into a script,
in three versions: AutoHotkey v1, AutoHotkey v2 and a batch file (.bat). For example, the
AutoHotkey v1 block:

```
Run, "C:\utils\simhub\SimHubWPF.exe" -triggeraction TPTelemetry.Activate_WMMT3DXP
Sleep, 5000
Run, "C:\utils\simhub\SimHubWPF.exe" -switchgame Custom_580b91a2-a30e-429d-930f-b416fa1d43c7
```

The pasted text starts with notes (lines beginning `;`) on what each line does: delete them, and
the two blocks you don't use, before saving. Select the game in SimHub first: SimHub's game code
(from `DataCorePlugin.CurrentGame`) is only included if one is selected, and custom game codes are
made per PC, so copy them on the PC they'll run on.

They must be separate commands: given both in one line, a running SimHub only acts on the first.
And SimHub ignores `-switchgame` while it's starting up, hence the 5 second wait (make it longer on
a slow PC).

There's no third line for the SimHub effects profile: SimHub has no command (or action) for
choosing a ShakeIt profile. Select the **TP Telemetry** profile in ShakeIt once while SimHub has the
game selected, and use the same SimHub game in every launch script (the effect profiles are the
same for every TP Telemetry game; see [SimHub_Effects.md](SimHub_Effects.md)).

To stop all reading, for example from the script after the game exits:

```
"C:\utils\simhub\SimHubWPF.exe" -triggeraction TPTelemetry.Deactivate
```

The selection, including a Deactivate, is remembered across SimHub restarts. An Activate command
always starts reading again.

## Recording values

**Record Values** (in **Capture table values and FFB**, under the table) writes every row of the
selected game, plus the FFB, TeknoParrot and output values, to a spreadsheet (CSV) file at the poll
rate: 120 rows a second by default. Use it to see what a game is doing over time and to tune
formulas, or send it to someone who's helping. Files go to
`SimHub\PluginsData\TPTelemetry\Recordings\`, named with the date, time and game. Recording stops
by itself after 15 minutes. It doesn't need USBPcap: anything that can't be read is left blank (see
[USB_Capture.md](USB_Capture.md) for what blank cells mean).

**Mark Event** puts the next number (1, 2, 3...) in the `marker` column, on the row where you
pressed it. Rather than reaching for the mouse mid-race, bind it to a wheel button: in SimHub's
**Controls and events**, map a button to the action `TPTelemetry.Mark`. Recording can be started
and stopped the same way: `TPTelemetry.RecordValues` starts it if it's stopped and stops it if it's
running, so one button does both. For separate buttons, or a launch script, use
`TPTelemetry.StartRecording` and `TPTelemetry.StopRecording`, which only ever do what they say.
`TPTelemetry.Recording` is true while it runs. Then note what each marker was ("1: left drift
starts, 2: countersteer, 3: hit left wall") and the numbers line up with the data.

Columns: `time_s` (seconds since recording started), `marker`, `attached` (1 while the game
process is attached), each of the game's properties (e.g. `WMMT3DXP_speed1`), then `FFB_force`,
`FFB_spring` and the other FFB channels, the TeknoParrot slots and the outputs. Empty cells mean no
value at that moment.

## Using the settings page

The page scrolls both ways, so it can be used down to 640×480 (and around SimHub's licence banner).
Wider than about 600 pixels, button rows wrap to fit; narrower, the page scrolls sideways. The
table takes the height that's left, and the page scrolls if that's less than about 180 pixels.

* **Top bar**: the **Game** list (choosing a game also makes it the one that reads memory),
  **Add Game**, **Import…** (a profile `.json`, or a Cheat Engine `.CT` table as a new game or added
  to the current one, which keeps its process name), **Export…**, **Delete Game**, **Open Profiles
  Folder**, and **Copy Commandlines To Set Game/Profile** (see
  [above](#copy-commandlines-to-set-gameprofile)).
* **Game fields**: display name, property prefix and process name (e.g. `BudgieLoader.exe`; a long
  name scrolls inside the box). The process name only decides which running program to attach to:
  addresses come from each row's own Module, Base offset and Offsets.
* **Max speed** and **Max revs**: this game's top speed and redline, in the units of its speed and
  revs rows. Formulas read them as `max_speed` and `max_revs`, so `value / max_speed` on the speed
  row makes it run 0 to 1, which lets one SimHub effect or formula suit every game. Blank counts as 1
  (the raw value comes through); the smallest value is 1. The game profiles pack's speed and rpm rows
  already divide by them. They're saved in the profile.
* **Status line**: whether the process is attached and the actual sample rate, or why not.
* **Table**, one row per value:
  * **Export**: tick to publish to SimHub. Unticked rows are still read and shown, which is handy for
    comparing candidate addresses side by side.
  * **Source**: `Memory` (module + offset + pointer chain) or `Computed` (formula only).
  * **Type**: Float, Double, Int32 (CE "4 Bytes"), Int16, Byte, Int64, UInt32, UInt16. Shown on
    memory rows only (computed rows are always decimals).
  * **Module / Base offset / Offsets**: hex, as in Cheat Engine. Offsets are comma separated in the
    order they're applied from the base outwards (the importer converts CE's reversed order).
    Module `<main>` means the process's own executable, whatever it's called, so a profile can use
    exe-relative addresses before anyone knows the exe's name (the game pack's profiles do this).
    An offset written with `@` in front (`8FF174, @588`; plugin 0.18.2) is for games inside an
    emulator such as Flycast: the first offset follows the emulator's own pointer to the game's
    memory, and at each `@` step the value read is one of the game's own 32-bit addresses, which the
    plugin finds inside that memory before adding the offset. `@` can't be the first offset.
    An offset written `[-E80]*578` (plugin 0.19.0) indexes an array of records by a number the game
    keeps beside its pointer: the chain reads a 4-byte number at the current address plus the bracketed
    offset (before following the pointer there), and the next offset lands that many records (of the
    size after `*`) further on. Sega World Drivers Championship picks your car's record this way
    (`278, 10, 2550, [-E80]*578, -118`: your car number sits E80 before the records' pointer, and the
    field offset takes one record off because the game counts cars from 1). It must be followed by an
    ordinary offset.
    Leave Module empty to use an absolute address (rarely stable, but right for games TeknoParrot
    loads at a fixed address, such as Lindbergh games). Base offset and Offsets are blank on
    computed rows.
  * **Raw**: the number read from memory, before the formula (memory rows only).
  * **Formula**: optional; empty publishes Raw. On a memory row, `value` is the Raw number. Hover
    over the column heading for a summary; [Formula_Reference.md](Formula_Reference.md) has it all.
  * **Output / Status**: live. Output is what SimHub gets; Status shows the resolved address or why
    a read failed (e.g. which pointer level was null).
  * **SimHub property**: the property's full name, to use in SimHub (`TPTelemetry.<PREFIX>_<row>`).
  * **Connected**, always the last row: the plugin's own `TPTelemetry.<PREFIX>_Connected`, True while
    the game's process is attached. It can't be edited, moved or removed.
  * **Show address columns** (beside the row buttons) hides Source, Type, Module, Base offset and
    Offsets, for when you're only using a ready-made profile.
* **Row buttons**: **Add Row** (a memory row below the selected one; change Source to Computed for a
  formula row), **Duplicate**, **▲** / **▼** (move), **Remove**.
* **Capture table values and FFB** (closed until you open it):
  * **Record Values**, **Mark Event**, **Open Recordings Folder** (see [Recording values](#recording-values)),
    and the actions to bind to wheel buttons.
  * One status line for the sources every game shares: TeknoParrot, game outputs and USB capture.
  * **Outputs port** (8000; see [Game_Outputs.md](Game_Outputs.md)) and **Poll rate (Hz)**.
  * USB capture: the capture box, **Wheel**, **Find Devices**, **Decoder**, **Record 60 s Capture**,
    **Record Test Pattern**, **Open Captures Folder** and the USBPcapCMD.exe path (see [USB_Capture.md](USB_Capture.md)).
  * **Add FFB values to table** / **Remove FFB values from table**.
* **SimHub effects** (closed until you open it): tick the hardware you have, on two rows: **Bass
  Shaker** (seat, pedal box, gas, brake, clutch pedal) and **Shaker Motor** (the same, plus fans). Click
  **Create TP Effect Profiles** to write SimHub profiles holding the "TP -" effects. The profiles are
  for the whole plugin, not per game: make them once for each kind of hardware (Bass Shakers, Shaker
  Motors). See [SimHub_Effects.md](SimHub_Effects.md).

Edits apply as you type (after a short pause) and are saved to
`SimHub\PluginsData\TPTelemetry\Profiles\`, one JSON file per game, named after its prefix
(e.g. `WMMT3DXP.json`). Two games sharing a prefix get a short suffix to keep the names apart.
SimHub can't remove a property while running, so a renamed or unticked row leaves its old property
behind (reading null) until SimHub restarts.

Every profile is read when it's the selected game: 0.12.0 removed the old **Enabled** box, and
profiles saved disabled by older versions are switched back on.

## SimHub effects and the common values

Every game's profile maps its own values onto a common set (`car_` rows), which the plugin publishes
as `TPTelemetry.Car_impact`, `Car_rpm_frac`, `Car_rumble_strip` and so on, from whichever game is
selected. Effects built on those work in every game, so the plugin can write one set of ready-made
SimHub effects ("TP - Collision", "TP - Engine"...) for bass shakers, shaker motors (seat and pedals) and fans.
Everything about them, including giving pedal shakers their own channels, is in
[SimHub_Effects.md](SimHub_Effects.md); the values themselves are listed in [Common_Properties.md](Common_Properties.md).

The same rows also give **dashboard values** in one unit for every game (`Car_speed_kmh`, `Car_speed_mph`,
`Car_rpm_dial`, `Car_gear_text`, `Car_time_left`...: [Common_Dashboard.md](Common_Dashboard.md)), and rows named
`lamp_` give **common lamps** (`TPTelemetry.Lamp_start`, `Lamp_leader`...: [Common_Lamps.md](Common_Lamps.md)), so
one dashboard and one LED set-up serve every game.

## Formulas

The formula language (names, operators, functions, examples, and why acceleration is worked out
the way it is) is in [Formula_Reference.md](Formula_Reference.md). Each game's formulas are in
Game_Formulas.md in the game profiles pack.

## Dummy profile: test signal and example formulas

`profiles/DUMMY.json` needs no game. It has no process, so it runs as soon as it's active, and
generates a repeating 20-second "lap" from formulas alone. Use it to build dashboards and ShakeIt
effects away from the cabinet, and to test switching (`-triggeraction TPTelemetry.Activate_DUMMY`).

It's also a library of formulas to copy into your own games. Its rows come in three kinds:

| Rows | What they are |
|---|---|
| `REPLACE_speed`, `REPLACE_gear`, `REPLACE_rpm`, `REPLACE_heading`, `REPLACE_pos_x/y/z`, `REPLACE_wheel_speed` | **Stand-ins** for values you'd read from a real game's memory |
| `sim_course`, `sim_slip` | Internals of the test signal. Not exported; don't copy |
| everything else | **Example formulas**, built only on the stand-ins |

| Example | Gives |
|---|---|
| `accel_long_g` | forward/back G from speed |
| `yaw_rate`, `accel_lat_g` | turning rate and cornering G, from speed and heading |
| `travel_dir`, `accel_lat_g_path` | direction of travel and cornering G from world position (stays right in drifts) |
| `drift_angle` | traction loss: angle between where the car points and where it's going |
| `wheelspin`, `lockup` | traction loss under power and under braking, from a wheel speed |
| `vertical_g`, `road_rumble` | road surface, bumps and kerbs, from the car's height |
| `impact` | collisions: speed changing faster than braking can manage |
| `gear_shift`, `shift_light`, `distance_km` | gear-change kick, shift point, distance driven |

### Copying an example into a game

Wherever an example formula says `REPLACE_something`, put the name of your own game's variable
there. For example, if your game's speed row is called `speed1`:

```
dummy:      ema(slope(REPLACE_speed, 0.1), 0.05) / 3.6 / g
your game:  ema(slope(speed1, 0.1), 0.05) / 3.6 / g
```

Then:

* **Check the units.** The stand-ins use km/h, degrees and metres; each row's Notes say what to
  change for mph, m/s or radians (e.g. `unwrap(heading, 2 * pi)` instead of `360`).
* **Copy the examples an example depends on.** `accel_lat_g` uses `yaw_rate`, `drift_angle` uses
  `travel_dir`, and so on. A missing name shows as an error in the row's Status.
* **Check the signs and axes.** Games differ on which way is left and which position axes are the
  ground. If a value comes out backwards, put a minus in front; if `travel_dir` disagrees with
  heading while driving straight, swap the two position names.

Leaving a `REPLACE_` name in place shows "Unknown variable 'REPLACE_…'" in that row, so nothing
half-copied goes unnoticed.

## TeknoParrot force feedback

For some games, TeknoParrot publishes the force feedback commands, as the arcade cabinet's force
feedback board would receive them, in a small block of shared memory (`TeknoParrot_JvsState`). The plugin
reads it all the time, with nothing to set up, no USB capture and no particular wheel: it works with
any wheel, or none. Formulas read it as `tp_jvs0` to `tp_jvs15` (32-bit values) and `tp_connected`;
SimHub gets `TPTelemetry.TP_jvs0` and so on, plus `TPTelemetry.TP_Status`.

Which slots a game uses, and what the numbers mean, differs per game, so it's decoded in the game's
profile. The game profiles pack has WMMT3DX+, Sega Rally 3, Initial D 6, 7 and 8, Ford Racing,
Arctic Thunder, Dead Heat, D1 Grand Prix and Storm Racer G. Most games use slot 2; WMMT3DX+, Dead
Heat, D1GP and Storm Racer G use slots 6 to 9.

Other games leave the block at 0 (WMMT5DX+, OutRun 2 SP and others: the status still says
connected). That isn't a fault: their profiles read what they can from game memory instead.

If TeknoParrot runs as administrator, SimHub must too, or Windows won't let it read the block.

The layout was learned from the open-source [FFB Arcade Plugin](https://github.com/Boomslangnz/FFBArcadePlugin)
(GPL-3.0) by Boomslangnz; this plugin has its own reader and contains none of its code.

## Game outputs

Lamps, LEDs, seat motors, digit displays and RPM, as the game drives the cabinet's hardware. Most
game profiles read them straight from game memory; for the rest, and for MAME, Supermodel, Flycast
and the Model 2 Emulator, the plugin receives them over the network (port 8000). Each appears in
SimHub as `TPTelemetry.Output_<name>`. Setting up each emulator, and replacing MAMEHooker, is in
[Game_Outputs.md](Game_Outputs.md).

**Flycast:** outputs are off until you switch them on: in Flycast, **Settings, Network**, tick
**Broadcast Digital Outputs**. Flycast sends hexadecimal values, which this plugin reads from 0.13.3.

## USB force feedback capture (optional)

To see the force your wheel actually gets, and to read steering and pedals from the wheel itself, the
plugin can capture the force feedback a wheel receives over USB. No profile in the game profiles pack
uses it, so every common value works without it. It is the only way to see the force in games where
the FFB Arcade Plugin or FFB Blaster makes it with a code hook (OutRun 2 SP, for one): the pack
README's "Without USB capture" section lists them. Installing USBPcap, setting it up, the values
it gives (`ffb_force`, `TPTelemetry.FFB_force` and so on), supported wheels (Logitech, Thrustmaster, Fanatec,
Moza and other USB PID wheels since 0.21.0) and how to capture a wheel (**Record Test Pattern**, **Record 60 s
Capture**) are in [USB_Capture.md](USB_Capture.md).

## What the plugin touches

Everything is read-only as far as games and TeknoParrot are concerned:

* **Game memory.** The plugin opens the game's process with read and query rights only
  (`PROCESS_VM_READ` plus query information), never all-access. It never writes to the game,
  injects code, patches or hooks anything. A read of an address that isn't there just fails,
  returns an error code to the plugin and leaves the game alone; the row's Status says why.
* **TeknoParrot's shared memory.** Opened read-only, and only once TeknoParrot has created it.
  The plugin never creates it or writes to it.
* **Game outputs.** The plugin connects to OutputBlaster's (or MAME's) port and only listens.
* **USB capture** (optional, off by default). USBPcap copies the USB traffic to the plugin;
  nothing is sent to the wheel.
* **64-bit helper.** `TPTelemetryHelper64.exe` opens 64-bit games with the same read and query
  rights only, and never writes to them. The only things it writes are its own named pipe and
  shared memory block (random names, created fresh each time), which the plugin opens read-only.
  It writes no files, runs at SimHub's own elevation, and exits when the plugin closes the pipe,
  when SimHub exits, or when the job object it's placed in closes.
* **Files.** The plugin writes only under `SimHub\PluginsData\TPTelemetry\` (profiles, settings,
  log, recordings and captures).
* **Programs.** It starts `USBPcapCMD.exe` when USB capture is on, `TPTelemetryHelper64.exe` when a
  64-bit game is attached, and Explorer when you click an "Open folder" button. The only programs it
  ever stops are the USBPcapCMD and helpers it started.

Some games only switch their force feedback output on when the FFB Arcade Plugin writes to their
memory (R-Tuned, Sonic & Sega All-Stars Racing). This plugin won't do that; run the FFB Arcade
Plugin alongside it for those games.

## Project layout

```
src/TPTelemetry/
  TPTelemetry.cs            SimHub entry point (IDataPlugin + settings page)
  Core/Model.cs             profiles, variables, types, naming
  Core/CheatTableImporter.cs  .CT parsing
  Core/ProcessMemory.cs     read-only process access (works from 32-bit and 64-bit SimHub)
  Core/Sources.cs           raw value sources (memory), pointer walking and its status text
  Core/Remote/              64-bit helper: read plan, shared results block, pipe protocol,
                            the helper's loop (HelperServer) and the plugin's side (HelperClient)
  Core/ChildProcessJob.cs   job object that ends USBPcapCMD and the helper with SimHub
  Core/TeknoParrot/         TeknoParrot shared memory reader
  Core/Outputs/             MAME network output protocol client (lamps etc.)
  Core/Ffb/                 USB force feedback: capture stream reader, wheel decoders (FfbDecoders, FfbWheelDecoders,
                            PidDecoder with HidDescriptor and WindowsHidPid), USBPcapCMD control
  Core/Expressions.cs       formula parser and time-series functions
  Core/TelemetryEngine.cs   poll thread, attach/detach, dependency ordering, property values
  Core/ProfileStore.cs      JSON profiles on disk
  Core/LaunchLines.cs       the launch-script lines Copy Commandlines puts on the clipboard
  Core/CommonValues.cs      TPTelemetry.Car_* and Lamp_* from the selected game's car_ and lamp_ rows
  Core/SimHubProfiles.cs    the SimHub effect profiles (.siprofile) for the ticked hardware
  UI/                       settings page (built in code, no XAML): SettingsControl, CapturePanel, EffectsPanel, VarRow
src/TPTelemetryHelper64/    TPTelemetryHelper64.exe (x64): shares Core's memory code, built with the plugin
src/TPTelemetryFfbTest/     TPTelemetryFfbTest.exe: plays the force feedback test pattern through DirectInput
                            (Record Test Pattern), built with the plugin and copied beside it
profiles/                   dummy test signal and example formulas (game profiles ship separately)
Formula_Reference.md        the formula language
USB_Capture.md              USBPcap, wheel capture, recordings and blank cells
Game_Outputs.md             outputs from TeknoParrot, MAME, Supermodel, Flycast, Model 2 Emulator
SimHub_Effects.md           the TP effect profiles, channel set-up, future options
Common_Properties.md        the common values the effects are built from
Common_Dashboard.md         the common dashboard values
Common_Lamps.md             the common lamps
tests/CoreTests/            engine tests (dotnet run), runs on any OS. fixtures/ holds a real G25
                            capture for the FFB tests, and recordings of the checked games (WMMT,
                            OutRun 2, SR3, SWDC, GRID, GTI Club, ID6) replayed through those
                            games' profiles; sample.CT is made up for the
                            importer tests. Set TPT_PROFILE_DIRS to a game pack folder to check its
                            profiles load cleanly and run the replays
tests/SimHubStubs/          API stand-ins for compile checks without SimHub
tests/HelperTestTarget64/   a pretend 64-bit game and its HELPERTEST profile, for trying the helper
tests/CompileCheck/         compile-check.sh: builds plugin (settings page included), helper and test pattern tool on Linux
                            against the .NET Framework 4.8 API, with WpfStubs.cs standing in for WPF
```

## Changes

**0.21.0** (helper 0.18.0, unchanged; new TPTelemetryFfbTest.exe beside the plugin)
* **More wheels for USB capture**: decoders for Thrustmaster (T300RS, T248, TX, TS-XW, TS-PC, T-GT II), Fanatec (CSL Elite,
  CSL DD, DD Pro, ClubSport DD, Podium DD1 and DD2, ClubSport V2 and V2.5, CSR Elite), Logitech HID++ (G920, G923 Xbox,
  G PRO, RS50), and the USB force feedback standard (USB PID) used by Moza, Simucube, VRS, Cammus, Asetek, PXN and
  OpenFFBoard. The G29 and the G923 PlayStation edition join the Logitech classic decoder. Auto picks each from the
  wheel's USB ID. Written from each protocol's public description (mostly the Linux drivers for these wheels) and not
  yet checked against captures: see USB_Capture.md.
* **USB PID layouts**: a USB PID wheel's message layout is read from Windows' HID parser on the PC, or from the wheel's
  report descriptor when a capture sees it plugged in; otherwise the layout most of these wheels share is assumed.
  The capture now also reads output reports sent as control transfers (SET_REPORT).
* **Record Test Pattern** (settings page): records the USB traffic while TPTelemetryFfbTest.exe plays a fixed set of
  forces on the wheel (pushes each way at 25% and 50%, a vibration, spring, damper, friction), with a log of each step's
  time beside the capture. The quickest way to add or check a wheel. Not yet run against a real wheel.

**0.20.0** (helper 0.18.0, unchanged)
* **Common dashboard values**, so one SimHub dashboard serves every game: `Car_speed_kmh` and `Car_speed_mph`
  (from a profile's `car_speed_kmh` row, where the game's units are known), `Car_max_speed`, `Car_max_revs`,
  `Car_rpm_dial` (revs / Max revs for a needle), `Car_rev_limit_rpm` (the car's limiter, else Max revs),
  `Car_gear_text` (`R`, `N`, `1`...), `Car_position`, `Car_lap`, `Car_laps_total`, `Car_final_lap`,
  `Car_time_left` (RT), `Car_race_time` (TT), `Car_lap_time`, `Car_brake`, `Car_steer` and `Car_gap`. The plugin
  doesn't tie them to racing; see Common_Dashboard.md.
* **Common lamps**, so one LED or lamp set-up serves every game: rows named `lamp_<name>` are published as
  `TPTelemetry.Lamp_<name>`, 0 to 1, whatever the race state (`Lamp_start`, `Lamp_view1` to `4`, `Lamp_leader`,
  `Lamp_checkpoint`, `Lamp_shift`, `Lamp_warning`, the colour lamps and more). A few are made by the plugin when a game
  has no row: `Lamp_view` from the view buttons, `Lamp_leader` from 1st place, `Lamp_shift` at 90% of the limiter,
  `Lamp_boost` and `Lamp_brake`. See Common_Lamps.md.
* Recordings also hold the lamps (`Lamp_` columns, after the `Car_` ones).
* New help files: Common_Properties.md (the values the effects are built from), Common_Dashboard.md and
  Common_Lamps.md. A game profile can't use the prefix `Lamp`, as it couldn't use `Car`.

**0.19.0** (helper 0.18.0)
* **Offsets can index an array of records by the game's own number**: write `[offset]*size` (`278, 10,
  2550, [-E80]*578, -118`). The chain reads a 4-byte number at the current address plus the bracketed
  offset, then lands that many records further on at the next pointer. Sega World Drivers Championship
  keeps every car's data in one array and your car number beside it, so your speedo, revs, gear, race
  state, place and sparks are read this way (18 November 2026). Install the plugin and the helper
  together: an older helper misreads these rows.

**0.18.2** (helper 0.17.1)
* **Offsets can follow a game's own pointers inside an emulator**: write `@` before the offset
  (`8FF174, @418, @8`). Flycast keeps a NAOMI game's memory at one of its own pointers, and the game's
  pointers inside it are 32-bit addresses of the emulated machine, which an ordinary chain can't
  follow. Initial D 3's time left, race clock and lap are read this way (17 November 2026). Install
  the plugin and the helper together: an older helper misreads these rows.

**0.18.1**
* **Always reads the newest copy of the game.** When several processes share the game's name (an old
  `game.exe` can hang on after the game is closed, or another program is called the same), the plugin opens
  the newest, and moves to a newer one within a few seconds if it starts while attached. Before, it took
  whichever Windows listed first: a Battle Gear 4 race was read from the previous, stopped game, frozen
  (10 November 2026). The status line shows the PID it reads.

**0.18.0**
* **Drifting is a common value:** `Car_drift` (0 to 1) and `Car_drift_angle` (degrees, + the car pointing
  right of its path, raw), from a game's `car_drift` or `car_drift_angle` row; with only the angle,
  Car_drift is its size over 40 degrees. Where a game has no slip value of its own, its drift is also its
  `Car_grip_loss`. The effect profiles gain **TP - Drift** (a deep, smooth rumble at the rear, on seat
  shakers and motors): create the profiles again and re-import them to get it. Mario Kart Arcade GP DX
  feeds it from its drift flag and Initial D Arcade Stage 6 from its physics' drift angle; more games as
  their drift values are found.

**0.17.2**
* **Formulas with a time window no longer stick when the game starts after its profile.** With the
  profile selected before the game was running (as a launch script does), the rows kept evaluating
  while waiting, and on attaching their clock went back to 0. Windowed functions (`maxw`, `minw`,
  `avg`, `slope`) then held on to the samples from the wait until the new clock caught up, so a hit
  or shift row could read 1, and `accel_g` stay frozen, for as long as the game had been waited for
  (32 s in an Initial D 6 recording, which made Car_impact read 1 throughout). The clock now carries on
  through the attach, and if a profile's clock ever runs backwards its windows start again.
  Recordings made with 0.17.1 or earlier still hold correct raw reads; only rows with windows were
  affected, and only until the clock caught up.

**0.17.1**
* **SimHub 9.13 imports the effect profiles.** They're now saved under SimHub's own name for an
  exported "Any Game" profile, `Any Game - TP Telemetry.siprofile`, one in `SimHub effects\Bass Shakers\`
  and one in `SimHub effects\Motors\`. In SimHub 9.13 the old `TP Telemetry - Bass
  Shakers.siprofile` imported as an empty copy of the default profile, while the identical file under
  SimHub's name imported properly; it seems to take the game from the file name (9.9.4 didn't
  mind). Files under the old names are deleted when new ones are written.
* The SimHub effects section says the profiles are made once for the whole plugin, one per kind of
  hardware, not per game.
* Copy Commandlines notes that SimHub has no command for choosing a ShakeIt profile.

**0.17.0**
* **Per-car rev range:** a game can give `car_rpm_frac`, its revs as a fraction of the car's own
  limiter, and `Car_rpm_frac` (so the rev limiter, engine and other revs effects) follows it instead of
  revs / Max revs. GRID has one: its cars limit anywhere from 6500 to 8200. Without the row, nothing
  changes.

**0.16.0**
* **The wheel stays chosen.** USB capture remembers the wheel by its name (and learns its USB vendor
  and product IDs, the IDs the FFB plugin's `DeviceGUID` is made from).
  When Windows gives it a new USB address (a replug, a restart, a G25 switching modes), the plugin
  finds it again by itself, and if USBPcapCMD stops, it starts it again (after 2, 5, 10, then every
  30 s). **Find Devices** is needed once, to choose the wheel. A wheel that isn't plugged in shows
  "Waiting for ...".
* **Hit side from the wheel force:** a hit the game gives no side for (`Car_impact_side` 0) takes the
  side of the wheel force's kick at the same moment, when USB capture sees one (OutRun 2's wall hits,
  sometimes; its traffic hits).
* **Recordings** also hold the common values SimHub got (`Car_` columns, after the in-race gate and the
  USB stand-in), so a recording shows what the effects saw.
* README: the build's command prompt (new, as administrator) is now the start of step 3.

**0.15.0**
* **Effects from the wheel force:** with USB capture on, any force-based common value the selected
  game has no `car_` row for (`Car_impact` and its side, `Car_road_bump`, `Car_cornering`,
  `Car_vibration`) is worked out from the force the wheel got. Games whose force feedback comes from
  a hook (OutRun 2, Cruis'n Blast, Cars, the Fast and Furious games, Hummer, MAME games without force
  outputs) get those effects. A tick box under the capture box turns it off; `Car_usb` shows when it's
  in use. See USB_Capture.md.

**0.14.0**
* A new common value, **`Car_throttle`** (0 to 1), from a game's `car_throttle` row. Where a game has
  one (WMMT5DX+ so far), the engine effects follow the throttle as well as the revs: 60% of their
  strength off the throttle, full at full throttle. Games without one are unchanged.

**0.13.3**
* Outputs from **Flycast** (Settings, Network, Broadcast Digital Outputs) are read correctly: Flycast
  sends hexadecimal values after a `game = ...` line, where MAME, Supermodel and OutputBlaster send
  decimal. See Game_Outputs.md.
* The Fans tick reads "Fans (as motors)" again.

**0.13.2**
* SimHub effects: the hardware ticks are two matching rows, **Bass Shaker** and **Shaker Motor**
  (seat, pedal box, gas, brake, clutch pedal; motors also fans). Pedal effects go only in the file
  for the kind of shaker ticked (before, any pedal tick put them in both files). Pedal ticks saved by
  0.13.0 or 0.13.1 count as bass shakers.
* The live values line and the "provides" line are gone from the SimHub effects section.

**0.13.1**
* `Car_landed` (the Landing effect) is graded by the time in the air: 0.4 after the briefest lift,
  rising to full strength after a quarter of a second or more. On WMMT5DX+ crests where the wheels
  stay down give a softer thump than a jump where they leave the road.

**0.13.0**
* Common values: `TPTelemetry.Car_...` (32 of them), worked out from the selected game's `car_` rows,
  gated by `car_in_race`, with speed and revs scaled by Max speed and Max revs (silent while blank).
  The game profiles pack gives every game its `car_` rows.
* **SimHub effects** section: hardware ticks and **Create TP Effect Profiles**, which writes "Any Game"
  SimHub profiles (Bass Shakers, ShakeIt Motors) holding up to 27 and 12 "TP -" effects. Pedal shakers
  and fans get their own named outputs. See SimHub_Effects.md, which also lists future options
  (motion, belt tensioners, ShakeIt Wind, lights).
* No game's prefix can be "Car" (it would clash with the common values).
* Pedal effects are named "TP - Pedal Gas: Engine", "TP - Pedal Box: Braking" and so on, and are in
  both files (pedal shakers can be bass shakers or motors).
* The dummy profile tests the first six effects: each ramps from 0 to full and back over 10 seconds,
  one after another, every minute (`car_` rows at the end of its table).

**0.12.1**
* The table now grows back when the Capture section closes or the window gets taller (before, it
  could only shrink).
* Raw and Output values are centred in their columns, so they stand out from the formulas.

**0.12.0**
* Settings page tidied for low resolutions: it scrolls both ways (usable at 640×480), button rows
  wrap above about 600 pixels wide, and the table fills the height that's left.
* **Copy Commandlines To Set Game/Profile** replaces the two command boxes: it copies both commands
  with a wait between them, for AutoHotkey v1, AutoHotkey v2 and batch files, with notes.
* **Max speed** and **Max revs** per game, read in formulas as `max_speed` and `max_revs` (blank = 1).
  The game profiles pack's speed and rpm rows divide by them.
* The table: **Raw** sits before **Formula**; the fixed **Connected** row shows
  `TPTelemetry.<PREFIX>_Connected`; **Show address columns** hides Source, Type, Module and the
  offsets; Type, Base offset and Offsets are blank on computed rows.
* One **Import…** button for profiles and Cheat Engine tables. **Add Row** replaces Add memory value
  and Add computed value; Add acceleration from selected speed is gone (copy `accel_g` from a pack
  profile instead). The **Enabled** box is gone: the selected game is the one read.
* **Capture table values and FFB** (was Force feedback and outputs) now holds recording, the actions
  to bind, one status line for TeknoParrot, outputs and USB, the outputs port and poll rate, and USB
  capture. Game outputs are always on (the switch is gone; the port stays).
* The formula reference, USB capture help and outputs help moved off the page into
  Formula_Reference.md, USB_Capture.md and Game_Outputs.md.

**0.11.0**
* A game profile whose game isn't running yet keeps updating its rows that don't need the game's
  memory (TeknoParrot force feedback, outputs, USB values, formulas on those). Memory rows stay
  blank, saying "not attached", and `<PREFIX>_Connected` stays false until the game is found.
  Before, nothing updated until then, which mattered once TeknoParrot-only profiles gained
  memory-read lamps.

**0.10.0**
* **Add FFB values to table** / **Remove FFB values from table** button under USB capture: adds the
  12 USB values as rows in the game you're viewing, or takes them out. Profiles no longer ship with them.
* The dummy profile no longer has `wheel_` rows (use the button).
* `tests/CompileCheck`: compile-checks everything, settings page included, without Windows.
* Replays of real recordings in the tests: the G25 WMMT3 capture (now self-contained) and a WMMT5DX+ drive.

**0.9.0**
* 64-bit games: read through `TPTelemetryHelper64.exe`, started by the plugin when needed.
* Memory rows read by the plugin or the helper share the same status text.
* `tests/HelperTestTarget64`, a pretend 64-bit game for trying the helper.
