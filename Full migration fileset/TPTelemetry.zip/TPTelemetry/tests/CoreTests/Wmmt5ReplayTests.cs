using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;

/// <summary>
/// Replays real WMMT5DX+ recordings through the pack's WMMT5DXP profile, feeding the memory rows the
/// values the 64-bit helper read at the time, and checks the computed rows against what happened.
///  * 29 October 2026, 11:08: freeway at about 200 km/h, expansion joints, a ripple strip, 18 hits and a big crash.
///  * 29 October 2026, 17:48: about 100 to 140 km/h, a ripple strip at the start, a jump, three walls
///    (right, right, left), a drift across a strip, and 7 noted gear changes.
///  * 1 November 2026, 16:22: a full race in a five-speed car. Rolling start, braking almost to a stop,
///    up through the gears, expansion joints at 80, 60, 40 and under 20 km/h, top speed 249, a 16 s
///    freeze, the finish line and the results screen. Markers were loose; no notes beyond that.
/// </summary>
static class Wmmt5ReplayTests
{
    internal sealed class Feed : IRawSource
    {
        public double Value = double.NaN;
        public bool TryRead(SourceContext ctx, out double value, out string status) { value = Value; status = "replay"; return true; }
    }

    internal sealed class Replay
    {
        public Dictionary<string, List<(double t, double v)>> Out;
        public List<double> Marks = new List<double>();
        public double End;
        public Dictionary<string, List<(double t, double v)>> Car = new Dictionary<string, List<(double t, double v)>>();

        public double Max(string n, double a, double b) => Out[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(double.NaN).Max();
        public double Min(string n, double a, double b) => Out[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(double.NaN).Min();
        public double At(string n, double t) => Out[n].First(x => x.t >= t).v;

        /// <summary>Spans where the value is non-zero (or above a threshold), as start times.</summary>
        public List<double> Events(string n, double above = 0, double gap = 0.15)
        {
            var ev = new List<double>(); double last = -9;
            foreach (var (t, v) in Out[n])
                if (Math.Abs(v) > above) { if (t - last > gap) ev.Add(t); last = t; }
            return ev;
        }

        /// <summary>Spans where the value is non-zero, as "start-end" text for messages.</summary>
        public string Spans(string n)
        {
            var s = new List<string>(); double? a = null, last = null;
            foreach (var (t, v) in Out[n])
            {
                if (v != 0 && !double.IsNaN(v)) { if (a == null) a = t; last = t; }
                else if (a != null) { s.Add($"{a:0.00}-{last:0.00}"); a = null; }
            }
            if (a != null) s.Add($"{a:0.00}-{last:0.00}");
            return string.Join(", ", s);
        }
    }

    static Replay Run(Action<bool, string> check, string path, string fixture, double? maxSpeed = null, double? maxRevs = null)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = ""; // no process: runs on the replayed values
        prof.MaxSpeed = maxSpeed; prof.MaxRevs = maxRevs;

        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);

        var feeds = new Dictionary<string, Feed>();
        var eng = new TelemetryEngine
        {
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "WMMT5DXP" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), "WMMT5DXP rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));

        var rp = new Replay { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()) };
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        ps.Connected = true; // replayed: the game counts as attached throughout
        int tc = Col("time_s"), mc = Col("marker");
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(kv.Key));
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            if (r[mc] != "") rp.Marks.Add(t);
            foreach (var kv in feeds) kv.Value.Value = Num(r, cols[kv.Key]);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            rp.End = t;
        }
        return rp;
    }

    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "WMMT5DXP");
        if (gamePackDir == null || !File.Exists(path)) return;
        var freeway = Run(check, path, "wmmt5dxp-20261029.csv.gz");
        Freeway(check, freeway);
        Walls(check, Run(check, path, "wmmt5dxp-20261029-174800.csv.gz"));
        var norm = Run(check, path, "wmmt5dxp-20261029.csv.gz", 320, 9000);
        Normalised(check, freeway, norm);
        Common(check, freeway, norm);
        var pack = ProfileStore.ReadProfile(path);
        check(pack.MaxSpeed == 230 && pack.MaxRevs == 8900, $"WMMT5DXP ships with Max speed 230 and Max revs 8900 (for rpm2): {pack.MaxSpeed} {pack.MaxRevs}");
        // This race was recorded before rpm2 existed, so Car_rpm falls back to rpm: replay it with 8250, the Max revs that suits rpm.
        Race(check, Run(check, path, "wmmt5dxp-20261101-162221.csv.gz", pack.MaxSpeed, 8250));
    }

    /// <summary>16:22 recording: a whole race, start to results screen.</summary>
    static void Race(Action<bool, string> check, Replay r)
    {
        double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        double CarMin(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Min();
        check(r.Marks.Count == 25, "25 markers in the recording: " + r.Marks.Count);

        // Race clock: starts at 5.13 s, freezes 44.38 to 60.57 s, stops at the finish line at 355.52 s
        // (finishing time 5:34.191), then holds on the results screen until the game leaves the race.
        check(r.Max("in_race", 0, 5.0) == 0 && r.Min("in_race", 5.4, 44.3) == 1, "in_race off before the green light, on from it: " + r.Spans("in_race"));
        check(r.Max("in_race", 44.6, 60.4) == 0 && r.Min("in_race", 60.8, 355.4) == 1, "in_race off while the game is frozen (44.4 to 60.6 s), on again after");
        check(r.Max("in_race", 355.7, r.End) == 0, "in_race off from the finish line, results screen included");
        check(CarMax("in_race", 355.7, r.End) == 0 && CarMax("engine", 355.7, r.End) == 0 && CarMax("engine", 44.6, 60.4) == 0,
              "Car_in_race and Car_engine silent after the finish and during the freeze");
        check(CarMax("shift", 355.7, r.End) == 0, "no gear-change pulses on the results screen (the stored gear runs 5, 4, 3, 2 there)");
        check(r.At("race_time", 360) > 334.19 && r.At("race_time", 360) < 334.2, "race_time holds the finishing time, 334.191");

        // Gear: the stored value is the gear. A five-speed car: neutral at the rolling start (revved to
        // 8390 standing still), 1st from the standstill at 12.9 s, up to 5th; down to 1st at 146 s.
        var gears = new[] { (8.0, 0), (12.6, 0), (13.5, 1), (17.0, 2), (23.0, 3), (30.0, 4), (40.0, 5), (146.6, 1), (149.0, 2), (151.0, 3), (153.0, 4), (160.0, 5) };
        check(gears.All(g => r.At("gear", g.Item1) == g.Item2), "gear = stored value, 0 neutral, 1 to 5: " + string.Join(", ", gears.Select(g => $"{g.Item1}s {r.At("gear", g.Item1)}")));
        check(r.Max("gear", 5.2, 355.5) == 5, "five gears: never above 5 in the race");

        // Max speed 230 (249 reached), Max revs 8250 (soft limiter: 8035 to 8237 in 1st and 2nd).
        check(CarMax("speed_frac", 330, 340) == 1 && r.Car["speed"].Max(x => x.v) >= 249, "Car_speed_frac reaches 1 at 230 km/h and stays there to 249");
        check(CarMax("rev_limit", 19.3, 21.4) == 1 && CarMax("rev_limit", 147.5, 148.1) == 1, "Car_rev_limit on the limiter in 2nd (19 to 21 s) and 1st (147.5 s)");
        check(CarMax("rev_limit", 160, 175) == 0 && CarMax("rev_limit", 300, 340) == 0, "Car_rev_limit off cruising in 5th at up to 249 km/h");

        // Joints at low speed: one kick per axle, 0.21, all caught. Markers 10 to 13 follow joints at
        // 61, 63, 15 to 18 and 40 km/h.
        var lowJoints = new[] { 112.40, 119.40, 123.10, 126.97, 132.93, 133.57, 142.00, 142.27 };
        check(lowJoints.All(t => r.Max("road_joint", t - 0.02, t + 0.06) > 0.19), "road_joint catches every joint between 15 and 82 km/h");
        check(r.Marks.Skip(9).Take(4).All(m => r.Max("road_joint", m - 0.6, m) > 0.19), "road_joint before markers 10 to 13");
        check(r.Max("impact", 106, 146) == 0 && r.Min("impact", 106, 146) == 0, "no hits in the slow section");
        check(lowJoints.All(t => CarMax("road_bump", t - 0.02, t + 0.06) > 0.6), "Car_road_bump about 0.7 for the slow joints");

        // Ripple strips: markers 14 to 17 and 21 to 24 were pressed on strips.
        check(new[] { 14, 15, 16, 17, 21, 22, 23, 24 }.All(i => r.Max("rumble_strip", r.Marks[i - 1] - 0.3, r.Marks[i - 1] + 0.3) == 1), "rumble_strip on at the strip markers");
        // Short strips Alexis confirmed from the video (5 or 6 kicks, about 0.37 s), and the strip
        // during the slide before the wall at 295.5 s. rumble_strip comes on as they end.
        foreach (var (a, b) in new[] { (182.2, 183.0), (194.1, 194.9), (218.77, 219.6), (297.9, 298.7), (308.3, 309.1), (295.17, 295.9) })
            check(r.Max("rumble_strip", a, b) == 1, $"short strip at {a:0.0} s: " + r.Spans("rumble_strip"));
        // Runs of 3 or 4 kicks over about 0.2 s (two joints close together) aren't strips.
        foreach (var (a, b) in new[] { (41.1, 41.8), (165.5, 167.9), (180.1, 181.6), (223.0, 223.7), (292.0, 292.9) })
            check(r.Max("rumble_strip", a, b) == 0, $"no strip for the short burst at {a:0.0} s: " + r.Spans("rumble_strip"));

        // Hits (time trial, no traffic: all walls)
        check(r.Min("impact", 39.3, 39.45) <= -0.5, "big left-hand wall hit at 39.36 s (223 to 128 km/h in one sample; LHS confirmed from the video)");
        check(r.Min("impact", 210.1, 210.35) < -0.7, "-0.75 hit (left) at 210.27 s");

        // Crests, all confirmed from the video: spring held at 0, revs rising, no hit before it.
        // 186 s (rear wheels off) and 303.5 s (a dip, rear wheels off) leave the ground; 92 s is a
        // crest; 101.7, 192.8 and 308.3 s are crests where the wheels stay down.
        foreach (var (a, b) in new[] { (92.0, 92.26), (101.65, 101.83), (186.3, 186.75), (192.75, 192.87), (303.5, 303.68), (308.28, 308.37) })
            check(r.Max("airborne", a, b) == 1, $"airborne on the crest at {a:0.0} s: " + r.Spans("airborne"));
        check(r.Max("airborne", 0, 6) == 0 && r.Max("airborne", 355, r.End) == 0, "airborne never before the start or after the finish");
        // Landing strength follows the time in the air: full where the rear wheels left the road,
        // softer for the crests where they stayed down (Alexis, 1 November).
        check(CarMax("landed", 186.75, 187.1) == 1, "Car_landed full after the rear wheels left the road at 186 s: " + CarMax("landed", 186.75, 187.1));
        check(CarMax("landed", 303.65, 304.0) > 0.7, "Car_landed strong after the dip at 303.5 s (rear wheels off): " + CarMax("landed", 303.65, 304.0));
        foreach (var (a, b) in new[] { (192.8, 193.2), (308.3, 308.7) })
            check(CarMax("landed", a, b) > 0 && CarMax("landed", a, b) < 0.6, $"Car_landed soft after the wheels-down crest at {a:0.0} s: " + CarMax("landed", a, b));
        check(CarMax("landed", 101.8, 102.1) > 0 && CarMax("landed", 101.8, 102.1) < 0.75, "Car_landed softer after the wheels-down crest at 101.7 s: " + CarMax("landed", 101.8, 102.1));

        Console.WriteLine($"WMMT5DX+ replay 16:22: in_race {r.Spans("in_race")}; airborne {r.Spans("airborne")}; strip {r.Spans("rumble_strip")}; " +
                          $"hits {r.Events("impact").Count}; wall {r.Spans("wall_contact")}");
    }

    /// <summary>TPTelemetry.Car_* from the WMMT5DXP car_ rows, on the freeway recording.</summary>
    static void Common(Action<bool, string> check, Replay raw, Replay norm)
    {
        double Max(Replay r, string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        check(raw.Car["speed"].Max(x => x.v) > 200 && raw.Car["speed_frac"].Max(x => x.v) == 0,
              "Car_speed raw (215 km/h); Car_speed_frac silent with Max speed blank");
        check(Math.Abs(norm.Car["speed_frac"].Max(x => x.v) - norm.Car["speed"].Max(x => x.v) / 320) < 1e-9 && norm.Car["speed"].Max(x => x.v) > 200,
              "with Max speed 320: Car_speed_frac = speed / 320, Car_speed still raw");
        var hits = raw.Events("impact");
        check(hits.All(h => Max(raw, "impact", h - 0.05, h + 0.1) > 0.5), "Car_impact fires on every WMMT hit");
        check(Max(raw, "impact", 55.4, 55.8) > 0.9, "big crash (0.78): Car_impact about 1");
        check(hits.All(h => Max(raw, "impact_left", h - 0.05, h + 0.1) > 0 && Max(raw, "impact_right", h - 0.05, h + 0.1) > 0),
              "every hit is felt on both sides (30% on the far side)");
        check(Max(raw, "rumble_strip", 51.9, 53.0) == 1 && raw.Car["rumble_strip"].Where(x => (x.t < 48.5 || x.t > 54) && !ShortStrip(x.t)).All(x => x.v == 0),
              "Car_rumble_strip only on the strips");
        check(raw.Car["road_bump"].Max(x => x.v) > 0.6, "Car_road_bump reaches the joint kicks (0.3 -> about 1)");
        check(raw.Car["in_race"].Last().v == 1, "Car_in_race 1 once the race clock runs");
        check(norm.Car["rpm_frac"].Max(x => x.v) > 0.8 && norm.Car["rpm_frac"].Max(x => x.v) <= 1, "Car_rpm_frac with Max revs 9000");
    }

    /// <summary>Max speed and Max revs set: speed and rpm run 0 to 1, and accel_g (which undoes the
    /// division) and everything else stays exactly as with the boxes blank.</summary>
    static void Normalised(Action<bool, string> check, Replay raw, Replay norm)
    {
        bool Same(string n, Func<double, double> f) =>
            raw.Out[n].Zip(norm.Out[n], (a, b) => double.IsNaN(a.v) ? double.IsNaN(b.v) : Math.Abs(f(a.v) - b.v) < 1e-9).All(x => x);
        check(Same("speed", v => v / 320), "Max speed 320: speed = raw km/h / 320");
        check(Same("rpm", v => v / 9000), "Max revs 9000: rpm = raw RPM / 9000");
        check(norm.Out["speed"].Max(x => x.v) < 1 && norm.Out["speed"].Max(x => x.v) > 0.6, "normalised speed runs 0 to 1 (215 km/h top = 0.67)");
        check(Same("accel_g", v => v), "accel_g unchanged by Max speed");
        check(new[] { "road_joint", "rumble_strip", "impact", "wall_contact", "airborne", "gear" }.All(n => Same(n, v => v)),
              "other rows unchanged by Max speed and Max revs");
    }

    /// <summary>Two six-kick runs in the 11:08 recording, the same shape as the short strips Alexis
    /// confirmed on 1 November (5 or 6 kicks over about 0.37 s): 70.1 to 70.5 s (unmarked, between
    /// joint markers 13 and 14) and 55.2 to 55.7 s, just before the big crash.</summary>
    static bool ShortStrip(double t) => (t >= 55.5 && t <= 56.1) || (t >= 70.4 && t <= 71.0);

    /// <summary>11:08 recording: joints, a strip and hits at about 200 km/h.</summary>
    static void Freeway(Action<bool, string> check, Replay r)
    {
        var marks = r.Marks;
        check(marks.Count == 15, "15 markers in the recording");
        // Joint markers: 1-5 and 9-15 (6-8 are the ripple strip). Each follows a joint within 0.6 s.
        var jointMarks = marks.Take(5).Concat(marks.Skip(8)).ToList();
        int found = jointMarks.Count(m => r.Max("road_joint", m - 0.6, m) > 0.2);
        check(found == jointMarks.Count, $"road_joint fires before every joint marker: {found} of {jointMarks.Count}");
        check(jointMarks.All(m => r.Max("impact", m - 0.6, m) == 0 || r.Min("impact", m - 0.6, m) == 0), "joints aren't hits");

        var hits = r.Events("impact");
        check(hits.Count == 18, "18 hits, as in the recording: " + hits.Count + " (" + string.Join(", ", hits.Select(h => h.ToString("0.00", CultureInfo.InvariantCulture))) + ")");
        check(r.Max("impact", 55.4, 55.8) > 0.7, "the big crash reads 0.78");
        check(hits.All(h => Math.Sign(r.At("impact_side", h + 0.1)) == Math.Sign(r.At("impact", h))),
              "impact_side shows every hit, with its sign, 0.1 s later");

        var strip = r.Events("rumble_strip", 0.5, 0.3);
        check(r.Max("rumble_strip", 51.9, 53.0) == 1 && r.Max("rumble_strip", 49.5, 50.5) == 1, "rumble_strip on through both stretches of strip");
        check(marks.Skip(5).Take(3).All(m => r.Max("rumble_strip", m - 0.5, m) == 1), "rumble_strip on at markers 6-8");
        double stripOutside = r.Out["rumble_strip"].Where(x => (x.t < 48.5 || x.t > 54.0) && !ShortStrip(x.t)).Max(x => x.v);
        check(stripOutside == 0, "rumble_strip off everywhere else: " + r.Spans("rumble_strip"));
        check(strip.Count <= 4, "rumble_strip comes on in a few stretches, not flickering: " + strip.Count);
        // Separate hits a quarter of a second or more apart aren't scraping along a wall; the big crash
        // (0.78, then 0.5 held) is the one place it shows.
        bool Off(double a, double b) => r.Max("wall_contact", a, b) == 0 && r.Min("wall_contact", a, b) == 0;
        check(Off(0, 55.5) && Off(56.1, r.End) && r.Max("wall_contact", 55.5, 56.1) == 1, "wall_contact only at the big crash: " + r.Spans("wall_contact"));

        check(r.Max("grip_loss", 19, 25) < 0.2, "grip_loss low cruising: " + r.Max("grip_loss", 19, 25));
        check(r.Max("grip_loss", 37.4, 40.0) > 0.9 && r.Max("grip_loss", 73.7, 75.4) > 0.9, "grip_loss near 1 in the slides");
        check(r.Min("accel_g", 55.2, 56.0) < -5 && r.Max("accel_g", 19, 25) < 0.4, "accel_g: crash strongly negative, cruising small");

        Console.WriteLine($"WMMT5DX+ replay 11:08: {found}/{jointMarks.Count} joint markers, {hits.Count} hits, strip {string.Join(", ", strip.Select(s => s.ToString("0.0", CultureInfo.InvariantCulture)))} s, " +
                          $"airborne {r.Spans("airborne")}");
    }

    /// <summary>17:48 recording. Alexis's notes, with the markers:
    /// ripple strip, right turn, 1 end of the strip, up to 4th, left turn, up to 5th, 2 jump (rear wheels
    /// only), 3 crash into the right-hand wall, down to 4th, up to 5th, down to 4th, 4 right-hand turn
    /// drifting over a ripple strip, up to 5th, left turn, quick right turn/drift, 5 right-hand wall, 6 left-hand wall.</summary>
    static void Walls(Action<bool, string> check, Replay r)
    {
        var m = r.Marks;
        check(m.Count == 6, "6 markers in the recording: " + m.Count);
        if (m.Count != 6) return;

        // Gear changes where the notes put them. The notes called these 4th and 5th; the 1 November
        // recording (a five-speed car reaching a stored 5) showed the stored value is the gear itself,
        // so they were 3rd and 4th.
        var gears = new[] { (7.5, 3), (10.0, 4), (16.0, 4), (21.0, 3), (24.0, 4), (28.0, 3), (33.0, 4), (40.0, 4) };
        check(gears.All(g => r.At("gear", g.Item1) == g.Item2), "gear changes at the noted shifts: " + string.Join(", ", gears.Select(g => $"{g.Item1}s {r.At("gear", g.Item1)}")));

        // Ripple strip from the start to marker 1, and again drifting across one at marker 4.
        check(r.Min("rumble_strip", 3.0, 6.3) == 1, "rumble_strip on along the opening strip: " + r.Spans("rumble_strip"));
        check(r.Max("rumble_strip", m[3], m[3] + 2.5) == 1, "rumble_strip on while drifting over the strip at marker 4");
        // The drift across the strip at marker 4 runs on to 29.6 s (four more kicks), so strip until 30.1 s.
        check(r.Max("rumble_strip", 7.6, m[3] - 0.5) == 0 && r.Max("rumble_strip", 30.2, r.End) == 0, "rumble_strip off elsewhere, walls included: " + r.Spans("rumble_strip"));

        // Walls: + on the right, - on the left.
        check(r.Max("impact", m[2] - 0.1, m[2] + 0.1) >= 0.5, "marker 3: right-hand wall reads +");
        check(r.Max("impact", m[4] - 0.1, m[4] + 0.1) >= 0.5, "marker 5: right-hand wall reads +");
        check(r.Min("impact", m[5] - 0.5, m[5]) <= -0.5, "marker 6: left-hand wall reads -");
        check(r.Min("wall_contact", m[2] + 0.4, m[2] + 1.3) == 1, "wall_contact +1 along the right-hand wall after marker 3: " + r.Spans("wall_contact"));
        check(r.Max("wall_contact", m[4], m[4] + 1.0) == 1, "wall_contact +1 after marker 5");
        check(r.Min("wall_contact", m[5], m[5] + 2.0) == -1 && r.Max("wall_contact", m[5], m[5] + 2.0) <= 0, "wall_contact -1 along the left-hand wall at marker 6");
        check(r.Max("wall_contact", 0, m[2]) == 0 && r.Max("wall_contact", 20, m[4] - 0.1) == 0 && r.Min("wall_contact", 0, m[5] - 1) >= 0,
              "wall_contact off away from the walls: " + r.Spans("wall_contact"));
        check(r.Max("road_joint", m[2], m[2] + 1.4) == 0, "the 0.2 held along the wall isn't a road joint");

        // Jump at marker 2: the game drops the spring with no hit.
        check(r.Max("airborne", m[1] - 0.3, m[1] + 0.3) == 1, "airborne at the jump (marker 2)");
        check(r.Spans("airborne").Split(',').Length == 1, "airborne only at the jump: " + r.Spans("airborne"));

        check(r.Min("tire_slip", m[3], m[3] + 2.5) < -0.1, "tire_slip - drifting right at marker 4");
        check(r.Max("grip_loss", m[3], m[3] + 2.5) > 0.9, "grip_loss near 1 drifting at marker 4");
        check(r.Max("lampview1", 5, 10) == 1 && r.Min("lampview1", 5, 10) == 0, "View 1 lamp blinks");

        Console.WriteLine($"WMMT5DX+ replay 17:48: strip {r.Spans("rumble_strip")}; wall {r.Spans("wall_contact")}; airborne {r.Spans("airborne")}");
    }
}
