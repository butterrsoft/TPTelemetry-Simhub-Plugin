using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.TeknoParrot;
using Replay = Wmmt5ReplayTests.Replay;

/// <summary>
/// Replays Alexis's Sega Rally 3 recording (2 November 2026, 19:22, 86 s, one lap of three, manual)
/// through the pack's SR3 profile: the memory rows get the speed (mph), stored gear, revs and lamp byte
/// read at the time, and TeknoParrot's slots the force commands the game wrote. The fixture also keeps
/// the force, steering and throttle her G25 saw over USB (usb_ columns) to check the force decode.
/// Her notes: driver's view, revving in neutral; 1 start (game drops it into 1st, she shifts up); brush
/// left in 4th; 5th, brush a car on the right; drift through a right turn; brush a car on the left;
/// 2 front right-hand wall; 6th; 3 jump 1 takeoff at 186 km/h; 4 landing at 196; rear right-hand wall
/// (drift into it); 5 jump 2 takeoff at 201; 6 landing in water, a small dip; small turns; a dip;
/// checkpoint at 200 to 201; 7 front left-hand hit in water; 8 left-hand wall flat while drifting;
/// 9 kissing the same wall; 10 front right-hand wall; 11 scraping the right-hand wall; down a few gears
/// and back up; 12 kiss a car on the left; lap line; left-hand wall at about 193 km/h.
/// </summary>
static class Sr3ReplayTests
{
    static readonly string[] Extra = { "usb_force", "usb_steer", "usb_throttle" };

    static Replay Run(Action<bool, string> check, string path, string fixture)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = ""; // no process: runs on the replayed values

        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);

        var tp = new double[TpChannels.Count];
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            TpSource = a => Array.Copy(tp, a, a.Length),
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "SR3" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), "SR3 rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));

        var rp = new Replay { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()) };
        foreach (var x in Extra) rp.Out[x] = new List<(double t, double v)>();
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        foreach (var l in CommonValues.Lamps) rp.Car["Lamp_" + l.Name] = new List<(double t, double v)>();   // 0.20.0
        ps.Connected = true;
        int tc = Col("time_s"), mc = Col("marker");
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(kv.Key));
        // the rows from the game's own code (Rally.exe, 12 November 2026) came after this recording
        var later = new HashSet<string>(prof.Variables.Where(v => (v.Notes ?? "").Contains("Rally.exe, 12 November 2026")).Select(v => v.Name));
        check(later.Count >= 8 && later.Contains("player_state") && later.Contains("time_left"), "SR3 rows from the game's code: " + string.Join(", ", later));
        check(cols.Where(c => !later.Contains(c.Key)).All(c => c.Value >= 0), "the recording has every memory row: " + string.Join(", ", cols.Where(c => c.Value < 0 && !later.Contains(c.Key)).Select(c => c.Key)));
        var slots = Enumerable.Range(0, TpChannels.SlotCount).Select(i => Col("tp_jvs" + i)).ToArray();
        int conn = Col("tp_connected");
        var extra = Extra.ToDictionary(x => x, Col);
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            if (r[mc] != "") rp.Marks.Add(t);
            foreach (var kv in feeds) kv.Value.Value = Num(r, cols[kv.Key]);
            for (int i = 0; i < slots.Length; i++) tp[i] = Num(r, slots[i]);
            tp[TpChannels.Connected] = Num(r, conn);
            eng.TpSource(ps.Ctx.Tp);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            foreach (var x in Extra) rp.Out[x].Add((t, Num(r, extra[x])));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            foreach (var l in CommonValues.Lamps) rp.Car["Lamp_" + l.Name].Add((t, eng.Common.GetLamp(l.Name)));
            rp.End = t;
        }
        return rp;
    }

    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "SR3");
        if (gamePackDir == null || !File.Exists(path)) return;
        // From Rally.exe (12 November 2026): car 0's record in the static car array (0x9DBAC8, 0x1F18 each) and the time left.
        var prof = ProfileStore.ReadProfile(path);
        foreach (var (n, b, o, t) in new[] { ("player_state", "5DD5C0", "", MemType.Int32), ("time_left", "5DB4C8", "", MemType.Int64),
                                             ("lap", "5DD614", "", MemType.Int32), ("position", "5DD61C", "", MemType.Int32),
                                             ("checkpoints", "5DD610", "", MemType.Int32), ("laps_total", "328A28", "", MemType.Int32),
                                             ("wrong_way", "5DBACC", "1CBC", MemType.Int32) })
        {
            var v = prof.Variables.FirstOrDefault(x => x.Name == n);
            check(v != null && v.Source == SourceKind.Memory && v.Module == "<main>" && v.BaseOffset == b && (v.Offsets ?? "").Replace(" ", "") == o && v.Type == t,
                  $"SR3 {n}: Rally.exe+{b}" + (o == "" ? "" : " -> " + o));
        }
        Lap(check, Run(check, path, "sr3-20261102-192249.csv.gz"));
        Sixteenth(check, Run(check, path, "sr3-20261116-102408.csv.gz"));
    }

    /// <summary>16 November 2026, 10:24, with the exe rows (game mode 5, three laps): attract mode and menus (player state 0),
    /// the intro (1, 4 s), GO at 26.63 s (3; the time set to 70 s), checkpoints at 62.75, 117.81 and 191.11 s (+25 s) and lap lines
    /// at 88.71 and 162.07 s (+30 s), a crash and WRONG WAY turning round (144.85 to 148.71 s), the finish line at 217.39 s (5),
    /// then the results with the revs frozen at 6758. Her marks at the three checkpoints came 0.4 to 0.5 s after the time jumped.</summary>
    static void Sixteenth(Action<bool, string> check, Replay r)
    {
        bool Near(IList<double> xs, params double[] want) => xs.Count == want.Length && xs.Zip(want, (a, b) => Math.Abs(a - b) < 0.05).All(x => x);
        check(Near(r.Events("racing", 0, 0.5), 26.63) && r.At("racing", 217.3) == 1 && r.At("racing", 217.5) == 0 && r.Max("racing", 0, 26.5) == 0,
              "racing from GO (26.63) to the finish line (217.39): " + r.Spans("racing"));
        check(r.Car["in_race"].Zip(r.Out["racing"], (p, q) => p.v == q.v).All(x => x), "Car_in_race is racing (0 in the attract mode and menus, state 0)");
        foreach (var n in new[] { "speed", "rpm", "gear", "impact", "cornering", "airborne" })
            check(r.Car[n].Where(x => r.At("racing", x.t) == 0).All(x => x.v == 0), $"Car_{n} 0 outside a race");
        check(r.Out["rpm"].Last().v * 7100 > 6700, "the game leaves the revs at 6758 in the results; Car_rpm reads 0 there");
        check(Near(r.Events("checkpoint", 0, 0.5), 62.75, 88.71, 117.81, 162.07, 191.11), "checkpoint at the three checkpoints and two lap lines: " + r.Spans("checkpoint"));
        check(r.At("lap", 29.0) == 0 && r.At("lap", 30.0) == 1 && r.At("lap", 89.0) == 2 && r.At("lap", 163.0) == 3 && r.At("final_lap", 163.0) == 1 && r.At("final_lap", 150) == 0,
              "lap 1 over the start line, 2 and 3 at the lap lines; final lap on the third");
        int Changes(string n) => r.Out[n].Zip(r.Out[n].Skip(1), (p, q) => p.v != q.v).Count(x => x);
        check(Changes("position") <= 14 && r.At("position", 217.3) == 3, $"position without the game's flicker ({Changes("position")} changes), 3 at the line");
        check(r.Max("wrong_way", 0, 26) == 0 && r.Max("wrong_way", 145, 148) == 1 && r.Max("wrong_way", 150, 217) == 0, "WRONG WAY only while turned round (the game leaves it set in the menus)");
        // dashboard values and common lamps (0.20.0) on her Quick Race
        double CarAt16(string n, double t) => r.Car[n].First(x => x.t >= t).v;
        check(r.Car["Lamp_warning"].Zip(r.Out["wrong_way"], (p, q) => p.v == q.v).All(x => x), "Lamp_warning is WRONG WAY here");
        check(r.Car["time_left"].Zip(r.Out["rt"], (p, q) => Math.Abs(p.v - (r.At("racing", p.t) == 1 ? q.v : 0)) < 1e-9).All(x => x), "Car_time_left is the RT on screen while racing");
        check(r.Car["race_time"].Zip(r.Out["race_time"], (p, q) => Math.Abs(p.v - q.v) < 1e-9).All(x => x), "Car_race_time is the TT");
        check(Enumerable.Range(0, 20).Select(i => 30 + i * 9.0).All(t => Math.Abs(CarAt16("speed_mph", t) - CarAt16("speed", t)) < 1e-6 && Math.Abs(CarAt16("speed_kmh", t) - CarAt16("speed", t) * 1.609344) < 1e-6),
              "Car_speed_mph is the screen's mph, Car_speed_kmh that in km/h");
        check(r.Car["lap"].Where(x => r.At("racing", x.t) == 1 && x.t > 30).All(x => x.v >= 1 && x.v <= 3) && CarAt16("laps_total", 100) == 3, "Car_lap 1 to 3 of Car_laps_total 3");
        check(r.Car["Lamp_final_lap"].Zip(r.Out["final_lap"], (p, q) => p.v == q.v).All(x => x) && r.Car["final_lap"].Zip(r.Car["Lamp_final_lap"], (p, q) => p.v == q.v).All(x => x),
              "Lamp_final_lap and Car_final_lap follow final_lap");
        check(r.Car["Lamp_leader"].Zip(r.Out["leader"], (p, q) => p.v == q.v).All(x => x), "Lamp_leader is the made-up leader lamp");
        check(r.Car["Lamp_shift"].Where(x => r.At("racing", x.t) == 0).All(x => x.v == 0) && r.Car["Lamp_shift"].Any(x => x.v == 1),
              "Lamp_shift (made from Car_rpm_frac, no game lamp) lights in the race only: " + F(r.Car["Lamp_shift"].Count(x => x.v == 1) / 120.0) + " s");
        var hits = r.Events("hit", 0, 0.5);
        check(hits.All(t => t > 26.6 && t < 217.4) && hits.Count >= 8, "hits only in the race: " + Times(hits));
        // RT as the screen shows it (Alexis, 16 November 2026: 33 at TT 0:36.43, 56 at TT 0:38.73; the screen cuts off the decimals)
        double go = 26.627;
        // the game adds the extension at TT 0:36.12; the screen keeps the old RT while TIME EXTENSION flashes (her 33 at 0:36.43 is 70 - TT)
        check(Math.Floor(r.At("rt", go + 36.05)) == 33 && Math.Floor(r.At("rt", go + 38.73)) == 56, $"rt 33 before the extension and 56 at TT 0:38.73: {F(r.At("rt", go + 36.05))}, {F(r.At("rt", go + 38.73))}");
        check(Math.Abs(r.At("race_time", 217.3) - 190.67) < 0.05 && r.At("race_time", 220) == 0, $"race_time is TT (3:10.76 at the line): {F(r.At("race_time", 217.3))}");
        Console.WriteLine($"SR3 replay 16 Nov 10:24: racing {r.Spans("racing")}; checkpoints {r.Spans("checkpoint")}; position changes {Changes("position")}; hits {Times(hits)}");
    }

    static string F(double v) => v.ToString("0.00", CultureInfo.InvariantCulture);
    static string Times(IEnumerable<double> ts) => string.Join(", ", ts.Select(F));

    static double Corr(IList<double> a, IList<double> b)
    {
        double ma = a.Average(), mb = b.Average(), sab = 0, saa = 0, sbb = 0;
        for (int i = 0; i < a.Count; i++) { sab += (a[i] - ma) * (b[i] - mb); saa += (a[i] - ma) * (a[i] - ma); sbb += (b[i] - mb) * (b[i] - mb); }
        return sab / Math.Sqrt(saa * sbb);
    }

    static void Lap(Action<bool, string> check, Replay r)
    {
        var m = r.Marks;
        check(m.Count == 12, "12 markers in the 19:22 recording: " + m.Count);
        // Car_in_race: the player state's racing (3); a recording without the row (this one) keeps it on, as before
        check(r.Car["in_race"].All(x => x.v == 1), "Car_in_race stays 1 when the player state can't be read");
        if (m.Count != 12) return;
        double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        double CarAt(string n, double t) => r.Car[n].First(x => x.t >= t).v;
        double Kmh(double t) => CarAt("speed", t) * 1.609344;

        // Speed is mph: it matches the km/h Alexis read off the speedo at her marks.
        foreach (var (t, kmh) in new[] { (m[2], 186.0), (m[3], 196.0), (m[4], 201.0), (83.30, 193.0) })
            check(Math.Abs(Kmh(t) - kmh) < 4, $"speed in mph matches the speedo ({kmh:0} km/h) at {F(t)}: {Kmh(t):0.0} km/h");
        double top = r.Car["speed"].Max(x => x.v);
        check(top > 128 && top < 132, "top speed about 130 mph (210 km/h): " + top.ToString("0.0", CultureInfo.InvariantCulture));

        // Gear: -1 before the driver's view, neutral on the grid, the game drops it into 1st, then up to 6th.
        check(r.Max("gear", 0, 3.3) == -1 && r.Min("gear", 3.5, 7.3) == 0 && r.Max("gear", 3.5, 7.3) == 0, "gear -1, then 0 (neutral) on the grid");
        check(r.At("gear", 7.40) == 1 && r.At("gear", 8.2) == 2 && r.At("gear", 10.2) == 4 && r.At("gear", 13.4) == 5 && r.At("gear", 29.3) == 6, "gear 1 at the start, then 2 to 6 as she shifted");
        check(r.At("gear", 11.4) == 4, "4th when she brushed the left side (11.41)");
        check(r.Min("gear", 66, 69) == 2 && r.At("gear", 73) == 6, "down to 2nd and back up to 6th after mark 11");

        // Revs: limiter about 6930 in gear, 7397 overrevved on the downshift; 0 on the grid before the throttle.
        double revs = r.Car["rpm"].Max(x => x.v);
        check(revs > 7300 && revs < 7500, "top revs 7397 on the downshift: " + revs.ToString("0", CultureInfo.InvariantCulture));
        check(r.Car["rpm"].Where(x => x.t > 13.4 && x.t < 66).Max(x => x.v) < 6940, "limiter under 6940 in 5th and 6th");
        check(r.Car["rpm"].Where(x => x.t > 3.5 && x.t < 4.5).All(x => Math.Abs(x.v) < 10), "revs read 0 on the grid before the throttle");
        // Max revs 7100 (Alexis): the rev limiter effect only at the limiter, not over 40% of the lap as at 6600.
        double limOn = r.Car["rev_limit"].Where(x => x.t > 7.4).Count(x => x.v > 0) / (double)r.Car["rev_limit"].Count(x => x.t > 7.4);
        check(limOn > 0.01 && limOn < 0.06, "Car_rev_limit at the limiter only (Max revs 7100): on " + (limOn * 100).ToString("0.0", CultureInfo.InvariantCulture) + "% of the lap");
        check(CarMax("rev_limit", 5.5, 7.3) == 1 && CarMax("rev_limit", 47.5, 50.0) == 0, "Car_rev_limit revving on the grid, not at 4000 rpm in the water");
        // Max speed 125 mph (Alexis): full speed effects from about 201 km/h, the top being 210.
        check(CarMax("speed_frac", 44.0, 47.3) == 1 && CarMax("speed_frac", 24.0, 28.0) < 0.9, "Car_speed_frac 1 above 125 mph only");

        // Force: the decode is what the G25 got over USB (about two samples later), and + is steering right.
        var f = r.Out["force"].Select(x => x.v).ToList(); var usb = r.Out["usb_force"].Select(x => x.v).ToList();
        double cUsb = Corr(f.Take(f.Count - 2).ToList(), usb.Skip(2).ToList());
        check(cUsb > 0.9, "force matches the USB force: correlation " + F(cUsb));
        double cSteer = Corr(r.Out["force_smooth"].Select(x => x.v).ToList(), r.Out["usb_steer"].Select(x => x.v).ToList());
        check(cSteer > 0.5, "force_smooth is + steering right: correlation " + F(cSteer));
        check(r.Max("force", 0, r.End) < 0.74 && r.Min("force", 0, r.End) > -0.67, "the game's force stays within -0.67 to 0.73");

        // Hits: every wall, nothing else. Marks 8 and 9 came about a second after the contact.
        var walls = new[] { 21.79, 34.13, 47.32, 56.35, 61.24, 63.22, 83.32, 84.72 };
        var sides = new[] { 1.0, -1, -1, -1, 1, 1, -1, -1 }; // 34.13 was a rear right-hand hit: the wheel kicked left
        var hits = r.Events("hit", 0, 0.5);
        check(hits.Count == walls.Length && hits.Zip(walls, (a, b) => Math.Abs(a - b) < 0.05).All(x => x), "hit at the walls only: " + Times(hits));
        for (int i = 0; i < walls.Length; i++)
        {
            check(r.At("hit_side", walls[i] + 0.05) == sides[i], $"hit_side {sides[i]} at {F(walls[i])}: {r.At("hit_side", walls[i] + 0.05)}");
            check(CarMax("impact", walls[i], walls[i] + 0.3) >= 0.5, $"Car_impact at {F(walls[i])}");
        }
        foreach (var t in new[] { 21.79, 47.32, 56.35, 83.32 })
            check(CarMax("impact", t, t + 0.3) > 0.9, $"Car_impact near 1 at the big hit at {F(t)}: {F(CarMax("impact", t, t + 0.3))}");
        foreach (var t in new[] { 34.13, 63.22 })
            check(CarMax("impact", t, t + 0.3) < 0.7, $"Car_impact lighter at {F(t)}: {F(CarMax("impact", t, t + 0.3))}");
        check(r.Out["hit_side"].All(x => x.v == 0 || r.At("hit", x.t) == 1), "hit_side only while hit");
        check(r.Max("hit", 39.3, 40.5) == 0, "landing in water (mark 6) is a landing, not a hit");
        check(r.Max("hit", 66.0, 69.0) == 0, "no hit on the downshift to 2nd (engine braking)");

        // Airborne: no force for 0.4 s at speed, both jumps only; a landing after each.
        var air = r.Events("airborne", 0, 0.5);
        check(air.Count == 2 && Math.Abs(air[0] - 32.47) < 0.05 && Math.Abs(air[1] - 38.92) < 0.05, "airborne at the two jumps only: " + r.Spans("airborne"));
        check(r.At("airborne", 32.6) == 1 && r.At("airborne", 32.7) == 0 && r.At("airborne", 39.4) == 1 && r.At("airborne", 39.5) == 0, "airborne ends at 32.66 and 39.47");
        check(CarMax("landed", 32.66, 32.95) > 0.7 && CarMax("landed", 39.47, 39.75) == 1, $"Car_landed after each jump: {F(CarMax("landed", 32.66, 32.95))}, {F(CarMax("landed", 39.47, 39.75))}");

        // The old stand-ins from the force are gone: no road bump, and Car_impact only at the walls.
        check(r.Out["car_road_bump"].All(x => x.v == 0) && r.Car["road_bump"].All(x => x.v == 0), "car_road_bump is 0 (the force kicks were road texture all the time; the 0 row also keeps the USB stand-in out)");
        var stray = r.Car["impact"].Where(x => x.v > 0 && r.At("hit", x.t) != 1).Select(x => x.t).ToList();
        check(stray.Count == 0, "Car_impact only while hit (so only at the walls): stray at " + Times(stray.Take(5)));

        Console.WriteLine($"SR3 replay 19:22: hits {Times(hits)}; Car_impact {string.Join(", ", walls.Select(t => F(CarMax("impact", t, t + 0.3))))}; airborne {r.Spans("airborne")}; force vs USB {F(cUsb)}");
    }
}
