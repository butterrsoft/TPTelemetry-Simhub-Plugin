using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.TeknoParrot;
using TeknoTelemetry.Core.Ffb;
using Replay = Wmmt5ReplayTests.Replay;

/// <summary>
/// Replays Alexis's OutRun 2 SP SDX recordings (2 November 2026) through the pack's OUTRUN2SP profile.
/// They were made with the old Legacy profile, so the fixtures keep only the memory rows, renamed to
/// the profile's names (and the time column, whose header was damaged in the recording).
///  * 15:38, 90 s, with Alexis's notes: 1 start; 2 sand centre strip, then the left-hand and right-hand
///    walls; 3 bus (car leaves the ground); 4 rear of a small car; 7 rear of a small car; 8 striped verge;
///    9 right-hand wall; 10 left-hand wall after a little grass; 11 drifts and grass verges; 12 checkpoint;
///    13 scraping a small car; 14 left-hand wall, then the rear of a midsize car; 15 semitrailer.
///  * 15:30, 102 s, no notes: checked for the same signals.
///  * 17:45, 83 s, automatic gearbox: 1 start; 2 to 4 around a left-hand wall hit at 80.02 s where the car
///    flips over and the game puts it back on the track; the recording ends there.
/// </summary>
static class Or2ReplayTests
{
    static Replay Run(Action<bool, string> check, string path, string fixture)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = ""; // no process: runs on the replayed values

        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);

        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "OUTRUN2SP" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), "OUTRUN2SP rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));

        var rp = new Replay { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()) };
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        ps.Connected = true;
        int tc = Col("time_s"), mc = Col("marker");
        // The rows from the game's own code (11 November 2026) aren't in these recordings. Car_in_race now comes from the game's
        // main sequence (15 = GAME) and its goal and time-up bits: fed here from what gated the effects when they were recorded
        // (the HUD flag, in_race), with no goal or time up, so the replays gate the effects as they did live.
        var fromCol = new Dictionary<string, (string col, Func<double, double> conv)>
        {
            ["main_mode"] = ("in_race", x => double.IsNaN(x) ? double.NaN : (x != 0 ? 15 : 0)),
            ["observer_flag"] = ("in_race", x => double.IsNaN(x) ? double.NaN : 0),
        };
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(fromCol.TryGetValue(kv.Key, out var fc) ? fc.col : kv.Key));
        // Rows added after a recording was made aren't in it: they read nothing here.
        var later = new HashSet<string>(prof.Variables.Where(v => ((v.Notes ?? "").Contains("fake mode") || (v.Notes ?? "").Contains("the game's own code"))
                                                                  && !fromCol.ContainsKey(v.Name)).Select(v => v.Name));
        check(cols.Where(c => !later.Contains(c.Key)).All(c => c.Value >= 0), "the recording has every memory row: " + string.Join(", ", cols.Where(c => c.Value < 0 && !later.Contains(c.Key)).Select(c => c.Key)));
        // Recordings with USB capture: the wheel force goes through the common values as it did live.
        int uf = Col("usb_force"), ur = Col("usb_rumble");
        if (uf >= 0) foreach (var x in new[] { "usb_force", "usb_steer" }) rp.Out[x] = new List<(double t, double v)>();
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            if (r[mc] != "") rp.Marks.Add(t);
            foreach (var kv in feeds) kv.Value.Value = fromCol.TryGetValue(kv.Key, out var fc) ? fc.conv(Num(r, cols[kv.Key])) : Num(r, cols[kv.Key]);
            if (uf >= 0)
            {
                var ffb = ps.Ctx.Ffb;
                ffb[FfbChannels.Connected] = 1; ffb[FfbChannels.Force] = Num(r, uf); ffb[FfbChannels.Rumble] = Num(r, ur);
                rp.Out["usb_force"].Add((t, Num(r, uf))); rp.Out["usb_steer"].Add((t, Num(r, Col("usb_steer"))));
            }
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            rp.End = t;
        }
        return rp;
    }

    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "OUTRUN2SP");
        if (gamePackDir == null || !File.Exists(path)) return;
        check(!File.Exists(PackFiles.Find(gamePackDir, "OUTRUN2SPLEGACY")), "the OR2 Legacy profile is gone");
        Main(check, Run(check, path, "or2-20261102-153851.csv.gz"));
        Extra(check, Run(check, path, "or2-20261102-153048.csv.gz"));
        Third(check, Run(check, path, "or2-20261102-174520.csv.gz"));
        Fourth(check, Run(check, path, "or2-20261103-204859.csv.gz"));
    }

    static string F(double v) => v.ToString("0.00", CultureInfo.InvariantCulture);
    static string Times(IEnumerable<double> ts) => string.Join(", ", ts.Select(F));

    static void Main(Action<bool, string> check, Replay r)
    {
        var m = r.Marks;
        check(m.Count == 15, "15 markers in the 15:38 recording: " + m.Count);
        if (m.Count != 15) return;
        double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        double CarMin(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Min();

        // Walls: marks 2 (left then right), 9 (right), 10 (left), 14 (left).
        var walls = new[] { 11.14, 12.91, 57.82, 59.27, 77.99 };
        var sides = new[] { -1.0, 1, 0, -1, -1 }; // the game gave no side at the right-hand wall at mark 9
        var hits = r.Events("wall_hit", 0, 0.5);
        check(hits.Count == 5 && hits.Zip(walls, (a, b) => Math.Abs(a - b) < 0.05).All(x => x), "wall_hit at the five walls only: " + Times(hits));
        for (int i = 0; i < walls.Length; i++)
            check(r.At("wall_side", walls[i] + 0.1) == sides[i], $"wall_side {sides[i]} at {F(walls[i])}: {r.At("wall_side", walls[i] + 0.1)}");
        check(r.Out["wall_side"].All(x => x.v == 0 || r.At("wall_hit", x.t) == 1), "wall_side only while wall_hit");

        // Every hit, walls and traffic, gives Car_impact; braking and drifts don't.
        var traffic = new[] { 30.17, 38.32, 49.62, 76.64, 80.9, 86.1 }; // bus, small, small, small (scrape), midsize, semi
        foreach (var t in walls.Concat(traffic))
            check(CarMax("impact", t - 0.3, t + 0.5) >= 0.5, $"Car_impact at the hit at {F(t)}: {F(CarMax("impact", t - 0.3, t + 0.5))}");
        foreach (var t in new[] { 19.4, 41.7, 42.7, 71.0 })
            check(CarMax("impact", t - 0.5, t + 0.5) == 0, $"no Car_impact under hard braking at {F(t)}");
        check(CarMax("impact", 46.0, 49.0) == 0, "no Car_impact in the long drift (marks 5 to 6)");
        // The speed reading dips at 20 to 26 G as some drifts start (after the bus at 31.5, and at 44.0 and 60.7 s).
        foreach (var t in new[] { 31.5, 44.0, 60.7 })
            check(CarMax("impact", t - 0.1, t + 0.4) == 0, $"no Car_impact at the drift dip at {F(t)}");
        var imp = r.Car["impact"].Where(x => x.v > 0).Select(x => x.t).ToList();
        var known = walls.Concat(traffic).ToList();
        var stray = imp.Where(t => !known.Any(k => t > k - 0.6 && t < k + 1.0)).ToList();
        check(stray.Count == 0, "Car_impact only at the noted hits: stray at " + Times(stray.Where((t, i) => i == 0 || t - stray[i - 1] > 0.05)));
        check(CarMin("impact_side", 11.1, 11.5) == -1 && CarMax("impact_side", 12.9, 13.3) == 1, "Car_impact_side left then right at mark 2");

        // Surfaces.
        check(r.Max("off_road", 8.8, 9.7) == 1 && r.Max("rumble_strip", 8.2, 8.7) == 1, "sand centre strip at mark 2 (with its edge)");
        check(r.Max("rumble_strip", 53.3, 54.2) == 1 && r.Max("off_road", 53.0, 55.0) == 0, "striped verge at mark 8");
        check(r.Max("off_road", 59.13, 59.3) == 1, "grass just before the wall at mark 10");
        check(r.Max("off_road", 65.2, 66.5) == 1 && r.Max("off_road", 73.3, 74.0) == 1, "grass verges after mark 11");
        check(CarMax("off_road", 65.2, 66.5) == 1 && CarMax("rumble_strip", 53.3, 54.2) == 1, "Car_off_road and Car_rumble_strip");
        check(r.Max("off_road", 20, 50) == 0, "no off_road on the road (20 to 50 s)");

        // Timer, checkpoint, gear, revs.
        var cp = r.Events("checkpoint", 0, 1.5);
        check(cp.Count == 1 && Math.Abs(cp[0] - 74.56) < 0.05, "checkpoint once, at 74.56 (mark 12 at 74.22): " + Times(cp));
        check(Math.Abs(r.At("time_left", 1.0) - 5999 / 60.0) < 0.1, "time_left starts at 100 s: " + F(r.At("time_left", 1.0)));
        check(r.Min("gear", 0, r.End) == 1 && r.Max("gear", 0, r.End) == 5, "gear 1 to 5");
        double revs = r.Car["rpm"].Max(x => x.v);
        check(revs > 9000 && revs < 10000, "Car_rpm is real revs (the game stores RPM / 10): top " + revs.ToString("0", CultureInfo.InvariantCulture));
        check(r.Car["rpm"].Where(x => x.t < 3).Min(x => x.v) > 1000, "idle about 1600 rpm");

        Console.WriteLine($"OR2 replay 15:38: walls {Times(hits)}; Car_impact at hits {string.Join(", ", known.Select(t => F(CarMax("impact", t - 0.3, t + 0.5))))}; top revs {revs:0}");
    }

    static void Extra(Action<bool, string> check, Replay r)
    {
        var walls = new[] { 34.5, 63.95, 65.4, 66.95, 99.8 };
        var hits = r.Events("wall_hit", 0, 0.5);
        check(hits.Count == 5 && hits.Zip(walls, (a, b) => Math.Abs(a - b) < 0.05).All(x => x), "15:30: wall_hit at five walls: " + Times(hits));
        var cp = r.Events("checkpoint", 0, 1.5);
        check(cp.Count == 1 && Math.Abs(cp[0] - 73.7) < 0.05, "15:30: one checkpoint, at 73.7: " + Times(cp));
        double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        foreach (var t in walls.Concat(new[] { 38.57, 55.15, 63.12, 75.0, 83.24, 93.04 }))
            check(CarMax("impact", t - 0.3, t + 0.5) >= 0.5, $"15:30: Car_impact at {F(t)}");
        Console.WriteLine($"OR2 replay 15:30: walls {Times(hits)}; Car_impact spans {r.Spans("wall_hit")}");
    }

    static void Third(Action<bool, string> check, Replay r)
    {
        var m = r.Marks;
        check(m.Count == 4, "4 markers in the 17:45 recording: " + m.Count);
        double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        double CarMin(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Min();

        check(r.Max("transmission", 0, r.End) == 0, "transmission 0 on automatic (1 on manual in the other two)");
        var hits = r.Events("wall_hit", 0, 0.5);
        check(hits.Count == 2 && Math.Abs(hits[0] - 30.12) < 0.05 && Math.Abs(hits[1] - 80.02) < 0.05, "wall_hit at 30.12 and 80.02 (the flip): " + Times(hits));
        // At the flip side_hit_dir came two samples after the hit started, and only for one sample.
        check(r.At("wall_side", 30.2) == -1 && r.At("wall_side", 80.1) == -1, "wall_side left at both walls");
        check(CarMin("impact_side", 80.0, 80.4) == -1, "Car_impact_side left at the flip");
        check(CarMax("impact", 80.0, 80.3) >= 0.5, "Car_impact at the wall where the car flips");
        // The speed reading freezes for 0.5 s, then falls from 411 to 101 in 0.07 s: the big hit, as on every wall but bigger.
        check(CarMax("impact", 80.5, 80.7) == 1, "Car_impact 1 when the speed falls after the flip");
        // At 82.57 s the game puts the car back on the track at 0: not a hit.
        check(r.Max("hard_hit", 82.4, r.End) == 0 && CarMax("impact", 82.4, r.End) == 0, "no hit when the car is put back at 0 speed");
        check(r.Max("gear", 80.40, 80.43) == 5 && r.At("gear", 80.5) == 1, "gear drops 5 to 1 after the flip (automatic)");
        var cp = r.Events("checkpoint", 0, 1.5);
        check(cp.Count == 1 && Math.Abs(cp[0] - 63.62) < 0.05, "17:45: one checkpoint, at 63.62: " + Times(cp));
        check(Math.Abs(r.Car["speed_frac"].Max(x => x.v) - 1) < 1e-9 && r.Max("speed", 70, 79) > 1.0, "speed passes Max speed (400 units, about 280 km/h) near the top");
        Console.WriteLine($"OR2 replay 17:45: walls {Times(hits)}; Car_impact {r.Spans("wall_hit")} / {r.Spans("hard_hit")}");
    }

    /// <summary>20:48 (3 November), 89 s, manual, USB capture on: 1 across the sand centre divider; 2 the rear of a
    /// truck or bus; 3 a hit; 4 the wall where the car flips (the same place as at 17:45).</summary>
    static void Fourth(Action<bool, string> check, Replay r)
    {
        var m = r.Marks;
        check(m.Count == 4, "4 markers in the 20:48 recording: " + m.Count);
        double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        double CarMin(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Min();
        // 1: the sand divider. No hit; the wheel force's kicks there are the road bump (from USB: OR2 has no row for it).
        check(r.Max("off_road", 11.4, 12.0) == 1 && CarMax("impact", 10, 13) == 0, "mark 1: sand (off road), not a hit");
        check(CarMax("road_bump", 11.4, 12.2) > 0.5 && CarMax("road_bump", 13, 39) < 0.3, "mark 1: Car_road_bump from the USB force on the sand; only small ones from gear-change sines (13 to 39 s): " + F(CarMax("road_bump", 11.4, 12.2)) + " / " + F(CarMax("road_bump", 13, 39)));
        // Hits: 2 the truck or bus (28.84, the hard hit 281 to 197 km/h), 3 at 45.14, two unmarked traffic hits, 4 the wall.
        var crash = r.Events("crash", 0, 0.5);
        check(crash.Count == 4 && crash.Zip(new[] { 28.84, 40.20, 45.14, 49.77 }, (a, b) => Math.Abs(a - b) < 0.05).All(x => x), "crashes at 28.84, 40.20, 45.14, 49.77: " + Times(crash));
        check(CarMax("impact", 28.8, 29.3) == 1 && CarMax("impact", 45.1, 45.5) >= 0.5, "Car_impact at marks 2 (1, the big vehicle) and 3");
        // The FFB plugin pushes the wheel only for side-on hits: none at the rear-end hits (2, 3), so they have no side.
        check(CarMax("impact_side", 28.7, 29.3) == 0 && CarMin("impact_side", 28.7, 29.3) == 0 && CarMax("impact_side", 45.0, 45.5) == 0 && CarMin("impact_side", 45.0, 45.5) == 0,
              "rear-end hits: no side");
        check(CarMin("impact_side", 40.1, 40.6) == -1 && CarMax("impact_side", 49.7, 50.2) == 1, "unmarked traffic hits: sides from the USB force (-1 at 40.20, +1 at 49.77)");
        // 4: the wall where the car flips. The game gave no side this time; the wheel got a full push from the left.
        var walls = r.Events("wall_hit", 0, 0.5);
        check(walls.Count == 1 && Math.Abs(walls[0] - 84.77) < 0.05 && r.Max("wall_side", 84.7, 85.2) == 0 && r.Min("wall_side", 84.7, 85.2) == 0, "mark 4: wall hit at 84.77 with no side from the game: " + Times(walls));
        check(r.Min("usb_force", 84.7, 84.9) < -0.75 && CarMin("impact_side", 84.7, 85.1) == -1 && CarMax("impact_side", 84.7, 85.1) == 0,
              "mark 4: Car_impact_side -1 (left) from the USB force, as at the flip on 2 November");
        check(CarMax("impact", 85.3, 85.7) == 1, "Car_impact 1 when the speed falls after the flip");
        check(r.Car["cornering"].All(x => x.v == 0), "Car_cornering stays 0 (the 0 row): the hook sends no steering force");
        check(r.Car["usb"].Max(x => x.v) == 1, "Car_usb 1: values filled from the wheel force");
        Console.WriteLine($"OR2 replay 20:48: crashes {Times(crash)}; wall {Times(walls)}; sides " +
                          string.Join(", ", new[] { 28.9, 40.25, 45.2, 49.8, 84.8 }.Select(t => F(CarMin("impact_side", t - 0.1, t + 0.3) + CarMax("impact_side", t - 0.1, t + 0.3)))));
    }
}
