using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Ffb;
using TeknoTelemetry.Core.TeknoParrot;
using Replay = Wmmt5ReplayTests.Replay;

/// <summary>
/// Alexis's GRID recording under TeknoParrot (3 November 2026, 20:21), FFB plugin in its Custom mode and the G25
/// captured over USB. Her marks: 1 driver view, revs maxed; 2 race start; 3 RHS wall at about 257 km/h (26.9 s);
/// RHS wall about 42 to 43 s; 4 car on her right (55.7); 5 LHS wall (59.8); 6 RHS wall (61.6); 7 right turn, no
/// hit (74.5), then a LHS wall at 254 km/h; 8 RHS wall (97.2); 9 scraping a wall (97.7); 10 gentle left (105.1);
/// 11 rear of a car (110.0); 12 a touch or the kerb (111.6). The USB force replays through the common values.
/// </summary>
static class GridReplayTests
{
    static readonly string[] Extra = { "usb_force", "usb_rumble", "usb_steer", "usb_throttle", "usb_brake", "rec_Car_rpm", "rec_Car_impact", "rec_Car_impact_side", "rec_Car_gear" };

    static Replay Run(Action<bool, string> check, string path, string fixture)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = "";

        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);

        var tp = new double[TpChannels.Count];
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            TpSource = a => Array.Copy(tp, a, a.Length),
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "GRID" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), "GRID rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));

        var rp = new Replay { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()) };
        foreach (var x in Extra) rp.Out[x] = new List<(double t, double v)>();
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        ps.Connected = true;
        int tc = Col("time_s"), mc = Col("marker");
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(kv.Key));
        // the dial rows came later (4 November, from Alexis's Cheat Engine work): older recordings don't have them
        var later = new HashSet<string> { "speed", "rpm", "rpm2", "rev_frac", "throttle", "shift_lights", "distance", "dial_294", "tacho_scale" };
        // and the rows from the game's code (12 November 2026, checked in her recordings that day), and raw reads not yet recorded
        foreach (var n in new[] { "brake", "race_on", "race_over", "race_clock", "race_laps", "car0_laps", "car0_lap_time", "steer" }) later.Add(n);
        foreach (var v in prof.Variables.Where(v => (v.Notes ?? "").StartsWith("Raw"))) later.Add(v.Name);
        check(cols.Where(c => !later.Contains(c.Key)).All(c => c.Value >= 0), "the recording has every memory row: " + string.Join(", ", cols.Where(c => c.Value < 0 && !later.Contains(c.Key)).Select(c => c.Key)));
        var slots = Enumerable.Range(0, TpChannels.SlotCount).Select(i => Col("tp_jvs" + i)).ToArray();
        int conn = Col("tp_connected");
        var extra = Extra.ToDictionary(x => x, Col);
        var ffb = ps.Ctx.Ffb;
        check(ffb != null && ffb.Length > FfbChannels.Connected, "the profile has FFB channels to replay the USB force into");
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            if (r[mc] != "") rp.Marks.Add(t);
            foreach (var kv in feeds) kv.Value.Value = Num(r, cols[kv.Key]);
            for (int i = 0; i < slots.Length; i++) tp[i] = Num(r, slots[i]);
            tp[TpChannels.Connected] = Num(r, conn);
            ffb[FfbChannels.Connected] = 1;
            ffb[FfbChannels.Force] = Num(r, extra["usb_force"]);
            ffb[FfbChannels.Rumble] = Num(r, extra["usb_rumble"]);
            eng.TpSource(ps.Ctx.Tp);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            foreach (var x in Extra) rp.Out[x].Add((t, Num(r, extra[x])));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            rp.End = t;
        }
        return rp;
    }

    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "GRID");
        if (gamePackDir == null || !File.Exists(path)) return;
        // Revs from memory (Alexis's Cheat Engine table, 4 November 2026): two chains, Max revs 6900, no OutputBlaster.
        var prof = ProfileStore.ReadProfile(path);
        var rpm = prof.Variables.FirstOrDefault(v => v.Name == "rpm"); var rpm2 = prof.Variables.FirstOrDefault(v => v.Name == "rpm2");
        check(rpm != null && rpm.Source == SourceKind.Memory && rpm.BaseOffset == "B1B100" && rpm.Offsets.Replace(" ", "") == "200,120,284" && rpm.Type == MemType.Float,
              "GRID rpm: GRID.exe+B1B100 -> 200 -> 120 -> 284, a float");
        check(rpm2 != null && rpm2.BaseOffset == "41CA50" && rpm2.Offsets.Replace(" ", "") == "2B8,8,5E0", "GRID rpm2: GRID.exe+41CA50 -> 2B8 -> 8 -> 5E0");
        check(prof.MaxRevs == 6900 && !prof.Variables.Any(v => (v.Formula ?? "").Contains("out_")), "Max revs 6900; nothing needs OutputBlaster");
        // From GRID.exe (12 November 2026): the brake beside the throttle on the dial, and the race (dial +210 -> the HUD, +1F8 -> the
        // race, +21A0 -> its race clock object at +F8) and steering (dial +258 -> the car physics), checked in her recordings of
        // 12 November and ticked; the damage block read nothing (the arcade build has no damage: Alexis), so it is gone.
        var brake = prof.Variables.FirstOrDefault(v => v.Name == "brake");
        check(brake != null && brake.Enabled && brake.BaseOffset == "B1B100" && brake.Offsets.Replace(" ", "") == "200,120,280" && brake.Type == MemType.Float,
              "GRID brake: the dial's +280, ticked");
        foreach (var (rn, chain, t) in new[] { ("race_on", "200,120,210,1F8,21A0,108", MemType.Byte), ("race_over", "200,120,210,1F8,21A0,109", MemType.Byte),
                                               ("race_clock", "200,120,210,1F8,21A0,120", MemType.Int64), ("race_laps", "200,120,210,1F8,21A0,10C", MemType.Int32),
                                               ("car0_laps", "200,120,210,1F8,21A0,178", MemType.Int32), ("steer", "200,120,258,E30", MemType.Float) })
        {
            var v = prof.Variables.FirstOrDefault(x => x.Name == rn);
            check(v != null && v.Enabled && !(v.Notes ?? "").StartsWith("Raw") && v.BaseOffset == "B1B100" && v.Offsets.Replace(" ", "") == chain && v.Type == t,
                  $"GRID {rn}: ticked, GRID.exe+B1B100 -> {chain}");
        }
        check(!prof.Variables.Any(v => v.Name.StartsWith("dmg_") || v.Name == "steer_in"), "GRID: no damage rows, steer_in now steer");
        // From GRID.exe (16 November 2026), unticked raw reads for the next recording: the race position list (HUD +C0 -> +4) and the game mode.
        foreach (var (rn, chain) in new[] { ("place0", "200,120,210,C0,4,74"), ("me", "200,120,210,C0,4,170"), ("game_mode", "200,120,210,1F8,21C4,10,48,0,C,54") })
        {
            var v = prof.Variables.FirstOrDefault(x => x.Name == rn);
            check(v != null && !v.Enabled && (v.Notes ?? "").StartsWith("Raw") && v.BaseOffset == "B1B100" && v.Offsets.Replace(" ", "") == chain && v.Type == MemType.Int32,
                  $"GRID {rn}: unticked raw read, GRID.exe+B1B100 -> {chain}");
        }
        var cir = prof.Variables.FirstOrDefault(v => v.Name == "car_in_race");
        check(cir != null && cir.Formula == "racing", "GRID: Car_in_race is racing");
        check(prof.Variables.Where(v => v.Name.StartsWith("car_") && v.Name != "car_in_race" && v.Name != "car_hit" && v.Name != "car_contact" && v.Formula != "0")
                  .All(v => v.Formula.StartsWith("racing ? (")), "GRID: every other common value reads 0 outside a race (Alexis, 16 November 2026)");
        double ms = prof.MaxSpeed ?? 1;
        check(ms == 280, "Max speed 280 (Alexis, 4 November 2026: a middle for the car classes)");
        var a = Run(check, path, "grid-20261103-202137.csv.gz");
        string F(double v) => v.ToString("0.00", CultureInfo.InvariantCulture);
        double CarMax(string n, double t0, double t1) => a.Car[n].Where(x => x.t >= t0 && x.t <= t1).Select(x => x.v).DefaultIfEmpty(0).Max();
        double CarMin(string n, double t0, double t1) => a.Car[n].Where(x => x.t >= t0 && x.t <= t1).Select(x => x.v).DefaultIfEmpty(0).Min();

        check(a.Marks.Count == 13, "13 marks: " + a.Marks.Count);
        // The old wheel speed (now wheel_speed): peaks at 236 on the straight before mark 8. The old gear (now gear_abs) is one
        // less than the dial's: 0 (1st) at the start, up to 5 (6th). The fixture's gear column is gear_abs + 1.
        check(Math.Abs(a.Max("wheel_speed", 74, 97) - 236) < 1, "wheel speed top about 236: " + F(a.Max("wheel_speed", 74, 97)));
        check(a.Max("gear_abs", 0, 13.5) == 0 && a.Max("gear_abs", 20, 100) == 5 && a.Max("gear", 20, 100) == 6, "gear_abs 0 to 5, the dial's gear 1 to 6");

        // Wall hits: the side of each one Alexis marked (+ right).
        foreach (var (t0, t1, side, what) in new[] { (26.8, 27.7, 1, "mark 3, RHS wall"), (42.8, 43.3, 1, "RHS wall at 42 to 43 s"), (59.7, 60.5, -1, "mark 5, LHS wall"),
                                                     (61.3, 62.2, 1, "mark 6, RHS wall"), (95.5, 96.3, -1, "LHS wall at 254 km/h"), (96.4, 97.9, 1, "mark 8, RHS wall") })
        {
            check(CarMax("impact", t0, t1) >= 0.25, $"Car_impact at the {what}: {F(CarMax("impact", t0, t1))}");
            double s = side > 0 ? CarMax("impact_side", t0, t1) : CarMin("impact_side", t0, t1);
            check(s == side, $"Car_impact_side {side} at the {what}");
        }
        check(Math.Abs(CarMax("impact", 96.4, 97.9) - 0.75) < 0.01, "the hardest hit (mark 8, 202 to 86 km/h) reads 6 of 8");

        // The USB force is what the FFB plugin's Custom mode works out: the wall force (hit_strength / 8 by
        // wall_side) a poll later, and a 0.49 sine at each gear change.
        var x = a.Out["impact_side"].Select(p => p.v).ToList(); var u = a.Out["usb_force"].Select(p => p.v).ToList();
        int n = 0, ok = 0;
        for (int i = 0; i + 1 < x.Count; i++) if (x[i] != 0) { n++; if (Math.Abs(u[i + 1] - x[i]) < 0.02) ok++; }
        check(n > 800 && ok > 0.93 * n, $"impact_side is the USB force a poll later in {ok} of {n} hit frames");
        var g = a.Out["gear"]; var shifts = Enumerable.Range(1, g.Count - 1).Where(i => g[i].v != g[i - 1].v && !double.IsNaN(g[i - 1].v)).Select(i => g[i].t).ToList();
        int sine = shifts.Count(t => a.Out["usb_force"].Where(p => p.t >= t - 0.05 && p.t <= t + 0.15).Any(p => Math.Abs(p.v) > 0.45));
        check(shifts.Count >= 30 && sine >= shifts.Count - 1, $"a gear-change sine on the wheel at {sine} of {shifts.Count} gear changes");

        // The force is only hits, gear changes and kerbs: the 0 rows keep it out of road bumps and cornering.
        check(CarMax("road_bump", 0, a.End) == 0 && CarMax("cornering", 0, a.End) == 0 && CarMin("cornering", 0, a.End) == 0,
              "Car_road_bump and Car_cornering stay 0 with the USB force on");
        Console.WriteLine($"GRID replay 3 Nov: wheel speed top {F(a.Max("wheel_speed", 0, a.End))}; USB force matches the hit force in {ok} of {n} frames; sines at {sine} of {shifts.Count} gear changes");
        Fourth(check, Run(check, path, "grid-20261104-101302.csv.gz"));
        Dial(check, Run(check, path, "grid-20261104-131502.csv.gz"), Run(check, path, "grid-20261104-131816.csv.gz"), Run(check, path, "grid-20261104-133227.csv.gz"));
        Twelfth(check, Run(check, path, "grid-20261112-120036.csv.gz"));
    }

    /// <summary>12 November 2026, 12:00 (the 12 November pack, USB capture), in the game's own units: attract mode, coins, menus;
    /// race 1 (GO 71.08 s) with a hard brake twice, a 5 s pause (113.3 to 118.5 s, TT 0:42.23), a hard LHS wall hit, then TIME OVER at
    /// 174.03 s (TT 1:39.15); menus; race 2 (GO 239.41 s), three laps, finished 2nd at 438.21 s (TT 3:18.77 on screen); menus,
    /// attract mode. Alexis's answers (16 November 2026): pause screen 0:42.21, finish 3:18.77, laps 2 and 3 0:59.42 and 1:02.33.</summary>
    static void Twelfth(Action<bool, string> check, Replay r)
    {
        string F(double v) => v.ToString("0.00", CultureInfo.InvariantCulture);
        string Sp(string n) => r.Spans(n);
        // racing: GO to the pause, the pause's end to TIME OVER, GO to the finish line; never in the attract mode or menus
        var on = r.Events("racing", 0, 0.02);
        var off = r.Out["racing"].Zip(r.Out["racing"].Skip(1), (p, q) => (p, q)).Where(x => x.p.v == 1 && x.q.v == 0).Select(x => x.q.t).ToList();
        bool Near(IList<double> xs, params double[] want) => xs.Count == want.Length && xs.Zip(want, (a, b) => Math.Abs(a - b) < 0.15).All(x => x);
        check(Near(on, 71.08, 118.53, 239.41), "racing starts at GO, after the pause and at GO: " + Sp("racing"));
        check(Near(off, 113.40, 174.03, 438.21), "racing ends at the pause, TIME OVER and the finish line: " + Sp("racing"));
        check(r.Car["in_race"].Zip(r.Out["racing"], (p, q) => p.v == q.v).All(x => x), "Car_in_race is racing");
        // every other common value reads 0 outside a race (Alexis, 16 November 2026): the revs idled in the menus before
        foreach (var n in new[] { "speed", "rpm", "gear", "accel_g", "impact", "rpm_frac", "throttle" })
            check(r.Car[n].Where(x => r.At("racing", x.t) == 0).All(x => x.v == 0), $"Car_{n} 0 outside a race");
        check(r.Out["rpm"].Where(x => x.t > 55 && x.t < 66).All(x => x.v * 6900 > 600) && r.Car["rpm"].Where(x => x.t > 55 && x.t < 66).All(x => x.v == 0),
              "the revs idle on the grid (rpm row) while Car_rpm reads 0");
        // the race clock is the TT on screen: 42.235 through the pause (her pause screen: 0:42.21); held at TIME OVER and the finish
        check(Math.Abs(r.At("race_clock", 116) - 42.235) < 0.005 && Math.Abs(r.At("race_clock", 180) - 99.151) < 0.005, $"race clock 42.235 paused, 99.151 at TIME OVER: {F(r.At("race_clock", 116))}, {F(r.At("race_clock", 180))}");
        check(Math.Abs(r.At("car0_lap_time", 445) - 198.777) < 0.005, "the player's race time held at the finish: 3:18.777 (3:18.77 on screen)");
        // laps: 1 to 3, the lap line at each line and the finish, the final lap from the second line
        check(r.At("lap", 300) == 1 && r.At("lap", 320) == 2 && r.At("lap", 380) == 3 && r.At("final_lap", 380) == 1 && r.At("final_lap", 320) == 0, "laps 1, 2, 3; final lap on the third");
        check(Near(r.Events("lap_line", 0, 0.5), 316.43, 375.87, 438.21), "lap_line at the two lap lines and the finish: " + Sp("lap_line"));
        // steering + right, from the wheel itself; the brake follows the pedal
        double Corr(IList<double> x, IList<double> y) { double mx = x.Average(), my = y.Average(), sxy = 0, sxx = 0, syy = 0; for (int i = 0; i < x.Count; i++) { sxy += (x[i] - mx) * (y[i] - my); sxx += (x[i] - mx) * (x[i] - mx); syy += (y[i] - my) * (y[i] - my); } return sxy / Math.Sqrt(sxx * syy); }
        var race = r.Out["racing"].Select((x, i) => (x.v, i)).Where(x => x.v == 1).Select(x => x.i).ToList();
        double cs = Corr(race.Select(i => r.Out["steer"][i].v).ToList(), race.Select(i => r.Out["usb_steer"][i].v).ToList());
        double cb = Corr(race.Select(i => r.Out["brake"][i].v).ToList(), race.Select(i => r.Out["usb_brake"][i].v).ToList());
        check(cs > 0.9, $"steer follows the G25's steering, + right (correlation {F(cs)})");
        check(cb > 0.9, $"brake follows the G25's brake pedal (correlation {F(cb)})");
        Console.WriteLine($"GRID replay 12 Nov 12:00: racing {Sp("racing")}; steer {F(cs)}, brake {F(cb)}; lap lines {Sp("lap_line")}");
    }

    /// <summary>4 November 2026, 10:13 (plugin 0.16.0, revs rows, USB capture): 1 the race start (the revs were already
    /// at the limiter from 6.4 s); RHS wall, contact on her left with a car, LHS wall (21 to 23 s); 2 about 100 km/h;
    /// 3 about 148 km/h. The recording has the Car_ values SimHub got, so the replay is checked against them.</summary>
    static void Fourth(Action<bool, string> check, Replay r)
    {
        string F(double v) => v.ToString("0.00", CultureInfo.InvariantCulture);
        double CarMax(string n, double t0, double t1) => r.Car[n].Where(x => x.t >= t0 && x.t <= t1).Select(x => x.v).DefaultIfEmpty(0).Max();
        double CarMin(string n, double t0, double t1) => r.Car[n].Where(x => x.t >= t0 && x.t <= t1).Select(x => x.v).DefaultIfEmpty(0).Min();
        check(r.Marks.Count == 3 && Math.Abs(r.Marks[0] - 10.63) < 0.05, "3 marks, the first at the start (10.63): " + string.Join(", ", r.Marks.Select(F)));
        // Revs: 1000 before the start, the limiter at 7500 for this car (it bounces 7500, 7113, 6727), never 0.
        check(r.Min("rpm", 0, 6.3) * 6900 > 999 && r.Max("rpm", 0, 6.3) * 6900 < 1001, "revs 1000 before the start");
        check(Math.Abs(r.Max("rpm", 6.3, 10.4) * 6900 - 7500) < 1 && r.Out["rpm"].All(x => x.v * 6900 > 990), "limiter 7500 for this car, revs never 0: " + F(r.Max("rpm", 6.3, 10.4) * 6900));
        // The two revs chains agree (they differ only when the game writes between the two reads).
        int same = r.Out["rpm"].Zip(r.Out["rpm2"], (p, q) => Math.Abs(p.v - q.v) * 6900 < 1).Count(x => x);
        check(same > r.Out["rpm"].Count - 20, $"rpm and rpm2 agree in {same} of {r.Out["rpm"].Count} samples");
        // The replay gives what SimHub got live.
        foreach (var n in new[] { "rpm", "impact", "impact_side", "gear" })
        {
            var live = r.Out["rec_Car_" + n]; var rep = r.Car[n];
            // Car_gear was the old gear then, one less than the dial's gear that feeds it now
            int diff = live.Zip(rep, (p, q) => Math.Abs(p.v + (n == "gear" ? 1 : 0) - q.v) > (n == "rpm" ? 0.05 : 1e-3)).Count(x => x);   // the recording keeps 6 decimals of rpm / 6900
            check(diff <= 2, $"replayed Car_{n} matches the recording's ({diff} samples differ)");
        }
        // 21 to 23 s: RHS wall, a car on her left, then the LHS wall: both sides read.
        check(CarMax("impact_side", 21.0, 21.2) == 1 && CarMin("impact_side", 21.2, 23.1) == -1, "RHS wall then contact and LHS wall: sides +1 then -1");
        var x = r.Out["impact_side"].Select(p => p.v).ToList(); var u = r.Out["usb_force"].Select(p => p.v).ToList();
        int n2 = 0, ok = 0;
        for (int i = 0; i + 1 < x.Count; i++) if (x[i] != 0) { n2++; if (Math.Abs(u[i + 1] - x[i]) < 0.05) ok++; }
        check(n2 > 900 && ok > 0.9 * n2, $"10:13: the USB force is impact_side a poll later in {ok} of {n2} hit frames (the rest: the first and last frame of a hit, or a gear-change sine on top)");
        check(r.Max("car_contact", 84.8, 85.8) == 3, "car_contact counts contacts: 3 at 85.3 s");
        Console.WriteLine($"GRID replay 4 Nov 10:13: limiter {F(r.Max("rpm", 6.3, 10.4) * 6900)}; USB {ok} of {n2}; wheel speed top {F(r.Max("wheel_speed", 0, r.End))}");
    }

    /// <summary>4 November 2026, 13:15 to 13:32, with the dial rows (speed, gear, rev_frac, throttle, shift lights):
    ///  * 13:15, fastest class (limiter 8000): 1 driver view, revving; 2 start; on the limiter in 1st at about 95 km/h;
    ///    3 2nd at 156; 4 3rd at 211; RHS then LHS wall; 5 and 6 4th at 265; 7 a car on her front left; 8 about 95.
    ///  * 13:18, the same car in reverse: 61 km/h at most.
    ///  * 13:32, another car (limiter 8200): 1 driver view, revving; 2 start; 138 on the limiter in 2nd, 196 in 3rd.</summary>
    static void Dial(Action<bool, string> check, Replay a, Replay rv, Replay b)
    {
        string F(double v) => v.ToString("0.00", CultureInfo.InvariantCulture);
        double At(Replay r, string n, double t) => r.Car[n].First(x => x.t >= t).v;
        foreach (var (t, kmh, gear, what) in new[] { (30.0, 156.0, 2, "mark 3"), (34.5, 211.0, 3, "mark 4"), (72.5, 265.0, 4, "mark 5"), (75.0, 265.0, 4, "mark 6") })
        {
            check(Math.Abs(At(a, "speed", t) - kmh) < 2, $"13:15 {what}: Car_speed {F(At(a, "speed", t))} km/h where the speedo showed {kmh}");
            check(At(a, "gear", t) == gear, $"13:15 {what}: gear {At(a, "gear", t)}, {gear} as noted");
        }
        check(At(a, "gear", 25.5) == 1 && Math.Abs(At(a, "rpm", 25.5) - 8000) < 1, "13:15: 1st gear on the limiter (8000) at 25.5 s");
        // rev_frac is revs / the car's limiter, and never passes 1; Car_rpm_frac follows it, not revs / Max revs (6900).
        check(a.Max("rev_frac", 0, a.End) == 1 && b.Max("rev_frac", 0, b.End) == 1, "rev_frac stops at 1.0 at the limiter");
        check(Math.Abs(a.At("rev_max", 110) - 8000) < 1 && Math.Abs(b.At("rev_max", 38) - 8200) < 1, $"rev_max: 8000 (fastest class), 8200 (13:32 car): {F(a.At("rev_max", 110))}, {F(b.At("rev_max", 38))}");
        int same = a.Car["rpm_frac"].Zip(a.Out["rev_frac"], (p, q) => Math.Abs(p.v - Math.Max(0, Math.Min(1, q.v))) < 1e-9).Count(x => x);
        check(same > a.Car["rpm_frac"].Count - 5, $"Car_rpm_frac is rev_frac ({same} of {a.Car["rpm_frac"].Count})");
        check(Math.Abs(At(a, "rpm_frac", 30.0) - 0.9) < 0.01 && At(a, "rpm", 30.0) > 6900, "7200 revs in the 8000 car: Car_rpm_frac 0.9, where revs / Max revs would read 1");
        check(a.Car["rev_limit"].Where(x => x.t > 73 && x.t < 75.5).Any(x => x.v == 1), "rev limiter effect on the 8000 car's limiter (4th, 265 km/h)");
        // The other car: 1st on the limiter at 83 km/h, 2nd at 138, 3rd at 196.
        check(At(b, "gear", 18.0) == 1 && Math.Abs(At(b, "rpm", 18.0) - 8200) < 1, "13:32: 1st gear on the 8200 limiter");
        check(Math.Abs(At(b, "speed", 28.5) - 138) < 2 && At(b, "gear", 28.5) == 2, $"13:32: 138 km/h in 2nd: {F(At(b, "speed", 28.5))}");
        check(Math.Abs(b.Car["speed"].Where(x => x.t > 36 && x.t < 39).Max(x => x.v) - 196) < 2 && At(b, "gear", 37.5) == 3, "13:32: 196 km/h in 3rd");
        // Reverse: gear -1 (the game stores 9), speed + up to 61 km/h.
        check(rv.Min("gear", 1.5, 6.5) == -1 && rv.Max("gear", 1.5, 6.5) == -1, "13:18: gear -1 in reverse");
        double rmax = rv.Car["speed"].Where(x => x.t < 7.5).Max(x => x.v);
        check(Math.Abs(rmax - 61) < 1.5 && rv.Car["speed"].All(x => x.v >= 0), $"13:18: up to 61 km/h in reverse, never negative: {F(rmax)}");
        // Throttle as the game uses it, the shift lights, and a speed smooth enough for G.
        double Corr(IList<double> x, IList<double> y) { double mx = x.Average(), my = y.Average(), sxy = 0, sxx = 0, syy = 0; for (int i = 0; i < x.Count; i++) { sxy += (x[i] - mx) * (y[i] - my); sxx += (x[i] - mx) * (x[i] - mx); syy += (y[i] - my) * (y[i] - my); } return sxy / Math.Sqrt(sxx * syy); }
        double ct = Corr(b.Out["throttle"].Select(x => x.v).ToList(), b.Out["usb_throttle"].Select(x => x.v).ToList());
        check(ct > 0.99 && b.Car["throttle"].Max(x => x.v) == 1, $"throttle follows the pedal (correlation {F(ct)}) and feeds Car_throttle");
        var hi = a.Out["shift_lights"].Zip(a.Out["rev_frac"], (p, q) => (p.v, q.v)).Where(x => x.Item2 > 0.98).ToList();
        var lo = a.Out["shift_lights"].Zip(a.Out["rev_frac"], (p, q) => (p.v, q.v)).Where(x => x.Item2 < 0.6).ToList();
        check(hi.Count(x => x.Item1 >= 1) > 0.9 * hi.Count && lo.Count(x => x.Item1 == 0) > 0.99 * lo.Count,
              $"shift lights on at the limiter ({hi.Count(x => x.Item1 >= 1)} of {hi.Count}), off below 60% ({lo.Count(x => x.Item1 == 0)} of {lo.Count}; they lag a moment after an upshift)");
        check(a.Max("accel_g", 22, 36) < 3 && a.Max("accel_g", 40, 110) < 3, "no G spikes speeding up (the dial speed is smooth)");
        check(a.Min("accel_g", 37, 39.5) < -3, "the wall hit at 37 to 39 s reads as hard slowing");
        Console.WriteLine($"GRID replay 4 Nov 13:15/13:18/13:32: speeds {F(At(a, "speed", 30))}, {F(At(a, "speed", 34.5))}, {F(At(a, "speed", 72.5))}; reverse {F(rmax)}; limiters {F(a.At("rev_max", 110))}, {F(b.At("rev_max", 38))}");
    }
}
