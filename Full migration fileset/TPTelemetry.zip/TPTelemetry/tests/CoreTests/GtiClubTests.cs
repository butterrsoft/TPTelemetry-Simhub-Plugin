// GTI Club Supermini Festa (GTICLUB3): the rows found in the game's code (8 November 2026). A made-up race checks the
// formulas do what their notes say (gating, laps, checkpoint), then Alexis's recording (8 November 2026, 18:25, intermediate
// course, manual, 3 laps) replays through the real engine: her landings, car hits, walls, the barrier crash and kerbs.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;
using Replay = Wmmt5ReplayTests.Replay;

static class GtiClubTests
{
    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "GTICLUB3");
        if (gamePackDir == null || !File.Exists(path)) return;
        var prof = ProfileStore.ReadProfile(path);
        check(prof.MaxRevs == 7500 && prof.MaxSpeed == 160, $"GTICLUB3 ships with Max revs 7500 and Max speed 160: {prof.MaxRevs} {prof.MaxSpeed}");
        prof.ProcessName = "";

        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "GTICLUB3" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), "GTICLUB3 rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
        ps.Connected = true;

        var outs = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>());
        var car = CommonValues.Outputs.ToDictionary(o => o.Name, o => new List<(double t, double v)>());
        void Set(string n, double v) { if (feeds.TryGetValue(n, out var f)) f.Value = v; }
        double tl = 60, lapTicks = 0, vib = 0;
        const double dt = 1 / 120.0;
        for (double t = 0; t < 26; t += dt)
        {
            // race state: menus (pointer null), countdown, racing, time up, menus again
            double state = t < 1 ? double.NaN : t < 3 ? 3 : t < 20 ? 5 : t < 23 ? 8 : double.NaN;
            Set("race_state", state);
            bool racing = state == 5;
            // stale car values outside a race
            double kmh = t < 1 || t >= 23 ? 150 : racing ? Math.Min(150, (t - 3) * 20) : 0;
            if (t >= 14 && t < 14.3) kmh -= (t - 14) * 100;   // the wall at 14 s costs 30 km/h
            Set("speed", kmh); Set("true_speed", kmh / 3.6); Set("rpm", racing ? 50 + kmh / 2 : 50); Set("rpm_tacho", 3000);
            Set("gear", racing ? 3 : 1); Set("gear_stored", 2); Set("gearbox", 0); Set("speedo_mph", 0);
            Set("game_mode", 1); Set("in_menu", 0); Set("laps_total", 3); Set("finished", t >= 20 && t < 23 ? 1 : 0);
            Set("position", t < 17 ? 1 : 0);   // stored 0 = first
            Set("laps_done", t < 16 ? 0 : t < 18 ? 1 : 2);
            Set("lap1", t < 16 ? 0 : 12345); Set("lap2", t < 18 ? 0 : 11500);
            for (int n = 3; n <= 7; n++) Set("lap" + n, 0);
            // time left: counts down while racing; +20 s eased in over 0.5 s at t = 10
            if (racing) tl -= dt;
            if (t >= 10 && t < 10.5) tl += 20 / 60.0;
            Set("time_left", Math.Round(tl * 1000));   // milliseconds
            if (racing) lapTicks += 30 * dt;
            if (t >= 16 && t < 16 + dt) lapTicks = 0;
            Set("lap_time", lapTicks);
            // surfaces: two wheels on code 2 from 12 to 13 s, one more on code 2 + 256 (skipped by the game)
            bool rough = t >= 12 && t < 13 || t >= 14.95 && t < 15.5;   // the kerb at 15 s is under two wheels
            Set("surface1", rough ? 2 : 0); Set("surface2", rough ? 2 : 0); Set("surface3", rough ? 2 + 256 : 0); Set("surface4", 0);
            Set("force_angle", 0.1);
            // jolts, pattern 15, fading by the frame time: a wall at 14 s (level 21), a kerb at 15 s (27, no speed lost),
            // another car at 16.5 s (36) and a landing at 18 s (50)
            vib = Math.Max(0, vib - dt);
            if (t >= 14 && t < 14 + dt) vib = 21 / 72.0;
            if (t >= 15 && t < 15 + dt) vib = 27 / 72.0;
            if (t >= 16.5 && t < 16.5 + dt) vib = 0.5;
            if (t >= 18 && t < 18 + dt) vib = 50 / 72.0;
            Set("ffb_vibration", Math.Min(63, Math.Floor(vib * 72)));
            Set("ffb_other", t >= 14 ? 15 : 10);
            Set("ffb_flags", 0); Set("ffb_main", 0); Set("ob_ffb", 0);
            foreach (var l in new[] { "lampaction", "lampstart", "lampselectup", "lampselectdown", "lampselectleft", "lampselectright" }) Set(l, 0);

            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) outs[v.Def.Name].Add((t, v.Output));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) car[o.Name].Add((t, eng.Common.Get(o.Name)));
        }
        double At(string n, double t) => outs[n].First(x => x.t >= t).v;
        double Max(string n, double a, double b) => outs[n].Where(x => x.t >= a && x.t < b).Max(x => x.v);
        double CarMax(string n, double a, double b) => car[n].Where(x => x.t >= a && x.t < b).Max(x => x.v);
        double Span(string n, double a, double b) => outs[n].Count(x => x.t >= a && x.t < b && x.v != 0) * dt;

        check(At("speed", 0.5) == 0 && At("rpm", 0.5) == 0 && At("gear", 0.5) == 0 && At("position", 0.5) == 0,
              $"GTICLUB3: car values read 0 before a race (stale pointer): speed {At("speed", 0.5)}, gear {At("gear", 0.5)}");
        check(At("speed", 24) == 0 && At("true_speed", 24) == 0, $"GTICLUB3: car values read 0 after the race: {At("speed", 24)}");
        check(At("in_race", 2) == 0 && At("in_race", 5) == 1 && At("in_race", 21) == 0 && At("in_race", 0.5) == 0,
              "GTICLUB3: in_race only in race state 5");
        check(Math.Abs(At("rpm", 2) - 3000 / 7500.0) < 1e-9, $"GTICLUB3: rpm = revs a second x 60 / Max revs on the grid: {At("rpm", 2)}");
        check(Math.Abs(At("speed", 8) * 160 - 100) < 0.5 && Math.Abs(At("true_speed", 8) - 100) < 0.5, $"GTICLUB3: speed and true_speed in km/h: {At("speed", 8) * 160} {At("true_speed", 8)}");
        double cp = Span("checkpoint", 3, 20);
        check(Max("checkpoint", 10, 10.2) == 1 && cp > 1.4 && cp < 1.6 && Max("checkpoint", 3, 9.9) == 0,
              $"GTICLUB3: checkpoint 1 for about a second from the time extension (eased in over 0.5 s): {cp:0.00} s");
        check(Math.Abs(Max("kerb", 12, 13) - 0.5) < 1e-9 && Max("kerb", 13.1, 14.9) == 0 && Max("kerb", 15.6, 20) == 0 && Max("rough_ground", 3, 20) == 0,
              $"GTICLUB3: kerb counts wheels on code 2 but not code 2 + 256: {Max("kerb", 12, 13)}");
        double hit = Max("hit", 14, 14.4);
        check(Max("wall_hit", 14, 14.4) == 1 && hit > 0.8 && hit <= 1 && Max("hit", 3, 13.99) == 0, $"GTICLUB3: wall hit at 14 s, sized by the 30 km/h lost: {hit:0.00}");
        check(Max("wall_hit", 14.9, 16.4) == 0 && Max("hit", 14.9, 16.4) == 0, "GTICLUB3: the kerb's jolt (no speed lost) is no hit");
        check(Max("car_hit", 16.5, 16.8) == 1 && Max("car_hit", 3, 16.4) == 0 && Math.Abs(Max("hit", 16.5, 16.8) - 0.5) < 1e-9, "GTICLUB3: car hit at 16.5 s, 0.5 with no speed lost");
        check(Max("landing", 18, 18.2) == 1 && Max("landing", 3, 17.9) == 0 && Max("hit", 17.9, 19) == 0, "GTICLUB3: landing at 18 s, and it's no hit");
        check(CarMax("impact", 14, 14.4) > 0.8 && CarMax("road_bump", 18, 18.2) == 1 && CarMax("road_bump", 3, 17.9) == 0, "GTICLUB3: Car_impact from hits, Car_road_bump from landings");
        check(At("position", 10) == 2 && At("leader", 10) == 0 && At("position", 17.5) == 1 && At("leader", 17.5) == 1 && At("leader", 21) == 0,
              "GTICLUB3: position 1 = first (stored 0), leader only while racing");
        check(At("last_lap", 15) == 0 && Math.Abs(At("last_lap", 17) - 12.345) < 1e-9 && Math.Abs(At("last_lap", 19) - 11.5) < 1e-9,
              $"GTICLUB3: last_lap follows laps_done: {At("last_lap", 17)} {At("last_lap", 19)}");
        check(At("final_lap", 17) == 0 && At("final_lap", 19) == 1, "GTICLUB3: final_lap on lap 3 of 3");
        check(Math.Abs(At("lap_time", 15.9) - 12.9) < 0.05 && At("lap_time", 16.5) < 0.6, $"GTICLUB3: lap_time in seconds (30 a second): {At("lap_time", 15.9)}");
        check(At("hurry", 19) == 0, "GTICLUB3: hurry off with time to spare");
        check(Math.Abs(car["speed"].First(x => x.t >= 8).v - At("speed", 8) * 160) < 1e-9 && CarMax("in_race", 21, 23) == 0, "GTICLUB3: Car_speed is the speedo, Car_in_race off after time up");
        check(Math.Abs(CarMax("rumble_strip", 12, 13) - 0.5) < 1e-9 && CarMax("off_road", 3, 20) == 0, "GTICLUB3: Car_rumble_strip from kerb, Car_off_road from rough_ground");
        Recording(check, path);
    }

    static Replay Feed(Action<bool, string> check, string path, string fixture)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = "";
        prof.MaxSpeed = 1;   // the recording was made before Max speed was set
        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "GTICLUB3" });
        var ps = eng.Profiles[0];
        ps.Connected = true;
        // time_left and speedo_mph moved to the race display after this recording: they read nothing here
        var later = new HashSet<string> { "time_left", "speedo_mph" };
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(kv.Key));
        check(cols.Where(c => !later.Contains(c.Key)).All(c => c.Value >= 0), "GTICLUB3: the recording has every memory row: " +
              string.Join(", ", cols.Where(c => c.Value < 0 && !later.Contains(c.Key)).Select(c => c.Key)));
        var rp = new Replay { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()) };
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        int tc = Col("time_s"), mc = Col("marker");
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            if (r[mc] != "") rp.Marks.Add(t);
            foreach (var kv in feeds) kv.Value.Value = Num(r, cols[kv.Key]);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            rp.End = t;
        }
        return rp;
    }

    // Times from the recording: each list is where the game sent that jolt (checked against Alexis's notes where she marked them).
    static readonly double[] Landings = { 70.46, 72.22, 78.56, 118.13, 125.00, 129.37, 133.36, 139.80, 175.71, 190.14, 196.64, 229.22, 231.39 };
    static readonly double[] Cars = { 87.06, 93.76, 96.72, 150.00, 151.10, 167.73, 173.01, 180.84, 182.61, 185.94, 204.41, 215.51, 238.42, 242.89 };
    // 99.42: her front right into the RHS wall (no speed lost; confirmed 8 November). 148.20: her rear right onto the LHS kerb.
    static readonly double[] Walls = { 74.22, 76.59, 82.92, 85.26, 92.79, 99.42, 100.62, 108.76, 140.43, 154.40, 164.13, 198.84, 213.51, 226.42, 227.58, 230.29, 233.96 };
    static readonly double[] KerbJolts = { 148.20, 166.97, 232.86, 233.09 };   // the same jolt with a wheel on the kerb, no speed lost

    static string Near(List<double> got, double[] want, double after) =>
        string.Join(" ", want.Where(w => !got.Any(g => g >= w - 0.02 && g <= w + after)).Select(w => w.ToString("0.00", CultureInfo.InvariantCulture)));
    static string Extra(List<double> got, double[] want, double after) =>
        string.Join(" ", got.Where(g => !want.Any(w => g >= w - 0.02 && g <= w + after)).Select(g => g.ToString("0.00", CultureInfo.InvariantCulture)));

    static void Recording(Action<bool, string> check, string path)
    {
        var r = Feed(check, path, "gti-20261108-182540.csv.gz");
        string s = "GTICLUB3 recording: ";
        check(r.Marks.Count == 37, s + $"37 marks: {r.Marks.Count}");
        // racing from the start (63.8 s) to the finish line (244.59 s); the game drives on its own after that
        check(r.At("in_race", 64) == 1 && r.At("in_race", 244.5) == 1 && r.Max("in_race", 244.65, r.End) == 0 && r.Max("in_race", 0, 63.5) == 0,
              s + "in_race from the start to the finish line");
        check(r.Max("final_lap", 188, 244.5) == 1 && r.Max("final_lap", 64, 187.6) == 0, s + "final lap from 187.7 s");
        check(Math.Abs(r.At("last_lap", 140) - 67.049) < 1e-9 && Math.Abs(r.At("last_lap", 200) - 56.764) < 1e-9, s + "last_lap 67.049, then 56.764");
        check(Math.Abs(r.At("rpm_tacho", 67.86) - 7058) < 60 || r.Max("rpm_tacho", 67.6, 67.9) > 7000, s + "tacho at her first shift about 7058");
        check(r.Max("gear", 64, 244) == 5 && r.Max("gearbox", 64, 244) == 1, s + "five gears; gearbox 1 with the manual");
        var land = r.Events("landing", 0, 0.3); var car = r.Events("car_hit", 0, 0.35); var wall = r.Events("wall_hit", 0, 0.35);
        check(Near(land, Landings, 0.05) == "" && Extra(land, Landings, 0.05) == "", s + $"landings: missed {Near(land, Landings, 0.05)}; extra {Extra(land, Landings, 0.05)}");
        check(Near(car, Cars, 0.05) == "" && Extra(car, Cars, 0.05) == "", s + $"car hits: missed {Near(car, Cars, 0.05)}; extra {Extra(car, Cars, 0.05)}");
        check(Near(wall, Walls, 0.3) == "" && Extra(wall, Walls, 0.3) == "", s + $"wall hits: missed {Near(wall, Walls, 0.3)}; extra {Extra(wall, Walls, 0.3)}");
        check(r.Events("crash", 0, 0.6).SequenceEqual(new[] { r.Out["crash"].First(x => x.v > 0).t }) && Math.Abs(r.Out["crash"].First(x => x.v > 0).t - 108.82) < 0.05,
              s + "one full-stop crash, the barrier at 108.8 s");
        check(KerbJolts.All(k => r.Max("hit", k, k + 0.3) == 0), s + "kerb jolts with no speed lost are no hits");
        check(r.Max("hit", 108.8, 109) == 1 && r.Max("hit", 74.2, 74.5) > 0.85 && r.Max("hit", 151.1, 151.4) == 0.5 && r.Max("hit", 99.42, 99.7) == 0.5,
              s + "hit: the crash 1, the LHS wall (26 km/h lost) about 0.9, a rub and the RHS wall at 99.42 with no speed lost 0.5");
        // kerbs: her marks 19 (RHS kerb) and the LHS kerb at 97.4 s; never in the first lap's opening straight
        check(r.Max("kerb", 97.4, 98) > 0 && r.Max("kerb", 64, 82.9) == 0, s + $"kerb from 97.4 s, none before the first at 82.9 s: {r.Spans("kerb")}");
        check(r.Max("rough_ground", 64, 245) == 0, s + "no surface code 5 in this course");
        check(r.Car["impact"].Where(x => x.t >= 108.8 && x.t < 109).Max(x => x.v) == 1 && r.Car["road_bump"].Where(x => x.t >= 70.4 && x.t < 70.8).Max(x => x.v) == 1,
              s + "Car_impact 1 at the crash; Car_road_bump at the first landing");
    }
}
