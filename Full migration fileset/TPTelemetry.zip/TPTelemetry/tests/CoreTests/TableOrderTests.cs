using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Expressions;

/// <summary>
/// Every profile in the pack has its table in Alexis's order (3 November 2026): values read from the game
/// first (speed, then revs, then gear, then the rest), then values calculated from other rows, then the car_
/// rows that feed the common values. And no redundant rows: no row that is just another row's name, and no
/// memory read used only by one plain calculated row (tools/tidytable.py merges those).
/// </summary>
static class TableOrderTests
{
    static readonly Regex[] Kinds = { new Regex("^(speed|speedo)\\d*$"), new Regex("^(rpm|revs)\\d*$"), new Regex("^gear(\\d+|_raw)?$") };
    static readonly Regex Stateful = new Regex("\\b(slope|deriv|avg|minw|maxw|ema|smooth|prev|delta|rate|unwrap|integrate|hold)\\s*\\(");

    public static void Run(Action<bool, string> check, string pack)
    {
        if (string.IsNullOrEmpty(pack) || !Directory.Exists(pack)) return;
        var files = Directory.GetFiles(pack, "*.json", SearchOption.AllDirectories);
        var common = new HashSet<string>(CommonValues.Sources.Select(s => "car_" + s.Name).Concat(CommonValues.Lamps.Select(l => CommonValues.LampRowPrefix + l.Name)));   // 0.20.0: and the lamp_ rows
        var badOrder = new List<string>(); var aliases = new List<string>(); var singles = new List<string>();
        foreach (var f in files)
        {
            var p = ProfileStore.ReadProfile(f);
            var names = new HashSet<string>(p.Variables.Select(v => v.Name));
            IEnumerable<string> Refs(VariableDef v) => Formula.Identifiers(v.Formula).Where(n => names.Contains(n) && n != v.Name).Distinct();
            int Group(VariableDef v) => common.Contains(v.Name) ? 2 : v.Source == SourceKind.Memory || !Refs(v).Any() ? 0 : 1;
            int Kind(VariableDef v) { for (int i = 0; i < Kinds.Length; i++) if (Kinds[i].IsMatch(v.Name)) return i; return Kinds.Length; }
            var keys = p.Variables.Select(v => (g: Group(v), k: Group(v) == 2 ? 0 : Kind(v))).ToList();
            for (int i = 1; i < keys.Count; i++)
                if (keys[i].g < keys[i - 1].g || keys[i].g == keys[i - 1].g && keys[i].g < 2 && keys[i].k < Math.Min(keys[i - 1].k, Kinds.Length))
                { badOrder.Add($"{p.Prefix}: {p.Variables[i].Name} after {p.Variables[i - 1].Name}"); break; }
            foreach (var v in p.Variables.Where(v => v.Source == SourceKind.Computed && !common.Contains(v.Name)))
                if (names.Contains((v.Formula ?? "").Trim())) aliases.Add($"{p.Prefix}: {v.Name} = {v.Formula}");
            foreach (var x in p.Variables.Where(v => v.Source == SourceKind.Memory && !v.Name.StartsWith("ob_") && !(v.Notes ?? "").Contains("OutputBlaster")))
            {
                var users = p.Variables.Where(v => v.Name != x.Name && Refs(v).Contains(x.Name)).ToList();
                if (users.Count == 1 && users[0].Source == SourceKind.Computed && !common.Contains(users[0].Name)
                    && Refs(users[0]).SequenceEqual(new[] { x.Name }) && !Stateful.IsMatch(users[0].Formula ?? ""))
                    singles.Add($"{p.Prefix}: {x.Name} only feeds {users[0].Name}");
            }
        }
        check(files.Length > 100 && badOrder.Count == 0, $"every table in order (game values with speed, revs, gear first; calculated; car_ rows): {files.Length} profiles; " + string.Join("; ", badOrder.Take(5)));
        check(aliases.Count == 0, "no row is just another row's name: " + string.Join("; ", aliases.Take(5)));
        check(singles.Count == 0, "no memory read feeds only one plain calculated row: " + string.Join("; ", singles.Take(5)));
    }
}
