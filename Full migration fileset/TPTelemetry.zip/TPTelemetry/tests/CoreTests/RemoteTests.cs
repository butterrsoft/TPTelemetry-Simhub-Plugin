using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.IO.Pipes;
using System.Linq;
using System.Threading;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Remote;

/// <summary>The 64-bit helper: read plan, results block, pipe protocol, the helper's loop and the
/// plugin's client, run in-process over a real named pipe and shared memory.</summary>
static class RemoteTests
{
    /// <summary>A pretend 64-bit game: modules, 8-byte pointers and values at addresses.</summary>
    sealed class FakeGame : IGameReader
    {
        public readonly Dictionary<string, long> Modules = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        public readonly Dictionary<long, long> Pointers = new Dictionary<long, long>();
        public readonly Dictionary<long, double> Values = new Dictionary<long, double>();
        public volatile bool Exited;
        public bool HasExited => Exited;
        // like ProcessMemory: <main> is the exe, listed first
        public bool TryGetModuleBase(string module, out long b) =>
            Modules.TryGetValue(module == ProcessMemory.MainModule ? "wmn5r.exe" : module, out b);
        public bool TryReadPointer(long a, out long v) => Pointers.TryGetValue(a, out v) && v != 0;
        public bool TryReadValue(long a, MemType t, out double v) { lock (Values) return Values.TryGetValue(a, out v); }
        public void Set(long a, double v) { lock (Values) Values[a] = v; }
        public void Dispose() { }
    }

    /// <summary>Runs the real HelperServer on a thread, joined to the client by a named pipe and an
    /// anonymous memory map (the Windows build uses a named one).</summary>
    sealed class InProcessTransport : IHelperTransport
    {
        readonly MemoryMappedFile _mmf;
        readonly NamedPipeServerStream _server;
        readonly NamedPipeClientStream _client;
        readonly Thread _thread;
        public readonly HelperServer Server;
        public UnmanagedMemoryAccessor Block { get; }
        public Stream Control => _client;
        public bool Alive => _thread.IsAlive;
        public static readonly List<InProcessTransport> Started = new List<InProcessTransport>();

        public InProcessTransport(Func<int, string, IGameReader> opener)
        {
            _mmf = MemoryMappedFile.CreateNew(null, ResultsLayout.Size(ReadPlan.MaxRows));
            var rw = _mmf.CreateViewAccessor();
            Block = _mmf.CreateViewAccessor(0, 0, MemoryMappedFileAccess.Read);
            var name = "tpt_test_" + Guid.NewGuid().ToString("N").Substring(0, 12);
            _server = new NamedPipeServerStream(name, PipeDirection.InOut, 1);
            Server = new HelperServer(_server, rw, ReadPlan.MaxRows, 99, opener);
            _thread = new Thread(() => { _server.WaitForConnection(); Server.Run(); }) { IsBackground = true };
            _thread.Start();
            _client = new NamedPipeClientStream(".", name, PipeDirection.InOut);
            _client.Connect(5000);
            lock (Started) Started.Add(this);
        }

        public void Kill() { Server.Stop(); _thread.Join(3000); }

        public void Dispose()
        {
            _client.Dispose();
            _thread.Join(3000);
            _server.Dispose();
        }
    }

    /// <summary>A helper that answers on the pipe and publishes once, then never again (hung).</summary>
    sealed class HungTransport : IHelperTransport
    {
        readonly MemoryMappedFile _mmf;
        readonly NamedPipeServerStream _server;
        readonly NamedPipeClientStream _client;
        public UnmanagedMemoryAccessor Block { get; }
        public Stream Control => _client;
        public bool Alive => true;

        public HungTransport()
        {
            _mmf = MemoryMappedFile.CreateNew(null, ResultsLayout.Size(16));
            var w = new ResultsWriter(_mmf.CreateViewAccessor(), 16, 7);
            Block = _mmf.CreateViewAccessor(0, 0, MemoryMappedFileAccess.Read);
            var name = "tpt_hung_" + Guid.NewGuid().ToString("N").Substring(0, 12);
            _server = new NamedPipeServerStream(name, PipeDirection.InOut, 1);
            new Thread(() =>
            {
                try
                {
                    _server.WaitForConnection();
                    HelperProtocol.Write(_server, "HELLO 1 7");
                    string m;
                    while ((m = HelperProtocol.Read(_server)) != null && m != "STOP")
                    {
                        var plan = ReadPlan.Parse(m.Substring(5));
                        w.Publish(plan.Generation, GameState.Attached, plan.Pid, "", new RowResult[1], 1);
                        HelperProtocol.Write(_server, "OK " + plan.Generation);
                    }
                }
                catch { }
            }) { IsBackground = true }.Start();
            _client = new NamedPipeClientStream(".", name, PipeDirection.InOut);
            _client.Connect(5000);
        }

        public void Dispose() { _client.Dispose(); _server.Dispose(); }
    }

    static bool WaitFor(Func<bool> cond, int ms = 4000)
    {
        var sw = Stopwatch.StartNew();
        while (sw.ElapsedMilliseconds < ms) { if (cond()) return true; Thread.Sleep(5); }
        return cond();
    }

    const long Hi = 0x7FF6_1234_0000; // above 4 GB, as in a 64-bit game

    static FakeGame MakeGame()
    {
        var g = new FakeGame();
        g.Modules["wmn5r.exe"] = 0x7FF6_0000_0000;
        g.Modules["game.dll"] = 0x7FF8_0000_0000;
        g.Set(0x7FF6_0000_0100, 123.5);                     // <main>+100
        g.Pointers[0x7FF8_0000_0010] = Hi;                  // game.dll+10 -> Hi
        g.Pointers[Hi + 0x20] = Hi + 0x1000;                // [Hi+20] -> Hi+1000
        g.Set(Hi + 0x1000 + 0x8, 6.0);                      // + 8: the value
        g.Set(0x1000_0000, 42);                             // absolute
        return g;
    }

    static ReadPlan MakePlan(int pid) => new ReadPlan
    {
        Pid = pid, ProcessName = "wmn5r.exe", PollHz = 200,
        Rows =
        {
            new ReadPlanRow { Module = "<main>", BaseOffset = 0x100, Type = MemType.Float },
            new ReadPlanRow { Module = "game.dll", BaseOffset = 0x10, Offsets = new long[] { 0x20, 0x8 }, Type = MemType.Double },
            new ReadPlanRow { Module = "missing.dll", BaseOffset = 0x10, Type = MemType.Int32 },
            new ReadPlanRow { Module = "game.dll", BaseOffset = 0x10, Offsets = new long[] { 0x30, 0x8 }, Type = MemType.Int32 },
            new ReadPlanRow { Module = "", BaseOffset = 0x1000_0000, Type = MemType.Int32 },
        }
    };

    public static void Run(Action<bool, string> check, Action<double, double, double, string> near)
    {
        // ---- several processes with the game's name (0.18.1): the newest is read (Battle Gear 4, 10 November 2026:
        // a stopped game.exe hung on and the next race was read from it, frozen)
        var t0 = new DateTime(2026, 11, 10, 19, 0, 0);
        check(ProcessMemory.PickNewest(new (int, DateTime?)[] { (900, t0), (412, t0.AddMinutes(20)), (77, t0.AddMinutes(5)) }) == 412,
              "process choice: the latest started");
        check(ProcessMemory.PickNewest(new (int, DateTime?)[] { (500, null), (300, t0) }) == 300,
              "process choice: a known start time beats an unknown one");
        check(ProcessMemory.PickNewest(new (int, DateTime?)[] { (5, null), (9, null) }) == 9, "process choice: no start times, the higher PID");
        check(ProcessMemory.PickNewest(new (int, DateTime?)[0]) == null, "process choice: none running");

        // ---- read plan
        var plan = MakePlan(1234);
        plan.Generation = 7;
        var text = plan.Serialise();
        var back = ReadPlan.Parse(text);
        check(back.Pid == 1234 && back.ProcessName == "wmn5r.exe" && back.PollHz == 200 && back.Generation == 7, "plan header round-trips");
        check(back.Rows.Count == 5 && back.Rows[0].Module == "<main>" && back.Rows[4].Module == "" && back.Rows[4].BaseOffset == 0x1000_0000,
              "plan rows round-trip, including <main> and absolute addresses");
        check(back.Rows[1].Offsets.SequenceEqual(new long[] { 0x20, 0x8 }) && back.Rows[1].Type == MemType.Double, "plan offsets and type round-trip");
        check(Throws(() => ReadPlan.Parse("hello")), "a non-plan is refused");
        check(Throws(() => ReadPlan.Parse("TPTPLAN 1\nrow\tx\tZZ\t\tFloat\n")), "a bad base offset is refused");
        check(Throws(() => ReadPlan.Parse("TPTPLAN 1\nrow\tx\t10\t\tBanana\n")), "an unknown type is refused");
        var tabs = new ReadPlan { ProcessName = "a\tb", Rows = { new ReadPlanRow { Module = "x\ty.dll" } } };
        check(ReadPlan.Parse(tabs.Serialise()).Rows[0].Module == "x y.dll", "tabs in names can't break the format");
        var big = new ReadPlan(); for (int i = 0; i <= ReadPlan.MaxRows; i++) big.Rows.Add(new ReadPlanRow { Module = "m" });
        check(Throws(() => ReadPlan.Parse(big.Serialise())), $"more than {ReadPlan.MaxRows} rows is refused");

        // ---- results block
        using (var mmf = MemoryMappedFile.CreateNew(null, ResultsLayout.Size(8)))
        using (var rw = mmf.CreateViewAccessor())
        using (var ro = mmf.CreateViewAccessor(0, 0, MemoryMappedFileAccess.Read))
        {
            var reader = new ResultsReader(ro);
            var snap = new ResultsSnapshot();
            check(!reader.TryRead(snap), "an empty block isn't read");
            var w = new ResultsWriter(rw, 8, 555);
            check(reader.TryRead(snap) && snap.HelperPid == 555 && snap.RowCount == 0 && snap.Generation == -1, "a fresh block reads as empty");
            var rows = new[]
            {
                new RowResult { Value = 1.25, Address = Hi, Status = ReadStatus.Ok },
                new RowResult { Value = double.NaN, Address = 0x40, Status = ReadStatus.NullPointer, Detail = 2 },
            };
            w.Publish(3, GameState.Attached, 4321, "", rows, 2);
            check(reader.TryRead(snap) && snap.Generation == 3 && snap.State == GameState.Attached && snap.GamePid == 4321 && snap.RowCount == 2,
                  "header fields round-trip");
            check(snap.Rows[0].Value == 1.25 && snap.Rows[0].Address == Hi && snap.Rows[0].Status == ReadStatus.Ok, "an ok row round-trips, with a 64-bit address");
            check(double.IsNaN(snap.Rows[1].Value) && snap.Rows[1].Status == ReadStatus.NullPointer && snap.Rows[1].Detail == 2, "a failed row keeps its status and level");
            int beat = snap.Heartbeat;
            w.Publish(3, GameState.Attached, 4321, "", rows, 2);
            check(reader.TryRead(snap) && snap.Heartbeat == beat + 1, "the heartbeat moves on every publish");

            rw.Write(32, rw.ReadInt32(32) + 1); // pretend the writer is mid-update
            check(!reader.TryRead(snap, 2), "a block that's being written isn't read");
            rw.Write(32, rw.ReadInt32(32) + 1);
            check(reader.TryRead(snap), "...and is read once the write finishes");

            var longMsg = new string('é', 150); // 300 bytes of UTF-8
            w.Publish(3, GameState.Error, 0, longMsg, rows, 0);
            check(reader.TryRead(snap) && snap.Message.Length == 100 && snap.Message.All(c => c == 'é'),
                  "a long message is cut at a character boundary, got " + snap.Message.Length + " characters");
            check(reader.TryRead(snap) && snap.State == GameState.Error && snap.RowCount == 0, "error state reads back");
        }

        // ---- protocol framing
        using (var ms = new MemoryStream())
        {
            HelperProtocol.Write(ms, "PLAN\nhello");
            HelperProtocol.Write(ms, "");
            ms.Position = 0;
            check(HelperProtocol.Read(ms) == "PLAN\nhello" && HelperProtocol.Read(ms) == "" && HelperProtocol.Read(ms) == null,
                  "messages are framed, and the end of the stream reads as null");
        }

        // ---- the helper and the client together
        var game = MakeGame();
        int opens = 0;
        IGameReader Open(int pid, string name) { opens++; return pid == 1234 ? game : null; }
        InProcessTransport tr = null;
        var client = new HelperClient(() => tr = new InProcessTransport(Open));
        client.Start(MakePlan(1234));
        check(WaitFor(() => client.Poll() == RemoteState.Running), "the helper attaches: " + client.Message);
        check(WaitFor(() => { client.Poll(); return client.TryGet(0, out _); }), "results arrive");
        client.TryGet(0, out var r0); client.TryGet(1, out var r1); client.TryGet(2, out var r2); client.TryGet(3, out var r3); client.TryGet(4, out var r4);
        check(r0.Status == ReadStatus.Ok && r0.Value == 123.5 && r0.Address == 0x7FF6_0000_0100, "<main> row read through the helper");
        check(r1.Status == ReadStatus.Ok && r1.Value == 6.0 && r1.Address == Hi + 0x1008, "pointer chain above 4 GB read through the helper");
        check(r2.Status == ReadStatus.ModuleNotLoaded, "missing module reported");
        check(r3.Status == ReadStatus.NullPointer && r3.Detail == 2 && r3.Address == Hi + 0x30, "null pointer reported with its level and address");
        check(r4.Status == ReadStatus.Ok && r4.Value == 42, "absolute address read through the helper");
        check(!client.TryGet(5, out _) && !client.TryGet(-1, out _), "slots outside the plan have no result");
        check(MemorySource.Describe(r3.Status, "game.dll", r3.Address, r3.Detail) == "null/unreadable pointer at level 2 (0x7FF612340030)",
              "status text matches what the plugin shows for its own reads");

        game.Set(Hi + 0x1008, 7.5);
        check(WaitFor(() => { client.Poll(); return client.TryGet(1, out var r) && r.Value == 7.5; }), "values follow the game");

        // an edit: different rows; old results mustn't be taken for the new ones
        var edited = new ReadPlan { ProcessName = "wmn5r.exe", PollHz = 200, Rows = { new ReadPlanRow { Module = "", BaseOffset = 0x1000_0000, Type = MemType.Int32 } } };
        client.SetPlan(edited);
        client.Poll();
        check(!client.TryGet(0, out var stale) || stale.Value == 42, "results from the old plan aren't used for the new one");
        check(WaitFor(() => { client.Poll(); return client.TryGet(0, out var r) && r.Value == 42; }), "the edited plan takes effect");
        check(!client.TryGet(1, out _), "rows beyond the edited plan are gone");

        game.Exited = true;
        check(WaitFor(() => client.Poll() == RemoteState.GameExited), "game exit is reported: " + client.Message);
        check(client.Message.Contains("exited"), "exit message: " + client.Message);
        check(!client.TryGet(0, out _), "no results once the game has gone");
        client.Dispose();
        check(WaitFor(() => !tr.Alive), "the helper stops when the client is disposed");

        // the helper dies
        game = MakeGame();
        var client2 = new HelperClient(() => tr = new InProcessTransport(Open));
        client2.Start(MakePlan(1234));
        check(WaitFor(() => client2.Poll() == RemoteState.Running), "second helper attaches");
        tr.Kill();
        check(WaitFor(() => client2.Poll() == RemoteState.Failed), "a helper that dies is noticed");
        check(client2.Message.Contains("exited unexpectedly"), "message: " + client2.Message);
        client2.Dispose();

        // a PID that has gone already
        var client3 = new HelperClient(() => tr = new InProcessTransport(Open));
        client3.Start(MakePlan(999));
        check(WaitFor(() => client3.Poll() == RemoteState.GameExited), "a PID that's gone reads as exited");
        client3.Dispose();

        // a game that can't be opened
        var client4 = new HelperClient(() => tr = new InProcessTransport((pid, n) => throw new UnauthorizedAccessException("access denied")));
        client4.Start(MakePlan(1234));
        check(WaitFor(() => client4.Poll() == RemoteState.Failed) && client4.Message.Contains("access denied"), "open errors come back: " + client4.Message);
        client4.Dispose();

        // a helper that hangs
        var client5 = new HelperClient(() => new HungTransport()) { StallTimeout = TimeSpan.FromMilliseconds(300) };
        client5.Start(MakePlan(1234));
        check(WaitFor(() => client5.Poll() == RemoteState.Failed) && client5.Message.Contains("stopped responding"), "a hung helper is noticed: " + client5.Message);
        client5.Dispose();

        // a helper that can't start
        var client6 = new HelperClient(() => throw new FileNotFoundException("TPTelemetryHelper64.exe is missing"));
        client6.Start(MakePlan(1234));
        check(WaitFor(() => client6.Poll() == RemoteState.Failed) && client6.Message.Contains("missing"), "a missing helper is reported: " + client6.Message);
        client6.Dispose();

        // a helper that never connects
        var client7 = new HelperClient(() => { Thread.Sleep(2000); throw new TimeoutException("late"); }) { StartTimeout = TimeSpan.FromMilliseconds(200) };
        client7.Start(MakePlan(1234));
        check(client7.Poll() == RemoteState.Starting, "starting while the helper launches");
        check(WaitFor(() => client7.Poll() == RemoteState.Failed) && client7.Message.Contains("didn't start"), "start-up timeout: " + client7.Message);
        client7.Dispose();

        Engine(check);
        TestTargetProfile(check);
    }

    /// <summary>The HELPERTEST profile against a fake game laid out like HelperTestTarget64.exe.</summary>
    static void TestTargetProfile(Action<bool, string> check)
    {
        const long A = 0x7E00_0000_0000, B = 0x7E00_0001_0000, C = 0x7E00_0002_0000;
        var g = new FakeGame();
        g.Modules["wmn5r.exe"] = 0x7FF7_1111_0000;   // stands in for HelperTestTarget64.exe as <main>
        g.Modules["kernel32.dll"] = 0x7FFB_2222_0000;
        g.Set(0x7FF7_1111_0000, 23117); g.Set(0x7FFB_2222_0000, 23117);
        g.Pointers[A] = B; g.Pointers[B + 0x10] = C;
        g.Set(C + 0x08, 0.5); g.Set(C + 0x10, 600);

        var prof = Newtonsoft.Json.JsonConvert.DeserializeObject<GameProfile>(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "HELPERTEST.json")));
        var eng = new TelemetryEngine
        {
            ProcessOpener = name => throw new Target64BitException(55, name),
            RemoteMemoryFactory = () => new HelperClient(() => new InProcessTransport((pid, n) => pid == 55 ? g : null)),
        };
        eng.Load(new[] { prof }, new PluginSettings());
        var p = eng.Profiles[0];
        check(p.Vars.All(v => !v.HasConfigError), "HELPERTEST profile has no errors: " + string.Join("; ", p.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
        eng.TryAttach(p, 0);
        check(WaitFor(() => { eng.Tick(p); return p.Connected && !double.IsNaN(p.Vars.First(v => v.Def.Name == "wave").Output); }), "HELPERTEST attaches: " + p.Status);
        double V(string n) => p.Vars.First(v => v.Def.Name == n).Output;
        string St(string n) => p.Vars.First(v => v.Def.Name == n).Status;
        check(V("mz") == 23117 && V("kernel32_mz") == 23117, "HELPERTEST module rows");
        check(V("wave") == 0.5 && V("wave_x2") == 1.0, "HELPERTEST pointer chain and formula");
        check(V("counter") == 600, "HELPERTEST absolute address");
        check(St("missing") == "notloaded.dll not loaded", "HELPERTEST missing module: " + St("missing"));
        check(St("broken").StartsWith("null/unreadable pointer at level 2"), "HELPERTEST broken chain: " + St("broken"));
        eng.Dispose();
    }

    static void Engine(Action<bool, string> check)
    {
        var game = MakeGame();
        var transports = new List<InProcessTransport>();
        int launches = 0;
        var eng = new TelemetryEngine
        {
            ProcessOpener = name => throw new Target64BitException(1234, name),
            RemoteMemoryFactory = () => new HelperClient(() =>
            {
                Interlocked.Increment(ref launches);
                var t = new InProcessTransport((pid, n) => pid == 1234 ? game : null);
                lock (transports) transports.Add(t);
                return t;
            }),
            RemoteRetryMs = 200,
        };
        GameProfile Prof(string speedBase) => new GameProfile
        {
            Prefix = "WMMT5", ProcessName = "wmn5r.exe", Variables =
            {
                new VariableDef { Name = "speed", Source = SourceKind.Memory, Module = "<main>", BaseOffset = speedBase, Type = MemType.Float },
                new VariableDef { Name = "slip", Source = SourceKind.Memory, Module = "game.dll", BaseOffset = "10", Offsets = "20, 8", Type = MemType.Double },
                new VariableDef { Name = "gone", Source = SourceKind.Memory, Module = "missing.dll", BaseOffset = "10", Type = MemType.Int32 },
                new VariableDef { Name = "double_speed", Source = SourceKind.Computed, Formula = "speed * 2" },
            }
        };
        eng.Load(new[] { Prof("100") }, new PluginSettings());
        var p = eng.Profiles[0];
        check(p.Plan.Rows.Count == 3 && p.Plan.Rows[1].Offsets.SequenceEqual(new long[] { 0x20, 0x8 }), "the engine builds a read plan from the memory rows");
        check(p.Vars.Where(v => v.Def.Source == SourceKind.Memory).Select(v => ((MemorySource)v.Source).PlanSlot).SequenceEqual(new[] { 0, 1, 2 }),
              "memory rows get plan slots in order");

        eng.TryAttach(p, 0);
        check(p.Remote != null && p.Status.StartsWith("Starting the 64-bit helper"), "a 64-bit game starts the helper: " + p.Status);
        check(WaitFor(() => { eng.Tick(p); return p.Connected && !double.IsNaN(p.Vars[0].Output); }), "the engine attaches through the helper: " + p.Status);
        check(p.Status.Contains("64-bit") && p.Status.Contains("PID 1234"), "status says it's 64-bit through the helper: " + p.Status);
        var speed = p.Vars[0]; var slip = p.Vars[1]; var gone = p.Vars[2]; var dbl = p.Vars[3];
        check(speed.Output == 123.5 && speed.Status == "0x7FF600000100", $"memory row value and address through the helper: {speed.Output} {speed.Status}");
        check(slip.Output == 6.0, "pointer chain through the helper: " + slip.Output);
        check(double.IsNaN(gone.Output) && gone.Status == "missing.dll not loaded", "row status through the helper: " + gone.Status);
        check(dbl.Output == 247, "formulas use helper values: " + dbl.Output);
        check(eng.GetPropertyValue("WMMT5_speed") is double d && d == 123.5, "the SimHub property carries the helper's value");

        // an edit keeps the same helper and sends the new rows
        var remote = p.Remote;
        game.Set(0x7FF6_0000_0200, 88);
        eng.Load(new[] { Prof("200") }, new PluginSettings());
        var p2 = eng.Profiles[0];
        check(p2 != p && ReferenceEquals(p2.Remote, remote) && p.Remote == null, "the helper carries over an edit");
        check(WaitFor(() => { eng.Tick(p2); return p2.Vars[0].Output == 88; }), "edited row read through the same helper: " + p2.Vars[0].Output + " " + p2.Vars[0].Status);
        check(launches == 1, "no second helper for an edit, launches " + launches);

        // the game exits
        game.Exited = true;
        check(WaitFor(() => { eng.Tick(p2); return !p2.Connected; }), "game exit detaches");
        check(p2.Status.StartsWith("Game exited") && p2.Remote == null, "status after exit: " + p2.Status);
        check(double.IsNaN(p2.Vars[0].Output), "values clear after exit");
        check(WaitFor(() => transports.All(t => !t.Alive)), "the helper is stopped after the game exits");

        // it comes back: a new helper for the new run
        game.Exited = false;
        eng.TryAttach(p2, 100000);
        check(WaitFor(() => { eng.Tick(p2); return p2.Connected; }), "re-attaches when the game is back: " + p2.Status);
        check(launches == 2, "a fresh helper for the new run, launches " + launches);

        // the helper dies: retried after RemoteRetryMs
        lock (transports) transports.Last().Kill();
        check(WaitFor(() => { eng.Tick(p2); return !p2.Connected; }), "a dead helper detaches");
        check(p2.Status.Contains("exited unexpectedly") && p2.Status.Contains("trying again"), "status says it will retry: " + p2.Status);
        var sw = Stopwatch.StartNew();
        check(WaitFor(() =>
        {
            eng.TryAttach(p2, (long)sw.Elapsed.TotalMilliseconds + 100000 + 0); // engine clock is internal; push well past the retry
            eng.Tick(p2);
            return p2.Connected;
        }), "retries and re-attaches after the helper died: " + p2.Status);

        // no helper available: the old message
        var eng2 = new TelemetryEngine { ProcessOpener = name => throw new Target64BitException(1, name) };
        eng2.Load(new[] { Prof("100") }, new PluginSettings());
        eng2.TryAttach(eng2.Profiles[0], 0);
        check(eng2.Profiles[0].Status.Contains("SimHub is running as 32-bit"), "without a helper the 64-bit message stays: " + eng2.Profiles[0].Status);

        eng.Dispose();
        check(WaitFor(() => transports.All(t => !t.Alive)), "disposing the engine stops every helper");

        // a profile whose game isn't running: rows that don't need its memory still update
        var eng3 = new TelemetryEngine { ProcessOpener = _ => null };
        eng3.Load(new[] { new GameProfile { Prefix = "WAIT", ProcessName = "notrunning.exe", Variables =
        {
            new VariableDef { Name = "raw", Source = SourceKind.Memory, Module = "<main>", BaseOffset = "10", Type = MemType.Byte },
            new VariableDef { Name = "calc", Source = SourceKind.Computed, Formula = "1 + 1" },
            new VariableDef { Name = "clock", Source = SourceKind.Computed, Formula = "t" },
        } } }, new PluginSettings());
        var w = eng3.Profiles[0];
        eng3.TryAttach(w, 0); eng3.Tick(w); System.Threading.Thread.Sleep(20); eng3.Tick(w);
        check(!w.Connected && w.Status == "Waiting for notrunning.exe", "waiting profile: not connected, status " + w.Status);
        check(w.Vars[1].Output == 2 && w.Vars[2].Output > 0, "waiting profile: computed rows still update");
        check(double.IsNaN(w.Vars[0].Output) && w.Vars[0].Status.StartsWith("not attached"), "waiting profile: memory rows blank, saying why: " + w.Vars[0].Status);

        // 0.17.2: attaching carries the clock on from the waiting ticks. It used to restart at 0, and the windows kept what
        // they saw while waiting until the new clock caught up (an ID6 hit row stuck at 1 for 32 s, 9 November 2026).
        {
            var g2 = MakeGame();
            bool up = false;
            var eng4 = new TelemetryEngine
            {
                ProcessOpener = name => up ? throw new Target64BitException(1234, name) : null,
                RemoteMemoryFactory = () => new HelperClient(() => new InProcessTransport((pid, n) => pid == 1234 ? g2 : null)),
            };
            eng4.Load(new[] { new GameProfile { Prefix = "WAIT2", ProcessName = "wmn5r.exe", Variables =
            {
                new VariableDef { Name = "speed", Source = SourceKind.Memory, Module = "<main>", BaseOffset = "100", Type = MemType.Float },
                new VariableDef { Name = "waited", Source = SourceKind.Computed, Formula = "maxw(valid(speed, -1) < 0, 0.05)" },
                new VariableDef { Name = "clock", Source = SourceKind.Computed, Formula = "t" },
            } } }, new PluginSettings());
            var q = eng4.Profiles[0];
            var wait = Stopwatch.StartNew();
            eng4.TryAttach(q, 0);
            while (wait.Elapsed.TotalSeconds < 0.6) { eng4.Tick(q); System.Threading.Thread.Sleep(5); }
            check(!q.Connected && q.Vars[1].Output == 1, "waiting 0.6 s: the window sees the blank read");
            up = true;
            eng4.TryAttach(q, 100000);
            check(WaitFor(() => { eng4.Tick(q); return q.Connected && q.Vars[0].Output == 123.5; }), "attaches after waiting: " + q.Status);
            var after = Stopwatch.StartNew();
            while (after.Elapsed.TotalSeconds < 0.15) { eng4.Tick(q); System.Threading.Thread.Sleep(5); }
            check(q.Vars[1].Output == 0, "a 0.05 s window lets go of the waiting samples soon after attaching: " + q.Vars[1].Output);
            check(q.Vars[2].Output > 0.6, "the clock carries on from the waiting ticks: " + q.Vars[2].Output);
            // and if a clock ever runs backwards, the windows start again rather than sticking
            TelemetryEngine.EvaluateTick(q, 0.01);
            check(q.Vars[1].Output == 0 && q.Vars[2].Output == 0.01, "time running backwards restarts the windows");
            eng4.Dispose();
        }
    }

    static bool Throws(Action a) { try { a(); return false; } catch (FormatException) { return true; } }
}
