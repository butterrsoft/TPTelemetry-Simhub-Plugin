using System.IO;
using System.Linq;

/// <summary>Finds a profile in the game profiles pack, which groups them by emulator
/// (pack/Teknoparrot/SR3/SR3.json, pack/Flycast/FLYINITD3/FLYINITD3.json...).</summary>
static class PackFiles
{
    public static string Find(string pack, string prefix)
    {
        if (string.IsNullOrEmpty(pack) || !Directory.Exists(pack)) return Path.Combine(pack ?? "", prefix, prefix + ".json");
        return Directory.GetFiles(pack, prefix + ".json", SearchOption.AllDirectories)
                        .FirstOrDefault(f => Path.GetFileName(Path.GetDirectoryName(f)) == prefix)
               ?? Path.Combine(pack, prefix, prefix + ".json");
    }
}
