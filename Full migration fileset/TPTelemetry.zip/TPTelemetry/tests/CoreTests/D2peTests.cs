// Daytona USA 2 Power Edition in Supermodel (SMDAYTO2PE), 18 November 2026: RAM logs from the same Supermodel source as
// Alexis's supermodel.exe (git 0b82a98), with a logger added, running her ROM sets (`dayto2pe`, with `daytona2`) and NVRAM on
// the Beginner course (Three Seven Speedway, 8 laps) with an autopilot, replayed through the pack's profile (Max speed 350,
// Max revs 9500). Memory rows' raw values, t = frame / 57.524 s:
// * finish: the menus, the rolling start (time set at 67.49 s, GO at 79.05 s), eight laps (lines at 97.49, 116.40, 137.06,
//   156.16, 176.08, 194.51, 212.95 s), the finish line (231.80 s, TT 2:34.18), the results and the attract mode; manual, the
//   autopilot changing up at about 8,500 (it dropped to first at GO, 289 km/h, where the revs sat at the game's 10000 ceiling);
// * timeup: from lap 4, with big crashes at 159.22 and 185.89 s, to time up at 214.74 s (TT 7914 frames: 02'18"835).
// Alexis's three recordings of 18 November 2026 with the 15:00 profile (Max revs 9500 then), every second sample, worked back
// to raw values (`supermodel/capfixture.py`, PRE=SMDAYTO2PE; with the drive board commands as out_RawDrive), t = recording time:
// * cap1 (16:41): Advanced, NORMAL, manual; grid 24.18 to GO 29.53; car hits; big crashes at 89.8 and 106.9 s; time up 180.39;
// * cap2 (16:47): Expert, HARD, manual; grid 18.97 to GO 24.32; big crashes left then right at 42.8 and 43.3 s; time up 164.04;
// * cap3 (16:50): Beginner, SPECIAL, automatic, from the rolling start; a pit stop (time left still from 96.86 to 108.13 s,
//   the game driving out to about 115 s); the finish line at 165.94 s.
// * cap4 (18:37) and cap5 (18:38), Mixed, manual, recorded with Max revs 8500: EASY on the limiter in first, second and third
//   (7,880, 7,640, 7,610); SPECIAL in second and third (6,990). These recorded +0x1DC (now `rpm_wheels`) as `rpm`.
// * cap6 (18:57), Mixed, SPECIAL, manual: a standing start with wheelspin (the rev counter, +0x1E0, now `rpm`, at 8,500 while
//   the wheels' revs are 3,000 to 3,600), then first, second and third on the limiter (8,500, 7,812, 7,793; her marks).
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;

static class D2peTests
{
    public static void Run(Action<bool, string> check, string pack)
    {
        if (string.IsNullOrEmpty(pack)) return;
        var path = Directory.GetFiles(pack, "SMDAYTO2PE.json", SearchOption.AllDirectories).FirstOrDefault();
        if (path == null) return;
        Finish(check, path);
        TimeUp(check, path);
        Cap1(check, path);
        Cap2(check, path);
        Cap3(check, path);
        Limiters(check, path);
    }

    sealed class R
    {
        public Dictionary<string, List<(double t, double v)>> Out, Car;
        public double At(string n, double t) => Out[n].First(x => x.t >= t).v;
        public double Max(string n, double a, double b) => Out[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        public double Min(string n, double a, double b) => Out[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Min();
        public double CarMax(string n, double a, double b) => Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        public double Start => Out["speed"].First().t;
        public double End => Out["speed"].Last().t;
    }

    static R Replay(Action<bool, string> check, string path, string fixture, string s)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = "";
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var outs = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);   // Supermodel's outputs, where a fixture has them
        var eng = new TelemetryEngine
        {
            OutputSource = n => outs.TryGetValue(n, out var v) ? v : double.NaN,
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "SMDAYTO2PE" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), s + "rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
        ps.Connected = true;
        var r = new R { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()),
                        Car = CommonValues.Outputs.ToDictionary(o => o.Name, o => new List<(double t, double v)>()) };
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            var head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null)
            {
                var f = line.Split(',');
                double P(int i) => f[i].Length == 0 ? double.NaN : double.Parse(f[i], CultureInfo.InvariantCulture);
                double t = P(0);
                for (int i = 2; i < head.Length; i++)
                    if (feeds.TryGetValue(head[i], out var feed)) feed.Value = P(i);
                    else if (head[i].StartsWith("out_")) outs[head[i].Substring(4)] = P(i);
                TelemetryEngine.EvaluateTick(ps, t);
                foreach (var v in ps.Vars) r.Out[v.Def.Name].Add((t, v.Output));
                eng.Common.Update(ps, t);
                foreach (var o in CommonValues.Outputs) r.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            }
        }
        return r;
    }

    static void Finish(Action<bool, string> check, string path)
    {
        string s = "SMDAYTO2PE finish: ";
        var r = Replay(check, path, "smdayto2pe-emu-20261118-finish.csv.gz", s);
        double end = r.End;
        check(r.Max("countdown", r.Start, 67.4) == 0 && r.Min("countdown", 67.6, 78.9) == 1 && r.Max("racing", r.Start, 78.9) == 0,
              s + "the start from the time set (rolling start) to GO");
        check(r.Min("racing", 79.2, 231.7) == 1 && r.Max("racing", 231.9, end) == 0 && r.Max("countdown", 231.9, end) == 0,
              s + "racing from GO to the finish line; nothing in the results and the attract mode");
        check(r.CarMax("in_race", 67.6, 70) == 1 && r.CarMax("in_race", 232, end) == 0 && r.CarMax("speed", 232, end) == 0, s + "Car_in_race and Car_speed");
        check(r.At("finished", 240) == 1 && r.At("finished", 200) == 0, s + "finished after the line");
        check(Math.Abs(r.At("race_clock", 240) - 8788 / 57.0) < 0.01, s + $"TT at the line: {r.At("race_clock", 240):0.00}");
        foreach (var (t, lap) in new[] { (90.0, 1), (110.0, 2), (130.0, 3), (150.0, 4), (170.0, 5), (190.0, 6), (205.0, 7), (225.0, 8) })
            check(r.At("lap", t) == lap, s + $"lap {lap} at {t} s");
        foreach (double m in new[] { 97.49, 116.40, 137.06 })
            check(r.Max("time_extended", m - 0.1, m + 0.4) == 1, s + $"time extended at the lap line ({m:0.00} s)");
        check(Math.Abs(r.At("last_lap", 100) - 1062 / 57.0) < 0.01, s + "last lap 18.63 s after the first line (the screen: 18\"626)");
        check(r.At("position", 94.6) == 34 && r.At("position", 205.4) == 24, s + "positions 34th and 24th where the screen showed them");
        double top = r.Out["rpm"].Where(x => x.t > 80 && x.t < 231).Max(x => x.v) * 8500;
        check(top > 8400 && top < 8700 && r.Out["gear"].Where(x => x.t > 80 && x.t < 231).Max(x => x.v) == 4, s + $"revs to {top:0} (the autopilot's change-up), gears to 4th");
        check(Math.Abs(r.Out["rpm"].Where(x => x.t > 79.1 && x.t < 79.8).Max(x => x.v) * 8500 - 10000) < 0.5, s + "the 10000 ceiling over-revving in first at GO");
    }

    static void TimeUp(Action<bool, string> check, string path)
    {
        string s = "SMDAYTO2PE time up: ";
        var r = Replay(check, path, "smdayto2pe-emu-20261118-timeup.csv.gz", s);
        check(r.Min("racing", r.Start + 0.3, 214.6) == 1 && r.Max("racing", 214.9, r.End) == 0, s + "racing to time up");
        check(Math.Abs(r.At("race_clock", 215.5) - 7914 / 57.0) < 0.01 && r.At("rt", 215.5) == 0 && r.At("finished", 215.5) == 0, s + "TT 02'18\"84, time left 0, not finished");
        check(r.Max("hit", 159.1, 159.6) == 1 && r.Max("hit", 185.8, 186.3) == 1 && r.CarMax("impact", 159.1, 159.6) == 1, s + "the two big crashes");
    }

    static int Edges(R r, string n, double a, double b)
    {
        int k = 0; double last = 0;
        foreach (var (t, v) in r.Out[n]) { if (t < a || t > b) continue; if (v > 0 && last <= 0) k++; last = v; }
        return k;
    }

    static void Cap1(Action<bool, string> check, string path)
    {
        string s = "SMDAYTO2PE cap1 (Advanced, NORMAL, manual): ";
        var r = Replay(check, path, "smdayto2pe-20261118-cap1.csv.gz", s);
        check(r.At("countdown", 25) == 1 && r.CarMax("in_race", 24.5, 29) == 1 && r.CarMax("speed", 24.5, 29.3) == 0 && r.CarMax("rpm", 24.5, 29.3) > 8000,
              s + "the grid: Car_in_race and revs, standing still");
        check(r.Min("racing", 29.7, 180.2) == 1 && r.Max("racing", 180.6, r.End) == 0 && r.At("finished", r.End) == 0, s + "GO to time up");
        check(r.At("car_class", 100) == 1, s + "car class 1 (NORMAL)");
        check(r.Max("car_touch", 34.3, 34.7) == 1 && r.Max("hit", 34.3, 34.7) >= 0.5, s + "her car-hit mark at lap 1 0:05.11: a car hit");
        foreach (var (t, side, what) in new[] { (34.38, -1, "left rear, lap 1 0:05.11"), (41.97, 1, "right side, 0:13.09"), (70.57, 1, "right rear, 0:43.21"), (82.48, -1, "left rear, 0:55.74") })
            check(r.Out["hit_side"].Where(x => x.t >= t - 0.1 && x.t <= t + 0.5).Any(x => x.v == side) && !r.Out["hit_side"].Where(x => x.t >= t - 0.1 && x.t <= t + 0.5).Any(x => x.v == -side),
                  s + $"car hit {what}: side {side} from the game's roll command (Alexis)");
        check(r.Max("drift", 116.3, 118.6) > 0.4 && r.Max("drift", 116.3, 118.6) < 0.52, s + $"her right drift at lap 2 0:33.26 about 0.45: {r.Max("drift", 116.3, 118.6):0.00}");
        check(r.CarMax("throttle", 24.5, 29.3) == 1 && r.Out["rpm"].Where(x => x.t > 24.5 && x.t < 29.3).Max(x => x.v) * 8500 > 8000, s + "the grid: Car_throttle 1 so the engine follows the revs");
        check(r.Max("hit", 89.7, 90.2) == 1 && r.Max("hit", 106.7, 107.2) == 1, s + "the two big crashes");
        check(r.Min("hit_side", 44.3, 44.8) == -1 && r.Max("hit_side", 54.8, 55.3) == 1, s + "wall hits left (lap 1 0:15.65) and right (0:26.70)");
        check(r.CarMax("rpm_frac", 42, 44) > 0.99, s + $"third gear on the 8,500 limiter reads Car_rpm_frac 1 (Max revs 8500): {r.CarMax("rpm_frac", 42, 44):0.000}");
        check(r.Max("pit_stop", r.Start, r.End) == 0, s + "no pit stop");
    }

    static void Cap2(Action<bool, string> check, string path)
    {
        string s = "SMDAYTO2PE cap2 (Expert, HARD, manual): ";
        var r = Replay(check, path, "smdayto2pe-20261118-cap2.csv.gz", s);
        check(r.Min("racing", 24.5, 163.8) == 1 && r.Max("racing", 164.3, r.End) == 0, s + "GO to time up");
        check(r.At("car_class", 100) == 2, s + "car class 2 (HARD)");
        check(r.Max("hit", 42.7, 43.2) == 1 && r.Min("hit_side", 42.7, 43.2) == -1 && r.Max("hit", 43.25, 43.8) == 1 && r.Max("hit_side", 43.25, 43.8) == 1,
              s + "big crashes, left then right (lap 1 0:19.44, 0:19.98)");
        check(r.Max("car_touch", 28.9, 29.4) == 1, s + "her mark at lap 1 0:05.60: touching a car");
        check(r.Max("drift", 152.3, 154.4) > 0.97, s + $"her right drift growing to 82 degrees (lap 1 2:14.81) reads 1: {r.Max("drift", 152.3, 154.4):0.00}");
    }

    static void Cap3(Action<bool, string> check, string path)
    {
        string s = "SMDAYTO2PE cap3 (Beginner, SPECIAL, automatic): ";
        var r = Replay(check, path, "smdayto2pe-20261118-cap3.csv.gz", s);
        check(r.Min("countdown", r.Start + 0.3, 10.1) == 1 && r.CarMax("in_race", 2, 9) == 1 && r.CarMax("speed", 2, 9) > 250, s + "the rolling start: effects on (Alexis)");
        check(r.Min("racing", 10.4, 165.8) == 1 && r.Max("racing", 166.1, r.End) == 0 && r.At("finished", r.End) == 1, s + "GO to the finish line");
        check(r.At("lap", 165) == 8 && r.At("car_class", 100) == 3, s + "the eighth lap at the line; car class 3 (SPECIAL)");
        check(r.Max("pit_stop", 90, 96.7) == 0 && r.Min("pit_stop", 97.2, 107.9) == 1 && r.Max("pit_stop", 108.5, 125) == 0, s + "the pit stop: time left still");
        check(r.Max("hit", 96.9, 101) == 0, s + "no hit braking into the pit lane");
        check(Edges(r, "hit", 10.3, 165.8) > 20, s + $"hits through the race: {Edges(r, "hit", 10.3, 165.8)}");
        check(r.Max("drift", 74.3, 77) > 0.75 && r.Max("drift", 74.3, 77) < 0.9, s + $"her left drift at lap 4 0:13.54 about 0.8: {r.Max("drift", 74.3, 77):0.00}");
        check(r.Min("pit_stop", 101, 105) == 1 && r.CarMax("in_race", 101, 105) == 1, s + "effects stay on in the pit stop (Alexis)");
    }

    static void Limiters(Action<bool, string> check, string path)
    {
        string s = "SMDAYTO2PE limiters: ";
        var e = Replay(check, path, "smdayto2pe-20261118-cap4.csv.gz", s + "EASY ");
        check(e.At("car_class", 10) == 0, s + "EASY is car class 0");
        foreach (var (a, b, g) in new[] { (7.2, 8.2, "first"), (12.0, 14.0, "second"), (23.0, 25.0, "third") })
            check(e.CarMax("rpm_frac", a, b) > 0.98, s + $"EASY on the limiter in {g} reads Car_rpm_frac 1: {e.CarMax("rpm_frac", a, b):0.000}");
        var p = Replay(check, path, "smdayto2pe-20261118-cap5.csv.gz", s + "SPECIAL ");
        check(p.At("car_class", 10) == 3, s + "SPECIAL is car class 3");
        foreach (var (a, b, g) in new[] { (12.5, 14.0, "second"), (23.0, 25.0, "third") })
            check(p.CarMax("rpm_frac", a, b) > 0.9 && p.CarMax("rpm_frac", a, b) < 0.95, s + $"SPECIAL (manual) sitting at 6,990 in {g} reads Car_rpm_frac 0.91 (limit 7,650; the next recording sat at 7,800): {p.CarMax("rpm_frac", a, b):0.000}");
        var x = Replay(check, path, "smdayto2pe-20261118-cap6.csv.gz", s + "SPECIAL launch ");
        check(x.At("car_class", 20) == 3, s + "18:57 recording: SPECIAL");
        check(x.CarMax("rpm", 8.75, 9.05) == 8500 && x.Out["rpm_wheels"].Where(v => v.t > 8.75 && v.t < 9.05).Max(v => v.v) < 3700 && x.CarMax("rpm_frac", 8.75, 9.05) == 1,
              s + "the standing start: Car_rpm on the 8,500 limiter (her dial stuck at 8.2k) while the wheels' revs are under 3,700");
        foreach (var (a, b, g) in new[] { (11.6, 12.7, "first"), (15.6, 17.4, "second"), (28.6, 30.0, "third") })
            check(x.CarMax("rpm_frac", a, b) > 0.99, s + $"SPECIAL on the limiter in {g} (her marks) reads Car_rpm_frac 1: {x.CarMax("rpm_frac", a, b):0.000}");
        check(p.CarMax("rpm_frac", 28, 30) < 0.92, s + "SPECIAL in fourth, short of the limiter, reads under 1");
    }
}
