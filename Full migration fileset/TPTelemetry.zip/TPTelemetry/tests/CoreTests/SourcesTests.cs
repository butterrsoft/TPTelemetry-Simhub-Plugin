using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Expressions;
using TeknoTelemetry.Core.Outputs;
using TeknoTelemetry.Core.TeknoParrot;

static class SourcesTests
{
    public static void Run(Action<bool, string> check, Action<double, double, double, string> near)
    {
        // ---- bit functions (Initial D packs command and values into one 32-bit number)
        double E(string f, double x = 0) => Formula.Compile(f, _ => null).Evaluate(new EvalContext { Value = x });
        near(E("byte(value, 0)", 0x04017F), 0x7F, 0, "byte 0");
        near(E("byte(value, 1)", 0x04017F), 0x01, 0, "byte 1");
        near(E("byte(value, 2)", 0x04017F), 0x04, 0, "byte 2");
        near(E("byte(value, 3)", -1), 0xFF, 0, "byte of a negative int32 uses its bit pattern");
        near(E("bits(value, 4, 4)", 0xAB), 0xA, 0, "bits");
        near(E("band(value, 0x0F)", 0xAB), 0xB, 0, "band");
        near(E("bor(0xA0, 0x0B)"), 0xAB, 0, "bor");
        near(E("shr(value, 8)", 0x1234), 0x12, 0, "shr");
        near(E("shl(1, 31)"), 2147483648.0, 0, "shl to bit 31");
        near(E("signed8(0xFF)"), -1, 0, "signed8");
        near(E("signed16(0xFFFE)"), -2, 0, "signed16");
        check(Formula.IsReservedName("tp_jvs6") && Formula.IsReservedName("tp_connected") && Formula.IsReservedName("out_LampStart") &&
              !Formula.IsReservedName("tp_spring"), "tp_jvsN, tp_connected and out_ are reserved; other tp_ names are free");
        check(TpChannels.FromIdentifier("tp_jvs16") == null && TpChannels.FromIdentifier("tp_jvs06") == null, "only tp_jvs0..15");

        // ---- engine: tp_ values and outputs reach formulas, with clear statuses when missing
        var tpVals = new double[TpChannels.Count];
        var outs = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        var eng = new TelemetryEngine { TpSource = a => Array.Copy(tpVals, a, a.Length), OutputSource = n => outs.TryGetValue(n, out var v) ? v : double.NaN };
        var prof = new GameProfile { Prefix = "SRC", Variables =
        {
            new VariableDef { Name = "spring", Source = SourceKind.Computed, Formula = "tp_jvs6 / 63" },
            new VariableDef { Name = "start", Source = SourceKind.Computed, Formula = "out_LampStart" },
        } };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "SRC" });
        var ps = eng.Profiles[0];
        tpVals[6] = 63; tpVals[TpChannels.Connected] = 1;
        eng.TpSource(ps.Ctx.Tp);
        TelemetryEngine.EvaluateTick(ps, 0.01);
        near(ps.Vars[0].Output, 1, 1e-9, "tp_jvs6 read in a formula");
        check(ps.Vars[1].Status.StartsWith("No output 'LampStart'"), "missing output explained: " + ps.Vars[1].Status);
        outs["lampstart"] = 1;
        TelemetryEngine.EvaluateTick(ps, 0.02);
        near(ps.Vars[1].Output, 1, 0, "out_ names are case-insensitive");
        tpVals[TpChannels.Connected] = 0; for (int i = 0; i < 16; i++) tpVals[i] = double.NaN;
        eng.TpSource(ps.Ctx.Tp);
        TelemetryEngine.EvaluateTick(ps, 0.03);
        check(ps.Vars[0].Status == TelemetryEngine.NoTp, "no TeknoParrot data explained: " + ps.Vars[0].Status);

        // ---- outputs client against a local server speaking MAME's network protocol
        var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        int port = ((IPEndPoint)listener.LocalEndpoint).Port;
        var seen = new List<string>();
        var client = new NetOutputsClient();
        client.NewOutput += n => { lock (seen) seen.Add(n); };
        client.Apply(new OutputsSettings { Enabled = true, Host = "127.0.0.1", Port = port });
        using (var server = listener.AcceptTcpClient())
        {
            var s = server.GetStream();
            void Send(string text) { var b = Encoding.ASCII.GetBytes(text); s.Write(b, 0, b.Length); s.Flush(); }
            Send("mame_start = SegaRally3\r");
            Send("LampStart = 1\rLampView1 = 0\r");   // CR endings
            Send("LampView2 = 255\r\n");               // CR LF endings
            Send("Lamp");                              // a line split across packets
            Thread.Sleep(50);
            Send("Leader = 1\rid:LampStart\rpause = 1\r");
            Thread.Sleep(300);
            check(client.Connected && client.Game == "SegaRally3", "connected, game name from mame_start: " + client.Game);
            near(client.Get("LampStart"), 1, 0, "LampStart = 1");
            near(client.Get("lampview2"), 255, 0, "CR LF line read; names case-insensitive");
            near(client.Get("LampLeader"), 1, 0, "a line split across reads is joined");
            check(client.Paused, "pause = 1 seen");
            lock (seen) check(seen.SequenceEqual(new[] { "LampStart", "LampView1", "LampView2", "LampLeader" }), "each new output announced once: " + string.Join(",", seen));
            check(double.IsNaN(client.Get("id:LampStart")) && client.All().Count == 4, "id: lines ignored, not outputs");
            Send("mame_stop = 1\r");
            Thread.Sleep(100);
            check(client.Game == "", "mame_stop clears the game");
        }
        Thread.Sleep(300);
        check(!client.Connected, "server closing is noticed: " + client.Status);
        // reconnects to a new session, which starts with a clean set of outputs
        using (var server2 = listener.AcceptTcpClient())
        {
            var b = Encoding.ASCII.GetBytes("mame_start = InitialD8\rLampStart = 0\r");
            server2.GetStream().Write(b, 0, b.Length);
            Thread.Sleep(300);
            check(client.Game == "InitialD8" && client.All().Count == 1 && client.Get("LampStart") == 0, "reconnects; new game starts clean");
        }
        // Flycast: "game = id" first, then hexadecimal values with LF endings
        using (var server3 = listener.AcceptTcpClient())
        {
            var b = Encoding.ASCII.GetBytes("game = INITIAL D Ver.3\nmidiffb = 840001\nawffb = 1a\nlamp3 = 1\ntachometer = 1f40\n");
            server3.GetStream().Write(b, 0, b.Length);
            Thread.Sleep(300);
            check(client.Game == "INITIAL D Ver.3" && client.HexValues, "Flycast recognised from its game line");
            near(client.Get("midiffb"), 0x840001, 0, "Flycast values read as hexadecimal: midiffb 840001 = 0x840001");
            near(client.Get("awffb"), 26, 0, "awffb 1a = 26");
            near(client.Get("tachometer"), 8000, 0, "tachometer 1f40 = 8000 RPM");
            near(client.Get("lamp3"), 1, 0, "lamp3 = 1");
        }
        Thread.Sleep(300);
        using (var server4 = listener.AcceptTcpClient())
        {
            var b = Encoding.ASCII.GetBytes("mame_start = outrun\rlamp1 = 10\r");
            server4.GetStream().Write(b, 0, b.Length);
            Thread.Sleep(300);
            check(!client.HexValues && client.Get("lamp1") == 10, "a new connection that isn't Flycast reads decimal again");
        }
        client.Dispose();
        listener.Stop();
        check(!client.Connected, "client stops");
    }
}
