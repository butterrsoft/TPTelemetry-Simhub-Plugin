// Scud Race in Supermodel (SMSCUD), 18 November 2026, replayed through the pack's profile (Max speed 350, Max revs 9500).
// Alexis's recordings of 18 November 2026 (raw values worked back from the recorded rows, every second sample, her marks):
// * cap1: Porsche, manual, Beginner night, to time up (jumps marked);
// * cap3: F40, automatic, Expert, with a pit stop (marked in and out), to time up;
// * cap4: Viper, manual, Beginner night, to the finish line (jumps marked);
// * cap5: F40, manual, Beginner night, 29 s of car hits and walls she listed in order (13:30).
// And RAM logs from the same Supermodel source as her supermodel.exe (git 0b82a98), with a logger added, running her ROM
// set (`scudau`) on the Beginner course with an autopilot. Each holds the memory rows' raw values (t = frame / 57.524 s):
// * finish: the attract mode, the menus, the rolling start, four laps to the finish line and back to the attract mode
//   (extra time poked in so the autopilot could finish), every third frame;
// * timeup: a race from GO to time up and the attract mode, every second frame;
// * leftwall: the car pinned against the left barrier at about 100 km/h, every second frame.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;

static class ScudTests
{
    public static void Run(Action<bool, string> check, string pack)
    {
        if (string.IsNullOrEmpty(pack)) return;
        var path = Directory.GetFiles(pack, "SMSCUD.json", SearchOption.AllDirectories).FirstOrDefault();
        if (path == null) return;
        Finish(check, path);
        TimeUp(check, path);
        LeftWall(check, path);
        Cap4(check, path);
        Cap1(check, path);
        Cap3(check, path);
        Cap5(check, path);
    }

    sealed class R
    {
        public Dictionary<string, List<(double t, double v)>> Out, Car;
        public double At(string n, double t) => Out[n].First(x => x.t >= t).v;
        public double Max(string n, double a, double b) => Out[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        public double Min(string n, double a, double b) => Out[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Min();
        public double CarMax(string n, double a, double b) => Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        public double CarMin(string n, double a, double b) => Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Min();
        public double End => Out["speed"].Last().t;
        public List<double> Marks = new List<double>();
        // the recording time where the race clock first reaches a TT (seconds)
        public double T(double tt) => Out["race_clock"].Zip(Out["racing"], (c, g) => (c, g)).Select((p, i) => (p, i)).First(x => x.p.g.v == 1 && x.p.c.v >= tt).p.c.t;
        public double Start => Out["speed"].First().t;
    }

    static R Replay(Action<bool, string> check, string path, string fixture, string s)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = "";
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "SMSCUD" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), s + "rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
        ps.Connected = true;
        var r = new R { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()),
                        Car = CommonValues.Outputs.ToDictionary(o => o.Name, o => new List<(double t, double v)>()) };
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            var head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null)
            {
                var f = line.Split(',');
                double P(int i) => f[i].Length == 0 ? double.NaN : double.Parse(f[i], CultureInfo.InvariantCulture);
                double t = P(0);
                if (f[1].Length > 0) r.Marks.Add(t);
                for (int i = 2; i < head.Length; i++)
                    if (feeds.TryGetValue(head[i], out var feed)) feed.Value = P(i);
                TelemetryEngine.EvaluateTick(ps, t);
                foreach (var v in ps.Vars) r.Out[v.Def.Name].Add((t, v.Output));
                eng.Common.Update(ps, t);
                foreach (var o in CommonValues.Outputs) r.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            }
        }
        return r;
    }

    // Frames: the rolling start's camera shots from 3763 (65.42 s), the driver's view and 3-2-1 from 4123 (71.68 s), GO at
    // 4371 (75.99 s), lap lines at 6499, 8923, 10955 (112.98, 155.12, 190.44 s), the finish line at 13017 (226.29 s), the
    // race clock stopping at 8647 frames (2:31.70); the attract mode's demo race after that. A hard hit on the left at 6800
    // (118.21 s), 299 to 205 km/h.
    static void Finish(Action<bool, string> check, string path)
    {
        string s = "SMSCUD finish: ";
        var r = Replay(check, path, "smscud-emu-20261118-finish.csv.gz", s);
        double end = r.End;
        check(r.Max("racing", r.Start, 71.6) == 0 && r.Min("racing", 71.8, 226.2) == 1 && r.Max("racing", 226.6, end) == 0,
              s + "racing from the 3-2-1 countdown (the driver's view) to the finish line; not in the attract mode, menus or camera shots");
        check(r.CarMax("in_race", 226.6, end) == 0 && r.CarMax("speed", 226.6, end) == 0 && r.CarMax("speed", 120, 121) > 100,
              s + "Car_in_race and Car_speed 0 after the line, though the attract demo's car drives on");
        check(r.At("countdown", 72) == 1 && r.At("countdown", 76.2) == 0 && r.At("phase", 66) == 3 && r.At("phase", 72) == 4, s + "countdown and phase");
        check(Math.Abs(r.At("race_clock", 230) - 8647 / 57.0) < 0.01 && Math.Abs(r.At("race_clock", 76.0)) < 0.1,
              s + $"race clock from GO, stopped at 2:31.70 at the line: {r.At("race_clock", 230):0.00}");
        check(Math.Abs(r.At("rt", 72) - 60) < 0.01, s + "60 s on the clock in the countdown");
        check(r.At("lap", 100) == 1 && r.At("lap", 130) == 2 && r.At("lap", 170) == 3 && r.At("lap", 200) == 4, s + "laps 1 to 4");
        foreach (double m in new[] { 112.98, 155.12, 190.44 })
            check(r.Max("time_extended", m - 0.2, m + 0.3) == 1 && r.At("time_extended", m - 0.5) == 0 && r.At("time_extended", m + 2.5) == 0,
                  s + $"TIME EXTENSION! for 2 s at the lap line ({m:0.00} s)");
        check(r.Max("time_extended", r.Start, 112.5) == 0, s + "no time extension at the start, where the time is first set");
        check(Math.Abs(r.At("lap_time", 112.9) - 37.0) < 0.6 && r.At("lap_time", 113.2) < 0.5 && Math.Abs(r.At("best_lap", 120) - 2129 / 57.0) < 0.01,
              s + $"lap clock back to 0 at the line; best lap 37.35 s after the first: {r.At("lap_time", 112.9):0.00} {r.At("best_lap", 120):0.00}");
        check(r.At("position", 72) == 40 && r.Min("position", 76, 226) >= 15 && r.Max("position", 76, 226) <= 40, s + "40th at the start, then 15th to 40th");
        check(r.Max("hit", 118.0, 118.6) == 1 && r.Min("hit_side", 118.0, 118.6) == -1,
              s + $"the big crash at 118.2 s reads 1 and on the left: {r.Max("hit", 118.0, 118.6):0.00}");
        check(r.CarMax("impact", 118.0, 118.6) == 1, s + "Car_impact at the crash");
        check(r.Max("car_touch", 78.8, 79.1) == 1 && r.Max("car_side", 78.8, 79.1) == 1 && r.Min("car_side", 82.3, 82.6) == -1
              && r.Max("car_touch", r.Start, 71) == 0, s + "touching cars: on the right at 78.8 s, the left at 82.4 s; none before the race");
        check(r.Max("near_car", 76, 226) == 1, s + "another car near");
        double over = r.Out["rpm"].Where(x => x.t > 76 && x.t < 226).Max(x => x.v) * 9500;
        check(over > 6800 && over < 7500 && r.Out["gear"].Where(x => x.t > 76 && x.t < 226).Max(x => x.v) == 4, s + $"revs up to {over:0} and 4th gear");
        var ang = r.Out["drift_angle"].Where(x => x.t > 76 && x.t < 226).Select(x => Math.Abs(x.v)).OrderBy(x => x).ToArray();
        check(ang[ang.Length / 2] < 6 && ang[(int)(ang.Length * 0.99)] < 45, s + $"drift angle: median {ang[ang.Length / 2]:0.0}, 99th percentile {ang[(int)(ang.Length * 0.99)]:0.0} degrees");
    }

    // A race from GO at 15083 (262.20 s) to time up at 20175 (350.73 s), with the race clock stopping at 5092 frames
    // (1'29"33 on the result screen), then the attract mode. Hard hits at 16458 (left), 18732 and 19351 (left).
    static void TimeUp(Action<bool, string> check, string path)
    {
        string s = "SMSCUD time up: ";
        var r = Replay(check, path, "smscud-emu-20261118-timeup.csv.gz", s);
        double end = r.End;
        check(r.Min("racing", 262.4, 350.6) == 1 && r.Max("racing", 351.0, end) == 0, s + "racing to time up, then nothing in the attract mode");
        check(Math.Abs(r.At("race_clock", 355) - 5092 / 57.0) < 0.01 && Math.Abs(r.At("race_clock", 355) - 89.33) < 0.01, s + "TT 1'29\"33 as the result screen shows");
        check(r.At("rt", 355) == 0, s + "time left 0 at time up");
        check(r.Max("hit", 286.0, 286.5) == 1 && r.Min("hit_side", 286.0, 286.5) == -1 && r.Max("hit", 336.1, 336.7) == 1, s + "big crashes on the left at 286.1 and 336.4 s");
        check(r.CarMax("speed", 351.5, end) == 0 && r.Max("speed", 351.5, end) > 0, s + "Car_speed 0 after time up, though the car still rolls");
    }

    // The car pinned against the left barrier (autopilot steering the wrong way), GO at 11456 (199.15 s).
    static void LeftWall(Action<bool, string> check, string path)
    {
        string s = "SMSCUD left wall: ";
        var r = Replay(check, path, "smscud-emu-20261118-leftwall.csv.gz", s);
        var w = r.Out["wall_contact"].Where(x => x.t > 202 && x.t < r.End).Select(x => x.v).ToArray();
        double left = w.Count(x => x == -1) / (double)w.Length, right = w.Count(x => x == 1) / (double)w.Length;
        check(left > 0.4 && right < 0.05, s + $"wall contact on the left for {left:P0} of the time, right {right:P0}");
        check(r.CarMin("wall_contact", 202, r.End) == -1, s + "Car_wall_contact -1");
    }

    // Alexis's Viper recording (manual, Beginner night): the rolling start's 3-2-1 from 7.90 s, GO at 14.80 s, lap lines at
    // 45.93, 77.45, 109.10 s, the finish line at 146.29 s (TT 2:18.42, 21st); jumps marked at 36.43, 67.78, 99.58 s.
    static void Cap4(Action<bool, string> check, string path)
    {
        string s = "SMSCUD Viper (Alexis, 12:21): ";
        var r = Replay(check, path, "smscud-20261118-cap4.csv.gz", s);
        double end = r.End;
        check(r.Marks.Count == 3, s + $"three marks: {r.Marks.Count}");
        check(r.Max("racing", r.Start, 7.8) == 0 && r.Min("racing", 8.0, 146.25) == 1 && r.Max("racing", 146.4, end) == 0,
              s + "racing from the rolling start's 3-2-1 to the finish line, then nothing");
        check(Math.Abs(r.At("race_clock", 147) - 138.42) < 0.02, s + $"TT 2:18.42 at the line: {r.At("race_clock", 147):0.00}");
        check(r.At("finished", 147) == 1 && r.At("final_position", 147) == 21 && r.At("finished", 100) == 0, s + "finished, 21st");
        check(r.At("lap", 30) == 1 && r.At("lap", 60) == 2 && r.At("lap", 90) == 3 && r.At("lap", 120) == 4, s + "laps 1 to 4");
        foreach (double m in new[] { 45.95, 77.46, 109.12 })
            check(r.Max("time_extended", m - 0.1, m + 0.3) == 1 && r.At("time_extended", m + 2.5) == 0, s + $"time extended at the lap line ({m:0.00} s)");
        foreach (double m in r.Marks)
            check(r.Max("airborne", m - 0.5, m + 0.5) == 1 && r.CarMax("airborne", m - 0.5, m + 0.5) == 1, s + $"airborne at her jump mark ({m:0.00} s)");
        check(r.Max("airborne", r.Start, 14.8) == 0 && r.Max("airborne", 146.4, end) == 0, s + "never airborne outside the race");
        double top = r.Out["rpm"].Where(x => x.t > 15 && x.t < 146).Max(x => x.v) * 9500;
        check(Math.Abs(top - 7200) < 1, s + $"revs to the Viper's 7200 limiter: {top:0}");
        check(r.Max("wrong_way", 15, 146) == 0, s + "never the wrong way");
        check(r.CarMax("speed", 146.4, end) == 0, s + "Car_speed 0 after the line");
    }

    // Alexis's Porsche recording (manual, Beginner night), to time up at 141.50 s (TT 1:53.33, 33rd); her first mark (55.87 s)
    // is a jump; a big crash at 121.13 s (TT 1:31.88).
    static void Cap1(Action<bool, string> check, string path)
    {
        string s = "SMSCUD Porsche (Alexis, 12:09): ";
        var r = Replay(check, path, "smscud-20261118-cap1.csv.gz", s);
        double end = r.End;
        check(r.Max("racing", r.Start, 29.0) == 0 && r.Min("racing", 29.2, 141.45) == 1 && r.Max("racing", 141.6, end) == 0,
              s + "racing from the rolling start's 3-2-1 to time up");
        check(r.At("finished", 143) == 0 && r.At("final_position", 143) == 33 && r.At("rt", 143) == 0, s + "time up, 33rd");
        check(r.Max("airborne", r.Marks[0] - 0.5, r.Marks[0] + 0.5) == 1, s + "airborne at the first jump mark");
        check(r.Max("hit", 121.0, 121.5) == 1, s + "the big crash at TT 1:31.88");
        double lt = r.T(63.3);
        check(r.Max("light", lt - 0.2, lt + 0.8) == 1 && r.Max("airborne", lt - 0.2, lt + 0.8) == 0 && Math.Abs(r.CarMax("airborne", lt - 0.2, lt + 0.8) - 0.5) < 1e-9,
              s + "TT 1:03.3, only the front wheels off the ground: light (Car_airborne 0.5), not airborne");
        double rv = r.T(95.14);
        check(r.Max("wrong_way", rv - 0.3, rv + 0.3) == 1, s + "REVERSE! on screen at TT 1:35.14 (Alexis)");
    }

    // Alexis's F40 recording (automatic, Expert): GO at 18.35 s, checkpoints, a pit stop (in about 84.3 s, out about 99.6 s,
    // marked three times each), time up at 159.10 s (TT 2:28.18, 20th).
    static void Cap3(Action<bool, string> check, string path)
    {
        string s = "SMSCUD F40 (Alexis, 12:14): ";
        var r = Replay(check, path, "smscud-20261118-cap3.csv.gz", s);
        check(r.Max("racing", r.Start, 18.2) == 0 && r.Min("racing", 18.5, 159.0) == 1, s + "racing from GO (standing start) to time up, through the pit stop");
        check(r.Min("pit_stop", 85, 98) == 1 && r.Max("pit_stop", 20, 82.5) == 0 && r.Max("pit_stop", 100, 159) == 0, s + "pit stop while the time stands still");
        foreach (double m in new[] { 35.39, 50.64, 117.25, 135.59 })
            check(r.Max("time_extended", m - 0.1, m + 0.3) == 1, s + $"time extended at the checkpoint ({m:0.00} s)");
        check(r.At("final_position", 161) == 20 && r.At("finished", 161) == 0, s + "time up, 20th");
        // Alexis, 18 November 2026: the drift at TT 0:39.33 should read about 0.9, at 1:40.30 about 0.65
        double d1 = r.At("drift", r.T(39.33)), d2 = r.At("drift", r.T(100.30));
        check(Math.Abs(d1 - 0.9) < 0.03 && Math.Abs(d2 - 0.65) < 0.03, s + $"Car_drift 0.9 at TT 0:39.33 and 0.65 at 1:40.30: {d1:0.00} {d2:0.00}");
        // the grid before GO (standing start, 13.44 to 18.35 s): Car_in_race and revs, nothing else
        check(r.At("grid", 16) == 1 && r.At("racing", 16) == 0 && r.Car["in_race"].First(x => x.t >= 16).v == 1 && r.CarMax("speed", 14, 18.2) == 0
              && r.CarMax("rpm", 14, 18.2) > 500 && r.At("grid", 20) == 0, s + "on the grid: Car_in_race and Car_rpm, no speed");
        check(r.Car["throttle"].First(x => x.t >= 16).v == 1, s + "Car_throttle 1 on the grid, so the engine follows the revs alone (Alexis)");
    }

    // Alexis's F40 recording (manual, Beginner night, 13:30): in order, up the back of the car in front, a car on her left,
    // right, left, the left-hand wall with a big crash and a flip, the right-hand verge and wall slowly, the left-hand wall
    // twice, the right-hand wall.
    static void Cap5(Action<bool, string> check, string path)
    {
        string s = "SMSCUD F40 (Alexis, 13:30): ";
        var r = Replay(check, path, "smscud-20261118-cap5.csv.gz", s);
        double Tt(double x) => r.T(x);
        check(r.Max("car_touch", Tt(1.0), Tt(1.3)) == 1 && r.Max("hit", Tt(1.0), Tt(1.5)) > 0.9 && r.Max("car_side", Tt(1.0), Tt(1.3)) == 0,
              s + "up the back of the car in front (TT 0:01.07): a hard hit, no side");
        check(r.Min("car_side", Tt(2.6), Tt(3.1)) == -1 && r.Max("car_side", Tt(4.4), Tt(4.9)) == 1 && r.Min("car_side", Tt(5.6), Tt(5.9)) == -1,
              s + "cars on her left (0:02.68), right (0:04.49), left (0:05.63)");
        check(r.Max("hit", Tt(2.6), Tt(2.9)) >= 0.5 && r.Min("hit_side", Tt(2.6), Tt(2.9)) == -1 && r.Max("hit_side", Tt(4.4), Tt(4.7)) == 1,
              s + "the side contacts read as hits with their side");
        check(r.Max("hit", Tt(6.4), Tt(6.8)) == 1 && r.Min("hit_side", Tt(6.4), Tt(6.8)) == -1, s + "the big crash on the left-hand wall (0:06.47)");
        check(r.Min("wall_contact", Tt(15.8), Tt(16.3)) == -1 && r.Min("wall_contact", Tt(20.6), Tt(21.1)) == -1 && r.Max("wall_contact", Tt(26.4), Tt(26.9)) == 1,
              s + "left-hand wall twice, then the right-hand wall");
        double lim = r.T(15.30);
        check(Math.Abs(r.Max("rpm_frac", lim - 0.3, lim + 0.3) - 1) < 0.01, s + $"the F40 on its 9040 limiter at TT 0:15.30 reads rpm_frac 1: {r.Max("rpm_frac", lim - 0.3, lim + 0.3):0.000}");
    }
}
