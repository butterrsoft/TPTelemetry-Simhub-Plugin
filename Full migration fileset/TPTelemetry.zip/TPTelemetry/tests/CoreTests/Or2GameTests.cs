using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Replay = Wmmt5ReplayTests.Replay;
using static Wmmt3GameTests;

/// <summary>
/// Replays Alexis's OutRun 2 SP recording of 11 November 2026 (19:06; OutRun mode, manual, five stages to the goal)
/// through the OUTRUN2SP profile's rows read from the game's own variables (`jennifer`). The fixture holds each memory
/// row in the game's units (converted back from the recorded rows). Start sequence (13) from 21.2 s, GO 34.18 s, stage
/// gates 96.83, 157.95, 219.38 and 277.36 s, finish line 331.90 s (her mark 332.07), then the menus and the title.
/// Traffic crashes at 108.0 and 182.6 s, a wall crash at 296.4 s; 15 drifts.
/// </summary>
static class Or2GameTests
{
    /// <summary>
    /// 12 November 2026, 10:05: OutRun mode, a six-speed car, lots of traffic hits, USB capture on. The side of each car hit
    /// from the game's own contact words (car_side) against the wheel force's push (not fed here, so the replay shows the
    /// game alone): left at 40.04, 45.32, 74.85, 98.92 and 114.63 s; right at 42.30, 81.93, 105.26, 109.97 and 115.29 s.
    /// The hit at 92.88 s (306 km/h, -33 km/h, no push) only the side code caught.
    /// </summary>
    /// <summary>
    /// 12 November 2026, 10:09: Time Attack (250 GTO) from GO at 52.30 s to time up at 154.22 s; the attract mode (187.8 to
    /// 310.6 s, the demo car driving); Heart Attack (512 BB) from 347.40 s, with two challenges won (172 hearts at 383.40 s,
    /// 225 more at 396.08 s). Redline lights in 2nd at TT 0:05.996 (GTO) and 0:06.328 (BB), per Alexis's video.
    /// </summary>
    static void Modes(Action<bool, string> check, Replay r)
    {
        check(r.At("game_mode", 100) == 0 && r.At("game_mode", 360) == 2, "OR2 10:09: game_mode 0 in Time Attack, 2 in Heart Attack");
        var on = r.Car["in_race"].Where(x => x.v > 0).Select(x => x.t).ToList();
        check(on.First() > 52.2 && on.First() < 52.4 && on.Where(t => t < 200).Max() < 154.3 && on.Where(t => t > 200).Min() > 347.3 && on.Where(t => t > 200).Min() < 347.5,
              "OR2 10:09: Car_in_race from GO to time up in Time Attack, and from GO in Heart Attack");
        check(CarMax(r, "in_race", 160, 340) == 0 && CarMax(r, "speed", 187.8, 310.6) == 0 && CarMax(r, "rpm", 187.8, 310.6) == 0 && CarMax(r, "gear", 187.8, 310.6) == 0,
              "OR2 10:09: the attract mode's demo car gives no Car_speed, Car_rpm or Car_gear (Alexis: 0, like the effects)");
        check(r.Max("speed_kmh", 187.8, 310.6) > 200, "OR2 10:09: the demo car is driving (speed_kmh still reads it)");
        check(r.At("hearts", 383.0) == 0 && r.At("hearts", 384.0) == 172 && r.At("hearts", 397.0) == 397, "OR2 10:09: hearts 0, 172, 397 (x 10,000 in the game)");
        check(r.Max("challenge_won", 383.3, 384.4) == 1 && r.Max("challenge_won", 396.0, 397.1) == 1 && r.Max("challenge_won", 347, 383.3) == 0,
              "OR2 10:09: challenge_won at each challenge's hearts");
        check(r.At("shift_light", 60.247) == 1 && r.At("shift_light", 60.149) == 0 && r.At("shift_light", 355.681) == 1 && r.At("shift_light", 355.583) == 0,
              "OR2 10:09: 250 GTO and 512 BB shift_light at TT 0:05.996 and 0:06.328 in 2nd");
        check(CarMax(r, "impact_side", 372.1, 372.4) == 1 && CarMin(r, "impact_side", 407.3, 407.6) == -1, "OR2 10:09: Heart Attack car hits: right at 372.13 s, left at 407.37 s");
    }

    static void Traffic(Action<bool, string> check, Replay r)
    {
        foreach (var (t, side) in new[] { (40.04, -1.0), (42.30, 1.0), (45.32, -1.0), (74.85, -1.0), (81.93, 1.0), (98.92, -1.0),
                                          (105.26, 1.0), (109.97, 1.0), (114.63, -1.0), (115.29, 1.0) })
        {
            double s = r.Car["impact_side"].Where(x => x.t >= t && x.t <= t + 0.2).Select(x => x.v).FirstOrDefault(v => v != 0);
            check(s == side && CarMax(r, "impact", t, t + 0.2) >= 0.5,
                  $"OR2 10:05: car hit at {F(t)} s on the {(side > 0 ? "right" : "left")} without USB: Car_impact_side {F(s)}");
        }
        check(CarMax(r, "impact", 92.85, 93.2) >= 0.5, "OR2 10:05: the hit at 92.88 s (side code only) reads as a hit");
        // the Enzo's redline light in 2nd: on at TT 0:05.863 (Alexis's video)
        check(r.At("shift_light", 17.766) == 1 && r.At("shift_light", 17.674) == 0, "OR2 10:05: Enzo shift_light at TT 0:05.863");
    }

    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "OUTRUN2SP");
        if (gamePackDir == null || !File.Exists(path)) return;
        Traffic(check, Wmmt3GameTests.Run(check, path, "or2-20261112-100526.csv.gz", "OUTRUN2SP"));
        Modes(check, Wmmt3GameTests.Run(check, path, "or2-20261112-100900.csv.gz", "OUTRUN2SP"));
        var r = Wmmt3GameTests.Run(check, path, "or2-20261111-190631.csv.gz", "OUTRUN2SP");

        var on = r.Car["in_race"].Where(x => x.v > 0).Select(x => x.t).ToList();
        check(on.Count > 0 && Math.Abs(on.First() - 34.18) < 0.05 && Math.Abs(on.Last() - 331.89) < 0.05,
              $"OR2 19:06: Car_in_race from GO to the finish line ({F(on.FirstOrDefault())} to {F(on.LastOrDefault())}; 34.18 and 331.90)");
        check(CarMax(r, "in_race", 21.0, 34.1) == 0 && CarMax(r, "in_race", 332.0, r.End) == 0, "OR2 19:06: no effects in the start sequence or after the line");

        double top = r.Car["speed"].Max(x => x.v);
        check(top > 305 && top < 320 && r.Car["speed_frac"].Max(x => x.v) == 1, $"OR2 19:06: Car_speed is the speedo's km/h (top {F(top)}, Max speed 280)");

        var stages = new[] { 96.83, 157.95, 219.38, 277.36 };
        check(stages.Select((t, i) => r.At("stage", t + 0.1) == i + 2 && r.Max("checkpoint", t, t + 0.5) == 1).All(x => x),
              "OR2 19:06: stage 2 to 5 and a checkpoint at each gate");

        foreach (var (t, len, kind) in new[] { (108.01, 1.5, 7.0), (182.63, 1.5, 7.0), (296.41, 2.5, 1.0) })
        {
            double end = r.Out["crash_motion"].Where(x => x.t > t && x.v == 0).Select(x => x.t).FirstOrDefault();
            check(r.Max("crash_motion", t, t + 0.1) == 1 && Math.Abs(end - t - len) < 0.1 && r.Max("crash_kind", t, t + 0.2) == kind,
                  $"OR2 19:06: crash motion at {F(t)} s for {F(end - t)} s (about {F(len)}), kind {r.Max("crash_kind", t, t + 0.2)}");
        }
        check(CarMax(r, "impact", 296.4, 296.7) == 1, "OR2 19:06: Car_impact 1 at the wall crash (267 to 72 km/h)");

        foreach (var t in new[] { 93.31, 133.10, 144.68, 174.92, 192.31, 225.78, 250.71, 289.91 })
            check(CarMax(r, "drift", t, t + 2.0) > 0.9, $"OR2 19:06: Car_drift in the drift from {F(t)} s");
        // Alexis: right turns at 93.31 and 225.78 s, left turns at 133.10 and 285.43 s
        check(r.Max("drift_angle", 93.3, 97.3) > 50 && r.Min("drift_angle", 133.1, 136.2) < -50 && r.Max("drift_angle", 225.8, 232.1) > 50
              && r.Min("drift_angle", 285.4, 287.9) < -50, "OR2 19:06: right-hand drifts read +, left-hand -");
        // crash motions: rear wheels up at the truck and the bus (0.5), flying and flipping at the wall (1)
        check(CarMax(r, "airborne", 108.0, 108.5) == 0.5 && CarMax(r, "airborne", 108.7, 110) == 0 && CarMax(r, "airborne", 182.6, 183.1) == 0.5
              && CarMin(r, "airborne", 296.5, 298.8) == 1 && CarMax(r, "airborne", 34.2, 108.0) == 0,
              "OR2 19:06: Car_airborne 0.5 as the rear lifts at the truck and bus, 1 through the flip");
        // the fork's "easy" arrow at 83.63 s; nothing at the other flag (48.30 s)
        check(r.Max("fork_sign", 83.6, 84.0) == 1 && r.Max("fork_sign", 40, 83.5) == 0, "OR2 19:06: fork_sign at the easy arrow (83.63 s)");
        // the redline light (Testarossa): she saw it at TT 0:07.375 (8,370 RPM in third); 8,270 lights it 0.1 s sooner
        check(r.At("shift_light", 43.496) == 1 && r.Max("shift_light", 43.0, 43.33) == 0, "OR2 19:06: shift_light on by TT 0:07.375, off at 0:07.20");
        // nothing outside the race: Car_speed and Car_rpm 0 in the menus after the line (Alexis, 12 November 2026)
        check(CarMax(r, "speed", 332.0, r.End) == 0 && CarMax(r, "rpm", 332.0, r.End) == 0, "OR2 19:06: Car_speed and Car_rpm 0 after the line");
        // Car_drift full at 75 degrees for OutRun (other games 50): a 60-degree drift reads about 0.95, a 78-degree one 1
        double d60 = CarMax(r, "drift", 285.4, 287.9), d78 = CarMax(r, "drift", 114.3, 121.6);
        check(d60 > 0.9 && d60 < 0.99 && d78 == 1, $"OR2 19:06: Car_drift graded to 75 degrees: {F(d60)} at 60, {F(d78)} at 78");
        check(r.Out["drift_angle"].Zip(r.Out["speed_kmh"], (a, s) => s.v <= 10 && a.v != 0).All(x => !x), "OR2 19:06: no slip angle under 10 km/h");
    }
}
