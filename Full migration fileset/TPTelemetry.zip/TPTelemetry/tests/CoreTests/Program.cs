using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Expressions;

static class Program
{
    static int _pass, _fail;

    static void Check(bool ok, string what)
    {
        if (ok) _pass++; else { _fail++; Console.WriteLine("FAIL: " + what); }
    }
    static void Near(double a, double b, double tol, string what) => Check(Math.Abs(a - b) <= tol, $"{what}: got {a}, expected {b} ±{tol}");

    static double Eval(string f, double value = 0, Dictionary<string, double> vars = null)
    {
        var names = vars?.Keys.ToList() ?? new List<string>();
        var fx = Formula.Compile(f, n => names.IndexOf(n) is var i && i >= 0 ? i : (int?)null);
        var ctx = new EvalContext { Value = value, Slots = names.Select(n => vars[n]).ToArray() };
        return fx.Evaluate(ctx);
    }

    static string CompileError(string f)
    {
        try { Formula.Compile(f, n => n == "speed" ? 0 : (int?)null); return null; }
        catch (FormulaException e) { return e.Message; }
    }

    static int Main()
    {
        CheatTable();
        CheatTableOffsetOrder();
        Expressions();
        TimeSeries();
        Engine();
        References();
        Launch();
        CommonValuesTests.Run(Check, Near);
        SimHubProfilesTests.Run(Check);
        PointerWalk();
        Store();
        ProfileCheck.Run(Check);
        ActiveGame();
        Dummy();
        FfbTests.Run(Check, Near);
        WheelDecoderTests.Run(Check, Near);
        FfbCaptureTests.Run(Check, Near);
        RecorderTests.Run(Check);
        SourcesTests.Run(Check, Near);
        RemoteTests.Run(Check, Near);
        ProfilesTests.Run(Check, Near, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        MemProfilesTests.Run(Check, Near, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        Bg4Tests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        Mk118Tests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        FfbFormulaTests.Run(Check);
        FfbRowsTests.Run(Check);
        Wmmt5ReplayTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        Wmmt3ReplayTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        Wmmt3GameTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        Or2ReplayTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        Or2GameTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        Sr3ReplayTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        Wmmt5OutputsReplayTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        SwdcReplayTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        GridReplayTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        GtiClubTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        Id6Tests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        Id0Tests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        Fly3Tests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        ScudTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        D2peTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        TableOrderTests.Run(Check, Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS")?.Split(';')[0]);
        Console.WriteLine($"\n{_pass} passed, {_fail} failed");
        return _fail == 0 ? 0 : 1;
    }

    static void CheatTable()
    {
        var r = CheatTableImporter.ImportFile("sample.CT");
        var p = r.Profile;
        Check(p.ProcessName == "Game.exe", "process inferred from the .exe entries, got " + p.ProcessName);
        Check(p.Prefix == "sample", "prefix from file name, got " + p.Prefix);
        Check(p.Variables.Count == 8, "8 entries imported, got " + p.Variables.Count);

        var s1 = p.Variables.Single(v => v.Name == "speed_a");
        Check(s1.Module == "Game.exe" && s1.BaseOffset == "106A79C" && s1.Offsets == "24" && s1.Type == MemType.Float && s1.Enabled,
            $"speed-a parsed: {s1.Module}+{s1.BaseOffset} [{s1.Offsets}] {s1.Type}");
        var sb = p.Variables.Single(v => v.Name == "speed_b");
        Check(sb.Module == "Helper.dll" && sb.BaseOffset == "3A63CB4" && sb.Offsets == "EC", "DLL-relative entry parsed");
        Check(p.Variables.Single(v => v.Name == "gear_a").Type == MemType.Int32, "4 Bytes -> Int32");

        var abs = p.Variables.Where(v => v.Module == "").ToList();
        Check(abs.Count == 3 && abs.All(v => !v.Enabled), "3 absolute addresses imported disabled");
    }

    static void CheatTableOffsetOrder()
    {
        var xml = @"<CheatTable><CheatEntries><CheatEntry><Description>""deep""</Description><VariableType>Float</VariableType>
            <Address>""game.exe""+1000</Address><Offsets><Offset>C</Offset><Offset>8</Offset><Offset>4</Offset></Offsets></CheatEntry>
            <CheatEntry><Description>""grp""</Description><CheatEntries><CheatEntry><Description>""child""</Description>
            <VariableType>Double</VariableType><Address>other.dll+20</Address></CheatEntry></CheatEntries></CheatEntry>
            <CheatEntry><Description>""sym""</Description><VariableType>Float</VariableType><Address>[game.exe+10]+4</Address></CheatEntry>
            <CheatEntry><Description>""str""</Description><VariableType>String</VariableType><Address>game.exe+10</Address></CheatEntry>
            </CheatEntries></CheatTable>";
        var r = Import(xml);
        var deep = r.Profile.Variables.Single(v => v.Name == "deep");
        Check(deep.Offsets == "4, 8, C", "CE offsets reversed into application order, got " + deep.Offsets);
        Check(r.Profile.Variables.Any(v => v.Name == "child" && v.Module == "other.dll" && v.Type == MemType.Double), "nested group entries imported");
        Check(r.Profile.Variables.Count == 2 && r.Warnings.Count == 2, "symbolic address and String type skipped with warnings");
    }

    static ImportResult Import(string xml) => CheatTableImporter.Import(xml, "t");

    static void Expressions()
    {
        Near(Eval("1 + 2 * 3"), 7, 0, "precedence");
        Near(Eval("(1 + 2) * 3"), 9, 0, "parens");
        Near(Eval("-2 ^ 2"), -4, 0, "unary minus binds looser than ^");
        Near(Eval("2 ^ 3 ^ 2"), 512, 0, "^ right associative");
        Near(Eval("value * 3.6", 10), 36, 1e-12, "value");
        Near(Eval("x / 2", 10), 5, 0, "x alias");
        Near(Eval("speed / 3.6", 0, new Dictionary<string, double> { ["speed"] = 36 }), 10, 1e-12, "variable reference");
        Near(Eval("value > 5 ? 1 : -1", 6), 1, 0, "ternary");
        Near(Eval("if(value == 3, 10, 20)", 3), 10, 0, "if()");
        Near(Eval("clamp(value, 0, 100)", 150), 100, 0, "clamp");
        Near(Eval("round(1.23456, 2)"), 1.23, 1e-12, "round digits");
        Near(Eval("max(1, 5, 3)"), 5, 0, "max varargs");
        Near(Eval("map(value, 0, 255, -1, 1)", 255), 1, 1e-12, "map");
        Near(Eval("deadzone(value, 0.1)", 0.05), 0, 0, "deadzone");
        Near(Eval("valid(value, 7)", double.NaN), 7, 0, "valid");
        Near(Eval("0x10 + 1e2"), 116, 0, "hex and exponent literals");
        Near(Eval("!0 && (1 || 0)"), 1, 0, "logic");
        Near(Eval("g"), 9.80665, 1e-12, "g constant");

        Check(CompileError("1 +") != null, "trailing operator rejected");
        Check(CompileError("foo + 1")?.Contains("Unknown variable 'foo'") == true, "unknown variable: " + CompileError("foo + 1"));
        Check(CompileError("slope(speed)")?.Contains("takes 2 arguments") == true, "arity: " + CompileError("slope(speed)"));
        Check(CompileError("speed = 1")?.Contains("==") == true, "single = gives a hint");
        Check(CompileError("abs(speed") != null, "unclosed paren");
        Check(CompileError("ema(slope(speed, 0.1), 0.05) / 3.6 / g") == null, "accel template compiles");
    }

    /// Speed rising at 36 km/h per second (10 m/s², 1.0197 G). The game updates it at 60 Hz,
    /// we sample at 120 Hz with jitter, so half the samples repeat. The derived G must be steady.
    static void TimeSeries()
    {
        var f = Formula.Compile("ema(slope(speed, 0.1), 0.05) / 3.6 / g", n => n == "speed" ? 0 : (int?)null);
        var raw2pt = Formula.Compile("rate(speed) / 3.6 / g", n => n == "speed" ? 0 : (int?)null);
        var ctx = new EvalContext { Slots = new double[1] };
        var rnd = new Random(1);
        double t = 0, prevT = 0, last = 0, maxDev = 0, maxDevRaw = 0;
        for (int i = 0; i < 600; i++)
        {
            t += 1.0 / 120 + (rnd.NextDouble() - 0.5) * 0.004; // ±2 ms jitter
            double gameT = Math.Floor(t * 60) / 60;              // 60 Hz game updates
            ctx.Slots[0] = 50 + 36 * gameT;
            ctx.T = t; ctx.Dt = i == 0 ? 0 : t - prevT; prevT = t;
            last = f.Evaluate(ctx);
            var r = raw2pt.Evaluate(ctx);
            if (t > 0.5) { maxDev = Math.Max(maxDev, Math.Abs(last - 1.0197)); maxDevRaw = Math.Max(maxDevRaw, Math.Abs(r - 1.0197)); }
        }
        Near(last, 36 / 3.6 / 9.80665, 0.06, "accel G from staircase speed");
        Check(maxDev < 0.08, $"smoothed accel stays within 0.08 G (max dev {maxDev:0.000}, naive two-point dev {maxDevRaw:0.00})");
        Console.WriteLine($"Accel test: smoothed max error {maxDev:0.000} G vs naive two-point derivative {maxDevRaw:0.00} G");

        // NaN (pointer lost in menus) resets history rather than producing a spike
        var s = Formula.Compile("slope(value, 0.1)", _ => null);
        var c = new EvalContext();
        for (int i = 0; i < 20; i++) { c.T = i * 0.01; c.Value = i; s.Evaluate(c); }
        c.T = 0.2; c.Value = double.NaN; Check(double.IsNaN(s.Evaluate(c)), "NaN in -> NaN out");
        c.T = 0.21; c.Value = 1000; Near(s.Evaluate(c), 0, 0, "history reset after NaN (no spike)");

        // avg / minw / maxw / delta / prev
        var a = Formula.Compile("avg(value, 1)", _ => null); c = new EvalContext();
        foreach (var (tt, v) in new[] { (0.0, 2.0), (0.5, 4.0), (1.0, 6.0), (1.6, 8.0) }) { c.T = tt; c.Value = v; last = a.Evaluate(c); }
        Near(last, 6, 1e-9, "avg window drops samples older than 1 s");
        var d = Formula.Compile("delta(value)", _ => null); c = new EvalContext { Value = 3 }; d.Evaluate(c); c.Value = 5;
        Near(d.Evaluate(c), 2, 0, "delta");
    }

    sealed class FakeSource : IRawSource
    {
        public double V;
        public bool TryRead(SourceContext ctx, out double value, out string status) { value = V; status = "fake"; return true; }
    }

    static void Engine()
    {
        var speedSrc = new FakeSource { V = 100 };
        var prof = new GameProfile
        {
            Prefix = "WMMT3DX+",
            Variables =
            {
                new VariableDef { Name = "speed_ms", Source = SourceKind.Computed, Formula = "speed / 3.6" }, // defined before its dependency
                new VariableDef { Name = "speed", Source = SourceKind.Memory, Module = "fake.exe", BaseOffset = "10", Formula = "value * 1" },
                new VariableDef { Name = "loop_a", Source = SourceKind.Computed, Formula = "loop_b + 1" },
                new VariableDef { Name = "loop_b", Source = SourceKind.Computed, Formula = "loop_a + 1" },
                new VariableDef { Name = "uses_bad", Source = SourceKind.Computed, Formula = "loop_a * 2" },
                new VariableDef { Name = "self", Source = SourceKind.Computed, Formula = "self + 1" },
                new VariableDef { Name = "dt", Source = SourceKind.Computed, Formula = "1" },
                new VariableDef { Name = "hidden", Source = SourceKind.Computed, Formula = "speed * 2", Enabled = false },
                new VariableDef { Name = "bad_hex", Source = SourceKind.Memory, Module = "fake.exe", BaseOffset = "XYZ" },
            }
        };
        var eng = new TelemetryEngine { SourceFactory = v => v.Name == "speed" ? speedSrc : TelemetryEngine.DefaultSourceFactory(v) };
        List<string> published = null;
        eng.PropertiesChanged += n => published = n.ToList();
        eng.Load(new[] { prof }, new PluginSettings());
        var ps = eng.Profiles[0];
        VarState V(string n) => ps.Vars.Single(v => v.Def.Name == n);

        TelemetryEngine.EvaluateTick(ps, 0.01);
        Near(V("speed_ms").Output, 100 / 3.6, 1e-9, "dependency evaluated first regardless of list order");
        Check(V("loop_a").HasConfigError && V("loop_b").HasConfigError, "cycle detected: " + V("loop_a").Status);
        Check(V("uses_bad").HasConfigError, "dependant of a broken variable flagged");
        Check(V("self").HasConfigError && V("self").Status.Contains("itself"), "self reference: " + V("self").Status);
        Check(V("dt").HasConfigError && V("dt").Status.Contains("reserved"), "reserved name: " + V("dt").Status);
        Check(V("bad_hex").HasConfigError, "bad hex: " + V("bad_hex").Status);
        Check(V("speed").PropertyName == "WMMT3DXP_speed", "prefix sanitised: " + V("speed").PropertyName);

        Check(published.Contains("WMMT3DXP_speed") && published.Contains("WMMT3DXP_Connected") && !published.Contains("WMMT3DXP_hidden"),
            "published names: " + string.Join(", ", published));
        Check(eng.GetPropertyValue("WMMT3DXP_hidden") == null, "disabled variable returns null");
        Near(V("hidden").Output, 200, 0, "disabled variable still evaluated for preview");
        Check((double)eng.GetPropertyValue("WMMT3DXP_loop_a") == 0.0, "errored variable publishes 0");
        Check(eng.GetPropertyValue("WMMT3DXP_Connected") is bool, "connected flag is bool");
    }

    /// <summary>max_speed and max_revs: blank or below 1 gives 1 (raw values); set values divide.</summary>
    static void References()
    {
        Check(GameProfile.Reference(null) == 1 && GameProfile.Reference(0.5) == 1 && GameProfile.Reference(double.NaN) == 1 &&
              GameProfile.Reference(320) == 320, "Reference(): blank, below 1 or NaN gives 1");
        Check(Formula.IsReservedName("max_speed") && Formula.IsReservedName("MAX_REVS"), "max_speed and max_revs are reserved");
        var src = new FakeSource { V = 160 };
        GameProfile Prof(double? ms, double? mr) => new GameProfile
        {
            Prefix = "REF", MaxSpeed = ms, MaxRevs = mr,
            Variables =
            {
                new VariableDef { Name = "speed", Source = SourceKind.Memory, Module = "fake.exe", BaseOffset = "10", Formula = "value / max_speed" },
                new VariableDef { Name = "revs", Source = SourceKind.Computed, Formula = "8000 / max_revs" },
            }
        };
        foreach (var (ms, mr, speed, revs) in new[] { ((double?)null, (double?)null, 160.0, 8000.0), (320, 8000, 0.5, 1.0), (0.2, 1, 160, 8000) })
        {
            var eng = new TelemetryEngine { SourceFactory = v => v.Name == "speed" ? src : TelemetryEngine.DefaultSourceFactory(v) };
            var prof = Prof(ms, mr);
            eng.Load(new[] { prof }, new PluginSettings());
            var ps = eng.Profiles[0];
            TelemetryEngine.EvaluateTick(ps, 0.01);
            Near(ps.Vars[0].Output, speed, 1e-9, $"speed with max_speed {ms?.ToString() ?? "blank"}");
            Near(ps.Vars[1].Output, revs, 1e-9, $"revs with max_revs {mr?.ToString() ?? "blank"}");
            var back = ProfileStore.Clone(prof);
            Check(back.MaxSpeed == ms && back.MaxRevs == mr, "max speed and revs survive save/load");
        }
    }

    /// <summary>The clipboard text from Copy Commandlines To Set Game/Profile.</summary>
    static void Launch()
    {
        const string exe = @"C:\Program Files (x86)\SimHub\SimHubWPF.exe";
        var t = LaunchLines.Build(exe, "TPTelemetry.Activate_WMMT5DXP", "Wangan Midnight Maximum Tune 5DX+", "Custom_36fd164a");
        var lines = t.Split(new[] { "\r\n" }, StringSplitOptions.None).Where(x => x != "").ToList();
        var code = lines.Where(x => !x.StartsWith(";")).ToList();
        Check(code.Count == 9, "three commands in each of three blocks, got " + code.Count);
        Check(code[0] == "Run, \"" + exe + "\" -triggeraction TPTelemetry.Activate_WMMT5DXP" && code[1] == "Sleep, 5000" &&
              code[2] == "Run, \"" + exe + "\" -switchgame Custom_36fd164a", "AutoHotkey v1 block: " + string.Join(" | ", code.Take(3)));
        Check(code[3] == "Run '\"" + exe + "\" -triggeraction TPTelemetry.Activate_WMMT5DXP'" && code[4] == "Sleep 5000" &&
              code[5] == "Run '\"" + exe + "\" -switchgame Custom_36fd164a'", "AutoHotkey v2 block: " + string.Join(" | ", code.Skip(3).Take(3)));
        Check(code[6] == "start \"\" \"" + exe + "\" -triggeraction TPTelemetry.Activate_WMMT5DXP" && code[7] == "timeout /t 5 /nobreak >nul" &&
              code[8] == "start \"\" \"" + exe + "\" -switchgame Custom_36fd164a", "batch block: " + string.Join(" | ", code.Skip(6)));
        Check(t.Contains("\r\n") && !t.Replace("\r\n", "").Contains("\n"), "Windows line endings");
        Check(t.Contains("no command for choosing a ShakeIt effects profile"), "note on the effects profile");
        var spaced = LaunchLines.Build(exe, "TPTelemetry.Activate_X", "X", "Assetto Corsa");
        Check(spaced.Contains("-switchgame \"Assetto Corsa\""), "game code with a space is quoted");
        var none = LaunchLines.Build(exe, "TPTelemetry.Activate_X", "X", "");
        var noneCode = none.Split(new[] { "\r\n" }, StringSplitOptions.None).Where(x => x != "" && !x.StartsWith(";")).ToList();
        Check(noneCode.Count == 3 && noneCode.All(x => x.Contains("-triggeraction")) && none.Contains("No SimHub game was selected"),
              "no SimHub game: only the TP Telemetry line in each block, with a note");
    }

    sealed class FakeMemory : IMemoryReader
    {
        public Dictionary<long, long> Ptr = new Dictionary<long, long>();
        public Dictionary<long, double> Val = new Dictionary<long, double>();
        public bool TryGetModuleBase(string m, out long b) { b = 0x400000; return m.Equals("BudgieLoader.exe", StringComparison.OrdinalIgnoreCase); }
        public bool TryReadPointer(long a, out long v) => Ptr.TryGetValue(a, out v) && v != 0;
        public bool TryReadValue(long a, MemType t, out double v) => Val.TryGetValue(a, out v);
    }

    static void PointerWalk()
    {
        var mem = new FakeMemory();
        // "BudgieLoader.exe"+0106A79C -> [ptr]+24 = speed
        mem.Ptr[0x400000 + 0x0106A79C] = 0x20000000;
        mem.Val[0x20000000 + 0x24] = 123.5;
        var src = MemorySource.From(new VariableDef { Module = "\"BudgieLoader.exe\"", BaseOffset = "0106A79C", Offsets = "24" });
        var ctx = new SourceContext { Memory = mem };
        Check(src.TryRead(ctx, out var v, out var st) && v == 123.5, $"single-level pointer: {v} {st}");

        // three levels, base first
        mem.Ptr[0x400000 + 0x100] = 0x1000; mem.Ptr[0x1000 + 0x4] = 0x2000; mem.Ptr[0x2000 + 0x8] = 0x3000; mem.Val[0x3000 + 0xC] = 7;
        src = MemorySource.From(new VariableDef { Module = "BudgieLoader.exe", BaseOffset = "100", Offsets = "4, 8, C" });
        Check(src.TryRead(ctx, out v, out st) && v == 7, $"three-level pointer: {v} {st}");

        mem.Ptr[0x2000 + 0x8] = 0; // object freed between races
        Check(!src.TryRead(ctx, out v, out st) && st.Contains("level 3"), "null pointer reported with level: " + st);

        src = MemorySource.From(new VariableDef { Module = "TeknoParrot.dll", BaseOffset = "10", Offsets = "" });
        Check(!src.TryRead(ctx, out v, out st) && st.Contains("not loaded"), "missing module: " + st);

        // "@" offsets (0.18.2): 32-bit pointers of an emulated machine. Flycast keeps the game's RAM at a host pointer;
        // the game's own pointers are 0x0C...... / 0x8C...... addresses inside it (Initial D 3, 17 November 2026).
        mem.Ptr[0x400000 + 0x2840C90] = 0x7F0000000000;                       // the emulator's pointer to the game's RAM
        mem.Val[0x7F0000000000 + 0x8FF174] = 0x0DF986C0;                      // the game's pointer to its race object
        mem.Val[0x7F0000000000 + 0x1F986C0 + 0x588] = 905000;                 // the race clock in it
        mem.Val[0x7F0000000000 + 0x1F986C0 + 0x418] = 0x8D9B7B40;             // a second game pointer (mirror address)
        mem.Val[0x7F0000000000 + 0x19B7B40 + 0x8] = 162800;
        src = MemorySource.From(new VariableDef { Module = "BudgieLoader.exe", BaseOffset = "2840C90", Offsets = "8FF174, @588", Type = MemType.Int32 });
        Check(src.TryRead(ctx, out v, out st) && v == 905000, $"emulated pointer, one hop: {v} {st}");
        src = MemorySource.From(new VariableDef { Module = "BudgieLoader.exe", BaseOffset = "2840C90", Offsets = "8FF174, @418, @8", Type = MemType.Int32 });
        Check(src.TryRead(ctx, out v, out st) && v == 162800, $"emulated pointer, two hops and a mirror address: {v} {st}");
        mem.Val[0x7F0000000000 + 0x8FF174] = 0;                               // no race: the game's pointer is null
        Check(!src.TryRead(ctx, out v, out st) && st.Contains("level 2"), "null emulated pointer reported with level: " + st);
        var planRow = src.ToPlanRow();                                         // the 64-bit helper gets the same chain
        var plan2 = TeknoTelemetry.Core.Remote.ReadPlan.Parse(new TeknoTelemetry.Core.Remote.ReadPlan { ProcessName = "flycast.exe", Rows = { planRow } }.Serialise());
        Check(plan2.Rows.Count == 1 && plan2.Rows[0].Offsets.Length == 3 && Hex.IsEmuHop(plan2.Rows[0].Offsets[1]) && !Hex.IsEmuHop(plan2.Rows[0].Offsets[0])
              && (plan2.Rows[0].Offsets[2] & ~Hex.EmuHop) == 8, "emulated pointer offsets survive the helper's read plan");
        Check(!Hex.TryParseList("@588", out _, out var emuErr) && emuErr.Contains("first"), "@ can't be the first offset: " + emuErr);
        Check(Hex.TryParseList("10, -8", out var plain, out _) && plain[1] == -8 && !Hex.IsEmuHop(plain[1]), "a negative offset is not an emulated hop");

        // "[-E80]*578" (0.19.0): an index into the game's per-car records, read from its own player number (SWDC, 18 November 2026).
        // [main+4B07438] -> +278 -> +10 = the data model Q; Q+2550 points to the records (578 bytes each); Q+16D0 is the player's
        // car number, counted from 1; the speedo's km/h is at +460 in a record.
        mem.Ptr[0x400000 + 0x4B07438] = 0x5000; mem.Ptr[0x5000 + 0x278] = 0x6000; mem.Ptr[0x6000 + 0x10] = 0x10000;
        mem.Ptr[0x10000 + 0x2550] = 0x80000;
        mem.Val[0x10000 + 0x16D0] = 3;                                        // the player is car 3
        mem.Val[0x80000 + 2 * 0x578 + 0x460] = 187;                           // car 3's km/h
        src = MemorySource.From(new VariableDef { Module = "BudgieLoader.exe", BaseOffset = "4B07438", Offsets = "278, 10, 2550, [-E80]*578, -118", Type = MemType.Int32 });
        Check(src.TryRead(ctx, out v, out st) && v == 187, $"indexed record: {v} {st}");
        mem.Val[0x10000 + 0x16D0] = 1; mem.Val[0x80000 + 0x460] = 95;           // car 1
        Check(src.TryRead(ctx, out v, out st) && v == 95, $"indexed record, first car: {v} {st}");
        var idxPlan = TeknoTelemetry.Core.Remote.ReadPlan.Parse(new TeknoTelemetry.Core.Remote.ReadPlan { ProcessName = "Todoroki-Win64-Shipping.exe", Rows = { src.ToPlanRow() } }.Serialise());
        var idxOff = idxPlan.Rows[0].Offsets;
        Check(idxOff.Length == 5 && Hex.IsIndexHop(idxOff[3]) && Hex.IndexOffset(idxOff[3]) == -0xE80 && Hex.IndexStride(idxOff[3]) == 0x578 && idxOff[4] == -0x118,
              "indexed offsets survive the helper's read plan");
        Check(!Hex.TryParseList("2550, [-E80]*578", out _, out var idxErr) && idxErr.Contains("followed"), "an index needs an offset after it: " + idxErr);
        Check(!Hex.TryParseList("[16D0]578", out _, out idxErr) && idxErr.Contains("record size"), "an index needs *size: " + idxErr);
        Check(Hex.TryParseList("10, -8", out var plain2, out _) && !Hex.IsIndexHop(plain2[1]), "a negative offset is not an index");
        mem.Ptr[0x10000 + 0x2550] = 0;                                        // no records yet
        Check(!src.TryRead(ctx, out v, out st) && st.Contains("level 5"), "null record pointer reported with level: " + st);

        // no offsets: read directly at module+base
        mem.Val[0x400000 + 0x50] = 3;
        src = MemorySource.From(new VariableDef { Module = "BudgieLoader.exe", BaseOffset = "50" });
        Check(src.TryRead(ctx, out v, out st) && v == 3, "static address read");
    }

    static void ActiveGame()
    {
        GameProfile G(string prefix) => new GameProfile { Prefix = prefix, ProcessName = "BudgieLoader.exe",
            Variables = { new VariableDef { Name = "speed", Module = "BudgieLoader.exe", BaseOffset = "10" } } };
        var games = new[] { G("WMMT3DX+"), G("OR2") };
        var eng = new TelemetryEngine();
        bool[] Act(string active) { eng.Load(games, new PluginSettings { ActiveGame = active }); return eng.Profiles.Select(p => p.Active).ToArray(); }

        Check(Act("").SequenceEqual(new[] { true, true }), "auto: every enabled game may attach");
        Check(Act("WMMT3DX+").SequenceEqual(new[] { true, false }), "active by unsanitised prefix");
        Check(Act("wmmt3dxp").SequenceEqual(new[] { true, false }), "active by sanitised prefix, any case");
        Check(eng.Profiles[1].Status.ToUpperInvariant().Contains("WMMT3DXP"), "inactive status names the active game: " + eng.Profiles[1].Status);
        Check(Act("OR2").SequenceEqual(new[] { false, true }), "switch to OR2 with the same loader process");
        Check(Act(PluginSettings.NoGame).SequenceEqual(new[] { false, false }), "none");
        Check(Act("NOPE").SequenceEqual(new[] { false, false }), "unknown prefix reads nothing");
        games[1].Enabled = false;
        Check(Act("OR2").SequenceEqual(new[] { false, false }), "disabled profile stays off even when selected");
        Check((bool)eng.GetPropertyValue("WMMT3DXP_Connected") == false, "inactive game publishes Connected = false");
    }

    static void Dummy()
    {
        var p = ProfileStore.ReadProfile("../../profiles/DUMMY.json");
        var eng = new TelemetryEngine();
        eng.Load(new[] { p }, new PluginSettings());
        var ps = eng.Profiles[0];
        Check(ps.Vars.All(v => !v.HasConfigError), "dummy profile compiles: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
        Check(p.Variables.Where(v => v.Notes.StartsWith("EXAMPLE")).All(v => !v.Formula.Contains("sim_")), "example formulas only use REPLACE_ stand-ins, never the test-signal internals");
        double V(string n) => ps.Vars.Single(v => v.Def.Name == n).Output;

        var rng = new Dictionary<string, (double lo, double hi)>();
        void Track(string n) { var v = V(n); rng[n] = rng.TryGetValue(n, out var r) ? (Math.Min(r.lo, v), Math.Max(r.hi, v)) : (v, v); }
        double driftErr = 0, latErr = 0, latYawErr = 0; int shifts = 0; double prevShift = 0;
        for (int i = 0; i <= 60 * 120; i++)
        {
            TelemetryEngine.EvaluateTick(ps, i / 120.0);
            if (i < 120) continue;
            foreach (var n in new[] { "REPLACE_speed", "REPLACE_gear", "REPLACE_rpm", "REPLACE_heading", "accel_long_g", "yaw_rate", "accel_lat_g",
                                      "accel_lat_g_path", "drift_angle", "wheelspin", "lockup", "vertical_g", "road_rumble", "impact", "shift_light", "distance_km" })
                Track(n);
            if (V("REPLACE_speed") > 40) driftErr = Math.Max(driftErr, Math.Abs(V("drift_angle") - V("sim_slip")));
            // expected cornering G from the signal's own turn rate
            var turnRate = (600 + 1100 * Math.Sin(i / 120.0 * 2 * Math.PI / 7)) / Math.Max(V("REPLACE_speed"), 30);
            var expLat = V("REPLACE_speed") / 3.6 * turnRate * Math.PI / 180 / 9.80665;
            if (i > 240) latErr = Math.Max(latErr, Math.Abs(V("accel_lat_g_path") - expLat));       // path-based: exact everywhere
            if (V("REPLACE_speed") < 38 && i > 240) latYawErr = Math.Max(latYawErr, Math.Abs(V("accel_lat_g") - expLat)); // heading-based: exact without slip
            if (V("gear_shift") > 0 && prevShift == 0) shifts++;
            prevShift = V("gear_shift");
        }
        Console.WriteLine("Dummy over 60 s:");
        foreach (var kv in rng) Console.WriteLine($"  {kv.Key,-16} {kv.Value.lo,8:0.00} .. {kv.Value.hi,8:0.00}");
        Console.WriteLine($"  drift_angle max error vs actual slip {driftErr:0.00} deg, accel_lat_g_path max error {latErr:0.000} G, accel_lat_g (no slip) {latYawErr:0.000} G, {shifts} gear-shift pulses");

        Check(rng["REPLACE_speed"].lo > 9 && rng["REPLACE_speed"].hi < 231, "speed range");
        Check(rng["REPLACE_gear"].lo == 1 && rng["REPLACE_gear"].hi == 6, "gears 1-6");
        Check(rng["accel_long_g"].hi > 0.9 && rng["accel_long_g"].lo < -0.9, "longitudinal G about +-1");
        Check(rng["REPLACE_heading"].lo < 20 && rng["REPLACE_heading"].hi > 340, "heading wraps through 360");
        Check(rng["yaw_rate"].hi < 60 && rng["yaw_rate"].lo > -60, "no yaw spike when heading wraps");
        Check(latErr < 0.15 && rng["accel_lat_g_path"].hi > 0.5, $"path-based lateral G tracks the real cornering (max error {latErr:0.000})");
        Check(latYawErr < 0.15, $"heading-based lateral G right when not sliding (max error {latYawErr:0.000})");
        Check(driftErr < 3 && rng["drift_angle"].hi > 8, $"drift_angle finds the slip (max error {driftErr:0.00} deg)");
        Check(rng["wheelspin"].hi > 0.1 && rng["lockup"].hi > 0.1, "wheelspin and lockup both trigger");
        Check(rng["vertical_g"].hi < 3 && rng["vertical_g"].hi > 0.2 && rng["road_rumble"].hi > 0.3, "vertical G and rumble sensible");
        Check(rng["impact"].hi == 0, "no false impacts from normal braking");
        Check(shifts >= 10, "gear-shift pulses, got " + shifts);
        Check(rng["shift_light"].hi == 1 && rng["shift_light"].lo == 0, "shift light toggles");
        Check(rng["distance_km"].hi > 1.5 && rng["distance_km"].hi < 4.5, "distance about speed x time");
        Check(p.Source() == ProfileSource.None, "dummy runs without a game process");

        // adding a memory row to the dummy mustn't stop its formulas
        p.Variables.Add(new VariableDef { Name = "new_value", Module = "x.exe", BaseOffset = "10" });
        Check(p.Source() == ProfileSource.None, "dummy with a memory row still runs without a process");
        var eng2 = new TelemetryEngine();
        eng2.Load(new[] { p }, new PluginSettings { ActiveGame = "DUMMY" });
        var p2 = eng2.Profiles[0];
        eng2.Tick(p2); var s1 = p2.Vars.Single(v => v.Def.Name == "REPLACE_speed").Output;
        System.Threading.Thread.Sleep(200);
        eng2.Tick(p2); var s2 = p2.Vars.Single(v => v.Def.Name == "REPLACE_speed").Output;
        Check(s1 != s2 && !double.IsNaN(s2), $"dummy speed keeps moving with a memory row present ({s1:0.00} -> {s2:0.00})");
        Check(p2.Vars.Single(v => v.Def.Name == "new_value").Status.Contains("Process"), "memory row explains it has no process");
    }

    static void Store()
    {
        var dir = Path.Combine(Path.GetTempPath(), "tpt-test-" + Guid.NewGuid().ToString("N"), "Profiles");
        var store = new ProfileStore(dir);
        var p = CheatTableImporter.ImportFile("sample.CT").Profile;
        store.SaveAll(new[] { p });
        var back = store.LoadAll();
        Check(back.Count == 1 && back[0].Variables.Count == 8 && back[0].Variables[2].Offsets == p.Variables[2].Offsets, "profile round-trips");
        Check(File.ReadAllText(Directory.GetFiles(dir)[0]).Contains("\"Type\": \"Float\""), "enums saved as text");
        store.SaveAll(new GameProfile[0]);
        Check(Directory.GetFiles(dir).Length == 1, "files not marked as removed are left alone");
        store.MarkRemoved(p.Id);
        store.SaveAll(new GameProfile[0]);
        Check(Directory.GetFiles(dir).Length == 0, "deleted game's file removed");

        // Alexis's folder: the starter copied in by hand next to the plugin's older save, plus a new game
        var wm = new GameProfile { Id = "wmmt3dxplus000000000000000000000", DisplayName = "WMMT3DX+", Prefix = "WMMT3DXP", ProcessName = "BudgieLoader.exe" };
        ProfileStore.WriteProfile(wm, Path.Combine(dir, "WMMT3DXP_wmmt3d.json"));
        File.SetLastWriteTimeUtc(Path.Combine(dir, "WMMT3DXP_wmmt3d.json"), DateTime.UtcNow.AddMinutes(-5));
        ProfileStore.WriteProfile(wm, Path.Combine(dir, "WMMT3DXP.json"));
        ProfileStore.WriteProfile(new GameProfile { Id = "a2016d88db9d4882afefe7cd14fefcf7", DisplayName = "Test", Prefix = "Test" }, Path.Combine(dir, "Test_a2016d.json"));
        File.WriteAllText(Path.Combine(dir, "readme.txt"), "not a profile");
        store = new ProfileStore(dir);
        var loaded = store.LoadAll();
        Check(loaded.Count == 2, "duplicate copies of one game load once, got " + loaded.Count);
        store.SaveAll(loaded);
        var names = Directory.GetFiles(dir).Select(Path.GetFileName).OrderBy(n => n, StringComparer.Ordinal).ToArray();
        Check(names.SequenceEqual(new[] { "Test.json", "WMMT3DXP.json", "readme.txt" }.OrderBy(n => n, StringComparer.Ordinal)), "tidied to prefix names: " + string.Join(", ", names));

        // two games sharing a prefix get suffixed names
        var a = new GameProfile { Prefix = "OR2" }; var b = new GameProfile { Prefix = "OR2" };
        store.SaveAll(loaded.Concat(new[] { a, b }));
        Check(Directory.GetFiles(dir, "OR2_*.json").Length == 2 && !File.Exists(Path.Combine(dir, "OR2.json")), "shared prefix gets Id suffix");
        // renaming a prefix moves the file
        loaded.Single(g => g.Prefix == "Test").Prefix = "TestRenamed";
        store.SaveAll(loaded.Concat(new[] { a, b }));
        Check(!File.Exists(Path.Combine(dir, "Test.json")) && File.Exists(Path.Combine(dir, "TestRenamed.json")), "prefix rename replaces the old file");
        Directory.Delete(Path.GetDirectoryName(dir), true);
    }
}
static class ProfileCheck
{
    // Every shipped profile loads with no errors. Set TPT_PROFILE_DIRS (separated by ;) to also
    // check a game profiles pack.
    public static void Run(Action<bool, string> check)
    {
        var dirs = new List<string> { "../../profiles" };
        dirs.AddRange((Environment.GetEnvironmentVariable("TPT_PROFILE_DIRS") ?? "").Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries));
        foreach (var f in dirs.SelectMany(d => Directory.GetFiles(d, "*.json", SearchOption.AllDirectories)))
        {
            var p = ProfileStore.ReadProfile(f);
            var eng = new TelemetryEngine { SourceFactory = v => v.Source == SourceKind.Computed ? NoSource.Instance : new ZeroSource() };
            eng.Load(new[] { p }, new PluginSettings());
            var errs = eng.Profiles[0].Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + ": " + v.Status).ToList();
            check(errs.Count == 0, $"{Path.GetFileName(f)} loads cleanly " + string.Join("; ", errs));
            Console.WriteLine($"Profile {Path.GetFileName(f)}: {p.Variables.Count} variables, {errs.Count} errors");
        }
    }
    sealed class ZeroSource : IRawSource { public bool TryRead(SourceContext c, out double v, out string s) { v = 0; s = null; return true; } }
}
