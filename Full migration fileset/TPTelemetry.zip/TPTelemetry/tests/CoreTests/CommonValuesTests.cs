using System;
using System.Collections.Generic;
using System.Linq;
using TeknoTelemetry.Core;

/// <summary>TPTelemetry.Car_* values: worked out from a game's car_ rows, gated by car_in_race,
/// scaled by Max speed / Max revs (silent when blank), with pulses and sides.</summary>
static class CommonValuesTests
{
    sealed class Feed : IRawSource
    {
        public double Value;
        public bool TryRead(SourceContext ctx, out double value, out string status) { value = Value; status = "test"; return true; }
    }

    public static void Run(Action<bool, string> check, Action<double, double, double, string> near)
    {
        var feeds = new Dictionary<string, Feed>();
        GameProfile Prof(double? maxSpeed, double? maxRevs, params string[] sources) => new GameProfile
        {
            Prefix = "CV", ProcessName = "", MaxSpeed = maxSpeed, MaxRevs = maxRevs,
            Variables = sources.Select(n => new VariableDef { Name = "car_" + n, Source = SourceKind.Memory, Module = "x.exe", BaseOffset = "10", Enabled = false }).ToList(),
        };
        (TelemetryEngine eng, ProfileState ps) Load(GameProfile prof)
        {
            feeds.Clear();
            var eng = new TelemetryEngine
            {
                SourceFactory = v => { if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v); var f = new Feed(); feeds[v.Name.Substring(4)] = f; return f; },
            };
            eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "CV" });
            return (eng, eng.Profiles[0]);
        }
        void Tick(TelemetryEngine eng, ProfileState ps, double t) { eng.Tick(ps); eng.Common.Update(ps, t); }
        double G(TelemetryEngine eng, string n) => eng.Common.Get(n);

        var all = CommonValues.Sources.Select(s => s.Name).Where(n => n != "rpm_frac").ToArray();   // rpm_frac (0.17.0) has its own check below
        check(CommonValues.Outputs.Select(o => o.Name).Distinct().Count() == CommonValues.Outputs.Length, "Car_ output names are unique");

        // car_rpm_frac (0.17.0): the car's own rev range replaces revs / Max revs (GRID: cars limit at 6500 to 8200)
        {
            var (e2, p2) = Load(Prof(200, 6900, "in_race", "rpm", "rpm_frac"));
            feeds["in_race"].Value = 1; feeds["rpm"].Value = 8200; feeds["rpm_frac"].Value = 1.0;
            Tick(e2, p2, 1.0);
            near(G(e2, "rpm_frac"), 1.0, 1e-9, "Car_rpm_frac from car_rpm_frac");
            near(G(e2, "rpm"), 8200, 1e-9, "Car_rpm stays real RPM");
            feeds["rpm"].Value = 6900; feeds["rpm_frac"].Value = 6900 / 8200.0; Tick(e2, p2, 1.01);
            near(G(e2, "rpm_frac"), 6900 / 8200.0, 1e-9, "6900 in an 8200 car is 84%, not 100% of Max revs 6900");
            check(G(e2, "rev_limit") == 0, "no rev limiter effect at 84% of the car's limiter");
            feeds["in_race"].Value = 0; Tick(e2, p2, 1.02);
            near(G(e2, "rpm_frac"), 0, 0, "Car_rpm_frac gated by in_race");
        }

        // drifting (0.18.0): Car_drift from car_drift, or from the size of car_drift_angle; a game with no grip_loss row
        // gives its drift as the grip loss too (Alexis, 9 November 2026)
        {
            var (e3, p3) = Load(Prof(200, 8000, "in_race", "drift_angle"));
            feeds["in_race"].Value = 1; feeds["drift_angle"].Value = -20; Tick(e3, p3, 1.0);
            near(G(e3, "drift"), 0.5, 1e-9, "Car_drift = |angle| / 40 degrees");
            near(G(e3, "drift_angle"), -20, 1e-9, "Car_drift_angle raw, with its sign");
            near(G(e3, "grip_loss"), 0.5, 1e-9, "no grip_loss row: Car_grip_loss is the drift");
            feeds["drift_angle"].Value = 70; Tick(e3, p3, 1.01);
            near(G(e3, "drift"), 1, 0, "Car_drift capped at 1");
            feeds["in_race"].Value = 0; Tick(e3, p3, 1.02);
            near(G(e3, "drift"), 0, 0, "Car_drift gated by in_race"); near(G(e3, "grip_loss"), 0, 0, "and so is the grip loss from it");
            near(G(e3, "drift_angle"), 70, 1e-9, "Car_drift_angle not gated (a gauge)");

            var (e4, p4) = Load(Prof(200, 8000, "in_race", "drift", "drift_angle", "grip_loss"));
            feeds["in_race"].Value = 1; feeds["drift"].Value = 0.3; feeds["drift_angle"].Value = 35; feeds["grip_loss"].Value = 0.8; Tick(e4, p4, 1.0);
            near(G(e4, "drift"), 0.3, 1e-9, "a car_drift row wins over the angle");
            near(G(e4, "grip_loss"), 0.8, 1e-9, "a game's own grip_loss row stays the grip loss");

            var (e5, p5) = Load(Prof(200, 8000, "in_race"));
            feeds["in_race"].Value = 1; Tick(e5, p5, 1.0);
            near(G(e5, "drift"), 0, 0, "no drift rows: Car_drift 0"); near(G(e5, "grip_loss"), 0, 0, "and grip loss 0");
        }

        // everything present, Max speed and revs set
        var (e, p) = Load(Prof(200, 8000, all));
        foreach (var f in feeds.Values) f.Value = 0;
        feeds["in_race"].Value = 1; feeds["speed"].Value = 100; feeds["rpm"].Value = 4000; feeds["gear"].Value = 3; feeds["throttle"].Value = 1;
        Tick(e, p, 1.0);
        near(G(e, "in_race"), 1, 0, "in race");
        near(G(e, "speed_frac"), 0.5, 1e-9, "speed_frac = 100 / 200");
        near(G(e, "rpm_frac"), 0.5, 1e-9, "rpm_frac = 4000 / 8000");
        near(G(e, "engine"), 0.35 + 0.65 * 0.5, 1e-9, "engine strength rises from 0.35 at idle");
        near(G(e, "engine_hz"), 25 + 35 * 0.5, 1e-9, "engine pitch 25 to 60 Hz");
        // throttle load (0.14.0): off the throttle the engine effects drop to 60%; the pitch doesn't change
        feeds["throttle"].Value = 0; Tick(e, p, 1.01);
        near(G(e, "engine"), (0.35 + 0.65 * 0.5) * 0.6, 1e-9, "engine at 60% off the throttle");
        near(G(e, "engine_hz"), 25 + 35 * 0.5, 1e-9, "engine pitch unchanged by the throttle");
        feeds["throttle"].Value = 0.5; Tick(e, p, 1.02);
        near(G(e, "engine"), (0.35 + 0.65 * 0.5) * 0.8, 1e-9, "engine at 80% on half throttle"); near(G(e, "throttle"), 0.5, 1e-9, "Car_throttle");
        feeds["throttle"].Value = 1; Tick(e, p, 1.03);
        near(G(e, "rev_limit"), 0, 0, "no limiter at half revs");
        near(G(e, "shift"), 0, 0, "no shift before a gear change");

        feeds["gear"].Value = 4; Tick(e, p, 1.05);
        near(G(e, "shift"), 1, 0, "gear change: shift pulse");
        Tick(e, p, 1.25);
        near(G(e, "shift"), 0, 0, "shift pulse over after 0.15 s");

        feeds["rpm"].Value = 7900;
        var lim = new List<double>();
        for (double t = 2; t < 3; t += 0.01) { Tick(e, p, t); lim.Add(G(e, "rev_limit")); }
        check(lim.Contains(1) && lim.Contains(0) && Math.Abs(lim.Average() - 0.5) < 0.1, "rev limiter stutters at 99% of Max revs (on about half the time): " + lim.Average());

        feeds["impact"].Value = 0.6; feeds["impact_side"].Value = 1; Tick(e, p, 3);
        near(G(e, "impact_right"), 0.6, 1e-9, "right-hand hit: full on the right");
        near(G(e, "impact_left"), 0.18, 1e-9, "right-hand hit: 30% on the left");
        feeds["impact_side"].Value = 0; Tick(e, p, 3.01);
        check(G(e, "impact_left") == 0.6 && G(e, "impact_right") == 0.6, "unknown side: both sides");
        feeds["impact"].Value = 0;

        feeds["wall_contact"].Value = -1; feeds["cornering"].Value = 0.4; feeds["accel_g"].Value = -0.75; Tick(e, p, 4);
        check(G(e, "wall_left") == 1 && G(e, "wall_right") == 0, "left wall scrape");
        check(G(e, "corner_left") == 0.4 && G(e, "corner_right") == 0, "turning right: load on the left");
        near(G(e, "braking"), 0.5, 1e-9, "braking at 0.75 G = 0.5");
        near(G(e, "accelerating"), 0, 0, "not accelerating while braking");

        feeds["airborne"].Value = 1; Tick(e, p, 5);
        check(G(e, "airborne") == 1 && G(e, "road") == 0, "airborne: road texture cut");
        feeds["airborne"].Value = 0; Tick(e, p, 5.3);
        near(G(e, "landed"), 1, 1e-9, "landing pulse, full strength after 0.3 s in the air");
        Tick(e, p, 5.6);
        near(G(e, "landed"), 0, 0, "landing pulse over after 0.25 s");
        feeds["airborne"].Value = 1; Tick(e, p, 5.65);
        feeds["airborne"].Value = 0; Tick(e, p, 5.7);
        near(G(e, "landed"), 0.4 + 0.6 * 0.05 / 0.25, 1e-9, "a brief lift (0.05 s) lands softly: 0.52");
        Tick(e, p, 5.98);
        near(G(e, "landed"), 0, 0, "soft landing pulse over after 0.25 s");

        // out of the race: events gated, raw values kept
        feeds["in_race"].Value = 0; feeds["impact"].Value = 1; feeds["vibration"].Value = 1; Tick(e, p, 6);
        check(G(e, "impact") == 0 && G(e, "vibration") == 0 && G(e, "speed_frac") == 0 && G(e, "engine") == 0, "outside a race: effects silent");
        check(G(e, "speed") == 100 && G(e, "rpm") == 7900, "outside a race: raw speed and revs still there for gauges");

        // Max speed / Max revs blank: fractions silent, raw values kept
        (e, p) = Load(Prof(null, null, "speed", "rpm"));
        feeds["speed"].Value = 150; feeds["rpm"].Value = 6000; Tick(e, p, 1);
        check(G(e, "speed_frac") == 0 && G(e, "rpm_frac") == 0 && G(e, "engine") == 0 && G(e, "road") == 0, "blank Max speed and Max revs: speed and engine effects silent");
        check(G(e, "speed") == 150 && G(e, "rpm") == 6000, "blank boxes: raw speed and revs still published");
        (e, p) = Load(Prof(200, 8000, "in_race", "rpm"));
        feeds["in_race"].Value = 1; feeds["rpm"].Value = 4000; Tick(e, p, 1.0);
        near(G(e, "engine"), 0.35 + 0.65 * 0.5, 1e-9, "no car_throttle row: engine effects as before (full strength)");
        near(G(e, "throttle"), 0, 0, "no car_throttle row: Car_throttle 0");

        // USB stand-in (0.15.0): a game with no force-based rows gets them from the force the wheel got.
        {
            (e, p) = Load(Prof(200, 8000, "in_race", "speed"));
            var ffb = p.Ctx.Ffb; var C = TeknoTelemetry.Core.Ffb.FfbChannels.Connected; var Fo = TeknoTelemetry.Core.Ffb.FfbChannels.Force; var Ru = TeknoTelemetry.Core.Ffb.FfbChannels.Rumble;
            feeds["in_race"].Value = 1; feeds["speed"].Value = 100;
            double tt = 10;
            void Run(double force, double secs, double rumble = 0) { for (int i = 0; i < Math.Max(1, (int)(secs * 120)); i++) { ffb[Fo] = force; ffb[Ru] = rumble; Tick(e, p, tt += 1.0 / 120); } }
            ffb[C] = 0; ffb[Fo] = double.NaN; Run(double.NaN, 0.2);
            check(G(e, "usb") == 0 && G(e, "impact") == 0 && G(e, "cornering") == 0, "USB capture off: nothing from it");
            ffb[C] = 1; Run(0.4, 1.0);
            near(G(e, "cornering"), 0.4, 0.01, "USB: steady wheel force = cornering"); near(G(e, "usb"), 1, 0, "Car_usb 1 while values come from the wheel force");
            near(G(e, "corner_left"), 0.4, 0.01, "USB: + force (from the right) = load on the left, as for game rows");
            Run(-0.6, 1.0 / 120);
            check(G(e, "impact") > 0.5 && G(e, "impact_side") == -1 && G(e, "impact_left") > 0.5, $"USB: a sudden kick from the left = a hit on the left: {G(e, "impact"):0.00}");
            Run(-0.6, 1.0); Run(-0.45, 1.0 / 120);
            check(G(e, "impact") == 0 && G(e, "road_bump") > 0.2, $"USB: a small kick = a road bump: {G(e, "road_bump"):0.00}");
            Run(0, 0.5, 0.7); near(G(e, "vibration"), 0.7, 1e-9, "USB: the wheel's rumble = Car_vibration");
            feeds["in_race"].Value = 0; Run(0.5, 1.0); check(G(e, "impact") == 0 && G(e, "corner_left") == 0 && Math.Abs(G(e, "cornering") - 0.5) < 0.05, "USB values gated outside a race like any other (raw cornering still shown)");
            feeds["in_race"].Value = 1;
            e.Common.UsbStandIn = false; Run(0.3, 0.5); Run(-0.6, 1.0 / 120);
            check(G(e, "usb") == 0 && G(e, "impact") == 0 && G(e, "cornering") == 0, "setting off: nothing from the wheel force");
            e.Common.UsbStandIn = true;

            // A game's own rows win: car_impact present, so only the missing ones come from USB.
            (e, p) = Load(Prof(200, 8000, "in_race", "impact"));
            ffb = p.Ctx.Ffb; ffb[C] = 1; feeds["in_race"].Value = 1; feeds["impact"].Value = 0;
            Run(0, 0.5); Run(0.9, 1.0 / 120);
            check(G(e, "impact") == 0 && G(e, "usb") == 1, "the game's own car_impact is used even when the wheel kicks; the rest from USB");
            ffb[C] = 0; ffb[Fo] = double.NaN; ffb[Ru] = double.NaN;
        }
        near(G(e, "in_race"), 1, 0, "no car_in_race row: in race while the game is attached");

        // a game with no car_ rows: everything 0 but in_race
        (e, p) = Load(new GameProfile { Prefix = "CV", ProcessName = "" });
        Tick(e, p, 1);
        check(CommonValues.Outputs.Where(o => o.Name != "in_race" && o.Name != "engine_hz").All(o => G(e, o.Name) == 0), "no car_ rows: all values 0 (engine_hz rests at 25 Hz)");
        e.Common.Update(null, 2);
        near(G(e, "in_race"), 0, 0, "no game selected: everything 0");

        check(CommonValues.ProvidedBy(Prof(1, 1, "speed", "impact")).SequenceEqual(new[] { "speed", "impact" }), "ProvidedBy lists the car_ rows a profile has");

        // dashboard values and common lamps (0.20.0)
        {
            check(CommonValues.Lamps.Select(o => o.Name).Distinct().Count() == CommonValues.Lamps.Length, "Lamp_ names are unique");
            var lf = new Dictionary<string, Feed>();
            (TelemetryEngine, ProfileState) LoadRows(double? ms, double? mr, params string[] rows)
            {
                lf.Clear();
                var prof = new GameProfile { Prefix = "CV", ProcessName = "", MaxSpeed = ms, MaxRevs = mr,
                    Variables = rows.Select(n => new VariableDef { Name = n, Source = SourceKind.Memory, Module = "x.exe", BaseOffset = "10", Enabled = false }).ToList() };
                var eng = new TelemetryEngine { SourceFactory = v => { if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v); var f = new Feed(); lf[v.Name] = f; return f; } };
                eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "CV" });
                return (eng, eng.Profiles[0]);
            }
            double Lp(TelemetryEngine eng, string n) => eng.Common.GetLamp(n);

            var (d, dp1) = LoadRows(300, 9000, "car_in_race", "car_speed", "car_speed_kmh", "car_rpm", "car_gear", "car_position", "car_lap", "car_laps_total",
                "car_time_left", "car_race_time", "car_lap_time", "car_brake", "car_steer", "car_gap", "car_rev_limit_rpm",
                "lamp_start", "lamp_view2", "lamp_final_lap", "lamp_warning");
            lf["car_in_race"].Value = 0; lf["car_speed"].Value = 120; lf["car_speed_kmh"].Value = 193.12128; lf["car_rpm"].Value = 4500; lf["car_gear"].Value = -1;
            lf["car_position"].Value = 3; lf["car_lap"].Value = 2; lf["car_laps_total"].Value = 3; lf["car_time_left"].Value = 41.5; lf["car_race_time"].Value = 62.35;
            lf["car_lap_time"].Value = 20.5; lf["car_brake"].Value = 0.4; lf["car_steer"].Value = -1.5; lf["car_gap"].Value = -12; lf["car_rev_limit_rpm"].Value = 8200;
            lf["lamp_start"].Value = 1; lf["lamp_view2"].Value = 0.5; lf["lamp_final_lap"].Value = 0; lf["lamp_warning"].Value = 3;
            Tick(d, dp1, 1.0);
            near(G(d, "speed_kmh"), 193.12128, 1e-9, "Car_speed_kmh from car_speed_kmh, outside a race too (dashboard values aren't gated)");
            near(G(d, "speed_mph"), 120, 1e-9, "Car_speed_mph = km/h / 1.609344");
            check(G(d, "max_speed") == 300 && G(d, "max_revs") == 9000, "Car_max_speed and Car_max_revs: the profile's boxes");
            near(G(d, "rpm_dial"), 0.5, 1e-9, "Car_rpm_dial = revs / Max revs, not gated");
            check(G(d, "rev_limit_rpm") == 8200, "Car_rev_limit_rpm from the game's limiter");
            check(G(d, "position") == 3 && G(d, "lap") == 2 && G(d, "laps_total") == 3, "position and laps");
            check(G(d, "time_left") == 41.5 && G(d, "race_time") == 62.35 && G(d, "lap_time") == 20.5, "clocks, seconds");
            check(G(d, "brake") == 0.4 && G(d, "steer") == -1 && G(d, "gap") == -12, "brake, steering (clamped to -1..1) and gap");
            check(d.Common.GearText == "R", "gear text: R below 0");
            lf["car_gear"].Value = 0; Tick(d, dp1, 1.01); check(d.Common.GearText == "N", "gear text: N at 0");
            lf["car_gear"].Value = 4; Tick(d, dp1, 1.02); check(d.Common.GearText == "4", "gear text: the number");
            check(Lp(d, "start") == 1, "Lamp_start from lamp_start, outside a race too (lamps are never gated)");
            near(Lp(d, "view"), 0.5, 1e-9, "no lamp_view row: Lamp_view is the brightest view button");
            check(Lp(d, "warning") == 1, "lamps clamped to 0..1");
            check(Lp(d, "leader") == 0, "leader stand-in off outside a race");
            check(Lp(d, "brake") == 1, "brake light stand-in from Car_brake 0.4");
            lf["car_in_race"].Value = 1; lf["car_position"].Value = 1; lf["lamp_final_lap"].Value = 1; lf["car_rpm"].Value = 7500; Tick(d, dp1, 1.03);
            check(Lp(d, "leader") == 1, "leader stand-in: racing in 1st");
            check(G(d, "final_lap") == 1 && Lp(d, "final_lap") == 1, "Car_final_lap follows Lamp_final_lap");
            check(Lp(d, "shift") == 0, "shift stand-in off at 83% of Max revs");
            lf["car_rpm"].Value = 8200; Tick(d, dp1, 1.04);
            check(Lp(d, "shift") == 1, "shift stand-in on at 91% of Max revs");
            lf["car_in_race"].Value = 0; Tick(d, dp1, 1.05);
            check(Lp(d, "shift") == 0 && Lp(d, "start") == 1, "outside a race: the made-up shift light goes off, the game's lamps stay");

            var (d2, dp2) = LoadRows(null, null, "car_in_race", "car_gear", "lamp_leader", "lamp_shift", "car_position");
            lf["car_in_race"].Value = 1; lf["car_gear"].Value = 2; lf["car_position"].Value = 1; lf["lamp_leader"].Value = 0; lf["lamp_shift"].Value = 0;
            Tick(d2, dp2, 1.0);
            check(Lp(d2, "leader") == 0, "a game's own lamp_leader row wins over the stand-in");
            check(G(d2, "max_speed") == 0 && G(d2, "rev_limit_rpm") == 0 && G(d2, "rpm_dial") == 0 && G(d2, "speed_kmh") == 0, "blank boxes and no km/h row: 0");
            var (d3, dp3) = LoadRows(200, 8000, "car_speed");
            lf["car_speed"].Value = 100; Tick(d3, dp3, 1.0);
            check(d3.Common.GearText == "" && G(d3, "speed_kmh") == 0 && G(d3, "rev_limit_rpm") == 8000, "no gear row: empty gear text; no km/h row: 0; no limiter row: Max revs");
            check(CommonValues.LampsProvidedBy(new GameProfile { Variables = new List<VariableDef> { new VariableDef { Name = "lamp_start" }, new VariableDef { Name = "lampstart" } } }).SequenceEqual(new[] { "start" }),
                  "LampsProvidedBy lists the lamp_ rows a profile has");
            d.Common.Update(null, 3);
            check(Lp(d, "start") == 0 && d.Common.GearText == "", "no game selected: lamps 0, gear text empty");
        }

        // the three help files list every common property by its full name (0.20.0)
        {
            string Doc(string f) => System.IO.File.Exists("../../" + f) ? System.IO.File.ReadAllText("../../" + f) : "";
            var props = Doc("Common_Properties.md") + Doc("Common_Dashboard.md");
            var missing = CommonValues.Outputs.Select(o => "`TPTelemetry.Car_" + o.Name + "`").Concat(new[] { "`TPTelemetry.Car_gear_text`" }).Where(n => !props.Contains(n)).ToList();
            check(missing.Count == 0, "Common_Properties.md and Common_Dashboard.md list every Car_ property: " + string.Join(", ", missing));
            var lamps = Doc("Common_Lamps.md");
            var missingL = CommonValues.Lamps.Select(o => "`TPTelemetry.Lamp_" + o.Name + "`").Where(n => !lamps.Contains(n)).ToList();
            check(missingL.Count == 0, "Common_Lamps.md lists every Lamp_ property: " + string.Join(", ", missingL));
        }

        // the dummy profile's effects test: six 10-second windows, each ramping 0 -> 1 -> 0
        var dummy = ProfileStore.ReadProfile("../../profiles/DUMMY.json");
        var de = new TelemetryEngine();
        de.Load(new[] { dummy }, new PluginSettings { ActiveGame = "DUMMY" });
        var dp = de.Profiles[0];
        var seen = new Dictionary<string, List<(double t, double v)>>();
        foreach (var n in new[] { "impact", "wall_left", "rumble_strip", "road_bump", "off_road", "shift" }) seen[n] = new List<(double, double)>();
        dp.Connected = true;
        for (double t = 0.01; t < 60; t += 0.01)
        {
            TeknoTelemetry.Core.TelemetryEngine.EvaluateTick(dp, t);
            de.Common.Update(dp, t);
            foreach (var kv in seen) kv.Value.Add((t, de.Common.Get(kv.Key)));
        }
        double At(string n, double t) => seen[n].OrderBy(x => Math.Abs(x.t - t)).First().v;
        double MaxIn(string n, double a, double b) => seen[n].Where(x => x.t >= a && x.t < b).Max(x => x.v);
        var order = new[] { "impact", "wall_left", "rumble_strip", "road_bump", "off_road" };
        for (int i = 0; i < order.Length; i++)
        {
            double s0 = i * 10;
            check(Math.Abs(At(order[i], s0 + 5) - 1) < 0.01 && Math.Abs(At(order[i], s0 + 2.5) - 0.5) < 0.01 && At(order[i], s0 + 9.99) < 0.01,
                  $"dummy: Car_{order[i]} ramps 0 -> 1 at {s0 + 5} s -> 0 at {s0 + 10} s");
            check(order.Where(o => o != order[i]).All(o => MaxIn(o, s0 + 0.1, s0 + 9.9) == 0), $"dummy: only Car_{order[i]} runs from {s0} to {s0 + 10} s");
        }
        var shifts = seen["shift"].Where((x, k) => k > 0 && x.v > 0 && seen["shift"][k - 1].v == 0).Select(x => x.t).ToList();
        check(shifts.Count >= 9 && shifts.All(t => t >= 50), "dummy: a gear change every second from 50 to 60 s: " + shifts.Count);
    }
}
