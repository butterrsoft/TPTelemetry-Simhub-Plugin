using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;

// Battle Gear 4 Tuned (BG4JP): Alexis's recording of 10 November 2026, 20:58 (four cars, automatic, 25 marks: Brake!
// warnings and drifts; a checkpoint; a game freeze at 15.3 to 29.3 s; driving the wrong way to avoid a checkpoint, then
// time up). The fixture holds the raw reads (every second sample) and her USB steering.
static class Bg4Tests
{
    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "BG4JP");
        if (gamePackDir == null || !File.Exists(path)) return;
        var r = Replay(check, path, "bg4jp-20261110-205811.csv.gz");
        const string s = "BG4JP 20:58: ";

        // the game froze for 14 s: no racing (and so no effects) while its clock stood still
        check(r.At("racing", 14.0) == 1 && r.At("racing", 20.0) == 0 && r.CarAt("in_race", 20.0) == 0 && r.At("racing", 31.0) == 1,
              s + $"racing off while the game is frozen: 14 s {r.At("racing", 14.0)}, 20 s {r.At("racing", 20.0)}, 31 s {r.At("racing", 31.0)}");
        // the checkpoint (the lap line here): +60 s and lap 1
        check(r.At("checkpoint", 88.0) == 1 && r.At("lap", 88.0) == 1 && r.At("lap", 87.0) == 0 && r.At("time_left", 88.0) > 170,
              s + $"checkpoint at 87.7 s: time left {r.At("time_left", 88.0):0.0}, lap {r.At("lap", 88.0)}");
        // time up: race phase 11, the race and its effects stop
        check(r.At("race_phase", 262) == 11 && r.At("racing", 262) == 0 && r.CarAt("in_race", 262) == 0,
              s + $"time up: phase {r.At("race_phase", 262)}, racing {r.At("racing", 262)}");

        // drifts: the angle between the car's heading and its travel; + right-hand, following the wheel
        double Peak(double a, double b) => r.Out["drift_angle"].Where(x => x.t >= a && x.t <= b).OrderByDescending(x => Math.Abs(x.v)).First().v;
        double d1 = Peak(39.5, 40.3), d2 = Peak(131.8, 132.8), d3 = Peak(140.8, 141.6);
        check(d1 > 35 && d2 < -25 && d3 > 15, s + $"her marked drifts: {d1:0} (wheel right), {d2:0} (wheel left), {d3:0} (wheel right) degrees");
        double c1 = r.Car["drift"].Where(x => x.t >= 39.5 && x.t <= 40.3).Max(x => x.v);
        check(c1 > 0.4 && c1 < 0.7, s + $"Car_drift for a 48 degree drift at 27 km/h: {c1:0.00}");
        check(r.Car["grip_loss"].Zip(r.Car["drift"], (g, d) => double.IsNaN(d.v) || g.v >= d.v - 1e-9).All(x => x), s + "Car_grip_loss is at least the drift");
        // her Brake! marks: no drift there (straight-line braking)
        var calm = new[] { 38.25, 49.40, 60.84, 87.65, 152.39 }.Select(m => Math.Abs(Peak(m - 1.5, m + 0.3))).ToList();
        check(calm.All(a => a < 8), s + "no drift at her Brake! marks: " + string.Join(", ", calm.Select(a => a.ToString("0.0"))));
        // ordinary driving: the heading lines up with the travel within a few degrees
        var racing = r.Out["drift_angle"].Where((x, i) => r.Out["racing"][i].v == 1 && r.Out["speed"][i].v * 200 > 60).Select(x => Math.Abs(x.v)).OrderBy(v => v).ToList();
        check(racing[racing.Count / 2] < 2, s + $"median drift angle above 60 km/h {racing[racing.Count / 2]:0.00} degrees");
        // the drift's sign follows the wheel (her words): + with the wheel right, - left, in the big drifts
        int agree = 0, total = 0;
        for (int i = 0; i < r.Out["drift_angle"].Count; i++)
        {
            double a = r.Out["drift_angle"][i].v, w = r.Steer[i];
            if (Math.Abs(a) < 20 || Math.Abs(w) < 0.3) continue;
            total++; if (Math.Sign(a) == Math.Sign(w)) agree++;
        }
        check(total > 50 && agree > total * 0.8, s + $"drift sign follows the wheel in {agree} of {total} samples");

        // 11 November, 08:56: Brake! marks (she thinks she missed the first after the start). The car navigation's Brake!
        // trigger came about half a second before each mark, plus once after the start and once just after a checkpoint.
        var b = Replay(check, path, "bg4jp-20261111-085621.csv.gz");
        var brakes = new List<double>(); double last = -9;
        for (int i = 0; i < b.Out["brake_warning"].Count; i++)
        {
            var (t, v) = b.Out["brake_warning"][i];
            if (v > 0 && t - last > 2) brakes.Add(t);
            if (v > 0) last = t;
        }
        var marks = new[] { 43.07, 54.08, 60.64, 70.67, 93.12, 99.66 };
        check(brakes.Count == 8 && marks.All(m => brakes.Any(x => m - x > 0.2 && m - x < 1.2)),
              "BG4JP 08:56: Brake! before each of her marks: " + string.Join(", ", brakes.Select(x => x.ToString("0.00"))));
        double held = b.Out["brake_warning"].Where(x => x.t >= 42.4 && x.t <= 44.5 && x.v > 0).Select(x => x.t).DefaultIfEmpty(0).Max();
        check(held > 43.8 && held < 44.1, $"BG4JP 08:56: Brake! held 1.5 s ({held:0.00})");
        check(b.Out["corner_ahead"].Any(x => x.v > 0) && b.Out["corner_ahead"].Where(x => x.t > 59 && x.t < 61).All(x => x.v == 1) && b.Out["corner_ahead"].Where(x => x.t > 62 && x.t < 69).All(x => x.v == 0),
              "BG4JP 08:56: corner_ahead while a curve marker shows, off when it clears");
        // her names for the codes: 4 hairpin left (58.5 s), 2 medium right (41.8 s), 9 slight left (89.4 s), 48 snake right-left (46.3 s)
        double Side(double t) => b.Out["corner_side"].First(x => x.t >= t).v;
        double Sharp(double t) => b.Out["corner_sharpness"].First(x => x.t >= t).v;
        check(Side(59.5) == -1 && Sharp(59.5) == 1 && Side(42.5) == 1 && Sharp(42.5) == 0.6 && Side(90.0) == -1 && Sharp(90.0) == 0.3 &&
              Side(47.0) == 1 && Side(65.0) == 0 && Sharp(65.0) == 0,
              "BG4JP 08:56: corner side and sharpness from her names for the curve markers");
    }

    internal sealed class Bg4Replay
    {
        public Dictionary<string, List<(double t, double v)>> Out = new Dictionary<string, List<(double t, double v)>>();
        public Dictionary<string, List<(double t, double v)>> Car = new Dictionary<string, List<(double t, double v)>>();
        public List<double> Steer = new List<double>();
        public double At(string n, double t) => Out[n].First(x => x.t >= t).v;
        public double CarAt(string n, double t) => Car[n].First(x => x.t >= t).v;
    }

    static Bg4Replay Replay(Action<bool, string> check, string path, string fixture)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = "";
        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "BG4JP" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), "BG4JP rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
        ps.Connected = true;
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(kv.Key));
        // rows added after this recording (car_flags, the car navigation's signs) read blank
        var later = new HashSet<string> { "car_flags", "navi_curve", "navi_curve_on", "navi_sign", "navi_sign_on" };
        check(cols.All(c => c.Value >= 0 || later.Contains(c.Key)), "BG4JP: the recording has the memory rows: missing " + string.Join(", ", cols.Where(c => c.Value < 0 && !later.Contains(c.Key)).Select(c => c.Key)));
        var rp = new Bg4Replay();
        foreach (var v in ps.Vars) rp.Out[v.Def.Name] = new List<(double t, double v)>();
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        int tc = Col("time_s"), sc = Col("ffb_steer");
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            foreach (var kv in feeds) kv.Value.Value = Num(r, cols[kv.Key]);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            rp.Steer.Add(Num(r, sc));
        }
        return rp;
    }
}
