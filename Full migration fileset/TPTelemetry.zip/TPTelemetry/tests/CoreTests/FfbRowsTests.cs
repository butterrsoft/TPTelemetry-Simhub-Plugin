using System;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Ffb;

/// The settings page's "Add FFB values to table" / "Remove FFB values from table" button.
static class FfbRowsTests
{
    public static void Run(Action<bool, string> check)
    {
        int all = FfbTableRows.Channels.Length;
        check(all == 12, "12 USB values are offered, got " + all);
        check(!FfbTableRows.Channels.Contains(FfbChannels.Activity) && !FfbTableRows.Channels.Contains(FfbChannels.Connected) &&
              !FfbTableRows.Channels.Contains(FfbChannels.Raw0), "diagnostic channels aren't offered");

        var own = new VariableDef { Name = "speed", Source = SourceKind.Memory, Module = "<main>", BaseOffset = "10" };
        var mine = new VariableDef { Name = "my_force", Source = SourceKind.Computed, Formula = "ffb_force * 2" };
        var p = new GameProfile { Prefix = "T", Variables = { own, mine } };
        check(FfbTableRows.CountPresent(p) == 0 && !FfbTableRows.AllPresent(p), "none present at first");
        check(FfbTableRows.CountPresent(null) == 0 && !FfbTableRows.AllPresent(null), "no game: none present");

        check(FfbTableRows.AddMissing(p) == all && FfbTableRows.AllPresent(p), "Add adds them all");
        check(p.Variables[0] == own && p.Variables[1] == mine && p.Variables.Count == 2 + all, "added at the end; the game's own rows are untouched");
        check(p.Variables.Any(v => v.Name == "wheel_force" && v.Formula == "ffb_force") && p.Variables.Any(v => v.Name == "wheel_steer"),
              "rows are named wheel_<channel>");
        check(FfbTableRows.AddMissing(p) == 0 && p.Variables.Count == 2 + all, "adding again adds nothing");

        // the user removes one and renames another: only the missing one comes back, under its usual name
        p.Variables.RemoveAll(v => v.Name == "wheel_brake");
        p.Variables.First(v => v.Name == "wheel_spring").Name = "spring_on_wheel";
        check(FfbTableRows.CountPresent(p) == all - 1 && !FfbTableRows.AllPresent(p), "a removed row counts as missing; a renamed one still counts");
        check(FfbTableRows.AddMissing(p) == 1 && p.Variables.Count(v => v.Formula == "ffb_spring") == 1, "only the missing row is added back");

        // a name already taken by something else
        var q = new GameProfile { Variables = { new VariableDef { Name = "wheel_force", Source = SourceKind.Memory, Module = "x.dll", BaseOffset = "4" } } };
        FfbTableRows.AddMissing(q);
        check(q.Variables.Any(v => v.Name == "wheel_force_2" && v.Formula == "ffb_force") && q.Variables[0].Source == SourceKind.Memory,
              "a taken name gets _2, and the existing row is left alone");

        check(FfbTableRows.RemoveAll(p) == all && p.Variables.Count == 2 && p.Variables[0] == own && p.Variables[1] == mine,
              "Remove takes out all of them, renamed ones too, and nothing else");
        check(FfbTableRows.CountPresent(p) == 0, "none left after Remove");

        // rows that use a channel in a bigger formula, or a memory row, aren't these rows
        check(FfbTableRows.ChannelOf(mine) == -1, "a formula that uses ffb_force isn't one of these rows");
        check(FfbTableRows.ChannelOf(new VariableDef { Source = SourceKind.Computed, Formula = " FFB_Steer " }) == FfbChannels.Steer, "spaces and case don't matter");
        check(FfbTableRows.ChannelOf(new VariableDef { Source = SourceKind.Computed, Formula = "ffb_activity" }) == -1, "ffb_activity isn't one of them");

        // the added rows compile and run in the engine
        var r = new GameProfile { Prefix = "R" };
        FfbTableRows.AddMissing(r);
        var eng = new TelemetryEngine();
        eng.Load(new[] { r }, new PluginSettings { ActiveGame = "R" });
        check(eng.Profiles[0].Vars.All(v => !v.HasConfigError), "added rows have no errors: " +
              string.Join("; ", eng.Profiles[0].Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
    }
}
