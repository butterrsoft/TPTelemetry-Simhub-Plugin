using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.TeknoParrot;
using Replay = Wmmt5ReplayTests.Replay;

/// <summary>
/// Replays a real WMMT3DX+ recording through the pack's WMMT3DXP profile: the memory rows get the speed,
/// revs and gear read at the time, and TeknoParrot's slots the values the game wrote.
///  * 1 November 2026, 15:49: freeway, 47 s. 22 markers: 1-13 and 15-20 straight after expansion joints,
///    14, 21 and 22 after crashes (right at 24.1 s from 228 to 68 km/h, then pushed along the right-hand
///    wall; right at 42.8 s; left at 45.5 s to the end). Top speed 220 km/h, top revs 8999 (per Alexis).
///  * 1 November 2026, 15:54: 39 s, Alexis's log: 1 down through the gears to neutral at max revs;
///    2, 3, 4 joints; 5 crash into the left-hand wall and scrape; 6 the same on the right; 7, 8 "not
///    clear, possibly joints" (they are); 9, 10 joints; 11 crash into the left-hand wall and scrape.
///    The game detaches at 37.07 s (memory rows blank from there).
/// </summary>
static class Wmmt3ReplayTests
{
    static readonly int[] CrashMarks = { 14, 21, 22 };

    static Replay Run(Action<bool, string> check, string path, string fixture)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = ""; // no process: runs on the replayed values

        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);

        var tp = new double[TpChannels.Count];
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            TpSource = a => Array.Copy(tp, a, a.Length),
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "WMMT3DXP" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), "WMMT3DXP rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));

        var rp = new Replay { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()) };
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        ps.Connected = true;
        int tc = Col("time_s"), mc = Col("marker");
        // The recordings were made with the cheat table's rows, a copy of the meter: speed km/h, revs RPM and gear. The
        // profile now reads the game's own car (11 November 2026: speed in mm/s, revs in rad/s), so each sample is fed
        // in those units. The game was racing throughout
        // (race state 2) while attached; at the detach (15:54, 37.07 s) the memory columns go blank, so the game's
        // reads do too.
        var fromCol = new Dictionary<string, (string col, Func<double, double> conv)>
        {
            ["speed"] = ("speed", x => x / 0.0036), ["rpm"] = ("rpm", x => x * 2 * Math.PI / 60), ["gear"] = ("gear", x => x),
            // the clocks keep moving while racing (in_race is off while they stand still, as in a pause)
            ["race_time"] = ("time_s", x => x), ["countdown"] = ("speed", x => double.IsNaN(x) ? double.NaN : 0),
            ["seq_active"] = ("speed", x => double.IsNaN(x) ? double.NaN : 1), ["race_state"] = ("speed", x => double.IsNaN(x) ? double.NaN : 2),
        };
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(fromCol.TryGetValue(kv.Key, out var fc) ? fc.col : kv.Key));
        // Rows added after these recordings were made (from cheat tables or the game's code) aren't in them: they read nothing here.
        var later = new HashSet<string>(prof.Variables.Where(v => (v.Notes ?? "").Contains("cheat table") && !fromCol.ContainsKey(v.Name)
                                                                 || (v.Notes ?? "").Contains("the game's own code") && !fromCol.ContainsKey(v.Name)).Select(v => v.Name));
        check(cols.Where(c => !later.Contains(c.Key)).All(c => c.Value >= 0), "the recording has every memory row: " + string.Join(", ", cols.Where(c => c.Value < 0 && !later.Contains(c.Key)).Select(c => c.Key)));
        var slots = Enumerable.Range(0, TpChannels.SlotCount).Select(i => Col("tp_jvs" + i)).ToArray();
        int conn = Col("tp_connected");
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            if (r[mc] != "") rp.Marks.Add(t);
            foreach (var kv in feeds) kv.Value.Value = fromCol.TryGetValue(kv.Key, out var fc) ? fc.conv(Num(r, cols[kv.Key])) : Num(r, cols[kv.Key]);
            for (int i = 0; i < slots.Length; i++) tp[i] = Num(r, slots[i]);
            tp[TpChannels.Connected] = Num(r, conn);
            eng.TpSource(ps.Ctx.Tp);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            rp.End = t;
        }
        return rp;
    }

    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "WMMT3DXP");
        if (gamePackDir == null || !File.Exists(path)) return;
        First(check, Run(check, path, "wmmt3dxp-20261101-154943.csv.gz"));
        Second(check, Run(check, path, "wmmt3dxp-20261101-155436.csv.gz"));
    }

    static void First(Action<bool, string> check, Replay r)
    {
        var m = r.Marks;
        check(m.Count == 22, "22 markers in the recording: " + m.Count);
        if (m.Count != 22) return;
        double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();

        check(r.Min("in_race", 0, r.End) == 1 && r.Car["in_race"].Min(x => x.v) == 1, "in_race (race state 2) throughout the drive");

        // speed, revs, gear
        check(r.Max("speed", 0, r.End) > 1 && r.Car["speed"].Max(x => x.v) > 225, "speed passes the 220 km/h Max speed (230 seen): Car_speed raw " + r.Car["speed"].Max(x => x.v).ToString("0.0", CultureInfo.InvariantCulture));
        check(r.Car["speed_frac"].Max(x => x.v) == 1, "Car_speed_frac stops at 1");
        check(Math.Abs(r.Max("rpm", 0, r.End) * 10000 - 8999) < 1, "rpm reaches 8999 (the old row's top; Max revs 10000 since 11 November 2026)");
        check(r.Max("gear", 0, 5.5) == 0 && r.Min("gear", 6, r.End) >= 1 && r.Max("gear", 0, r.End) == 5, "gear 0 before driving, then 1 to 5");
        var ratios = new[] { 102.0, 70, 48, 39, 33 };
        for (int g = 1; g <= 5; g++)
        {
            var rs = r.Out["gear"].Select((x, i) => (x, i)).Where(p => p.x.v == g && r.Out["speed"][p.i].v * 220 > 30 && r.Out["rpm"][p.i].v * 10000 < 8820)
                       .Select(p => r.Out["rpm"][p.i].v * 10000 / (r.Out["speed"][p.i].v * 220)).OrderBy(x => x).ToList();
            if (rs.Count == 0) continue;
            var med = rs[rs.Count / 2];
            check(Math.Abs(med / ratios[g - 1] - 1) < 0.1, $"gear {g} is the gear in play (not one low): {med:0} revs per km/h");
        }

        // joints
        var jointMarks = m.Where((x, i) => !CrashMarks.Contains(i + 1)).ToList();
        int found = jointMarks.Count(x => r.Max("road_joint", x - 0.6, x) > 0.3);
        check(found == jointMarks.Count, $"road_joint fires before every joint marker: {found} of {jointMarks.Count}");
        // Each joint is usually two pulses about 0.07 s apart (front then rear wheels): 41 pulses, 25 joints.
        var joints = r.Events("road_joint");
        var pulses = r.Events("road_joint", 0, 0.03);
        check(pulses.Count >= 38 && pulses.Count <= 44 && joints.Count >= 22 && joints.Count <= 28, $"41 joint pulses, 25 joints (found by hand): {pulses.Count} pulses, {joints.Count} joints");
        check(r.Out["road_bump"].Max(x => x.v) <= 1 && r.Max("road_bump", 30, 42) > 0.9, "road_bump 0 to 1, near 1 at 220 km/h");

        // crashes and walls
        var crashes = CrashMarks.Select(k => m[k - 1]).ToList();
        check(crashes.All(c => r.Max("impact", c - 1.0, c) == 1), "impact before each crash marker");
        check(r.At("impact_side", 24.2) == 1 && r.At("impact_side", 42.9) == 1 && r.At("impact_side", 45.6) == -1, "impact_side: right, right, left");
        bool Quiet(string n, double a, double b) => r.Max(n, a, b) == 0 && r.Min(n, a, b) == 0;
        check(Quiet("impact", 0, 24.0) && Quiet("impact", 27.9, 42.7), "no impact away from the crashes: " + r.Spans("impact"));
        check(r.Min("wall_contact", 24.6, 27.6) == 1 && r.Min("wall_contact", 43.2, 44.2) == 1 && r.Max("wall_contact", 45.9, 47.0) == -1 && r.Min("wall_contact", 45.9, 47.0) == -1,
              "wall_contact along each wall: right, right, left: " + r.Spans("wall_contact"));
        check(Quiet("wall_contact", 0, 24.3) && Quiet("wall_contact", 27.9, 43.0) && Quiet("wall_contact", 44.5, 45.7), "wall_contact off elsewhere");
        check(Quiet("road_joint", 24.0, 27.9) && Quiet("road_joint", 42.7, 44.4) && Quiet("road_joint", 45.4, r.End), "no joints read during crashes or along the walls");

        // common values
        check(CarMax("impact", 24.0, 24.4) > 0.9, "Car_impact about 1 for the 228 to 68 km/h crash: " + CarMax("impact", 24.0, 24.4).ToString("0.00", CultureInfo.InvariantCulture));
        check(crashes.All(c => CarMax("impact", c - 1.0, c) >= 0.6), "Car_impact at least 0.6 at every crash");
        check(CarMax("wall_right", 25, 27) == 1 && CarMax("wall_left", 46, 47) == 1 && CarMax("wall_left", 0, 45.5) == 0, "Car_wall_right and Car_wall_left");
        check(jointMarks.All(x => CarMax("road_bump", x - 0.6, x) > 0.4), "Car_road_bump at every joint marker");
        check(CarMax("braking", 24.0, 24.6) == 1, "Car_braking during the big crash");
        check(CarMax("shift", 6, 40) == 1, "Car_shift on gear changes");
        Console.WriteLine($"WMMT3DX+ replay 15:49: {found}/{jointMarks.Count} joint markers, {joints.Count} joints; wall {r.Spans("wall_contact")}; " +
                          $"Car_impact {string.Join(", ", crashes.Select(c => CarMax("impact", c - 1.0, c).ToString("0.00", CultureInfo.InvariantCulture)))}");
    }

    static void Second(Action<bool, string> check, Replay r)
    {
        var m = r.Marks;
        check(m.Count == 11, "11 markers in the second recording: " + m.Count);
        if (m.Count != 11) return;
        double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        bool Quiet(string n, double a, double b) => r.Max(n, a, b) == 0 && r.Min(n, a, b) == 0;

        // marker 1: down through the gears to neutral, revs near the limiter
        check(r.At("gear", 1.0) == 3 && r.At("gear", 3.0) == 1 && r.At("gear", m[0]) == 0 && r.At("rpm", m[0]) * 10000 > 8820,
              "marker 1: down through 3, 2, 1 to neutral (gear 0) near max revs");
        check(r.Max("gear", 30, 36) == 6, "this car has a sixth gear");
        check(CarMax("shift", 0.5, 5) == 1, "Car_shift on the way down");

        var crashes = new[] { (m[4], -1), (m[5], 1), (m[10], -1) };
        var jointMarks = new[] { 1, 2, 3, 6, 7, 8, 9 }.Select(i => m[i]).ToList();
        int found = jointMarks.Count(x => r.Max("road_joint", x - 0.6, x + 0.1) > 0.3);
        check(found == jointMarks.Count, $"road_joint at every joint marker (7 and 8 included): {found} of {jointMarks.Count}");
        check(r.Max("road_joint", 28.9, 29.2) > 0.3 && Quiet("wall_contact", 28.0, 30.0),
              "two joints running together at marker 9 (0.2 s of 30s and 32s) read as joints, not a wall");

        check(crashes.All(c => r.Max("impact", c.Item1 - 0.6, c.Item1 + 0.1) == 1), "impact at each crash marker");
        check(crashes.All(c => r.Out["impact_side"].Where(x => x.t >= c.Item1 - 0.6 && x.t <= c.Item1 + 0.1).Any(x => x.v == c.Item2)),
              "impact_side: left, right, left");
        check(Quiet("impact", 0, 18.7) && Quiet("impact", 24.5, 35.4), "no impact away from the crashes: " + r.Spans("impact"));
        check(r.Min("wall_contact", 19.2, 19.9) == -1 && r.Min("wall_contact", 22.9, 23.9) == 1 && r.Max("wall_contact", 35.9, 36.7) == -1,
              "wall_contact along each wall, left, right, left: " + r.Spans("wall_contact"));
        check(r.Max("wall_contact", 18.7, 21) <= 0 && r.Min("wall_contact", 22.4, 24.5) >= 0 && r.Max("wall_contact", 35.4, r.End) <= 0,
              "wall_contact never takes the wrong side");
        check(Quiet("wall_contact", 0, 18.8) && Quiet("wall_contact", 24.6, 35.4), "wall_contact off away from the walls");

        check(CarMax("impact", 22.5, 22.7) == 1, "Car_impact 1 for the right-hand crash (196 to 124 km/h in a frame)");
        check(CarMax("wall_left", 19.2, 19.9) == 1 && CarMax("wall_right", 22.9, 23.9) == 1, "Car_wall_left and Car_wall_right");
        check(r.Car["speed"].Where(x => x.t > 37.2).All(x => x.v == 0) && CarMax("impact", 37.2, r.End) == 0, "game detached at 37.07 s: values drop to 0");
        Console.WriteLine($"WMMT3DX+ replay 15:54: {found}/{jointMarks.Count} joint markers, {r.Events("road_joint").Count} joints; " +
                          $"wall {r.Spans("wall_contact")}; impact {r.Spans("impact")}");
    }
}
