using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TeknoTelemetry.Core;

// Mario Kart Arcade GP DX (USA) (MKGPDXUSA): Alexis's first USA recording with 0.18.1 (11 November 2026, 14:33): Bowser Jr cup
// course 3, three laps from 6th, finished 2nd (same surface codes as course 2, below). Raw reads from 40 s (the unticked axis rows weren't recorded).
static class MkUsaTests
{
    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "MKGPDXUSA");
        if (gamePackDir == null || !File.Exists(path)) return;
        var r = Mk118Tests.Replay(check, path, "mkgpdxusa-20261111-143354.csv.gz", "MKGPDXUSA",
            new HashSet<string> { "travel_x", "travel_z", "side_x", "side_z", "heading_x", "heading_z" });
        const string s = "MKGPDXUSA 14:33: ";
        List<(double t, double v)> O(string n) => r.Out[n];
        double At(string n, double t) => O(n).First(x => x.t >= t).v;
        double Side(double t) => O("hit_side").Where(x => x.t >= t && x.t <= t + 0.4).Select(x => x.v).FirstOrDefault(v => v != 0);
        int Rises(string n, double a, double b) => O(n).Zip(O(n).Skip(1), (x, y) => y.t > a && y.t < b && x.v <= 0 && y.v > 0 ? 1 : 0).Sum();

        check(At("racing", 77.2) == 0 && At("racing", 77.4) == 1 && At("racing", 236.8) == 1 && At("racing", 237.0) == 0 &&
              r.Car["in_race"].First(x => x.t >= 240).v == 0, s + "racing from GO to the line, not after");
        check(At("laps_total", 100) == 3 && At("lap", 100) == 1 && At("lap", 131.0) == 2 && At("lap", 182.1) == 3 && At("final_lap", 200) == 1,
              s + "three laps");
        check(At("position", 70) == 6 && At("position", 100) == 1 && At("position", 235) == 2, s + "6th on the grid, leading in lap 1, 2nd at the line");
        check(Math.Abs(At("race_time", 130.94) - 51.552) < 0.05 && Math.Abs(At("race_time", 237.5) - 153.242) < 0.02,
              s + $"race time {At("race_time", 237.5)} s at the line");
        // drifts: + right-hand, as in v1.18; drift_side 1 = left
        var dr = O("drift_angle").Where((x, i) => O("drift")[i].v == 1 && O("racing")[i].v == 1 && Math.Abs(x.v) > 10).Select((x, i) => x).ToList();
        int agree = O("drift_angle").Where((x, i) => O("drift")[i].v == 1 && O("racing")[i].v == 1 && Math.Abs(x.v) > 10)
                                    .Count(x => (x.v < 0) == (At("drift_side", x.t) == 1));
        check(dr.Count > 1000 && agree > 0.9 * dr.Count, s + $"drift angle sign agrees with drift_side in {agree} of {dr.Count} drift samples");
        check(At("terrain", 125.0) == 9 && At("terrain", 176.0) == 9, s + "carpet (code 9) where her marks are");
        check(At("spin", 132.5) == 1 && At("spin", 194.0) == 1 && At("airborne", 132.5) == 1 && Side(131.56) == 0 && Side(194.9) == 0,
              s + "the two tumbles in the air (state 11) are spins, with no hit side");
        check(At("item_held", 104.8) == 1 && At("item_held", 105.5) == 1 && Rises("item_held", 104.0, 106.5) == 0,
              s + "the item lamp's flashes don't count as new items");
        var lamps = O("ob_kanbansidelampdata").Where(x => x.t > 48.5 && x.t < 77).Select(x => x.v).Distinct().Count();
        check(lamps > 5, s + $"the side lamp word changes before GO ({lamps} values), as on a cabinet");
        check(At("gliding", 100.0) == 1 && At("gliding", 97.5) == 0, s + "the glide");
        check(At("off_road", 125.5) == 0 && At("off_road", 115.5) == 0.3, s + "carpet (9) smooth, floorboards (8) 0.3");
        Course2(check, path);
    }

    // Her second USA recording (11 November 2026, 15:12): Bowser Jr cup course 2, three laps, won. Her names: 8 smooth floorboards,
    // 15 cloud, 5 checkerplate, 9 carpet, 2 metal grille sections, 0 the boost ramps before the glides. 123.1 and 134.8 s a bomb
    // threw her skyward spinning (state 7). Hit sides as she gave them.
    static void Course2(Action<bool, string> check, string path)
    {
        var r = Mk118Tests.Replay(check, path, "mkgpdxusa-20261111-151213.csv.gz", "MKGPDXUSA",
            new HashSet<string> { "travel_x", "travel_z", "side_x", "side_z", "heading_x", "heading_z" });
        const string s = "MKGPDXUSA 15:12: ";
        List<(double t, double v)> O(string n) => r.Out[n];
        double At(string n, double t) => O(n).First(x => x.t >= t).v;
        double Side(double t) => O("hit_side").Where(x => x.t >= t && x.t <= t + 0.4).Select(x => x.v).FirstOrDefault(v => v != 0);
        check(At("racing", 75.6) == 0 && At("racing", 75.9) == 1 && At("racing", 232.0) == 1 && At("racing", 232.2) == 0 &&
              At("lap", 131) == 2 && At("lap", 182) == 3 && At("position", 231) == 1, s + "three laps from GO to the line, won");
        check(At("off_road", 155.0) == 0.3 && At("off_road", 147.0) == 0 && At("off_road", 173.0) == 0 && At("off_road", 176.5) == 0,
              s + $"floorboards {At("off_road", 155.0)}, cloud {At("off_road", 147.0)}, checkerplate {At("off_road", 173.0)}, carpet {At("off_road", 176.5)}");
        check(At("rumble_strip", 152.0) == 1 && At("rumble_strip", 202.0) == 1 && At("rumble_strip", 147.0) == 0, s + "metal grille sections as a rumble strip");
        check(At("spin", 124.0) == 1 && At("spin", 135.5) == 1 && At("knocked", 124.0) == 1 && At("spin", 127.0) == 0 &&
              Side(123.15) == 0 && Side(134.85) == 0, s + "the bomb blasts (state 7) are spins, with no hit side");
        var sides = new[] { (78.07, -1), (78.62, 1), (90.36, 1), (93.52, 1), (146.58, -1), (149.98, 1), (158.52, 1), (159.34, 1), (176.04, 1) };
        check(sides.All(e => Side(e.Item1) == e.Item2) && Side(148.17) == 0 && Side(187.47) == 0,
              s + "hit sides: " + string.Join(", ", sides.Select(e => $"{e.Item1} {Side(e.Item1)}")) + $"; items from behind {Side(148.17)}, {Side(187.47)}");
    }
}
