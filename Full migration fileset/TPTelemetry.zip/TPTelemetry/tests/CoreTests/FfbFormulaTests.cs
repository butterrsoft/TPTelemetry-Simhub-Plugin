using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Ffb;

/// Runs FFB formulas over the G25 capture at the plugin's 120 Hz poll rate.
static class FfbFormulaTests
{
    public static Dictionary<string, List<(double t, double v)>> Simulate(IEnumerable<VariableDef> rows)
    {
        var r = new PcapStreamReader(File.OpenRead("fixtures/g25-wmmt3dxp.pcapng")); r.ReadHeader();
        var packets = new List<UsbPacket>(); UsbPacket p;
        while ((p = r.Next()) != null) packets.Add(p);
        double t0 = packets[0].Time, now = 0;
        var pipe = new FfbPipeline(FfbDecoderChoice.Auto, 16, () => now);
        var prof = new GameProfile { Prefix = "SIM", Variables = rows.Select(x => x.Clone()).ToList() };
        var eng = new TelemetryEngine();
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "SIM" });
        var ps = eng.Profiles[0];
        var outp = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double, double)>());
        int i = 0;
        for (double t = 0; t < 57; t += 1.0 / 120)
        {
            now = t;
            while (i < packets.Count && packets[i].Time - t0 <= t) pipe.OnPacket(packets[i++]);
            pipe.Snapshot(ps.Ctx.Ffb, true);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) outp[v.Def.Name].Add((t, v.Output));
        }
        foreach (var v in ps.Vars.Where(v => v.HasConfigError)) Console.WriteLine($"  {v.Def.Name}: {v.Status}");
        return outp;
    }

    /// <summary>WMMT3's force feedback decodes, worked out from this capture. They used to ship as the
    /// WMMT3DXP profile's _usb rows; the profile now uses TeknoParrot's copy of the same signal
    /// (tp_ rows, same formulas), and USB rows are added on request. Kept here as the record of how
    /// the decode was checked, built on the rows the settings page's button adds.</summary>
    static IEnumerable<VariableDef> Wmmt3UsbDecode()
    {
        var p = new GameProfile();
        FfbTableRows.AddMissing(p);
        VariableDef C(string n, string f) => new VariableDef { Name = n, Source = SourceKind.Computed, Formula = f };
        return p.Variables.Concat(new[]
        {
            C("grip_loss_usb", "clamp((1 - wheel_spring) / 0.3, 0, 1)"),
            C("cornering_usb", "ema(wheel_force, 0.15)"),
            C("cornering_abs_usb", "abs(cornering_usb)"),
            C("road_bump_usb", "clamp(abs(wheel_force - ema(wheel_force, 0.15)) * 2, 0, 1)"),
            C("impact_now_usb", "wheel_spring < 0.5 || abs(wheel_force) > 0.99"),
            C("impact_dir_usb", "sign(maxw(wheel_force, 0.3) + minw(wheel_force, 0.3))"),
            C("impact_usb", "maxw(impact_now_usb, 0.15)"),
            C("impact_side_usb", "maxw(impact_now_usb && impact_dir_usb > 0, 0.15) - maxw(impact_now_usb && impact_dir_usb < 0, 0.15)"),
        });
    }

    public static void Run(Action<bool, string> check)
    {
        var s = Simulate(Wmmt3UsbDecode());
        double Max(string n, double a, double b) => s[n].Where(x => x.t >= a && x.t <= b).Max(x => x.v);
        // capture clock (your video clock minus about 1.2 s)
        Console.WriteLine($"WMMT3 FFB formulas: grip_loss straight {Max("grip_loss_usb", 17, 20.5):0.00}, slides {Max("grip_loss_usb", 29.8, 30.6):0.00}/{Max("grip_loss_usb", 43.9, 45.7):0.00}; " +
                          $"bump at joints {Max("road_bump_usb", 15.9, 16.5):0.00}/{Max("road_bump_usb", 19.7, 20.0):0.00}/{Max("road_bump_usb", 23.3, 23.6):0.00}, during smooth cornering {Max("road_bump_usb", 30.0, 30.9):0.00}; " +
                          $"impact before graze {Max("impact_usb", 2.5, 26.5):0}, crash {Max("impact_usb", 49, 53):0}");
        check(Max("grip_loss_usb", 17, 20.5) < 0.05, "grip_loss ~0 driving straight");
        check(Max("grip_loss_usb", 29.8, 30.6) > 0.6 && Max("grip_loss_usb", 43.9, 45.7) > 0.9, "grip_loss high in the slides");
        check(Max("road_bump_usb", 15.9, 16.5) > 0.5 && Max("road_bump_usb", 19.7, 20.0) > 0.5 && Max("road_bump_usb", 23.3, 23.6) > 0.5, "bump fires at expansion joints");
        check(Max("road_bump_usb", 30.0, 30.9) < 0.35, "bump stays low through smooth cornering force");
        check(Max("impact_usb", 2.5, 26.5) == 0 && Max("impact_usb", 49, 53) == 1, "impact only in the crashes");
        check(Max("cornering_usb", 30.0, 30.9) > 0.5, "cornering load follows the sustained force");
        double Min(string n, double a, double b) => s[n].Where(x => x.t >= a && x.t <= b).Min(x => x.v);
        // wall contacts (capture clock = video clock - 1.2 s): graze 27.1, RHS 46.3-47.8, LHS 49.2-50.4, RHS 51.5-53.3
        Console.WriteLine($"impact_side: graze {Max("impact_side_usb", 26.9, 27.3):+0;-0;0}, RHS {Max("impact_side_usb", 46.2, 47.9):+0;-0;0}/{Min("impact_side_usb", 46.2, 47.9):+0;-0;0}, " +
                          $"LHS {Min("impact_side_usb", 49.1, 50.5):+0;-0;0}/{Max("impact_side_usb", 49.1, 50.5):+0;-0;0}, RHS {Max("impact_side_usb", 51.4, 53.4):+0;-0;0}/{Min("impact_side_usb", 51.4, 53.4):+0;-0;0}");
        check(Max("impact_side_usb", 26.9, 27.3) == 1, "wall graze reads right (+1)");
        check(Max("impact_side_usb", 46.2, 47.9) == 1 && Min("impact_side_usb", 46.2, 47.9) >= 0, "first crash reads right only (RHS wall)");
        check(Min("impact_side_usb", 49.1, 50.5) == -1 && Max("impact_side_usb", 49.1, 50.5) <= 0, "second crash reads left only (LHS wall)");
        check(Max("impact_side_usb", 51.4, 53.4) == 1 && Min("impact_side_usb", 51.4, 53.4) >= 0, "third crash reads right only (RHS wall)");
        check(Max("impact_usb", 2.5, 26.5) == 0, "no impacts before the graze");
        check(Math.Abs(Max("cornering_abs_usb", 30, 31) - Max("cornering_usb", 30, 31)) < 1e-9 && Min("cornering_usb", 36, 37.5) < -0.5, "cornering + right / - left, cornering_abs its size");
    }
}
