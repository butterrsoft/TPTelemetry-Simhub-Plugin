using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Ffb;

/// Runs FfbCapture against a stand-in for USBPcapCMD (a shell script), on non-Windows test machines.
static class FfbCaptureTests
{
    public static void Run(Action<bool, string> check, Action<double, double, double, string> near)
    {
        // extcap parsing, as Wireshark's extcap protocol lays it out
        var sample = "interface {value=\\\\.\\USBPcap1}{display=USBPcap1}\n" +
                     "arg {number=99}{call=--devices}{display=Attached USB Devices}{type=multicheck}\n" +
                     "value {arg=99}{value=11}{display=[11] Generic USB Hub}{enabled=true}\n" +
                     "value {arg=99}{value=16}{display=[16] Logitech G25 Racing Wheel USB}{enabled=true}{parent=11}\n" +
                     "value {arg=99}{value=16_1}{display=Logitech G25 Racing Wheel USB (HID)}{enabled=false}{parent=16}\n";
        var vals = FfbCapture.ParseExtcap(sample, "value");
        check(vals.Count == 3 && vals[1]["display"] == "[16] Logitech G25 Racing Wheel USB", "extcap value lines parsed");

        // Finding the chosen wheel again (0.16.0): by name, preferring the same hub and address.
        var g25 = new UsbDeviceChoice { Interface = @"\\.\USBPcap1", Device = 16, Display = "[16] Logitech G25 Racing Wheel USB" };
        var moved = new UsbDeviceChoice { Interface = @"\\.\USBPcap2", Device = 5, Display = "[5] Logitech G25 Racing Wheel USB" };
        var kbd = new UsbDeviceChoice { Interface = @"\\.\USBPcap1", Device = 16, Display = "[16] USB Keyboard" };
        check(FfbCapture.DeviceLabel("[16] Logitech G25 Racing Wheel USB") == "Logitech G25 Racing Wheel USB" && FfbCapture.DeviceLabel("Plain") == "Plain",
              "the device name without its [address]");
        check(FfbCapture.Match(new[] { kbd, moved, g25 }, g25.Interface, 16, g25.Display) == g25, "same name, hub and address: that one");
        check(FfbCapture.Match(new[] { kbd, moved }, g25.Interface, 16, g25.Display) == moved, "the wheel on another hub at a new address, not the keyboard now at [16]");
        check(FfbCapture.Match(new[] { kbd }, g25.Interface, 16, g25.Display) == null, "not plugged in: no match");
        check(FfbCapture.Match(new[] { kbd }, g25.Interface, 16, "") == kbd, "no saved name (older settings): the saved address");
        check(FfbCapture.Match(new[] { g25, moved }, g25.Interface, 16, g25.Display, g25.Interface + "|16") == moved, "an address found to be another device is skipped");

        if (Environment.OSVersion.Platform == PlatformID.Win32NT) return; // the stand-in is a shell script

        var dir = Path.Combine(Path.GetTempPath(), "tpt-ffb-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(dir);
        var pcap = Path.Combine(dir, "g25.pcap");
        File.WriteAllBytes(pcap, FfbTestsAccess.PcapOfFixture());
        long half = new FileInfo(pcap).Length / 2;
        var exe = Path.Combine(dir, "USBPcapCMD.exe");
        File.WriteAllText(exe,
            "#!/bin/sh\n" +
            "if [ \"$1\" = \"--extcap-interfaces\" ]; then printf 'interface {value=\\\\\\\\.\\\\USBPcap1}{display=USBPcap1}\\n'; exit 0; fi\n" +
            "if [ \"$3\" = \"--extcap-config\" ]; then cat \"" + Path.Combine(dir, "config.txt") + "\"; exit 0; fi\n" +
            "printf '%s ' \"$@\" > \"" + Path.Combine(dir, "args.txt") + "\"\n" +
            "echo run >> \"" + Path.Combine(dir, "runs.txt") + "\"\n" +
            $"head -c {half} \"{pcap}\"; sleep 1; tail -c +{half + 1} \"{pcap}\"; sleep 3\n");
        File.WriteAllText(Path.Combine(dir, "config.txt"), sample.Substring(sample.IndexOf("arg ", StringComparison.Ordinal)));
        System.Diagnostics.Process.Start("chmod", $"+x \"{exe}\"").WaitForExit();

        var devices = FfbCapture.ListDevices(exe, out var err);
        check(err == null && devices.Any(d => d.Device == 16 && d.Interface == @"\\.\USBPcap1" && d.Display.Contains("G25")),
              "Find devices lists the G25: " + (err ?? string.Join(", ", devices)));
        check(!devices.Any(d => d.Display.Contains("(HID)")), "interface children aren't offered as devices");

        var cap = new FfbCapture { CapturesFolder = Path.Combine(dir, "Captures") };
        var engine = new TelemetryEngine { FfbSource = cap.Snapshot };
        var settings = new FfbSettings { Enabled = true, Interface = @"\\.\USBPcap1", Device = 16, DeviceName = "[16] Logitech G25 Racing Wheel USB", UsbPcapCmdPath = exe };
        var changes = new List<FfbSettings>();
        cap.DeviceChanged += d => { lock (changes) changes.Add(d); };
        cap.Apply(settings);
        var waited = Wait(() => cap.IsCapturing, 3000);
        check(waited, "capture running: " + cap.Status);
        var args = File.Exists(Path.Combine(dir, "args.txt")) ? File.ReadAllText(Path.Combine(dir, "args.txt")).Trim() : "";
        check(args == @"-d \\.\USBPcap1 -o - --devices 16 --inject-descriptors", "USBPcapCMD started with: " + args);

        var rec = cap.StartRecording(60);   // during the pause after the first half
        Thread.Sleep(2500);                  // second half arrives
        check(cap.Status.Contains("Logitech classic"), "status names the decoder: " + cap.Status);
        var v = new double[FfbChannels.Count];
        cap.Snapshot(v);
        check(v[FfbChannels.Connected] == 1, "connected while capturing");
        near(v[FfbChannels.Spring], 1.0, 1e-9, "final spring as in the capture (full)");
        near(v[FfbChannels.Damper], 1.0, 1e-9, "final damper as in the capture");

        // formulas see the channels through the engine
        var prof = new GameProfile { Prefix = "FFBTEST", Variables =
        {
            new VariableDef { Name = "grip_loss", Source = SourceKind.Computed, Formula = "clamp((1 - ffb_spring) / 0.3, 0, 1)" },
            new VariableDef { Name = "online", Source = SourceKind.Computed, Formula = "ffb_connected" },
        } };
        engine.Load(new[] { prof }, new PluginSettings { ActiveGame = "FFBTEST" });
        var ps = engine.Profiles[0];
        engine.FfbSource(ps.Ctx.Ffb);   // what the poll thread does each sample
        TelemetryEngine.EvaluateTick(ps, 0.01);
        check(ps.Vars.All(x => !x.HasConfigError), "ffb_ names compile in formulas");
        near(ps.Vars[1].Output, 1, 0, "ffb_connected reads 1 in a formula");
        near(ps.Vars[0].Output, 0, 1e-9, "grip_loss 0 with full spring");
        check(ps.Vars[0].Status == "OK", "FFB formula status OK while capturing: " + ps.Vars[0].Status);
        for (int k = 0; k < ps.Ctx.Ffb.Length; k++) ps.Ctx.Ffb[k] = double.NaN;
        ps.Ctx.Ffb[FfbChannels.Connected] = 0;
        TelemetryEngine.EvaluateTick(ps, 0.02);
        check(ps.Vars[0].Status.StartsWith("No force feedback data"), "FFB formula explains when capture is off: " + ps.Vars[0].Status);
        check(TeknoTelemetry.Core.Expressions.Formula.IsReservedName("ffb_force") && TeknoTelemetry.Core.Expressions.Formula.IsReservedName("FFB_Spring"),
              "ffb_ names are reserved for variables");

        check(Wait(() => { lock (changes) return changes.Any(c => c.VendorId == 0x046D && c.ProductId == 0xC299); }, 3000),
              "the wheel's IDs (046D:C299) learnt from its descriptor and passed on to be saved");

        cap.StopRecording();
        var recPackets = FfbTestsAccess.CountPackets(rec);
        check(recPackets > 1000 && recPackets < 24122, $"recording holds the second half ({recPackets} packets) and opens as a capture");

        // USBPcapCMD ends (the stand-in stops after its capture): the watchdog starts it again by itself.
        check(Wait(() => File.ReadAllLines(Path.Combine(dir, "runs.txt")).Length >= 2, 8000), "capture restarted after USBPcapCMD ended");

        // Windows gives the wheel a new address: found again by name, and the new address passed on.
        File.WriteAllText(Path.Combine(dir, "config.txt"), sample.Substring(sample.IndexOf("arg ", StringComparison.Ordinal)).Replace("16", "17").Replace("[17] Logitech", "[17] Logitech"));
        var cap2 = new FfbCapture { CapturesFolder = Path.Combine(dir, "Captures") };
        var changes2 = new List<FfbSettings>();
        cap2.DeviceChanged += d => { lock (changes2) changes2.Add(d); };
        cap2.Apply(new FfbSettings { Enabled = true, Interface = @"\\.\USBPcap1", Device = 16, DeviceName = "[16] Logitech G25 Racing Wheel USB", UsbPcapCmdPath = exe });
        check(Wait(() => cap2.IsCapturing, 3000), "capture running on the moved wheel: " + cap2.Status);
        var args2 = File.ReadAllText(Path.Combine(dir, "args.txt")).Trim();
        check(args2.EndsWith("--devices 17 --inject-descriptors"), "USBPcapCMD started on the new address: " + args2);
        check(Wait(() => { lock (changes2) return changes2.Any(c => c.Device == 17 && c.DeviceName == "[17] Logitech G25 Racing Wheel USB"); }, 1000), "new address passed on to be saved");
        cap2.Dispose();

        // Not plugged in: waits and says so, without starting capture.
        File.WriteAllText(Path.Combine(dir, "config.txt"), "value {arg=99}{value=11}{display=[11] Generic USB Hub}{enabled=true}\n");
        var cap3 = new FfbCapture { CapturesFolder = Path.Combine(dir, "Captures") };
        cap3.Apply(new FfbSettings { Enabled = true, Interface = @"\\.\USBPcap1", Device = 16, DeviceName = "[16] Logitech G25 Racing Wheel USB", UsbPcapCmdPath = exe });
        check(Wait(() => cap3.Status.StartsWith("Waiting for Logitech G25 Racing Wheel USB"), 3000) && !cap3.IsCapturing, "unplugged wheel: " + cap3.Status);
        cap3.Dispose();

        cap.Apply(new FfbSettings { Enabled = false });
        check(!cap.IsCapturing && cap.Status == "Off", "turning it off stops capture");
        cap.Snapshot(v);
        check(double.IsNaN(v[FfbChannels.Force]) && v[FfbChannels.Connected] == 0, "values blank when off");

        var missing = new FfbCapture { CapturesFolder = dir };
        missing.Apply(new FfbSettings { Enabled = true, Interface = @"\\.\USBPcap1", Device = 16, UsbPcapCmdPath = Path.Combine(dir, "nope.exe") });
        check(missing.Status == FfbCapture.UsbPcapMissing || missing.Status.Contains("USBPcapCMD"), "missing USBPcapCMD explained: " + missing.Status);

        cap.Dispose(); missing.Dispose();
        try { Directory.Delete(dir, true); } catch { }
    }

    static double[] Fill(FfbCapture c) { var a = new double[FfbChannels.Count]; c.Snapshot(a); return a; }

    static bool Wait(Func<bool> cond, int ms)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        while (sw.ElapsedMilliseconds < ms) { if (cond()) return true; Thread.Sleep(20); }
        return cond();
    }
}

static class FfbTestsAccess
{
    public static byte[] PcapOfFixture()
    {
        var r = new PcapStreamReader(File.OpenRead("fixtures/g25-wmmt3dxp.pcapng")); r.ReadHeader();
        var ms = new MemoryStream(); var w = new BinaryWriter(ms);
        w.Write(0xA1B2C3D4u); w.Write((ushort)2); w.Write((ushort)4); w.Write(0); w.Write(0u); w.Write(65535u); w.Write(249u);
        UsbPacket p;
        while ((p = r.Next()) != null)
        {
            var b = p.Record; int cap = BitConverter.ToInt32(b, 20);
            long us = (long)Math.Round(p.Time * 1e6);
            w.Write((uint)(us / 1000000)); w.Write((uint)(us % 1000000)); w.Write((uint)cap); w.Write((uint)cap); w.Write(b, 28, cap);
        }
        return ms.ToArray();
    }

    public static int CountPackets(string path)
    {
        using (var f = File.OpenRead(path))
        {
            var r = new PcapStreamReader(f); r.ReadHeader();
            int n = 0; while (r.Next() != null) n++;
            return n;
        }
    }
}
