using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TeknoTelemetry.Core.Ffb;

/// Replays a real G25 capture (WMMT3DX+, 57 s) through the FFB pipeline.
static class FfbTests
{
    const string Capture = "fixtures/g25-wmmt3dxp.pcapng";

    public static void Run(Action<bool, string> check, Action<double, double, double, string> near)
    {
        var packets = Read(File.OpenRead(Capture), out var isNg);
        check(isNg && packets.Count == 24122, $"pcapng capture read ({packets.Count} packets)");

        var series = Replay(packets, out var pipe);
        check(pipe.VendorId == 0x046D && pipe.ProductId == 0xC299, $"device descriptor seen: {pipe.VendorId:X4}:{pipe.ProductId:X4}");
        check(pipe.DecoderName.StartsWith("Logitech classic"), "Auto picked the Logitech classic decoder for a G25");
        check(pipe.Commands == 623, "623 commands decoded, got " + pipe.Commands);

        double At(double t, int ch) => series.Last(s => s.t <= t).v[ch];
        // first commands: 23/43 stop, 21 damper (k=0F) and 41 spring (clip FF), then 11 08 4E 80 = constant -50
        near(At(1.460, FfbChannels.Damper), 1.0, 1e-9, "damper loaded at full strength");
        near(At(1.460, FfbChannels.Spring), 1.0, 1e-9, "spring loaded at full strength");
        near(At(1.480, FfbChannels.Force), (0x4E - 0x80) / 127.0, 1e-9, "11 08 4E 80 = constant force -0.39");
        near(At(1.500, FfbChannels.Force), 0, 1e-9, "13 = slot 1 stopped, force 0");
        near(At(16.08, FfbChannels.Force), (0xB4 - 0x80) / 127.0, 1e-9, "expansion-joint kick +0.41");
        near(At(27.11, FfbChannels.Spring), 0xCE / 255.0, 1e-9, "spring eased to 0.81 (wall graze)");
        var minSpring = series.Where(s => s.t > 51 && s.t < 54).Min(s => s.v[FfbChannels.Spring]);
        check(minSpring < 0.05, $"spring collapses in the crash (min {minSpring:0.000})");
        var slide = series.Where(s => s.t > 43.9 && s.t < 45.81).Select(s => s.v[FfbChannels.Spring]).ToList();
        check(slide.Count > 0 && slide.Max() < 0.75, "spring stays eased off through the long slide");
        check(series.Max(s => s.v[FfbChannels.Activity]) >= 25, "activity count works: peak " + series.Max(s => s.v[FfbChannels.Activity]));
        check(series.All(s => s.v[FfbChannels.Rumble] == 0), "no vibration effects in this game");

        // Xbox rumble decoders, from the documented report layouts (no capture yet)
        UsbPacket Out(params byte[] b) => new UsbPacket { Device = 3, Endpoint = 0x02, Transfer = 1, Payload = b, Record = new byte[0] };
        UsbPacket Desc(int vid, int pid) => new UsbPacket { Device = 3, Endpoint = 0x80, Transfer = 2, FromDevice = true,
            Payload = new byte[] { 0x12, 0x01, 0, 2, 0xFF, 0xFF, 0xFF, 0x40, (byte)vid, (byte)(vid >> 8), (byte)pid, (byte)(pid >> 8), 0, 1, 1, 2, 3, 1 }, Record = new byte[0] };
        var x360 = new FfbPipeline(FfbDecoderChoice.Auto, 3);
        x360.OnPacket(Desc(0x045E, 0x028E));
        x360.OnPacket(Out(0x00, 0x08, 0x00, 0xFF, 0x40, 0, 0, 0));
        var xv = new double[FfbChannels.Count]; x360.Snapshot(xv, true);
        check(x360.DecoderName.StartsWith("Xbox 360"), "Auto picks Xbox 360 decoder for 045E:028E");
        near(xv[FfbChannels.RumbleLarge], 1, 1e-9, "360 large motor");
        near(xv[FfbChannels.RumbleSmall], 0x40 / 255.0, 1e-9, "360 small motor");
        near(xv[FfbChannels.Rumble], 1, 1e-9, "rumble = strongest motor");
        check(double.IsNaN(xv[FfbChannels.Force]), "a gamepad has no steering force");
        var xone = new FfbPipeline(FfbDecoderChoice.Auto, 3);
        xone.OnPacket(Desc(0x045E, 0x0B12));
        xone.OnPacket(Out(0x09, 0x00, 0x01, 0x09, 0x00, 0x0F, 0, 0, 50, 25, 0xFF, 0, 0));
        xone.Snapshot(xv, true);
        check(xone.DecoderName.StartsWith("Xbox One"), "Auto picks Xbox One decoder for 045E:0B12");
        near(xv[FfbChannels.RumbleLarge], 0.5, 1e-9, "One strong motor");
        near(xv[FfbChannels.RumbleSmall], 0.25, 1e-9, "One weak motor");
        var g25 = new double[FfbChannels.Count]; pipe.Snapshot(g25, true);
        check(double.IsNaN(g25[FfbChannels.RumbleLarge]), "wheels report no separate rumble motors");
        check(At(30, FfbChannels.Raw0) == 0x41 || At(30, FfbChannels.Raw0) == 0x11 || At(30, FfbChannels.Raw0) == 0x13, "raw bytes follow the last command");

        // steering and pedals from the wheel's own reports
        var inPipe = new FfbPipeline(FfbDecoderChoice.Auto, 16);
        var iv = new double[FfbChannels.Count];
        double minSt = 9, maxSt = -9, maxTh = 0; bool first = true;
        foreach (var p in packets)
        {
            inPipe.OnPacket(p);
            if (!(p.FromDevice && p.Endpoint == 0x81 && p.Payload.Length == 11)) continue;
            inPipe.Snapshot(iv, true);
            if (first)
            {
                // first report 08 00 80 26 81 FF FF FF ...: position (0x81 << 6 | 0x26 >> 2) = 8265
                near(iv[FfbChannels.Steer], (8265 - 8192) / 8192.0, 1e-9, "steering decoded from the first G25 report");
                near(iv[FfbChannels.Throttle], 0, 1e-9, "throttle released (255) = 0");
                first = false;
            }
            minSt = Math.Min(minSt, iv[FfbChannels.Steer]); maxSt = Math.Max(maxSt, iv[FfbChannels.Steer]);
            maxTh = Math.Max(maxTh, iv[FfbChannels.Throttle]);
        }
        Console.WriteLine($"G25 steering range in the capture {minSt * 450:0} to {maxSt * 450:0} degrees (at 900 lock), throttle max {maxTh:0.00}");
        check(maxSt > 0.5 && maxSt < 0.8 && minSt < -0.4 && minSt > -0.8, "steering range matches the chart (about +-270 degrees)");
        check(maxTh > 0.99, "full throttle seen");

        // the same capture as classic pcap (USBPcapCMD's own format) gives identical results
        var pcap = ToPcap(packets);
        var p2 = Read(new MemoryStream(pcap), out var isNg2);
        var s2 = Replay(p2, out var pipe2);
        check(!isNg2 && p2.Count == packets.Count && pipe2.Commands == 623, "classic pcap stream reads the same");
        near(s2.Last(s => s.t <= 27.11).v[FfbChannels.Spring], 0xCE / 255.0, 1e-6, "classic pcap decodes the same");

        // a stream cut off mid-record ends cleanly rather than throwing
        var cut = pcap.Take(pcap.Length - 5).ToArray();
        try { var p3 = Read(new MemoryStream(cut), out _); check(false, "truncated stream should report end"); }
        catch (EndOfStreamException) { check(true, ""); }

        // Raw decoder leaves interpretation empty but still shows bytes
        var raw = new FfbPipeline(FfbDecoderChoice.Raw, 16);
        foreach (var p in packets) raw.OnPacket(p);
        var rv = new double[FfbChannels.Count]; raw.Snapshot(rv, true);
        check(double.IsNaN(rv[FfbChannels.Force]) && !double.IsNaN(rv[FfbChannels.Raw0]), "raw decoder: no force, raw bytes present");

        // other devices' traffic is ignored
        var other = new FfbPipeline(FfbDecoderChoice.Auto, 5);
        foreach (var p in packets) other.OnPacket(p);
        check(other.Commands == 0, "packets from other device addresses ignored");

        Console.WriteLine($"FFB replay: {pipe.Commands} commands, decoder '{pipe.DecoderName}'");
    }

    static List<UsbPacket> Read(Stream s, out bool isNg)
    {
        var r = new PcapStreamReader(s);
        r.ReadHeader(); isNg = r.IsPcapNg;
        var list = new List<UsbPacket>(); UsbPacket p;
        while ((p = r.Next()) != null) list.Add(p);
        return list;
    }

    static List<(double t, double[] v)> Replay(List<UsbPacket> packets, out FfbPipeline pipe)
    {
        double t0 = packets[0].Time, now = 0;
        pipe = new FfbPipeline(FfbDecoderChoice.Auto, 16, () => now);
        var series = new List<(double, double[])>();
        foreach (var p in packets)
        {
            now = p.Time - t0;
            pipe.OnPacket(p);
            if (p.IsHostToDeviceData && p.Transfer != 2)
            {
                var v = new double[FfbChannels.Count]; pipe.Snapshot(v, true);
                series.Add((now, v));
            }
        }
        return series;
    }

    static byte[] ToPcap(List<UsbPacket> packets)
    {
        var ms = new MemoryStream(); var w = new BinaryWriter(ms);
        w.Write(0xA1B2C3D4u); w.Write((ushort)2); w.Write((ushort)4); w.Write(0); w.Write(0u); w.Write(65535u); w.Write(249u);
        foreach (var p in packets)
        {
            // rebuild the USBPcap header + payload from the pcapng record's packet data
            var b = p.Record; int cap = BitConverter.ToInt32(b, 20);
            var data = new byte[cap]; Buffer.BlockCopy(b, 28, data, 0, cap);
            long us = (long)Math.Round(p.Time * 1e6);
            w.Write((uint)(us / 1000000)); w.Write((uint)(us % 1000000)); w.Write((uint)cap); w.Write((uint)cap); w.Write(data);
        }
        return ms.ToArray();
    }
}
