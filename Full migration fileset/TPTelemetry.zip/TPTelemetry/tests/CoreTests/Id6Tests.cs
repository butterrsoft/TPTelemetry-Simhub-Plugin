// Initial D Arcade Stage 6 AA (ID6): the v1.2 rows found in the game's code (8 November 2026), fed a made-up race through the
// real engine (slot choice, gating, events, lamps), then Alexis's recording (9 November 2026, 11:31, story prologue, R32 GT-R,
// manual, USB capture on) replayed: her readings of speed, revs and gear, the walls, gutters and car contacts she noted. Then
// two more that day: 13:34 (AE86 Trueno, the same course, manual, no notes) and 13:44 (Civic, time trial on Irohazaka,
// automatic, notes): leaves, guard rails, ripple strips, landings. Then two drifting runs (15:23 Savanna RX-7 on Akina, 15:43
// Impreza on Irohazaka in the wet, both time trial, notes) for the drift angle the exe gave.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.TeknoParrot;
using Replay = Wmmt5ReplayTests.Replay;

static class Id6Tests
{
    const double V12 = 1313406292;

    sealed class Rec
    {
        public Dictionary<string, List<(double t, double v)>> Out;
        public Dictionary<string, List<(double t, double v)>> Car;
        public double At(string n, double t) => Out[n].First(x => x.t >= t).v;
        public double Max(string n, double a, double b) => Out[n].Where(x => x.t >= a && x.t < b).Max(x => x.v);
        public double CarAt(string n, double t) => Car[n].First(x => x.t >= t).v;
        public double CarMax(string n, double a, double b) => Car[n].Where(x => x.t >= a && x.t < b).Max(x => x.v);
    }

    static Rec Feed(Action<bool, string> check, string path, double stamp, int mySlot)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = "";
        prof.MaxSpeed = null; prof.MaxRevs = null;   // the made-up race is in raw units
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "ID6" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), "ID6 rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
        ps.Connected = true;
        var r = new Rec { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()),
                          Car = CommonValues.Outputs.ToDictionary(o => o.Name, o => new List<(double t, double v)>()) };
        bool v12 = stamp == V12;
        void Set(string n, double v) { if (feeds.TryGetValue(n, out var f)) f.Value = v; }
        const double dt = 1 / 120.0;
        for (double t = 0; t < 20; t += dt)
        {
            Set("v12", stamp);   // the build stamp read (merged into the v12 row)
            double state = t < 1 ? double.NaN : t < 3 ? 3 : t < 16 ? 4 : t < 18 ? 5 : double.NaN;
            Set("race_state", state);
            Set("my_slot", mySlot);
            bool racing = state == 4;
            double kmh = racing ? Math.Min(120, (t - 3) * 15) : 0;
            if (t >= 9 && t < 9.3) kmh -= (t - 9) * 100;   // the wall hit at 9 s costs 30 km/h
            for (int k = 0; k < 2; k++)
            {
                bool mine = k == mySlot;
                Set("speed_" + k, mine ? kmh / 1 : 77);   // the rival reads 77 km/h throughout
                Set("rpm_" + k, mine ? 3000 + kmh * 50 : 9999);
                Set("rpm_tacho_" + k, mine ? 3300 : 9999);
                Set("gear_" + k, mine ? (t < 6 ? 2 : 3) : 5);
                Set("throttle_" + k, mine ? 1 : 0); Set("brake_" + k, 0);
                Set("drift_angle_" + k, mine ? (t >= 11 && t < 11.5 ? 0.3 : 0) : 1.0);   // a drift at 11 s; the rival's angle must not show
                int ev = 0;
                if (mine && t >= 9 && t < 10.5) ev |= 0x8000;      // left wall from 9 s to 10.5 s
                if (mine && t >= 12 && t < 12.1) ev |= 0x20000;    // right guard... wall, briefly
                if (mine && t >= 13 && t < 13.05) ev |= 0x800;     // a road joint
                if (mine && t >= 14 && t < 14.5) ev |= 0x200;      // a rumble strip
                if (!mine) ev = 0x80000;                           // the rival's own flags must not leak through
                Set("events_" + k, ev);
            }
            // lamps: start lamp lit on v1.2's byte, view lamp lit on v1.0's byte
            Set("lamps_a12", 128); Set("lamps_b12", 0); Set("lamps_a10", 64); Set("lamps_b10", 64);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) r.Out[v.Def.Name].Add((t, v.Output));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) r.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
        }
        return r;
    }

    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "ID6");
        if (gamePackDir == null || !File.Exists(path)) return;
        var shipped = ProfileStore.ReadProfile(path);
        check(shipped.MaxSpeed == 220 && shipped.MaxRevs == 8140, $"ID6 ships with Max speed 220 and Max revs 8140: {shipped.MaxSpeed} {shipped.MaxRevs}");
        foreach (int slot in new[] { 0, 1 })
        {
            var r = Feed(check, path, V12, slot);
            string s = $"ID6 (slot {slot}): ";
            check(r.At("in_race", 2) == 0 && r.At("in_race", 5) == 1 && r.At("in_race", 17) == 0 && r.At("in_race", 0.5) == 0, s + "in_race only in race state 4");
            check(r.At("speed", 0.5) == 0 && r.At("speed", 19) == 0 && Math.Abs(r.At("speed", 7) - 60) < 0.2, s + $"speed is your car's and 0 outside a race: {r.At("speed", 7)}");
            check(r.At("gear", 7) == 3 && r.At("rpm_tacho", 7) == 3300 && r.At("throttle", 7) == 1, s + "gear, tacho and throttle from your slot");
            check(r.Max("car_contact", 3, 16) == 0, s + "the other car's flags don't show as yours");
            check(r.Max("hit", 9, 9.3) == 1 && r.Max("hit", 9.4, 11.9) == 0 && r.Max("hit", 12, 12.3) == 1 && r.Max("hit", 3, 8.99) == 0,
                  s + "hit for 0.3 s at the start of each contact, not through a long scrape");
            check(r.At("wall_contact", 10) == -1 && r.At("wall_contact", 9.1) == 0 && r.At("wall_contact", 12.05) == 0,
                  s + "wall_contact -1 after 0.3 s on the left wall, not for a brief touch");
            check(r.CarMax("impact_side", 9, 9.3) == -1 && r.CarMax("impact_side", 12, 12.3) == 1, s + "Car_impact_side left then right");
            double imp = r.CarMax("impact", 9, 9.3);
            check(imp > 0.6 && imp <= 1, s + $"Car_impact sized by the km/h lost: {imp:0.00}");
            check(r.Max("road_joint", 13, 13.1) == 1 && r.CarMax("road_bump", 13, 13.2) > 0.5, s + "road joint and Car_road_bump");
            check(r.Max("rumble_strip", 14, 14.5) == 1 && r.CarMax("rumble_strip", 14, 14.5) == 1, s + "rumble strip");
            check(r.At("lampstart", 7) == 1 && r.At("lampview1", 7) == 0, s + "v1.2 lamps from v1.2's lamp byte");
            double ang = r.At("drift_angle", 11.2), drift = r.CarAt("drift", 11.2);
            check(Math.Abs(ang + 0.3 * 57.29578) < 0.01 && Math.Abs(drift - DriftOf(0.3 * 57.29578, 200)) < 0.001 && Math.Abs(r.CarAt("grip_loss", 11.2) - drift) < 1e-9 &&
                  r.At("drift_angle", 10) == 0 && r.CarAt("drift", 10) == 0,
                  s + $"drift angle in degrees from the physics (0.3 rad = -17.2), Car_drift from the angle at full speed weight, Car_grip_loss the same: {ang:0.00} {drift:0.000}");
            check(r.At("drift_angle", 3.5) == 0, s + "no drift angle below 10 km/h");
        }
        var v10 = Feed(check, path, 1234, 0);
        check(v10.At("speed", 7) == 0 && v10.At("in_race", 7) == 0, "ID6 on another version: the v1.2 rows read 0");
        check(v10.At("lampstart", 7) == 0 && v10.At("lampview1", 7) == 1 && v10.At("lampselectleft", 7) == 0 && v10.At("lampselectright", 7) == 1,
              "ID6 on v1.0: lamps from v1.0's lamp bytes");
        Recording(check, path);
        Trueno(check, path);
        Irohazaka(check, path);
        Drifting(check, path);
    }

    static Replay Replay(Action<bool, string> check, string path, string fixture)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = "";
        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);
        var tp = new double[TpChannels.Count];
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            TpSource = a => Array.Copy(tp, a, a.Length),
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "ID6" });
        var ps = eng.Profiles[0];
        ps.Connected = true;
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(kv.Key));
        // drift_angle (9 November 2026, from the exe) came after these recordings
        check(cols.All(c => c.Value >= 0 || c.Key.StartsWith("drift_angle_")), "ID6: the recording has every memory row: " + string.Join(", ", cols.Where(c => c.Value < 0).Select(c => c.Key)));
        var slots = Enumerable.Range(0, TpChannels.SlotCount).Select(i => Col("tp_jvs" + i)).ToArray();
        int conn = Col("tp_connected"), tc = Col("time_s"), mc = Col("marker");
        var rp = new Replay { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()) };
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            if (r[mc] != "") rp.Marks.Add(t);
            foreach (var kv in feeds) kv.Value.Value = Num(r, cols[kv.Key]);
            for (int i = 0; i < slots.Length; i++) tp[i] = Num(r, slots[i]);
            tp[TpChannels.Connected] = Num(r, conn);
            eng.TpSource(ps.Ctx.Tp);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            rp.End = t;
        }
        return rp;
    }

    // The race clock started at 92.565 s in the recording (race state 4 from 92.58 s, her total time 0.017 s): her notes give
    // total times, so a note at T is at 92.565 + T. Her readings (total time, gear, revs, km/h) off the screen; shifts left out
    // of the gear and revs checks (the game's gear changes a frame or two after the frame she read).
    const double T0 = 92.565;
    static readonly (double tt, int gear, double revs, double kmh, bool shift)[] Readings =
    {
        (0.017, 4, 7100, 185, false), (3.017, 4, 7600, 197, false), (8.917, 4, 7800, 202, false), (12.267, 4, 7800, 201, false),
        (14.917, 3, 5100, 127, true), (23.401, 2, 7900, 159, true), (26.867, 2, 8000, 132, false), (28.161, 2, 7900, 132, false),
        (32.228, 3, 7400, 129, true), (37.111, 3, 7600, 160, false), (37.778, 3, 7300, 156, false), (38.795, 3, 7200, 152, false),
        (40.378, 4, 5400, 141, false), (41.795, 4, 4900, 126, false), (51.270, 3, 5100, 109, false), (56.371, 3, 6600, 139, false),
        (73.104, 4, 7700, 195, false), (74.604, 4, 8000, 202, false), (76.654, 4, 7900, 201, false), (82.421, 4, 7800, 202, false),
        (86.988, 4, 8000, 202, false), (88.705, 4, 7800, 202, false), (90.921, 4, 7700, 199, false), (96.655, 4, 4400, 132, true),
        (102.638, 3, 7000, 151, false), (109.305, 4, 7000, 182, false), (120.739, 4, 6800, 160, false), (135.923, 5, 5400, 167, false),
        (140.523, 5, 5700, 173, false), (141.339, 5, 4000, 124, false),
    };
    // Where a contact starts (total time). Her notes: the RHS wall (12.27), the second touch of the other car (28.16; the game
    // flagged nothing at 26.87), the other car (37.11), the LHS wall (38.80, a guard rail), the RHS wall (41.80), the RHS gutter
    // she ground along (56.37: a wall too), the RHS wall or gutter (82.42: both), the other car (86.99, then a grind to 88.98),
    // the right gutter twice (91.49, 94.04: walls too), the RHS gutter and wall (110.06), into the LHS gutter (111.42: a wall
    // too), the LHS wall (140.52). Not in her notes: the right wall twice in the drifting right turn (24.83, 25.17), and the other
    // car pushing past with a touch of the left guard rail (48.67, 49.71) before it overtook.
    static readonly double[] Hits = { 12.32, 24.83, 25.17, 28.10, 37.08, 38.79, 41.83, 48.67, 49.71, 56.41, 82.42, 86.92, 91.49, 94.04, 110.06, 111.42, 140.56 };

    static void Recording(Action<bool, string> check, string path)
    {
        var r = Replay(check, path, "id6-20261109-113134.csv.gz");
        string s = "ID6 recording: ";
        double T(double tt) => T0 + tt;
        double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Max(x => x.v);
        double CarAt(string n, double t) => r.Car[n].First(x => x.t >= t).v;
        check(r.Marks.Count == 17, s + $"17 marks: {r.Marks.Count}");
        check(!(r.Max("race_state", 0, 70) > 0) && r.At("my_slot", T(10)) == 0, s + "no race before the story movie; your car in slot 0");
        // racing from the start to the finish line; the rolling start's last 6 s have live revs
        check(r.At("in_race", T(0.02)) == 1 && r.At("in_race", T(141.3)) == 1 && r.Max("in_race", T(141.4), r.End) == 0 && r.Max("in_race", 0, T(-0.01)) == 0,
              s + "in_race from the race clock's start to the finish line");
        check(r.At("countdown_live", T(-6.2)) == 0 && r.At("countdown_live", T(-5.9)) == 1 && r.At("countdown_live", T(0.02)) == 0,
              s + "countdown_live once the revs come alive in the rolling start");
        check(CarAt("in_race", T(-5)) == 1 && CarAt("in_race", T(-6.3)) == 0 && CarAt("in_race", T(142)) == 0, s + "Car_in_race from the live countdown to the finish");
        // her readings
        var spd = Readings.Select(x => Math.Abs(r.At("speed", T(x.tt)) * 220 - x.kmh)).Max();
        check(spd < 1.5, s + $"speed matches the speedo at all 30 readings, within {spd:0.0} km/h");
        var revs = Readings.Where(x => !x.shift).Select(x => Math.Abs(r.At("rpm", T(x.tt)) * 8140 - x.revs)).Max();
        check(revs < 350, s + $"rpm matches the revs on screen (shifts left out), within {revs:0}");
        var gears = Readings.Where(x => !x.shift && r.At("gear", T(x.tt)) != x.gear).Select(x => x.tt.ToString("0.000", CultureInfo.InvariantCulture)).ToList();
        check(gears.Count == 0, s + "gear matches at every reading but the shifts: " + string.Join(" ", gears));
        check(Readings.Where(x => x.shift).All(x => r.Max("gear", T(x.tt), T(x.tt) + 0.03) == x.gear || r.Min("gear", T(x.tt), T(x.tt) + 0.03) == x.gear),
              s + "the gear she read at a shift follows within 0.03 s");
        check(Math.Abs(r.Max("rpm", T(0), T(141.3)) * 8140 - 8140) < 1 && Math.Abs(r.Max("rpm_tacho", T(0), T(141.3)) / (r.Max("rpm", T(0), T(141.3)) * 8140) - 1.08) < 0.005,
              s + "the limiter is 8140; rpm_tacho is 1.08 x rpm in the R32 GT-R");
        check(r.Max("brake", T(41.25), T(41.4)) == 1 && r.Max("throttle", T(41.25), T(41.4)) == 0 && r.Max("brake", T(0), T(41)) == 0, s + "the brake at 41.3 s, throttle off");
        // contacts
        var hits = r.Events("hit", 0, 0.02).Where(t => t > T(0) && t < T(141.4)).Select(t => t - T0).ToList();
        string Fmt(IEnumerable<double> ts) => string.Join(" ", ts.Select(t => t.ToString("0.00", CultureInfo.InvariantCulture)));
        var missed = Hits.Where(h => !hits.Any(g => Math.Abs(g - h) < 0.03)).ToList();
        var extra = hits.Where(g => !Hits.Any(h => Math.Abs(g - h) < 0.03)).ToList();
        check(missed.Count == 0 && extra.Count == 0, s + $"hits: missed {Fmt(missed)}; extra {Fmt(extra)}");
        check(r.Max("hit", T(30), T(36)) == 0 && r.Max("shift", T(33), T(39.3)) == 0, s + "hit and shift let go between events (they stuck at 1 live, before plugin 0.17.2)");
        check(r.Max("hit", T(87.3), T(89)) == 0 && r.Max("car_contact", T(87.3), T(89)) == 1, s + "the grind along the other car (87.2 to 89 s) is one hit, at its start");
        check(r.Max("hit", T(102.7), T(103.1)) == 0 && r.Max("rough_ground", T(102.7), T(103.1)) == 1 && r.Max("hit", T(120.8), T(121.2)) == 0 && r.Max("gutter", T(120.8), T(121.2)) == 1,
              s + "right tyres in the gutter (102.8 s) and left tyres (120.9 s): rough ground, no hit");
        check(CarMax("impact_side", T(12.3), T(12.7)) == 1 && CarMax("impact_side", T(38.78), T(39.1)) == 0 && r.Min("hit_side", T(38.8), T(39.1)) == -1 &&
              r.Car["impact_side"].Where(x => x.t >= T(140.5) && x.t <= T(140.9)).Min(x => x.v) == -1, s + "wall sides: right at 12.3 s, left at 38.8 and 140.6 s");
        check(CarMax("impact", T(12.3), T(12.7)) == 1 && Math.Abs(CarMax("impact", T(28.1), T(28.45)) - 0.5) < 0.02, s + "Car_impact 1 for the 202 km/h wall at 12.3 s, 0.5 for a touch of the other car");
        check(CarMax("vibration", T(102.8), T(102.9)) == 1 && CarMax("off_road", T(102.8), T(103)) == 1, s + "Car_vibration 1 as a wheel drops into the gutter (the game's 0.16), Car_off_road while in it");
        check(r.Max("lampstart", 0, 5) == 1 && r.Min("lampstart", 0, 5) == 0 && r.Max("lampselectleft", 16, 21) == 1, s + "the start lamp blinks in attract, the select lamps on the card screen");
    }

    // 13:34: the AE86 Trueno in the story prologue (manual, no notes). Its rev counter reads 8k at the limiter (Alexis).
    static void Trueno(Action<bool, string> check, string path)
    {
        var r = Replay(check, path, "id6-20261109-133425.csv.gz");
        string s = "ID6 Trueno recording: ";
        double start = r.Out["in_race"].First(x => x.v == 1).t;
        check(Math.Abs(start - 97.77) < 0.02 && r.At("in_race", 240.6) == 1 && r.Max("in_race", 240.7, r.End) == 0, s + $"racing 97.77 to 240.6 s: {start:0.00}");
        check(r.Car["in_race"].First(x => x.v == 1).t < 92 && r.At("countdown_live", 92) == 1, s + "Car_in_race from the live rolling start (6 s before the race clock)");
        double top = r.Max("speed", start, 240.6) * 220, lim = r.Max("rpm", start, 240.6) * 8140;
        check(top > 214 && top < 216 && Math.Abs(lim - 8140) < 1, s + $"top speed 215 km/h (under Max speed 220), limiter 8140 like the GT-R: {top:0.0} {lim:0}");
        check(Math.Abs(r.Max("rpm_tacho", start, 240.6) / lim - 1.23) < 0.01, s + "rpm_tacho is 1.23 x rpm in the Trueno (10,000 on the limiter; the screen reads 8k)");
        check(r.Max("landing", start, 240.6) == 0 && r.Max("rumble_strip", start, 240.6) == 0 && r.Max("leaves", start, 240.6) == 0,
              s + "no landings, ripple strips or leaves on this course");
        check(r.Events("hit", 0, 0.02).Count(t => t > start && t < 240.7) >= 15, s + "the gutter-and-wall hits come through");
    }

    // 13:44: a Civic in time trial on Irohazaka downhill (automatic), recorded from mid-race, 15 marks. Her total times are
    // the recording's time + 4.09 s (her readings fit to within a km/h).
    const double I0 = 4.09;
    static readonly (double tt, int gear, double kmh)[] IroReadings =
    {
        (8.540, 3, 106), (26.674, 4, 118), (27.707, 3, 92), (35.891, 2, 61), (64.008, 3, 94), (69.158, 3, 97), (89.230, 3, 100), (99.298, 2, 67),
        (125.265, 2, 49), (125.482, 2, 53), (125.715, 2, 56), (125.815, 2, 58), (146.216, 2, 44), (146.766, 2, 42), (146.866, 2, 42), (146.999, 2, 41), (147.416, 2, 40),
    };
    // Ripple strips she noted (total time): braking at 26.67, marks 2 to 5, round the right hairpin from 64, mark 8, mark 10, and
    // the heavy braking before mark 12. The game sends its vibration at level 10 on them; event bit 0x200 never came on.
    static readonly double[] Strips = { 26.67, 44.0, 46.35, 48.6, 55.1, 64.05, 89.2, 99.3, 107.3 };
    // Contacts she noted, as the game flagged them: the LHS wall grind (27.6), the RHS guard rail out of the left hairpin (36.7), her
    // front right (47.8), the LHS wall (51.1), RHS (57.1), the RHS wall mid-hairpin and the guard rails after (69.9, 70.9, 73.0), the
    // rammed guard rail and the next (84.7, 87.7), mark 12 (108.6), the guard rail with the leaves (119.2, 120.4), the RHS wall (129.6),
    // the possible RHS wall (143.5) and the last two (154.1, 156.4).
    static readonly double[] IroHits = { 27.58, 36.74, 47.81, 51.06, 57.06, 69.88, 70.91, 72.95, 84.73, 87.68, 108.57, 119.17, 120.40, 129.60, 143.53, 154.10, 156.40 };

    static void Irohazaka(Action<bool, string> check, string path)
    {
        var r = Replay(check, path, "id6-20261109-134431.csv.gz");
        string s = "ID6 Irohazaka recording: ";
        double T(double tt) => tt - I0;
        double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Max(x => x.v);
        string Fmt(IEnumerable<double> ts) => string.Join(" ", ts.Select(t => (t + I0).ToString("0.00", CultureInfo.InvariantCulture)));
        check(r.Marks.Count == 15, s + $"15 marks: {r.Marks.Count}");
        check(r.Min("in_race", 0, r.End) == 1 && r.Max("my_slot", 0, r.End) == 0, s + "in_race in time trial (race state 4 throughout), your car in slot 0");
        var spd = IroReadings.Select(x => Math.Abs(r.At("speed", T(x.tt)) * 220 - x.kmh)).Max();
        check(spd < 1.5, s + $"speed matches her readings, within {spd:0.0} km/h");
        check(IroReadings.All(x => r.At("gear", T(x.tt)) == x.gear) && r.Max("gear", 0, r.End) == 5, s + "gear right at every reading; the automatic uses 1 to 5");
        var land = r.Events("landing", 0, 0.3);
        check(land.Count == 3 && Math.Abs(land[0] - T(125.83)) < 0.05 && Math.Abs(land[1] - T(147.43)) < 0.05 && Math.Abs(land[2] - T(149.68)) < 0.05,
              s + $"three landings: over the first apex (125.8), the long fall (147.4) and mark 15 (149.7): {Fmt(land)}");
        check(CarMax("road_bump", T(125.8), T(126.1)) == 1 && CarMax("road_bump", T(126.2), T(146)) == 0,
              s + "Car_road_bump 1 at the landing, not for the 20 s the game leaves its landing bit on");
        var strips = r.Events("rumble_strip", 0, 0.2);
        check(Strips.All(x => r.Max("rumble_strip", T(x) - 0.1, T(x) + 0.4) == 1) && r.Max("rumble_strip", 0, T(26.5)) == 0,
              s + "every ripple strip she noted, none before the first: " + Fmt(strips));
        check(Math.Abs(CarMax("vibration", T(55.2), T(56.8)) - 10 / 127.0 / 0.15) < 0.01 && CarMax("rumble_strip", T(55.2), T(56.8)) == 1,
              s + "Car_rumble_strip on the strips, Car_vibration about 0.5 there");
        var hits = r.Events("hit", 0, 0.02);
        var missed = IroHits.Where(h => !hits.Any(g => Math.Abs(g - T(h)) < 0.05)).ToList();
        check(missed.Count == 0, s + "her contacts each came through as a hit; missed: " + string.Join(" ", missed));
        check(r.Max("leaves", T(6.8), T(10.2)) == 1 && CarMax("off_road", T(7), T(10)) == 1 && r.Max("leaves", T(15), T(18)) == 0,
              s + "left tyres in the leaves at 8.5 s: leaves, Car_off_road");
    }

    // 15:23 (Savanna RX-7, Akina downhill, manual, 13 marks) and 15:43 (Impreza, Irohazaka downhill in the wet, 7 marks): a drift
    // at each mark. + = right-hand drift (the car pointing right of its path), as her notes say, and the steering agreed every time.
    // Her 15:43 mark 7 says "left hairpin", but the angle and the steering both went right there, as the hairpins alternate after
    // mark 6's left: taken as a right. Her words for each drift and the peak angle: very gentle 17, gentle 18, very mild 19, mild 25
    // to 33, moderate 23 to 39, almost extreme 49, extreme 50.
    static readonly (string fixture, int mark, int dir, string words)[] Drifts =
    {
        ("id6-20261109-152326.csv.gz", 1, 1, "gentle"), ("id6-20261109-152326.csv.gz", 2, 1, "mild to mild-moderate"),
        ("id6-20261109-152326.csv.gz", 3, -1, "moderate"), ("id6-20261109-152326.csv.gz", 4, 1, "very mild"),
        ("id6-20261109-152326.csv.gz", 5, 1, "mild, faster"), ("id6-20261109-152326.csv.gz", 6, -1, "mild"),
        ("id6-20261109-152326.csv.gz", 7, 1, "mild"), ("id6-20261109-152326.csv.gz", 8, -1, "mild to moderate"),
        ("id6-20261109-152326.csv.gz", 9, -1, "mild"), ("id6-20261109-152326.csv.gz", 10, 1, "mild to moderate"),
        ("id6-20261109-152326.csv.gz", 11, -1, "moderate"), ("id6-20261109-152326.csv.gz", 12, 1, "the inside contact"),
        ("id6-20261109-152326.csv.gz", 13, -1, "moderate"),
        ("id6-20261109-154348.csv.gz", 1, 1, "riding the LHS guard rails"), ("id6-20261109-154348.csv.gz", 2, -1, "moderate"),
        ("id6-20261109-154348.csv.gz", 3, -1, "moderate"), ("id6-20261109-154348.csv.gz", 4, -1, "moderate"),
        ("id6-20261109-154348.csv.gz", 5, 1, "moderate"), ("id6-20261109-154348.csv.gz", 6, -1, "almost extreme"),
        ("id6-20261109-154348.csv.gz", 7, 1, "extreme (noted left)"),
    };

    // Car_drift (Alexis, 10 November 2026): angle part 1 - (1 - x)^2 with x = (|angle| - 5) / 45, times the square root of the
    // speed part (km/h - 20) / 80, each clamped to 0..1
    static double DriftOf(double angle, double kmh)
    {
        double x = Math.Max(0, Math.Min(1, (Math.Abs(angle) - 5) / 45)), sp = Math.Max(0, Math.Min(1, (kmh - 20) / 80));
        return (1 - (1 - x) * (1 - x)) * Math.Sqrt(sp);
    }

    static void Drifting(Action<bool, string> check, string path)
    {
        foreach (var fx in Drifts.Select(d => d.fixture).Distinct())
        {
            var r = Replay(check, path, fx);
            string s = $"ID6 drifting ({fx.Substring(13, 6)}): ";
            double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Max(x => x.v);
            check(r.Min("in_race", 0, 90) == 1, s + "in_race in time trial");
            // the drift's angle: the biggest in the 1.5 s before the mark
            double Peak(double m)
            {
                var w = r.Out["drift_angle"].Where(x => x.t >= m - 1.5 && x.t <= m + 0.5).ToList();
                return w.OrderByDescending(x => Math.Abs(x.v)).First().v;
            }
            var wrong = Drifts.Where(d => d.fixture == fx).Where(d => Math.Sign(Peak(r.Marks[d.mark - 1])) != d.dir || Math.Abs(Peak(r.Marks[d.mark - 1])) < 15)
                              .Select(d => $"mark {d.mark} ({d.words}) {Peak(r.Marks[d.mark - 1]):0.0}").ToList();
            check(wrong.Count == 0, s + "every marked drift is 15 degrees or more, + right-hand, - left-hand: " + string.Join("; ", wrong));
            // Car_drift: nothing in ordinary driving (the angle stays under 7 degrees), and Car_grip_loss follows it
            var calm = r.Out["drift_angle"].Select((x, i) => (x, c: r.Car["drift"][i].v)).Where(p => Math.Abs(p.x.v) < 5).ToList();
            check(calm.All(p => p.c == 0), s + "Car_drift 0 while the angle is under 5 degrees");
            check(r.Car["drift"].Zip(r.Car["grip_loss"], (a, b) => a.v == b.v).All(x => x), s + "Car_grip_loss is the drift (ID6 has no slip value of its own)");
            check(r.Car["drift_angle"].Zip(r.Out["drift_angle"], (a, b) => a.v == b.v).All(x => x), s + "Car_drift_angle is the drift angle");
        }
        // Car_drift: the angle part (5 to 50 degrees) times the speed part (20 to 100 km/h; Alexis, 9 and 10 November 2026)
        var rx7 = Replay(check, path, "id6-20261109-152326.csv.gz");
        var imp = Replay(check, path, "id6-20261109-154348.csv.gz");
        foreach (var r in new[] { rx7, imp })
        {
            var slow = r.Out["speed"].Select((x, i) => (kmh: x.v * 220, c: r.Car["drift"][i].v)).Where(p => p.kmh < 20).ToList();
            check(slow.All(p => p.c == 0), "ID6 drifting: no Car_drift below 20 km/h");
            var ok = r.Out["drift_angle"].Select((x, i) => (a: x.v, kmh: r.Out["speed"][i].v * 220, c: r.Car["drift"][i].v, inr: r.Out["in_race"][i].v))
                      .Where(p => p.inr == 1).All(p => Math.Abs(p.c - DriftOf(p.a, p.kmh)) < 1e-9);
            check(ok, "ID6 drifting: Car_drift = angle part x speed part throughout");
        }
        // to the end of the drift: her mark 3 "becomes moderate near the end" peaks a second after the mark
        double Cm(Replay r, int mark) => r.Car["drift"].Where(x => x.t >= r.Marks[mark - 1] - 1.5 && x.t <= r.Marks[mark - 1] + 1.5).Max(x => x.v);
        double gentle = Cm(rx7, 1), moderate = Cm(rx7, 3), fast = Cm(rx7, 5), extreme = Cm(imp, 7);
        check(Math.Abs(gentle - 0.5) < 0.05 && Math.Abs(moderate - 0.7) < 0.08 && Math.Abs(fast - 0.84) < 0.05 && Math.Abs(extreme - 0.85) < 0.05,
              $"ID6 drifting: Car_drift near Alexis's targets (0.5, 0.7, 0.84, 0.85): gentle at 134 km/h {gentle:0.00}, moderate hairpin at 73 km/h {moderate:0.00}, mark 5 at 115 km/h {fast:0.00}, extreme hairpin at 74 km/h {extreme:0.00}");
        // her other notes on the RX-7 run: walls and ripple strips
        check(rx7.Max("wall_left", 50.4, 51.3) == 1 && rx7.Max("wall_left", 144, 145.7) == 1 && rx7.Max("wall_right", 165.4, 166) == 1,
              "ID6 drifting: the LHS wall at mark 5, riding the LHS wall round the right hairpin, the inside of the corner at mark 12");
        check(rx7.Events("rumble_strip", 0, 0.1).Count(t => t > 141 && t < 144) == 3 && rx7.Max("rumble_strip", 95.5, 97.5) == 1,
              "ID6 drifting: the three ripple strips on the straight, and the one before mark 7");
        check(imp.Max("wall_left", 26, 27.8) == 1 && imp.Max("wall_right", 56.5, 57.4) == 1 && imp.Max("wall_left", 79.2, 80.3) == 1,
              "ID6 drifting (Impreza): the LHS guard rails at mark 1, the rail at the end of mark 3, the rail during mark 5");
    }
}
