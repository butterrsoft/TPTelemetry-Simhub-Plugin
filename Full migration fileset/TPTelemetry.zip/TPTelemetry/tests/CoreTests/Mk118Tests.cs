using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;

// Mario Kart Arcade GP DX v1.18 (MKGPDX118): Alexis's recording of 11 November 2026, 10:57 (100cc Grand Prix, Mario,
// two laps from 6th, 48 marks: drifts both ways, two kite glides, two log ripple strips, item hits, 20 coins). The
// fixture holds the raw reads from 40 s (the force and drift angle rows read the same address, kart +BC8).
static class Mk118Tests
{
    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "MKGPDX118");
        if (gamePackDir == null || !File.Exists(path)) return;
        var r = Replay(check, path, "mkgpdx118-20261111-105714.csv.gz", "MKGPDX118",
            new HashSet<string> { "position", "laps_done", "laps_total", "race_time", "race_timer_1c" });
        const string s = "MKGPDX118 10:57: ";
        List<(double t, double v)> O(string n) => r.Out[n];
        double At(string n, double t) => O(n).First(x => x.t >= t).v;
        double CarAt(string n, double t) => r.Car[n].First(x => x.t >= t).v;
        double Span(string n) => O(n).Zip(O(n).Skip(1), (a, b) => a.v > 0 ? b.t - a.t : 0).Sum();
        int Rises(string n) => O(n).Zip(O(n).Skip(1), (a, b) => a.v <= 0 && b.v > 0 ? 1 : 0).Sum();

        // the race: GO at 78.5 s (her mark 6 at 78.8), the line at 253.4 (mark 47 at 253.6); the FFB plugin's flag drops
        // for one sample at the lap line (169.6 s), the race state doesn't
        check(At("racing", 77.0) == 0 && At("racing", 80.0) == 1 && At("racing", 169.65) == 1 && At("racing", 254.0) == 0 &&
              CarAt("in_race", 254.0) == 0, s + "racing from GO to the finish line, through the lap line");
        // drifts: + right-hand, - left-hand; her marked right drift (mark 8) and left drift (mark 13)
        double Peak(double a, double b) => O("drift_angle").Where(x => x.t >= a && x.t <= b).OrderByDescending(x => Math.Abs(x.v)).First().v;
        double d8 = Peak(105.7, 109.0), d13 = Peak(121.6, 124.3);
        check(d8 > 40 && d13 < -20, s + $"drift angles: right (mark 8) {d8:0}, left (mark 13) {d13:0} degrees");
        check(At("drift_side", 122.5) == 1 && At("drift_side", 107.0) == 0, s + "drift_side 1 in the left-hand drift only");
        var straight = O("drift_angle").Where((x, i) => O("racing")[i].v == 1 && O("drift")[i].v == 0 && O("knocked")[i].v == 0)
                                       .Select(x => Math.Abs(x.v)).OrderBy(v => v).ToList();
        check(straight[straight.Count / 2] < 2, s + $"median drift angle off a drift {straight[straight.Count / 2]:0.00} degrees");
        double c8 = r.Car["drift"].Where(x => x.t >= 106.5 && x.t <= 108.5).Max(x => x.v);
        check(c8 > 0.9 && CarAt("drift", 100.2) > 0.4 && CarAt("drift", 100.2) < 0.7 && CarAt("drift", 95.0) == 0,
              s + $"Car_drift: mark 8's drift {c8:0.00}, her very slight one {CarAt("drift", 100.2):0.00}, none on the straight");
        // the air: two kite glides of about 4.4 s, not the drift hops or the ripple-strip logs
        check(At("airborne", 111.5) == 1 && At("airborne", 195.5) == 1 && At("gliding", 111.5) == 1 && At("airborne", 87.7) == 0 &&
              At("hop", 87.7) == 1 && At("airborne", 103.5) == 0, s + "airborne in the glides, not in a hop or on the logs");
        double air = Span("airborne");
        check(air > 8.5 && air < 9.5, s + $"airborne {air:0.0} s in all (two glides of 4.4 s, and a few short drops)");
        check(At("landed", 114.0) == 1 && CarAt("road_bump", 114.0) == 1, s + "landing after the first glide (mark 10)");
        // the two log ripple strips, and nothing else
        check(At("rumble_strip", 104.0) == 1 && At("rumble_strip", 188.5) == 1 && Span("rumble_strip") < 4.5,
              s + $"ripple strips at 104 and 188.5 s, {Span("rumble_strip"):0.0} s in all");
        // coins: 20 in the race, each its own pickup
        check(At("coins", 252.0) == 20 && new[] { 104.1, 117.7, 201.8, 244.5, 251.1 }.All(t => At("coin_pickup", t) == 1) && At("coin_pickup", 150) == 0,
              s + $"coins {At("coins", 252.0)}; coin_pickup at her coins ({Rises("coin_pickup")} runs: coins in quick succession run together)");
        // items: an item box at 86 s, the red shell fired at 90.65 (after mark 7)
        check(At("item_held", 89.0) == 1 && At("item_held", 91.2) == 0 && At("item_gone", 91.0) == 1, s + "the red shell held, then fired (the lamp held 0.25 s over its flashes)");
        // hits: the shake in the countdown is no hit; the spin-out at mark 11 is
        check(CarAt("impact", 77.75) == 0 && CarAt("impact", 117.5) == 1 && At("spin", 117.5) == 1 && CarAt("grip_loss", 117.5) == 1,
              s + "no impact in the countdown; the spin-out at mark 11 is one");
        check(At("boost", 108.0) == 0 && At("boost", 109.5) == 1, s + "the mini-turbo boost at mark 9");
        // hit sides (Alexis, 11 November 2026): Princess on her left at 96.05, Princess on her right at 120.2, Luigi on her right
        // at 134.77, the left-hand wall at 231.75 and 248.64; the side shows about 0.1 s after the hit
        double Side(double t) => O("hit_side").Where(x => x.t >= t && x.t <= t + 0.3).Select(x => x.v).FirstOrDefault(v => v != 0);
        var sides = new[] { (96.05, -1), (120.20, 1), (134.77, 1), (231.75, -1), (248.64, -1) };
        check(sides.All(e => Side(e.Item1) == e.Item2) && r.Car["impact_side"].Any(x => x.v == -1),
              s + "hit sides: " + string.Join(", ", sides.Select(e => $"{e.Item1} {Side(e.Item1)}")));
        // no side ever the wrong way round at her other marked hits (left: 84.68, 206.48 to 209.74; right: 176.74, 204.33, 226.44)
        var lefts = new[] { 84.68, 161.78, 206.48, 207.07, 208.39, 209.08, 209.74 }; var rights = new[] { 176.74, 204.33, 226.44 };
        check(lefts.All(t => Side(t) <= 0) && rights.All(t => Side(t) >= 0), s + "no hit given the wrong side: " + string.Join(", ", lefts.Concat(rights).Select(t => $"{t} {Side(t)}")));
        // surfaces: the planked bridge (code 10) is rough ground 0.5, the dirt road none, the grassy verge 1
        check(At("off_road", 155.0) == 0.5 && At("off_road", 90.0) == 0 && At("off_road", 249.0) == 1 && At("off_road", 104.0) == 0,
              s + $"surfaces: bridge {At("off_road", 155.0)}, road {At("off_road", 90.0)}, verge {At("off_road", 249.0)}, ripple strip {At("off_road", 104.0)}");
        check(Math.Abs(CarAt("speed", 90.0) - At("speed", 90.0) * 160) < 1e-6 && At("speed", 90.0) < 1, s + "speed over Max speed 160");
        MarioCup(check, path);
        MkUsaTests.Run(check, gamePackDir);
    }

    // Alexis's second v1.18 recording (11 November 2026, 14:20): Mario cup course 1, four laps from 6th, won. Her names: 0 the
    // blue, stripy rebound-ace road, 11 its verge, 13 striped blue and gold glass ending in three boost rings (10) with sand (14)
    // between and after them, 12 pavement. 110.9 s an item flipped her into the air spinning over and over (state 6); 161.1 a
    // banana peel spun her (state 10), then a kart hit her right side; 147.0 a kart on her left, 147.8 one on her right;
    // 100.2 the right-hand wall; 91.9 an item from behind.
    static void MarioCup(Action<bool, string> check, string path)
    {
        var r = Replay(check, path, "mkgpdx118-20261111-142048.csv.gz", "MKGPDX118", new HashSet<string>());
        const string s = "MKGPDX118 14:20: ";
        List<(double t, double v)> O(string n) => r.Out[n];
        double At(string n, double t) => O(n).First(x => x.t >= t).v;
        double Side(double t) => O("hit_side").Where(x => x.t >= t && x.t <= t + 0.4).Select(x => x.v).FirstOrDefault(v => v != 0);
        check(At("racing", 82.9) == 0 && At("racing", 83.1) == 1 && At("racing", 192.8) == 1 && At("racing", 193.0) == 0, s + "racing from GO to the line");
        check(At("laps_total", 100) == 4 && At("lap", 100) == 1 && At("lap", 113) == 2 && At("lap", 139) == 3 && At("lap", 168) == 4 &&
              At("final_lap", 166) == 0 && At("final_lap", 180) == 1, s + "four laps, the lap ticking over at each line");
        check(At("position", 70) == 6 && At("position", 190) == 1 && At("leader", 190) == 1 && At("place_gained", 86.0) == 1,
              s + "from 6th on the grid to 1st at the line");
        check(Math.Abs(At("race_time", 194) - 105.488) < 1e-9 && Math.Abs(At("race_time", 112.57) - 28.432) < 0.05,
              s + $"race time {At("race_time", 194)} s at the line (the game's clock: 16 ms a frame)");
        check(At("off_road", 85) == 0 && At("off_road", 95) == 0 && At("off_road", 101.5) == 1 && At("off_road", 105) == 1,
              s + $"surfaces: road {At("off_road", 85)}, glass {At("off_road", 95)}, sand {At("off_road", 101.5)}, verge {At("off_road", 105)}");
        check(At("spin", 112) == 1 && At("knocked", 112) == 1 && At("airborne", 112) == 1 && At("spin", 161.5) == 1 && At("spin", 115) == 0,
              s + "flipped spinning into the air at 110.9 s, the banana spin at 161.1");
        check(Side(147.0) == -1 && Side(147.76) == 1 && Side(100.18) == 1 && Side(161.07) == 0 && Side(162.25) == 0,
              s + $"hit sides: 147.0 {Side(147.0)}, 147.8 {Side(147.76)}, the wall at 100.2 {Side(100.18)}, none while spinning");
        check(Side(175.66) <= 0 && Side(127.53) >= 0, s + "no side the wrong way round (175.7 a kart on her left, 127.5 one on her right)");
    }

    internal sealed class MkReplay
    {
        public Dictionary<string, List<(double t, double v)>> Out = new Dictionary<string, List<(double t, double v)>>();
        public Dictionary<string, List<(double t, double v)>> Car = new Dictionary<string, List<(double t, double v)>>();
    }

    internal static MkReplay Replay(Action<bool, string> check, string path, string fixture, string prefix, HashSet<string> later)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = "";
        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = prefix });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), prefix + " rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
        ps.Connected = true;
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(kv.Key));
        // rows added after the recording (or left unticked in it) read blank
        check(cols.All(c => c.Value >= 0 || later.Contains(c.Key)), prefix + " " + fixture + ": the recording has the memory rows: missing " + string.Join(", ", cols.Where(c => c.Value < 0 && !later.Contains(c.Key)).Select(c => c.Key)));
        var rp = new MkReplay();
        foreach (var v in ps.Vars) rp.Out[v.Def.Name] = new List<(double t, double v)>();
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        int tc = Col("time_s");
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            foreach (var kv in feeds) kv.Value.Value = cols[kv.Key] < 0 ? double.NaN : Num(r, cols[kv.Key]);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
        }
        return rp;
    }
}
