using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Outputs;

/// Feeds known memory values to the game pack profiles that read game memory, and checks the decoding.
static class MemProfilesTests
{
    const long Main = 0x400000, Jgt = 0x10000000;

    sealed class Mem : IMemoryReader
    {
        public readonly Dictionary<long, long> Ptr = new Dictionary<long, long>();
        public readonly Dictionary<long, double> Val = new Dictionary<long, double>();
        public bool TryGetModuleBase(string m, out long b)
        {
            b = m == ProcessMemory.MainModule ? Main : m.Equals("jgt.dll", StringComparison.OrdinalIgnoreCase) ? Jgt : 0;
            return b != 0;
        }
        public bool TryReadPointer(long a, out long v) => Ptr.TryGetValue(a, out v) && v != 0;
        public bool TryReadValue(long a, MemType t, out double v) => Val.TryGetValue(a, out v);
    }

    public static void Run(Action<bool, string> check, Action<double, double, double, string> near, string pack)
    {
        // Output names with spaces can be read the way formulas and SimHub spell them.
        var oc = new NetOutputsClient();
        oc.Handle("Intake Left = 1");
        near(oc.Get("Intake_Left"), 1, 0, "outputs: 'Intake Left' readable as Intake_Left");
        near(oc.Get("Intake Left"), 1, 0, "outputs: and by its own name");

        if (pack == null || !Directory.Exists(pack)) return;
        Mem mem = null; ProfileState ps = null; double t = 0;
        void Load(string prefix)
        {
            var prof = ProfileStore.ReadProfile(PackFiles.Find(pack, prefix));
            var eng = new TelemetryEngine();
            eng.Load(new[] { prof }, new PluginSettings { ActiveGame = prefix });
            ps = eng.Profiles[0];
            check(ps.Vars.All(v => !v.HasConfigError), $"{prefix} loads: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
            check(prof.ProcessName.EndsWith(".exe"), $"{prefix}: process set ({prof.ProcessName})");
            mem = new Mem();
            ps.SrcCtx.Memory = mem;
        }
        void Tick() => TelemetryEngine.EvaluateTick(ps, t += 1.0 / 120);
        double V(string n) => ps.Vars.Single(v => v.Def.Name == n).Output;
        long blk = 0x60000000;
        // a pointer chain from <main>+b, reusing pointers already set, with v at the last offset
        void Chain(long b, double v, params long[] offs)
        {
            long a = Main + b;
            foreach (var o in offs.Take(offs.Length - 1)) { if (!mem.Ptr.TryGetValue(a, out var p)) mem.Ptr[a] = p = blk += 0x100000; a = p + o; }
            if (!mem.Ptr.TryGetValue(a, out var q)) mem.Ptr[a] = q = blk += 0x100000;
            mem.Val[q + offs[^1]] = v;
        }

        // Initial D style: UInt32 command with a UInt16 strength over its top half
        void IdFfb(long addr, int cmd, int v1, int str)
        {
            mem.Val[addr] = (uint)(cmd | v1 << 8 | str << 16);
            mem.Val[addr + 2] = str;
        }
        foreach (var (g, addr) in new[] { ("ID5", 0x08CB6120L), ("IDTA", Main + 0x3D35838), ("ID4", 0x089AE898L), ("KODRIVE", Main + 0x7261F4) })
        {
            Load(g);
            IdFfb(addr, 0x84, 1, 0x4000); Tick(); near(V("force"), 0x4000 / 32767.0, 1e-9, g + ": 0x84 dir 1 = +strength");
            IdFfb(addr, 0x86, 0, 0x2000); Tick(); near(V("spring"), 0x2000 / 32767.0, 1e-9, g + ": 0x86 = spring");
            near(V("force"), 0x4000 / 32767.0, 1e-9, g + ": force held through a spring command");
            IdFfb(addr, 0x84, 0, 0x6000); Tick(); near(V("force"), -(32767 - 0x6000) / 32767.0, 1e-9, g + ": 0x84 dir 0 = -(32767 - strength)");
            IdFfb(addr, 0x85, 0x40, 0x7FFF); Tick(); near(V("vibration"), 1, 1e-9, g + ": 0x85 = vibration");
        }

        Load("SWDC");
        mem.Val[Main + 0x9BC7B20] = BitConverter.ToInt32(new[] { (byte)'S', (byte)'D', (byte)'D', (byte)'S' }, 0);
        IdFfb(Main + 0x9BC7B18, 0x84, 1, 0x2000); Tick();
        near(V("version"), 230, 0, "SWDC: finds version 2.30 by its SDDS tag");
        near(V("force"), 0x2000 / 32767.0, 1e-9, "SWDC: decodes the 2.30 command");
        // The rows read the addresses Alexis's table gives (Cheat Engine lists offsets last first).
        var ct = CheatTableImporter.ImportFile(Path.Combine("fixtures", "swdc-20261103.CT")).Profile.Variables;
        var swdc = ProfileStore.ReadProfile(PackFiles.Find(pack, "SWDC")).Variables;
        foreach (var (row, entry) in new[] { ("revs", "revs"), ("speed2", "speed2"), ("speed1", "speed1"), ("gear2", "gears2"), ("gear1", "gears1") })
        {
            var a = swdc.First(v => v.Name == row); var b = ct.First(v => v.Name == entry);
            check(a.BaseOffset.TrimStart('0') == b.BaseOffset.TrimStart('0') && a.Offsets.Replace(" ", "") == b.Offsets.Replace(" ", ""),
                  $"SWDC {row} reads the table's {entry}: {a.BaseOffset} [{a.Offsets}] vs {b.BaseOffset} [{b.Offsets}]");
        }

        // 18 November 2026, from the v2.30 exe: the game's data model Q = [[[<main>+4B07438]+278]+10]; Q+16D0 your car number,
        // Q+2550 the per-car records (578 bytes each, car 1 first), Q+2558 how many. Your record: +8 car number, +2E0 race state,
        // +460 km/h, +490 gear, +410 place. 19 November: values only from the rolling start (state 2) to the line (state 3).
        Load("SWDC");
        mem.Val[Main + 0x9BC7B20] = BitConverter.ToInt32(new[] { (byte)'S', (byte)'D', (byte)'D', (byte)'S' }, 0);
        IdFfb(Main + 0x9BC7B18, 0x86, 0, 7444);                                  // the driving spring: no longer a race signal
        mem.Ptr[Main + 0x9D1AAE8] = 0x60000000; mem.Ptr[0x60000DD0] = 0x61000000; mem.Ptr[0x61000020] = 0x62000000;
        mem.Val[0x62000298] = 52f; mem.Val[0x62000348] = 3;
        for (int i = 0; i < 30; i++) { mem.Val[Main + 0x9EAF670] = 6100f + i; Tick(); }
        near(V("in_race"), 0, 0, "SWDC: no car record (menus, attract mode): not racing, whatever the revs");
        near(V("revs"), 0, 0, "SWDC: revs read 0 outside a race (they hold their last value in the menus)");
        near(V("speed2"), 0, 0, "SWDC: speed2 0 outside a race"); near(V("car_rpm"), 0, 0, "SWDC: Car_rpm 0 outside a race");
        const long Q = 0x70000000, Recs = 0x71000000, Rec = Recs + 34 * 0x578;   // you are car 35
        mem.Ptr[Main + 0x4B07438] = 0x6F000000; mem.Ptr[0x6F000278] = 0x6F100000; mem.Ptr[0x6F100010] = Q;
        mem.Ptr[Q + 0x2550] = Recs; mem.Val[Q + 0x2558] = 45; mem.Val[Q + 0x16D0] = 35;
        mem.Val[Rec + 0x8] = 35; mem.Val[Rec + 0x2E0] = 1; mem.Val[Rec + 0x460] = 0; mem.Val[Rec + 0x490] = 1; mem.Val[Rec + 0x420] = 20;
        mem.Val[Main + 0x9EAF670] = 9326.67f;
        for (int i = 0; i < 10; i++) Tick();
        near(V("player_ok"), 1, 0, "SWDC: your record found by your car number");
        near(V("in_race"), 0, 0, "SWDC: not racing in the countdown (race state 1)"); near(V("car_speed"), 0, 0, "SWDC: Car_speed 0 before the rolling start");
        near(V("revs"), 0, 0, "SWDC: the countdown's frozen revs read 0");
        mem.Val[Rec + 0x2E0] = 2; mem.Val[Rec + 0x460] = 187; mem.Val[Rec + 0x490] = 5;
        for (int i = 0; i < 30; i++) { mem.Val[Main + 0x9EAF670] = 10500f; Tick(); }
        near(V("in_race"), 1, 0, "SWDC: racing at race state 2");
        near(V("car_speed"), 187, 0, "SWDC: Car_speed is the speedo's km/h from your record"); near(V("car_gear"), 5, 0, "SWDC: Car_gear from your record");
        near(V("car_rpm"), 10500, 1e-3, "SWDC: Car_rpm from the table's revs, steady on the limiter too"); near(V("position"), 20, 0, "SWDC: your place in your class");
        near(V("speed_kmh"), 2.0625 * 52 + 0.005467 * 52 * 52, 1e-3, "SWDC: the table's raw 52 = 122 km/h on the speedo");
        mem.Val[Rec + 0x2E0] = 3; Tick();
        near(V("in_race"), 0, 0, "SWDC: out of the race at your finish line (race state 3)"); near(V("car_speed"), 0, 0, "SWDC: Car_speed 0 after the line");
        near(V("revs"), 0, 0, "SWDC: revs 0 after the line");
        mem.Val[Rec + 0x2E0] = 2; mem.Val[Rec + 0x8] = 9; Tick();
        near(V("player_ok"), 0, 0, "SWDC: a record with another car number is not yours");
        near(V("in_race"), 0, 0, "SWDC: so not racing");

        Load("MKGPDX110");
        mem.Ptr[Main + 0xA2FE20] = 0x20000000; mem.Ptr[0x20000008] = 0x30000000; mem.Val[0x30000000 + 0xA44] = 0.5;
        mem.Ptr[Main + 0xA416E4] = 0x40000000; mem.Val[0x40000000 + 0x628] = 4; mem.Val[0x40000000 + 0x658] = 1;
        Tick();
        near(V("force"), -0.5, 1e-9, "MK 1.10: two-level pointer, + raw = force from the left");
        near(V("rough_ground"), 1, 0, "MK 1.10: grass on the ground = rough");

        // 9 November 2026, from the v1.18 exe: the player's kart is <main>+AAEEA0 -> +8 (the list's player car)
        Load("MKGPDX118");
        mem.Ptr[Main + 0xAAEEA0] = 0x20000000; mem.Ptr[0x20000008] = 0x30000000;
        mem.Val[0x30000000 + 0xAC4] = 85.5; mem.Val[0x30000000 + 0xAC8] = 6200; mem.Val[0x30000000 + 0xBC8] = 0.25;
        mem.Ptr[Main + 0xAC2A30] = 0x40000000; mem.Val[0x40000000 + 0x6B8] = 1; mem.Val[0x40000000 + 0x6BA] = 1;
        mem.Val[Main + 0xAC72D8] = -268435456;   // 0xF0000000 as a signed Int32 read
        Tick();
        near(V("speed"), 85.5 / 160, 1e-9, "MK 1.18: speed from the kart's +AC4 through the car list");
        near(V("rpm"), 6200 / 10000.0, 1e-9, "MK 1.18: revs from the kart's +AC8");
        near(V("force"), -0.25, 1e-9, "MK 1.18: force through the same kart pointer");
        near(V("drift_side"), 1, 0, "MK 1.18: drift side flag");
        near(V("sideledred"), 1, 0, "MK 1.18: side lamp bit 0xF0000000 lights now the word is read as 32 bits");
        check(ps.Vars.Single(v => v.Def.Name == "ob_kanbansidelampdata").Def.Type == MemType.Int32, "MK 1.18: side lamp word read as Int32");
        check(!ps.Vars.Single(v => v.Def.Name == "speed_snd").Def.Enabled, "MK 1.18: the FFB plugin's old speed is kept unticked");
        mem.Ptr[Main + 0xAAEE80] = 0x50000000; mem.Ptr[0x50000038] = 0x51000000; mem.Val[0x5100000C] = 6; Tick();
        near(V("race_state"), 6, 0, "MK 1.18: race state through the race manager's current state (6 = race)");
        // 11 November 2026, from the v1.18 exe: place, laps and race time (claude/MKGPDX118-exe-20261111.md)
        Chain(0xAAEEA0, 2, 8, 0xCC, 0x1D4); Chain(0xAAEEA0, 1, 8, 0xCC, 0x1E4); Chain(0xAAEE7C, 3, 4, 0x10); Chain(0xAAEEA0, 61234, 4, 0x2C); Tick();
        near(V("position"), 2, 0, "MK 1.18: place through the kart's race record (+CC -> +1D4)");
        near(V("laps_done"), 1, 0, "MK 1.18: laps done at the record's +1E4"); near(V("laps_total"), 3, 0, "MK 1.18: laps in the race");
        near(V("race_time"), 61.234, 1e-9, "MK 1.18: race time in seconds from the HUD's millisecond count");
        // the attract demo runs race state 6 with the FFB's in-race flag 0 (Alexis's attract recording): no effects then
        near(V("racing"), 0, 0, "MK 1.18: race state 6 without the in-race flag (the attract demo) is not racing");
        near(V("lap"), 0, 0, "MK 1.18: no lap outside a race");
        Chain(0xAAFAB8, 1, 0x44, 0x70, 0x108, 0x98, 0x4C4); Tick();
        near(V("racing"), 1, 0, "MK 1.18: racing with the in-race flag"); near(V("lap"), 2, 0, "MK 1.18: lap 2 after one lap done");
        near(V("final_lap"), 0, 0, "MK 1.18: not the last lap yet");
        Chain(0xAAEEA0, 2, 8, 0xCC, 0x1E4); Chain(0xAAEEA0, 1, 8, 0xCC, 0x1D4); Tick();
        near(V("final_lap"), 1, 0, "MK 1.18: last lap"); near(V("leader"), 1, 0, "MK 1.18: leading in first place");

        // 11 November 2026, from the USA exe: the same structures at other places (claude/MKGPDXUSA-exe-20261111.md)
        Load("MKGPDXUSA");
        mem.Ptr[Main + 0xB47B48] = 0x20000000; mem.Ptr[0x20000008] = 0x30000000;
        mem.Val[0x30000000 + 0x958] = 92.5; mem.Val[0x30000000 + 0x95C] = 7100; mem.Val[0x30000000 + 0x2FC] = 0.5;
        mem.Ptr[Main + 0xB4F324] = 0x40000000; mem.Val[0x40000000 + 0x674] = 1; mem.Val[0x40000000 + 0x676] = 1;
        mem.Val[Main + 0xB96B58] = -268435456;   // v1.18's side lamp word (+AC72D8) moved 0xCF880 with the I/O block
        mem.Val[Main + 0xB96834] = 4;            // v1.18's button lamp byte (+AC6FB4), moved the same
        Tick();
        near(V("speed"), 92.5 / 160, 1e-9, "MK USA: speed from the kart's +958 through the car list");
        near(V("rpm"), 7100 / 10000.0, 1e-9, "MK USA: revs from the kart's +95C");
        near(V("force"), -0.5, 1e-9, "MK USA: the FFB plugin's force through the same kart pointer");
        near(V("drift_angle"), -30, 1e-9, "MK USA: drift angle = asin of the slide sine, + right-hand as in v1.18's recording (raw 0.5 = -30 degrees)");
        near(V("drift"), 1, 0, "MK USA: drift flag"); near(V("drift_side"), 1, 0, "MK USA: drift side flag");
        near(V("sideledred"), 1, 0, "MK USA: side lamp bit 0xF0000000 from the moved lamp word");
        near(V("lampstart"), 1, 0, "MK USA: start lamp from the moved button byte");
        check(!ps.Vars.Single(v => v.Def.Name == "speed_snd").Def.Enabled, "MK USA: the FFB plugin's old speed is kept unticked");
        mem.Val[0x30000000 + 0x2FC] = -1.2; Tick();
        near(V("drift_angle"), 90, 1e-9, "MK USA: a sine past -1 reads 90 degrees, not NaN");
        mem.Ptr[Main + 0xB47B28] = 0x50000000; mem.Ptr[0x50000038] = 0x51000000; mem.Val[0x5100000C] = 6; Tick();
        near(V("race_state"), 6, 0, "MK USA: race state through the race manager's current state (6 = race)");
        Chain(0xB47B48, 4, 8, 0xA8, 0x1D0); Chain(0xB47B48, 2, 8, 0xA8, 0x1DC); Chain(0xB47B24, 3, 4, 0xC); Chain(0xB47B48, 95500, 4, 0x2C); Tick();
        near(V("position"), 4, 0, "MK USA: place through the kart's race record (+A8 -> +1D0)");
        near(V("laps_done"), 2, 0, "MK USA: laps done at the record's +1DC"); near(V("laps_total"), 3, 0, "MK USA: laps in the race");
        near(V("race_time"), 95.5, 1e-9, "MK USA: race time in seconds");
        near(V("racing"), 0, 0, "MK USA: race state 6 without the in-race flag (the attract demo) is not racing");
        Chain(0xB486BC, 1, 0x2E0, 0xAC, 0xC, 0xC, 0x330); Tick();
        near(V("racing"), 1, 0, "MK USA: racing with the in-race flag"); near(V("final_lap"), 1, 0, "MK USA: lap 3 of 3 is the last");

        Load("DAYTONA3");
        mem.Val[Main + 0x131FEC9] = 0x95; mem.Ptr[Main + 0x11B0148] = 0x50000000; mem.Val[0x50000004] = 1; mem.Val[Main + 0x15B5744] = 22;
        Tick(); near(V("force"), -11 / 15.0, 1e-9, "Daytona: 0x95 = -11/15");
        mem.Val[0x50000004] = 2; Tick(); near(V("force"), 11 / 15.0, 1e-9, "Daytona: swapped on track 2 in a race");
        mem.Val[Main + 0x131FEC9] = 0xA5; Tick(); near(V("force"), -11 / 15.0, 1e-9, "Daytona: 0xA5 swapped = -11/15");
        mem.Val[Main + 0x131FEC9] = 0x85; Tick(); near(V("spring"), 11 / 15.0, 1e-9, "Daytona: 0x85 = spring 11/15");
        near(V("force"), -11 / 15.0, 1e-9, "Daytona: force held");

        Load("CHASEHQ2");
        mem.Ptr[Main + 0x130B558] = 0x60000000;
        mem.Val[0x60000045] = 20480 + 16; Tick(); near(V("force"), 1 / 15.0, 1e-9, "Chase HQ 2: lamp bit removed, level 15 = +1/15");
        mem.Val[0x60000045] = 24640 + 512; Tick(); near(V("force"), -2 / 15.0, 1e-9, "Chase HQ 2: level 29 = -2/15");

        Load("WACKYRACES");
        mem.Ptr[Main + 0x7E00590] = 0x60000000;
        mem.Val[0x60000045] = 4096 + 16384; Tick(); near(V("force"), 1 / 15.0, 1e-9, "Wacky Races: level 30 = +1/15");
        mem.Val[0x60000045] = 14432; Tick(); near(V("force"), -15 / 15.0, 1e-9, "Wacky Races: level 1 = -1");

        Load("RF3D");
        mem.Val[Jgt + 0x7D2BB9] = 3; mem.Val[Jgt + 0x7D2BBB] = 1; mem.Val[Jgt + 0x7D2BBC] = 1; Tick();
        near(V("force"), -3 / 7.0, 1e-9, "RF3D: jgt.dll module, 3 = -3/7");

        Load("BG4JP");
        // 11 November 2026 (Alexis: effects off once the finish line is crossed): the countdown and race on, the finish off
        mem.Val[Main + 0x4A9508] = 1; mem.Val[Main + 0x3F2654] = 1; Chain(0x42CCA8, 6, 0x64); Tick();
        near(V("car_in_race"), 1, 0, "BG4JP: in the countdown (phase 6)");
        Chain(0x42CCA8, 8, 0x64); Tick(); near(V("car_in_race"), 0, 0, "BG4JP: off from the finish line (phase 8)");
        Chain(0x42CCA8, 9, 0x64); Tick(); near(V("car_in_race"), 0, 0, "BG4JP: off while the car rolls to a stop (phase 9)");
        mem.Val[Main + 0x4A9508] = 0; mem.Val[Main + 0x3F2654] = 0; Chain(0x42CCA8, 0, 0x64);
        mem.Val[Main + 0x42EBB2] = 32; Tick(); near(V("impact_side"), 1, 0, "BG4JP: wall flag 32 = right");
        mem.Val[Main + 0x42EBB2] = 0; mem.Val[Main + 0x42EBB3] = 8; Tick(); near(V("impact_side"), -1, 0, "BG4JP: car flag 8 = left");
        // 9 November 2026, from the game's code: car 0's record (speed signed, revs, gear -1 reverse, position 0 = first)
        mem.Val[Main + 0x42ECDC] = -12.5; mem.Val[Main + 0x42ECE4] = 700; mem.Val[Main + 0x42ECF0] = -1; mem.Val[Main + 0x42EC1C] = 0;
        mem.Val[Main + 0x4A9508] = 1; Tick();
        near(V("speed"), 12.5 / 200, 1e-9, "BG4JP: speed is the speedo's size of the signed speed, over Max speed 200");
        near(V("rpm"), 700 / 8000.0, 1e-9, "BG4JP: revs over Max revs 8000");
        near(V("gear"), -1, 0, "BG4JP: gear reads -1 in reverse");
        check(ps.Vars.Single(v => v.Def.Name == "gear").Def.Type == MemType.Int32, "BG4JP: gear is read as Int32 (as a Byte, reverse read 255)");
        near(V("position"), 1, 0, "BG4JP: position 1 = first (stored 0)");
        check(double.IsNaN(V("leader")) || V("leader") == 0, "BG4JP: no leader without the race phase");
        // 10 November 2026, Alexis's recording: race phase 7 and a cockpit camera = racing; camera 12 = attract demo and menus
        mem.Ptr[Main + 0x42CCA8] = 0x20000000; mem.Val[0x20000064] = 7; mem.Val[Main + 0x3F2654] = 2; Tick();
        near(V("leader"), 1, 0, "BG4JP: leader while first in a race");
        mem.Val[Main + 0x3F2654] = 12; Tick();
        near(V("leader"), 0, 0, "BG4JP: no leader in the menus (camera 12), though the game's race flag stays on");
        near(V("car_in_race"), 0, 0, "BG4JP: Car_in_race off in the menus");
        mem.Val[Main + 0x3F2654] = 2; mem.Val[Main + 0x42EBB2] = 128; mem.Val[Main + 0x42EBB3] = 0; Tick();
        near(V("car_wall_contact"), 1, 0, "BG4JP: wall bit 128 = scraping the right-hand wall");
        near(V("impact_side"), 0, 0, "BG4JP: scraping alone isn't a hit");
        mem.Val[Main + 0x42EBB2] = 0; mem.Val[Main + 0x42EBB3] = 4; Tick();
        near(V("contact"), 1, 0, "BG4JP: a bump from behind (car bit 4) counts as contact");
        // race time left from the exe: [<main>+4B1758] +34 -> +1C frames
        mem.Ptr[Main + 0x4B1758] = 0x21000000; mem.Ptr[0x21000034] = 0x22000000; mem.Val[0x2200001C] = 69.8 * 60; Tick();
        near(V("time_left"), 69.8, 1e-9, "BG4JP: time left in seconds from frames");
        mem.Val[0x2200001C] = 119.61 * 60; Tick();
        near(V("checkpoint"), 1, 0, "BG4JP: a checkpoint's extension (time left jumping up) lights checkpoint");
        mem.Val[Main + 0x42EBB2] = 2; Tick(); near(V("boost"), 1, 0, "BG4JP: wall bit 2 (a nitro burning, 7 s a shot) is boost");
        check(!ps.Vars.Any(v => v.Def.Name == "car_off_road"), "BG4JP: the nitro bit is no longer read as off-road");
        mem.Val[Main + 0x42EBB2] = 0; Tick(); near(V("boost"), 0, 0, "BG4JP: no boost once the nitro is spent");
        // Brake! (10 November 2026): the car navigation's second sign, [race scene +3C] +48 on, +4C its code
        mem.Ptr[0x21000000 + 0x3C] = 0x23000000; mem.Val[0x23000048] = 1; mem.Val[0x2300004C] = 0x1000; Tick();
        near(V("brake_warning"), 1, 0, "BG4JP: Brake! from the car navigation's second sign");
        mem.Val[0x23000048] = 0; mem.Val[Main + 0x42F75C] = 2; Tick();
        near(V("brake_warning"), 1, 0, "BG4JP: Brake! held after its one-frame trigger");
        near(V("auto_brake"), 1, 0, "BG4JP: the brake assist's flag");
        mem.Val[Main + 0x42F75C] = 0; mem.Val[Main + 0x42EBB1] = 128; Tick();
        near(V("wheelspin"), 1, 0, "BG4JP: ground flag 128 = wheelspin (recording 6)");
        near(V("car_grip_loss"), 1, 0, "BG4JP: wheelspin feeds Car_grip_loss");

        Load("SEGARACINGCLASSIC");
        mem.Val[0x834C19] = 0xA9; Tick(); near(V("force"), 7 / 8.0, 1e-9, "Sega Racing Classic: 0xA9 = +7/8");
        mem.Val[0x834C19] = 0x99; Tick(); near(V("force"), -7 / 8.0, 1e-9, "Sega Racing Classic: 0x99 = -7/8");

        Load("WMMT5DXP");
        void Coll(double v, double secs) { mem.Val[Main + 0x1FA6F4C] = v; for (int i = 0; i < Math.Max(1, (int)Math.Round(secs * 120)); i++) Tick(); }
        Coll(0, 0.3); Coll(0.25, 0);
        near(V("road_joint"), 0.25, 1e-9, "WMMT5DX+: 0.25 collision = road joint");
        near(V("impact"), 0, 0, "WMMT5DX+: and not a hit");
        Coll(0, 0.3); Coll(-0.8, 0); near(V("impact"), -0.8, 1e-9, "WMMT5DX+: -0.8 = hit from the left");
        Coll(0, 0.3); Coll(0.17, 0);
        near(V("road_joint"), 0.17, 1e-9, "WMMT5DX+: a slow-speed joint (0.17) is still a joint");
        near(V("impact"), 0, 0, "WMMT5DX+: and not a hit");
        Coll(0.5, 0); near(V("impact"), 0.5, 1e-9, "WMMT5DX+: 0.5 = an ordinary hit");
        Coll(0.2, 0.2); near(V("road_joint"), 0, 0, "WMMT5DX+: 0.2 held after a hit is the wall, not a joint");
        Coll(0.2, 0.3); near(V("wall_contact"), 1, 0, "WMMT5DX+: held contact = wall_contact on the right");
        Coll(0, 0.5); near(V("wall_contact"), 0, 0, "WMMT5DX+: wall_contact off when contact ends");
        mem.Ptr[Main + 0x1FD11B0] = 0x500000; mem.Val[0x500398] = 3; Tick();
        near(V("gear"), 3, 0, "WMMT5DX+: stored gear 3 = 3rd (0 is neutral)");
        // Rows from the Outputs script (2 November 2026): the same race structure as the gear row.
        mem.Val[0x500BEC] = 50000f; mem.Val[0x500D94] = 6543.4f; mem.Val[0x5003F0] = 1.25f; mem.Val[0x5002E4] = 61.5f; Tick();
        near(V("speed2"), 180 / 230.0, 1e-6, "WMMT5DX+ Outputs script: 50000 mm/s = 180 km/h, over Max speed 230");
        near(V("rpm2"), 6543.4 / 8900.0, 1e-4, "WMMT5DX+ Outputs script: float revs over Max revs (8900)");
        near(V("turbo"), 1.25, 1e-6, "WMMT5DX+ Outputs script: turbo gauge raw"); near(V("race_time2"), 61.5, 1e-6, "WMMT5DX+ Outputs script: race clock");
        mem.Val[Main + 0x1FD5904] = 85 | 17 << 16; mem.Val[Main + 0x1FD5A14] = 40 | 34 << 16; Tick();
        near(V("throttle"), 1, 1e-9, "WMMT5DX+ Outputs script: throttle, low byte, the higher copy, 85 = full");
        near(V("brake"), 34 / 85.0, 1e-9, "WMMT5DX+ Outputs script: brake, third byte, the higher copy");
        mem.Val[0x500A78] = 1500000f; mem.Ptr[0x500158] = 0x510000; mem.Val[0x510028] = 250000f; Tick();
        near(V("distance"), 1250, 1e-6, "WMMT5DX+ Outputs script: distance = (progress - start) / 1000 metres");
        mem.Val[Main + 0x1FD17E0] = 3; mem.Val[Main + 0x1FD17E4] = 2; mem.Val[Main + 0x1FD17E8] = 0; mem.Val[Main + 0x1FD17EC] = 1; Tick();
        near(V("place"), 3, 0, "WMMT5DX+ Outputs script: the player (0) third in the race order = 3rd");

        // Outputs read straight from memory (translated from OutputBlaster's code)
        check(ps.Vars.All(v => !v.Def.Name.StartsWith("ob_ffb")), "WMMT5DX+: OutputBlaster's FFB1-4 copies are gone");
        mem.Val[Main + 0x1FD55D1] = 0x08; mem.Val[Main + 0x1FD55D2] = 0xE0 | 0x10; Tick();
        near(V("lampview1"), 1, 0, "WMMT5DX+: View1 lamp bit"); near(V("lampinterruptionbutton"), 0, 0, "WMMT5DX+: interruption off");
        near(V("lampred"), 1, 0, "WMMT5DX+: red"); near(V("lampside"), 1, 0, "WMMT5DX+: side"); near(V("lampwhite"), 1, 0, "WMMT5DX+: white when byte 2 >= 0xE0");
        mem.Val[Main + 0x1FD55D2] = 0x80; Tick();
        near(V("lampwhite"), 0, 0, "WMMT5DX+: white off below 0xE0"); near(V("lampgreen"), 0, 0, "WMMT5DX+: green off");

        Load("ID0V131");   // four-level pointer chain, 64-bit
        mem.Ptr[Main + 0x21396F0] = 0x100000; mem.Ptr[0x100040] = 0x200000; mem.Ptr[0x200040] = 0x300000; mem.Ptr[0x300000] = 0x400000;
        mem.Val[0x400278] = 0x80 | 0x02; mem.Val[0x400279] = 0x40; Tick();
        near(V("lampstart"), 1, 0, "ID0 v1.31: start lamp through the pointer chain"); near(V("lampview1"), 0, 0, "ID0 v1.31: view off");
        near(V("lampselectup"), 1, 0, "ID0 v1.31: select up"); near(V("lampselectright"), 1, 0, "ID0 v1.31: select right (second byte)");

        Load("BG4JP");     // lookup table, then scaled
        mem.Val[0x82D95C] = 0x10; mem.Val[0x82D95E] = 0x20; mem.Val[0x82D960] = 0x20; mem.Val[0x82D962] = 0; Tick();
        near(V("lampstart"), 4 / 8.0 * 100, 1e-9, "BG4: start lamp 0x10 -> level 4 of 8 -> 50");
        near(V("lampyellow"), 8 / 8.0 * 100, 1e-9, "BG4: yellow = red and green levels");
        near(V("lampwhite"), 0, 1e-9, "BG4: white needs blue too");

        Load("SR3");       // RPM rounded as OutputBlaster does
        mem.Val[Main + 0x5DBE84] = 5049.6; mem.Val[Main + 0x5D6DF8] = 2; Tick();
        near(V("rpm"), 5050 / 7100.0, 1e-9, "SR3: rpm = round(5049.6) / Max revs 7100 (OutputBlaster itself sends RPM / 100)"); near(V("lampview2"), 1, 0, "SR3: view2 is start byte bit 2"); near(V("lampstart"), 0, 0, "SR3: start off");
        mem.Val[Main + 0x5DD104] = 1; Tick(); near(V("lampview1"), 1, 0, "SR3: view1 read straight into its own row (bit 1)");
        check(ps.Vars.Count(v => v.Def.Name.StartsWith("ob_")) == 1, "SR3: one ob_ row, the start byte the Start and View 2 lamps share");
        mem.Val[Main + 0x74B25C] = 62.5f; Tick(); near(V("speed"), 0.5, 1e-6, "SR3: 62.5 mph = half of Max speed 125");
        mem.Ptr[Main + 0x30B324] = 0x600000; mem.Val[0x6000F4] = 0; Tick(); near(V("gear"), -1, 0, "SR3: stored 0 = reverse (-1)");
        mem.Val[0x6000F4] = 1; Tick(); near(V("gear"), 0, 0, "SR3: stored 1 = neutral");
        mem.Val[0x6000F4] = 7; Tick(); near(V("gear"), 6, 0, "SR3: stored 7 = sixth");
    }
}
