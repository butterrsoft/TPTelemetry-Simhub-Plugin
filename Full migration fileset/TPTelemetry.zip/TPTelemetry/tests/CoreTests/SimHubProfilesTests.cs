using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;
using TeknoTelemetry.Core;

/// <summary>The SimHub effect profiles (.siprofile) the plugin writes: laid out like SimHub 9.9.4's own
/// exports (fixtures), every formula reading a real Car_ value, and the right effects per hardware tick.</summary>
static class SimHubProfilesTests
{
    public static void Run(Action<bool, string> check)
    {
        var bassSample = JObject.Parse(File.ReadAllText(Path.Combine("fixtures", "simhub-9.9.4-bass-shakers.siprofile")));
        var motorSample = JObject.Parse(File.ReadAllText(Path.Combine("fixtures", "simhub-9.9.4-motors.siprofile")));
        var everything = new EffectHardware { Seat = true, PedalBox = true, GasPedal = true, BrakePedal = true, ClutchPedal = true, Motors = true,
                                             MotorPedalBox = true, MotorGasPedal = true, MotorBrakePedal = true, MotorClutchPedal = true, Fans = true };

        foreach (var (sample, bass) in new[] { (bassSample, true), (motorSample, false) })
        {
            var kind = bass ? "Bass Shakers" : "Motors";
            var ours = SimHubProfiles.Profile(bass ? SimHubProfiles.BassEffects(everything) : SimHubProfiles.MotorEffects(everything), bass);
            var missingTop = sample.Properties().Select(p => p.Name).Where(n => ours[n] == null && sample[n].Type != JTokenType.Null).ToList();
            check(missingTop.Count == 0, $"{kind}: profile has every top-level field SimHub 9.9.4 writes; missing {string.Join(", ", missingTop)}");
            check((int)ours["OutputMode"] == (int)sample["OutputMode"], $"{kind}: OutputMode matches SimHub's ({sample["OutputMode"]})");
            check(ours["GameCode"].Type == JTokenType.Null, $"{kind}: Any Game profile (no game code)");
            check((string)ours["Name"] == "TP Telemetry" && (bool)ours["IncludeOutputSettingsInProfile"] == false, $"{kind}: named TP Telemetry, no output settings");

            var ref1 = (JObject)sample["EffectsContainers"].First(c => (string)c["ContainerType"] == "CustomEffectContainer");
            foreach (JObject c in ours["EffectsContainers"])
            {
                var name = (string)c["Description"];
                var missing = Missing(ref1, c, "").Where(m => !m.EndsWith("AssignToChannelGroup") && !m.EndsWith("ChannelGroupName") &&
                                                              !m.EndsWith("PropertyName") && !m.EndsWith("ExportProperty")).ToList();
                check(missing.Count == 0, $"{kind} {name}: has every field of SimHub's custom effect; missing {string.Join(", ", missing)}");
                check((string)c["Output"]["OutputType"] == (string)ref1["Output"]["OutputType"], $"{kind} {name}: output type {ref1["Output"]["OutputType"]}");
                check(name.StartsWith("TP - "), $"{kind} {name}: name starts 'TP - '");
                var formulas = new[] { "FrontLeftFormula", "FrontRightFormula", "RearLeftFormula", "RearRightFormula",
                                       "FrontLeftFrequencyFormula", "FrontRightFrequencyFormula", "RearLeftFrequencyFormula", "RearRightFrequencyFormula" }
                               .Select(f => (string)c[f]["Expression"]).Where(f => f != "").ToList();
                var props = formulas.SelectMany(f => Regex.Matches(f, @"\[TPTelemetry\.Car_(\w+)\]").Cast<Match>().Select(m => m.Groups[1].Value)).ToList();
                check(props.Count > 0 && props.All(pn => CommonValues.OutputIndex(pn) >= 0), $"{kind} {name}: formulas read real Car_ values: {string.Join(", ", props)}");
                check(formulas.All(f => Regex.IsMatch(f, @"^\[TPTelemetry\.Car_\w+\]( \* \d+(\.\d+)?)?$")), $"{kind} {name}: formulas are plain property x scale (no functions SimHub might not have)");
                var mode = (string)c["AggregationMode"];
                check(mode == "Mono" ? (string)c["FrontLeftFormula"]["Expression"] != "" && (string)c["FrontRightFormula"]["Expression"] == ""
                    : mode == "Left/Right" ? (string)c["FrontRightFormula"]["Expression"] != "" && (string)c["RearLeftFormula"]["Expression"] == ""
                    : mode == "Front/Rear" && (string)c["RearLeftFormula"]["Expression"] != "",
                    $"{kind} {name}: formulas sit in the slots SimHub uses for {mode}");
            }
            var ids = ours["EffectsContainers"].Select(c => (string)c["ContainerId"]).ToList();
            check(ids.Distinct().Count() == ids.Count, $"{kind}: effect ids unique");
            var again = SimHubProfiles.Profile(bass ? SimHubProfiles.BassEffects(everything) : SimHubProfiles.MotorEffects(everything), bass);
            check(JToken.DeepEquals(ours, again), $"{kind}: the same ticks always give the same file");
        }

        // which effects for which ticks
        var seatOnly = SimHubProfiles.BassEffects(new EffectHardware { Seat = true });
        check(seatOnly.Count == 16 && seatOnly.All(e => e.Channel == null), "seat shakers: 16 effects, all on the ordinary channels");
        var drift = seatOnly.Single(e => e.Name == "TP - Drift");   // 0.18.0
        check(drift.A == "drift" && drift.B == "drift" && drift.Mode == "Front/Rear" && !drift.Noise, "Drift: Car_drift, mostly at the rear, smooth (not noise like grip loss)");
        check(SimHubProfiles.MotorEffects(new EffectHardware { Motors = true }).Any(e => e.Name == "TP - Drift"), "Drift in the Motors file too");
        var engine = seatOnly.Single(e => e.Name == "TP - Engine");
        check(engine.HzFrom == "engine_hz" && engine.Gain == 50, "Engine: pitch from Car_engine_hz, 50% gain");
        var pedals = SimHubProfiles.BassEffects(new EffectHardware { Seat = false, GasPedal = true, BrakePedal = true, ClutchPedal = true, PedalBox = true });
        check(pedals.All(e => e.Channel != null) && pedals.Select(e => e.Channel).Distinct().Count() == 4,
              "pedal effects each carry their pedal's output name (gas, brake, clutch, pedal box)");
        var pedalHw = new EffectHardware { Seat = false, GasPedal = true, BrakePedal = true, ClutchPedal = true, PedalBox = true };
        var motorPedalHw = new EffectHardware { Seat = false, MotorGasPedal = true, MotorBrakePedal = true, MotorClutchPedal = true, MotorPedalBox = true };
        var motorPedals = SimHubProfiles.MotorEffects(motorPedalHw);
        check(motorPedals.Count == 12 && motorPedals.Select(e => e.Name).SequenceEqual(pedals.Select(e => e.Name)),
              "Shaker Motor pedal ticks: the same pedal effects in the Motors file, same names");
        check(SimHubProfiles.MotorEffects(pedalHw).Count == 0 && SimHubProfiles.BassEffects(motorPedalHw).Count == 0,
              "Bass Shaker pedal ticks only fill the Bass Shakers file, Shaker Motor pedal ticks only the Motors file");
        check(SimHubProfiles.MotorEffects(new EffectHardware { Seat = false, MotorGasPedal = true }).All(e => e.Channel == SimHubProfiles.GasChannel) &&
              SimHubProfiles.MotorEffects(new EffectHardware { Seat = false, MotorGasPedal = true }).Count == 3, "one motor pedal: just its three effects, on its own output");
        check(pedals.All(e => System.Text.RegularExpressions.Regex.IsMatch(e.Name, @"^TP - Pedal (Gas|Brake|Clutch|Box): [A-Z]")),
              "pedal effects named 'TP - Pedal Gas: Engine' style: " + string.Join(", ", pedals.Select(e => e.Name)));
        check(pedalHw.AnyBassShakers && !pedalHw.AnyMotors && motorPedalHw.AnyMotors && !motorPedalHw.AnyBassShakers,
              "pedal ticks make only their own kind's file");
        check(SimHubProfiles.MotorEffects(new EffectHardware { Seat = false, Fans = true }).All(e => e.Channel == SimHubProfiles.FansChannel),
              "fans only: just the wind effects, on the TP Fans output");

        var dir = Path.Combine(Path.GetTempPath(), "tpt-effects-" + Guid.NewGuid().ToString("N"));
        try
        {
            check(SimHubProfiles.Write(new EffectHardware { Seat = false }, dir).Count == 0, "nothing ticked: no files");
            var seat = SimHubProfiles.Write(new EffectHardware { Seat = true }, dir);
            check(seat.Count == 1 && seat[0].EndsWith(SimHubProfiles.BassFile), "seat only: just the Bass Shakers file");
            var both = SimHubProfiles.Write(everything, dir);
            check(both.Count == 2 && both.All(File.Exists), "seat and motors: both files written");
            check(both.All(f => Path.GetFileName(f) == "Any Game - TP Telemetry.siprofile") &&
                  Path.GetFileName(Path.GetDirectoryName(both[0])) == "Bass Shakers" && Path.GetFileName(Path.GetDirectoryName(both[1])) == "Motors",
                  "SimHub's own file name, one folder per kind: " + string.Join(", ", both));
            File.WriteAllText(Path.Combine(dir, "TP Telemetry - Bass Shakers.siprofile"), "{}");
            SimHubProfiles.Write(everything, dir);
            check(!File.Exists(Path.Combine(dir, "TP Telemetry - Bass Shakers.siprofile")), "a file under the old name is removed");
            var parsed = JObject.Parse(File.ReadAllText(both[0]));
            check(parsed["EffectsContainers"].Count() == SimHubProfiles.BassEffects(everything).Count, "written file reads back as JSON with every effect");
        }
        finally { try { Directory.Delete(dir, true); } catch { } }

        // TPT_EFFECTS_OUT=<folder>: also write the every-box-ticked profiles there, to try in SimHub.
        var outDir = Environment.GetEnvironmentVariable("TPT_EFFECTS_OUT");
        if (!string.IsNullOrEmpty(outDir)) SimHubProfiles.Write(everything, outDir);
    }

    /// <summary>Paths of fields in <paramref name="reference"/> that <paramref name="ours"/> lacks (objects compared recursively).</summary>
    static IEnumerable<string> Missing(JObject reference, JObject ours, string at)
    {
        foreach (var p in reference.Properties())
        {
            var o = ours[p.Name];
            if (o == null) { yield return at + p.Name; continue; }
            if (p.Value is JObject ro && o is JObject oo)
                foreach (var m in Missing(ro, oo, at + p.Name + ".")) yield return m;
        }
    }
}
