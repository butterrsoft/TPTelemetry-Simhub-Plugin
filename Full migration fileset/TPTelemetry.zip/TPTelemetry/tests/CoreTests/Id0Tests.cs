// Initial D Arcade Stage Zero v2.30 (ID0V230): the rows found in the game's own code (16 November 2026), fed a made-up race
// through the real engine: the player's slot chosen from the race, gating (countdown, pause, the finish line, the attract
// demo's replays), time left and its checkpoint extension, the gap to the rival, the event flags (the same bits as ID6), the
// drift angle and the common values. No recording yet.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;

static class Id0Tests
{
    sealed class Rec
    {
        public Dictionary<string, List<(double t, double v)>> Out;
        public Dictionary<string, List<(double t, double v)>> Car;
        public double At(string n, double t) => Out[n].First(x => x.t >= t).v;
        public double Max(string n, double a, double b) => Out[n].Where(x => x.t >= a && x.t < b).Max(x => x.v);
        public double CarAt(string n, double t) => Car[n].First(x => x.t >= t).v;
        public double CarMax(string n, double a, double b) => Car[n].Where(x => x.t >= a && x.t < b).Max(x => x.v);
    }

    // The race: no race until 1 s, countdown to 3 s (race clock -2000 to 0 ms), racing to 16 s with a pause from 6 to 7 s
    // (the clock stands still), your car over the line at 16 s (race state 5, your car 5), race over at 18 s.
    static Rec Feed(Action<bool, string> check, string path, int mySlot, int mode)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = "";
        prof.MaxSpeed = null; prof.MaxRevs = null;
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "ID0V230" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), "ID0V230 rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
        ps.Connected = true;
        var r = new Rec { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()),
                          Car = CommonValues.Outputs.ToDictionary(o => o.Name, o => new List<(double t, double v)>()) };
        void Set(string n, double v) { if (feeds.TryGetValue(n, out var f)) f.Value = v; }
        const double dt = 1 / 120.0;
        double clock = -2000, timeLeft = 60000;
        for (double t = 0; t < 20; t += dt)
        {
            double state = t < 1 ? double.NaN : t < 3 ? 3 : t < 16 ? 4 : t < 18 ? 5 : double.NaN;
            bool paused = t >= 6 && t < 7;
            if (state >= 3 && !paused && t < 16) clock += dt * 1000;
            if (state == 4 && !paused) timeLeft -= dt * 1000;
            double ext = t >= 12 && t < 12.5 ? 8000 - (t - 12) * 16000 : 0;   // a checkpoint at 12 s: 8 s added over 0.5 s
            if (ext > 0) timeLeft += dt * 16000;
            Set("race_state", state);
            Set("game_mode", mode | 0x200);
            Set("my_slot", double.IsNaN(state) ? double.NaN : mySlot);
            Set("cars", double.IsNaN(state) ? double.NaN : 2);
            Set("race_ms", double.IsNaN(state) ? double.NaN : Math.Round(clock));
            Set("time_left", double.IsNaN(state) ? double.NaN : Math.Round(timeLeft));
            Set("time_extension", double.IsNaN(state) ? double.NaN : Math.Max(0, Math.Round(ext)));
            Set("gap", double.IsNaN(state) ? double.NaN : (t < 10 ? -12.5 : 30));   // behind, then ahead from 10 s
            bool racing = state == 4;
            double kmh = racing ? Math.Min(120, (t - 3) * 15) : 0;
            if (t >= 9 && t < 9.3) kmh -= (t - 9) * 100;   // the wall hit at 9 s costs 30 km/h
            for (int k = 0; k < 2; k++)
            {
                bool mine = k == mySlot;
                Set("state_" + k, double.IsNaN(state) ? double.NaN : mine ? (t < 3 ? 3 : t < 16 ? 4 : 5) : 4);
                Set("speed_" + k, mine ? kmh : 77);   // the rival reads 77 km/h throughout
                Set("rpm_" + k, mine ? 3000 + kmh * 50 : 9999);
                Set("rpm_tacho_" + k, mine ? 3300 : 9999);
                Set("rpm_auto_" + k, mine ? 4000 : 9999);
                Set("gear_" + k, mine ? (t < 6 ? 2 : 3) : 5);
                Set("throttle_" + k, mine ? 1 : 0); Set("brake_" + k, 0);
                Set("steer_" + k, mine ? 0.25 : -1);
                Set("drift_angle_" + k, mine ? (t >= 11 && t < 11.5 ? 0.3 : 0) : 1.0);   // a drift at 11 s; the rival's angle must not show
                int ev = 0;
                if (mine && t >= 9 && t < 10.5) ev |= 0x8000;      // left wall from 9 s to 10.5 s
                if (mine && t >= 12 && t < 12.1) ev |= 0x20000;    // right wall, briefly
                if (mine && t >= 13 && t < 13.05) ev |= 0x800;     // a road joint
                if (!mine) ev = 0x80000;                           // the rival's own flags must not leak through
                Set("events_" + k, ev);
                Set("area_" + k, mine && t >= 14 && t < 14.5 ? 2 : (mine && t >= 15 && t < 15.5 ? 3 : 0));   // striped surface, then grass
            }
            // the force feedback packet: a ripple strip's vibration (level 5) from 14 s to 14.5 s, else a constant force
            bool strip = t >= 14 && t < 14.5;
            Set("ffb_raw", strip ? 0x85 | (70 << 8) | (5 << 16) : 0x84 | (1 << 8) | (16 << 16));
            Set("ffb_str", strip ? 5 : 16);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) r.Out[v.Def.Name].Add((t, v.Output));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) r.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
        }
        return r;
    }

    static double DriftOf(double deg, double kmh)
    {
        double x = Math.Clamp((Math.Abs(deg) - 5) / 45, 0, 1), s = Math.Clamp((kmh - 20) / 80, 0, 1);
        return (1 - Math.Pow(1 - x, 2)) * Math.Sqrt(s);
    }

    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "ID0V230");
        if (gamePackDir == null || !File.Exists(path)) return;
        foreach (int slot in new[] { 0, 1 })
        {
            var r = Feed(check, path, slot, 3);   // story
            string s = $"ID0V230 (slot {slot}): ";
            check(r.At("in_race", 2) == 0 && r.At("in_race", 5) == 1 && r.At("in_race", 17) == 0 && r.At("in_race", 0.5) == 0,
                  s + "in_race from GO to your finish line");
            check(r.Max("in_race", 6.3, 6.9) == 0 && r.At("in_race", 7.5) == 1, s + "in_race off while paused (the race clock stands still)");
            check(r.CarMax("speed", 6.3, 6.9) == 0 && r.CarAt("speed", 7.5) > 0, s + "Car_speed 0 while paused");
            check(r.At("speed", 0.5) == 0 && r.At("speed", 19) == 0 && Math.Abs(r.At("speed", 8) - 75) < 0.2, s + $"speed is your car's and 0 outside a race: {r.At("speed", 8)}");
            check(r.At("gear", 8) == 3 && r.At("rpm_tacho", 8) == 3300 && r.At("throttle", 8) == 1 && r.At("steer", 8) == -0.25, s + "gear, tacho, throttle and steering (+ right) from your slot");
            check(Math.Abs(r.At("rpm", 8) - (3000 + 75 * 50)) < 0.01, s + $"rpm from the manual gearbox's value: {r.At("rpm", 8)}");
            check(r.Max("car_contact", 3, 16) == 0, s + "the other car's flags don't show as yours");
            check(r.Max("hit", 9, 9.3) == 1 && r.Max("hit", 9.4, 11.9) == 0 && r.Max("hit", 12, 12.3) == 1 && r.Max("hit", 3, 8.99) == 0,
                  s + "hit for 0.3 s at the start of each contact, not through a long scrape");
            check(r.At("wall_contact", 10) == -1 && r.At("wall_contact", 9.1) == 0, s + "wall_contact -1 after 0.3 s on the left wall");
            check(r.CarMax("impact_side", 9, 9.3) == -1 && r.CarMax("impact_side", 12, 12.3) == 1, s + "Car_impact_side left then right");
            double imp = r.CarMax("impact", 9, 9.3);
            check(imp > 0.6 && imp <= 1, s + $"Car_impact sized by the km/h lost: {imp:0.00}");
            check(r.Max("road_joint", 13, 13.1) == 1 && r.CarMax("road_bump", 13, 13.2) > 0.5, s + "road joint and Car_road_bump");
            check(r.Max("rumble_strip", 14, 14.5) == 1 && r.CarMax("rumble_strip", 14, 14.5) == 1 && r.Max("rumble_strip", 13, 13.9) == 0 && r.Max("rumble_strip", 14.9, 16) == 0,
                  s + "ripple strip from the game's vibration at level 5");
            check(r.Max("grass", 15, 15.5) == 1 && r.CarMax("off_road", 15, 15.5) == 1 && r.CarMax("off_road", 14, 14.9) == 0, s + "grass feeds Car_off_road");
            double ang = r.At("drift_angle", 11.2), drift = r.CarAt("drift", 11.2);
            check(Math.Abs(ang + 0.3 * 57.29578) < 0.01 && Math.Abs(drift - DriftOf(0.3 * 57.29578, 120)) < 0.001 && r.At("drift_angle", 10) == 0,
                  s + $"drift angle in degrees (0.3 rad = -17.2) and Car_drift with ID6's weighting: {ang:0.00} {drift:0.000}");
            check(Math.Abs(r.At("race_clock", 2) + 1) < 0.02 && Math.Abs(r.At("race_clock", 5) - 2) < 0.02 && r.At("race_clock", 0.5) == 0,
                  s + $"race_clock in seconds from GO, negative in the countdown: {r.At("race_clock", 2):0.00} {r.At("race_clock", 5):0.00}");
            check(Math.Abs(r.At("time_left", 5) - 58) < 0.05 && r.At("time_left", 0.5) == 0, s + $"time_left in seconds: {r.At("time_left", 5):0.00}");
            check(r.Max("checkpoint", 12, 14) == 1 && r.Max("checkpoint", 3, 11.9) == 0, s + "checkpoint as the time is extended");
            check(r.At("gap", 8) == -12.5 && r.At("leader", 8) == 0 && r.At("leader", 11) == 1, s + "gap and leader");
            check(r.At("lampleader", 8) == 0 && r.At("lampleader", 11) == 1 && r.At("lampleader", 0.5) == 0 && r.Max("lampcheckpoint", 12, 14) == 1 && r.Max("lampcheckpoint", 3, 11.9) == 0,
                  s + "leader lamp while ahead, checkpoint lamp at the extension");
            check(r.CarAt("cornering", 8) < -0.5 && r.CarAt("cornering", 8) >= -1, s + $"Car_cornering from the steering (the game's 0.25, left, at 75 km/h): {r.CarAt("cornering", 8):0.00}");
        }
        var ta = Feed(check, path, 0, 2);   // time attack: no rival, whatever the second slot holds
        check(ta.Max("gap", 0, 20) == 0 && ta.Max("leader", 0, 20) == 0 && ta.At("in_race", 5) == 1, "ID0V230: no gap or leader in time attack");
        check(ta.At("lampleader", 5) == 1 && ta.At("lampleader", 2) == 0, "ID0V230: the leader lamp from GO in time attack (alone)");
        var demo = Feed(check, path, 0, 7);   // the attract demo's replay
        check(demo.Max("in_race", 0, 20) == 0 && demo.Max("speed", 0, 20) == 0 && demo.CarMax("speed", 0, 20) == 0 && demo.CarMax("impact", 0, 20) == 0,
              "ID0V230: nothing in the attract demo's replays (game mode 7)");
        var shipped = ProfileStore.ReadProfile(path);
        check(shipped.MaxSpeed == 220 && shipped.MaxRevs == 8140, $"ID0V230 ships with Max speed 220 and Max revs 8140: {shipped.MaxSpeed} {shipped.MaxRevs}");
        Recordings(check, path);
    }

    // Alexis's recordings of 16 November 2026 (claude/ID0V230-capture-20261116.md): ID0-1, the story's intro race (tutorial, game
    // mode 16) against the computer in an AE86 Trueno, manual, with two how-to demos that stop the race clock; ID0-2, an Irohazaka
    // downhill time attack in a Savanna RX-7, automatic, FFB on. USB capture in both. Times below are TT (the race clock).
    static Wmmt5ReplayTests.Replay Replay(Action<bool, string> check, string path, string fixture, out Func<double, double> at, out List<(double t, double steer)> wheel)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = "";
        prof.MaxSpeed = null; prof.MaxRevs = null;   // raw km/h and revs
        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "ID0V230" });
        var ps = eng.Profiles[0];
        ps.Connected = true;
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(kv.Key));
        // rpm_auto came after these recordings; the cheat table's two reads weren't recorded usefully
        check(cols.All(c => c.Value >= 0 || (c.Key.StartsWith("rpm_auto_") && !fixture.Contains("204240")) || c.Key == "menu_timer" || c.Key == "hud_meter"),
              "ID0V230: the recording has every memory row: " + string.Join(", ", cols.Where(c => c.Value < 0).Select(c => c.Key)));
        int tc = Col("time_s"), mc = Col("marker"), ms = Col("race_ms"), rs = Col("race_state"), ws = Col("FFB_steer");
        var rp = new Wmmt5ReplayTests.Replay { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()) };
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        var clock = new List<(double t, double ms)>();
        wheel = new List<(double t, double steer)>();
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            if (r[mc] != "") rp.Marks.Add(t);
            foreach (var kv in feeds) kv.Value.Value = Num(r, cols[kv.Key]);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            if (Num(r, rs) == 4) clock.Add((t, Num(r, ms)));
            wheel.Add((t, Num(r, ws)));
            rp.End = t;
        }
        at = tt => clock.First(c => c.ms >= tt * 1000).t;   // the recording time at TT tt (seconds)
        return rp;
    }

    static double Corr(IEnumerable<(double a, double b)> xs)
    {
        var l = xs.Where(x => !double.IsNaN(x.a) && !double.IsNaN(x.b)).ToList();
        double ma = l.Average(x => x.a), mb = l.Average(x => x.b);
        double c = l.Sum(x => (x.a - ma) * (x.b - mb));
        return c / Math.Sqrt(l.Sum(x => (x.a - ma) * (x.a - ma)) * l.Sum(x => (x.b - mb) * (x.b - mb)));
    }

    static void Recordings(Action<bool, string> check, string path)
    {
        // ID0-1: Trueno, manual, tutorial
        var r = Replay(check, path, "id0v230-20261116-144831.csv.gz", out var T, out var wheel);
        string s = "ID0V230 ID0-1: ";
        double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Max(x => x.v);
        check(r.Marks.Count == 20 && r.At("game_mode", T(10)) == 16, s + $"20 marks, game mode 16 (tutorial): {r.Marks.Count} {r.At("game_mode", T(10))}");
        check(r.Max("in_race", 0, T(0) - 0.05) == 0 && r.At("in_race", T(1)) == 1 && r.At("in_race", T(100)) == 1 && r.Max("in_race", T(202.9) + 0.15, r.End) == 0,
              s + "in_race from GO to the finish line (TT 3:22.98)");
        check(r.Max("in_race", 118, 135.9) == 0 && r.Max("in_race", 187, 205.6) == 0 && CarMax("speed", 118, 135.9) == 0,
              s + "nothing while the how-to demos stop the race clock (TT 0:02.05 and 0:52.13)");
        check(r.Max("race_clock", 105.5, 112.3) == 0 && r.Min("race_clock", 105.5, 112.3) == 0 && Math.Abs(r.At("race_clock", 113.1) + 2.3) < 0.1,
              s + "race_clock 0 through the intro, -3 s from the countdown");
        foreach (var (tt, kmh) in new[] { (30.9, 160.6), (110.9, 167.4), (186.7, 203.0) })
            check(Math.Abs(r.At("speed", T(tt)) - kmh) < 1, s + $"speed at TT {tt}: {r.At("speed", T(tt)):0.0} (Alexis read {Math.Floor(kmh)})");
        check(r.Max("rpm", T(8.2), T(10)) <= 8141 && r.Min("rpm", T(8.2), T(10)) > 7800, s + "rpm bounces under 8,140 on the limiter (Alexis: 7.7k to 7.9k)");
        check(Corr(r.Out["steer"].Zip(wheel, (a, b) => (a.v, b.steer)).Where((x, i) => r.Out["in_race"][i].v == 1)) > 0.9, s + "steer follows the wheel, + right");
        check(r.Max("drift_angle", T(16.1), T(18.6)) > 25 && r.Min("drift_angle", T(11.1), T(11.9)) < -15, s + "drift angle + in the right turn at TT 0:16.10, - in the left at 0:11.12");
        foreach (double tt in new[] { 61.93, 112.95, 158.82 })
            check(r.Max("checkpoint", T(tt - 0.1), T(tt + 0.3)) == 1 && r.At("checkpoint", T(tt - 0.3)) == 0, s + $"checkpoint at TT {tt}");
        check(r.At("leader", T(30)) == 0 && r.At("leader", T(45)) == 1 && r.At("leader", T(55)) == 0 && r.At("leader", T(100)) == 1 && r.At("leader", T(202)) == 1,
              s + "leader: passing at TT 0:38.86, passed at 0:50.41, passing again at 0:59.95");
        check(r.Max("landing", T(88.8), T(89.3)) == 1 && r.Max("landing", T(152.7), T(153.2)) == 1 && r.Max("landing", T(1), T(88)) == 0, s + "the two jumps' landings");
        foreach (var (a, b) in new[] { (7.0, 8.0), (113.8, 114.5), (137.4, 138.2), (141.6, 142.0), (143.2, 144.6) })
            check(r.Max("rumble_strip", T(a), T(b)) == 1, s + $"ripple strip at TT {a}");
        check(r.Max("rumble_strip", T(20), T(100)) == 0, s + "no ripple strip where there's none (TT 0:20 to 1:40)");
        check(r.At("lampleader", T(45)) == 1 && r.At("lampleader", T(55)) == 0 && r.Max("lampcheckpoint", T(61.8), T(62.3)) == 1,
              s + "leader lamp follows the places, checkpoint lamp at TT 1:01.93");
        check(CarMax("cornering", T(16.1), T(18.6)) > 0.3 && r.Car["cornering"].Where(x => x.t >= T(11.1) && x.t <= T(11.9)).Min(x => x.v) < -0.3,
              s + "Car_cornering + in the right turn at TT 0:16.10, - in the left at 0:11.12");
        check(r.Max("hit", T(3.8), T(4.2)) == 1 && CarMax("impact_side", T(5.4), T(5.8)) == 1 && r.Car["impact_side"].Where(x => x.t >= T(16.0) && x.t <= T(16.4)).Min(x => x.v) == -1,
              s + "the bump at TT 0:03.84, the right wall at 0:05.44, the left wall at 0:16.05");

        // ID0-2: RX-7, automatic, Irohazaka time attack
        r = Replay(check, path, "id0v230-20261116-150104.csv.gz", out T, out wheel);
        s = "ID0V230 ID0-2: ";
        check(r.Marks.Count == 10 && r.At("game_mode", T(10)) == 2, s + "10 marks, game mode 2 (time attack)");
        check(r.Max("gap", 0, r.End) == 0 && r.Max("leader", 0, r.End) == 0, s + "no gap or leader in time attack (no rival)");
        check(r.At("in_race", T(1)) == 1 && r.Max("in_race", T(214.0) + 0.15, r.End) == 0, s + "in_race to the finish line (TT 3:34.10)");
        foreach (var (tt, kmh) in new[] { (9.4, 113.1), (65.6, 105.0) })
            check(Math.Abs(r.At("speed", T(tt)) - kmh) < 1, s + $"speed at TT {tt}: {r.At("speed", T(tt)):0.0}");
        foreach (double tt in new[] { 48.77, 106.62, 164.32 })
            check(r.Max("checkpoint", T(tt - 0.1), T(tt + 0.3)) == 1, s + $"checkpoint at TT {tt}");
        check(r.Max("landing", T(128.9), T(129.3)) == 1 && r.Max("landing", T(150.1), T(150.5)) == 1, s + "the two kerb drops' landings");
        check(r.Max("rumble_strip", 0, r.End) == 0, s + "Irohazaka's painted strips aren't ripple strips (the game doesn't shake for them)");
        check(Corr(r.Out["steer"].Zip(wheel, (a, b) => (a.v, b.steer)).Where((x, i) => r.Out["in_race"][i].v == 1)) > 0.9, s + "steer follows the wheel, + right");
        check(r.Max("drift_angle", T(28.5), T(31.2)) > 45 && r.Min("drift_angle", T(36.8), T(38.4)) < -35, s + "drift angle + in the right hairpin at TT 0:28.46, - in the left at 0:36.77");
        double Side(double a, double b) { var v = r.Car["impact_side"].Where(x => x.t >= T(a) && x.t <= T(b)).Select(x => x.v); return v.Max() == 1 ? 1 : (v.Min() == -1 ? -1 : 0); }
        check(Side(20.5, 20.9) == 1 && Side(29.7, 30.1) == -1 && Side(52.6, 53.0) == -1 && Side(74.3, 74.7) == 1 && Side(105.2, 105.6) == 1,
              s + "guard rail and wall sides Alexis confirmed (TT 0:20.59 right, 0:29.77 left, 0:52.67 left, 1:14.35 right, 1:45.30 right)");

        // ID0-3 (20:42:40): story, Akina Lake, Nissan Silvia, automatic, to the first lap's checkpoint; her rev counter readings
        r = Replay(check, path, "id0v230-20261116-204240.csv.gz", out T, out wheel);
        s = "ID0V230 ID0-3: ";
        check(r.Marks.Count == 1 && r.At("game_mode", T(10)) == 3 && r.At("in_race", T(10)) == 1, s + "story mode (3), racing");
        foreach (var (tt, revs) in new[] { (9.84, 5800.0), (28.93, 5450.0), (65.10, 6200.0), (74.10, 6075.0), (92.14, 5950.0) })
            check(Math.Abs(r.At("rpm", T(tt)) - revs) < 60, s + $"the automatic's rev counter at TT {tt}: {r.At("rpm", T(tt)):0} (Alexis read {revs})");
        check(r.Max("checkpoint", T(93.0), T(93.4)) == 1, s + "the checkpoint at TT 1:33.14 (her mark 1:33.32)");
    }
}
