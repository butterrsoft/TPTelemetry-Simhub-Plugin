using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.TeknoParrot;
using Replay = Wmmt5ReplayTests.Replay;

/// <summary>
/// Replays Alexis's WMMT3DX+ recordings of 11 November 2026 through the WMMT3DXP profile's rows read from the
/// game's own variables. The fixtures hold each memory row in the game's own units (the recorder kept the rows'
/// outputs, so they were converted back: speed / 0.0036, revs x 2 pi / 60 at the then Max revs 8999, slip angle in
/// 65536ths, odometers in mm, steering flipped; `load` from TeknoParrot's spring slot, as the game works the spring
/// out from it).
///  * 18:36: story mode, C class, Hakone inbound, manual. Opening shot 33.7 to 43.4 s (not to have effects), countdown
///    from 43.6 s (the driver's view), GO 47.68 s, finish line 263.76 s. Right-hander at 75 s, left hairpin at 81 s.
///    Crests at 50.5 s and 218.9 s (light, not airborne, per Alexis), the jump at 252.3 s (rear in the air).
///    Tacho readings (Alexis): 7.6k at 48.33 s, 6.8k at 147.0 s, 7.5k at 252.8 s.
///  * 20:15: traffic; road joints (her first eight marks), then traffic hits and a truck shunting the car from 50 s.
///    14 car contacts by the game's own flag.
/// </summary>
static class Wmmt3GameTests
{
    internal static Replay Run(Action<bool, string> check, string path, string fixture, string game = "WMMT3DXP")
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = "";
        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);

        var tp = new double[TpChannels.Count];
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            TpSource = a => Array.Copy(tp, a, a.Length),
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = game });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), game + " rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));

        var rp = new Replay { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()) };
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        ps.Connected = true;
        int tc = Col("time_s"), mc = Col("marker");
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(kv.Key));
        // raw rows added after these recordings (notes starting "Raw") aren't in them
        var raw = new HashSet<string>(prof.Variables.Where(v => (v.Notes ?? "").StartsWith("Raw")).Select(v => v.Name)) { "speed2" };
        check(cols.Where(c => !raw.Contains(c.Key)).All(c => c.Value >= 0),
              "the fixture has every memory row: " + string.Join(", ", cols.Where(c => c.Value < 0 && !raw.Contains(c.Key)).Select(c => c.Key)));
        var slots = Enumerable.Range(0, TpChannels.SlotCount).Select(i => Col("tp_jvs" + i)).ToArray();
        int conn = Col("tp_connected");
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            if (r[mc] != "") rp.Marks.Add(t);
            foreach (var kv in feeds) kv.Value.Value = Num(r, cols[kv.Key]);
            for (int i = 0; i < slots.Length; i++) tp[i] = Num(r, slots[i]);
            tp[TpChannels.Connected] = Num(r, conn);
            eng.TpSource(ps.Ctx.Tp);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            rp.End = t;
        }
        return rp;
    }

    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "WMMT3DXP");
        if (gamePackDir == null || !File.Exists(path)) return;
        Story(check, Run(check, path, "wmmt3dxp-20261111-183637.csv.gz"));
        Traffic(check, Run(check, path, "wmmt3dxp-20261111-201500.csv.gz"));
    }

    internal static double CarMax(Replay r, string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(double.NaN).Max();
    internal static double CarMin(Replay r, string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(double.NaN).Min();
    internal static string F(double v) => v.ToString("0.00", CultureInfo.InvariantCulture);

    static void Story(Action<bool, string> check, Replay r)
    {
        // effects from the countdown (driver's view) to the finish line; none in the opening shot
        var on = r.Car["in_race"].Where(x => x.v > 0).Select(x => x.t).ToList();
        check(on.Count > 0 && on.First() > 43.55 && on.First() < 43.75 && on.Last() > 263.6 && on.Last() < 263.8,
              $"WMMT3 18:36: Car_in_race from the countdown to the line ({F(on.FirstOrDefault())} to {F(on.LastOrDefault())}; countdown 43.60, line 263.76)");
        check(CarMax(r, "in_race", 33.0, 43.5) == 0, "WMMT3 18:36: no effects in the opening shot (33.7 to 43.4 s, including its moment of race state 1)");
        check(CarMin(r, "in_race", 43.8, 263.6) == 1, "WMMT3 18:36: Car_in_race stays on through the countdown and the race");

        // the dial: Alexis's readings
        foreach (var (t, dial) in new[] { (48.33, 7600.0), (147.0, 6800.0), (252.8, 7500.0) })
        {
            double v = r.At("tacho", t);
            check(Math.Abs(v - dial) < 150, $"WMMT3 18:36: tacho {v:0} at {F(t)} s against Alexis's {dial:0} on the dial");
        }

        // signs: right-hander at 75 s, left hairpin at 81 s
        check(r.At("drift_angle", 75.06) > 5 && r.At("steer", 75.06) > 0.5, "WMMT3 18:36: right-hand slide and steering at 75.06 s read +");
        check(r.At("drift_angle", 81.48) < -5 && r.At("steer", 81.48) < -0.5, "WMMT3 18:36: left hairpin at 81.48 s reads -");

        // her front right nudging the rival, twice
        foreach (var t in new[] { 55.33, 129.74 })
            check(CarMax(r, "impact_side", t, t + 0.3) == 1 && CarMin(r, "impact_side", t, t + 0.3) == 0,
                  $"WMMT3 18:36: rival nudge at {F(t)} s on the front right reads right");

        // the jump (rear in the air) is airborne; the crests only light
        check(CarMax(r, "airborne", 252.3, 252.95) == 1, "WMMT3 18:36: Car_airborne 1 at the jump (252.3 s): " + F(CarMax(r, "airborne", 252.3, 252.95)));
        foreach (var c in new[] { 50.4, 218.8 })
        {
            double m = CarMax(r, "airborne", c, c + 0.5);
            check(m > 0.2 && m < 0.5, $"WMMT3 18:36: crest at {F(c)} s light, not airborne: Car_airborne {F(m)}");
        }
        double elsewhere = r.Car["airborne"].Where(x => x.v >= 1 && (x.t < 252.3 || x.t > 253.0)).Select(x => x.t).DefaultIfEmpty(-1).First();
        check(elsewhere < 0, "WMMT3 18:36: no other full airborne: " + F(elsewhere));
    }

    static void Traffic(Action<bool, string> check, Replay r)
    {
        // the game's contact flag: every car contact gives an impact, the hard ones 1
        var contacts = new[] { 19.30, 19.81, 23.93, 25.45, 30.36, 30.73, 34.68, 40.11, 43.96, 50.08, 52.86, 62.00, 62.53 };
        var miss = contacts.Where(t => CarMax(r, "impact", t, t + 0.2) < 0.2).ToList();
        check(miss.Count == 0, "WMMT3 20:15: Car_impact at every car contact (missed " + string.Join(", ", miss.Select(F)) + ")");
        check(CarMax(r, "impact", 23.9, 24.1) == 1 && CarMax(r, "impact", 61.95, 62.2) == 1 && CarMax(r, "impact", 50.05, 50.3) == 1,
              "WMMT3 20:15: the two crashes into traffic and the truck's shunt read 1");
        // sides (Alexis): front right at 19.30 and 25.45, a truck along the left at 40.11
        foreach (var (t, side) in new[] { (19.30, 1.0), (25.45, 1.0), (40.11, -1.0) })
        {
            double s = r.Car["impact_side"].Where(x => x.t >= t && x.t <= t + 0.2).Select(x => x.v).FirstOrDefault(v => v != 0);
            check(s == side, $"WMMT3 20:15: car hit at {F(t)} s on the {(side > 0 ? "right" : "left")}: Car_impact_side {F(s)}");
        }
        check(CarMax(r, "impact", 19.8, 20.2) < 0.4, "WMMT3 20:15: a light rub reads light: " + F(CarMax(r, "impact", 19.8, 20.2)));
        // road joints (her first eight marks) aren't hits
        check(CarMax(r, "impact", 9.0, 14.2) == 0 && CarMax(r, "road_bump", 9.0, 14.2) > 0.5, "WMMT3 20:15: joints at 9 to 14 s are road bumps, not hits");
        check(CarMin(r, "in_race", 0.1, r.End) == 1, "WMMT3 20:15: in race throughout (countdown, then racing)");
    }
}
