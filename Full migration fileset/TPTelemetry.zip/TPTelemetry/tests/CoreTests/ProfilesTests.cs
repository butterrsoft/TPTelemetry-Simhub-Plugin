using System;
using System.IO;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.TeknoParrot;

/// Feeds known TeknoParrot values to each game pack profile and checks the decoding.
static class ProfilesTests
{
    public static void Run(Action<bool, string> check, Action<double, double, double, string> near, string pack)
    {
        if (pack == null || !Directory.Exists(pack)) return;
        var tp = new double[TpChannels.Count];
        TelemetryEngine eng = null; ProfileState ps = null; double t = 0;
        void Load(string prefix)
        {
            var prof = ProfileStore.ReadProfile(PackFiles.Find(pack, prefix));
            eng = new TelemetryEngine { TpSource = a => Array.Copy(tp, a, a.Length), OutputSource = n => n == "LampStart" ? 1 : double.NaN };
            eng.Load(new[] { prof }, new PluginSettings { ActiveGame = prefix });
            ps = eng.Profiles[0];
            check(ps.Vars.All(v => !v.HasConfigError), $"{prefix} loads: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
        }
        double Run1(params (int slot, double v)[] set)
        {
            for (int i = 0; i < 16; i++) tp[i] = 0;
            tp[TpChannels.Connected] = 1;
            foreach (var (slot, v) in set) tp[slot] = v;
            eng.TpSource(ps.Ctx.Tp);
            TelemetryEngine.EvaluateTick(ps, t += 1.0 / 120);
            return 0;
        }
        double V(string n) => ps.Vars.Single(v => v.Def.Name == n).Output;

        Load("SR3");
        Run1((2, 10)); near(V("force"), 6 / 15.0, 1e-9, "SR3: 10 = +6/15");
        Run1((2, 20)); near(V("force"), -11 / 15.0, 1e-9, "SR3: 20 = -11/15");
        Run1((2, 0)); near(V("force"), 0, 0, "SR3: 0 = none");

        // SR3 now has a process (its lamps read memory): TeknoParrot rows must still run before the game is found
        {
            var prof = ProfileStore.ReadProfile(PackFiles.Find(pack, "SR3"));
            check(prof.ProcessName == "Rally.exe", "SR3: process set for its lamp rows, got " + prof.ProcessName);
            var e2 = new TelemetryEngine { TpSource = a => Array.Copy(tp, a, a.Length), ProcessOpener = _ => null };
            e2.Load(new[] { prof }, new PluginSettings { ActiveGame = "SR3" });
            var p2 = e2.Profiles[0];
            for (int i = 0; i < 16; i++) tp[i] = 0;
            tp[TpChannels.Connected] = 1; tp[2] = 10;
            e2.TryAttach(p2, 0);
            for (int i = 0; i < 3; i++) { e2.TpSource(p2.Ctx.Tp); e2.Tick(p2); }
            check(!p2.Connected && p2.Status.StartsWith("Waiting for Rally.exe"), "SR3: waiting for the game: " + p2.Status);
            near(p2.Vars.Single(v => v.Def.Name == "force").Output, 6 / 15.0, 1e-9, "SR3: TeknoParrot force still decoded while waiting for the game");
            var raw = p2.Vars.Single(v => v.Def.Name == "ob_startbutton");
            check(double.IsNaN(raw.Output) && raw.Status.StartsWith("not attached"), "SR3: memory rows blank while waiting: " + raw.Status);
        }
        Load("ID6");
        Run1();
        // 8 November 2026: ID6's lamps read game memory for v1.0 and v1.2 (OutputBlaster's addresses for each), not out_LampStart.
        check(!ps.Vars.Single(v => v.Def.Name == "lampstart").Def.Formula.Contains("out_"), "ID6: lamp rows read memory, not OutputBlaster");

        foreach (var g in new[] { "ID6", "ID7", "ID8" })
        {
            Load(g);
            Run1((2, 0x04017F)); near(V("force"), 0x7F / 127.0, 1e-9, g + ": cmd 4, dir 1, 0x7F = +1");
            Run1((2, 0x040040)); near(V("force"), -(128 - 0x40) / 127.0, 1e-9, g + ": cmd 4, dir 0, 0x40 = -0.5");
            Run1((2, 0x060050)); near(V("spring"), 0x50 / 127.0, 1e-9, g + ": cmd 6 sets the spring");
            near(V("force"), -(128 - 0x40) / 127.0, 1e-9, g + ": force held while another command arrives");
            Run1((2, 0x050A60)); near(V("vibration"), 0x60 / 127.0, 1e-9, g + ": cmd 5 vibration");
            near(V("spring"), 0x50 / 127.0, 1e-9, g + ": spring held");
            Run1((2, 0x000001)); near(V("spring"), 1, 1e-9, g + ": cmd 0 value 1 = full spring");
        }

        Load("FORDRACING");
        Run1((2, -65510)); near(V("force"), 5 / 9.0, 1e-9, "Ford: -65510 = +5/9");
        Run1((2, 12)); near(V("force"), -4 / 9.0, 1e-9, "Ford: 12 = -4/9");
        Run1((2, 1)); near(V("force"), -1, 1e-9, "Ford: clamped to -1");

        Load("ARCTICTHUNDER");
        Run1((7, 128), (8, 0x90)); near(V("vibration"), 128 / 255.0, 1e-9, "Arctic: vibration"); near(V("force"), -16 / 127.0, 1e-9, "Arctic: 0x90 = -16/127");
        Run1((7, 255), (8, 0x70)); near(V("vibration"), 0, 0, "Arctic: 255 = vibration off"); near(V("force"), 16 / 127.0, 1e-9, "Arctic: 0x70 = +16/127");

        Load("DEADHEAT");
        Run1((6, 63), (9, 0x20)); near(V("force"), 0x20 / 63.0, 1e-9, "Dead Heat: reflect 0x20 = +"); near(V("grip_loss"), 0, 1e-9, "Dead Heat: full spring");
        Run1((6, 63), (9, 0xF0)); near(V("force"), -(255 - 0xF0) / 63.0, 1e-9, "Dead Heat: reflect 0xF0 = -15/63");
        Run1((6, 63), (8, -21), (9, 0x20)); near(V("force"), 21 / 63.0, 1e-9, "Dead Heat: centre offset wins over reflect");

        Load("D1GP");
        Run1((6, 100), (7, 2)); near(V("force"), 0.5, 1e-9, "D1GP: 100 = 0.5"); near(V("vibration_on"), 1, 0, "D1GP: effect 2 = vibration");
        Run1((6, -1000)); near(V("force"), -1, 1e-9, "D1GP: clamped");

        Load("SRG");
        Run1((6, 23000), (7, 750)); near(V("force"), 0.5, 1e-9, "SRG: 23000 = 0.5"); near(V("shake"), 0.5, 1e-9, "SRG: shake 750 = 0.5");

        Load("WMMT3DXP");
        Run1((6, 63), (8, -20)); near(V("tp_force"), 20 / 63.0, 1e-9, "WMMT3: centre offset -20 = +0.32"); near(V("grip_loss"), 0, 1e-9, "WMMT3: full spring, no grip loss");
        Run1((6, 45), (9, 63)); near(V("tp_force"), 1, 1e-9, "WMMT3: reflect 63 = +1 when no centre offset"); near(V("grip_loss"), (1 - 45 / 63.0) / 0.3, 1e-9, "WMMT3: spring 45 = grip loss 0.95");
        near(V("impact_side"), 1, 0, "WMMT3: full kick reads as an impact");
        tp[TpChannels.Connected] = 0; eng.TpSource(ps.Ctx.Tp); TelemetryEngine.EvaluateTick(ps, t += 0.01);
        check(ps.Vars.Single(v => v.Def.Name == "tp_spring").Status == TelemetryEngine.NoTp, "WMMT3: rows say when TeknoParrot data is missing");
    }
}
