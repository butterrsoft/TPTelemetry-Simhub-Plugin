using System;
using System.IO;
using System.Linq;
using System.Threading;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.Ffb;

static class RecorderTests
{
    public static void Run(Action<bool, string> check)
    {
        var dir = Path.Combine(Path.GetTempPath(), "tpt-rec-" + Guid.NewGuid().ToString("N"));
        var dummy = ProfileStore.ReadProfile("../../profiles/DUMMY.json");
        var eng = new TelemetryEngine();
        double fakeForce = 0.25;
        eng.FfbSource = a => { for (int i = 0; i < a.Length; i++) a[i] = double.NaN; a[FfbChannels.Force] = fakeForce; a[FfbChannels.Connected] = 1; };
        eng.Load(new[] { dummy }, new PluginSettings { ActiveGame = "DUMMY", PollRateHz = 100 });
        eng.Start();
        Thread.Sleep(300);
        var rec = eng.StartRecording(dir);
        check(rec.GamePrefix == "DUMMY" && Path.GetFileName(rec.Path).EndsWith("_DUMMY.csv"), "recording names the selected game: " + Path.GetFileName(rec.Path));
        Thread.Sleep(300);
        check(eng.Mark() == 1, "first mark is number 1");
        Thread.Sleep(200);
        // an edit mid-recording (re-applied profiles) must not misalign columns
        eng.Load(new[] { dummy }, new PluginSettings { ActiveGame = "DUMMY", PollRateHz = 100 });
        Thread.Sleep(200);
        eng.Mark(); Thread.Sleep(200);
        eng.StopRecording();
        eng.Dispose();
        check(eng.Mark() == 0, "Mark does nothing when not recording");

        var lines = File.ReadAllLines(rec.Path);
        var head = lines[0].Split(',');
        int Col(string n) => Array.IndexOf(head, n);
        check(head[0] == "time_s" && head[1] == "marker" && Col("DUMMY_REPLACE_speed") > 0 && Col("FFB_force") > 0 && Col("FFB_steer") > 0,
              "header has time, marker, the game's properties and FFB channels");
        var rows = lines.Skip(1).Select(l => l.Split(',')).ToList();
        check(rows.All(r => r.Length == head.Length), "every row has every column");
        check(rows.Count > 50 && rows.Count < 120, $"about 100 rows a second for ~0.9 s: {rows.Count}");
        var marks = rows.Select(r => r[1]).Where(m => m != "").ToList();
        check(marks.SequenceEqual(new[] { "1", "2" }), "markers 1 and 2 each on one row: " + string.Join(",", marks));
        var speeds = rows.Select(r => r[Col("DUMMY_REPLACE_speed")]).Where(v => v != "").Select(v => double.Parse(v, System.Globalization.CultureInfo.InvariantCulture)).ToList();
        check(speeds.Count > rows.Count - 3 && speeds.Distinct().Count() > 10, "speed recorded and changing, including after the re-apply");
        check(rows.All(r => r[Col("FFB_force")] == "0.25") && rows.All(r => r[Col("FFB_spring")] == ""), "FFB values recorded; missing ones left empty");
        check(CommonValues.Outputs.All(o => Col("Car_" + o.Name) > 0) && CommonValues.Lamps.All(o => Col("Lamp_" + o.Name) > 0) && head.Last() == "Lamp_" + CommonValues.Lamps.Last().Name,
              "the common values and lamps SimHub got are recorded too (Car_ then Lamp_ columns, last)");
        check(rows.Skip(5).All(r => r[Col("Car_in_race")] == "1"), "Car_in_race recorded (1: the dummy game has no in-race row)");
        var times = rows.Select(r => double.Parse(r[0], System.Globalization.CultureInfo.InvariantCulture)).ToList();
        // never backwards; two rows can share a time when the poll thread catches up after a stall
        check(times.Zip(times.Skip(1), (a, b) => b >= a).All(x => x) && times.Zip(times.Skip(1), (a, b) => b > a).Count(x => x) > times.Count * 0.9, "time increases");
        try { Directory.Delete(dir, true); } catch { }
    }
}
