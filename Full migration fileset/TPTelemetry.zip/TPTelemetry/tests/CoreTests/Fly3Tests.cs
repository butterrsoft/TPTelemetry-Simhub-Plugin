// Initial D Arcade Stage Ver. 3 in Flycast (FLYINITD3): Alexis's recordings of 17 November 2026, replayed through the pack's
// profile (Max speed 205, Max revs 9000). 16:57 (a whole story race, three
// laps, from the menus to the finish line and back to the menus), replayed through the pack's profile. The fixture holds
// the memory rows in the game's own units (m/s, 1/6000 s clocks, lap less one, steering + left), every second sample
// (60 a second), with her marks (GO, the two lap lines, the finish) and the wheel over USB. 19:33: drifts both ways
// on Akagi, with the heading and travel rows.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;

static class Fly3Tests
{
    public static void Run(Action<bool, string> check, string pack)
    {
        if (string.IsNullOrEmpty(pack)) return;
        var path = Directory.GetFiles(pack, "FLYINITD3.json", SearchOption.AllDirectories).FirstOrDefault();
        if (path == null) return;
        Race(check, path);
        Drifts(check, path);
    }

    sealed class R
    {
        public Dictionary<string, List<(double t, double v)>> Out, Car;
        public List<double> Marks = new List<double>();
        public List<(double steer, double thr)> Usb = new List<(double steer, double thr)>();
    }

    static R Replay(Action<bool, string> check, string path, string fixture, string s)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = "";
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "FLYINITD3" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), s + "rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));
        ps.Connected = true;
        var r = new R { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()),
                        Car = CommonValues.Outputs.ToDictionary(o => o.Name, o => new List<(double t, double v)>()) };
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            var head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null)
            {
                var f = line.Split(',');
                double P(int i) => f[i].Length == 0 ? double.NaN : double.Parse(f[i], CultureInfo.InvariantCulture);
                double t = P(0);
                if (f[1].Length > 0) r.Marks.Add(t);
                for (int i = 2; i < head.Length; i++)
                    if (feeds.TryGetValue(head[i], out var feed)) feed.Value = P(i);
                r.Usb.Add((P(Array.IndexOf(head, "usb_steer")), P(Array.IndexOf(head, "usb_throttle"))));
                TelemetryEngine.EvaluateTick(ps, t);
                foreach (var v in ps.Vars) r.Out[v.Def.Name].Add((t, v.Output));
                eng.Common.Update(ps, t);
                foreach (var o in CommonValues.Outputs) r.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            }
        }
        return r;
    }

    // Alexis's drift recording, 17 November 2026, 19:33 (RX-7, manual, Akagi, lap 1 to 2, about 38 s): drifts both ways.
    static void Drifts(Action<bool, string> check, string path)
    {
        string s = "FLYINITD3 19:33: ";
        var r = Replay(check, path, "flyinitd3-20261117-193351.csv.gz", s);
        double Max(string n, double a, double b) => r.Out[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        double Min(string n, double a, double b) => r.Out[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Min();
        double CarMax(string n, double a, double b) => r.Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        double end = r.Out["speed"].Last().t;
        // right-hand drifts at 15.53 to 17.00 s and 25.51 to 27.43 s; left at 19.50 to 20.92 s and 28.97 to 30.83 s
        check(Max("drift_angle", 15.5, 17.0) > 18 && Max("drift_angle", 25.5, 27.5) > 17, s + "drift angle + in the right-hand drifts");
        check(Min("drift_angle", 19.5, 21.0) < -17 && Min("drift_angle", 28.9, 30.9) < -15, s + "drift angle - in the left-hand drifts");
        double top = CarMax("drift", 0, end);
        check(top > 0.58 && top < 0.66, s + $"Car_drift tops out at 0.6 to 0.65 in her hardest drifts (Alexis, 17 November 2026): {top:0.000}");
        check(Max("drift", 10.0, 11.1) < 0.65 && Max("drift_curve", 10.0, 11.1) > 0.8, s + $"the rail contact at 10 s doesn't read as a big drift: {Max("drift", 10.0, 11.1):0.00} (the raw curve {Max("drift_curve", 10.0, 11.1):0.00})");
        check(CarMax("cornering", 15.5, 17.0) > 0.5 && r.Car["cornering"].Where(x => x.t >= 19.5 && x.t <= 21.0).Min(x => x.v) < -0.5,
              s + "Car_cornering + in the right-hand bend, - in the left (from the steering, no outputs needed)");
    }

    static void Race(Action<bool, string> check, string path)
    {
        string s = "FLYINITD3 16:57: ";
        var r = Replay(check, path, "flyinitd3-20261117-165737.csv.gz", s);
        var Out = r.Out; var Car = r.Car; var marks = r.Marks; var usb = r.Usb;
        double At(string n, double t) => Out[n].First(x => x.t >= t).v;
        double Max(string n, double a, double b) => Out[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        double Min(string n, double a, double b) => Out[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Min();
        double CarMax(string n, double a, double b) => Car[n].Where(x => x.t >= a && x.t <= b).Select(x => x.v).DefaultIfEmpty(0).Max();
        double end = Out["speed"].Last().t;

        check(marks.Count == 4, s + $"four marks (GO, two lap lines, the finish): {marks.Count}");
        // GO at 68.46 s (gear leaves 0, the race clock starts); the finish line at 259.23 s (the clock stops at 3:09.83)
        check(Max("racing", 0, 68.3) == 0 && Min("racing", 68.6, 259.1) == 1 && Max("racing", 259.5, end) == 0,
              s + "racing from GO to the finish line, and nothing in the menus before or after (the race object's rubbish at 269 s)");
        check(CarMax("in_race", 0, 68.3) == 0 && CarMax("in_race", 259.5, end) == 0 && Car["in_race"].First(x => x.t >= 100).v == 1, s + "Car_in_race the same");
        check(Math.Abs(At("race_clock", 259.5) - 189.83) < 0.02 && Math.Abs(At("race_clock", marks[0]) - 0.33) < 0.1, s + $"race clock 0:00.33 at her GO mark and 3:09.83 at the line: {At("race_clock", 259.5):0.00}");
        check(Math.Abs(At("rt", 65) - 90) < 0.01 && Math.Abs(At("rt", 141.5) - 17.1) < 0.1 && Math.Abs(At("rt", 141.7) - 77.0) < 0.1 && Math.Abs(At("rt", 262) - 19.13) < 0.02,
              s + "time left: 90 s on the grid, 17 to 77 s at the first lap line, held at 19.13 s after the finish");
        check(At("lap", 100) == 1 && At("lap", 150) == 2 && At("lap", 230) == 3, s + "laps 1, 2, 3");
        foreach (double m in new[] { marks[1], marks[2] })
            check(Max("lampcheckpoint", m - 0.3, m + 0.3) == 1 && At("lampcheckpoint", m - 0.5) == 0 && At("lampcheckpoint", m + 1.5) == 1 && At("lampcheckpoint", m + 2.5) == 0,
                  s + $"checkpoint lamp for 2 s at her lap-line mark ({m:0.00} s)");
        check(Max("lampcheckpoint", 0, marks[1] - 0.5) == 0 && Max("lampcheckpoint", marks[1] + 2.5, marks[2] - 0.5) == 0 && Max("lampcheckpoint", marks[2] + 2.5, end) == 0,
              s + "no checkpoint lamp anywhere else (GO, the finish, the menus)");
        check(Max("lampleader", 0, 68.3) == 0 && At("lampleader", 90) == 1 && At("lampleader", 120) == 0 && At("lampleader", 230) == 1
              && At("lampleader", 265) == 1 && Max("lampleader", 269.9, end) == 0,
              s + "leader lamp: off on the grid, ahead at 90 s, behind at 120 s, ahead from 197 s, held after the line until the race is cleared (269 s)");
        check(At("rev_limit", 120) == 8000 && Math.Abs(At("speed", 200.01) * 205 - 199.27) < 0.05 && At("gear", 200) == 5, s + $"rev limit 8000, 199 km/h in 5th at 200 s: {At("rev_limit", 120)} {At("speed", 200.01) * 205:0.00}");
        // ripple strips: surface code 20 under a wheel (48 spells in the race; the first at 74.56 s, TT 0:06.10)
        check(Max("rumble_strip", 74.5, 75.0) == 1 && Max("rumble_strip", 0, 68) == 0 && Max("rumble_strip", 259.5, end) == 0
              && CarMax("rumble_strip", 74.5, 75.0) == 1, s + "ripple strip at TT 0:06.10 (surface code 20), none outside the race");
        int spells = 0; double lastOn = -9;
        foreach (var x in Out["rumble_strip"]) { if (x.v == 1) { if (x.t - lastOn > 0.5) spells++; lastOn = x.t; } }
        check(spells == 48, s + $"48 ripple strip spells in three laps: {spells}");
        check(Out["wall_contact"].All(x => x.v == 0 || Math.Abs(x.v) == 1) && Out["wall_contact"].Any(x => x.v != 0) && Max("wall_contact", 259.5, end) == 0
              && Max("hit", 0, end) <= 1, s + "wall contact reads -1, 0 or 1 and nothing after the line");
        check(CarMax("speed", 259.5, end) == 0 && CarMax("rpm", 259.5, end) == 0, s + "Car_speed and Car_rpm 0 after the line and in the menus");
        var race = Out["racing"].Select((x, i) => (x, i)).Where(p => p.x.v == 1).Select(p => p.i).ToArray();
        double Corr(Func<int, double> a, Func<int, double> b)
        {
            var idx = race.Where(i => !double.IsNaN(a(i)) && !double.IsNaN(b(i))).ToArray();
            double ma = idx.Average(a), mb = idx.Average(b);
            return idx.Sum(i => (a(i) - ma) * (b(i) - mb)) / Math.Sqrt(idx.Sum(i => (a(i) - ma) * (a(i) - ma)) * idx.Sum(i => (b(i) - mb) * (b(i) - mb)));
        }
        double cs = Corr(i => Out["steer"][i].v, i => usb[i].steer), ct = Corr(i => Out["throttle"][i].v, i => usb[i].thr);
        check(cs > 0.95, s + $"steer follows the wheel over USB, + right (the wheel's own value is - left): {cs:0.000}");
        check(ct > 0.9, s + $"throttle follows the pedal over USB: {ct:0.000}");
    }
}
