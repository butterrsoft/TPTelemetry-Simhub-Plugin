using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.TeknoParrot;
using Replay = Wmmt5ReplayTests.Replay;

/// <summary>
/// Alexis's WMMT5DX+ recording of 3 November 2026 (10:13, 36 s in a race, no markers), made with the rows
/// from the Outputs script ticked, to check them against the rows already checked: speed2 against speed,
/// rpm2 against rpm, distance against the speed, throttle against the G25's pedal over USB.
/// Alexis's choices (3 November 2026): speed2 feeds Car_speed and accel_g, rpm2 Car_rpm (Max revs 8900),
/// race_time2 in_race; the original rows stay as the fallback.
/// </summary>
static class Wmmt5OutputsReplayTests
{
    static readonly string[] Extra = { "usb_throttle" };

    static Replay Run(Action<bool, string> check, string path, string fixture)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = ""; // no process: runs on the replayed values

        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);

        var tp = new double[TpChannels.Count];
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            TpSource = a => Array.Copy(tp, a, a.Length),
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "WMMT5DXP" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), "WMMT5DXP rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));

        var rp = new Replay { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()) };
        foreach (var x in Extra) rp.Out[x] = new List<(double t, double v)>();
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        ps.Connected = true;
        int tc = Col("time_s"), mc = Col("marker");
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(kv.Key));
        check(cols.All(c => c.Value >= 0), "the recording has every memory row: " + string.Join(", ", cols.Where(c => c.Value < 0).Select(c => c.Key)));
        var slots = Enumerable.Range(0, TpChannels.SlotCount).Select(i => Col("tp_jvs" + i)).ToArray();
        int conn = Col("tp_connected");
        var extra = Extra.ToDictionary(x => x, Col);
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            if (r[mc] != "") rp.Marks.Add(t);
            foreach (var kv in feeds) kv.Value.Value = Num(r, cols[kv.Key]);
            for (int i = 0; i < slots.Length; i++) tp[i] = Num(r, slots[i]);
            tp[TpChannels.Connected] = Num(r, conn);
            eng.TpSource(ps.Ctx.Tp);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            foreach (var x in Extra) rp.Out[x].Add((t, Num(r, extra[x])));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            rp.End = t;
        }
        return rp;
    }

    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "WMMT5DXP");
        if (gamePackDir == null || !File.Exists(path)) return;
        Check(check, Run(check, path, "wmmt5dxp-20261103-101336.csv.gz"));
    }

    static string F(double v) => v.ToString("0.00", CultureInfo.InvariantCulture);

    static void Check(Action<bool, string> check, Replay r)
    {
        var sp = r.Out["speed"].Select(x => x.v * 230).ToList(); var sp2 = r.Out["speed2"].Select(x => x.v * 230).ToList();
        var d = sp2.Zip(sp, (a, b) => a - b).OrderBy(x => x).ToList();
        double med = d[d.Count / 2], p02 = d[d.Count / 50], p98 = d[d.Count * 49 / 50];
        check(med > 0.3 && med < 0.8 && p02 > -0.2 && p98 < 1.3, $"speed2 is the speed row plus 0 to 1 km/h (whole km/h is rounded down): median {F(med)}, 2% {F(p02)}, 98% {F(p98)}");
        check(r.Out["speed2"].Select(x => x.v).Distinct().Count() > 5 * r.Out["speed"].Select(x => x.v).Distinct().Count(), "speed2 changes far more often than the whole-km/h speed");
        check(r.Car["speed"].Zip(r.Out["speed2"], (c, s) => Math.Abs(c.v - s.v * 230)).Max() < 1e-6, "Car_speed comes from speed2");

        // accel_g from speed2 is steadier than from whole km/h (20 to 24 s: steady acceleration in 6th).
        var a = r.Out["accel_g"].Where(x => x.t > 20 && x.t < 24).Select(x => x.v).ToList();
        double mean = a.Average(), sd = Math.Sqrt(a.Sum(x => (x - mean) * (x - mean)) / a.Count);
        check(mean > 0.12 && mean < 0.2 && sd < 0.08, $"accel_g from speed2: {F(mean)} G, jitter {sd:0.000} G (0.1 from the speed row)");
        check(r.Car["accel_g"].Zip(r.Out["accel_g"], (c, x) => c.v == x.v).All(x => x), "Car_accel_g is accel_g");

        // rpm2 moves with rpm but on a wider scale: about 1.285 x rpm - 1920.
        var rp = r.Out["rpm"].Select(x => x.v * 8900).ToList(); var rp2 = r.Out["rpm2"].Select(x => x.v * 8900).ToList();
        double worst = rp.Zip(rp2, (x, y) => Math.Abs(1.285 * x - 1922 - y)).OrderBy(x => x).ElementAt(rp.Count * 99 / 100);
        check(worst < 200, "rpm2 is about 1.285 x rpm - 1920 (99% within 200 rpm): " + worst.ToString("0", CultureInfo.InvariantCulture));
        check(rp2.Max() > 8600 && rp.Max() < 8300, "rpm2 reaches 8700 at the limiter in 2nd where rpm reads 8270");
        check(r.Car["rpm"].Zip(rp2, (c, x) => Math.Abs(c.v - x)).Max() < 1e-6, "Car_rpm comes from rpm2 (Alexis, 3 November 2026)");
        // Max revs 8900 for rpm2: the rev limiter effect at the limiter in 2nd (0 to 4 s), not climbing 3rd to 6th.
        double CarMax(string n, double a0, double b0) => r.Car[n].Where(x => x.t >= a0 && x.t <= b0).Select(x => x.v).DefaultIfEmpty(0).Max();
        check(CarMax("rev_limit", 1.5, 4.0) == 1 && CarMax("rev_limit", 9.0, 36.0) == 0, "Car_rev_limit at the limiter in 2nd only (Max revs 8900)");

        // The rest of the script's rows.
        double dist = r.Out["distance"].Last().v - r.Out["distance"].First().v;
        double integ = 0; for (int i = 1; i < sp2.Count; i++) integ += (sp2[i] + sp2[i - 1]) / 2 / 3.6 * (r.Out["speed2"][i].t - r.Out["speed2"][i - 1].t);
        check(Math.Abs(dist - integ) < 0.01 * integ, $"distance grows as the speed says: {dist:0} m against {integ:0} m");
        var thr = r.Out["throttle"].Select(x => x.v).ToList(); var usb = r.Out["usb_throttle"].Select(x => x.v).ToList();
        check(thr.Zip(usb, (x, y) => Math.Abs(x - y) < 0.05).Count(x => x) > 0.99 * thr.Count, "throttle matches the G25's throttle over USB");
        check(r.Max("turbo", 0, r.End) == 1.5 && r.Min("turbo", 0, r.End) < -0.49, "turbo 1.5 on full throttle, -0.5 off it");
        check(r.Min("place", 0, r.End) == 1 && r.Max("place", 0, r.End) == 1, "place 1 throughout (order 0, 1, 2, 3)");
        check(!r.Out.ContainsKey("gear_raw"), "no gear_raw (merged into gear)");
        check(r.Out["race_time2"].Zip(r.Out["race_time"], (x, y) => Math.Abs(x.v - y.v) < 0.02).All(x => x), "race_time2 reads the same clock as race_time (to the frame)");
        // Both clocks stood still for 0.15 s at 10.86 s (a game hitch), so in_race may blink off there.
        var off = r.Out["in_race"].Where(x => x.t > 0.2 && x.v != 1).Select(x => x.t).ToList();
        check(off.All(t => t > 10.8 && t < 11.1) && r.Car["in_race"].Where(x => x.t > 0.2 && x.v != 1).All(x => x.t > 10.8 && x.t < 11.1),
              "in_race (from race_time2) on all through the race, but for the 0.15 s hitch at 10.86 s: off " + off.Count + " samples");
        check(r.Min("gear", 0, r.End) == 2 && r.Max("gear", 0, r.End) == 6, "gear 2 to 6");
        // Common values added 3 November 2026 (Alexis): boost from the turbo, throttle load on the engine, harder hits harder.
        check(CarMax("boost", 20, 24) == 1 && CarMax("boost", 35.8, 36.0) == 0 && r.Car["boost"].Where(x => x.t > 5.8 && x.t < 6.3).Min(x => x.v) < 0.8,
              $"Car_boost: 1 at full boost, dips at the upshift, 0 off the throttle: {CarMax("boost", 20, 24):0.00}, {CarMax("boost", 35.8, 36.0):0.00}, {r.Car["boost"].Where(x => x.t > 5.8 && x.t < 6.3).Min(x => x.v):0.00}");
        check(r.Car["throttle"].Zip(r.Out["throttle"], (c0, x) => (c0.t, d: Math.Abs(c0.v - x.v))).Where(x => r.Car["in_race"].First(y => y.t >= x.t).v == 1).All(x => x.d < 1e-9), "Car_throttle is the throttle row (in a race)");
        double Eng(double t) => r.Car["engine"].First(x => x.t >= t).v;
        double Frac(double t) => r.Car["rpm_frac"].First(x => x.t >= t).v;
        check(Math.Abs(Eng(30) - (0.35 + 0.65 * Frac(30))) < 1e-9 && Math.Abs(Eng(35.95) - (0.35 + 0.65 * Frac(35.95)) * 0.6) < 1e-9, "Car_engine full on the throttle, 60% off it");
        check(CarMax("impact", 25.1, 25.5) == 1 && CarMax("impact", 4.0, 5.0) < 0.8 && CarMax("impact", 4.0, 5.0) >= 0.6, "Car_impact 1 for the 68 km/h hit at 25.2 s, about 0.6 for the light ones at 4 to 5 s");
        Console.WriteLine($"WMMT5DX+ replay 10:13: speed2 - speed median {F(med)} km/h; accel_g jitter {sd:0.000} G; rpm2 fit 99% within {worst:0}; distance {dist:0}/{integ:0} m");
    }
}
