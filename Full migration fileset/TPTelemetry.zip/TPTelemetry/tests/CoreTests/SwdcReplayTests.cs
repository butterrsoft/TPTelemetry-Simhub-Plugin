using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using TeknoTelemetry.Core;
using TeknoTelemetry.Core.TeknoParrot;
using Replay = Wmmt5ReplayTests.Replay;

/// <summary>
/// Alexis's Sega World Drivers Championship recordings (version 2.30):
///  * 3 November 2026 (17:59, 18:04, 18:06, and 19:30 with USB capture), made with her table's rows only. Since
///    19 November nothing reaches SimHub without the game's own race state, so 17:59 replays with every value 0;
///    19:30 still checks the force decoded from memory against what the wheel got.
///  * 19 November 2026, 09:15 (SWDC-11): car select, a race from 35th on the grid to the finish line (16th), the
///    menus. The rolling start at 128.17 s, the finish line at 324.47 s (TT 3:16.29); hits, slides and car contact.
/// </summary>
static class SwdcReplayTests
{
    static readonly string[] Extra = { "usb_force", "usb_spring", "usb_steer" };

    static Replay Run(Action<bool, string> check, string path, string fixture)
    {
        var prof = ProfileStore.ReadProfile(path);
        prof.ProcessName = ""; // no process: runs on the replayed values

        string[] head; var rows = new List<string[]>();
        using (var gz = new GZipStream(File.OpenRead(Path.Combine("fixtures", fixture)), CompressionMode.Decompress))
        using (var rd = new StreamReader(gz))
        {
            head = rd.ReadLine().Split(',');
            string line;
            while ((line = rd.ReadLine()) != null) rows.Add(line.Split(','));
        }
        int Col(string n) => Array.IndexOf(head, n);
        double Num(string[] r, int c) => c < 0 || r[c] == "" ? double.NaN : double.Parse(r[c], CultureInfo.InvariantCulture);

        var tp = new double[TpChannels.Count];
        var feeds = new Dictionary<string, Wmmt5ReplayTests.Feed>();
        var eng = new TelemetryEngine
        {
            TpSource = a => Array.Copy(tp, a, a.Length),
            SourceFactory = v =>
            {
                if (v.Source != SourceKind.Memory) return TelemetryEngine.DefaultSourceFactory(v);
                var f = new Wmmt5ReplayTests.Feed(); feeds[v.Name] = f; return f;
            },
        };
        eng.Load(new[] { prof }, new PluginSettings { ActiveGame = "SWDC" });
        var ps = eng.Profiles[0];
        check(ps.Vars.All(v => !v.HasConfigError), "SWDC rows load: " + string.Join("; ", ps.Vars.Where(v => v.HasConfigError).Select(v => v.Def.Name + " " + v.Status)));

        var rp = new Replay { Out = ps.Vars.ToDictionary(v => v.Def.Name, v => new List<(double t, double v)>()) };
        foreach (var x in Extra) rp.Out[x] = new List<(double t, double v)>();
        foreach (var o in CommonValues.Outputs) rp.Car[o.Name] = new List<(double t, double v)>();
        ps.Connected = true;
        int tc = Col("time_s"), mc = Col("marker");
        var cols = feeds.ToDictionary(kv => kv.Key, kv => Col(kv.Key));
        // The rows from the game's own data (v2.30 exe, 18 November 2026) came after these recordings: they read blank here,
        // so the profile falls back to the table's rows, which these checks cover.
        var later = new HashSet<string>(ps.Vars.Where(v => (v.Def.Notes ?? "").Contains("From the v2.30 exe")).Select(v => v.Def.Name));
        check(cols.All(c => c.Value >= 0 || later.Contains(c.Key)), "the recording has every memory row: " + string.Join(", ", cols.Where(c => c.Value < 0 && !later.Contains(c.Key)).Select(c => c.Key)));
        var slots = Enumerable.Range(0, TpChannels.SlotCount).Select(i => Col("tp_jvs" + i)).ToArray();
        int conn = Col("tp_connected");
        var extra = Extra.ToDictionary(x => x, Col);
        foreach (var r in rows)
        {
            double t = Num(r, tc);
            if (r[mc] != "") rp.Marks.Add(t);
            foreach (var kv in feeds) kv.Value.Value = Num(r, cols[kv.Key]);
            for (int i = 0; i < slots.Length; i++) tp[i] = Num(r, slots[i]);
            tp[TpChannels.Connected] = Num(r, conn);
            eng.TpSource(ps.Ctx.Tp);
            TelemetryEngine.EvaluateTick(ps, t);
            foreach (var v in ps.Vars) rp.Out[v.Def.Name].Add((t, v.Output));
            foreach (var x in Extra) rp.Out[x].Add((t, Num(r, extra[x])));
            eng.Common.Update(ps, t);
            foreach (var o in CommonValues.Outputs) rp.Car[o.Name].Add((t, eng.Common.Get(o.Name)));
            rp.End = t;
        }
        return rp;
    }

    public static void Run(Action<bool, string> check, string gamePackDir)
    {
        var path = PackFiles.Find(gamePackDir, "SWDC");
        if (gamePackDir == null || !File.Exists(path)) return;
        string F(double v) => v.ToString("0.00", CultureInfo.InvariantCulture);
        double CarMax(Replay r, string n, double t0, double t1) => r.Car[n].Where(x => x.t >= t0 && x.t <= t1).Select(x => x.v).DefaultIfEmpty(0).Max();
        double CarPeak(Replay r, string n, double t0, double t1) => r.Car[n].Where(x => x.t >= t0 && x.t <= t1).Select(x => x.v).OrderByDescending(Math.Abs).FirstOrDefault();

        // 3 November recordings (Alexis's table only, no car record): since 19 November 2026 nothing reaches SimHub without
        // the game's own race state, so these replay with every value 0.
        var a = Run(check, path, "swdc-20261103-175900.csv.gz");
        check(a.Spans("in_race") == "" && CommonValues.Outputs.All(o => a.Car[o.Name].All(x => x.v == 0 || double.IsNaN(x.v)) || o.Name == "engine_hz"
                || o.Name == "max_speed" || o.Name == "max_revs" || o.Name == "rev_limit_rpm"),   // 0.20.0: the profile's Max speed and Max revs boxes
              "17:59 (no car record): nothing reaches SimHub");
        check(a.Max("version", 0, a.End) == 230, "version 2.30 found");

        // 19 November 2026 (SWDC-11, 09:15): car select, then a race from 35th on the grid to the finish line, then the menus.
        // The rolling start at 128.17 s (TT 0:00.00), the finish line at 324.47 s (TT 3:16.29).
        var b = Run(check, path, "swdc-20261119-091525.csv.gz");
        const double Go = 128.17, Line = 324.47;
        var on = b.Spans("in_race");
        var parts = on.Split('-');
        check(!on.Contains(",") && parts.Length == 2 && Math.Abs(double.Parse(parts[0], CultureInfo.InvariantCulture) - Go) < 0.03
              && Math.Abs(double.Parse(parts[1], CultureInfo.InvariantCulture) - Line) < 0.03, "SWDC-11: in race from the rolling start to the finish line, once: " + on);
        bool Outside(double t) => t < Go - 0.01 || t > Line + 0.02;
        foreach (var n in new[] { "speed", "rpm", "gear", "speed_frac", "rpm_frac", "accel_g", "impact", "impact_side", "road_bump", "cornering", "drift", "drift_angle", "grip_loss", "vibration", "off_road", "rumble_strip" })
            check(b.Car[n].Where(x => Outside(x.t)).All(x => x.v == 0), $"SWDC-11: Car_{n} 0 outside the race (car select, countdown, after the line, menus)");
        foreach (var n in new[] { "revs", "rpm", "speed2", "gear2", "speed_kmh", "kmh", "shift", "brake", "position", "overall", "lap", "race_secs", "pos_x", "yaw", "afterfire", "drift_angle", "hit", "car_contact", "verge", "kerb" })
            check(b.Out[n].Where(x => Outside(x.t)).All(x => x.v == 0), $"SWDC-11: {n} reads 0 outside the race");
        var inRace = Enumerable.Range(0, b.Out["kmh"].Count).Where(i => b.Out["kmh"][i].t > Go + 0.1 && b.Out["kmh"][i].t < Line - 0.1).ToList();
        check(inRace.All(i => b.Car["speed"][i].v == b.Out["kmh"][i].v), "SWDC-11: Car_speed is the speedo's km/h from the car record");
        check(inRace.All(i => b.Car["gear"][i].v == b.Out["gear2"][i].v), "SWDC-11: Car_gear (the record's) is the table's gear throughout");
        check(inRace.All(i => Math.Abs(b.Car["rpm"][i].v - b.Out["revs"][i].v) < 1e-6), "SWDC-11: Car_rpm is the table's revs");
        check(inRace.All(i => Math.Abs(b.Out["kmh"][i].v - b.Out["speed_kmh"][i].v) < 18), "SWDC-11: the record's km/h within 18 km/h of the table's speed through her speedo fit");
        // Laps at the line (TT 0:25.36, 1:28.87, 2:20.84, the finish 3:16.29), places 35th to 16th, the clock at the line.
        var laps = new List<double>(); double lastLap = 0;
        foreach (var (t, v) in b.Out["lap"]) { if (v > lastLap && t > Go) laps.Add(t - Go); if (t > Go && t <= Line) lastLap = v; }
        check(laps.Count == 3 && laps.Zip(new[] { 25.36, 88.87, 140.84 }, (x, y) => Math.Abs(x - y) < 0.05).All(x => x), "SWDC-11: lap lines at TT 0:25.36, 1:28.87, 2:20.84: " + string.Join(", ", laps.Select(F)));
        check(b.At("overall", Go + 0.5) == 35 && b.At("overall", Line - 0.1) == 16, "SWDC-11: 35th of all cars at the start, 16th at the line");
        check(b.At("position", Go + 0.5) == 20 && b.At("position", Line - 0.1) == 1, "SWDC-11: 20th in GT300 at the start, 1st at the line (her results)");
        check(Math.Abs(b.At("race_secs", Line - 0.02) - 196.27) < 0.05, "SWDC-11: race clock 3:16.27 just before the line: " + F(b.At("race_secs", Line - 0.02)));
        // Hits from the speed (the game slows the car at about 5 G): TT 0:17.51 (head-on into a car), 0:22.07 (right wall), 1:16.15 (right
        // wall), 1:25.50 (left wall). Hard braking at 2:26.55 (4.0 G at 223 km/h) is not a hit (her answer).
        var hits = b.Events("hit", 0, 0.5).Select(t => t - Go).ToList();
        check(hits.Count == 4 && hits.Zip(new[] { 17.51, 22.07, 76.15, 85.50 }, (x, y) => Math.Abs(x - y) < 0.06).All(x => x), "SWDC-11: hits at TT " + string.Join(", ", hits.Select(F)));
        // Car contacts and wall hits from the sideways jolt, with the side she gave: + right of her car.
        var contacts = new[] { (18.36, 1), (21.97, 1), (29.29, 1), (30.59, 1), (38.2, -1), (71.47, -1), (72.97, 1), (76.08, 1), (85.40, -1), (87.19, 1), (109.4, 1), (110.17, 1) };
        var cev = b.Events("car_contact", 0, 0.2).Select(t => t - Go).ToList();
        check(cev.Count == contacts.Length && cev.Zip(contacts, (x, y) => Math.Abs(x - y.Item1) < 0.25).All(x => x), "SWDC-11: twelve contacts: " + string.Join(", ", cev.Select(F)));
        foreach (var (t, side) in contacts)
        {
            var c = cev.Where(x => Math.Abs(x - t) < 0.3).ToList();
            double first = c.Count == 0 ? 0 : b.Car["impact_side"].First(x => x.t >= Go + c[0] - 0.01 && x.v != 0).v;
            check(first == side, $"SWDC-11: Car_impact_side {side:+0;-0} at TT {F(t)}: {first}");
        }
        check(cev.All(t => b.Car["impact"].Where(x => x.t > Go + t - 0.05 && x.t < Go + t + 0.35).Max(x => x.v) >= 0.4), "SWDC-11: Car_impact at every contact");
        // Surfaces from the game's vibration: the left verge (0:25.3 to 0:28.2), the right verge then kerb (1:14.1, 1:16.9 to 1:17.4).
        check(CarMax(b, "off_road", Go + 25.3, Go + 28.3) == 1 && CarMax(b, "off_road", Go + 74.1, Go + 74.7) == 1 && CarMax(b, "off_road", Go + 40, Go + 50) == 0, "SWDC-11: Car_off_road on the grass verges, not on the road");
        check(CarMax(b, "rumble_strip", Go + 76.9, Go + 77.5) == 1 && CarMax(b, "rumble_strip", Go + 20, Go + 22) == 0, "SWDC-11: Car_rumble_strip on the solid kerb, not the painted one");
        // Car_drift fitted to her values: 0:55.8 0.65, 1:04 0.6, 1:06 0.5 to 0.55, 1:36 0.6, 1:54 0.55, 2:28 0.75 (within 0.1).
        foreach (var (a0, b0, want) in new[] { (55.3, 57.0, 0.65), (63.8, 65.2, 0.6), (65.7, 67.2, 0.525), (95.7, 97.6, 0.6), (113.6, 115.2, 0.55), (147.5, 150.0, 0.75) })
        {
            double got = CarMax(b, "drift", Go + a0, Go + b0);
            check(Math.Abs(got - want) < 0.1, $"SWDC-11: Car_drift {F(got)} for her {F(want)} at TT {F(a0)}");
        }
        check(b.Car["drift"].Where(x => x.t > Go && x.t < Line).Count(x => x.v > 0.1) * (1 / 120.0) < 25, "SWDC-11: Car_drift over 0.1 for under 25 s of the 196 s race");
        // Drift angle: heading against travel, + in right-hand turns (it follows the steering); her biggest slides.
        double Corr(IList<double> x, IList<double> y) { double mx = x.Average(), my = y.Average(), sxy = 0, sxx = 0, syy = 0; for (int i = 0; i < x.Count; i++) { sxy += (x[i] - mx) * (y[i] - my); sxx += (x[i] - mx) * (x[i] - mx); syy += (y[i] - my) * (y[i] - my); } return sxy / Math.Sqrt(sxx * syy); }
        var fast = inRace.Where(i => b.Out["kmh"][i].v > 60).ToList();
        double cs = Corr(fast.Select(i => b.Out["drift_angle"][i].v).ToList(), fast.Select(i => b.Out["usb_steer"][i].v).ToList());
        check(cs > 0.4, "SWDC-11: + drift angle with steering right: correlation " + F(cs));
        check(b.Max("drift_angle", Go + 147.6, Go + 149.8) > 50, "SWDC-11: the 55-degree slide at TT 2:27.7 to 2:29.8");

        // 19 November 2026, 11:30 (SWDC-12): a GT500 race from 15th, recorded to TT 1:30.80 (no finish). The rolling start at 11.60 s.
        // GT500 cars run at the front, so the class place (the screen's, "/20 GT500") is mostly the place among every car too.
        var g = Run(check, path, "swdc-20261119-113002.csv.gz");
        const double Go2 = 11.60;
        var on2 = g.Spans("in_race");
        check(on2.StartsWith("11.6") && !on2.Contains(","), "SWDC-12: in race from the rolling start: " + on2);
        check(g.Out["position"].Zip(g.Out["overall"], (x, y) => (x.t, x.v <= y.v)).Where(x => x.t > Go2 + 0.1).All(x => x.Item2) && g.At("position", Go2 + 1) == 15
              && g.At("position", Go2 + 90.7) == 4 && g.At("overall", Go2 + 90.7) == 5, "SWDC-12: GT500 class place 15th at the start, the same as overall until 4th to 5th overall at TT 1:30.62");
        var cps = g.Events("checkpoint", 0, 1.2).Select(t => t - Go2).ToList();
        check(cps.Count == 6 && cps.Zip(new[] { 6.85, 20.64, 36.24, 48.61, 61.92, 77.23 }, (x, y) => Math.Abs(x - y) < 0.05).All(x => x),
              "SWDC-12: checkpoints at the lap and sector lines: " + string.Join(", ", cps.Select(F)));
        var gc = g.Events("car_contact", 0, 0.2).Select(t => t - Go2).ToList();
        var gside = gc.Select(t => CarPeak(g, "impact_side", Go2 + t - 0.05, Go2 + t + 0.4)).ToList();
        check(gc.Count >= 15 && gside.All(x => x == 1 || x == -1), "SWDC-12: contacts, each with a side: " + string.Join(", ", gc.Zip(gside, (t, x) => F(t) + (x > 0 ? "R" : "L"))));
        // Her answers: the side of the car hit (R right, L left), where she could tell.
        foreach (var (t, side) in new[] { (8.30, 1), (10.93, 1), (19.05, -1), (21.65, -1), (27.88, 1), (35.66, 1), (55.46, 1), (74.98, 1) })
        {
            var c = gc.Where(x => Math.Abs(x - t) < 0.3).ToList();
            double first = c.Count == 0 ? 0 : g.Car["impact_side"].First(x => x.t >= Go2 + c[0] - 0.01 && x.v != 0).v;
            check(c.Count > 0 && first == side, $"SWDC-12: contact at TT {F(t)} on the {(side > 0 ? "right" : "left")}: {(c.Count > 0 ? first.ToString() : "none")}");
        }
        check(Math.Abs(g.Car["drift"].Where(x => x.t > Go2 + 24.8 && x.t < Go2 + 25.7).Max(x => x.v) - 0.7) < 0.05, "SWDC-12: her 45-degree slide at TT 0:24.87 reads about 0.7");
        Console.WriteLine("SWDC replay SWDC-12: contacts " + string.Join(", ", gc.Zip(gside, (t, x) => F(t) + (x > 0 ? "R" : "L"))) + "; hits " + string.Join(", ", g.Events("hit", 0, 0.5).Select(t => F(t - Go2))));

        // 19:30 (3 November), USB capture on: the force decoded from memory is what the wheel got (the FFB plugin scales it by
        // about 0.93 and the wheel gets it a poll later); + is steering right.
        var d = Run(check, path, "swdc-20261103-193031.csv.gz");
        var f = d.Out["force"].Select(x => x.v).ToList(); var u = d.Out["usb_force"].Select(x => x.v).ToList();
        double cf = Corr(f.Take(f.Count - 1).ToList(), u.Skip(1).ToList());
        check(cf > 0.96, "19:30: force matches the USB force (one poll later): correlation " + F(cf));
        check(Corr(d.Out["force_smooth"].Select(x => x.v).ToList(), d.Out["usb_steer"].Select(x => x.v).ToList()) > 0.8, "19:30: + force is steering right");
        var slides = new[] { 55.3, 63.8, 65.7, 95.7, 113.6, 147.5, 166.8 }.Zip(new[] { 57.0, 65.2, 67.2, 97.6, 115.2, 150.0, 168.6 }, (x, y) => F(CarMax(b, "drift", Go + x, Go + y)));
        Console.WriteLine($"SWDC replay 19 Nov: in race {on}; laps {string.Join(", ", laps.Select(F))}; hits {string.Join(", ", hits.Select(F))}; contacts {string.Join(", ", cev.Select(F))}; drift/steer {F(cs)}; Car_drift at the slides {string.Join(", ", slides)}");
    }
}
