using System;
using System.Collections.Generic;
using System.Linq;
using TeknoTelemetry.Core.Ffb;

/// <summary>
/// The wheel decoders added in 0.21.0 (Thrustmaster, Fanatec, Logitech HID++, USB PID for Moza and others, the G29 and
/// G923 PlayStation on the classic decoder). No capture of these wheels exists yet, so the packets here are built from
/// each protocol's documented layout (the Linux drivers, the USB PID specification): they check the decoders read that
/// layout as intended, not that a real wheel sends it.
/// </summary>
static class WheelDecoderTests
{
    static UsbPacket Out(params byte[] b) => new UsbPacket { Device = 7, Endpoint = 0x01, Transfer = 1, Payload = b, Record = new byte[0] };
    static UsbPacket In(params byte[] b) => new UsbPacket { Device = 7, Endpoint = 0x81, Transfer = 1, FromDevice = true, Payload = b, Record = new byte[0] };
    static UsbPacket Desc(int vid, int pid) => new UsbPacket { Device = 7, Endpoint = 0x80, Transfer = 2, FromDevice = true, Stage = 3,
        Payload = new byte[] { 0x12, 0x01, 0, 2, 0, 0, 0, 0x40, (byte)vid, (byte)(vid >> 8), (byte)pid, (byte)(pid >> 8), 0, 1, 1, 2, 3, 1 }, Record = new byte[0] };
    static UsbPacket Setup(params byte[] b) => new UsbPacket { Device = 7, Endpoint = 0x00, Transfer = 2, Stage = 0, Payload = b, Record = new byte[0] };
    static UsbPacket CtrlData(bool fromDevice, params byte[] b) => new UsbPacket { Device = 7, Endpoint = (byte)(fromDevice ? 0x80 : 0x00), Transfer = 2,
        Stage = fromDevice ? 3 : 1, FromDevice = fromDevice, Payload = b, Record = new byte[0] };

    static double[] Snap(FfbPipeline p) { var v = new double[FfbChannels.Count]; p.Snapshot(v, true); return v; }

    public static void Run(Action<bool, string> check, Action<double, double, double, string> near)
    {
        var saved = FfbDecoderFactory.PidLayout;
        FfbDecoderFactory.PidLayout = (v, p) => null;   // no Windows HID parser here
        try { Picks(check); Thrustmaster(check, near); Fanatec(check, near); Hidpp(check, near); Pid(check, near); }
        finally { FfbDecoderFactory.PidLayout = saved; }
    }

    static void Picks(Action<bool, string> check)
    {
        string Pick(int vid, int pid) { var p = new FfbPipeline(FfbDecoderChoice.Auto, 7); p.OnPacket(Desc(vid, pid)); return p.DecoderName; }
        check(Pick(0x046D, 0xC24F).StartsWith("Logitech classic"), "G29 (046D:C24F) uses the Logitech classic decoder");
        check(Pick(0x046D, 0xC267).StartsWith("Logitech classic"), "G923 PlayStation/PC (046D:C267) uses the classic decoder");
        check(Pick(0x046D, 0xC262).StartsWith("Logitech HID++"), "G920 (046D:C262) uses HID++");
        check(Pick(0x046D, 0xC26E).StartsWith("Logitech HID++"), "G923 Xbox (046D:C26E) uses HID++");
        check(Pick(0x044F, 0xB66E).StartsWith("Thrustmaster") && Pick(0x044F, 0xB696).StartsWith("Thrustmaster"), "T300RS and T248 use the Thrustmaster decoder");
        check(Pick(0x0EB7, 0x0020).StartsWith("Fanatec") && Pick(0x0EB7, 0x0E03).StartsWith("Fanatec"), "CSL DD and CSL Elite use the Fanatec decoder");
        check(Pick(0x346E, 0x0004).StartsWith("USB PID") && Pick(0x346E, 0x0012).StartsWith("USB PID"), "Moza R5 and R9 use the USB PID decoder");
        check(Pick(0x16D0, 0x0D61).StartsWith("USB PID"), "Simucube 2 Sport uses the USB PID decoder");
        check(Pick(0x1234, 0x5678).StartsWith("Raw"), "an unknown wheel stays Raw");
    }

    static void Thrustmaster(Action<bool, string> check, Action<double, double, double, string> near)
    {
        var p = new FfbPipeline(FfbDecoderChoice.Auto, 7);
        p.OnPacket(Desc(0x044F, 0xB66E));
        byte[] Pkt(params byte[] head) { var b = new byte[64]; b[0] = 0x60; Buffer.BlockCopy(head, 0, b, 1, head.Length); return b; }
        // effect 1: constant force upload, level 8192 (half of the driver's 16384)
        p.OnPacket(Out(Pkt(0x00, 0x01, 0x6A, 0x00, 0x20)));
        near(Snap(p)[FfbChannels.Force], 0, 0, "T300: an uploaded effect does nothing until played");
        p.OnPacket(Out(Pkt(0x00, 0x01, 0x89, 0x41, 0x01, 0x00)));
        near(Snap(p)[FfbChannels.Force], 0.5, 1e-3, "T300: constant force 8192 plays as 0.5");
        p.OnPacket(Out(Pkt(0x00, 0x01, 0x6A, 0x00, 0xC0)));   // change to -16384
        near(Snap(p)[FfbChannels.Force], -1, 1e-3, "T300: changed to -16384 reads -1");
        // effect 2: a periodic (sine) at magnitude 16384, period 100 ms; timing duration differs from the period
        var per = Pkt(0x00, 0x02, 0x6B, 0x00, 0x40, 0, 0, 0, 0, 100, 0, 0x00, 0x80);
        per[22] = 3; per[23] = 0x4F; per[24] = 0xFF; per[25] = 0xFF;
        p.OnPacket(Out(per)); p.OnPacket(Out(Pkt(0x00, 0x02, 0x89, 0x41)));
        near(Snap(p)[FfbChannels.Rumble], 0.5, 1e-3, "T300: a periodic effect at 16384 reads as rumble 0.5");
        // effect 3: spring, coefficients 0x4000, type 06 at byte 28
        var spr = Pkt(0x00, 0x03, 0x64, 0x00, 0x40, 0x00, 0x40); spr[28] = 0x06;
        p.OnPacket(Out(spr)); p.OnPacket(Out(Pkt(0x00, 0x03, 0x89, 0x41)));
        near(Snap(p)[FfbChannels.Spring], 0.5, 1e-3, "T300: spring coefficient 0x4000 reads 0.5");
        p.OnPacket(Out(Pkt(0x00, 0x01, 0x89, 0x00)));
        near(Snap(p)[FfbChannels.Force], 0, 0, "T300: stopping the constant force zeroes it");
        p.OnPacket(Out(Pkt(0x08, 0x03, 0xFF, 0x7F)));
        near(Snap(p)[FfbChannels.Autocenter], 0x7FFF / 65535.0, 1e-6, "T300: auto-centre strength from 08 03");
    }

    static void Fanatec(Action<bool, string> check, Action<double, double, double, string> near)
    {
        var p = new FfbPipeline(FfbDecoderChoice.Auto, 7);
        p.OnPacket(Desc(0x0EB7, 0x0020));
        p.OnPacket(Out(0x01, 0x08, 0x00, 0xC0, 0x00, 0x00, 0x01));           // slot 0 constant, 16-bit 0xC000
        near(Snap(p)[FfbChannels.Force], 0.5, 1e-3, "Fanatec: 16-bit constant 0xC000 reads 0.5");
        p.OnPacket(Out(0x01, 0x08, 0x40, 0x00, 0x00, 0x00, 0x00));           // 8-bit 0x40
        near(Snap(p)[FfbChannels.Force], -0.5, 1e-3, "Fanatec: 8-bit constant 0x40 reads -0.5");
        p.OnPacket(Out(0x03, 0x08, 0x40, 0x00, 0x00, 0x00, 0x00));           // slot switched off
        near(Snap(p)[FfbChannels.Force], 0, 0, "Fanatec: switching the slot off zeroes the force");
        p.OnPacket(Out(0x01, 0x11, 0x0B, 0x7F, 0x80, 0x88, 0x00, 0x80));     // with a report ID byte first: spring, clip 0x80
        near(Snap(p)[FfbChannels.Spring], 0x80 / 255.0, 1e-6, "Fanatec: spring strength from byte 6 (after a report ID byte)");
        p.OnPacket(Out(0x21, 0x0C, 0x08, 0x00, 0x08, 0x00, 0xFF));           // slot 2 damper, 4-bit coefficients 8
        near(Snap(p)[FfbChannels.Damper], 8 / 15.0, 1e-6, "Fanatec: damper coefficient 8 of 15");
        p.OnPacket(Out(0xF8, 0x09, 0x01, 0x03, 0x00, 0xFF, 0x00));
        near(Snap(p)[FfbChannels.Rumble], 1, 1e-9, "Fanatec: rim rumble from F8 09 01 03");
    }

    static void Hidpp(Action<bool, string> check, Action<double, double, double, string> near)
    {
        var p = new FfbPipeline(FfbDecoderChoice.Auto, 7);
        p.OnPacket(Desc(0x046D, 0xC262));
        byte[] Msg(int func, params byte[] prm) { var b = new byte[20]; b[0] = 0x11; b[1] = 0xFF; b[2] = 0x0B; b[3] = (byte)(func << 4 | 0x0E); Buffer.BlockCopy(prm, 0, b, 4, prm.Length); return b; }
        p.OnPacket(Out(Msg(2, 0, 0x00, 0, 0, 0, 0, 0x40, 0x00)));           // new constant force, level 0x4000, no slot yet
        p.OnPacket(In(Msg(2, 3)));                                           // the wheel answers: slot 3
        p.OnPacket(Out(Msg(3, 3, 0x02)));                                    // play slot 3
        near(Snap(p)[FfbChannels.Force], 0x4000 / 32767.0, 1e-6, "HID++: constant force 0x4000 in the slot the wheel gave");
        p.OnPacket(Out(Msg(2, 3, 0x00, 0, 0, 0, 0, 0xC0, 0x00)));           // change slot 3 to -0x4000
        near(Snap(p)[FfbChannels.Force], -0x4000 / 32767.0, 1e-6, "HID++: changed in place");
        p.OnPacket(Out(Msg(2, 4, 0x86, 0, 0, 0, 0, 0x7F, 0xFF, 0x40, 0x00))); // slot 4 spring, autostart, left coefficient 0x4000
        near(Snap(p)[FfbChannels.Spring], 0x4000 / 32767.0, 1e-6, "HID++: an autostarted spring");
        p.OnPacket(Out(Msg(3, 3, 0x01)));
        near(Snap(p)[FfbChannels.Force], 0, 0, "HID++: stopping the slot");
        var led = new FfbPipeline(FfbDecoderChoice.LogitechHidpp, 7);
        led.OnPacket(Out(0x11, 0xFF, 0x0C, 0x2E, 0, 0x00, 0x7F));            // too short to be an effect download
        check(Snap(led)[FfbChannels.Force] == 0, "HID++: a short message on another feature isn't taken for force feedback");
    }

    // A USB PID report descriptor like a direct drive wheel's: Set Effect (1), Condition (3), Periodic (4),
    // Constant Force (5), Effect Operation (10), Device Control (12).
    static readonly byte[] PidDescriptor =
    {
        0x05, 0x01, 0x09, 0x04, 0xA1, 0x01,                                   // Generic Desktop, Joystick, Application
        0x05, 0x0F,
        0x09, 0x21, 0xA1, 0x02, 0x85, 0x01,                                   // Set Effect Report
            0x09, 0x22, 0x15, 0x01, 0x25, 0x28, 0x75, 0x08, 0x95, 0x01, 0x91, 0x02,
            0x09, 0x25, 0xA1, 0x02,
                0x09, 0x26, 0x09, 0x27, 0x09, 0x30, 0x09, 0x31, 0x09, 0x40, 0x09, 0x41, 0x09, 0x43,
                0x15, 0x01, 0x25, 0x07, 0x75, 0x08, 0x95, 0x01, 0x91, 0x00,
            0xC0,
            0x09, 0x52, 0x15, 0x00, 0x26, 0xFF, 0x00, 0x75, 0x08, 0x95, 0x01, 0x91, 0x02,
            0x09, 0x57, 0xA1, 0x02,
                0x05, 0x0A, 0x09, 0x01, 0x15, 0x00, 0x27, 0x9F, 0x8C, 0x00, 0x00, 0x75, 0x10, 0x95, 0x01, 0x91, 0x02,
                0x05, 0x0F,
            0xC0,
        0xC0,
        0x09, 0x5F, 0xA1, 0x02, 0x85, 0x03,                                   // Set Condition Report
            0x09, 0x22, 0x15, 0x01, 0x25, 0x28, 0x75, 0x08, 0x95, 0x01, 0x91, 0x02,
            0x09, 0x23, 0x15, 0x00, 0x25, 0x01, 0x75, 0x04, 0x95, 0x01, 0x91, 0x02, 0x75, 0x04, 0x91, 0x03,
            0x09, 0x60, 0x09, 0x61, 0x09, 0x62, 0x16, 0xF0, 0xD8, 0x26, 0x10, 0x27, 0x75, 0x10, 0x95, 0x03, 0x91, 0x02,
        0xC0,
        0x09, 0x6E, 0xA1, 0x02, 0x85, 0x04,                                   // Set Periodic Report
            0x09, 0x22, 0x15, 0x01, 0x25, 0x28, 0x75, 0x08, 0x95, 0x01, 0x91, 0x02,
            0x09, 0x70, 0x15, 0x00, 0x26, 0x10, 0x27, 0x75, 0x10, 0x95, 0x01, 0x91, 0x02,
        0xC0,
        0x09, 0x73, 0xA1, 0x02, 0x85, 0x05,                                   // Set Constant Force Report
            0x09, 0x22, 0x15, 0x01, 0x25, 0x28, 0x75, 0x08, 0x95, 0x01, 0x91, 0x02,
            0x09, 0x70, 0x16, 0xF0, 0xD8, 0x26, 0x10, 0x27, 0x75, 0x10, 0x95, 0x01, 0x91, 0x02,
        0xC0,
        0x09, 0x77, 0xA1, 0x02, 0x85, 0x0A,                                   // Effect Operation Report
            0x09, 0x22, 0x15, 0x01, 0x25, 0x28, 0x75, 0x08, 0x95, 0x01, 0x91, 0x02,
            0x09, 0x78, 0xA1, 0x02, 0x09, 0x79, 0x09, 0x7A, 0x09, 0x7B, 0x15, 0x01, 0x25, 0x03, 0x75, 0x08, 0x95, 0x01, 0x91, 0x00, 0xC0,
            0x09, 0x7C, 0x15, 0x00, 0x26, 0xFF, 0x00, 0x75, 0x08, 0x95, 0x01, 0x91, 0x02,
        0xC0,
        0x09, 0x95, 0xA1, 0x02, 0x85, 0x0C,                                   // Device Control
            0x09, 0x96, 0xA1, 0x02, 0x09, 0x97, 0x09, 0x98, 0x09, 0x99, 0x09, 0x9A, 0x09, 0x9B, 0x09, 0x9C,
            0x15, 0x01, 0x25, 0x06, 0x75, 0x08, 0x95, 0x01, 0x91, 0x00, 0xC0,
        0xC0,
        0xC0,
    };

    static void Pid(Action<bool, string> check, Action<double, double, double, string> near)
    {
        var layout = HidReportLayout.Parse(PidDescriptor);
        check(layout.UsesReportIds && DescriptorPidSource.LooksLikePid(layout), "PID descriptor: parsed, with report IDs, recognised as force feedback");
        var mag = layout.FieldsOf(5).FirstOrDefault(f => f.Usages.Contains(0x000F0070u));
        check(mag != null && mag.BitOffset == 8 && mag.BitSize == 16 && mag.LogicalMin == -10000 && mag.LogicalMax == 10000,
              "PID descriptor: the constant force magnitude is 16 bits after the block index, -10000 to 10000");
        var dirF = layout.FieldsOf(1).FirstOrDefault(f => f.Collections.Contains(0x000F0057u));
        check(dirF != null && dirF.LogicalMax == 35999, "PID descriptor: the direction (degrees x 100) sits in the Direction collection");

        // The pipeline: device descriptor, then the report descriptor as Windows asks for it when the wheel is plugged in
        var p = new FfbPipeline(FfbDecoderChoice.Auto, 7);
        p.OnPacket(Desc(0x346E, 0x0004));
        check(p.DecoderName.Contains("guessed"), "Moza: before the report descriptor, the shared layout is guessed: " + p.DecoderName);
        p.OnPacket(Setup(0x81, 0x06, 0x00, 0x22, 0x00, 0x00, (byte)PidDescriptor.Length, 0x00));
        p.OnPacket(CtrlData(true, PidDescriptor));
        check(p.DecoderName.Contains("from the wheel"), "Moza: the report descriptor in the capture gives the layout: " + p.DecoderName);

        byte[] Le(int v) => new[] { (byte)v, (byte)(v >> 8) };
        byte[] Cat(params object[] parts) => parts.SelectMany(o => o is byte[] a ? a : new[] { Convert.ToByte(o) }).ToArray();
        // effect 1: constant force, direction 90 degrees, gain 255, magnitude 5000 (half of 10000)
        p.OnPacket(Out(Cat((byte)1, (byte)1, (byte)1, (byte)255, Le(9000))));
        p.OnPacket(Out(Cat((byte)5, (byte)1, Le(5000))));
        near(Snap(p)[FfbChannels.Force], 0, 0, "PID: nothing until Effect Operation starts it");
        p.OnPacket(Out(10, 1, 1, 1));
        near(Snap(p)[FfbChannels.Force], 0.5, 1e-6, "PID: constant force 5000 of 10000 at 90 degrees reads 0.5");
        p.OnPacket(Out(Cat((byte)1, (byte)1, (byte)1, (byte)255, Le(27000))));
        near(Snap(p)[FfbChannels.Force], -0.5, 1e-6, "PID: the same force at 270 degrees reads -0.5");
        p.OnPacket(Out(Cat((byte)5, (byte)1, Le(-10000))));
        near(Snap(p)[FfbChannels.Force], 1, 1e-6, "PID: magnitude -10000 at 270 degrees reads 1");
        // effect 2: spring with coefficients 5000; sent as a SET_REPORT control transfer
        p.OnPacket(Out(Cat((byte)1, (byte)2, (byte)5, (byte)255, Le(0))));
        p.OnPacket(Setup(0x21, 0x09, 0x03, 0x02, 0x00, 0x00, 9, 0x00));
        p.OnPacket(CtrlData(false, Cat((byte)3, (byte)2, (byte)0, Le(0), Le(5000), Le(5000))));
        p.OnPacket(Out(10, 2, 1, 1));
        near(Snap(p)[FfbChannels.Spring], 0.5, 1e-6, "PID: a spring set over SET_REPORT reads its coefficient 0.5");
        // effect 3: sine at 3000 of 10000
        p.OnPacket(Out(Cat((byte)1, (byte)3, (byte)4, (byte)255, Le(9000))));
        p.OnPacket(Out(Cat((byte)4, (byte)3, Le(3000))));
        p.OnPacket(Out(10, 3, 1, 1));
        near(Snap(p)[FfbChannels.Rumble], 0.3, 1e-6, "PID: a sine at 3000 reads as rumble 0.3");
        p.OnPacket(Out(10, 1, 3, 0));
        near(Snap(p)[FfbChannels.Force], 0, 0, "PID: Effect Operation stop");
        p.OnPacket(Out(12, 3));   // Stop All Effects
        var v = Snap(p);
        check(v[FfbChannels.Spring] == 0 && v[FfbChannels.Rumble] == 0, "PID: Device Control Stop All stops everything");

        // without a descriptor: the shared layout (constant force 5, effect operation 10)
        var g = new FfbPipeline(FfbDecoderChoice.UsbPid, 7);
        g.OnPacket(Out(1, 1, 1));
        g.OnPacket(Out(Cat((byte)5, (byte)1, Le(-2500))));
        g.OnPacket(Out(10, 1, 1, 1));
        near(Snap(g)[FfbChannels.Force], -0.25, 1e-6, "PID guessed layout: constant force -2500 reads -0.25");
    }
}
