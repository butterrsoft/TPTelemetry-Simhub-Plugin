using System;
using System.Runtime.InteropServices;
using System.Threading;

/// <summary>
/// A stand-in 64-bit "game" for trying the 64-bit helper on Windows without a 64-bit TeknoParrot
/// game. It puts known values behind a two-level pointer chain at fixed addresses above 4 GB
/// (where 32-bit SimHub can't reach), and changes them while it runs:
///
///   0x7E0000000000          pointer -> 0x7E0000010000
///   0x7E0000010000 + 0x10   pointer -> 0x7E0000020000
///   0x7E0000020000 + 0x08   double: a sine wave, -1 to 1, every 4 seconds
///   0x7E0000020000 + 0x10   int32:  counter, 60 a second (worked out from the clock, so it
///                           doesn't depend on how long Windows lets the program sleep)
///
/// The HELPERTEST profile beside this file reads them, plus the "MZ" at the start of this exe
/// (&lt;main&gt;) and of kernel32.dll, to check that 64-bit module bases resolve.
/// Run: dotnet run -c Release (from this folder). Close the window to stop.
/// </summary>
static class Program
{
    const long A = 0x7E00_0000_0000, B = 0x7E00_0001_0000, C = 0x7E00_0002_0000;

    static int Main()
    {
        if (IntPtr.Size != 8) { Console.WriteLine("Build this as 64-bit (it is set to x64)."); return 1; }
        foreach (var page in new[] { A, B, C })
        {
            var got = VirtualAlloc(new IntPtr(page), new UIntPtr(4096), 0x3000 /* MEM_COMMIT|MEM_RESERVE */, 0x04 /* PAGE_READWRITE */);
            if (got != new IntPtr(page))
            {
                Console.WriteLine($"Couldn't put test memory at 0x{page:X} (error {Marshal.GetLastWin32Error()}). Try running it again.");
                return 2;
            }
        }
        Marshal.WriteInt64(new IntPtr(A), B);
        Marshal.WriteInt64(new IntPtr(B + 0x10), C);

        Console.WriteLine("HelperTestTarget64 is running (64-bit, PID " + System.Diagnostics.Process.GetCurrentProcess().Id + ").");
        Console.WriteLine("In SimHub, activate the HELPERTEST profile. Expected:");
        Console.WriteLine("  mz, kernel32_mz = 23117 (\"MZ\"),  wave = sine -1..1 every 4 s,  counter = +60 a second,");
        Console.WriteLine("  missing = 'notloaded.dll not loaded',  broken = 'null/unreadable pointer at level 2'.");
        Console.WriteLine("Close this window to stop; the values should clear and the Status say 'Waiting for HelperTestTarget64.exe'.\n");

        var start = DateTime.UtcNow;
        int shown = -1;
        while (true)
        {
            double t = (DateTime.UtcNow - start).TotalSeconds;
            double wave = Math.Sin(t * 2 * Math.PI / 4);
            int counter = (int)(t * 60);
            Marshal.WriteInt64(new IntPtr(C + 0x08), BitConverter.DoubleToInt64Bits(wave));
            Marshal.WriteInt32(new IntPtr(C + 0x10), counter);
            if (counter / 30 != shown) { shown = counter / 30; Console.Write($"\r  t = {t,6:0.0} s   wave = {wave,6:0.000}   counter = {counter,7}   "); }
            Thread.Sleep(5);
        }
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern IntPtr VirtualAlloc(IntPtr address, UIntPtr size, uint type, uint protect);
}
