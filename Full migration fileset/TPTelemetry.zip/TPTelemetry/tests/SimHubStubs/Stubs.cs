// Signatures mirror the SimHub plugin SDK demo (User.PluginSdkDemo). Compile-check only.
using System;
using System.Windows.Controls;
using System.Windows.Media;

namespace GameReaderCommon
{
    public class GameData { public bool GameRunning { get; set; } }
}

namespace SimHub.Plugins
{
    public class PluginManager { public object GetPropertyValue(string propertyName) => null; }

    public interface IPlugin
    {
        PluginManager PluginManager { get; set; }
        void Init(PluginManager pluginManager);
        void End(PluginManager pluginManager);
    }

    public interface IDataPlugin : IPlugin
    {
        void DataUpdate(PluginManager pluginManager, ref GameReaderCommon.GameData data);
    }

    public interface IWPFSettings : IPlugin
    {
        Control GetWPFSettingsControl(PluginManager pluginManager);
    }

    public interface IWPFSettingsV2 : IWPFSettings
    {
        ImageSource PictureIcon { get; }
        string LeftMenuTitle { get; }
    }

    [AttributeUsage(AttributeTargets.Class)] public class PluginNameAttribute : Attribute { public PluginNameAttribute(string n) { } }
    [AttributeUsage(AttributeTargets.Class)] public class PluginAuthorAttribute : Attribute { public PluginAuthorAttribute(string n) { } }
    [AttributeUsage(AttributeTargets.Class)] public class PluginDescriptionAttribute : Attribute { public PluginDescriptionAttribute(string n) { } }

    public static class PluginExtensions
    {
        public static void AttachDelegate<T>(this IPlugin plugin, string propertyName, Func<T> valueProvider) { }
        public static void AddAction(this IPlugin plugin, string actionName, Action<PluginManager, string> actionStart) { }
    }
}
