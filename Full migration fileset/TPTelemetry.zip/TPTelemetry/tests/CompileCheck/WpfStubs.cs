// Compile-check stand-ins for the WPF members TP Telemetry's code uses (Mono has no PresentationFramework).
// Signatures only; nothing here runs.
#pragma warning disable 67, 169, 436, 649
using System.Collections;
using System.ComponentModel;

namespace System.Windows
{
    public delegate void RoutedEventHandler(object sender, RoutedEventArgs e);
    public delegate void SizeChangedEventHandler(object sender, SizeChangedEventArgs e);
    public class SizeChangedEventArgs : RoutedEventArgs { public bool WidthChanged => false; public bool HeightChanged => false; }
    public class RoutedEventArgs : EventArgs { public bool Handled { get; set; } public object Source { get; set; } public object OriginalSource { get; set; } }
    public class Application { public static Application Current => null; public System.Windows.Threading.Dispatcher Dispatcher => null; }
    public enum TextWrapping { NoWrap, Wrap, WrapWithOverflow }
    public enum VerticalAlignment { Top, Center, Bottom, Stretch }
    public enum HorizontalAlignment { Left, Center, Right, Stretch }
    public enum Visibility { Visible, Hidden, Collapsed }
    public enum MessageBoxButton { OK, OKCancel, YesNoCancel, YesNo }
    public enum MessageBoxResult { None, OK, Cancel, Yes, No }
    public enum MessageBoxImage { None, Error, Warning, Information, Question }
    public struct Thickness { public Thickness(double u) { } public Thickness(double l, double t, double r, double b) { } }
    public struct FontWeight { }
    public static class FontWeights { public static FontWeight Bold => default(FontWeight); public static FontWeight SemiBold => default(FontWeight); public static FontWeight Normal => default(FontWeight); }
    public struct FontStyle { }
    public static class FontStyles { public static FontStyle Italic => default(FontStyle); }
    public class DependencyObject { public System.Windows.Threading.Dispatcher Dispatcher => null; public object GetValue(DependencyProperty p) => null; public void SetValue(DependencyProperty p, object v) { } }

    public class UIElement : DependencyObject { public static readonly DependencyProperty VisibilityProperty = null, IsEnabledProperty = null; public Size DesiredSize => default(Size); public bool IsEnabled { get; set; } public Visibility Visibility { get; set; } public double Opacity { get; set; } public bool IsKeyboardFocused => false; public bool Focus() => true; public event RoutedEventHandler LostFocus; public event RoutedEventHandler GotFocus; public event System.Windows.Input.KeyEventHandler KeyDown; public event System.Windows.Input.KeyEventHandler PreviewKeyDown; }
    public class FrameworkElement : UIElement
    {
        public Thickness Margin { get; set; } public double Width { get; set; } public double Height { get; set; } public double MinWidth { get; set; } public double MaxWidth { get; set; } public double MinHeight { get; set; } public double MaxHeight { get; set; }
        public VerticalAlignment VerticalAlignment { get; set; } public HorizontalAlignment HorizontalAlignment { get; set; }
        public object ToolTip { get; set; } public object DataContext { get; set; } public Style Style { get; set; } public object Tag { get; set; }
        public event RoutedEventHandler Loaded; public event RoutedEventHandler Unloaded;
        public double ActualWidth => 0; public double ActualHeight => 0; public event SizeChangedEventHandler SizeChanged;
        public static readonly DependencyProperty HorizontalAlignmentProperty = null, VerticalAlignmentProperty = null;
        public void SetBinding(DependencyProperty p, System.Windows.Data.BindingBase b) { }
    }
    public class FrameworkElementFactory { public FrameworkElementFactory(Type t) { } public void SetBinding(DependencyProperty p, System.Windows.Data.BindingBase b) { } public void SetValue(DependencyProperty p, object v) { } public void AddHandler(RoutedEvent e, Delegate h) { } }
    public class RoutedEvent { }
    public class DataTemplate { public FrameworkElementFactory VisualTree { get; set; } }
    public class SetterBase { }
    public class Setter : SetterBase { public Setter() { } public Setter(DependencyProperty p, object v) { } public DependencyProperty Property { get; set; } public object Value { get; set; } }
    public class TriggerBase { }
    public class DataTrigger : TriggerBase { public System.Windows.Data.BindingBase Binding { get; set; } public object Value { get; set; } public System.Collections.Generic.List<SetterBase> Setters { get; } = new System.Collections.Generic.List<SetterBase>(); }
    public class Style { public Style() { } public Style(Type t) { } public System.Collections.Generic.List<SetterBase> Setters { get; } = new System.Collections.Generic.List<SetterBase>(); public System.Collections.Generic.List<TriggerBase> Triggers { get; } = new System.Collections.Generic.List<TriggerBase>(); }
    public class Window : System.Windows.Controls.ContentControl { public static Window GetWindow(DependencyObject d) => null; }
    public static class MessageBox
    {
        public static MessageBoxResult Show(string t) => default(MessageBoxResult);
        public static MessageBoxResult Show(string t, string c) => default(MessageBoxResult);
        public static MessageBoxResult Show(string t, string c, MessageBoxButton b) => default(MessageBoxResult);
        public static MessageBoxResult Show(Window o, string t, string c, MessageBoxButton b) => default(MessageBoxResult);
        public static MessageBoxResult Show(string t, string c, MessageBoxButton b, MessageBoxImage i) => default(MessageBoxResult);
    }
    public static class Clipboard { public static void SetText(string s) { } public static string GetText() => ""; }
}
namespace System.Windows.Input
{
    // Key itself comes from the real WindowsBase.dll.
    public delegate void KeyEventHandler(object sender, KeyEventArgs e);
    public class KeyEventArgs : RoutedEventArgs { public Key Key => Key.None; }
}
namespace System.Windows.Data
{
    public enum BindingMode { TwoWay, OneWay, OneTime, OneWayToSource, Default }
    public enum UpdateSourceTrigger { Default, PropertyChanged, LostFocus, Explicit }
    public class BindingBase { }
    public class Binding : BindingBase { public Binding() { } public Binding(string path) { } public BindingMode Mode { get; set; } public UpdateSourceTrigger UpdateSourceTrigger { get; set; } public object Source { get; set; } }
}
namespace System.Windows.Controls
{
    public enum Dock { Left, Top, Right, Bottom }
    public enum Orientation { Horizontal, Vertical }
    public class UIElementCollection : IEnumerable { public void Add(UIElement e) { } public void Insert(int i, UIElement e) { } public void Clear() { } public int Count => 0; public IEnumerator GetEnumerator() { yield break; } }
    public class Control : FrameworkElement { public static readonly DependencyProperty ForegroundProperty = null; public Thickness Padding { get; set; } public System.Windows.Media.FontFamily FontFamily { get; set; } public FontWeight FontWeight { get; set; } public double FontSize { get; set; } public System.Windows.Media.Brush Foreground { get; set; } public System.Windows.Media.Brush Background { get; set; } }
    public class ContentControl : Control { public object Content { get; set; } }
    public class UserControl : ContentControl { }
    public class Panel : FrameworkElement { public UIElementCollection Children { get; } = new UIElementCollection(); }
    public class StackPanel : Panel { public Orientation Orientation { get; set; } }
    public class WrapPanel : Panel { public Orientation Orientation { get; set; } }
    public class DockPanel : Panel { public bool LastChildFill { get; set; } public static void SetDock(UIElement e, Dock d) { } }
    public class Grid : Panel { }
    public class Border : FrameworkElement { public UIElement Child { get; set; } public Thickness BorderThickness { get; set; } public System.Windows.Media.Brush BorderBrush { get; set; } public Thickness Padding { get; set; } }
    public class TextBlock : FrameworkElement { public string Text { get; set; } public TextWrapping TextWrapping { get; set; } public System.Windows.Media.FontFamily FontFamily { get; set; } public FontWeight FontWeight { get; set; } public FontStyle FontStyle { get; set; } public double FontSize { get; set; } public System.Windows.Media.Brush Foreground { get; set; } public static readonly DependencyProperty TextProperty = null; public static readonly DependencyProperty ForegroundProperty = null; public static readonly DependencyProperty FontFamilyProperty = null; }
    public class TextBox : Control { public string Text { get; set; } public bool IsReadOnly { get; set; } public TextWrapping TextWrapping { get; set; } public bool AcceptsReturn { get; set; } public event TextChangedEventHandler TextChanged; public static readonly DependencyProperty TextProperty = null; public void SelectAll() { } }
    public delegate void TextChangedEventHandler(object sender, TextChangedEventArgs e);
    public class TextChangedEventArgs : RoutedEventArgs { }
    public class ButtonBase : ContentControl { public event RoutedEventHandler Click; }
    public class Button : ButtonBase { }
    public class CheckBox : System.Windows.Controls.Primitives.ToggleButton { }
    public delegate void SelectionChangedEventHandler(object sender, SelectionChangedEventArgs e);
    public class SelectionChangedEventArgs : RoutedEventArgs { }
    public class ItemCollection : IEnumerable { public void Refresh() { } public IEnumerator GetEnumerator() { yield break; } public int Count => 0; }
    public class ItemsControl : Control { public IEnumerable ItemsSource { get; set; } public ItemCollection Items { get; } = new ItemCollection(); public string DisplayMemberPath { get; set; } }
    public class Selector : ItemsControl { public object SelectedItem { get; set; } public int SelectedIndex { get; set; } public event SelectionChangedEventHandler SelectionChanged; }
    public class ComboBox : Selector { public bool IsEditable { get; set; } public bool IsDropDownOpen { get; set; } }
    public class Expander : ContentControl { public object Header { get; set; } public bool IsExpanded { get; set; } public event RoutedEventHandler Expanded; public event RoutedEventHandler Collapsed; }
    public enum ScrollBarVisibility { Disabled, Auto, Hidden, Visible }
    public delegate void ScrollChangedEventHandler(object sender, ScrollChangedEventArgs e);
    public class ScrollChangedEventArgs : RoutedEventArgs { public double ViewportWidthChange => 0; public double ViewportHeightChange => 0; }
    public class ScrollViewer : ContentControl
    {
        public ScrollBarVisibility HorizontalScrollBarVisibility { get; set; } public ScrollBarVisibility VerticalScrollBarVisibility { get; set; }
        public double ViewportWidth => 0; public double ViewportHeight => 0; public event ScrollChangedEventHandler ScrollChanged;
    }
    public enum DataGridSelectionMode { Single, Extended }
    public enum DataGridHeadersVisibility { All, Column, Row, None }
    public struct DataGridLength { public DataGridLength(double v) { } public DataGridLength(double v, DataGridLengthUnitType t) { } public static DataGridLength Auto => default(DataGridLength); }
    public enum DataGridLengthUnitType { Auto, Pixel, SizeToCells, SizeToHeader, Star }
    public class DataGridColumn : DependencyObject { public object Header { get; set; } public DataGridLength Width { get; set; } public double MinWidth { get; set; } public bool IsReadOnly { get; set; } public Style CellStyle { get; set; } public Visibility Visibility { get; set; } }
    public class DataGridBoundColumn : DataGridColumn { public System.Windows.Data.BindingBase Binding { get; set; } public Style ElementStyle { get; set; } public Style EditingElementStyle { get; set; } }
    public class DataGridTextColumn : DataGridBoundColumn { public System.Windows.Media.FontFamily FontFamily { get; set; } }
    public class DataGridCheckBoxColumn : DataGridBoundColumn { }
    public class DataGridComboBoxColumn : DataGridColumn { public Style ElementStyle { get; set; } public Style EditingElementStyle { get; set; } public IEnumerable ItemsSource { get; set; } public System.Windows.Data.BindingBase SelectedItemBinding { get; set; } public System.Windows.Data.BindingBase SelectedValueBinding { get; set; } }
    public class DataGridTemplateColumn : DataGridColumn { public DataTemplate CellTemplate { get; set; } public DataTemplate CellEditingTemplate { get; set; } }
    public class DataGridRow : Control { public static readonly DependencyProperty BackgroundProperty = null; public object Item { get; set; } }
    public class DataGridBeginningEditEventArgs : EventArgs { public DataGridRow Row => null; public DataGridColumn Column => null; public bool Cancel { get; set; } }
    public class DataGridCell : Control { }
    public class DataGrid : Selector
    {
        public System.Collections.ObjectModel.ObservableCollection<DataGridColumn> Columns { get; } = new System.Collections.ObjectModel.ObservableCollection<DataGridColumn>();
        public bool AutoGenerateColumns { get; set; } public bool CanUserAddRows { get; set; } public bool CanUserDeleteRows { get; set; } public bool CanUserSortColumns { get; set; } public bool CanUserReorderColumns { get; set; }
        public DataGridSelectionMode SelectionMode { get; set; } public DataGridHeadersVisibility HeadersVisibility { get; set; } public Style RowStyle { get; set; }
        public void ScrollIntoView(object o) { } public bool CommitEdit() => true; public bool CancelEdit() => true;
        public double RowHeight { get; set; } public bool EnableRowVirtualization { get; set; }
        public event EventHandler<DataGridBeginningEditEventArgs> BeginningEdit;
    }
}
namespace System.Windows.Controls.Primitives { public class ToggleButton : System.Windows.Controls.ButtonBase { public bool? IsChecked { get; set; } public event RoutedEventHandler Checked; public event RoutedEventHandler Unchecked; public static readonly DependencyProperty IsCheckedProperty = null; } }
namespace System.Windows.Media
{
    public abstract class ImageSource { public void Freeze() { } }
    public abstract class Drawing { }
    public class DrawingImage : ImageSource { public DrawingImage(Drawing d) { } }
    public class Brush { }
    public class SolidColorBrush : Brush { public SolidColorBrush(Color c) { } }
    public struct Color { public static Color FromRgb(byte r, byte g, byte b) => default(Color); public static Color FromArgb(byte a, byte r, byte g, byte b) => default(Color); }
    public class Pen { }
    public static class Brushes { public static Brush White => null; public static Brush Red => null; public static Brush Orange => null; public static Brush Gray => null; public static Brush OrangeRed => null; public static Brush Transparent => null; }
    public abstract class Geometry { public static Geometry Parse(string s) => null; }
    public class GeometryDrawing : Drawing { public GeometryDrawing(Brush b, Pen p, Geometry g) { } }
    public class FontFamily { public FontFamily(string n) { } }
}
namespace Microsoft.Win32
{
    public abstract class FileDialog { public string Filter { get; set; } public string FileName { get; set; } public string Title { get; set; } public string InitialDirectory { get; set; } public string DefaultExt { get; set; } public bool? ShowDialog() => null; public bool? ShowDialog(System.Windows.Window owner) => null; }
    public class OpenFileDialog : FileDialog { public bool Multiselect { get; set; } public string[] FileNames => new string[0]; }
    public class SaveFileDialog : FileDialog { }
}
