#!/bin/sh
# Compile-checks the whole plugin (settings page included) and the 64-bit helper on Linux, against
# the real .NET Framework 4.8 API, without SimHub, WPF or NuGet. Nothing produced here is usable.
#
# Needs:  apt-get install dotnet-sdk-8.0 mono-devel
#         (Mono supplies /usr/lib/mono/4.8-api, the 4.8 reference assemblies; it has no WPF, so
#         WpfStubs.cs stands in for the WPF members the plugin uses. Add to it if the UI grows.)
# Run from anywhere:  sh tests/CompileCheck/compile-check.sh
set -e
HERE=$(cd "$(dirname "$0")" && pwd); ROOT=$(cd "$HERE/../.." && pwd)
OUT=${TMPDIR:-/tmp}/tpt-compile-check; mkdir -p "$OUT"
R=/usr/lib/mono/4.8-api
SDKDIR=$(dotnet --list-sdks | tail -1 | sed 's/.*\[\(.*\)\]/\1/')/$(dotnet --list-sdks | tail -1 | awk '{print $1}')
CSC="dotnet $SDKDIR/Roslyn/bincore/csc.dll -nologo -noconfig -nostdlib -langversion:latest -warn:4"
FAC=$(ls $R/Facades/*.dll | sed 's/^/-r:/' | tr '\n' ' ')

$CSC -target:library -out:"$OUT/SimHubStubs.dll" -r:$R/mscorlib.dll -r:$R/System.dll -r:$R/WindowsBase.dll \
    "$ROOT/tests/SimHubStubs/Stubs.cs" "$HERE/WpfStubs.cs"
$CSC -target:library -out:"$OUT/TPTelemetry.dll" -r:$R/mscorlib.dll -r:$R/System.dll -r:$R/System.Core.dll \
    -r:$R/System.Xml.dll -r:$R/System.Xml.Linq.dll -r:$R/System.Xaml.dll -r:$R/WindowsBase.dll -r:$R/Microsoft.CSharp.dll $FAC \
    -r:"$OUT/SimHubStubs.dll" -r:"$SDKDIR/Newtonsoft.Json.dll" \
    $(find "$ROOT/src/TPTelemetry" -name '*.cs' -not -path '*/obj/*' -not -path '*/bin/*')
echo "plugin: ok"
S="$ROOT/src/TPTelemetry/Core"
$CSC -platform:x64 -target:exe -define:TPT_HELPER -out:"$OUT/TPTelemetryHelper64.exe" -r:$R/mscorlib.dll -r:$R/System.dll -r:$R/System.Core.dll \
    "$ROOT/src/TPTelemetryHelper64/Program.cs" "$S/Model.cs" "$S/Log.cs" "$S/Sources.cs" "$S/ProcessMemory.cs" "$S/ChildProcessJob.cs" "$S"/Remote/*.cs
echo "helper: ok"
$CSC -target:exe -out:"$OUT/TPTelemetryFfbTest.exe" -r:$R/mscorlib.dll -r:$R/System.dll -r:$R/System.Windows.Forms.dll \
    "$ROOT/src/TPTelemetryFfbTest/Program.cs"
echo "test pattern: ok"
$CSC -platform:x64 -target:exe -out:"$OUT/HelperTestTarget64.exe" -r:$R/mscorlib.dll -r:$R/System.dll "$ROOT/tests/HelperTestTarget64/Program.cs"
echo "test target: ok"
