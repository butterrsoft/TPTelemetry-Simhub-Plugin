# SimHub effects

TP Telemetry can write ready-made SimHub effect profiles: a set of "TP -" effects (collisions, ripple
strips, engine, gear changes and so on) for bass shakers and shaker motors (seat and pedals) and fans. They
work in every game, so you set them up once. Each effect can be switched off, or turned up and down,
in SimHub like any other.

Every common value the effects read is listed in [Common_Properties.md](Common_Properties.md). The plugin also
publishes common dashboard values and lamps ([Common_Dashboard.md](Common_Dashboard.md),
[Common_Lamps.md](Common_Lamps.md)); no effect reads those.

## How it fits together

1. Each game's profile has a few `car_` rows (unticked, at the end of its table). They turn that
   game's own values into a common meaning: `car_impact` is a hit from 0 to 1 in every game,
   `car_speed` is its speed, and so on. The game profiles pack fills these in for every game.
2. The plugin publishes the common values as `TPTelemetry.Car_...` properties, from whichever game
   is selected. Effects are 0 outside a race, and speed and revs are scaled by the game's **Max speed**
   and **Max revs**.
3. The "TP -" effects read only `TPTelemetry.Car_...`. So one SimHub profile, called **TP Telemetry**,
   serves every game.

For the same reason, one SimHub game is enough for all your TeknoParrot games: the TP Telemetry
profile follows whichever game TP Telemetry has selected.

## Creating and importing the profiles

The profiles are for the whole plugin, not per game: the effects read the common values
(`TPTelemetry.Car_...`), which follow whichever game TP Telemetry has selected, so every game uses the
same profile. Make them once for each kind of hardware (one for Bass Shakers, one for Shaker
Motors), and again only when you change the ticks or update the plugin.

1. In TP Telemetry, open **SimHub effects** and tick the hardware you have. There are two rows, one
   for each kind of shaker:
   * **Bass Shaker** (ShakeIt Bass Shakers) and **Shaker Motor** (ShakeIt Motors), each with:
     * **Seat**: shakers or motors on the seat.
     * **Pedal box**: one shaker for all the pedals.
     * **Gas pedal**, **Brake pedal**, **Clutch pedal**: a shaker on each pedal.
   * **Fans (as motors)**, on the Shaker Motor row (fans run as ShakeIt Motors outputs): see [Fans](#fans).
2. Click **Create TP Effect Profiles**. The plugin saves one or two files in
   `SimHub\PluginsData\TPTelemetry\SimHub effects\` and opens the folder:
   * `Bass Shakers\Any Game - TP Telemetry.siprofile`, for everything ticked on the Bass Shaker row;
   * `Motors\Any Game - TP Telemetry.siprofile`, for everything ticked on the Shaker Motor row.

   Both have SimHub's own name for an exported "Any Game" profile called TP Telemetry. Keep the name:
   SimHub 9.13 appears to take the game from it: the same file under another name imported as an
   empty copy of the default profile.
3. In SimHub, open **ShakeIt Bass Shakers**, **Effects Profile** tab, click **Profiles manager**,
   then import the file in the `Bass Shakers` folder. Do the same in **ShakeIt Motors** with the
   file in the `Motors` folder. Importing a file into the wrong section won't work: the Bass Shakers
   file holds tone effects, the Motors file vibration effects.
4. Select the **TP Telemetry** profile. It's an "Any Game" profile, so it can be chosen whatever game
   SimHub has selected.

The profiles don't carry output settings, so importing one never changes how your shakers or motors
are wired. To update them later (new ticks, or a newer plugin), delete the old TP Telemetry profile
in Profiles manager first, then import the new file. Tested against SimHub 9.9.4's file layout; use
9.9.4 or later (the same file imports in 9.9.4, and in 9.13.3 under SimHub's file name).

Then, in TP Telemetry, set **Max speed** and **Max revs** for each game you play (see
[Max speed and Max revs](#max-speed-and-max-revs)).

## Testing without a game: the dummy profile

The dummy profile (`profiles\DUMMY.json` in the plugin download; import it like any profile) feeds the
first six effects, one at a time, in a repeating 60-second cycle. Each rises from 0 to full over 5
seconds and falls back to 0 over the next 5:

| Seconds into each minute | Effect |
|---|---|
| 0 to 10 | TP - Collision (both sides) |
| 10 to 20 | TP - Wall scrape (left) |
| 20 to 30 | TP - Rumble strip |
| 30 to 40 | TP - Road bump |
| 40 to 50 | TP - Off-road |
| 50 to 60 | TP - Gear change: one every second (a gear change is a fixed-size kick, so it can't ramp) |

Select the dummy in TP Telemetry, then set each effect's strength and channels in SimHub while you
feel it. The cycle starts when the dummy is selected. The same effects play on seat shakers, seat
motors and pedal box shakers (the pedal box gets Collision and Gear Change).

## The effects

All start switched on. The percentages are starting points: turn each up or down in SimHub, or switch
it off.

### Seat shakers (Bass Shakers file)

| Effect | What you feel | Value it reads (`TPTelemetry.Car_...`) |
|---|---|---|
| TP - Collision | a hard thump, stronger on the side that was hit (80%) | `impact_left`, `impact_right` |
| TP - Wall scrape | grinding while scraping along a wall, on that side (60%) | `wall_left`, `wall_right` |
| TP - Rumble strip | a low buzz on a ripple strip (60%) | `rumble_strip` |
| TP - Road bump | a thud for each joint or bump (70%) | `road_bump` |
| TP - Off-road | rough, noisy rumble on rough ground (50%) | `off_road` |
| TP - Gear change | a short kick (60%) | `shift` |
| TP - Engine | engine vibration: the pitch rises from 25 Hz at idle to 60 Hz at Max revs, the strength more gently (50%); in games with a throttle value (WMMT5DX+ so far) it runs at 60% off the throttle (0.14.0) | `engine`, pitch `engine_hz` |
| TP - Rev limiter | a stutter at 97% of Max revs and above (60%) | `rev_limit` |
| TP - Road (speed) | faint road texture growing with speed, cut while airborne (30%) | `road` |
| TP - Grip loss | rough rumble while sliding, mostly at the rear (50%) | `grip_loss` |
| TP - Drift | a deep, smooth rumble at the rear that grows with the drift (50%; 0.18.0) | `drift` |
| TP - Braking and acceleration | G-force cue: a low tone at the front under braking, at the rear under acceleration (30%) | `braking`, `accelerating` |
| TP - Cornering | G-force cue: a low tone on the outside of the turn (30%) | `corner_left`, `corner_right` |
| TP - Landing | a thump when landing after a jump or crest, harder the longer the car was in the air (70%) | `landed` |
| TP - Boost | a rising buzz while boosting (40%) | `boost` |
| TP - Game rumble | the game's own vibration commands (50%) | `vibration` |

Shakers can't push like a motion rig, so G-forces come as a cue: a quiet, low tone where the force
would be. Keep those two low.

### Pedal shakers (each on its own output)

A pedal ticked on the Bass Shaker row puts its effects in the Bass Shakers file; ticked on the Shaker
Motor row, in the Motors file (tick both if a pedal has one of each). The effects are the same either
way; on motors there's no pitch, so the engine effects are strength only.

| Pedal | Effects |
|---|---|
| Gas (output "TP Gas pedal") | TP - Pedal Gas: Engine (50%), TP - Pedal Gas: Rev Limiter (60%), TP - Pedal Gas: Wheelspin (40%) |
| Brake ("TP Brake pedal") | TP - Pedal Brake: Braking (50%, grows with braking force), TP - Pedal Brake: Collision (50%) |
| Clutch ("TP Clutch pedal") | TP - Pedal Clutch: Gear Change (70%), TP - Pedal Clutch: Engine (25%) |
| Pedal box ("TP Pedal box") | TP - Pedal Box: Engine (30%), TP - Pedal Box: Rev Limiter (40%), TP - Pedal Box: Braking (40%), TP - Pedal Box: Gear Change (50%), TP - Pedal Box: Collision (40%) |

### Seat motors (Motors file)

TP - Collision, Wall scrape, Rumble strip, Road bump, Off-road, Gear change, Rev limiter, Grip loss,
Drift, Landing and Game rumble, as for the seat (motors have no pitch, so there's no engine effect).

### Fans (Motors file, output "TP Fans")

TP - Wind (fan speed follows car speed, 100%) and TP - Wind: Boost gust (50%).

## Giving pedal shakers and fans their own channels

Seat effects (bass shakers and shaker motors) play on your outputs in SimHub's ordinary channel modes (Mono,
Left / Right, Corners...), with nothing to set up.

Pedal and fan effects carry an output name ("TP Gas pedal", "TP Fans"...). SimHub only plays a named
effect on an output set to **Custom channel map**, where you choose its channel. That keeps pedal
effects out of the seat, and seat effects out of the pedals.

### Example: two stereo sound devices

Device 1 drives the seat shakers (left and right). Device 2 drives a gas pedal shaker on its first
channel and a brake pedal shaker on its second.

1. **Windows.** Plug in the second device. In Windows sound settings set both to Stereo, 16-bit,
   48000 Hz, audio enhancements off. Don't make either the default playback device (SimHub warns in
   red if a shaker output is the Windows default: game sound would go there too).
2. **Add both in SimHub.** ShakeIt Bass Shakers, **Sound Output** tab. Click **Add additional sound
   output** for the second device. (An output marked "not available anymore" is an old unplugged
   device: **Delete this sound output**.)
3. **Seat device.** Expand it and choose **Left / Right** from the channel modes (Mono, Left / Right,
   Front / Rear, Front Left / Right, Rear Left / Right, Corners, Custom channel map). The seat effects
   play here; the named pedal effects don't.
4. **Pedal device.** Expand it and choose **Custom channel map (up to 8 channels)**. A grid appears:
   effects down the side, Channel 1 to Channel 8 across the top, each cell ON or OFF.
   * Find the **Custom Effect** rows marked **TP Gas pedal**: set them ON under Channel 1 and OFF
     everywhere else.
   * Do the same for the **TP Brake pedal** rows under Channel 2.
   * Set every other row OFF on this device, so the seat effects don't play through the pedals.
     **Clear** turns the whole grid off to start from.
   * A custom effect shows a row for each corner (FrontLeft, FrontRight, RearLeft, RearRight). The pedal
     effects only use FrontLeft, so that's the row that matters, but setting all four the same does no harm.
5. **Test.** **Test now** under each channel buzzes that shaker. **Show per effect gain** lets you
   balance each effect per channel.

Three outputs instead (say seat on a mono device and two pedals on a stereo one) work the same way:
the seat device in Mono, the pedal device in Custom channel map.

### Fans

SimHub's own **ShakeIt Wind** section can't use custom effects, and its speed-based wind reads
SimHub's own game speed, which TeknoParrot games don't supply ("Measured car max speed 0km/h"). So
the TP wind effects go in **ShakeIt Motors** instead, for fans connected the way motors are (for
example through an Arduino motor controller), set up as ShakeIt Motors outputs. Map the **TP Fans**
effects to the fan outputs as in the pedal example (Custom channel map), and keep other effects off
them. Fans that only work through ShakeIt Wind can still use its idle or forced wind, at a fixed speed.

## Max speed and Max revs

The speed, wind and engine effects use each game's **Max speed** and **Max revs** (the boxes above
its table): `Car_speed_frac` is speed / Max speed, `Car_rpm_frac` is revs / Max revs, both 0 to 1. So
the effects feel the same in every game, whatever its units or top speed. Where a game knows each car's
limiter (a `car_rpm_frac` row, plugin 0.17.0; GRID so far), `Car_rpm_frac` comes from it instead, so the
rev limiter and engine effects follow every car and Max revs only matters for the game's own rpm row.

* **Blank boxes keep those effects silent** (rather than flat out), and the SimHub effects section
  says "Set Max revs for the engine effects".
* Max revs is the redline: the rev limiter starts at 97% of it.
* Gauges and dashboards should use the raw `TPTelemetry.Car_speed` and `TPTelemetry.Car_rpm`, which
  don't depend on the boxes.

## Which games provide what

Effects whose value a game doesn't provide stay silent in that game. Today:

* **Collisions, bumps and cornering** work in nearly every game; in most they're worked out from the
  force the game sends the wheel, so they're stand-ins until better values are found.
* **Engine, speed, wind and gear change** work in the 11 to 16 games with speed, revs or gear values.
* **Wall scrape, ripple strips, grip loss, landing and boost** work where the game has them (WMMT5/6
  have the most).
* Checked against real recordings: WMMT5DX+, WMMT3DX+, OutRun 2 SP SDX, Sega Rally 3 and Sega World Drivers Championship.

### The common values (`TPTelemetry.Car_...`)

| Value | Meaning |
|---|---|
| `in_race` | 1 while racing (effects are 0 otherwise) |
| `speed`, `rpm`, `gear`, `accel_g` | raw speed (the game's units), RPM, gear, forward G, for gauges |
| `speed_frac`, `rpm_frac` | speed / Max speed, revs / Max revs, 0 to 1 |
| `engine`, `engine_hz` | engine vibration strength (0.35 at idle to 1; 60% of that off the throttle where the game has a throttle value) and pitch (25 to 60 Hz) |
| `rev_limit` | rev limiter stutter |
| `road` | road texture (speed_frac, cut while airborne) |
| `shift` | 1 for 0.15 s after a gear change |
| `impact`, `impact_left`, `impact_right`, `impact_side` | hits, 0 to 1, and how they split by side |
| `wall_contact`, `wall_left`, `wall_right` | scraping a wall |
| `road_bump`, `rumble_strip`, `off_road` | road surface |
| `grip_loss` | sliding; a game with no slip value of its own gives its drift here too (0.18.0) |
| `drift`, `drift_angle` | drifting, 0 to 1; the drift angle in degrees (+ the car pointing right of its path), raw, where the game gives one (0.18.0) |
| `braking`, `accelerating` | G-force cues, 0 to 1 |
| `cornering`, `corner_left`, `corner_right` | cornering load (+ turning right) and its cue on the outside |
| `airborne`, `landed` | in the air; 0.25 s pulse on landing, 0.4 after a brief lift rising to 1 after 0.25 s or more in the air |
| `boost`, `vibration` | boost (WMMT5DX+: the turbo gauge); the game's own rumble |
| `throttle` | throttle pedal, 0 to 1 (0.14.0; games with a throttle value, WMMT5DX+ so far) |
| `usb` | 1 while some values come from the wheel force over USB because the game has none (0.15.0; USB_Capture.md) |

### Adding car_ rows to your own profile

For a game you've set up yourself, add computed rows named after the common values, with formulas
giving the agreed meaning, and untick them (they feed `Car_...`, not a property of their own):

| Row | Formula should give |
|---|---|
| `car_in_race` | 1 while racing (leave it out to count "game attached" as racing) |
| `car_speed`, `car_rpm` | raw speed and RPM (if your speed row divides by Max speed: `speed * max_speed`) |
| `car_rpm_frac` | optional (0.17.0): revs as a fraction of the car's own limiter, 0 to 1; replaces revs / Max revs |
| `car_gear`, `car_accel_g` | gear (1 = first); forward G |
| `car_impact`, `car_impact_side` | hit 0 to 1 (about 0.6 ordinary, 1 big); side -1 left, 1 right, 0 unknown |
| `car_wall_contact` | -1 left wall, 1 right, 0 none (values in between: how hard) |
| `car_road_bump`, `car_rumble_strip`, `car_off_road` | 0 to 1; 1 on a strip; 0 to 1 |
| `car_grip_loss`, `car_cornering` | 0 to 1; -1 to 1 (+ turning right) |
| `car_drift`, `car_drift_angle` | optional (0.18.0): drifting 0 to 1; the drift angle in degrees, + pointing right of the car's path. With only the angle, Car_drift is its size over 40 degrees |
| `car_airborne`, `car_boost`, `car_vibration` | 1 in the air; 0 to 1; 0 to 1 |

Game_Formulas.md, in the game profiles pack, shows every game's `car_` rows to copy from.

## Future options

These aren't in the profiles yet, and why:

* **Motion rigs.** SimHub's Motion section doesn't accept custom (formula) effects, so TP Telemetry
  can't feed it. If that changes, the plan is: forward and back push and pitch from `Car_braking` and
  `Car_accelerating`; sideways push and roll from `Car_cornering`; up-and-down from `Car_road_bump`,
  `Car_rumble_strip` and `Car_landed`; jolts from `Car_impact_left` / `Car_impact_right`; rear slide
  (yaw) from `Car_drift_angle` or `Car_grip_loss`. The values are already published, so anyone experimenting can use them.
* **Seat belt tensioners.** Nearly always home-built (a servo or motor on an Arduino), driven through
  SimHub's Motion section or a Custom Serial device with its own formulas, neither of which takes
  these profiles. Builders can drive one from `TPTelemetry.Car_braking` (and `Car_accelerating`) in
  their own device's formula.
* **ShakeIt Wind.** As above: no custom effects there. Fans set up as ShakeIt Motors outputs are covered.
* **LEDs, gauges and cabinet lamps** (rev light strips, a race leader lamp on an Arduino output, dimmable
  cabinet lights, analogue gauges): next. The lamp rows already publish 0 or 1 for on/off lamps and
  0 to 255 for dimmable ones.
