# Common lamps

**This file lists the common lamp properties:** `TPTelemetry.Lamp_...`, one name per kind of cabinet lamp whatever the
game, so one LED or lamp setup in SimHub serves every game. Companion files:
[Common_Properties.md](Common_Properties.md) (the values the SimHub effects are built from) and
[Common_Dashboard.md](Common_Dashboard.md) (`TPTelemetry.Car_speed_kmh`, clocks, laps and so on).

Plugin 0.20.0, 19 November 2026.

**Using them in SimHub:** each name below is the full property name. In an NCalc formula write it in square brackets, `[TPTelemetry.Lamp_start]`; in a JavaScript formula, `$prop('TPTelemetry.Lamp_start')`. SimHub's property picker lists them under the TPTelemetry plugin.

## How they work

* A game profile has unticked rows named `lamp_<name>` that point at the game's own lamp (`lamp_start` = `lampstart`)
  or make one from its race values (`lamp_leader` from the position). The plugin publishes them as
  `TPTelemetry.Lamp_<name>`, 0 to 1 (0 off, 1 on; a few colour lamps dim in between).
* **Lamps are never tied to racing**: a cabinet lights its lamps in the attract mode and menus too, so these pass
  through whatever the race state. Lamps made from race values (leader, checkpoint, final lap, the made-up shift
  light) are naturally off outside a race.
* No profile drives every lamp. A game without a row reads 0, or the stand-in below.
* The game's own lamp rows are still published as before (`TPTelemetry.BG4JP_lampstart` and so on), for anything
  game-specific.
* Lamps read through OutputBlaster or an emulator's outputs need those running, as before (Game_Setup.md says which).

## The lamps

| Property | Meaning | Stand-in when the game has none | Profiles with a row (19 November 2026) |
|---|---|---|---|
| `TPTelemetry.Lamp_start` | the Start button | | 45 |
| `TPTelemetry.Lamp_view` | any view (camera) button | the brightest of `TPTelemetry.Lamp_view1` to `TPTelemetry.Lamp_view4` | (all with a view lamp) |
| `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4` | view buttons 1 to 4 | | 46, 22, 17, 15 |
| `TPTelemetry.Lamp_select_up`, `TPTelemetry.Lamp_select_down`, `TPTelemetry.Lamp_select_left`, `TPTelemetry.Lamp_select_right` | menu select buttons | | 9: Initial D 4 to 8 and Zero (older versions), GTI Club |
| `TPTelemetry.Lamp_action` | the cabinet's extra button: WMMT's interruption button, GTI Club's action button | | 6 |
| `TPTelemetry.Lamp_leader` | in the lead: the game's own leader lamp, or made from the position | racing in 1st place, for a game with `TPTelemetry.Car_position` | 25 |
| `TPTelemetry.Lamp_checkpoint` | a checkpoint passed or time extended (held 1 to 2 s) | | 11 |
| `TPTelemetry.Lamp_final_lap` | on the final lap | | 5: GRID, GTI Club, both Mario Karts (v1.18, USA), Sega Rally 3 |
| `TPTelemetry.Lamp_shift` | shift or over-rev light (GRID's dial: 0.5 with one light, 1 with both) | racing at 90% of the car's limiter or more (`TPTelemetry.Car_rpm_frac` 0.9) | 5: both Battle Gears, GRID, OutRun 2, WMMT3DX+ |
| `TPTelemetry.Lamp_warning` | any on-screen warning: WRONG WAY (Scud Race, Sega Rally 3), Brake! (Battle Gear 4 Tuned), SHIFT UP (OutRun 2) | | 4 |
| `TPTelemetry.Lamp_boost` | boost or nitro | `TPTelemetry.Car_boost` 0.9 or more | 3: H2Overdrive, R-Tuned, Sega Race TV |
| `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_green`, `TPTelemetry.Lamp_blue`, `TPTelemetry.Lamp_white` | the cabinet's main colour lamps or LEDs | | 13, 11, 13, 11 |
| `TPTelemetry.Lamp_marquee` | billboard, marquee, side or seat lighting | | 13 |
| `TPTelemetry.Lamp_brake` | brake light | `TPTelemetry.Car_brake` 0.1 or more | 1: MotoGP |

Each game's own list is in the pack's Game_Setup.md (**Common lamps**), and each row's formula in Game_Formulas.md.

## Notes

* **Colour lamps:** where a cabinet has several colour groups (Mario Kart's under-lamps and billboard), the main
  group is `TPTelemetry.Lamp_red` to `TPTelemetry.Lamp_white` and the billboard is `TPTelemetry.Lamp_marquee`. Battle Gear 4 Tuned's colour lamps dim in
  eight steps, so they read 0 to 1 in between.
* **Leader:** Model 2 Sega Rally's own lamps never lit for the lead in any log, so its `TPTelemetry.Lamp_leader` is made from the
  position; WMMT3DX+'s is lit while ahead of the CPU rival, Initial D 3's and Zero's while level with or ahead of the
  rival.
* **Left per game:** Mario Kart's item lamp and side LEDs, Wacky Races' seat and slot lamps, Chase H.Q. 2's Pato
  lamps, fog lights, Battle Gear's Key, Online and Hazard, Dead Heat's dash and keypad, and Initial D 3's `lamp0` to
  `lamp7` until a recording shows which lamp each is.
* **Scud Race and Daytona USA 2 Power Edition:** their lamp rows were called `lamp_start`, `lamp_view1`... before
  19 November 2026. They are now `lampstart`, `lampview1`..., as OutputBlaster names them everywhere else, so
  `lamp_<name>` means the common lamps only (`TPTelemetry.SMSCUD_lamp_start` is now `TPTelemetry.SMSCUD_lampstart`).
