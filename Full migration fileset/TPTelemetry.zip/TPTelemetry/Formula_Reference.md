# Formula reference

Every row in a game's table can have a formula. A formula works out the value the row publishes
to SimHub, from the row's own memory read, from other rows, or from the sources every game shares
(TeknoParrot's shared memory, game outputs, USB capture).

Hovering over the **Formula** column heading on the settings page shows a short version of this
list. Each game's own formulas, with what each row does, are in **Game_Formulas.md** in the game
profiles pack: they're the best examples to copy.

## Raw, formula and output

| Column | What it shows |
|---|---|
| **Raw** | The number read from memory, before the formula (memory rows only). |
| **Formula** | Optional. On a memory row, `value` in the formula means the Raw number. Empty: the row publishes Raw as it is. |
| **Output** | The result: what SimHub gets as `TPTelemetry.<PREFIX>_<row>`. |

So a memory row with the formula `value / max_speed` shows the game's speed in Raw and the speed
divided by Max speed in Output. A computed row has no Raw: its formula is all there is.

## Names a formula can use

| Name | Meaning |
|---|---|
| `value` or `x` | the row's Raw value (memory rows only) |
| other row names | that row's Output this sample, e.g. `speed`, in any order (the plugin works out which to calculate first, and flags loops) |
| `max_speed`, `max_revs` | the game's **Max speed** and **Max revs** boxes above the table. Blank counts as 1; the smallest value allowed is 1 |
| `dt`, `t` | seconds since the last sample; seconds since the game was attached |
| `pi`, `g` | constants (`g` = 9.80665, for G-forces) |
| `true`, `false` | 1 and 0 |
| `tp_jvs0` .. `tp_jvs15`, `tp_connected` | TeknoParrot's shared memory slots (32-bit values), and 1 while it's available |
| `out_<name>` | a game output (lamp, LED, RPM...) received over the network, e.g. `out_LampStart`. Spaces become `_`: `out_Intake_Left`. See Game_Outputs.md |
| `ffb_force`, `ffb_spring`, `ffb_damper`, `ffb_friction`, `ffb_autocenter`, `ffb_rumble`, `ffb_rumble_large`, `ffb_rumble_small`, `ffb_steer`, `ffb_throttle`, `ffb_brake`, `ffb_clutch`, `ffb_activity`, `ffb_connected`, `ffb_raw0` .. `ffb_raw7` | USB capture of the force feedback sent to a wheel. See USB_Capture.md |

These names are reserved, so a row can't be called any of them, or `Connected`.

## Common values: car_ rows

Rows named `car_impact`, `car_speed` and so on feed the common values every game shares, published
as `TPTelemetry.Car_...` and read by the ready-made SimHub effects. Their names, and what each formula
should give, are in [SimHub_Effects.md](SimHub_Effects.md#adding-car_-rows-to-your-own-profile). Leave
them unticked: they feed `Car_...`, not a property of their own.

## Operators

| | |
|---|---|
| arithmetic | `+ - * / % ^` (`^` is power) |
| comparison | `< <= > >= == !=` give 1 or 0 |
| logic | `&& \|\| !` give 1 or 0 |
| choice | `condition ? a : b` |

Numbers are decimal (no hex in formulas). A single `=` is an error: comparisons use `==`.

## Functions

**Maths**

| Function | Gives |
|---|---|
| `abs(v)`, `sign(v)` | size without direction; -1, 0 or 1 |
| `min(a, b, ...)`, `max(a, b, ...)` | smallest, largest |
| `clamp(v, lo, hi)` | v kept between lo and hi |
| `round(v[, digits])`, `floor(v)`, `ceil(v)` | rounding |
| `sqrt pow exp log sin cos tan atan2(y, x) hypot(a, b)` | the usual maths |
| `if(c, a, b)` | same as `c ? a : b` |
| `deadzone(v, d)` | 0 while abs(v) is d or less, then v moved d towards 0 (so it rises smoothly from 0) |
| `map(v, inLo, inHi, outLo, outHi)` | rescales v from one range to another |
| `valid(v, fallback)` | fallback while v has no value (blank, or a division by zero) |
| `wrap(angle, period)` | an angle brought into ±half a turn; `wrap(a - b, 360)` is the difference between two headings |

**Over time** (each use keeps its own history, sampled every tick)

| Function | Gives |
|---|---|
| `slope(expr, window_s)` | rate of change per second, fitted over the last window_s seconds |
| `avg(expr, window_s)` | average over the window |
| `ema(expr, tau_s)` | smoothed value (exponential moving average with time constant tau_s) |
| `minw(expr, window_s)`, `maxw(expr, window_s)` | smallest or largest over the window; `maxw(x, 0.3)` holds a short pulse for 0.3 s so SimHub sees it |
| `delta(expr)`, `rate(expr)`, `prev(expr)` | change since the last sample; change per second; last sample's value |
| `unwrap(angle, period)` | removes the jump at 360 to 0 so `slope()` works on headings |
| `integrate(expr)` | running total of expr × seconds, e.g. distance from speed |
| `hold(expr, condition)` | the last value of expr from when the condition was true (no value until then, so wrap it: `valid(hold(...), 0)`) |

Time-series functions start again when the game exits, when the game is switched, and when the
table is edited.

**Bits** (for values that pack several things into one number)

| Function | Gives |
|---|---|
| `byte(v, n)` | byte n (0 = lowest) |
| `bits(v, shift, count)` | count bits starting at bit shift |
| `band bor bxor shl shr` | bitwise and, or, xor, shift left, shift right |
| `signed8(v)`, `signed16(v)` | a byte or 16-bit value read as signed |

## Blank values

A row has no value when its memory can't be read (the game isn't running, or a pointer is null),
when a source it uses isn't there (no TeknoParrot, no outputs yet, USB capture off), or when the
formula divides by zero. The table shows `-`, recordings leave the cell empty, and SimHub gets 0.

A formula built on a blank row usually gives a blank too. Comparisons are the exception: `x > 0`
gives 0 and `x != 0` gives 1 when x is blank, so a row such as `ffb3 != 0 && ffb4 != 0` can read 1
before the game is running.

## Examples

```
value * 3.6                                       m/s to km/h
value / max_speed                                 speed as 0 to 1 (raw speed while Max speed is blank)
round(value)                                      a gear stored as a decimal
ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g   forward G from km/h speed, whatever Max speed is
clamp(value / 9000, 0, 1)                         a rev bar from 0 to 1
maxw(delta(crash_count) != 0, 0.3)                1 for 0.3 s each time a counter changes
band(ob_lamps, 8) != 0                            1 while bit 3 of a lamp byte is on
```

`profiles/DUMMY.json` (in the plugin download) has more worked examples: cornering G from heading,
drift angle, wheelspin, road rumble from the car's height. See the README's dummy profile section.

## Why acceleration is worked out this way

Values are sampled on the plugin's own thread (120 times a second by default) with precise
timestamps, not on SimHub's update loop. Arcade games usually update speed 60 times a second, so a
plain two-point difference jumps between zero and double the true value. `slope()` fits a line over
a short window instead. In the test suite, a 60 Hz staircase sampled at 120 Hz with timing jitter
gives a steady 1.02 G within 0.05 G, against swings of about 1.7 G for the plain difference. A
longer window is smoother but lags; 0.1 s is a starting point.

The speed must be in km/h for `/ 3.6`. For mph use `/ 2.237`; for m/s drop the `/ 3.6`. If the
speed row divides by Max speed, multiply it back (`speed * max_speed`) as the pack's profiles do.

Cornering G can't come from speed alone. With heading or world position addresses it can be built
from those: the dummy profile has worked examples of both.
