# Game outputs (lamps, LEDs, RPM and so on)

Arcade games drive the cabinet's lamps, LEDs, seat motors and displays. These are "outputs". TP
Telemetry receives them from TeknoParrot games, MAME, Supermodel, Flycast and the Model 2 Emulator, and
publishes each one to SimHub, so SimHub can drive the real thing: an Arduino that lights the start
button, a shift light, a gauge. No MAMEHooker needed.

**Most TeknoParrot game profiles don't need any of this.** For about 30 games, the game profiles
pack reads the outputs straight from game memory (the same addresses and bit masks OutputBlaster's
own code uses), so their lamp rows work with nothing else running. The pack's README lists the few
outputs that still need OutputBlaster.

## How it works

Outputs travel over MAME's network output protocol: the game (or OutputBlaster inside it) runs a
small server on TCP port 8000 and sends lines like `LampStart = 1`. TP Telemetry connects to
`127.0.0.1` on that port whenever something is listening there, and only listens; it never sends
anything back.

Each output appears in SimHub as `TPTelemetry.Output_<name>` (e.g. `TPTelemetry.Output_LampStart`)
the first time it's sent, and in formulas as `out_<name>`. Spaces and other characters that can't
go in a name become `_`: OutputBlaster's `Intake Left` is `Output_Intake_Left` and
`out_Intake_Left`. Lamps are usually 0 or 1; brightness, motors and displays 0 to 255.

Also published: `TPTelemetry.Outputs_Game` (the game sending them), `TPTelemetry.Outputs_Paused`
and `TPTelemetry.Outputs_Status`.

**Common lamps (plugin 0.20.0):** the game profiles pack also maps each game's lamps onto common names,
`TPTelemetry.Lamp_start`, `Lamp_view1`, `Lamp_leader` and so on, the same in every game, so one LED set-up serves
them all. See [Common_Lamps.md](Common_Lamps.md).

On the settings page, **Capture table values and FFB** has the **Outputs port** (8000 unless you
changed it in the game's settings) and a status line that reads, for example,
`Outputs: Connected: <game>, 9 outputs` or `Outputs: Looking for outputs on 127.0.0.1:8000`.

## Network outputs or MAMEHooker: one or the other

Each emulator sends its outputs one way at a time: as Windows messages (what MAMEHooker listens
for) or over the network (what TP Telemetry listens for). Switching an emulator to network outputs
means MAMEHooker stops getting them from it, including anything else MAMEHooker drove for that
game, such as gun recoil. If you need both, there are third-party bridges that pass network outputs
on as Windows messages.

Only one program can serve port 8000 at a time. That's fine when one game runs at a time.

## Setting up each emulator

### TeknoParrot (through OutputBlaster)

TeknoParrot's PC-based and Lindbergh games don't send outputs themselves; OutputBlaster (Boomslangnz,
GPL-3.0) does, from inside the game. (Games in TeknoParrot's own emulators can: see the next section.)

1. Put `OutputBlaster.dll` and `OutputBlaster.ini` in the game's folder. **A 64-bit game needs the
   64-bit DLL** (OutputBlaster 0.11's `x64` folder, for example); a 32-bit DLL can't load into it.
2. In `OutputBlaster.ini`, under `[Settings]`:
   ```
   OutputsSystem=1
   NetOutputsTCPPort=8000
   NetOutputsWithLF=0
   ```
   `OutputsSystem=0` is Windows messages for MAMEHooker; `1` is the network.
3. In TeknoParrot, tick **Enable Outputs** in the game's settings.

OutputBlaster supports around 60 TeknoParrot games. For six of them it also sends engine revs as
`RPM` (Daytona Championship USA and its New Season Edition, Sega Rally 3, Sega Racing Classic,
OutRun 2 SP and GRID), divided by 100 (by 10 on OutRun 2) to fit MAMEHooker's 0 to 255. The game
profiles pack reads the same value from memory for all but GRID, and gives real RPM.

### TeknoParrot's own emulators (Model 1, 2, 3, Viper, Vegas and others)

The games TeknoParrot runs in its own emulators (TeknoModel1, TeknoModel2, TeknoModel3, Hornet,
HNG64, GTI Club, Cobra, Zeus, Viper, Vegas, Hard Drivin', V Unit, AGX, Namco System 11/21/22/23, M2,
TPJC, Magic, Air) send outputs themselves, without OutputBlaster. In TeknoParrot, open the game's
settings and set **Outputs** to **Network Outputs** (the default is Windows Outputs, for MAMEHooker).
They then use the MAME protocol on port 8000 (CR line endings by default), which TP Telemetry reads.
This comes from TeknoParrotUI's source; which output names each game sends hasn't been checked yet.

### MAME

In `mame.ini` (or the game's own `.ini`), change

```
output                    windows
```

to

```
output                    network
```

or start MAME with `-output network`. MAME runs its own output server on port 8000. No OutputBlaster
files are needed. Output names are MAME's own and differ from game to game (`led0`, for example):
look in SimHub's property list for `TPTelemetry.Output_` while playing to see them.

### Supermodel (Model 3)

Change `-outputs=win` to `-outputs=net` on the command line, or set `Outputs = net` in
`Supermodel.ini`. The defaults are right for TP Telemetry:

```
OutputsTCPPort = 8000
OutputsUDPBroadcastPort = 8001
OutputsWithLF = 0
```

No OutputBlaster files are needed. An old Supermodel build that only knows `win` will refuse `net`
(it logs "Unknown outputs"); a newer build fixes that. Supermodel also sends a line naming its port,
which shows up as an `Output_tcp` property: ignore it. Supermodel's output names match
OutputBlaster's (`LampStart`, `LampView1`...), since OutputBlaster's output code came from it.

### Model 2 Emulator

The Model 2 Emulator has no outputs of its own: OutputBlaster provides them, which is why its files
are in the emulator's folder. It recognises the game by its window title and sends the lamps (start,
leader, view buttons). In that folder's `OutputBlaster.ini`, change `OutputsSystem=0` to
`OutputsSystem=1`, with `NetOutputsTCPPort=8000` and `NetOutputsWithLF=0` as above.

OutputBlaster's regular build reads the lamps at RAM+824, which only holds them when the emulator's own
game script moves them there: Daytona USA's does, STCC's and Sega Rally's don't. Those two send their
lamps to an I/O port whose last value the emulator keeps at exe+174CF0; a special STCC build of
OutputBlaster reads that instead.

The game profiles pack's Model 2 profiles (`M2DAYTONA`, `M2STCC`, `M2SRALLY`...) read the lamps and
the force feedback byte straight from the emulator's memory, so they need neither OutputBlaster nor
any extra Lua scripts in the emulator: Daytona's lamps from RAM+824, STCC's and Sega Rally's from
exe+174CF0.

### Flycast (NAOMI, NAOMI 2, Atomiswave)

In Flycast: **Settings, Network, Broadcast Digital Outputs** on. Flycast then serves outputs on TCP
port 8000, like MAME: lamps as `lamp0`, `lamp1`..., and for some driving games their force feedback
(`midiffb` for Initial D, Club Kart, The King of Route 66 and Sega Driving Simulator; `awffb` for
Maximum Speed and Faster Than Speed; `m3ffb` for 18 Wheeler and F355 Challenge), plus `tachometer` and
`speedometer` for Sega Driving Simulator. Flycast sends its values in hexadecimal; TP Telemetry 0.13.3
and later recognise Flycast from the first line it sends (`game = ...`) and read them correctly. Older
versions misread them. The game profiles pack has a `FLY...` profile for each of these games.

## Using outputs in SimHub

Because outputs are global (`Output_<name>`, not per game), the same SimHub setup works for every
game that uses the same name: `Output_LampStart` is the start lamp in any OutputBlaster or
Supermodel game. A game profile can also give an output a row of its own (a formula such as
`out_LampStart`), which then appears as `TPTelemetry.<PREFIX>_<row>` and in recordings.

Outputs aren't cleared when a game stops, only when the next one starts, so lamps keep their last
state in between.

## If nothing arrives

* The status line says **Looking for outputs**: nothing is serving the port. Check the emulator's
  setting above, that the game is running, and that the port numbers match.
* **Connected** but no outputs: the game hasn't sent any yet (many only send when a lamp changes),
  or OutputBlaster doesn't support this game.
* TeknoParrot: check **Enable Outputs** is ticked, the DLL is the right bitness, and the ini says
  `OutputsSystem=1`.
* Running TeknoParrot or the emulator as administrator? Then SimHub must be too.
