# USB capture and recordings

TP Telemetry can capture the force feedback a game sends to your wheel, as it travels over USB, and
read the wheel's steering and pedals from the same traffic. This is optional.

* **The game profiles pack doesn't need it.** No profile in the pack reads USB values: every
  common value (`Car_...`) comes from game memory, TeknoParrot's shared memory (`tp_jvs0` to
  `tp_jvs15`, for the games that use it) or network outputs, so every game works the same with it
  off.
* **Use it for** the force your wheel actually got (`FFB_force` and so on) in your own effects,
  steering and pedal positions, and checking a game profile's force decoding against the wheel.
* **Games whose force feedback is made by a code hook** (the FFB Arcade Plugin or FFB Blaster
  driving the wheel itself, as in OutRun 2 SP) never put the force in memory or in TeknoParrot's
  shared memory, so USB capture is the only place the plugin can see it. The pack README's "Without
  USB capture" section lists those games and which common values they lack. From 0.15.0 the plugin
  fills those in from the wheel force: see below.

## Effects from the wheel force (0.15.0)

With USB capture on and **Use the wheel's force for effects a game has no values for** ticked (it is
by default, under the capture tick box), any force-based common value the selected game has no
`car_` row for is worked out from the force your wheel got, the same way the pack does it for games
whose only force is the wheel force:

| Common value | From the wheel |
|---|---|
| `Car_impact`, `Car_impact_side` (and so `Car_impact_left`/`right`) | big, sudden changes in the force (more than 0.25 away from the force over the last 0.15 s), on the side the force came from |
| `Car_road_bump` | smaller sudden changes |
| `Car_cornering` (and `Car_corner_left`/`right`) | the force smoothed over 0.15 s, + from the right |
| `Car_vibration` | the wheel's rumble |

* A game's own rows always win: a game with `car_impact` keeps its own hits and only gets the rest
  from the wheel. A row whose formula is `0` means "none for this game" and isn't filled in (Sega
  Rally 3's road bump, where the force is steering and road texture all the time; GRID's road bump
  and cornering, where the FFB plugin's force is only hits, gear changes and kerbs).
* `TPTelemetry.Car_usb` is 1 while any common value comes from the wheel force.
* A game hit without a side (`car_impact_side` 0 at a hit) takes the side of the wheel force's kick
  within 0.3 s, when there is one (0.16.0). OutRun 2's hook pushes the wheel from the side at wall
  and traffic hits, but not at rear-end hits, which stay without a side.
* It works whatever produces the force: TeknoParrot, the FFB Arcade Plugin's hooks or memory scans,
  MAME's or Supermodel's own force feedback. It is the force after the FFB plugin's strength
  settings, and hits, bumps and cornering arrive mixed in one force, so it's an approximation.
* It assumes the force carries the car's handling. Where a game's force is only a few effects (GRID's
  Custom mode: wall hits, a sine at each gear change, kerbs), the gear changes would read as bumps and
  a held wall force as cornering; such games get 0 rows.
* With USB capture off, or nothing reaching the wheel, nothing changes.

Everything on this page lives in the **Capture table values and FFB** section of the settings page.

## Installing USBPcap

The plugin uses USBPcap, a free driver that copies USB traffic for programs to read. Wireshark is
not needed, though it installs USBPcap too.

1. Install USBPcap, either:
   * on its own, from the USBPcap website (desowin.org/usbpcap), or
   * by ticking **Install USBPcap** while installing Wireshark (wireshark.org).
2. **Restart the PC.** The driver doesn't attach to devices until you do.
3. **Run SimHub as administrator.** USBPcap only works for administrators. (Right-click SimHub,
   **Properties**, **Compatibility**, tick **Run this program as an administrator** to make it stick.)

The plugin finds `USBPcapCMD.exe` by itself in the usual USBPcap and Wireshark folders. If yours is
somewhere else, put its full path in the **USBPcapCMD.exe** box.

**Without USBPcap, nothing breaks.** Ticking the capture box just shows "USBPcap not found" in the
status line, the FFB values stay blank, and everything else (game memory, TeknoParrot, outputs,
recording) carries on as normal.

## Setting it up

1. Open **Capture table values and FFB** and click **Find Devices**.
2. Choose your wheel in the **Wheel** list. It usually shows its name, e.g.
   `[16] Logitech G25 Racing Wheel USB`.
3. Leave **Decoder** on **Auto** unless your wheel isn't recognised (see Supported wheels).
4. Tick **Capture force feedback sent to a wheel over USB**.
5. Start a game. The status line at the top of the section ends in `USB: Capturing ...,
   N commands/s`. While the game is driving the wheel, N should be above 0.

The choice is remembered, and capture starts with SimHub.

**The wheel is found again by itself (0.16.0).** Windows can give the wheel a different number after
a restart, after plugging it into another port, or when a G25 switches into its full mode. The
plugin remembers the wheel by its name (the text after the number, e.g. `Logitech G25 Racing Wheel
USB`) and learns its USB vendor and product IDs (046D:C299 for a G25). The FFB plugin's
`DeviceGUID` is made from the same IDs: it is SDL's joystick GUID, `030000006d04000099c2...` for a
G25 (046D written as `6d04`, C299 as `99c2`). USBPcap works below DirectInput and SDL, so it can't
use the GUID itself, but the name and IDs pick out the same wheel. So:

* when capture starts, it looks for that name on every USBPcap hub, preferring the hub and number
  you chose, and saves the new number if it changed;
* if USBPcapCMD stops, it starts it again: after 2 s, then 5, 10, and every 30 s;
* if the wheel goes quiet for 5 s, it checks whether the wheel has moved, at most every 30 s;
* if the wheel isn't plugged in, the status says **Waiting for** its name, and capture starts when
  it appears.

Find Devices is only needed to choose the wheel the first time, or to choose another one. Two
devices with exactly the same name are told apart by their number, so with two identical wheels,
check the right one is captured after a restart.

## What you get

| In formulas | In SimHub | Meaning |
|---|---|---|
| `ffb_force` | `TPTelemetry.FFB_force` | constant force on the wheel, -1 to 1 (0 when none) |
| `ffb_spring` | `TPTelemetry.FFB_spring` | centring spring strength, 0 to 1 |
| `ffb_damper` | `TPTelemetry.FFB_damper` | damper strength, 0 to 1 |
| `ffb_friction` | `TPTelemetry.FFB_friction` | friction strength, 0 to 1 |
| `ffb_autocenter` | `TPTelemetry.FFB_autocenter` | the wheel's own auto-centre strength, 0 to 1 |
| `ffb_rumble` | `TPTelemetry.FFB_rumble` | rumble or vibration, 0 to 1 (the stronger motor; 1 while a wheel's vibration effect plays) |
| `ffb_rumble_large` | `TPTelemetry.FFB_rumble_large` | large (low, heavy) rumble motor, 0 to 1. Gamepads only |
| `ffb_rumble_small` | `TPTelemetry.FFB_rumble_small` | small (high, buzzy) rumble motor, 0 to 1. Gamepads only |
| `ffb_steer` | `TPTelemetry.FFB_steer` | steering position read from the wheel, -1 full left to 1 full right |
| `ffb_throttle`, `ffb_brake`, `ffb_clutch` | `TPTelemetry.FFB_throttle` .. | pedals read from the wheel, 0 to 1 |
| `ffb_activity` | `TPTelemetry.FFB_activity` | commands sent to the wheel per second |
| `ffb_connected` | `TPTelemetry.FFB_connected` | 1 while capturing |
| `ffb_raw0` .. `ffb_raw7` | `TPTelemetry.FFB_raw0` .. | bytes of the last command |

`TPTelemetry.FFB_Status` holds the capture status as text. Steering and pedal layouts differ per
wheel; so far the G25's is decoded, and other wheels read blank for those.

### Showing them in a game's table

Game profiles don't include these, to keep their tables short. **Add FFB values to table** (in the
same section) adds 12 rows to the game you're viewing: `wheel_force`, `wheel_spring`,
`wheel_damper`, `wheel_friction`, `wheel_autocenter`, `wheel_rumble`, `wheel_rumble_large`,
`wheel_rumble_small`, `wheel_steer`, `wheel_throttle`, `wheel_brake` and `wheel_clutch`. They're
published like any other row (`TPTelemetry.<PREFIX>_wheel_force`) and recorded under the game's
prefix. Once all 12 are there, the same button reads **Remove FFB values from table**; it only
removes rows whose formula is just an `ffb_` value, never bigger formulas of your own.

## Supported wheels

The decoder is chosen from the wheel's USB ID, or set by hand. Only the G25 has been checked against
a real capture so far. The others (0.21.0) were written from each protocol's public description,
mostly the Linux drivers that support these wheels, so they are a starting point: send a test
pattern capture (below) and they can be checked and corrected.

| Decoder | Wheels | Source | Checked |
|---|---|---|---|
| **Logitech classic** | G25, G27, G29, G923 (PlayStation and PC), Driving Force GT, Driving Force Pro, Momo, Formula Force | Logitech's classic protocol (Linux lg4ff) | G25 only |
| **Logitech HID++** | G920, G923 (Xbox and PC), G PRO, RS50 | HID++ 2.0 force feedback (Linux hid-logitech-hidpp) | not yet |
| **Thrustmaster** | T300RS, T248, TX, TS-XW, TS-PC, T-GT II (shows up as a T300) | Thrustmaster's protocol (Linux hid-tmff2) | not yet |
| **Fanatec** | CSL Elite, CSL DD, DD Pro, ClubSport DD, Podium DD1 and DD2, ClubSport V2 and V2.5, CSR Elite (in PC mode) | Fanatec's protocol (Linux hid-fanatecff) | not yet |
| **USB PID** | Moza (R3 to R21), Simucube, VRS, Cammus, Asetek, PXN, OpenFFBoard | the USB standard for force feedback (PID) | not yet |
| **Xbox 360 / XInput, wired** | Xbox 360 pads, and wheels and sticks that copy them (rumble) | Linux xpad | not yet |
| **Xbox One / Series, wired** | rumble | Linux xpad | not yet |
| **Raw** | anything else | | |

* **USB PID wheels** describe their own message layout. On the PC running SimHub the plugin asks
  Windows for it (the status line ends in "layout from Windows"). If Windows can't say, a capture
  that sees the wheel being plugged in carries it ("layout from the wheel"), and failing both the
  plugin assumes the layout most of these wheels share ("layout guessed").
* **Which way is +:** on the G25, `ffb_force` is + for a force from the right. For the new decoders
  the sign comes from the protocol descriptions and needs a capture to confirm.
* **Steering and pedals** over USB are only decoded for the G25. SimHub reads every wheel's steering
  and pedals itself (its controller input), so the USB values aren't needed for those.
* **Raw**: `ffb_activity` and the `ffb_raw` bytes still work, so you can see that commands arrive
  and experiment in formulas.

## Capturing a racing wheel: adding or checking support

A capture is the USB traffic between the PC and your wheel, saved to a file. It is how a decoder is
written for a wheel the plugin doesn't know, and how one written from a protocol description is
checked against the real thing (every decoder above except the G25's needs one). One capture covers
a whole family of wheels that share a protocol.

### Before you start

1. Install USBPcap and restart the PC, run SimHub as administrator (see Installing USBPcap above).
2. Keep your wheel's own software running as usual (Moza Pit House, Fanatec's driver, Thrustmaster's
   control panel, Logitech G HUB), and put the wheel in PC mode where it has one.
3. In **Capture table values and FFB**, click **Find Devices**, choose your wheel, set **Decoder** to
   **Raw bytes only**, and tick capture. The status line should end in **Capturing**.

### Record Test Pattern (best: about 40 s, no game needed)

**Record Test Pattern** records the USB traffic while the plugin plays a fixed set of forces on the
wheel through DirectInput, the way games do: a push one way at 25% then 50%, the other way at 25%
then 50%, a 10 Hz vibration at 30%, then a spring, a damper and friction at 50%. Each step's start
and stop time goes to a `.txt` log beside the capture, so every USB command can be matched to a force
that's known, which is much quicker to decode than a game.

1. Close games and anything else using the wheel (the test needs the wheel to itself).
2. Click **Record Test Pattern**, keep a hand on the wheel, and let it run (about 30 s of forces).
   The forces stay at 50% or less, but a direct drive base is still strong.
3. Click **Open Captures Folder** and send the newest `_testpattern` capture (`.pcapng` or `.pcap`)
   **and** its `.txt` log, with the wheel's make, model, firmware version and mode (PC, PS4...).

The test pattern is played by `TPTelemetryFfbTest.exe`, beside the plugin (it runs on its own, so
nothing it does can affect SimHub). If the log says "no force feedback wheel found" or "Acquire
failed", another program has the wheel: close it and try again.

### Record 60 s Capture (in a game)

**Record 60 s Capture** saves 60 seconds of traffic while you drive. Use it as well as the test
pattern when a game's force feels wrong, or instead of it if the test pattern won't run.

1. Set up as above, start a game with strong force feedback, click **Record 60 s Capture**.
2. Drive: steer full left and right, press each pedal, hit walls on each side, drive over kerbs.
   Note roughly when each hit happens and which side.
3. Send the newest capture file with the wheel's make and model and your notes.

The files open in Wireshark, so you can look at them yourself too. Both buttons only work while
capture is running.

## Recordings and blank cells

**Record Values** saves every row of the game being viewed, plus the FFB, TeknoParrot and output
values and (0.16.0) the common values SimHub got (`Car_` columns, after the in-race gate and the
USB stand-in), to a spreadsheet (CSV) file at the poll rate, 120 rows a second by default. Files go to
`SimHub\PluginsData\TPTelemetry\Recordings\` (**Open Recordings Folder**), named with the date, time
and game, and recording stops by itself after 15 minutes. **Mark Event**, or the
`TPTelemetry.Mark` action on a wheel button, numbers a moment in the `marker` column.

Recording never needs USBPcap. Anything that couldn't be read at that moment is left as an empty
cell:

| Blank columns | Usually means |
|---|---|
| all `FFB_` columns | USB capture is off, USBPcap isn't installed, SimHub isn't running as administrator, or the wrong device is chosen |
| one `FFB_` column blank at first, then filled | normal: a value stays blank until the game first sends that kind of command (some never send a damper, say) |
| `FFB_rumble_large`, `FFB_rumble_small` on a wheel | normal: only gamepads have two motors |
| `FFB_steer`, `FFB_throttle`... | the wheel's steering and pedal layout isn't decoded yet (only the G25's is) |
| all `TP_jvs` columns | TeknoParrot isn't running (its shared memory only exists while it is), or the game doesn't use it |
| the game's memory rows (and `attached` 0) | the game wasn't running or attached yet, or a pointer was null (common in menus and before a race) |
| one memory row | that row's address or pointer chain didn't resolve at that moment |
| `Output_` columns | no outputs were coming in: see Game_Outputs.md |
| a computed row | something it's worked out from was blank, or it divided by zero |

In the table on the settings page the same blanks show as `-`, and the **Status** column says why.
SimHub itself gets 0 for a blank value.
