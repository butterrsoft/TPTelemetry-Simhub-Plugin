# Common properties (the SimHub effects' values)

**This file lists the common properties the TP SimHub effects are built from:** the `TPTelemetry.Car_...` values every
game profile feeds, what each means, and which effects read it. Two companion files cover the other common properties:
[Common_Dashboard.md](Common_Dashboard.md) (speed in km/h and mph, clocks, laps, position, pedals: one dashboard for every
game) and [Common_Lamps.md](Common_Lamps.md) (`TPTelemetry.Lamp_...`: one LED or lamp setup for every game).
[SimHub_Effects.md](SimHub_Effects.md) says how to make, import and tune the effect profiles.

Plugin 0.20.0, 19 November 2026.

**Using them in SimHub:** each name below is the full property name. In an NCalc formula write it in square brackets, `[TPTelemetry.Car_impact]`; in a JavaScript formula, `$prop('TPTelemetry.Car_impact')`. SimHub's property picker lists them under the TPTelemetry plugin.

## How a game feeds them

1. Each game profile ends with unticked rows named `car_<name>` (built by the pack's `commonrows.py`). Each maps that
   game's own values onto one agreed meaning and range.
2. The plugin reads those rows from whichever game is selected and publishes `TPTelemetry.Car_<name>`.
3. The "TP -" effects read only `TPTelemetry.Car_...`, so one SimHub effect profile serves every game.

A game without a particular row leaves the values built on it at 0 (silent). Every effect value is 0 outside a race
(`car_in_race` 0): effects run from the start to the finish line. The raw values marked **raw** below are never gated,
so gauges can show them.

## The rows a profile provides (`car_...`)

| Row | Must hold | Profiles with it (19 November 2026) |
|---|---|---|
| `car_in_race` | 1 while racing (not menus or attract mode). Missing: 1 while the game is attached | 30 |
| `car_speed` | speed in the game's own units (not divided by Max speed) | 30 |
| `car_rpm` | engine RPM (not divided by Max revs) | 29 |
| `car_gear` | gear: 1 = first, 0 neutral, -1 reverse | 23 |
| `car_accel_g` | forward G: + speeding up, - slowing down | 22 |
| `car_impact` | a hit, 0 to 1 (about 0.6 an ordinary hit, 1 a big crash) | 82 |
| `car_impact_side` | side of the hit: -1 left to 1 right, 0 unknown or straight on | 78 |
| `car_wall_contact` | scraping a wall: -1 left, 1 right, 0 none (in between: how hard) | 14 |
| `car_road_bump` | short bumps and joints, 0 to 1 | 78 |
| `car_rumble_strip` | 1 on a ripple strip or kerb | 16 |
| `car_off_road` | rough ground or off the track, 0 to 1 | 14 |
| `car_grip_loss` | sliding, 0 gripping to 1 | 20 |
| `car_cornering` | cornering load, -1 to 1: + turning right | 79 |
| `car_airborne` | 1 in the air (0.3 to 0.5 over a crest in some games) | 15 |
| `car_boost` | boost or nitro, 0 to 1 | 11 |
| `car_vibration` | the game's own rumble command, 0 to 1 | 48 |
| `car_throttle` | throttle pedal, 0 to 1. Missing: the engine effects don't follow the throttle | 8 |
| `car_rpm_frac` | revs as a fraction of this car's limiter, 0 to 1. Missing: revs / Max revs | 5 |
| `car_drift` | drifting, 0 to 1. Missing: \|drift angle\| / 40 degrees | 12 |
| `car_drift_angle` | drift angle, degrees: + pointing right of the car's path | 11 |

Each game's own list is in the pack's Game_Setup.md, and each row's formula in Game_Formulas.md.

**With USB capture on** (plugin 0.15.0 or later), a game with no row for `car_impact`, `car_impact_side`,
`car_road_bump`, `car_cornering` or `car_vibration` gets it from the force its wheel was sent; `TPTelemetry.Car_usb` is 1 while
that happens.

## What the plugin publishes (`TPTelemetry.Car_...`)

| Property | Meaning | Effects that read it |
|---|---|---|
| `TPTelemetry.Car_in_race` | 1 while racing | (gates all the others) |
| `TPTelemetry.Car_speed` | speed, the game's units, **raw** | |
| `TPTelemetry.Car_rpm` | engine RPM, **raw** | |
| `TPTelemetry.Car_gear` | gear, **raw** | |
| `TPTelemetry.Car_accel_g` | forward G, **raw** | |
| `TPTelemetry.Car_speed_frac` | speed / Max speed, 0 to 1 | Wind (fans) |
| `TPTelemetry.Car_rpm_frac` | revs / the car's limiter (or Max revs), 0 to 1 | (feeds Engine, Rev limiter) |
| `TPTelemetry.Car_engine` | engine vibration strength: 0.35 at idle to 1 at the limiter; 60% of that off the throttle | Engine, Pedal Gas/Clutch/Box: Engine |
| `TPTelemetry.Car_engine_hz` | engine pitch, 25 Hz at idle to 60 Hz at the limiter | Engine (pitch) |
| `TPTelemetry.Car_rev_limit` | stutter, 8 times a second, at 97% of the limiter or more | Rev limiter, Pedal Gas/Box: Rev Limiter |
| `TPTelemetry.Car_road` | road texture: TPTelemetry.Car_speed_frac, cut while airborne | Road (speed) |
| `TPTelemetry.Car_shift` | 1 for 0.15 s after a gear change | Gear change, Pedal Clutch/Box: Gear Change |
| `TPTelemetry.Car_impact` | hit, 0 to 1 | Pedal Brake/Box: Collision |
| `TPTelemetry.Car_impact_left`, `TPTelemetry.Car_impact_right` | the hit on each side: full on the side hit (or both if unknown), 30% on the other | Collision |
| `TPTelemetry.Car_impact_side` | side of the last hit, **raw** | |
| `TPTelemetry.Car_wall_contact` | wall scrape side, **raw** | |
| `TPTelemetry.Car_wall_left`, `TPTelemetry.Car_wall_right` | scraping a wall on that side, 0 to 1 | Wall scrape |
| `TPTelemetry.Car_road_bump` | bumps and joints, 0 to 1 | Road bump |
| `TPTelemetry.Car_rumble_strip` | 1 on a ripple strip | Rumble strip |
| `TPTelemetry.Car_off_road` | rough ground, 0 to 1 | Off-road |
| `TPTelemetry.Car_grip_loss` | sliding, 0 to 1 (a game with no slip value gives its drift here) | Grip loss, Pedal Gas: Wheelspin |
| `TPTelemetry.Car_drift` | drifting, 0 to 1 | Drift |
| `TPTelemetry.Car_drift_angle` | drift angle, degrees, **raw** | |
| `TPTelemetry.Car_braking` | slowing at 1.5 G or more reads 1 | Braking and acceleration, Pedal Brake/Box: Braking |
| `TPTelemetry.Car_accelerating` | speeding up at 0.8 G or more reads 1 | Braking and acceleration |
| `TPTelemetry.Car_cornering` | cornering load, -1 to 1, **raw** | |
| `TPTelemetry.Car_corner_left`, `TPTelemetry.Car_corner_right` | cornering load on each side (turning right loads the left), 0 to 1 | Cornering |
| `TPTelemetry.Car_airborne` | 1 in the air | (cuts Road; feeds Landing) |
| `TPTelemetry.Car_landed` | 0.25 s pulse on landing: 0.4 after a brief lift, 1 after 0.25 s or more in the air | Landing |
| `TPTelemetry.Car_boost` | boost, 0 to 1 | Boost, Wind: Boost gust |
| `TPTelemetry.Car_vibration` | the game's own rumble, 0 to 1 | Game rumble |
| `TPTelemetry.Car_throttle` | throttle pedal, 0 to 1 | (shapes Engine) |
| `TPTelemetry.Car_usb` | 1 while some values come from the wheel force over USB | |

The plugin also publishes dashboard values (`TPTelemetry.Car_speed_kmh`, `TPTelemetry.Car_time_left` and so on, in
[Common_Dashboard.md](Common_Dashboard.md)) and lamps (`TPTelemetry.Lamp_...`, in [Common_Lamps.md](Common_Lamps.md)). No effect
reads those.

## Scaling: Max speed and Max revs

`TPTelemetry.Car_speed_frac` is speed over the game's **Max speed**; `TPTelemetry.Car_rpm_frac` is revs over the car's own limiter where the
profile has `car_rpm_frac`, else over the game's **Max revs**. Left blank, the speed and engine effects stay silent.
The pack sets both for every game where they are known (Game_Setup.md says which).
