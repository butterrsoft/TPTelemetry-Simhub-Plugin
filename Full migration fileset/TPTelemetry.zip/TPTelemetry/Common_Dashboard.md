# Common dashboard values

**This file lists the common properties for SimHub dashboards:** `TPTelemetry.Car_...` values in one agreed unit for
every game, so one dashboard serves every game TP Telemetry reads. Companion files:
[Common_Properties.md](Common_Properties.md) (the values the SimHub effects are built from) and
[Common_Lamps.md](Common_Lamps.md) (`TPTelemetry.Lamp_...`).

Plugin 0.20.0, 19 November 2026.

**Using them in SimHub:** each name below is the full property name. In an NCalc formula write it in square brackets, `[TPTelemetry.Car_speed_kmh]`; in a JavaScript formula, `$prop('TPTelemetry.Car_speed_kmh')`. SimHub's property picker lists them under the TPTelemetry plugin.

## How they work

A game profile maps its own values onto unticked rows named `car_<name>`; the plugin publishes them as
`TPTelemetry.Car_<name>` from whichever game is selected. A game without a row reads 0 (or the stand-in given below).

Dashboard values are **not** tied to racing by the plugin: they show whatever the game gives. Some profiles read 0
outside a race on purpose (Sega Rally 3, GRID, SWDC, Initial D 3 and Zero, Scud Race, Daytona USA 2 Power Edition and,
for speed, revs and gear, OutRun 2), so menus and attract demos show nothing. `TPTelemetry.Car_in_race` tells a dashboard when a
race is on.

## Speed

| Property | Meaning | For |
|---|---|---|
| `TPTelemetry.Car_speed_kmh` | speed, km/h | a number |
| `TPTelemetry.Car_speed_mph` | speed, mph (`TPTelemetry.Car_speed_kmh` / 1.609344) | a number |
| `TPTelemetry.Car_speed_frac` | speed / Max speed, 0 to 1 (0 outside a race) | a dial or bar |
| `TPTelemetry.Car_max_speed` | the game's Max speed setting (0 while blank) | labelling a dial's top |
| `TPTelemetry.Car_speed` | speed in the game's own units, raw | (as before) |

`TPTelemetry.Car_speed_kmh` needs the game's units to be known. 26 profiles have it: every checked game, Sega Rally 3 (converted
from the screen's mph), the WMMT5 and 6 family, and Initial D The Arcade and Season 5 (probably km/h, not yet checked).
Mario Kart's speed is the game's own unit, taken as km/h (a kart has no speedo). Crazy Taxi, D1 Grand Prix, Storm
Racer G and the Flycast driving simulator read 0 until their units are checked. Max speed is in the units of
`TPTelemetry.Car_speed`, which is km/h in most games and mph in Sega Rally 3.

## Revs and gear

| Property | Meaning | For |
|---|---|---|
| `TPTelemetry.Car_rpm` | engine RPM | a number |
| `TPTelemetry.Car_rpm_dial` | revs / Max revs, 0 to 1 (not tied to racing) | a rev counter's needle |
| `TPTelemetry.Car_rpm_frac` | revs / this car's limiter (or Max revs), 0 to 1 (0 outside a race) | a shift-light bar |
| `TPTelemetry.Car_max_revs` | the game's Max revs setting, RPM (0 while blank) | labelling a dial's top |
| `TPTelemetry.Car_rev_limit_rpm` | this car's rev limit, RPM, where the game gives it (Initial D 3, GRID, OutRun 2, Scud Race, Daytona 2 PE, WMMT3DX+); else Max revs | marking the redline |
| `TPTelemetry.Car_gear` | gear: 1 = first, 0 neutral, -1 reverse | a number |
| `TPTelemetry.Car_gear_text` | the gear as text: `R`, `N`, `1`, `2`...; empty for a game with no gear | a gear display |

## Race

| Property | Meaning | Profiles with it |
|---|---|---|
| `TPTelemetry.Car_in_race` | 1 while racing (start to the finish line) | 30 |
| `TPTelemetry.Car_position` | race position, 1 = first (SWDC: your class place, as the screen shows it) | 12 |
| `TPTelemetry.Car_lap` | the lap you are on, 1 = first | 12 |
| `TPTelemetry.Car_laps_total` | laps in the race | 5 |
| `TPTelemetry.Car_final_lap` | 1 on the final lap (the same as `TPTelemetry.Lamp_final_lap`) | 5 |
| `TPTelemetry.Car_time_left` | time left on the clock (RT), seconds | 20 (8 of them from cheat tables, not yet checked) |
| `TPTelemetry.Car_race_time` | the race clock (TT), seconds from GO | 19 |
| `TPTelemetry.Car_lap_time` | the current lap's time (Sega Rally and OutRun 2: the stage's), seconds | 6 |
| `TPTelemetry.Car_gap` | distance to the rival, metres: + ahead, - behind (Initial D 3 and Zero, WMMT3DX+) | 3 |

## Driver and car

| Property | Meaning | Profiles with it |
|---|---|---|
| `TPTelemetry.Car_throttle` | throttle pedal, 0 to 1 | 8 |
| `TPTelemetry.Car_brake` | brake pedal, 0 to 1 | 8 |
| `TPTelemetry.Car_steer` | steering, -1 full left to 1 full right | 8 |
| `TPTelemetry.Car_boost` | boost or nitro, 0 to 1 | 11 |
| `TPTelemetry.Car_drift_angle` | drift angle, degrees: + pointing right of the car's path | 11 |
| `TPTelemetry.Car_accel_g` | forward G: + speeding up, - slowing down | 22 |

Each game's own list is in the pack's Game_Setup.md (**Common dashboard values**), and each row's formula in
Game_Formulas.md.

## Tips

* Times are seconds (62.35 is 1:02.35); format them as minutes and seconds in the dashboard's text formula.
* A dial with a fixed scale (0 to 300 km/h, say) reads `TPTelemetry.Car_speed_kmh` directly; a dial scaled to each game reads
  `TPTelemetry.Car_speed_frac` or `TPTelemetry.Car_rpm_dial` from 0 to 1, with `TPTelemetry.Car_max_speed` or `TPTelemetry.Car_max_revs` as the top label.
