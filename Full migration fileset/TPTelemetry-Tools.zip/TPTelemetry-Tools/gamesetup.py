"""Writes Game_Setup.md into the game profiles pack: how to set up each game, all games in one file,
with an index first. What each game needs (TeknoParrot's shared memory, OutputBlaster, an emulator's
network outputs, the 64-bit helper, USB capture) is worked out from its profile, so it can't drift
from the profiles; NOTES below adds what a profile can't say (versions, exe names, what's been checked).

memgames.py runs it at the end; on its own:   python3 gamesetup.py <pack folder>
"""
import json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import packlayout, commonrows

# The force-based common values the plugin can fill from the USB capture (plugin 0.15.0).
USB_STAND_INS = [('impact', 'hits'), ('road_bump', 'road bumps'), ('cornering', 'cornering'), ('vibration', 'rumble (from rumble motors, so pads more than wheels)')]
# Games where the wheel force is known to add nothing (it's made from values the profile already reads).
USB_NOTHING = {'GRID'}
FFB_CHANNELS = r'\bffb_(force|spring|damper|friction|autocenter|rumble|rumble_large|rumble_small|steer|throttle|brake|clutch|activity|connected|raw[0-7])\b'

# Checked against Alexis's recordings (or files); everything else is a starting point.
CHECKED = {
    'WMMT3DXP': "the force rows (joints, hits, walls, slides) in recordings of 29 October and 1 November 2026. The memory rows read the "
                "game's own variables, found in its code (Alexis's `main`, 11 November 2026), and were checked in her recording of "
                "11 November 2026 (18:36 and 20:15): speed, gear, the dial, race state from the countdown to the line, time left, rival gap, "
                "slide and steering signs, the jump, car hits. The side of car hits is still to work out",
    'WMMT5DXP': 'recordings of 29 October, 1 and 3 November 2026',
    'OUTRUN2SP': "recordings of 2 and 3 November 2026 (the last with USB capture), and the rows from the game's own code in a recording of 11 November 2026 and her answers (GO to the finish line, the speedo, stages, crash motions and what they are, drift sign, slipstream, the fork arrow), and three of 12 November (car hits and their side without USB, the modes, time up, attract mode)",
    'SR3': "a recording of 2 November 2026, with USB capture; four of 12 November (attract mode, the jumps, hits she named) and one of 16 November 2026 with the rows from the game's code (the player state from the attract mode to the results, checkpoints, lap lines, laps, position, WRONG WAY)",
    'SWDC': 'four recordings of 3 November 2026 (version 2.30), one with USB capture; the rows from the game\'s own data in her race of 19 November 2026 (SWDC-11)',
    'GRID': "a recording of 3 November 2026, with USB capture; the dial values (speed, revs, limiter, gear, throttle) in Cheat Engine and seven recordings (4 November 2026); the race rows from the game's code in two recordings of 12 November 2026 (GO, the pause, TIME OVER, three laps to the finish line, the attract mode) and her answers (the TT on screen, lap times)",
    'BG4JP': "Alexis's recordings of 10 November 2026 (a Golf GTI race with four cars; a time trial in a fast car to the finish; reverse in a Trueno): speed, revs, gears, positions, the leader, wall hits and scrapes by side, car contact on every side, and the menu problem (the race flag stays on), the nitro (wall bit 2), the finish (race phases 8 and 9), reverse, time left, laps and a checkpoint, wheelspin, time up, the drift angle (her drifts read 20 to 48 degrees, following the wheel), the nitro against the game's nitro timer, the Brake! warning (from the car navigation, 11 November)",
    'MKGPDX118': "the game's code (Alexis's MK_AGP3_FINAL.exe, 9 November 2026) and her recording of 11 November 2026 (a 100cc Grand Prix race, two laps): speed, revs, steering, the race state, drifts and their side and angle, drift hops, boosts, the kite glides, landings, the log ripple strips, the course's surfaces, water, hits and their side, spin-outs, coins, the item lamp; the attract demo checked to give no effects. Her second recording (11 November 2026, Mario cup course 1, four laps): place, laps, race time, the course's surfaces, item flips and a banana spin, hit sides. Drift meter stage and the LED colours still to find",
    'MKGPDXUSA': "the game's code (Alexis's MK_AGP3_FINAL.exe, USA, 11 November 2026) and her two recordings of 11 November 2026 (Bowser Jr cup courses 3 and 2, three laps each): speed, revs, steering, the race state and racing gate, drifts and their side and angle, glides, place, laps, race time, the courses' surfaces, the metal grilles, bomb blasts and item tumbles, hit sides, the item lamp (it flashes), the lamp words in menus and race",
    'M2STCC': "found in Alexis's RAM logs of 5 and 6 November 2026 against her readings from video, and checked in her TP Telemetry recording of 6 November 2026 (qualifying lap and a two-lap race)",
    'M2DAYTONA': "found in Alexis's RAM logs of 8 November 2026 (three laps with manual gears, and a run with automatic gears) against her readings and marks; the time extensions match her TP Telemetry recordings of that day",
    'M2SRALLY': "found in Alexis's RAM logs of 8 November 2026 (srallyc: a championship run, and Forest practice with automatic gears) against her readings and marks, and checked in two TP Telemetry recordings that day (the second with this profile)",
    'GTICLUB3': "found in the game's code from Alexis's Cheat Engine table, and checked in her recording of 8 November 2026 (intermediate course, manual, three laps); the time left still to check",
    'ID0V230': "found in the v2.30 exe's code (16 November 2026), and checked in Alexis's recordings of 16 November 2026 (the story's intro race in an AE86 Trueno, manual, with the tutorial's how-to demos; an Irohazaka time attack in a Savanna RX-7, automatic; USB capture on): speed, revs, gear, steering and drift signs, the race clock, checkpoints, places, contact with the other car, walls and guard rails by side, gutter, leaves, jumps and kerb drops, ripple strips. and the automatic's rev counter (a Silvia story race on Akina Lake, five readings)",
    'FLYINITD3': "found in Flycast's emulated RAM with three save states (17 November 2026), and checked in Alexis's recordings of 17 November 2026 (Civic, GT-R, RX-7, Trueno and others; Akina Lake, Irohazaka, Akagi, Myogi; story mode and time trial, manual and automatic; through the finish line and time up): speed, revs, gear, ADVANTAGE, throttle and steering against USB, rev limits, time left, race clock, laps, both checkpoint lamps, the leader lamp, Car_in_race from GO to the line, ripple strips, gutters, contact sides, the drift angle's sign and Car_drift's size",
    'ID6': "found in the v1.2 exe's code (8 November 2026), and checked in Alexis's recordings of 9 November 2026 (story prologue in an R32 GT-R and an AE86 Trueno, manual; Irohazaka time trial in a Civic, automatic; USB capture on): speed, revs, gear, brake, walls, guard rails, gutters, leaves, ripple strips, landings, the other car, lamps",
}

# What a profile can't say for itself. Short lines, each a step or a fact the player needs.
NOTES = {
    'WMMT3DXP': [
        "The memory rows read the game's own variables at the fixed addresses the game itself uses (it is a Linux program "
        "that BudgieLoader maps where it was built to run), so TeknoParrot updates can't move them, unlike the old cheat-table "
        "rows. `rpm` is the engine's revs (Max revs 10000, this car's limiter); `tacho` is what the dial shows.",
        "Effects run from the countdown (the driver's view) to the finish line, not in the story mode's opening shot or a pause. "
        "Car and traffic hits come from the game's own contact strength. Per-car limiter (`rev_limit`, so `Car_rpm_frac`), turbo boost "
        "against the car's own full boost (`Car_boost`), throttle (`Car_throttle`), the slip angle (`Car_drift`) and the load "
        "on the tyres (`Car_airborne`) come from the game too.",
    ],
    'OUTRUN2SP': [
        "Force feedback comes from the FFB Arcade Plugin's hook (\"Real\" mode, GameId 35), so the profile reads none. "
        "With **USB capture** on, the plugin takes the side of wall and traffic hits from the wheel force when the game gives none, "
        "and road bumps (the sand divider, say). Cornering stays 0: the hook sends no steering force.",
        "Manual or automatic both work; `transmission` says which.",
        "Since 11 November 2026 the profile also reads the game's own variables, found by name in its program (`jennifer`): the "
        "speedo's km/h (`speed_kmh`), the drift state and rear slip angle (`Car_drift`), slipstream, the SHIFT UP warning, crash "
        "motions, the stage, race and stage clocks, and the main sequence, so `Car_in_race` (`racing`) runs from GO to the finish "
        "line or time up, and not in the attract mode (checked 11 November 2026). `Car_speed` is the speedo's km/h (Max speed 280). "
        "`Car_drift` is full at 75 degrees here (OutRun's drifts are deep); `shift_light` lights at 8,270 RPM, as the rev dial's redline "
        "light did on four cars. `Car_speed`, `Car_rpm`, `Car_gear` and `Car_accel_g` read 0 outside a race (attract demo, menus).",
        "Car hits and their side come from the game itself (`car_hit`, `car_side`), so USB capture is no longer needed for traffic-hit "
        "sides. `game_mode`: 0 Time Attack, 1 OutRun, 2 Heart Attack. Heart Attack: `hearts` (the hearts won) and `challenge_won`. Unticked raw rows (`hit_dir`, `hit_box1` to `hit_box4`, `rev_limit`, "
        "`rev_1030`, `course_event`) stay unticked; the recorder keeps them.",
    ],
    'GRID': [
        "Force feedback: the FFB Arcade Plugin's Custom mode, made from the same values this profile reads, so USB capture adds nothing.",
        "Speed, revs, gear, throttle and shift lights come from the game's on-screen dial (Alexis's Cheat Engine work), so OutputBlaster isn't needed. Speed is the speedo's km/h; gear 1 to 6, -1 reverse.",
        "Each car's limiter (6500 to 8200) is read too, so with plugin 0.17.0 or later the rev limiter and engine effects follow every car; Max revs then only scales the rpm row.",
        "From the game's own code (12 November 2026), checked in her recordings: `brake`, `steer` (+ right), the race clock (`race_clock`, the TT on screen), `racing` (Car_in_race: GO to the finish line, off while paused and at TIME OVER), `lap`, `final_lap`, `lap_line`. Every other common value reads 0 outside a race.",
        "`position` and `leader` from the HUD's position list, and the unticked `game_mode` (7 Championship, 8 Quick Race), are from the game's code (16 November 2026) and not yet read in a recording. Time left and checkpoints are still to find (a Cheat Engine pointer scan).",
    ],
    'SR3': ["Speed is in mph, whatever the screen shows.",
            "From the game's own code (Rally.exe, 12 November 2026), checked in a recording of 16 November 2026: `player_state` (0 menus, 1 intro, 2 countdown, 3 racing, 4 finished, 5 post race), `racing` (Car_in_race: GO to the finish line), `checkpoint` (2 s after each checkpoint and lap line), `lap`, `laps_total`, `final_lap`, `position`, `leader`, `wrong_way`. Every other common value reads 0 outside a race.",
            "`rt` is the time left as the screen shows it (RT; the screen cuts off the decimals) and `race_time` the TT from GO. `time_left` is the time given (70 s at GO, +25 at a checkpoint, +30 at a lap line); in Quick Race RT is that less TT, checked against Alexis's readings."],
    'MKGPDX118': [
        "`racing` (race state 6 with the FFB plugin's flag) gates the effects: on from GO to the finish line, off in the countdown, while the game drives you after the line, and in the attract demo (race state 6, but the FFB plugin's flag stays 0).",
        "`position` (updated once a second, as the HUD is), `laps_done`, `laps_total`, `lap`, `final_lap`, `leader` and `race_time` (seconds, the game's clock: 16 ms a frame, about 4% slower than real time) checked in a recording.",
        "`drift_angle` (+ right-hand) and `drift_strength` feed Car_drift; `airborne` is the kite glides and jumps (not the drift hops), `rumble_strip` the log strips, `item_held` the item button's lamp, `coins` the coins collected.",
        "`force` is the kart's slide (the sine of the drift angle), which the FFB Arcade Plugin sends the wheel, so Car_road_bump comes from landings, not force kicks.",
        "`terrain` codes are the game's surface kinds, shared by surfaces that look different (Alexis's names): 0 rebound-ace road (Mario cup), boost ramps (Bowser Jr cup), or in the air; 2 metal grille; 3 dirt road; 4 grassy verge; 5 checkerplate; 7 water; 8 wood (floorboards, platforms, ripple-strip logs); 9 carpet; 10 planked bridge, boost rings; 11 rebound-ace verge; 12 pavement; 13 jungle floor, striped glass; 14 sand; 15 cloud.",
        "Car_off_road: 1 on a verge (grass, rebound-ace) or sand, 0.5 on the planked bridge, 0.3 on wood; 0 on everything else. Car_rumble_strip: the log ripple strips and the metal grilles.",
        "`spin` covers spin-outs on the ground (a banana peel) and being thrown into the air spinning (items, a bomb blast); `knocked` adds bumps from behind and flips.",
        "`hit_side` (Car_impact_side) is -1 for a hit on the left, 1 on the right, 0 when it can't tell (hits from in front or behind, gentle bumps, hits in a drift or a spin).",
    ],
    'MKGPDXUSA': [
        "For the USA version (MK_AGP3_FINAL.exe built 8 November 2016, 7,033,856 bytes). v1.10 and v1.18 run an exe of the same name: tick the profile for the version you run.",
        "OutputBlaster has no USA build, so the lamp rows read v1.18's lamp words where this version keeps them (its I/O block sits 0xCF880 higher). No OutputBlaster needed; they light in the menus and the race. The item lamp flashes at times in this version; `item_held` bridges the flashes.",
        "`force` here is the kart's sideways slide, which the FFB Arcade Plugin's Real mode sends to the wheel: near 0 driving straight. `drift_angle` gives it in degrees.",
        "The same rows and surfaces as v1.18 (see MKGPDX118), at this exe's addresses, checked in two races. Effects stop at the finish line (race state 7), though the FFB plugin's race flag stays on 2 s longer.",
        "Worked out from Alexis's USA exe, which she believes is a modified build that uses more memory. Its header carries the large-address flag (as her v1.18 exe's does), which moves nothing; if another USA exe reads nothing, its code differs and needs a look.",
    ],
    'SWDC': [
        "For version 2.30 (`version` says which it found). Needs plugin 0.19.0 or later (with its helper): the rows from your car's "
        "record use its indexed offsets (`[-E80]*578`), which older plugins can't read.",
        "Your car's record in the game's own data (its exe, v2.30), found by your car number (`player_no`; `player_ok` 1 when it reads): "
        "race state, the speedo's km/h, gear, brake, place, lap, sector, race clock, position and heading.",
        "Values reach SimHub only from the rolling start (race state 2) to your finish line: 0 in the countdown, after the line, in the "
        "menus and the attract mode (Alexis, 19 November 2026). The force feedback rows still show what the game sends the wheel.",
        "Revs are Alexis's table's `revs` (the record's own revs aren't the engine's); `speed2`/`gear2` stay to compare.",
        "`position` is your class place, as the screen and results show it (`overall` among every car).",
        "Car contacts and wall hits come from the sideways shove the game gives the car (`jolt`, `car_contact`), with their side; "
        "head-on hits from the speed falling at more than 4 G. The grass verge (Car_off_road) and solid kerbs (Car_rumble_strip) come "
        "from the game's own vibration command. Car_drift is fitted to Alexis's six slides of 19 November 2026.",
    ],
    'WMMT5DXP': [
        "Uses MasterRaver's Outputs script values (`speed2`, `rpm2`, `race_time2`) where they're better; nothing extra to run.",
        "Max revs 8900 suits `rpm2`; the limiter varies by car, so change it to suit yours.",
    ],
    'M2STCC': [
        "The lamp rows read the emulator's copy of the game's lamp port (exe+174CF0), as the STCC build of OutputBlaster does: "
        "`lampleader` is the leader lamp. No script or patch needed. The regular OutputBlaster build reads RAM+824, which STCC doesn't use.",
        "Max speed 320 and Max revs 12900 are set (rpm is the engine's own revs). Top speed depends on the car (278 and 335 km/h seen). "
        "`speed_kmh`, `rpm_tacho` and `rpm_display` are the screen's own figures.",
        "Kerbs and grass come from the surface under each wheel (`surfaces`), sliding from the rear tyres' slip angle, jumps from `air_frames`, "
        "wall hits from `wall_hit` (no side) plus the wheel force.",
        "`checkpoint` is 1 while TIME EXTENDED is on screen, for a lamp.",
    ],
    'M2DAYTONA': [
        "The emulator's own `SCRIPTS\\daytona.lua` moves the lamps to RAM+824, so keep it: the lamp rows rely on it.",
        "`speed` is the speedo's km/h and `rpm` the tacho's revs (8500 on the limiter).",
        "`gear` works with manual and automatic gears; it keeps the last gear through neutral.",
        "`checkpoint` is 1 for the 2 s TIME EXTENSION shows after each lap, for a lamp. Laps, lap time and last lap are there too.",
        "Grass and kerbs come from the surface under each wheel, sliding from the tyre squeal, wall hits and side-on contact from `hit`; "
        "rear-end bumps only show in the wheel force.",
    ],
    'M2SRALLY': [
        "For the `srallyc` romset (Sega Rally Championship): the other versions may keep their values elsewhere.",
        "Max revs is the limiter, 8800, where the tacho reads 8k; `rpm_tacho` has the tacho's figure.",
        "`checkpoint` is 1 for a second at each time extension checkpoint, and `leader` is 1 while you lead: both for lamps.",
        "Jumps come from the wheels on the ground (`wheels_down`), sliding from the rear tyre's slip, the grass verge from the surface under each "
        "wheel, wall and car hits (with their side) from `hit`.",
        "The lamp rows read the emulator's copy of the game's lamp port (exe+174CF0), so no script or patch is needed. Only `lampview3` "
        "has lit so far (blinking from coin-up), never a lead lamp, so use `leader` (1 while you're in 1st) for one.",
    ],
    'GTICLUB3': [
        "Speed, revs, gear, position, laps, lap times, time left, race state, surfaces and hits read the game's memory (from its code, "
        "starting from Alexis's Cheat Engine table, and checked in her recording of 8 November 2026); no OutputBlaster needed.",
        "`speed` is the speedo's km/h (km/h even with the display set to mph); `true_speed` is the car's real km/h. `rpm` is the "
        "engine's revs, `rpm_tacho` the tacho's. Max revs 7500 is the game's own limiter; Max speed 160 km/h is a little under the "
        "163 km/h reached in the recording.",
        "The game's vibration jolts tell the events apart: `landing` after a jump, `car_hit`, `wall_hit` and `crash`; `hit` sizes walls "
        "and cars by the speed lost. `kerb` counts the wheels on a kerb. None of these has a side.",
        "The car values read 0 outside a race (the game leaves its car pointer stale between races), and `in_race` ends at the finish line.",
        "`checkpoint`, `leader`, `final_lap` and `hurry` (last 10 s) are there for lamps.",
    ],
    'BG4JP': ["For Battle Gear 4 Tuned (Japan) v2.07, the version the FFB Arcade Plugin supports (its GameId 13).",
              "`speed` is the speedo's km/h and `rpm` the engine's revs (700 idle), read from car 0 like the FFB plugin does; "
              "`gear` is -1 in reverse and 0 in neutral. `racing` is 1 from the green light.",
              "The game's race flag stays on in the menus after a credit stops the attract demo (the car values freeze there), "
              "so Car_in_race also needs the camera (`view`) not to be 12. It goes off at the finish line (race phase 8) and at time up.",
              "Max speed 200 km/h (Alexis: most races stay under it, and above it the cars barely steer; the fast cars reach "
              "about 295). Max revs 8000 (the Citro\u00ebn's limiter; the Golf GTI's is 7500, a tuned car's 9000).",
              "`brake_warning`, `corner_ahead`, `corner_side` and `corner_sharpness` come from the car navigation (the CARNAVI setting must be on). `drift_angle` and `drift` feed Car_drift; `time_left` is the race time (RT), `lap` the laps completed, "
              "`checkpoint` 1 for 2 s after a checkpoint adds time; `wheelspin` feeds Car_grip_loss.",
              "If every row reads 0 or never changes while the game runs, TP Telemetry is reading another copy of game.exe: use "
              "plugin 0.18.1 or later, which always reads the newest."],
    'BG4': ["For the export version: lamps only. The Japanese Battle Gear 4 Tuned is `BG4JP`."],
    'RTUNED': ["The FFB Arcade Plugin switches this game's force feedback on by writing to its memory. "
               "This plugin only reads, so if the values stay at 0, run the FFB Arcade Plugin as well."],
    'SONICASR': ["The FFB Arcade Plugin switches this game's force feedback on, and OutputBlaster its outputs, by writing to its memory. "
                 "This plugin only reads, so if values or lamps stay at 0, run the FFB Arcade Plugin (or OutputBlaster) as well."],
    'HYDROTHUNDER': ["The patched builds are `HYDRO_x64_x64.exe` and `HYDRO_x64_x86.exe`: change Process to match yours."],
    'CRAZYTAXI': ["The PC release, not a TeknoParrot game: set Process to your copy's exe."],
    'CRUISNBLAST': ["Race force feedback comes from a hook, so there's none to read: USB capture fills the effects from the wheel force."],
    'D1GP': ["Force feedback from TeknoParrot's shared memory; `speed` reads `game.exe`."],
    'SRG': ["Force feedback from TeknoParrot's shared memory; `speed` and `racing` read `racing.exe`."],
    'ID6': ["Force feedback from TeknoParrot's shared memory, which works with any process name.",
            "Speed, revs, gear, pedals, race state and the car's events (walls and guard rails by side, the other car, the gutter, "
            "landings, road joints, rumble strips) read the memory of **v1.2** (the exe's own code, 8 November 2026). Process is set to "
            "`InitialD6_GLW_RE_SBUU_dump.exe`: change it if yours is named differently. On v1.0 those rows read 0.",
            "`speed` is the speedo's km/h and `rpm` the revs on screen; `rpm_tacho` is the revs times a factor for each car, not what "
            "the screen shows. Max revs 8140 is the limiter of the R32 GT-R and the AE86 Trueno; Max speed 220 km/h (the Trueno reached 215).",
            "`hit` is the start of a contact with a wall, guard rail or the other car (a grind along the other car counts once); "
            "`gutter` (Akina) and `leaves` (Irohazaka) are wheels off the edge of the road and feed Car_off_road; ripple strips come from "
            "the game's vibration, landings from the start of its landing flag. The other car's side isn't known.",
            "`drift_angle` is the physics' own drift angle in degrees (+ a right-hand drift, - left; checked in two drifting recordings). "
            "Car_drift (plugin 0.18.0) is the angle (5 to 50 degrees) times the speed (20 to 120 km/h), and Car_grip_loss follows it.",
            "Car_in_race starts in the rolling start's countdown once the engine runs (`countdown_live`), so the engine effects start "
            "with the engine; `in_race` itself starts with the race clock.",
            "The lamps read memory on both versions (the addresses OutputBlaster uses for each), so OutputBlaster isn't needed."],
    'FLYINITD3': ["Reads the game's own memory inside `flycast.exe`: speed (km/h, the speedo), revs, gear, ADVANTAGE, throttle, "
                  "steering and each car's rev limit from the player's car; time left (RT), race clock (TT) and lap through the "
                  "game's pointer to the race (**plugin 0.18.2 and helper 0.17.1**: older ones show an error on those rows); "
                  "what each wheel is on (ripple strips, gutters and kerbs, grooved concrete); contacts with their side and knock; "
                  "the drift angle from the car's heading against its travel. Car_in_race runs from GO to the finish line or time "
                  "up, and every other Car_ value is 0 outside it.",
                  "`lampleader` (from GO, ahead of or level with the rival; lit through a time trial; held after the line until the "
                  "race is cleared) and `lampcheckpoint` (2 s when the time left jumps up) are made from memory, not cabinet "
                  "outputs, so they work with Flycast's outputs off.",
                  "**Broadcast Digital Outputs is optional.** Only `ffb_raw` and the rows made from it (`ffb_cmd`, `ffb_str`, "
                  "`force`, `spring`, `vibration`, `force_abs`, `force_smooth`, `force_kick`, and Car_road_bump and Car_vibration) "
                  "and `lamp0` to `lamp7` and `lamp_bits` use it. With the FFB Arcade Plugin's files in Flycast's folder the game "
                  "froze in the menus with outputs on (Alexis, 17 November 2026): remove them, or leave outputs off.",
                  "The memory rows are for Flycast v2.7-1-g44e4c7b50 (flycast.exe MD5 d8db8f697e26e5384a186eb2c8b79289; from 19 November "
                  "2026, before which they were for v2.5-219-g27a913fc0) and the "
                  "export game (`initdv3e`). Another Flycast build keeps its RAM pointer elsewhere, and every memory row then reads "
                  "nothing: `ram_probe` shows it at once (a steady 3509307139 is right; 0 or an error means the pointer has to be "
                  "found again, as the FLYINITD3 notes say)."],
    'SMDAYTO2PE': ["Reads the game's own memory inside `supermodel.exe` (Supermodel 0.4-dev, git 0b82a98 of 16 November 2026, "
                   "MD5 440c8330529f89714047740b9b45831e) for the `dayto2pe` ROM set (Daytona USA 2 Power Edition): speed (km/h, as "
                   "on screen), revs, gear, the car class, throttle, brake, steering, time left (RT), race clock (TT), lap, lap times, "
                   "position, pit stops, big crashes, touching other cars (how hard, no side), wheels against walls and the drift "
                   "angle. Car_in_race runs from the time being set (on Beginner the rolling start, on Advanced and Expert the grid) "
                   "to the finish line or time up, and every Car_ value is 0 outside it.",
                   "Found in the emulator, then checked in Alexis's three recordings of 18 November 2026 (Advanced NORMAL manual, "
                   "Expert HARD manual, Beginner SPECIAL automatic with a pit stop) and two on Mixed (EASY and SPECIAL, manual, on the "
                   "limiter). Max revs 8500; Car_rpm is the rev counter's revs (wheelspin and clutch slip included) and Car_rpm_frac follows each car class's limiter (EASY and SPECIAL 7650, NORMAL and HARD 8500).",
                   "**`-outputs=net` is optional:** only the force rows (`ffb_cmd` and those made from it, so Car_road_bump and "
                   "Car_vibration) and the `lamp_` rows need it.",
                   "`SMDAYTONA2` (the force and lamps only, for the original Daytona USA 2) is unchanged."],
    'SMSCUD': ["Reads the game's own memory inside `supermodel.exe` (Supermodel 0.4-dev, git 0b82a98 of 16 November 2026, MD5 "
               "440c8330529f89714047740b9b45831e): speed (km/h, as on screen), revs and each car's rev limit, gear, throttle, brake, "
               "steering, the race phase, time left (RT), race clock (TT), lap, lap times, position, the finishing place, pit stops, "
               "big crashes, wheels against walls, touching other cars, jumps (free fall), the wrong way and the drift angle from the "
               "car's heading against its travel. Car_in_race runs from GO (on Beginner from the rolling start's 3-2-1, on Medium "
               "and Expert from the grid, where only revs and gear run, with Car_throttle at 1 so the engine follows the revs) to the "
               "finish line or time up, and every other Car_ value is 0 outside it. Car_drift is set from Alexis's two F40 drifts (0.9 at 53.5 degrees, 0.65 at 42.5).",
               "**`-outputs=net` is optional:** only the force rows (`ffb_cmd` and those made from it, so Car_road_bump and "
               "Car_vibration) and the `lamp_` rows need it.",
               "Checked in Alexis's four recordings of 18 November 2026 (memory read, race gate, clocks, laps, checkpoints, gears, "
               "pedals and steering against USB, rev limits, jumps, the front wheels lifting over a crest, car contact by side, wall "
               "hits by side, REVERSE!). Driving along a grass verge is still read as the wrong side's wall. Max speed 350, Max revs "
               "9500.",
               "Another Supermodel build may keep its RAM pointer elsewhere: `ram_probe` reading a steady 2087778982 means the memory "
               "rows read; 0 or an error means the pointer has to be found again (claude/SMSCUD-supermodel-20261118.md says how). "
               "With a fresh NVRAM the game stops at NETWORK BOARD NOT PRESENT: set LINK ID to SINGLE in the test menu's GAME "
               "ASSIGNMENTS."],
    'ID0V230': ["Every row (the force feedback too) reads the game's own memory, so it works the same whether the game runs under "
                "segatools or TeknoParrot (both run `InitialD0_DX11_Nu.exe`); TeknoParrot's shared memory isn't used. The rows are for "
                "the v2.30 exe whose MD5 is 2e506fe5e3d36fc4eff0d44389f4757b: on another build they may read nothing.",
                "Speed (the speedo), revs (the rev counter, manual or automatic: an automatic's counter shows 0.885 of the engine value), gear, pedals, steering, the drift angle, the race and "
                "car states, game mode, race clock (TT), time left (RT), checkpoints, the gap to the rival and the car's events (walls and "
                "guard rails by side, the other car, the gutter, leaves, landings) come from the game's own code, the same engine as "
                "Initial D 6. Ripple strips come from the game's own vibration (level 5), so Irohazaka's painted strips don't count.",
                "Max speed 220 km/h (the Trueno reached 203); Max revs 8140, the Trueno's limiter (the RX-7's is about 7,070). Car_drift "
                "uses ID6's weighting.",
                "Effects run from GO to your finish line, not in the attract demo, a replay, a pause or the tutorial's how-to demos; "
                "every common value but Car_in_race reads 0 outside a race. Car_cornering comes from the steering and speed, not the game's "
                "weak wheel force.",
                "Lamps made from the race values (OutputBlaster has no v2.30 entry): `lampleader` while you lead the rival (all race "
                "in time attack, where you run alone), `lampcheckpoint` for 2 s at each Extended Time!."],
    'FORDRACING': ["Force feedback from TeknoParrot's shared memory; no process needed."],
    'ID4JP': ["OutputBlaster only knows the export version's addresses, so the lamps come from it."],
    'DEADHEAT': ["Lamps come from OutputBlaster (it works them out in code hooks)."],
    'BATMAN': ["Lamps come from OutputBlaster (it only sends them while a flag it keeps is on)."],
    'H2OVERDRIVE': ["The boost lamp, keypad, throttle and speedo digits come from OutputBlaster; the other outputs read memory."],
    'IDTA21': ["The force address isn't known for this build: timer only."],
    'IDTAS4': ["The force address isn't known for this build: timer only."],
    'IDTAS5V321': ["The force address isn't known for this build: timer only."],
    'WMMT6RRP': ["The force address isn't known for this build. MasterRaver's Outputs script for 6RR is on its way."],
}

EMULATOR_STEPS = {
    'Teknoparrot': [
        "Run the game in TeknoParrot. The plugin finds it by its Process name (filled in for you) and selects it, or select it in the Game list, or from a launch line (the plugin's README, Choosing the game from a launch script).",
        "If TeknoParrot runs as administrator, SimHub must too, or the plugin can't read the game or TeknoParrot's shared memory.",
    ],
    'Model 2 Emulator': [
        "Use `emulator_multicpu.exe`, the build the FFB Arcade Plugin and OutputBlaster know (TeknoParrot's own Model 2 emulator may differ).",
        "Keep each game's own script in the emulator's `SCRIPTS` folder (it ships with the emulator); TP Telemetry needs no scripts of its own. "
        "If you renamed one to `<romname>_orig.lua` for TP Telemetry's RAM logger, rename it back and delete the logger's copy.",
        "If the emulator runs as administrator, SimHub must too.",
    ],
    'MAME': [
        "Switch MAME's outputs on: in `mame.ini`, set `output` to `network`. Without it the profile reads nothing.",
        "No process: select the game in the Game list (or from a launch line). See the plugin's Game_Outputs.md.",
    ],
    'Supermodel': [
        "Start Supermodel with `-outputs=net`. Without it the profile reads nothing.",
        "No process: select the game in the Game list (or from a launch line). See the plugin's Game_Outputs.md.",
    ],
    'Flycast': [
        "In Flycast: Settings, Network, tick **Broadcast Digital Outputs**. Without it the profile reads nothing. Needs plugin 0.13.3 or later.",
        "No process: select the game in the Game list (or from a launch line). See the plugin's Game_Outputs.md.",
    ],
    'PC': ["Set the profile's Process to your copy's exe if it's blank."],
}

HEAD = """# Setting up each game

How to get each game in the pack working with TP Telemetry, all in one place. Find your game in the
index, then follow its section.

**Before any game:**

1. **Set up the plugin itself** (its README, Build and install), and import the game's profile from
   this pack (README, Installing a profile).
2. **USBPcap may be needed.** USB capture reads the force feedback your wheel gets
   (the plugin's USB_Capture.md: install USBPcap, run SimHub as administrator, choose your wheel once).
   No game here *needs* it, but for games marked **USB adds** it fills effects the game has no values
   for (hits, road bumps, cornering, rumble), from the wheel force.
3. **OutputBlaster** is needed only for the rows marked **OutputBlaster** below (it must run with
   `OutputsSystem=1`; the plugin's Game_Outputs.md). Every other lamp and output reads game memory.

**Tags in the index:**

| Tag | Means |
|---|---|
| TP shared memory | reads TeknoParrot's shared memory: nothing to set up beyond TeknoParrot running |
| 64-bit | read through the plugin's 64-bit helper (`TPTelemetryHelper64.exe`, next to the plugin; nothing to set up) |
| OutputBlaster | some rows need OutputBlaster running |
| outputs | an emulator's network outputs must be switched on |
| USB adds | USB capture fills effects this game has no values for |
| no car_ rows | the game gives no values the effects use (lamps, timers or dashboard values only): only USB capture's hits, bumps, cornering and rumble reach the effects |
| USB needed | rows that read the USB capture |
| checked | checked against real recordings; the rest are starting points (send a recording if something looks wrong) |

This file is generated from the profiles (`tools/gamesetup.py`), so it always matches them.

"""

def anchor(prefix):
    return prefix.lower()

def info(p, group):
    vs = p['Variables']
    on = [v for v in vs if v['Enabled'] or v['Name'].startswith('car_')]
    forms = ' '.join(v['Formula'] or '' for v in on)
    notes = ' '.join(v['Notes'] or '' for v in vs)
    names = {v['Name'] for v in vs}
    d = dict(prefix=p['Prefix'], name=p['DisplayName'], group=group, process=p.get('ProcessName') or '')
    d['bit64'] = '64-bit game' in notes or 'TPTelemetryHelper64' in notes
    d['tp'] = bool(re.search(r'\btp_', forms))
    outs = sorted({v['Name'] for v in on if re.search(r'\bout_', v['Formula'] or '') and not v['Name'].startswith('car_')})
    d['ob'] = outs if group == 'Teknoparrot' else []
    d['netout'] = group in ('MAME', 'Supermodel', 'Flycast')
    d['usb_needed'] = sorted({v['Name'] for v in on if re.search(FFB_CHANNELS, v['Formula'] or '')})
    d['usb_adds'] = [] if p['Prefix'] in USB_NOTHING else [label for src, label in USB_STAND_INS if 'car_' + src not in names]
    d['memory'] = any(v['Source'] == 'Memory' for v in vs)
    d['max_speed'], d['max_revs'] = p.get('MaxSpeed'), p.get('MaxRevs')
    d['effects'] = sorted(n[4:] for n in names if n.startswith('car_') and n[4:] in commonrows.EFFECTS)
    d['dash'] = [n for n in commonrows.DASH if 'car_' + n in names]
    d['lamps'] = [n for n in commonrows.LAMPS if 'lamp_' + n in names]
    d['speedrevs'] = any(n in names for n in ('car_speed', 'car_rpm'))
    return d

def tags(d):
    t = []
    if d['tp']: t.append('TP shared memory')
    if d['bit64']: t.append('64-bit')
    if d['ob']: t.append('OutputBlaster')
    if d['netout']: t.append('outputs')
    if d['usb_needed']: t.append('USB needed')
    if not d['effects']: t.append('no car_ rows')
    if d['usb_adds']: t.append('USB adds')
    if d['prefix'] in CHECKED: t.append('checked')
    return ', '.join(t)

def section(d):
    L = [f'<a id="{anchor(d["prefix"])}"></a>', f'### {d["name"]} (`{d["prefix"]}`)', '']
    where = d['group'] if d['group'] != 'Teknoparrot' else 'TeknoParrot'
    proc = f'`{d["process"]}`' if d['process'] else ('none (selected in the Game list)' if not d['memory'] else '**blank: set it to your exe**')
    L.append(f'* **Runs in:** {where} ([common steps](#{anchor("steps-" + d["group"].replace(" ", "-"))})). **Process:** {proc}'
             + (', 64-bit (read through the 64-bit helper, plugin 0.9.0 or later)' if d['bit64'] else '') + '.')
    if d['tp']:
        L.append("* **TeknoParrot shared memory:** force feedback rows read it, so they work as soon as TeknoParrot runs the game.")
    if d['ob']:
        L.append(f"* **OutputBlaster needed** for: {', '.join('`' + n + '`' for n in d['ob'])}. Without it those rows read 0 and the rest work.")
    if d['netout'] and not d['memory']:
        L.append("* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.")
    if d['usb_needed']:
        L.append(f"* **USB capture needed** for: {', '.join('`' + n + '`' for n in d['usb_needed'])}.")
    if not d['effects']:
        L.append("* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.")
    if d['usb_adds']:
        L.append(f"* **USB capture adds** {', '.join(d['usb_adds'])} from the wheel force (plugin 0.15.0 or later), "
                 "if the game's force feedback reaches your wheel. Optional.")
    else:
        L.append("* **USB capture:** not needed; the game's own values cover the effects.")
    if d['dash']:   # plugin 0.20.0
        L.append('* **Common dashboard values:** ' + ', '.join('`TPTelemetry.Car_' + n + '`' + (' and `TPTelemetry.Car_speed_mph`' if n == 'speed_kmh' else '') for n in d['dash'])
                 + ' (besides speed, revs and gear; Common_Dashboard.md).')
    if d['lamps']:
        L.append('* **Common lamps:** ' + ', '.join('`TPTelemetry.Lamp_' + n + '`' for n in d['lamps']) + ' (Common_Lamps.md).')
    ms = d['max_speed']; mr = d['max_revs']
    if ms or mr:
        L.append('* **Max speed / Max revs:** ' + ' and '.join(x for x in [f'Max speed {ms:g}' if ms else '', f'Max revs {mr:g}' if mr else ''] if x)
                 + ' set' + ('' if ms and mr else '; set the other from a run (README, Speed and revs)') + '.')
    elif d['speedrevs']:
        L.append('* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).')
    for n in NOTES.get(d['prefix'], []):
        L.append('* ' + n)
    L.append('* **Checked:** ' + (CHECKED[d['prefix']] + '.' if d['prefix'] in CHECKED else 'not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.'))
    L.append('')
    return L

def main(pack):
    profiles = []
    for f in packlayout.files(pack):
        with open(f, encoding='utf-8') as fh:
            profiles.append(json.load(fh))
    order = {g: i for i, g in enumerate(packlayout.GROUPS)}
    profiles.sort(key=lambda p: (order.get(packlayout.group(p['Prefix']), 99), p['DisplayName'].lower()))
    games = [info(p, packlayout.group(p['Prefix'])) for p in profiles]

    out = [HEAD, '## Index\n', '| Game | Profile | Runs in | Tags |', '|---|---|---|---|']
    for d in games:
        where = d['group'] if d['group'] != 'Teknoparrot' else 'TeknoParrot'
        out.append(f'| [{d["name"]}](#{anchor(d["prefix"])}) | `{d["prefix"]}` | {where} | {tags(d)} |')
    out.append('')
    out.append('## Common steps by emulator\n')
    for g in packlayout.GROUPS:
        if g not in EMULATOR_STEPS or not any(d['group'] == g for d in games): continue
        out.append(f'<a id="{anchor("steps-" + g.replace(" ", "-"))}"></a>')
        out.append(f'### {g if g != "Teknoparrot" else "TeknoParrot"}\n')
        out += [f'{i}. {s}' for i, s in enumerate(EMULATOR_STEPS[g], 1)]
        out.append('')
    out.append('## Games\n')
    last = None
    for d in games:
        if d['group'] != last:
            out.append(f'## {d["group"] if d["group"] != "Teknoparrot" else "TeknoParrot"} games\n')
            last = d['group']
        out += section(d)
    text = '\n'.join(out).rstrip() + '\n'
    path = os.path.join(pack, 'Game_Setup.md')
    old = open(path, encoding='utf-8').read() if os.path.exists(path) else None
    if old != text:
        with open(path, 'w', encoding='utf-8', newline='\n') as fh: fh.write(text)
    return path, len(games)

if __name__ == '__main__':
    print(*main(sys.argv[1] if len(sys.argv) > 1 else '/home/claude/TPTelemetry-GameProfiles'))
