"""Looks up the named globals and functions in a 32-bit Linux game program (an ELF that TeknoParrot's
BudgieLoader runs, such as WMMT3DX+'s `main` or OutRun 2's `jennifer`). Many keep their dynamic symbol
table (some, like `jennifer`, the full one), so every global variable has a name and a fixed address: absolute addresses for TP Telemetry rows (Module blank).

    python3 -I elfsyms.py <program> <regex>         names matching the regex (case-insensitive)
    python3 -I elfsyms.py <program> 0x09813A6C      what is at an address (the symbol it falls in)
    python3 -I elfsyms.py <program> --float 0x9442628 [more addresses]    read 4-byte floats from the file

Needs binutils (readelf, c++filt). To read a function, disassemble it with objdump, e.g.
    objdump -d -C -M intel --no-show-raw-insn --start-address=0x08984428 --stop-address=0x089845ca <program>
(the start and length come from this script's output). Written 11 November 2026 for WMMT3DX+; reads the full symbol table too since OutRun 2.
"""
import re, struct, subprocess, sys

def symbols(path):
    # -s lists both tables: the dynamic one (all a stripped program like WMMT3DX+'s `main` keeps) and the full one
    # (OutRun 2's `jennifer` isn't stripped). The same symbol can be in both: keep it once.
    out = subprocess.run(['readelf', '-W', '-s', path], capture_output=True, text=True, check=True).stdout
    rows, seen = [], set()
    for line in out.splitlines():
        f = line.split()
        if len(f) < 8 or not f[0].endswith(':') or f[3] not in ('FUNC', 'OBJECT') or int(f[1], 16) == 0: continue
        size = int(f[2], 16) if f[2].startswith('0x') else int(f[2])
        key = (int(f[1], 16), f[7])
        if key in seen: continue
        seen.add(key)
        rows.append([int(f[1], 16), size, f[3], f[7]])
    names = subprocess.run(['c++filt'], input='\n'.join(r[3] for r in rows), capture_output=True, text=True, check=True).stdout.splitlines()
    for r, n in zip(rows, names): r[3] = n
    return rows

def segments(path):
    out = subprocess.run(['readelf', '-W', '-l', path], capture_output=True, text=True, check=True).stdout
    segs = []
    for line in out.splitlines():
        f = line.split()
        if f and f[0] == 'LOAD': segs.append((int(f[2], 16), int(f[1], 16), int(f[4], 16)))
    return segs

def main():
    path, what = sys.argv[1], sys.argv[2]
    if what == '--float':
        data = open(path, 'rb').read(); segs = segments(path)
        for a in sys.argv[3:]:
            a = int(a, 16)
            o = next((off + a - va for va, off, fs in segs if va <= a < va + fs), None)
            print(hex(a), 'not in the file (bss: set at run time)' if o is None else struct.unpack('<f', data[o:o + 4])[0])
        return
    syms = symbols(path)
    if re.fullmatch(r'0x[0-9a-fA-F]+', what):
        a = int(what, 16)
        for s in sorted(syms):
            if s[0] <= a < s[0] + max(s[1], 1): print(f'{s[0]:08X} +{a - s[0]:X}  {s[1]:6}  {s[2]:6}  {s[3]}')
        return
    rx = re.compile(what, re.I)
    for s in sorted(syms):
        if rx.search(s[3]): print(f'{s[0]:08X}  {s[1]:6}  {s[2]:6}  {s[3]}')

if __name__ == '__main__':
    main()
