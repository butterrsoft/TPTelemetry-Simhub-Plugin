# autopilot.py <dumpdir> <aipath.npz> <seconds> [events file] [sign]
# Steers the player's car along the AI cars' recorded paths while the race runs (reads the live ranges.bin).
# Events file lines: "<race s> <action> [args]": gas_off, gas_on, brake <s>, nosteer <s> (let go of the wheel), left <s>, right <s>,
# shift <keysym> (manual gears), lookahead <frames>. Race s counts from the first frame the race clock moves.
import sys, os, time, subprocess, numpy as np, math
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
D, path, secs = sys.argv[1], sys.argv[2], float(sys.argv[3])
events = [l.split() for l in open(sys.argv[4])] if len(sys.argv) > 4 and sys.argv[4] != '-' else []
events = [e for e in events if e and not e[0].startswith('#')]
SIGN = float(sys.argv[5]) if len(sys.argv) > 5 else 1.0
P = np.load(path)['P']; C, F, _ = P.shape; flat = P.reshape(-1, 2)
ranges = [tuple(int(x, 16) for x in l.split()) for l in open(f'{D}/ranges.txt') if l.strip()]
size = 14 + sum(n for _, n in ranges)
offs = {}; o = 14
for a, n in ranges: offs[a] = o; o += n
def col(addr):
    for a, n in ranges:
        if a <= addr < a + n: return offs[a] + addr - a
env = dict(os.environ, DISPLAY=':99')
W = subprocess.run(['xdotool', 'search', '--name', 'Supermodel'], capture_output=True, text=True, env=env).stdout.split()[0]
def key(kind, k): subprocess.run(['xdotool', kind, '--window', W, k], env=env, capture_output=True)
log = open(f'{D}/autopilot.txt', 'a')
def note(s): log.write(f'{time.time():.3f} {s}\n'); log.flush()
f = open(f'{D}/ranges.bin', 'rb')
def latest():
    n = os.path.getsize(f'{D}/ranges.bin') // size
    f.seek((n - 1) * size); b = f.read(size)
    g = lambda a, t='<f4': np.frombuffer(b[col(a):col(a) + 4], t)[0]
    if GAME == 'd2':   # Daytona USA 2 Power Edition: car record 0x501000 (speed +98, position +9C/+A4, matrix +D0), clocks 0x105010/0x10500C
        return dict(frame=np.frombuffer(b[0:4], '<u4')[0], x=g(0x50109c), z=g(0x5010a4), fx=g(0x5010d8), fz=-g(0x5010f0),
                    spd=g(0x501098, '<i4'), gear=g(0x5011d4, '<i4'), rpm=g(0x5011dc, '<i4'), tl=g(0x105010, '<i4'), tt=g(0x10500c, '<i4'))
    return dict(frame=np.frombuffer(b[0:4], '<u4')[0], x=g(0x18111c), z=g(0x181124), fx=g(0x181158), fz=-g(0x181170),
                spd=g(0x181118, '<i4'), gear=g(0x18123c, '<i4'), rpm=g(0x181244, '<i4'), tl=g(0x104010, '<i4'), tt=g(0x10400c, '<i4'))
MANUAL = os.environ.get('MANUAL') == '1'; GAME = os.environ.get('GAME', 'scud'); last_shift = 0
steer = None; gas = True; look = 30; t_end = time.time() + secs; t0 = None; ev = 0; hold_until = 0; forced = None
key('keydown', 'Up'); note('gas on')
while time.time() < t_end:
    s = latest()
    if t0 is None and s['tt'] > 0: t0 = time.time(); note(f'race clock moving, frame {s["frame"]}')
    rt = time.time() - t0 if t0 else -1
    while t0 and ev < len(events) and float(events[ev][0]) <= rt:
        e = events[ev]; ev += 1; note('event ' + ' '.join(e))
        if e[1] == 'gas_off': key('keyup', 'Up'); gas = False
        elif e[1] == 'gas_on': key('keydown', 'Up'); gas = True
        elif e[1] == 'brake': key('keyup', 'Up'); key('keydown', 'Down'); time.sleep(float(e[2])); key('keyup', 'Down'); key('keydown', 'Up') if gas else None
        elif e[1] in ('nosteer', 'left', 'right'): forced = e[1]; hold_until = time.time() + float(e[2])
        elif e[1] == 'shift': key('keydown', e[2]); time.sleep(0.2); key('keyup', e[2])
        elif e[1] == 'lookahead': look = int(e[2])
        elif e[1] == 'poke':
            open(f'{D}/poke.txt', 'w').write('%x %x\n' % (0x105010 if GAME == 'd2' else 0x104010, s['tl'] + 3420 * 4)); time.sleep(1.5); os.remove(f'{D}/poke.txt')
        elif e[1] == 'key': key('keydown', e[2]); time.sleep(float(e[3]) if len(e) > 3 else 0.15); key('keyup', e[2])
    if MANUAL and t0 and time.time() - last_shift > 0.6:
        if s['rpm'] > int(os.environ.get('UP', '6800')) and s['gear'] < 4: key('keydown', 'y'); time.sleep(0.1); key('keyup', 'y'); last_shift = time.time(); note(f"shift up from {s['gear']} at {s['rpm']}")
        elif s['rpm'] < int(os.environ.get('DOWN', '3800')) and s['gear'] > 1: key('keydown', 'h'); time.sleep(0.1); key('keyup', 'h'); last_shift = time.time(); note(f"shift down from {s['gear']} at {s['rpm']}")
    want = None
    if forced and time.time() < hold_until:
        want = {'nosteer': None, 'left': 'Left', 'right': 'Right'}[forced]
    else:
        forced = None
        d = np.hypot(flat[:, 0] - s['x'], flat[:, 1] - s['z']); i = int(np.argmin(d)); c, fr = divmod(i, F)
        tx, tz = P[c, min(fr + look, F - 1)] - (s['x'], s['z'])
        err = math.degrees(math.atan2(tx, tz) - math.atan2(s['fx'], s['fz'])); err = (err + 180) % 360 - 180
        if int(time.time()*4) % 4 == 0 and abs(time.time()*4 - int(time.time()*4)) < 0.15: note(f"f{s['frame']} x{s['x']:.0f} z{s['z']:.0f} spd{s['spd']} err{err:.0f}")
        if abs(err) > 4: want = 'Right' if SIGN * err > 0 else 'Left'
    if want != steer:
        if steer: key('keyup', steer)
        if want: key('keydown', want)
        steer = want
    time.sleep(0.03)
if steer: key('keyup', steer)
key('keyup', 'Up'); note('done')
