# aipath.py <dumpdir> <from> <to> <out.npz> : AI cars' trajectories (x, z, car, frame) from a ranges log, cars 1..39.
import sys; import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
B, ST, PX, PZ = (0x501000, 0x1000, 0x9c, 0xa4) if os.environ.get('GAME') == 'd2' else (0x181000, 0x300, 0x11c, 0x124)   # GAME=d2: Daytona USA 2 PE
from rlog import Log
import numpy as np
R = Log(sys.argv[1]); s, e = int(sys.argv[2]), int(sys.argv[3])
P = []
for k in range(1, 40):
    x = R.f32(B + k * ST + PX)[s:e]; z = R.f32(B + k * ST + PZ)[s:e]
    P.append(np.stack([x, z], 1))
P = np.stack(P)  # cars x frames x 2
np.savez(sys.argv[4], P=P)
d = np.hypot(*np.diff(P, axis=1).transpose(2, 0, 1)).sum(1)
print('path length per car (m):', np.round(d[:10]), 'min/max', d.min().round(), d.max().round())
