# Builds Scud Race's 2 MB fixed program ROM (CROM, 0xFFE00000-0xFFFFFFFF) as the PowerPC sees it (big-endian).
# Checked by the reset code at 0xFFF00100: epr-19734.20 gives bytes 0-1 of each 8, 19733.19 2-3, 19732.18 4-5, 19731.17 6-7, each 16-bit word byte-swapped.
import sys
d = sys.argv[1]; out = sys.argv[2]
names = ['epr-19734.20', 'epr-19733.19', 'epr-19732.18', 'epr-19731.17'] if len(sys.argv) < 4 else sys.argv[3].split(',')
roms = [open(f'{d}/{n}', 'rb').read() for n in names]
swap = True
b = bytearray(len(roms[0]) * 4)
for i in range(0, len(roms[0]), 2):
    for k, r in enumerate(roms):
        w = r[i:i+2]
        if swap: w = w[::-1]
        b[(i // 2) * 8 + k * 2:(i // 2) * 8 + k * 2 + 2] = w
open(out, 'wb').write(b)
