# findval.py <dump dir> <map.txt> <idx:value,...> [tol] : finds RAM words (float or int32, also 16-bit halves) proportional to the given values.
import sys, numpy as np
D, M, spec = sys.argv[1], sys.argv[2], sys.argv[3]
tol = float(sys.argv[4]) if len(sys.argv) > 4 else 0.03
mp = dict(l.split() for l in open(M))
pairs = [(p.split(':')[0], float(p.split(':')[1])) for p in spec.split(',')]
W = np.stack([np.frombuffer(open(f'{D}/{mp[i]}', 'rb').read(), dtype='<u4') for i, _ in pairs])
v = np.array([x for _, x in pairs])
def test(arr, label):
    arr = arr.astype(np.float64)
    ok = np.all(np.isfinite(arr), axis=0) & np.all(arr != 0, axis=0)
    r = arr / v[:, None]
    m = np.median(r, axis=0)
    good = ok & np.all(np.abs(r - m) <= tol * np.abs(m) + 1e-12, axis=0) & (np.abs(m) > 1e-6) & (np.abs(m) < 1e6)
    for a in np.nonzero(good)[0][:40]:
        print(f'{label} {a*4 if label!="h16hi" and label!="h16lo" else a*4:#08x} ratio {m[a]:.6g}  vals {arr[:, a][:6]}')
with np.errstate(all='ignore'):
    test(W.view('<f4'), 'f32')
    test(W.view('<i4'), 'i32')
    test((W >> 16).astype(np.int16), 'h16hi')   # PPC halfword at the word's address (big-endian order: high half first)
    test((W & 0xFFFF).astype(np.int16), 'h16lo') # halfword at address + 2
