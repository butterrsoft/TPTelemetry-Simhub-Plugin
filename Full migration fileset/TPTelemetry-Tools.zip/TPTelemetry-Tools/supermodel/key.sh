#!/bin/sh
# key.sh <keysym> [seconds held]  - presses a key in the Supermodel window on :99
export DISPLAY=:99
W=$(xdotool search --name Supermodel | head -1)
xdotool windowfocus --sync $W 2>/dev/null
xdotool keydown --window $W $1; sleep ${2:-0.15}; xdotool keyup --window $W $1
