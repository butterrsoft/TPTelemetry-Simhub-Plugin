# exact.py <dumpdir> <frame:value,...> [scale] : RAM bytes/halfwords/words equal to value*scale (+-1 frame) at every listed frame.
import sys; import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rlog import Log
import numpy as np
WIN = 8
R = Log(sys.argv[1]); sc = float(sys.argv[3]) if len(sys.argv) > 3 else 1
pairs = [(int(p.split(':')[0]), float(p.split(':')[1]) * sc) for p in sys.argv[2].split(',')]
idx = [int(np.searchsorted(R.frame, f)) for f, _ in pairs]
for a, (o, l) in R.off.items():
    raw = R.raw[:, o:o+l]
    W = raw.view('<u4')
    views = {'u32': W.astype(np.int64), 'i32': W.view('<i4').astype(np.int64), 'f32': W.view('<f4')}
    # bytes as the PPC addresses them: word byte k (big-endian) = host byte 3-k
    for k in range(4):
        views[f'b{k}'] = raw[:, (3 - k)::4].astype(np.int64)
    for k in range(2):
        views[f'h{k}'] = ((W >> 16) if k == 0 else (W & 0xFFFF)).astype(np.int16).astype(np.int64)
    for name, V in views.items():
        ok = None
        for i, (f, v) in zip(idx, pairs):
            m = np.zeros(V.shape[1], bool)
            for d in range(-WIN, WIN + 1):
                j = min(max(i + d, 0), R.n - 1)
                m |= (np.abs(V[j] - v) < 0.5) if name == 'f32' else (V[j] == v)
            ok = m if ok is None else ok & m
        for j in np.nonzero(ok)[0]:
            addr = a + 4 * j + (int(name[1]) if name[0] == 'b' else (2 * int(name[1]) if name[0] == 'h' else 0))
            print(f'{name} {addr:06x}')
