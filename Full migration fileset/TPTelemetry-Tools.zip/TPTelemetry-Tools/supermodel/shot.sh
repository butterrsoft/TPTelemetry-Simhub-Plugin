#!/bin/sh
DISPLAY=:99 import -window root -crop 496x384+72+48 ${2:-} $1
