# shotframes.py <capdir> <dumpdir> : prints "shot frame" pairs (nearest logged frame to each screenshot's wall time).
import sys; import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rlog import Log
import numpy as np
R = Log(sys.argv[2])
for l in open(f'{sys.argv[1]}/actions.txt'):
    t, kind, name = l.split()
    k = int(np.searchsorted(R.time, float(t)))
    if kind == 'shot': print(name, R.frame[min(k, R.n - 1)])
    else: print('#', kind, name, R.frame[min(k, R.n - 1)])
