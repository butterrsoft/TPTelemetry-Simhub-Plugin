# Reads ranges.bin from the analysis build: R = Log(dir); R.u32(addr), R.f32(addr), R.i16(addr), R.u8(addr) give a series per frame.
import numpy as np
class Log:
    def __init__(self, d):
        self.ranges = [tuple(int(x, 16) for x in l.split()) for l in open(f'{d}/ranges.txt') if l.strip()]
        size = 14 + sum(n for _, n in self.ranges)
        raw = np.memmap(f'{d}/ranges.bin', dtype=np.uint8, mode='r')
        n = len(raw) // size
        self.raw = raw[:n * size].reshape(n, size)
        self.frame = self.raw[:, 0:4].copy().view('<u4')[:, 0]
        self.time = self.raw[:, 4:12].copy().view('<f8')[:, 0]
        self.drive = self.raw[:, 12].copy(); self.lamps = self.raw[:, 13].copy()
        self.off = {}; o = 14
        for a, l in self.ranges: self.off[a] = (o, l); o += l
        self.n = n
    def col(self, addr, nbytes=4):
        for a, (o, l) in self.off.items():
            if a <= addr and addr + nbytes <= a + l: return o + addr - a
        raise KeyError(hex(addr))
    def word(self, addr):  # the 32-bit word holding addr, as stored (little-endian host order = PPC value)
        c = self.col(addr & ~3); return self.raw[:, c:c+4].copy().view('<u4')[:, 0]
    def u32(self, a): return self.word(a)
    def i32(self, a): return self.word(a).view('<i4')
    def f32(self, a): return self.word(a).view('<f4')
    def u16(self, a): w = self.word(a); return ((w >> 16) if (a & 2) == 0 else (w & 0xFFFF)).astype(np.uint16)
    def i16(self, a): return self.u16(a).view(np.int16)
    def u8(self, a): w = self.word(a); return ((w >> (8 * (3 - (a & 3)))) & 0xFF).astype(np.uint8)
    def i8(self, a): return self.u8(a).view(np.int8)
    def block(self, a, l):  # frames x words for [a, a+l)
        c = self.col(a, l); return self.raw[:, c:c+l].copy().view('<u4')
