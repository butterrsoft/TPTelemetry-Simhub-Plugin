#!/bin/sh
# hudsheet.sh <capdir> <out.png> <crop> <shot>... : labelled crops of screenshots (label = shot and frame)
C=$1; O=$2; G=$3; shift 3
L=""
for s in "$@"; do f=$(grep "^$s " $C/frames.txt | cut -d' ' -f2); convert $C/$s.png +repage -crop $G +repage -background white -gravity north -splice 0x14 -pointsize 12 -annotate +0+0 "$s f$f" /tmp/hs_$s.png 2>/dev/null; L="$L /tmp/hs_$s.png"; done
montage $L -tile 4x -geometry +1+1 $O
