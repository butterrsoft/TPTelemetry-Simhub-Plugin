# fixture.py <dumpdir> <profile.json> <from frame> <to frame> <step> <out.csv.gz> : a replay fixture for the plugin's tests from an
# analysis-build RAM log: t (s, 57.524 frames a second), mark (blank), then each memory row's raw value as the plugin reads it.
import sys, json, gzip, numpy as np
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rlog import Log
R = Log(sys.argv[1]); prof = json.load(open(sys.argv[2]))
a, b, step = int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
s, e = int(np.searchsorted(R.frame, a)), int(np.searchsorted(R.frame, b))
rows = [v for v in prof['Variables'] if v['Source'] == 'Memory']
cols = []
for v in rows:
    host = int(v['Offsets'].split(',')[-1], 16)
    t = v['Type']
    try: R.col(host & ~3)
    except KeyError: continue   # not in the log's ranges (ram_probe)
    if t == 'Byte': x = R.u8(host ^ 3)
    elif t == 'UInt16': x = R.u16(host ^ 2)
    elif t == 'Int16': x = R.i16(host ^ 2)
    elif t == 'Int32': x = R.i32(host)
    elif t == 'UInt32': x = R.u32(host)
    elif t == 'Float': x = R.f32(host)
    cols.append((v['Name'], t, x))
with gzip.open(sys.argv[6], 'wt', newline='\n') as f:
    f.write('t,mark,' + ','.join(n for n, _, _ in cols) + '\n')
    for k in range(s, e, step):
        vals = []
        for n, t, x in cols:
            vals.append(repr(float(x[k])) if t == 'Float' else str(int(x[k])))
        f.write(f'{R.frame[k] / 57.524:.4f},,' + ','.join(vals) + '\n')
print(len(range(s, e, step)), 'samples,', len(cols), 'rows')
