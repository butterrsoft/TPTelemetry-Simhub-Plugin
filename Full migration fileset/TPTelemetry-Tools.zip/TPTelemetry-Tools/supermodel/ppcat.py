# ppcat.py <pkl> <addr hex> [before] [after] : PowerPC listing around an address, r13 globals annotated.
import pickle, re, sys, os
R13 = int(os.environ.get('R13', '108000'), 16)
ins, refs = pickle.load(open(sys.argv[1], 'rb'))
a0 = int(sys.argv[2], 16); b = int(sys.argv[3]) if len(sys.argv) > 3 else 20; n = int(sys.argv[4]) if len(sys.argv) > 4 else 40
base = ins[0][0]; k = (a0 - base) // 4
r = {a: v for a, m, o, v in refs}
for a, m, o in ins[max(0, k - b):k + n]:
    note = ''
    mm = re.search(r'(-?0x[0-9a-f]+|-?\d+)\(r13\)', o)
    if mm: note = f'  ; g{R13 + int(mm.group(1), 0):06x}'
    elif m == 'addi' and ', r13, ' in o: note = f'  ; &g{R13 + int(o.split(",")[2], 0):06x}'
    elif a in r: note = f'  ; {r[a]:08x}'
    print(f'{"=>" if a == a0 else "  "}{a:08x} {m} {o}{note}')
