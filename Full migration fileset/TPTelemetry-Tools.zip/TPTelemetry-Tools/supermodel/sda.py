# sda.py <pkl> <addr hex>... : instructions using a global through r13 (Scud Race: 0x108000; set R13 for another game) or an absolute lis/addi pair.
import pickle, re, sys, os
R13 = int(os.environ.get('R13', '108000'), 16)
ins, refs = pickle.load(open(sys.argv[1], 'rb'))
want = {int(x, 16) for x in sys.argv[2:]}
memre = re.compile(r'(-?0x[0-9a-f]+|-?\d+)\(r13\)')
out = []
for a, m, o in ins:
    mm = memre.search(o)
    if mm and m != 'addi':
        v = R13 + int(mm.group(1), 0)
        if v in want: out.append((a, m, o, v))
    elif m == 'addi' and ', r13, ' in o:
        v = R13 + int(o.split(",")[2], 0)
        if v in want: out.append((a, m, o, v))
for a, m, o, v in refs:
    if v in want: out.append((a, m, o, v))
for a, m, o, v in sorted(out): print(f'{a:08x} {m} {o}  ; {v:06x}')
