#!/bin/sh
# Daytona 2 PE: coin, start, Beginner, NORMAL car, MANUAL (steer right held while choosing)
export DISPLAY=:99
K=$(dirname $0)/key.sh
$K 3 0.15; sleep 1.5; $K 1 0.15; sleep 4.5; $K Up 0.3; sleep 5; $K Up 0.3; sleep 5
W=$(xdotool search --name Supermodel | head -1)
xdotool keydown --window $W Right; sleep 0.8; xdotool keydown --window $W Up; sleep 0.3; xdotool keyup --window $W Up; xdotool keyup --window $W Right
