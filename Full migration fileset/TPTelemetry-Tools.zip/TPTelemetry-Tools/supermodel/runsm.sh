#!/bin/sh
# Runs the analysis build of Supermodel headless on display :99. $1 = dump dir, $2 = dump every N frames, rest = extra options.
D=$1; N=$2; shift 2
cd ${SMRUN:?set SMRUN to the folder with supermodel, Config, Assets, ROMs and NVRAM}
SDL_AUDIODRIVER=dummy SM_DUMP_DIR=$D SM_DUMP_EVERY=$N DISPLAY=:99 LIBGL_ALWAYS_SOFTWARE=1 ./supermodel ROMs/${GAME:-scud.zip} -window -res=496,384 -legacy3d -no-sound -no-dsb -show-fps "$@" > /tmp/sm.log 2>&1
