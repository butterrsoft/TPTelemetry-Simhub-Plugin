# exactfull.py <dumpdir> <map.txt> <idx:value,...> : bytes/halfwords/words (PPC addresses) equal to the values in full RAM dumps.
import sys, numpy as np
D, M, spec = sys.argv[1], sys.argv[2], sys.argv[3]
mp = dict(l.split() for l in open(M))
pairs = [(p.split(':')[0], float(p.split(':')[1])) for p in spec.split(',')]
raws = [np.frombuffer(open(f'{D}/{mp[i]}', 'rb').read(), np.uint8) for i, _ in pairs]
res = {}
for name in ['b0', 'b1', 'b2', 'b3', 'h0', 'h1', 'i32', 'f32']:
    ok = None
    for r, (_, v) in zip(raws, pairs):
        W = r.view('<u4')
        if name[0] == 'b': V = r[(3 - int(name[1]))::4].astype(np.int64)
        elif name[0] == 'h': V = ((W >> 16) if name[1] == '0' else (W & 0xFFFF)).astype(np.int16).astype(np.int64)
        elif name == 'i32': V = W.view('<i4').astype(np.int64)
        else: V = W.view('<f4')
        m = (np.abs(V - v) < 0.01) if name == 'f32' else (V == v)
        ok = m if ok is None else ok & m
    for j in np.nonzero(ok)[0][:30]:
        addr = 4 * j + (int(name[1]) if name[0] == 'b' else (2 * int(name[1]) if name[0] == 'h' else 0))
        print(f'{name} {addr:06x}')
