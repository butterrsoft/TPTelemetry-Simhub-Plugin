# drive.py <outdir> <script> : plays key actions into the Supermodel window on :99 and takes a screenshot every second.
# Script lines: "<t seconds> down|up|tap <keysym> [hold]" ; "<t> shot". Logs wall times of every action to <outdir>/actions.txt.
import subprocess, sys, time, os, threading
out, script = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
env = dict(os.environ, DISPLAY=':99')
W = subprocess.run(['xdotool', 'search', '--name', 'Supermodel'], capture_output=True, text=True, env=env).stdout.split()[0]
log = open(f'{out}/actions.txt', 'w')
def x(*a): subprocess.run(['xdotool', *a], env=env, capture_output=True)
def act(cmd, key, hold):
    if cmd == 'down': x('keydown', '--window', W, key)
    elif cmd == 'up': x('keyup', '--window', W, key)
    elif cmd == 'tap': x('keydown', '--window', W, key); time.sleep(hold); x('keyup', '--window', W, key)
    log.write(f'{time.time():.3f} {cmd} {key}\n'); log.flush()
stop = False
def shots():
    i = 0
    while not stop:
        t = time.time()
        subprocess.run(['import', '-window', 'root', '-crop', '496x384+72+48', f'{out}/s{i:04d}.png'], env=env, capture_output=True)
        log.write(f'{t:.3f} shot s{i:04d}\n'); log.flush()
        i += 1; time.sleep(max(0, 1.0 - (time.time() - t)))
th = threading.Thread(target=shots); th.start()
t0 = time.time()
for line in open(script):
    p = line.split()
    if not p or p[0].startswith('#'): continue
    t = float(p[0]); time.sleep(max(0, t0 + t - time.time()))
    if p[1] == 'end': break
    act(p[1], p[2], float(p[3]) if len(p) > 3 else 0.15)
stop = True; th.join()
