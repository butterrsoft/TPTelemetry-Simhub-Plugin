#!/bin/sh
# snaps.sh <outdir> <count> <interval s> : triggers a RAM dump and takes a screenshot each interval; prints index -> dump frame
D=${SNAPD:?set SNAPD to the dump folder}; O=$1; mkdir -p $O
i=0
while [ $i -lt $2 ]; do
  touch $D/trigger; $(dirname $0)/shot.sh $O/s$i.png
  sleep 0.2; f=$(ls -t $D/f*.bin | head -1); echo "$i $(basename $f)" >> $O/map.txt
  i=$((i+1)); sleep $3
done
