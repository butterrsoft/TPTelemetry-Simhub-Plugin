# ppcidx.py <crom.bin> <base hex> <out.pkl> : disassembles big-endian PowerPC code and records absolute data addresses
# formed by "lis rX, hi" + "addi/ori/load/store lo(rX)" (also r13/r2 small-data accesses, with their bases if found).
import sys, pickle, re
from capstone import Cs, CS_ARCH_PPC, CS_MODE_32, CS_MODE_BIG_ENDIAN
data = open(sys.argv[1], 'rb').read(); base = int(sys.argv[2], 16)
md = Cs(CS_ARCH_PPC, CS_MODE_32 | CS_MODE_BIG_ENDIAN)
ins = []
off = 0
while off < len(data):
    got = False
    for i in md.disasm(data[off:off+0x10000], base + off):
        ins.append((i.address, i.mnemonic, i.op_str)); got = True
        off = i.address - base + 4
    if not got or off % 0x10000: 
        if not got: ins.append((base + off, '.word', data[off:off+4].hex())); off += 4
refs = []
hi = {}
memre = re.compile(r'(-?0x[0-9a-f]+|-?\d+)\((r\d+)\)')
for a, m, o in ins:
    ops = [x.strip() for x in o.split(',')]
    if m == 'lis' and len(ops) == 2:
        hi[ops[0]] = (int(ops[1], 0) & 0xFFFF) << 16; continue
    if m in ('addi', 'addic') and len(ops) == 3 and ops[1] in hi:
        v = (hi[ops[1]] + int(ops[2], 0)) & 0xFFFFFFFF; refs.append((a, m, o, v))
        if ops[0] != ops[1]: hi.pop(ops[0], None)
        else: hi[ops[0]] = v  # keep as full address
        continue
    if m == 'ori' and len(ops) == 3 and ops[1] in hi:
        v = hi[ops[1]] | (int(ops[2], 0) & 0xFFFF); refs.append((a, m, o, v)); hi[ops[0]] = v; continue
    mm = memre.search(o)
    if mm and mm.group(2) in hi:
        v = (hi[mm.group(2)] + int(mm.group(1), 0)) & 0xFFFFFFFF; refs.append((a, m, o, v))
    if m.startswith('b') or m in ('rfi',): hi = {}
    elif ops and ops[0] in hi and not m.startswith(('st', 'cmp')): hi.pop(ops[0], None)
pickle.dump((ins, refs), open(sys.argv[3], 'wb'))
print(len(ins), 'instructions,', len(refs), 'absolute references')
