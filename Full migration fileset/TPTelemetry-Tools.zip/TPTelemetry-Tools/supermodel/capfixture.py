# capfixture.py <capture.csv> <profile.json> <step> <out.csv.gz> [max revs] : a replay fixture from a TP Telemetry recording
# of SMSCUD (or SMDAYTO2PE with PRE=SMDAYTO2PE): t, mark, then each memory row's raw value, worked back from the recorded
# output (Max speed 350; Max revs 7500 unless given). Rows the recording didn't have are left out (NaN in the replay).
import sys, json, gzip, pandas as pd, numpy as np
import os; PRE = os.environ.get('PRE', 'SMSCUD')
d = pd.read_csv(sys.argv[1], low_memory=False); d.columns = [c.replace(PRE + '_', '') for c in d.columns]
prof = json.load(open(sys.argv[2])); step = int(sys.argv[3])
MR = float(sys.argv[5]) if len(sys.argv) > 5 else 7500
inv = {'speed': lambda x: x * 350, 'rpm': lambda x: x * MR, 'rt': lambda x: x * 57, 'race_clock': lambda x: x * 57,
       'lap': lambda x: x - 1, 'lap_start': lambda x: x * 57, 'best_lap': lambda x: x * 57, 'last_lap': lambda x: x * 57,
       'position': lambda x: x - 1, 'throttle': lambda x: x * 255, 'brake': lambda x: x * 255, 'steer': lambda x: x * 32766}
if PRE == 'SMDAYTO2PE':   # 18 November 2026, 16:40 recordings: in-game byte 255 read as 1, near car bit 4
    inv.update({'playing': lambda x: x * 255, 'near_car': lambda x: x * 16})
alias = {'misc_2c4': 'wheel_angle', 'car_contact': 'contact_3c0'}
cols = []
for v in prof['Variables']:
    if v['Source'] != 'Memory': continue
    src = v['Name'] if v['Name'] in d.columns else alias.get(v['Name'], v['Name'])
    if PRE == 'SMDAYTO2PE' and 'rpm_1e0' in d.columns and v['Name'] in ('rpm', 'rpm_wheels'):
        # recorded 18:57 to 19:10 (18 November 2026): `rpm` was +0x1DC (now `rpm_wheels`), `rpm_1e0` the rev counter (now `rpm`)
        x = d['rpm_1e0'].astype(float) if v['Name'] == 'rpm' else d['rpm'].astype(float) * MR
        cols.append((v['Name'], v['Type'], x.round().values)); continue
    if src not in d.columns: continue
    x = inv.get(v['Name'], lambda x: x)(d[src].astype(float))
    if v['Type'] != 'Float': x = x.round()
    cols.append((v['Name'], v['Type'], x.values))
if PRE == 'SMDAYTO2PE' and 'Output_RawDrive' in d.columns:   # the drive board commands too (car-hit sides, 18 November 2026)
    cols.append(('out_RawDrive', 'Int32', d['Output_RawDrive'].fillna(0).astype(float).values))
mk_all = d.marker.values.copy()
for i in range(len(mk_all)):   # a mark on a dropped sample moves to the next kept one
    if mk_all[i] == mk_all[i] and i % step: mk_all[i + step - i % step if i + step - i % step < len(mk_all) else i - i % step] = mk_all[i]
d = d.copy(); d['marker'] = mk_all
d = d.iloc[::step]; idx = d.index.values
with gzip.open(sys.argv[4], 'wt', newline='\n') as f:
    f.write('t,mark,' + ','.join(n for n, _, _ in cols) + '\n')
    for i in idx:
        m = d.at[i, 'marker']; mk = '' if m != m else str(int(m))
        vals = [(repr(float(x[i])) if t == 'Float' else str(int(x[i]))) for n, t, x in cols]
        f.write(f"{d.at[i, 'time_s']:.4f},{mk}," + ','.join(vals) + '\n')
print(len(idx), 'samples', len(cols), 'rows')
