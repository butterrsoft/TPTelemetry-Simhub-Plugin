import os
B, BITS = (int(open('base.txt').read().split()[0], 16), int(open('base.txt').read().split()[1])) if os.path.exists('base.txt') else (0x400000, 32)
import pefile,struct,sys,pickle,re
pe=pefile.PE('bin.exe', fast_load=True)

def strat(v):
    try: return pe.get_data(v-B,80).split(b'\0')[0].decode('latin1')
    except Exception: return ''

for a in sys.argv[1:]:
    lo,hi=[int(x,16) for x in a.split('-')]
    v=lo
    while v<hi:
        s=strat(v)
        if len(s)>=3: print(hex(v), repr(s)); v+=len(s)+1
        else: v+=1
