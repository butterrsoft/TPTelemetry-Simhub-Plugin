import pickle, sys, bisect
ins=pickle.load(open('ins.pkl','rb')); addrs=[i[0] for i in ins]
def at(a): 
    k=bisect.bisect_left(addrs,a); return k if k<len(addrs) and addrs[k]==a else None
def resolve(a):
    k=at(a)
    while k is not None and ins[k][2]=='jmp' and ins[k][3].startswith('0x'):
        a=int(ins[k][3],16); k=at(a)
    return a
n=int(sys.argv[2]) if len(sys.argv)>2 else 200
a=resolve(int(sys.argv[1],16)); k=at(a); print(f'== {a:08X}')
c=0
while k is not None and c<n:
    ad,s,m,o=ins[k]
    # resolve call thunks
    if m=='call' and o.startswith('0x'): o=o+' -> '+hex(resolve(int(o,16)))
    print(f'{ad:08X} {m} {o}'); c+=1
    if m=='ret' and c>3 and len(sys.argv)<4: break
    k+=1
