# Exe-reading helpers (8 and 9 November 2026; four added 12 November; 64-bit 16 November)

Small scripts used to read gti3japkey.exe (GTI Club), the Initial D 6 exe and Battle Gear 4's game.exe, and since
16 November 2026 64-bit exes too (Initial D Zero v2.30). Needs Python 3 with `pefile` and `capstone`
(`pip install pefile capstone`). Copy the exe into a working folder as `bin.exe` and run from there, with
`python3 -I` (without it, `const.py` beside the scripts shadows a module capstone imports).

**64-bit (16 November 2026).** `dis.py` reads the exe's machine and image base and writes them to `base.txt` beside
`ins.pkl`; the other scripts read that file (no file: 32-bit at 0x400000, as before). In 64-bit code RIP-relative
operands are written as absolute addresses (`[rip + 0x10]` becomes `[0x140001234]`), so `xref.py <exe offset>` finds a
global the same way as in 32-bit code. `rawref.py` and `vtables.py` use 8-byte pointers, `rtti.py` the 64-bit RTTI
layout (image-relative offsets, signature 1), `cowrite.py` skips rsp, `const.py` also reads `q:` (64-bit) values.
`regs.py` and `callers.py`' padding guess are 32-bit habits (pushed arguments, int3/ret padding): in 64-bit code
arguments go in registers. Initial D Zero's 27 MB exe gives 5.7 million instructions (`ins.pkl` 155 MB, 13 s); the
`.pdata` section lists every function's start and end, handier than the padding guess.

| Script | Use |
|---|---|
| `dis.py` | Run first: disassembles the code section into `ins.pkl` (address, size, mnemonic, operands). |
| `around.py <addr> [n]` | Instructions around a code address (hex). |
| `xref.py <exe offsets>` | Instructions mentioning `<main>+offset` (hex offsets, e.g. `67FCC8`). |
| `field.py <0x...>` | Instructions using a structure offset, e.g. `0x2c4`. |
| `callers.py <addr>` | The function an address is in, and its callers. |
| `const.py <t:addr>` | Reads values stored at addresses in the exe (`i:` 32-bit int, `f:` float, `d:` double, `q:` 64-bit int). |
| `rawref.py <addr>` | Where an address (4 bytes, or 8 in a 64-bit exe) appears in the exe's data. |
| `sref.py <text>` | Code referring to a string. |
| `strings_at.py <from-to>` | Strings in an address range. |
| `rtti.py [Class]` | Finds C++ class vtables from RTTI into `vt.pkl`; with class names, prints their first methods. Names keep their namespace (`CSpeed@bg4`). |
| `fn.py <addr> [n] [x]` | A function from an address, following jump thunks (and resolving them in calls); stops at `ret` unless `x` is given. |
| `calls.py <addr>...` | Every call to a function, directly or through its jump thunk. |
| `fstart.py <addr>...` | The function an address is in (from the padding before it), its direct callers and code mentioning it; for a virtual function, then `rawref.py` on its start. (12 November) |
| `regs.py <from> <to>` | Names registered with a getter or handler in a range: each `push fn; push "name"; call` pair. GRID's commentary facts. (12 November) |
| `cowrite.py <off>...` | Functions that write every one of some structure offsets: finds the code that fills a structure. (12 November) |
| `vtables.py` | Every run of 13+ code pointers in .rdata into `vts.pkl`, for exes without RTTI (GRID). (12 November) |

Findings from them are in the GTICLUB3, ID6, BG4JP, Mario Kart, GRID, SR3 and ID0V230 exe notes.
