import os
B, BITS = (int(open('base.txt').read().split()[0], 16), int(open('base.txt').read().split()[1])) if os.path.exists('base.txt') else (0x400000, 32)
import pickle, sys, bisect
ins=pickle.load(open('ins.pkl','rb')); addrs=[i[0] for i in ins]
# thunk map: jmp in the first 0x5000 bytes of code
thunks={}
for a,s,m,o in ins:
    if a<B+0x6000 and m=='jmp' and o.startswith('0x'): thunks.setdefault(int(o,16),[]).append(a)
starts=set()
for a,s,m,o in ins:
    if m=='call' and o.startswith('0x'): starts.add(int(o,16))
for t in sys.argv[1:]:
    f=int(t,16); names={f}|set(thunks.get(f,[]))
    hits=[(a,o) for a,s,m,o in ins if m in('call','jmp') and o.startswith('0x') and int(o,16) in names and a>=B+0x6000]
    print(f'== {f:X} called from', ' '.join(f'{a:X}' for a,o in hits[:30]))
