import os
B, BITS = (int(open('base.txt').read().split()[0], 16), int(open('base.txt').read().split()[1])) if os.path.exists('base.txt') else (0x400000, 32)
import pickle, sys, re
ins=pickle.load(open('ins.pkl','rb'))
targets=[int(x,16)+B for x in sys.argv[1:]]
for t in targets:
    h=hex(t)
    hits=[i for i in ins if h in i[3]]
    print(f'== exe+{t-B:X} ({h}): {len(hits)} refs')
    for a,s,m,o in hits[:25]: print(f'   {a:08X} {m} {o}')
