import os
B, BITS = (int(open('base.txt').read().split()[0], 16), int(open('base.txt').read().split()[1])) if os.path.exists('base.txt') else (0x400000, 32)
import pefile,pickle,re,sys
pe=pefile.PE('bin.exe'); ins=pickle.load(open('ins.pkl','rb')); data=open('bin.exe','rb').read()
for s in sys.argv[1:]:
    for m in re.finditer(re.escape(s.encode())+b'\0', data):
        if m.start()>0 and data[m.start()-1]!=0: continue
        v=pe.get_rva_from_offset(m.start())+B; h=hex(v)
        print(s, h, [hex(a) for a,_,mm,o in ins if h in o][:8])
