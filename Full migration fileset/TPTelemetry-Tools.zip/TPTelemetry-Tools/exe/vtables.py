"""Every run of 13 or more code pointers (4 or 8 bytes) in .rdata (vtables, for exes without RTTI), saved to vts.pkl as (address, [functions]).
Usage: python3 -I vtables.py, then load vts.pkl and look for a vtable by what its slots hold (GRID's race clock records,
12 November 2026: slot +14 'mov eax, [ecx+18]; ret' gave the laps done)."""
import os
B, BITS = (int(open('base.txt').read().split()[0], 16), int(open('base.txt').read().split()[1])) if os.path.exists('base.txt') else (0x400000, 32)
import pefile, struct, pickle
pe = pefile.PE('bin.exe')
rd = [s for s in pe.sections if s.Name.startswith(b'.rdata')][0]
base = B + rd.VirtualAddress; data = rd.get_data()
t = pe.sections[0]; TLO = B + t.VirtualAddress; THI = TLO + t.Misc_VirtualSize
res = []; i = 0
while i < len(data) - 4:
    j = i; fns = []
    while j < len(data) - 4:
        p = struct.unpack_from('<Q' if BITS == 64 else '<I', data, j)[0]
        if TLO <= p < THI: fns.append(p); j += BITS // 8
        else: break
    if len(fns) >= 13: res.append((base + i, fns)); i = j
    else: i += BITS // 8
pickle.dump(res, open('vts.pkl', 'wb'))
print(len(res))
