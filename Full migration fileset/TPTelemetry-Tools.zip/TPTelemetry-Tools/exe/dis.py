"""Disassembles the code section of bin.exe into ins.pkl (address, size, mnemonic, operands) and writes base.txt
(image base and 32 or 64) for the other scripts. 32-bit and 64-bit exes (64-bit added 16 November 2026 for Initial D
Zero): in 64-bit code, RIP-relative operands are written as absolute addresses ([rip + 0x10] -> [0x140001234]), so
xref.py finds them the same way as in 32-bit code."""
import pefile, capstone, pickle, sys, re
pe = pefile.PE('bin.exe', fast_load=True)
bits = 64 if pe.FILE_HEADER.Machine == 0x8664 else 32
B = pe.OPTIONAL_HEADER.ImageBase
t = pe.sections[0]; code = t.get_data()[:t.Misc_VirtualSize]; base = B + t.VirtualAddress
md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64 if bits == 64 else capstone.CS_MODE_32); md.detail = False
RIP = re.compile(r'\[rip ([+-]) 0x([0-9a-f]+)\]')
intern = sys.intern
ins = []
off = 0
while off < len(code):
    for a, s, m, o in md.disasm_lite(code[off:], base + off):
        if 'rip' in o:
            o = RIP.sub(lambda g: '[%s]' % hex(a + s + (int(g.group(2), 16) if g.group(1) == '+' else -int(g.group(2), 16))), o)
        ins.append((a, s, intern(m), o)); off = a - base + s
    if off < len(code): off += 1
pickle.dump(ins, open('ins.pkl', 'wb'), protocol=4)
open('base.txt', 'w').write('%x %d\n' % (B, bits))
print(len(ins), hex(B), bits)
