import os
B, BITS = (int(open('base.txt').read().split()[0], 16), int(open('base.txt').read().split()[1])) if os.path.exists('base.txt') else (0x400000, 32)
import pefile,struct,sys,re
pe=pefile.PE('bin.exe', fast_load=True)
d=open('bin.exe','rb').read()
for a in sys.argv[1:]:
    v=int(a,16); pat=struct.pack('<Q' if BITS==64 else '<I',v)
    hits=[pe.get_rva_from_offset(m.start())+B for m in re.finditer(re.escape(pat),d)]
    print(a,[hex(h) for h in hits[:12]])
