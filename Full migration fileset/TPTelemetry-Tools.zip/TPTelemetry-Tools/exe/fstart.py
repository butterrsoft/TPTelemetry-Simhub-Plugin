"""The function an address is in (from the int3 padding before it), its direct callers, and code mentioning its address.
For a virtual function with no callers, run rawref.py on the start to find its vtable.
Usage: python3 -I fstart.py <addr> ...   (hex)"""
import pickle, bisect, sys, re
ins = pickle.load(open('ins.pkl', 'rb')); A = [i[0] for i in ins]
def start(a):
    j = bisect.bisect_left(A, a)
    while j > 0 and ins[j - 1][2] != 'int3': j -= 1
    return ins[j][0]
for x in sys.argv[1:]:
    st = start(int(x, 16))
    cs = [hex(i[0]) for i in ins if i[2] in ('call', 'jmp') and i[3] == hex(st)]
    refs = [hex(i[0]) for i in ins if re.search(r'\b%s\b' % hex(st), i[3]) and i[2] not in ('call', 'jmp')]
    print(x, 'fn', hex(st), 'callers', cs[:10], 'refs', refs[:6])
