import pickle, sys, bisect
ins=pickle.load(open('ins.pkl','rb')); addrs=[i[0] for i in ins]
for a in sys.argv[1:]:
    a,b,c=(a.split(':')+['30','30'])[:3]; a=int(a,16)
    k=bisect.bisect_left(addrs,a)
    print('-----',hex(a))
    for i in ins[max(0,k-int(b)):k+int(c)]: print(f'{i[0]:08X} {i[2]} {i[3]}')
