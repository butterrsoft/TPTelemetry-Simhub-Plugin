"""Names registered with a getter or handler: lists each (function, "name") pair pushed before a call in an address range.
GRID's commentary facts (inRace, playerPos, engDam ...) are registered this way (12 November 2026).
Usage (in the folder holding bin.exe and ins.pkl): python3 -I regs.py <from> <to>   (hex addresses)"""
import os
B, BITS = (int(open('base.txt').read().split()[0], 16), int(open('base.txt').read().split()[1])) if os.path.exists('base.txt') else (0x400000, 32)
import pickle, sys, pefile
pe = pefile.PE('bin.exe')
ins = pickle.load(open('ins.pkl', 'rb'))
idx = {a: i for i, (a, *_) in enumerate(ins)}
def s(va):
    return pe.get_data(va - B, 80).split(b'\0')[0].decode('latin1')
lo, hi = int(sys.argv[1], 16), int(sys.argv[2], 16)
i = idx[lo]; pend = []
while ins[i][0] < hi:
    a, _, m, o = ins[i]
    if m == 'push' and o.startswith('0x'): pend.append(int(o, 16))
    if m == 'call' and len(pend) >= 2:
        try: print(hex(pend[-2]), s(pend[-1]))
        except Exception: pass
    if m == 'call': pend = []
    i += 1
