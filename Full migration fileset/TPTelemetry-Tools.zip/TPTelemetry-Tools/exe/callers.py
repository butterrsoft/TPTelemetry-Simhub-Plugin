import pickle,bisect,sys
ins=pickle.load(open('ins.pkl','rb')); A=[i[0] for i in ins]
def start(a):
    k=bisect.bisect_left(A,a); j=k
    while j>0 and not (ins[j-1][2] in ('int3','ret','nop') or (ins[j-1][2]=='jmp' and ins[j][2]=='push')): j-=1
    return j
for x in sys.argv[1:]:
    a=int(x,16); j=start(a); st=ins[j][0]
    cs=[k for k,i in enumerate(ins) if i[2] in('call','jmp') and i[3]==hex(st)]
    print(f'== {x} in fn {st:X}; callers {[hex(ins[k][0]) for k in cs][:8]}')
    for k in cs[:4]:
        print('   ', ' ; '.join(f'{ins[q][2]} {ins[q][3]}' for q in range(k-3,k+5)))
