"""C++ class vtables from RTTI into vt.pkl ({class name: vtable address}); with class names, prints their first methods.
32-bit (pointers in the locator) and 64-bit (image-relative offsets in the locator, signature 1; 16 November 2026)."""
import os
B, BITS = (int(open('base.txt').read().split()[0], 16), int(open('base.txt').read().split()[1])) if os.path.exists('base.txt') else (0x400000, 32)
import pefile, struct, re, sys, pickle
pe=pefile.PE('bin.exe', fast_load=True); data=open('bin.exe','rb').read()
P = 8 if BITS == 64 else 4
t=pe.sections[0]; TEXT_LO=B+t.VirtualAddress; TEXT_HI=TEXT_LO+t.Misc_VirtualSize
def rd(va,n=4): return pe.get_data(va-B,n)
def ptr(va): return struct.unpack('<Q' if P == 8 else '<I', rd(va, P))[0]
names={}
for m in re.finditer(rb'\.\?A[VU]([A-Za-z0-9_@$?]+)@@\0', data):
    try: td=pe.get_rva_from_offset(m.start())+B-2*P
    except Exception: continue
    names[td]=m.group(1).decode()
cols={}
for s in pe.sections:
    if not s.Name.startswith((b'.rdata', b'.data')): continue
    rs=s.VirtualAddress+B; rb_=s.get_data()
    for i in range(0,len(rb_)-24,4):
        if BITS == 64:
            sig,off,cd,td,ch,me=struct.unpack_from('<6I',rb_,i)
            if sig==1 and off==0 and td+B in names and me==s.VirtualAddress+i: cols[rs+i]=names[td+B]
        else:
            sig,off,cd,td,ch=struct.unpack_from('<5I',rb_,i)
            if sig==0 and td in names and off==0: cols[rs+i]=names[td]
vt={}
for s in pe.sections:
    if not s.Name.startswith(b'.rdata'): continue
    rs=s.VirtualAddress+B; rb_=s.get_data()
    for i in range(0,len(rb_)-P,P):
        p=struct.unpack_from('<Q' if P == 8 else '<I',rb_,i)[0]
        if p in cols: vt[cols[p]]=rs+i+P
pickle.dump(vt,open('vt.pkl','wb'))
print(len(vt), 'vtables')
for n in sys.argv[1:]:
    v=vt.get(n)
    if not v: print(n,'?'); continue
    fns=[]
    for k in range(12):
        f=ptr(v+P*k)
        if not (TEXT_LO<=f<TEXT_HI): break
        fns.append(hex(f))
    print(n, hex(v), fns)
