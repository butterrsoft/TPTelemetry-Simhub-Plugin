import pickle, sys, re
ins=pickle.load(open('ins.pkl','rb'))
for f in sys.argv[1:]:
    pat=re.compile(r'\[\w+ \+ '+f+r'\]')
    hits=[i for i in ins if pat.search(i[3])]
    w=[i for i in hits if re.match(r'(mov|fstp|fst|movss|movd|inc|dec|add|sub)',i[2]) and i[3].startswith(('dword','word','byte','qword')) ]
    print(f'== +{f}: {len(hits)} refs, {len(w)} writes')
    for a,s,m,o in w[:20]: print(f'   W {a:08X} {m} {o}')
