"""Functions that write every one of some structure offsets (any width; not through esp or rsp).
Finds the code that fills a structure when only its field offsets are known.
Usage: python3 -I cowrite.py <off> <off> ...   (hex; with four or more offsets, one may be missing)"""
import os
B, BITS = (int(open('base.txt').read().split()[0], 16), int(open('base.txt').read().split()[1])) if os.path.exists('base.txt') else (0x400000, 32)
import pickle, sys, re, collections
ins = pickle.load(open('ins.pkl', 'rb'))
offs = [int(x, 16) for x in sys.argv[1:]]
start = None; prev = None; hits = collections.defaultdict(set)
for a, _, m, o in ins:
    if prev == 'int3' and m != 'int3': start = a
    prev = m
    if m in ('mov', 'movss', 'fstp', 'fistp', 'movd') or m.startswith('set'):
        dst = o.split(', ')[0]
        for off in offs:
            if re.search(r'\[(?!esp|rsp)[a-z0-9]{2,3} \+ 0x%x\]$' % off, dst): hits[start].add(off)
for f, s in sorted(hits.items()):
    if len(s) >= len(offs) - int(len(offs) > 3): print(hex(f), sorted(hex(x) for x in s))
