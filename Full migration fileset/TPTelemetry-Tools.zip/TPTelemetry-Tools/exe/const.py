import os
B, BITS = (int(open('base.txt').read().split()[0], 16), int(open('base.txt').read().split()[1])) if os.path.exists('base.txt') else (0x400000, 32)
import pefile, struct, sys
pe=pefile.PE('bin.exe')
for a in sys.argv[1:]:
    t,a=a.split(':'); a=int(a,16)
    d=pe.get_data(a-B, 8).ljust(8, b'\0')   # uninitialised .data past the file's bytes reads 0
    v=struct.unpack('<d',d)[0] if t=='d' else (struct.unpack('<f',d[:4])[0] if t=='f' else (struct.unpack('<q',d)[0] if t=='q' else struct.unpack('<i',d[:4])[0]))
    print(f'{a:X} {t} {v!r}')
