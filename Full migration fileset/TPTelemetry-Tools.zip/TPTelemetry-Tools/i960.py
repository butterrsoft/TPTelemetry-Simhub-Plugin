import struct,sys
MEM={0x80:'ldob',0x82:'stob',0x84:'bx',0x85:'balx',0x86:'callx',0x88:'ldos',0x8A:'stos',0x8C:'lda',0x90:'ld',0x92:'st',0x98:'ldl',0x9A:'stl',0xA0:'ldt',0xA2:'stt',0xB0:'ldq',0xB2:'stq',0xC0:'ldib',0xC2:'stib',0xC8:'ldis',0xCA:'stis'}
CTRL={0x08:'b',0x09:'call',0x0A:'ret',0x0B:'bal',0x10:'bno',0x11:'bg',0x12:'be',0x13:'bge',0x14:'bl',0x15:'bne',0x16:'ble',0x17:'bo'}
COBR={0x20:'testno',0x21:'testg',0x22:'teste',0x23:'testge',0x24:'testl',0x25:'testne',0x26:'testle',0x27:'testo',0x30:'bbc',0x31:'cmpobg',0x32:'cmpobe',0x33:'cmpobge',0x34:'cmpobl',0x35:'cmpobne',0x36:'cmpoble',0x37:'bbs',0x38:'cmpibno',0x39:'cmpibg',0x3A:'cmpibe',0x3B:'cmpibge',0x3C:'cmpibl',0x3D:'cmpibne',0x3E:'cmpible',0x3F:'cmpibo'}
REG={(0x58,0):'notbit',(0x58,1):'and',(0x58,2):'andnot',(0x58,3):'setbit',(0x58,4):'notand',(0x58,6):'xor',(0x58,7):'or',(0x58,8):'nor',(0x58,0xC):'clrbit',(0x58,0xE):'nand',(0x59,0):'addo',(0x59,1):'addi',(0x59,2):'subo',(0x59,3):'subi',(0x59,8):'shro',(0x59,0xA):'shrdi',(0x59,0xB):'shri',(0x59,0xC):'shlo',(0x59,0xE):'shli',(0x5A,0):'cmpo',(0x5A,1):'cmpi',(0x5A,2):'concmpo',(0x5A,3):'concmpi',(0x5A,4):'cmpinco',(0x5A,6):'cmpdeco',(0x5A,0xC):'scanbyte',(0x5A,0xE):'chkbit',(0x5B,0):'addc',(0x5B,2):'subc',(0x5C,0xC):'mov',(0x5D,0xC):'movl',(0x5E,0xC):'movt',(0x5F,0xC):'movq',(0x70,1):'mulo',(0x70,8):'remo',(0x70,0xB):'divo',(0x74,1):'muli',(0x74,8):'remi',(0x74,0xB):'divi',(0x66,0):'calls',(0x66,0xB):'mark',(0x66,0xC):'fmark',(0x66,0xD):'flushreg',(0x66,0xF):'syncf',(0x67,0):'emul',(0x67,1):'ediv',(0x64,0):'spanbit',(0x64,1):'scanbit',(0x65,0):'modac',(0x65,4):'modtc',(0x65,5):'modpc',(0x5C,0):'?'}
def r(n): return ('g%d'%(n-16)) if n>=16 else ('r%d'%n if n not in (0,1,2) else ['pfp','sp','rip'][n])
def dis(b,base,start,end):
    a=start
    while a<end:
        w=struct.unpack_from('<I',b,a-base)[0]; op=w>>24; s=''; ln=4
        if op in CTRL:
            d=w&0xFFFFFC; d=d-(1<<24) if d&0x800000 else d; s='%s 0x%X'%(CTRL[op],a+d)
        elif op in COBR:
            src1=(w>>19)&31; src2=(w>>14)&31; m=(w>>13)&1; d=w&0x1FFC; d=d-0x2000 if d&0x1000 else d
            s='%s %s,%s,0x%X'%(COBR[op],(str(src1) if m else r(src1)),r(src2),a+d)
            if op<0x30: s='%s %s'%(COBR[op],r(src1))
        elif op in MEM:
            reg=(w>>19)&31; abase=(w>>14)&31; mode=(w>>10)&0xF
            if (w>>12)&1==0:   # MEMA
                off=w&0xFFF; ea=('0x%X(%s)'%(off,r(abase))) if (w>>13)&1 else '0x%X'%off
            else:
                if mode in (0x5,0xC,0xD,0xE,0xF):
                    disp=struct.unpack_from('<I',b,a+4-base)[0]; ln=8
                    ea={0x5:'0x%X(ip)',0xC:'0x%X',0xD:'0x%%X(%s)'%r(abase),0xE:'0x%%X[%s*%d]'%(r(w&31),1<<((w>>7)&7)),0xF:'0x%%X(%s)[%s*%d]'%(r(abase),r(w&31),1<<((w>>7)&7))}[mode]%disp
                elif mode==4: ea='(%s)'%r(abase)
                elif mode==7: ea='(%s)[%s*%d]'%(r(abase),r(w&31),1<<((w>>7)&7))
                else: ea='?mode%X'%mode
            s='%s %s,%s'%(MEM[op],ea,r(reg)) if MEM[op].startswith('st') else '%s %s,%s'%(MEM[op],ea,r(reg))
        elif 0x58<=op<=0x7F:
            opc=(op<<4)|((w>>7)&0xF); name=REG.get((op,(w>>7)&0xF),'reg%03X'%opc)
            dst=(w>>19)&31; s2=(w>>14)&31; s1=w&31; m1=(w>>11)&1; m2=(w>>12)&1
            a1=str(s1) if m1 else r(s1); a2=str(s2) if m2 else r(s2)
            s='%s %s,%s,%s'%(name,a1,a2,r(dst))
        else: s='.word %08X'%w
        print('%06X: %08X %s'%(a,w,s)); a+=ln
if __name__=='__main__':
    b=open(sys.argv[1],'rb').read()
    for rg in sys.argv[2:]:
        s,e=[int(x,16) for x in rg.split('-')]; print('---'); dis(b,0,s,e)
