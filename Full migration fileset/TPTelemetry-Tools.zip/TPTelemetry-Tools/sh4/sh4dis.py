"""SH-4 helpers for NAOMI / NAOMI 2 games read from a RAM image (17 November 2026).

    python3 -I sh4dis.py <ram.bin> dis <address> [count]     disassemble from a game address (0x0C......)
    python3 -I sh4dis.py <ram.bin> lit <value> [value...]    where a 32-bit value sits in a literal pool or data
    python3 -I sh4dis.py <ram.bin> fn <address>              the function around an address (back to the previous rts)

<ram.bin> is the game's RAM, starting at 0x0C000000 (cut from a Flycast save state with flystate.py). PC-relative
loads (mov.l @(disp,PC)) are shown with the value they load. Needs capstone 5 (SH support).
"""
import sys, struct
from capstone import Cs, CS_ARCH_SH, CS_MODE_SH4, CS_MODE_LITTLE_ENDIAN, CS_MODE_SHFPU
BASE = 0x0C000000
def load(p): return open(p, 'rb').read()
def off(a): return a & 0x1FFFFFF
def dis(ram, addr, count=60):
    md = Cs(CS_ARCH_SH, CS_MODE_SH4 | CS_MODE_SHFPU | CS_MODE_LITTLE_ENDIAN)
    out = []; a = addr
    for _ in range(count):
        code = ram[off(a):off(a) + 2]
        op = struct.unpack('<H', code)[0]
        ins = next(md.disasm(code, a), None)
        text = f'{ins.mnemonic} {ins.op_str}' if ins else f'.word 0x{op:04x}'
        note = ''
        if op & 0xF000 == 0xD000:      # mov.l @(disp,PC),Rn
            t = (a & ~3) + 4 + (op & 0xFF) * 4
            note = f'   ; [{t:08X}] = {struct.unpack("<I", ram[off(t):off(t)+4])[0]:08X}'
        elif op & 0xF000 == 0x9000:    # mov.w @(disp,PC),Rn
            t = a + 4 + (op & 0xFF) * 2
            note = f'   ; [{t:08X}] = {struct.unpack("<h", ram[off(t):off(t)+2])[0]:#x}'
        elif op & 0xFF00 == 0xC700:    # mova
            note = f'   ; {(a & ~3) + 4 + (op & 0xFF) * 4:08X}'
        out.append(f'{a:08X} {op:04x}  {text}{note}')
        a += 2
    return out
def lit(ram, value, lo=0, hi=0x2000000):
    pat = struct.pack('<I', value); res = []; i = ram.find(pat, lo)
    while 0 <= i < hi:
        if i % 4 == 0: res.append(BASE + i)
        i = ram.find(pat, i + 1)
    return res
def fn_start(ram, addr):
    a = addr & ~1
    while a > BASE:
        if struct.unpack('<H', ram[off(a)-4:off(a)-2])[0] == 0x000B: return a   # after rts + delay slot
        a -= 2
    return a
if __name__ == '__main__':
    ram = load(sys.argv[1]); cmd = sys.argv[2]
    if cmd == 'dis':
        print('\n'.join(dis(ram, int(sys.argv[3], 16), int(sys.argv[4]) if len(sys.argv) > 4 else 60)))
    elif cmd == 'lit':
        for v in sys.argv[3:]:
            print(v, [f'{x:08X}' for x in lit(ram, int(v, 16))][:60])
    elif cmd == 'fn':
        s = fn_start(ram, int(sys.argv[3], 16)); print('\n'.join(dis(ram, s, int(sys.argv[4]) if len(sys.argv) > 4 else 120)))
