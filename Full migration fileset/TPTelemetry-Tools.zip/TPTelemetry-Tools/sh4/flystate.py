"""Unpacks a Flycast save state (17 November 2026; Flycast v2.5, "FLYSAVE1").

    python3 -I flystate.py <game.state> <out prefix> [ram offset, hex]

Writes <prefix>.png (the screenshot Flycast keeps in the state: the HUD at the moment it was saved), <prefix>.raw (the
whole state, unpacked) and <prefix>.ram (the game's 32 MB of RAM, game address 0x0C000000 first; NAOMI 2).

Layout: "FLYSAVE1", 8 bytes of time, version (u32), screenshot size (u32), the PNG, then "#RZIPv\\x01#", chunk size
(u32), total size (u64) and zlib chunks, each after its own size (u32). The RAM isn't at a fixed place in the unpacked
state: it is found from the copy of the game's header the BIOS keeps at 0x0C01F400 ("Naomi2" or "NAOMI", 16 bytes),
or give the offset yourself (0x3829337 in Initial D 3's states).
"""
import sys, struct, zlib
def unpack(path):
    d = open(path, 'rb').read()
    assert d[:8] == b'FLYSAVE1', 'not a Flycast v2.5 state'
    n = struct.unpack_from('<I', d, 20)[0]
    png, z = d[24:24 + n], d[24 + n:]
    assert z[:6] == b'#RZIPv', 'unexpected compression'
    total = struct.unpack_from('<Q', z, 12)[0]
    p, out = 20, bytearray()
    while p < len(z) and len(out) < total:
        c = struct.unpack_from('<I', z, p)[0]; p += 4
        out += zlib.decompress(z[p:p + c]); p += c
    return png, bytes(out)
def ram_start(raw):
    for tag in (b'Naomi2          ', b'NAOMI           '):
        i = raw.find(tag)
        while i >= 0:
            if raw[i + 16:i + 20].isalpha() and i - 0x1F400 >= 0: return i - 0x1F400
            i = raw.find(tag, i + 1)
    return None
if __name__ == '__main__':
    png, raw = unpack(sys.argv[1]); pre = sys.argv[2]
    s = int(sys.argv[3], 16) if len(sys.argv) > 3 else ram_start(raw)
    open(pre + '.png', 'wb').write(png); open(pre + '.raw', 'wb').write(raw)
    if s is None: sys.exit('RAM not found: give its offset')
    open(pre + '.ram', 'wb').write(raw[s:s + 0x2000000])
    print(f'RAM at 0x{s:X} of the unpacked state; first bytes {raw[s + 0x20000:s + 0x20004].hex()}')
