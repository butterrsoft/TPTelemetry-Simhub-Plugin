-- tptram.lua: TP Telemetry RAM logger for SEGA Model 2 Emulator 1.1c (emulator_multicpu.exe)
--
-- Records the game's RAM while you drive, so the values TP Telemetry needs (speed, revs, gear,
-- timer, position...) can be found from one recording instead of many Cheat Engine scans.
-- Only reads memory. Loaded by SCRIPTS\<romname>.lua (see stcc.lua), after the emulator's own script.
--
-- Output: TPTRAM_<romname>_<date>_<time>.txt in the emulator folder.
--   F <frame> <seconds>           start of a frame's lines
--   <address> <value>             a 32-bit word that changed (hex, the game's own address)
--   M <number>                    you pressed the mark key in this frame
-- The first full pass writes every word; after that only changed words are written.

local CFG = {
  -- regions logged, {from, to} (to not included). Set TPTRAM_REGIONS before loading to change them.
  regions   = TPTRAM_REGIONS or {
    { 0x200000, 0x240000 },  -- second RAM, all 256 KB: STCC's and Sega Rally's variables
    { 0x500000, 0x510000 },  -- work RAM, first 64 KB: Daytona's variables, and RAM+824 (lamps)
  },
  per_frame = TPTRAM_PER_FRAME or 3072,  -- 32-bit words read each frame (whole set about every 27 frames, 0.5 s)
  mark_key  = TPTRAM_MARK_KEY or 0x32,   -- DirectInput key code for the mark key (0x32 = M)
  show      = true,                      -- show "TPT RAM" and the mark count on screen
}

local romname = TPTRAM_ROMNAME or "game"
local file, prev, frame, marks, keydown, failed = nil, {}, 0, 0, false, nil
local region, pos = 1, nil

local function u32(v)
  if v == nil then return 0 end
  if v < 0 then v = v + 4294967296 end
  return v
end

local function open_log()
  local name = string.format("TPTRAM_%s_%s.txt", romname, os.date("%Y%m%d_%H%M%S"))
  file = io.open(name, "w")
  if not file then failed = "can't create " .. name; return end
  local regs = {}
  for _, r in ipairs(CFG.regions) do regs[#regs + 1] = string.format("%X-%X", r[1], r[2]) end
  file:write(string.format("# TPTRAM v2 rom=%s regions=%s per_frame=%d mark_key=%X\n",
    romname, table.concat(regs, ","), CFG.per_frame, CFG.mark_key))
  -- host addresses, to check Cheat Engine's pointer paths against
  for _, a in ipairs({ 0x200000, 0x500000 }) do
    local ok, p = pcall(I960_GetRamPtr, a)
    if ok and p then file:write(string.format("# host %X = %X\n", a, u32(p))) end
  end
  prev, frame, region, pos = {}, 0, 1, CFG.regions[1][1]
end

local function key_pressed(k)
  local ok, r = pcall(Input_IsKeyPressed, k)
  return ok and r ~= nil and r ~= false and r ~= 0
end

local function log_frame()
  if not file then return end
  frame = frame + 1
  local out = { string.format("F %d %.3f", frame, os.clock()) }
  local down = key_pressed(CFG.mark_key)
  if down and not keydown then marks = marks + 1; out[#out + 1] = "M " .. marks end
  keydown = down
  local left = CFG.per_frame
  while left > 0 do
    local r = CFG.regions[region]
    local stop = pos + left * 4
    if stop > r[2] then stop = r[2] end
    for a = pos, stop - 4, 4 do
      local v = u32(I960_ReadDWord(a))
      if prev[a] ~= v then
        prev[a] = v
        out[#out + 1] = string.format("%X %X", a, v)
      end
    end
    left = left - (stop - pos) / 4
    pos = stop
    if pos >= r[2] then
      region = region % #CFG.regions + 1
      pos = CFG.regions[region][1]
      if region == 1 then break end  -- at most one full pass per frame
    end
  end
  file:write(table.concat(out, "\n"), "\n")
  if frame % 600 == 0 then file:flush() end
end

-- chain onto the emulator's own script functions (if it has them)
local oldInit, oldFrame, oldPostDraw, oldReset = Init, Frame, PostDraw, Reset

function Init(...)
  if oldInit then oldInit(...) end
  open_log()
end

function Reset(...)
  if oldReset then oldReset(...) end
  if file then file:write("# reset\n"); file:flush() end
end

function Frame(...)
  if oldFrame then oldFrame(...) end
  if failed then return end
  local ok, err = pcall(log_frame)
  if not ok then failed = tostring(err); if file then file:write("# error: " .. failed .. "\n"); file:flush() end end
end

function PostDraw(...)
  if oldPostDraw then oldPostDraw(...) end
  if CFG.show then
    local text = failed and ("TPT RAM: " .. failed) or string.format("TPT RAM  marks %d", marks)
    pcall(Video_DrawText, 10, 10, text, 0xFFFF00)
  end
end
