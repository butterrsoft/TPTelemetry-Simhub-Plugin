"""Writes Game_Formulas.md into the game profiles pack: every game's formulas, with the notes that say
what each does, taken straight from the profiles so the document can't drift from them.

Run after any change to a profile (memgames.py runs it at the end; run it on its own after editing a
profile it doesn't make, such as WMMT3DXP):   python3 gameformulas.py <pack folder>
"""
import glob, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import packlayout

HEAD = """# Game formulas

Every formula in the game profiles pack, game by game (grouped by emulator, as the pack's folders are), with what each row does. A formula is a row's
recipe: it works the published value out from raw memory reads, TeknoParrot's shared memory, game
outputs or other rows. The formula language itself (functions, operators, names such as `tp_jvs2`,
`out_LampStart`, `max_speed`) is explained in **Formula_Reference.md**, which comes with the plugin.

Use these as examples to copy: the same pattern usually works in another game. Rows marked "not
exported" are working values other rows use; they show in the table but aren't SimHub properties.

This file is generated from the profiles (`tools/gameformulas.py`), so it always matches them. Most
formulas are unverified; the notes say which have been checked against recordings.

"""

def cell(text):
    return (text or '').replace('|', '\\|').replace('\n', ' ').strip()

def main(pack):
    profiles = []
    for f in packlayout.files(pack):
        with open(f, encoding='utf-8') as fh:
            profiles.append(json.load(fh))
    order = {g: i for i, g in enumerate(packlayout.GROUPS)}
    profiles.sort(key=lambda p: (order.get(packlayout.group(p['Prefix']), 99), p['DisplayName'].lower()))
    out = [HEAD, '## Games\n']
    last = None
    for p in profiles:
        g = packlayout.group(p['Prefix'])
        if g != last:
            out.append(f'\n**{g}** (folder `{g}`)\n'); last = g
        anchor = p['Prefix'].lower()
        out.append(f"* [{p['DisplayName']}](#{anchor}) ({p['Prefix']})")
    out.append('')
    for p in profiles:
        rows = [v for v in p['Variables'] if (v.get('Formula') or '').strip()]
        out.append(f'<a id="{p["Prefix"].lower()}"></a>')
        out.append(f"## {p['DisplayName']}\n")
        proc = p.get('ProcessName') or '(none: reads no game memory)'
        out.append(f"Prefix `{p['Prefix']}` (properties `TPTelemetry.{p['Prefix']}_<row>`), process `{proc}`, folder `{packlayout.group(p['Prefix'])}`.\n")
        if not rows:
            out.append('No formulas: every row is a raw memory read.\n')
            continue
        out.append('| Row | Formula | What it does |')
        out.append('|---|---|---|')
        for v in rows:
            name = f"`{v['Name']}`" + ('' if v.get('Enabled', True) else ' (not exported)')
            src = 'memory read, then ' if v.get('Source') == 'Memory' else ''
            out.append(f"| {name} | {src}`{cell(v['Formula'])}` | {cell(v.get('Notes'))} |")
        out.append('')
    path = os.path.join(pack, 'Game_Formulas.md')
    with open(path, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write('\n'.join(out))
    return path, len(profiles)

if __name__ == '__main__':
    path, n = main(sys.argv[1])
    print(f'{path}: {n} games')
