import re, sys, os
OB = os.path.join(os.path.dirname(__file__), '..', 'refsrc', 'ob')
def strip(s):
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
    return re.sub(r'//[^\n]*', '', s)
from pathlib import Path
h = strip(Path(f'{OB}/Output Files/Outputs.h').read_text(encoding='latin-1'))
enum = re.search(r'OutputUnknown\s*=\s*-1\s*,(.*?)\}', h, re.S).group(1)
enames = [e.strip().split('=')[0].strip() for e in enum.split(',') if e.strip()]
c = strip(Path(f'{OB}/Output Files/Outputs.cpp').read_text(encoding='latin-1'))
arr = re.search(r's_outputNames\[\]\s*=\s*\{(.*?)\};', c, re.S).group(1)
names = re.findall(r'"([^"]*)"', arr)
MAP = dict(zip(enames, names))
def outputs(game):
    s = strip(Path(f'{OB}/Game Files/{game}.cpp').read_text(encoding='latin-1'))
    seen = []
    for e in re.findall(r'SetValue\(\s*(Output\w+)', s):
        n = MAP.get(e)
        if n and n not in seen: seen.append(n)
    return seen
if __name__ == '__main__':
    for g in sys.argv[1:]: print(g, outputs(g))
