"""Builds the game-pack profiles for games whose memory the FFB Arcade Plugin reads.

Facts (addresses, types, how each value is decoded) come from the FFB Arcade Plugin and OutputBlaster
sources (Boomslangnz, GPL-3.0). Only facts are used; nothing here is their code.
FFB plugin direction: DIRECTION_FROM_RIGHT -> + here, DIRECTION_FROM_LEFT -> -.
"""
import json, os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
from obnames import outputs as ob_outputs

PACK = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/TPTelemetry-GameProfiles'
MAIN = '<main>'

DIR = ("+ = force from the right, which on WMMT3 matched right-hand corners and right-side hits "
       "(to be confirmed per game).")
UNVERIFIED = " Unverified: from the FFB Arcade Plugin's reading of this game."
BIT64 = " 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later)."

def row(name, source='Computed', typ='Float', module='', base='0', offsets='', formula='', notes=''):
    return dict(Name=name, Enabled=True, Source=source, Type=typ, Module=module, BaseOffset=base,
                Offsets=offsets, Formula=formula, Notes=notes)

# Speed and revs rows divide by the game's Max speed / Max revs (boxes on the settings page, plugin 0.12.0).
# Blank boxes count as 1, so by default these rows publish the raw value; set them and the rows run 0 to 1.
NORM = {'speed': ('max_speed', ' Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1).'),
        'rpm': ('max_revs', ' Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1).')}

def mem(name, typ, base, notes, module=MAIN, offsets='', formula=''):
    if name in NORM and not formula:
        formula = 'value / ' + NORM[name][0]
        notes = notes + NORM[name][1]
    return row(name, 'Memory', typ, module, base, offsets, formula, notes)

def calc(name, formula, notes):
    return row(name, formula=formula, notes=notes)

def force_tail(src='force'):
    return [
        calc('force_abs', f'abs({src})', 'Force without direction, 0 to 1.'),
        calc('force_smooth', f'ema({src}, 0.15)', 'Sustained force (cornering-like load), -1 to 1. ' + DIR),
        calc('force_kick', f'clamp(abs({src} - ema({src}, 0.15)) * 2, 0, 1)',
             'Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1.'),
    ]

def accel(speed='speed'):
    return calc('accel_g', f'ema(slope({speed} * max_speed, 0.1), 0.05) / 3.6 / g',
                f'Longitudinal G from {speed}, assuming km/h ({speed} x Max speed undoes the division, so this stays in G). '
                '+ speeding up, - slowing down.')

SKIP_OUT = re.compile(r'^(Speedo|Boost)\d+ Brightness$')

def lamp_rows(game, taken):
    rows = []
    for o in ob_outputs(game):
        if SKIP_OUT.match(o):
            continue
        safe = re.sub(r'[^A-Za-z0-9_]', '_', o)
        if o.upper().startswith('FFB'):
            name = 'ob_' + safe.lower()
            note = f"Output from OutputBlaster: {o}, the force feedback value it sends to the cabinet's wheel."
        else:
            name = safe.lower()
            note = f'Output from OutputBlaster: {o} (0 or 1, or 0-255).'
            if o == 'RPM': note = "Output from OutputBlaster: engine RPM as the cabinet's rev display gets it."
        if name in taken:
            name += '_out'
        taken.add(name)
        rows.append(calc(name, f'out_{safe}', note))
    return rows

def profile(prefix, display, rows, ob_game=None, max_speed=None, max_revs=None):
    taken = {r['Name'] for r in rows}
    if ob_game:
        rows = rows + lamp_rows(ob_game, taken)
    p = dict(Id=prefix.lower().ljust(32, '0')[:32], DisplayName=display, Prefix=prefix, ProcessName='',
             Enabled=True, Variables=rows)
    # Max speed / Max revs boxes (plugin 0.12.0), only where a recording or Alexis has given them.
    if max_speed: p['MaxSpeed'] = float(max_speed)
    if max_revs: p['MaxRevs'] = float(max_revs)
    return p

def hold0(expr, cond):
    return f'valid(hold({expr}, {cond}), 0)'

# ---------------------------------------------------------------- game definitions
P = []

# H2Overdrive
P.append(profile('H2OVERDRIVE', 'H2Overdrive', [
    mem('ffb_stiffness', 'Float', '392C54', 'Centring stiffness the game asks for.' + UNVERIFIED),
    mem('ffb_raw', 'Float', '392C58', 'Force the game asks for: + pushes one way, - the other.' + UNVERIFIED),
    calc('spring', 'clamp(ffb_stiffness / 1.25, 0, 1)', 'Centring spring, 0 to 1 (the FFB plugin scales stiffness by 1/1.25).'),
    calc('force', 'clamp(-ffb_raw, -1, 1)', 'Decoded force, -1 to 1. ' + DIR),
] + force_tail(), 'H2Overdrive'))

# Sega Racing Classic: one command byte
c = 'ffb_cmd'
P.append(profile('SEGARACINGCLASSIC', 'Sega Racing Classic', [
    mem(c, 'Byte', '834C19', 'Force feedback command byte (absolute address).' + UNVERIFIED, module=''),
    calc('force', hold0(f'{c} >= 168 && {c} <= 175 ? (176 - {c}) / 8 : ({c} >= 152 && {c} <= 159 ? -(160 - {c}) / 8 : 0)',
                        f'({c} >= 168 && {c} <= 175) || ({c} >= 152 && {c} <= 159)'),
         'Constant force, -1 to 1, kept until the next force command. ' + DIR),
    calc('spring', hold0(f'pow((200 - {c}) / 8, 0.1)', f'{c} >= 192 && {c} <= 199'), 'Centring spring, 0 to 1, kept until changed.'),
    calc('friction', hold0(f'(224 - {c}) / 8', f'{c} >= 216 && {c} <= 223'), 'Friction, 0 to 1, kept until changed.'),
    calc('vibration', f'{c} >= 184 && {c} <= 191 ? (192 - {c}) / 8 : 0', 'Vibration while the game asks for it, 0 to 1.'),
] + force_tail(), 'SegaRacingClassic'))

# OutRun 2 SP SDX (Lindbergh): telemetry the FFB plugin's "fake" mode reads
P.append(profile('OUTRUN2SP', 'OutRun 2 SP SDX', [
    mem('speed', 'Float', '08273DF0', 'Speedometer, km/h (absolute address).' + UNVERIFIED, module=''),
    mem('gear', 'Byte', '0827A160', 'Gear (absolute address).' + UNVERIFIED, module=''),
    mem('transmission', 'Byte', '082932C2', 'Transmission setting; the FFB plugin only shifts for you when this is 1.' + UNVERIFIED, module=''),
    mem('steer_raw', 'Byte', '08670DC8', 'Steering, 0 to 255 with 127 in the middle.' + UNVERIFIED, module=''),
    calc('steer', 'steer_raw < 127 ? -(127 - steer_raw) / 127 : (steer_raw - 127) / 128', 'Steering, -1 to 1, + right (it follows the G25 read over USB, 3 November 2026).'),
    mem('in_race', 'Byte', '08304ADC', '1 during a race.' + UNVERIFIED, module=''),
    mem('in_menu', 'Byte', '086749CA', '1 in the menus.' + UNVERIFIED, module=''),
    mem('surface', 'Int32', '0827A1A0', 'Surface rumble code: 4, 8 or 16 for the three kinds of rough ground the FFB plugin knows.' + UNVERIFIED, module=''),
    mem('side_hit_count', 'Int32', '0827A1DA', 'Changes at each side hit.' + UNVERIFIED, module=''),
    mem('side_hit_dir', 'Int32', '0827A1D4', 'Side of the last hit: 2 right, 1 left.' + UNVERIFIED, module=''),
    mem('crash_count', 'Int32', '0827A35D', 'Changes at each crash.' + UNVERIFIED, module=''),
    calc('impact_side', 'maxw(delta(side_hit_count) != 0 ? (side_hit_dir == 2 ? 1 : (side_hit_dir == 1 ? -1 : 0)) : 0, 0.3) + minw(delta(side_hit_count) != 0 ? (side_hit_dir == 2 ? 1 : (side_hit_dir == 1 ? -1 : 0)) : 0, 0.3)',
         'Side hit, +1 right or -1 left, held for 0.3 s so SimHub sees it.'),
    calc('crash', 'maxw(delta(crash_count) != 0, 0.3)', '1 for 0.3 s after a crash.'),
    calc('rough_ground', 'surface == 4 || surface == 8 || surface == 16', '1 on rough ground.'),
    accel(),
], 'Outrun2SP'))

def daytona(prefix, display, ffb, state, trackbase, ob, alt=None):
    c = 'ffb_cmd'
    rows = [
        mem(c, 'Byte', ffb, 'Force feedback command byte.' + UNVERIFIED),
        mem('game_state', 'Byte', state, 'Game state: 22 during a race, as the FFB plugin uses it.' + UNVERIFIED),
        mem('track', 'Byte', trackbase, 'Selected track.' + UNVERIFIED, offsets='4'),
        calc('mirrored', '(track == 2 || track == 4) && game_state == 22 ? -1 : 1',
             '-1 on the two tracks where the FFB plugin swaps the force direction, otherwise 1.'),
        calc('force', hold0(f'({c} >= 145 && {c} <= 160 ? -(160 - {c}) / 15 : ({c} >= 161 && {c} <= 176 ? (176 - {c}) / 15 : 0)) * mirrored',
                            f'{c} >= 145 && {c} <= 175'),
             'Constant force, -1 to 1, kept until the next force command. ' + DIR),
        calc('spring', hold0(f'{c} >= 129 && {c} <= 143 ? (144 - {c}) / 15 : ({c} >= 193 && {c} <= 207 ? (207 - {c}) / 15 : ({c} >= 225 && {c} <= 239 ? ({c} - 224) / 15 : ({c} - 240) / 15))',
                             f'({c} >= 129 && {c} <= 143) || ({c} >= 193 && {c} <= 207) || ({c} >= 225 && {c} <= 239) || {c} >= 241'),
             'Centring spring, 0 to 1, kept until changed.'),
        calc('vibration', f'{c} >= 177 && {c} <= 191 ? (192 - {c}) / 15 : 0', 'Vibration while the game asks for it, 0 to 1.'),
    ] + force_tail()
    if alt:
        rows += [
            mem('ffb_alt', 'Byte', alt, "Second force value the FFB plugin can use instead (absolute address): 1 to 15 one way, 16 to 31 the other." + UNVERIFIED, module=''),
            calc('force_alt', 'ffb_alt > 15 ? -(31 - ffb_alt) / 15 : (ffb_alt > 0 ? (16 - ffb_alt) / 15 : 0)', 'ffb_alt decoded, -1 to 1. ' + DIR),
        ]
    return profile(prefix, display, rows, ob)

P.append(daytona('DAYTONA3', 'Daytona Championship USA', '131FEC9', '15B5744', '11B0148', 'DaytonaChampionshipUSA', alt='15AFC46'))
P.append(daytona('DAYTONA3NSE', 'Daytona Championship USA New Season Edition', '1334061', '15C98C4', '11C22A0', 'DaytonaChampionshipUSANSE'))

def initiald(prefix, display, addr, relative, ob=None, extra=None):
    mod = MAIN if relative else ''
    where = '' if relative else ' (absolute address)'
    a = int(addr, 16)
    rows = (extra or []) + [
        mem('ffb_raw', 'UInt32', f'{a:X}', 'Force feedback command: byte 0 = command, byte 1 = direction or period, bytes 2-3 = strength' + where + '.' + UNVERIFIED, module=mod),
        mem('ffb_str', 'UInt16', f'{a + 2:X}', 'Strength, 0 to 32767' + where + '.' + UNVERIFIED, module=mod),
    ]
    rows += initiald_decode()
    return profile(prefix, display, rows, ob)

def initiald_decode(raw='ffb_raw', s='ffb_str'):
    return [
        calc('ffb_cmd', f'byte({raw}, 0)', 'Command: 132 constant force, 134 spring, 133 vibration, 128 (with byte 2 = 1) full spring.'),
        calc('ffb_v1', f'byte({raw}, 1)', 'Direction for command 132 (0 or 1), period for 133.'),
        calc('force', hold0(f'clamp(ffb_cmd == 132 && {s} > 0 ? (ffb_v1 == 0 ? -(32767 - {s}) / 32767 : (ffb_v1 == 1 ? {s} / 32767 : 0)) : 0, -1, 1)', 'ffb_cmd == 132'),
             'Constant force, -1 to 1, kept until the next force command. ' + DIR),
        calc('spring', hold0(f'ffb_cmd == 134 ? {s} / 32767 : 1', f'(ffb_cmd == 134 && {s} > 0) || (ffb_cmd == 128 && byte({raw}, 2) == 1)'),
             'Centring spring strength, 0 to 1, kept until changed.'),
        calc('vibration', f'ffb_cmd == 133 && ffb_v1 > 0 && {s} > 0 ? {s} / 32767 : 0', 'Vibration strength while the game asks for it, 0 to 1.'),
        calc('vibration_period_ms', 'ffb_cmd == 133 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0', 'Vibration period, roughly milliseconds.'),
    ] + force_tail()

P.append(initiald('ID4', 'Initial D Arcade Stage 4 (export)', '089AE898', False, 'InitialD4'))
P.append(initiald('ID4JP', 'Initial D Arcade Stage 4 (Japan)', '08989858', False, 'InitialD4'))
P.append(initiald('ID5', 'Initial D Arcade Stage 5', '08CB6120', False, 'InitialD5'))
P.append(initiald('ID0V131', 'Initial D Arcade Stage Zero v1.31', '168317C', True, 'ID0V131'))
P.append(initiald('ID0V211', 'Initial D Arcade Stage Zero v2.11', '18A720C', True, 'ID0V211'))
P.append(initiald('ID0V230', 'Initial D Arcade Stage Zero v2.30', '18B54DC', True))
P.append(initiald('IDTA', 'Initial D The Arcade v2.31', '3D35838', True))
P.append(initiald('KODRIVE', 'KO Drive', '7261F4', True))

# SWDC 2018: two versions, told apart by "SDDS" at a version-specific address
SDDS = int.from_bytes(b'SDDS', 'little')
P.append(profile('SWDC', 'Sega World Drivers Championship', [
    mem('ver103_tag', 'Int32', '8E5CBD0', f'Reads {SDDS} ("SDDS") on version 1.03.' + UNVERIFIED),
    mem('ver230_tag', 'Int32', '9BC7B20', f'Reads {SDDS} ("SDDS") on version 2.30.' + UNVERIFIED),
    calc('version', f'ver103_tag == {SDDS} ? 103 : (ver230_tag == {SDDS} ? 230 : 0)', 'Game version found: 103, 230, or 0 if neither.'),
    mem('ffb_raw103', 'UInt32', '8E5CCF4', 'Force feedback command, version 1.03.' + UNVERIFIED),
    mem('ffb_str103', 'UInt16', '8E5CCF6', 'Strength, version 1.03.' + UNVERIFIED),
    mem('ffb_raw230', 'UInt32', '9BC7B18', 'Force feedback command, version 2.30.' + UNVERIFIED),
    mem('ffb_str230', 'UInt16', '9BC7B1A', 'Strength, version 2.30.' + UNVERIFIED),
    calc('ffb_raw', 'version == 230 ? ffb_raw230 : ffb_raw103', 'Command for the version found: byte 0 = command, byte 1 = direction or period, bytes 2-3 = strength.'),
    calc('ffb_str', 'version == 230 ? ffb_str230 : ffb_str103', 'Strength for the version found, 0 to 32767.'),
] + initiald_decode()))

# Mario Kart Arcade GP DX: force (the FFB plugin's "Real" mode) plus kart telemetry (its "Custom" mode)
TERRAIN = 'Ground under the kart: 3 dirt, 4 grass, 7 water, 8 bridge, 9 carpet, 10 speed bump, 11 rough track, 12 tiles, 14 sand.'
def mariokart(prefix, display, real, k, ob):
    rows = [
        mem('ffb_raw', 'Float', real[0], 'Force the game asks for.' + UNVERIFIED, offsets=real[1]),
        calc('force', 'clamp(-ffb_raw, -1, 1)', 'Decoded force, -1 to 1. ' + DIR),
    ] + force_tail() + [
        mem('speed', 'Float', k['kart'], 'Kart speed (units unknown).' + UNVERIFIED, offsets=k['speed']),
        mem('steer_raw', 'Byte', k['wheel'][0], 'Steering, 0 to 255.' + UNVERIFIED, offsets=k['wheel'][1]),
        calc('steer', '(steer_raw - 127.5) / 127.5', 'Steering, -1 to 1 (which side is + still to be confirmed).'),
        mem('in_race', 'Byte', k['race'][0], '1 during a race.' + UNVERIFIED, offsets=k['race'][1]),
        mem('terrain', k.get('ttype', 'Byte'), k['kart'], TERRAIN + UNVERIFIED, offsets=k['terrain']),
        mem('on_ground', k.get('ttype', 'Byte'), k['kart'], '1 with the kart on the ground.' + UNVERIFIED, offsets=k['ground']),
        mem('drift', 'Byte', k['kart'], '1 while drifting.' + UNVERIFIED, offsets=k['drift']),
        mem('boost', 'Byte', k['boost'], '1 while boosting.' + UNVERIFIED, offsets='3A4'),
        mem('shake_raw', 'Int32', k['shake'], '4194308 while the game shakes the cabinet: hitting walls or karts, or hit by an item.' + UNVERIFIED),
        mem('coins', 'Byte', k['coins'], 'Changes when a coin is picked up.' + UNVERIFIED),
        mem('item', 'Byte', k['item'], 'Changes when an item box is picked up or an item used.' + UNVERIFIED),
        calc('hit', 'shake_raw == 4194308', '1 while the big shake plays (walls, karts, items).'),
        calc('landed', 'maxw(delta(on_ground) > 0 && on_ground == 1, 0.2)', '1 for 0.2 s after landing a jump.'),
        calc('coin_pickup', 'maxw(delta(coins) != 0, 0.2)', '1 for 0.2 s after picking up a coin.'),
        calc('item_change', 'maxw(delta(item) != 0, 0.3)', '1 for 0.3 s after an item box or item use.'),
        calc('rough_ground', 'on_ground == 1 && (terrain == 3 || terrain == 4 || terrain == 10 || terrain == 11 || terrain == 12 || terrain == 14)', '1 on dirt, grass, bumps, rough track, tiles or sand.'),
        calc('in_water', 'on_ground == 1 && terrain == 7', '1 driving through water.'),
    ]
    return profile(prefix, display, rows, ob)

P.append(mariokart('MKGPDX110', 'Mario Kart Arcade GP DX v1.10', ('A2FE20', '8, A44'), dict(
    kart='A416E4', speed='558', terrain='628', ground='658', drift='674', boost='A2E284', shake='A46974',
    wheel=('A4652D', ''), coins='A39690', item='A4528D', race=('A309A0', '304, E8, 64, 38, 4C4')), 'MarioKartGPDXJP1.10'))
P.append(mariokart('MKGPDX118', 'Mario Kart Arcade GP DX v1.18', ('AAEEA0', '8, BC8'), dict(
    kart='AC2A30', speed='580', terrain='66C', ground='69C', drift='6B8', boost='AAD0BC', shake='AC72F4',
    wheel=('AC6EAD', ''), coins='AB9110', item='AC5C0D', race=('AAFAB8', '44, 70, 108, 98, 4C4')), 'MarioKart1.18'))

# v1.18 from the game's code (MK_AGP3_FINAL.exe, CRC 0x6C9038BE, read 9 November 2026; claude/MKGPDX118-exe-20261109.md):
# * <main>+AAEEA0 is the race's car list; its +8 is the player's kart (clPlayerCar), from the list's "player car" call
#   (0x74896E). The FFB plugin's force (+BC8) already reads through it.
# * The kart's engine-sound feed (0x65F550) copies +AC4 (speed, capped at 400 for the sound) and +AC8 (engine revs,
#   capped at 11000) into the sound manager, and sets the sound manager's drift flags from the kart's +3BC (a signed
#   slide value: +6B8 = it isn't 0, +6BA = it's below 0).
# * <main>+AC2A30 is that sound manager (clCarSoundManager, 0x6BC bytes): +66C ground type of the first wheel pair, +69C wheel 1 on
#   the ground (forced to 0 in a few kart states), +6B8 drift. Its +580 is not a field the sound feed fills (the per-kart
#   slots are 0xF8 bytes, the player's slot number at +6B0), so the FFB plugin's speed is kept only to compare.
# * <main>+AC5C0D (item) is a byte of the JVS packet buffer for the I/O board; the game itself writes 76 there. No code
#   reads or writes <main>+AB9110 (coins) directly.
MK118 = " From the game's code (MK_AGP3_FINAL.exe v1.18, read 9 November 2026); not yet checked in a recording."
MK118_REC = " From the game's code (v1.18), checked in Alexis's recording of 11 November 2026."
# Alexis's names for the codes on course 1 of the Donkey Kong cup (11 November 2026), and the attract demo's planks
TERRAIN_MK = ("Ground under the first pair of wheels (the sound manager picks it from wheels 1 and 2). The codes are the game's "
              "surface kinds, shared by surfaces that look different. Alexis's names (11 November 2026), course 1 of the Donkey Kong "
              "cup: 3 the yellow dirt road, 4 the grassy verge, 7 water (also shallow water over pavement or jungle floor), 8 wood (the "
              "old mine-cart railway platform, the logs of the ripple strips, and planking in the attract demo), 10 the planked "
              "bridge, 12 tessellated pavement, 13 jungle floor; 0 in the air. Course 1 of the Mario cup: 0 the blue, stripy "
              "rebound-ace road, 11 its verge, 13 striped blue and gold glass, 10 the boost rings (three in a row after each glass "
              "section) with 14 sand between and after them, 12 pavement. Courses 2 and 3 of the Bowser Jr cup: 8 smooth floorboards, "
              "15 cloud (silky smooth), 5 checkerplate metal, 9 carpet, 2 separate sections of metal grille (a rumble strip), 0 "
              "the boost ramps before each glide. The FFB Arcade Plugin's list: 3 dirt, 4 grass, 7 water, 8 bridge, 9 carpet, 10 speed bump, 11 rough track, 12 tiles, 14 sand.")
MK118_KART = ('AAEEA0', '8, ')
def _mk118(p):
    rows = {v['Name']: v for v in p['Variables']}
    kart = lambda name, typ, off, notes, formula='': mem(name, typ, MK118_KART[0], notes + ('' if notes.endswith(MK118_REC) else MK118),
                                                          offsets=MK118_KART[1] + off, formula=formula)
    old = rows['speed']
    old.update(Name='speed_snd', Enabled=False,
               Notes="The FFB Arcade Plugin's speed read (sound manager +580): the sound's own copy of the speed, which follows "
                     "speed a little behind (within 5 in Alexis's recording of 11 November 2026). speed is the kart's own." + UNVERIFIED)
    new = [
        kart('speed', 'Float', 'AC4', "Kart speed in the game's own units (the value its engine sound follows): about 140 to 150 "
             "racing at 100cc, up to 195 without a boost and 217 with one." + MK118_REC),
        kart('rpm', 'Float', 'AC8', "Engine revs the kart's engine sound plays: 8000 to 9300 racing, 12360 at the most." + MK118_REC),
        dict(kart('slip', 'Float', '3BC', "The kart's drift value: 0 while gripping; +1 as a right-hand drift starts (-1 left), "
                  "then easing towards 0 by 0.1 a second for as long as the drift lasts (not the drift meter, and not an angle)."
                  + MK118_REC), Enabled=False),
        dict(kart('kart_state', 'Int32', '48C', "The kart's state: 0 driving, 1 the hop into a drift (0.27 s), 2 drifting, 3 knocked "
                  "up by an item while drifting, 5 hit and flipped, 10 spun out by an item, 17 launching off the kite ramp, 18 gliding, "
                  "22 on the grid before the start." + MK118_REC), Enabled=False),
        dict(kart('kart_flags', 'Int32', '810', "The kart's flag bits: 4 gliding, 4194304 for a moment at the kite launch, 8388608 for "
                  "about 3 s after being hit by an item (recovering)." + MK118_REC), Enabled=False),
        dict(kart('drift_angle', 'Float', 'BC8', "Drift angle, degrees: between where the kart points and where it is going, + pointing "
                  "right of its path (a right-hand drift), - left. The game keeps the sine of it (kart +BC8, the value the FFB Arcade "
                  "Plugin sends the wheel as force; the USA version's code works it out from the kart's sideways axis and its direction "
                  "of travel). Alexis's drifts read 30 to 45 degrees right, 15 to 35 left; under 2 driving straight; a spin-out swings "
                  "it round and round. Past 90 degrees it folds back." + MK118_REC,
                  formula='atan2(clamp(-value, -1, 1), sqrt(1 - pow(clamp(value, -1, 1), 2))) * 180 / pi'), Enabled=True),
        mem('drift_side', 'Byte', 'AC2A30', "1 in a left-hand drift (the drift value below 0), 0 otherwise." + MK118_REC, offsets='6BA'),
        # 10 November 2026, after Battle Gear 4: the race manager <main>+AAEE80 (made at 0x74AAD5 for a race and 0x61B546 by
        # the attract demo's loader) keeps its current state object at +38, whose +C is the state number (0x749870).
        mem('race_state', 'Int32', 'AAEE80', "The race manager's state: 1 initialise, 2 VS wait, 3 pre-start demo, 4 live wait, "
            "5 start count, 6 race, 7 goal, 8 time up, 9 end, 10 test run. Alexis's recording: 1 loading after the course is "
            "chosen, 3 the fly-over, 4 behind the kart, 5 the countdown, 6 from GO, 7 from the finish line (the game drives the kart), "
            "9 as the menus come up; unreadable before and after. The attract demo wasn't recorded running a race." + MK118_REC,
            offsets='38, C'),
        # 11 November 2026 (v1.18 exe, HUD code 0x6A7900 and 0x6B7770): the kart's +CC object holds the race position (+1D4,
        # 1 = first) and the laps completed (+1E4); the lap shown is laps completed + 1, up to the race's lap count,
        # [<main>+AAEE7C] +4 +10. The race (car list +4) keeps the race time in milliseconds at +2C (0x6A3040).
        kart('position', 'Int32', 'CC, 1D4', "Race position, 1 = first: what the HUD's position number shows (it animates when this "
             "changes). Updated once a second, as the HUD is: Alexis saw the HUD lag her real place (checked in two races)."),
        kart('laps_done', 'Int32', 'CC, 1E4', "Laps completed: 0 on the first lap; the HUD shows this + 1 as the lap."),
        mem('laps_total', 'Int32', 'AAEE7C', "Laps in this race (the HUD's lap count)." + MK118, offsets='4, 10'),
        mem('race_time', 'Int32', 'AAEEA0', "Race time, seconds: the race's clock, 16 ms a frame (so about 4% "
            "slower than real time), which the results show as minutes, seconds and milliseconds. Checked in two v1.18 and two USA races." + MK118, offsets='4, 2C', formula='value / 1000'),
        dict(mem('race_timer_1c', 'Int32', 'AAEEA0', "A countdown in milliseconds from 250 s, falling as the race "
             "clock rises (250 s less the race time in Alexis's recordings of 11 November): a time limit, not shown while racing." + MK118, offsets='4, 1C'), Enabled=False),
        dict(kart('kart_x', 'Float', '354', 'Kart position x (the engine sound\'s copy).'), Enabled=False),
        dict(kart('kart_y', 'Float', '358', 'Kart position y (height).'), Enabled=False),
        dict(kart('kart_z', 'Float', '35C', 'Kart position z.'), Enabled=False),
    ]
    rows['drift']['Notes'] = ("1 while drifting, from the hop to the boost (kart states 1 and 2): the game's engine-sound drift flag."
                              + MK118_REC)
    rows['terrain']['Notes'] = TERRAIN_MK + MK118_REC
    rows['on_ground']['Notes'] = ("1 with the first wheel on the ground; 0 in the air, in the hop into a drift and in a spin-out, and "
                                  "for a frame at each log of a ripple strip." + MK118_REC)
    rows['steer_raw']['Notes'] = 'Steering, 0 to 255.' + UNVERIFIED
    rows['steer']['Notes'] = "Steering, -1 to 1, + right (right-hand drifts read about +0.8 in Alexis's recording, 11 November 2026)."
    rows['item']['Notes'] = ("A byte of the game's JVS buffer for its I/O board (<main>+AC5C00 on), not an item counter: the game writes 76 "
                             "there when it sets the board up. The FFB Arcade Plugin saw it change with items; kept to check in a "
                             "recording." + UNVERIFIED)
    rows['coins']['Notes'] = ("Coins collected this race: 0 at the start, up 1 with each coin (20 by the end of Alexis's race, 11 November "
                              "2026; every coin she noted came through)." + UNVERIFIED.replace('Unverified: f', 'F'))
    i = p['Variables'].index(old)
    p['Variables'][i:i] = new
    return p
_mk118(P[-1])
P.append(mariokart('MKGPDXUSA', 'Mario Kart Arcade GP DX (USA)', ('B47B48', '8, 2FC'), dict(
    kart='B4F324', speed='558', terrain='628', ground='658', drift='674', boost='B441C8', shake='B96B74',
    wheel=('B4F2E0', '125'), coins='B4E330', item='B9548D', race=('B486BC', '2E0, AC, C, C, 330')), None))

# USA build from the game's code (Alexis's MK_AGP3_FINAL.exe, 7,033,856 bytes, built 8 November 2016, "USA1FF01"; read
# 11 November 2026; claude/MKGPDXUSA-exe-20261111.md). The same structures as v1.18 at other addresses and offsets:
# * <main>+B47B48 is the race's car list (0x48 bytes, made at 0x6F20DF); its +8 is the player's kart (clPlayerCar), from the
#   list's "player car" call (0x6F2105), as v1.18's <main>+AAEEA0. The FFB plugin's force (+2FC) already reads through it.
# * The engine-sound feed (0x647EE0) copies kart +958 (speed, capped at 400) and +95C (engine revs, capped at 11000) into
#   the sound manager, and sets its drift flags from kart +29C (the slide value: +674 = it isn't 0, +676 = it's below 0).
#   Kart +34C state (1, 6, 7, 11, 18 off the ground), +6B0 flags (bits 8, 64, 2048), +220 sound slot, +A8 physics.
#   Speed = [[kart+A8]+6C]+718 x [[kart+A8]]+728, revs = [[kart+A8]]+724 (0x63BF0C), as v1.18.
# * <main>+B4F324 is the sound manager (clCarSoundManager, 0x678 bytes, made at 0x4ACFF2; slots of 0xF0): +628 ground type of
#   the first wheel pair (0x485B90), +658 wheel 1 on the ground. Its +558 is not a field the feed fills, as v1.18's +580.
# * <main>+B47B28 is the race manager: +38 its current state, whose +C is the state number (the same ten states as v1.18,
#   made by the switch at 0x6F2C10). The attract play demo's loader makes one too (0x608E0A -> 0x609F40).
# * Kart +2FC (the FFB plugin's force) is the dot product of the kart's sideways axis (matrix row +4A8) with its direction
#   of travel ([[kart+A8]]+6C, +1C vector), both flattened (0x63CA52): the sine of the slide angle. Hence drift_angle.
# * The I/O (JVS) block is v1.18's moved up 0xCF880: item (+D) and the FFB plugin's shake word (+16F4) both sit exactly
#   there, so v1.18's steering byte and OutputBlaster's lamp words are read at the same move (moregames.fix_mkusa_lamps).
MKUSA = " From the game's code (MK_AGP3_FINAL.exe, USA, read 11 November 2026); not yet checked in a recording."
MKUSA_KART = ('B47B48', '8, ')
JVS_USA = 0xCF880   # the USA build's I/O block sits this far above v1.18's
def _mkusa(p):
    rows = {v['Name']: v for v in p['Variables']}
    kart = lambda name, typ, off, notes, formula='', on=False: dict(
        mem(name, typ, MKUSA_KART[0], notes + MKUSA, offsets=MKUSA_KART[1] + off, formula=formula), Enabled=on)
    old = rows['speed']
    old.update(Name='speed_snd', Enabled=False,
               Notes="The FFB Arcade Plugin's speed read (sound manager +558). Not a field the game's sound code fills (as +580 in "
                     "v1.18), so probably not the speed; kept to compare with speed in a recording." + UNVERIFIED)
    asin = 'atan2(clamp(-value, -1, 1), sqrt(1 - pow(clamp(value, -1, 1), 2))) * 180 / pi'
    new = [
        kart('speed', 'Float', '958', "Kart speed in the game's own units (the value its engine sound follows; the sound caps it at 400).", on=True),
        kart('rpm', 'Float', '95C', "Engine revs the kart's engine sound plays (the sound caps them at 11000).", on=True),
        kart('slip', 'Float', '29C', "The kart's slide value: 0 while the tyres grip, + or - while sliding (the drift row is this "
             "not being 0, and its sign gives the side). Units not known yet: recorded so a capture can scale it."),
        kart('kart_state', 'Int32', '34C', "The kart's state number (the engine sound treats states 1, 6, 7, 11 and 18 as off the "
             "ground). Recorded so a capture can name the states (hits, spins, jumps)."),
        kart('kart_flags', 'Int32', '6B0', "The kart's flag bits (the engine sound checks bits 8, 64 and 2048). Recorded so a "
             "capture can name them."),
        kart('drift_angle', 'Float', '2FC', "Drift angle, degrees: between where the kart points and where it is going, from the "
             "sine the game works out (kart +2FC, the value the FFB Arcade Plugin sends as the force): about 0 driving straight, "
             "growing in a slide; + pointing right of its path (a right-hand drift), - left, as v1.18's same value read in Alexis's "
             "recording (11 November 2026). Past 90 degrees (a spin) it folds back.", formula=asin, on=True),
        mem('drift_side', 'Byte', 'B4F324', "1 in a left-hand drift (the slide value below 0; left in v1.18's recording, 11 November "
            "2026)." + MKUSA, offsets='676'),
        mem('race_state', 'Int32', 'B47B28', "The race manager's state: 1 initialise, 2 VS wait, 3 pre-start demo, 4 live wait, "
            "5 start count, 6 race, 7 goal, 8 time up, 9 end, 10 test run. The attract demo runs a race too, so check it against "
            "in_race in a recording before relying on it." + MKUSA, offsets='38, C'),
        # For checking the drift angle (and its side): position and travel from the kart's physics, the heading from its matrix.
        kart('kart_x', 'Float', 'A8, 0, 6C, 4', "Kart position x (what the engine sound reads)."),
        kart('kart_y', 'Float', 'A8, 0, 6C, 8', 'Kart position y.'),
        kart('kart_z', 'Float', 'A8, 0, 6C, C', 'Kart position z.'),
        kart('travel_x', 'Float', 'A8, 0, 6C, 1C', "The kart's travel vector x (velocity, by its use: the game takes its direction "
             "for the slide angle)."),
        kart('travel_z', 'Float', 'A8, 0, 6C, 24', 'The travel vector z.'),
        kart('side_x', 'Float', '4A8', "The kart's sideways axis x (first row of its matrix): the slide angle's + side."),
        kart('side_z', 'Float', '4B0', 'The sideways axis z.'),
        kart('heading_x', 'Float', '4C8', "The kart's forward axis x (third row of its matrix)."),
        kart('heading_z', 'Float', '4D0', 'The forward axis z.'),
        # The same HUD code at 0x680AD0 and 0x680B50: the kart's +A8 object +1D0 position, +1DC laps completed; the race's lap
        # count [<main>+B47B24] +4 +C; the race time at the race's +2C (0x6F7000 formats it).
        kart('position', 'Int32', 'A8, 1D0', "Race position, 1 = first: what the HUD's position number shows. Updated once a "
             "second, as the HUD is (checked in two races).", on=True),
        kart('laps_done', 'Int32', 'A8, 1DC', "Laps completed: 0 on the first lap; the HUD shows this + 1 as the lap.", on=True),
        mem('laps_total', 'Int32', 'B47B24', "Laps in this race (the HUD's lap count)." + MKUSA, offsets='4, C'),
        mem('race_time', 'Int32', 'B47B48', "Race time, seconds: the race's clock, 16 ms a frame (about 4% slower than real time)." + MKUSA,
            offsets='4, 2C', formula='value / 1000'),
        dict(mem('race_timer_1c', 'Int32', 'B47B48', "A countdown in milliseconds from 250 s, falling as the race "
             "clock rises (250 s less the race time in Alexis's recordings of 11 November): a time limit, not shown while racing." + MKUSA, offsets='4, 1C'), Enabled=False),
        dict(mem('steer_jvs', 'Byte', f'{0xAC6EAD + JVS_USA:X}', "Steering, 0 to 255: v1.18's steering byte (the FFB Arcade Plugin's "
             "read there) moved with the I/O block. Recorded to compare with steer, which reads a pointer instead." + MKUSA), Enabled=False),
    ]
    rows['ffb_raw']['Notes'] = ("Force the game asks for: in this version the kart's sideways slide (the sine of drift_angle), which "
                                "the FFB Arcade Plugin's Real mode sends to the wheel, so near 0 driving straight." + UNVERIFIED)
    rows['drift']['Notes'] = "1 while drifting (sliding): the game's engine-sound drift flag, set while slip isn't 0." + MKUSA
    rows['terrain']['Notes'] = TERRAIN_MK + " Codes from v1.18's recording." + MKUSA
    rows['on_ground']['Notes'] = "1 with the first wheel on the ground; 0 in the air, and also in a few kart states (see kart_state)." + MKUSA
    rows['item']['Notes'] = ("A byte of the game's JVS buffer for its I/O board (<main>+B95480 on), not an item counter: the game writes 76 "
                             "there when it sets the board up (as v1.18). The FFB Arcade Plugin saw it change with items; kept to check "
                             "in a recording." + UNVERIFIED)
    rows['coins']['Notes'] = ("Coins collected this race, by the FFB Arcade Plugin's reading (v1.18's coin row counted every coin in "
                              "Alexis's recording, 11 November 2026). No code reads or writes this address directly; kept to check." + UNVERIFIED)
    rows['shake_raw']['Notes'] += " The same place in the I/O block as v1.18's shake word."
    i = p['Variables'].index(old)
    p['Variables'][i:i] = new
    return p
_mkusa(P[-1])

# Alexis's v1.18 recording (11 November 2026, claude/MKGPDX118-capture-20261111.md): a 100cc Grand Prix race, two laps,
# 48 marks. Rows built on what it showed, for v1.18 and (by the same code) the USA version:
# * `item` (the JVS byte) read exactly the button lamp byte all recording: bit 4 the item button's lamp, lit from an item box
#   until the item is used or lost; bit 8 lit while driving (off for drift hops, spin-outs and gliding).
# * race_state 6 is the race; the FFB plugin's in_race dropped for one sample at the lap line.
# * on_ground drops for drift hops (0.27 s) and for a frame at each log of a ripple strip, where terrain flicks 3/8/3/8.
# * The shake word (hit) fires for walls, karts and items, the kite launch and landing, and twice in the countdown.
def _mk_derived(p, src):
    v = {r['Name']: r for r in p['Variables']}
    p['Variables'] = [r for r in p['Variables'] if r['Name'] not in ('item', 'item_change')]
    rows = [
        calc('racing', 'valid(race_state, 0) == 6 && maxw(in_race, 0.1) > 0', "1 from GO to the finish line: race state 6 (race), "
             "with the FFB plugin's race flag (it drops for one sample at the lap line, so it is held 0.1 s)." + src),
        calc('hop', 'racing && kart_state == 1', '1 for the hop into a drift (0.27 s).' + src),
        calc('gliding', 'racing && (kart_state == 18 || band(kart_flags, 4) > 0)', '1 while gliding on the kite (4.4 s at each kite ramp '
             'in Alexis\'s race).' + src),
        calc('spin', 'racing && (kart_state == 6 || kart_state == 7 || kart_state == 10 || kart_state == 11)', '1 while spun out by an item: about 1.5 s on the ground (state 10, a banana peel among them), 2.5 to 3 s thrown into the air spinning over and over (6 and 11 items, 7 a bomb blast).' + src),
        calc('knocked', 'racing && (kart_state == 3 || kart_state == 5 || kart_state == 6 || kart_state == 7 || kart_state == 10 || kart_state == 11)', '1 while knocked about by an item: '
             'bumped (state 3, about 0.5 s: an item from behind kicks the rear wheels up), flipped (5) or spun out (6, 7, 10, 11).' + src),
        calc('recovering', 'racing && band(kart_flags, 8388608) > 0', '1 for about 3 s after being hit by an item.' + src),
        calc('airborne', 'racing && on_ground == 0 && kart_state != 1 && minw(on_ground == 0, 0.1) > 0', "1 in the air for more than "
             "0.1 s: the kite glides and jumps, not the drift hops or the logs of a ripple strip (where on_ground drops for a frame)." + src),
        calc('landed', 'maxw(prev(airborne) > 0 && airborne == 0, 0.25) > 0', '1 for 0.25 s after landing from the air.' + src),
        calc('hop_landed', 'maxw(prev(hop) > 0 && hop == 0, 0.15) > 0', '1 for 0.15 s as the kart lands from a drift hop.' + src),
        calc('rumble_strip', 'racing && (terrain == 2 || avg(delta(terrain) != 0, 0.3) > 0.07)', "1 on a ripple strip or metal grille: the logs of the "
             "Donkey Kong cup's ripple strips flick the ground type between two codes at every log (on 0.2 s into the strip; both strips "
             "in Alexis\'s race, nothing else), and the grille sections of the Bowser Jr cup read code 2." + src),
        calc('off_road', 'racing && on_ground == 1 && !rumble_strip ? (terrain == 4 || terrain == 11 || terrain == 14 ? 1 : '
             '(terrain == 10 ? 0.5 : (terrain == 8 ? 0.3 : 0))) : 0', 'Rough ground, 0 to 1: a verge (4 grass, 11 rebound-ace) or sand '
             '(14) 1, the planked bridge (10) 0.5, wood (8: floorboards, platforms) 0.3 (Alexis); roads, pavement, glass, jungle floor (13, '
             'which the glass on Mario Cup course 1 shares), checkerplate (5), carpet (9), cloud (15) and water 0, and not on a ripple '
             'strip or grille (the rumble strip has those). The game sends the wheel no texture of its own.' + src),
        calc('drift_strength', 'drift ? (1 - pow(1 - clamp((abs(drift_angle) - 5) / 45, 0, 1), 2)) : 0', "Drifting, 0 to 1, from the drift "
             "angle with ID6's weighting (nothing under 5 degrees, full at 50, eased), while the game's drift flag is on. Alexis's "
             'right-hand drifts read 0.8 to 0.95, left-hand 0.4 to 0.9, her "very slight" one 0.5.' + src),
        calc('item_held', 'racing && maxw(lampstart, 0.25) > 0', "1 from an item box until the item is used or lost: the item button's lamp, held over its flashes (USA, 11 November)." + src),
        calc('item_got', 'maxw(item_held && !prev(item_held), 0.3) > 0', '1 for 0.3 s after an item box.' + src),
        calc('item_gone', 'maxw(!item_held && prev(item_held) && racing, 0.3) > 0', '1 for 0.3 s after an item is used (or knocked away).' + src),
    ]
    v['coin_pickup'].update(Formula='maxw(delta(coins) > 0, 0.2)', Notes='1 for 0.2 s after picking up a coin.')
    v['shake_raw']['Notes'] += (" Alexis's v1.18 recording: walls, karts and items, the kite launch and landing, and twice in the "
                                'countdown (hit_race leaves those out).')
    rows.append(calc('hit_race', 'racing && hit', 'The big shake while racing (walls, karts, items).'))
    rows += [
        calc('slide_at_hit', 'valid(hold(avg(force, 0.3), hit_race && !prev(hit_race)), 0)', 'The slide (force) over the 0.3 s before a '
             'hit (the game\'s shake comes a few hundredths after the knock).'),
        calc('drift_at_hit', 'valid(hold(maxw(drift, 0.3), hit_race && !prev(hit_race)), 0)', '1 if the kart was drifting in the 0.3 s '
             'before a hit (the slide is unwinding then, so the knock can\'t be read).'),
        calc('slide_kick', 'hit_race && drift_at_hit == 0 ? force - slide_at_hit : 0', 'How far a hit knocks the kart\'s slide while the '
             'hit lasts (0 for hits in or just after a drift): a hit on the left knocks it negative, on the right positive.'),
        calc('hit_side', 'maxw(hit_race, 0.3) > 0 && drift_at_hit == 0 && drift == 0 && (kart_state == 0 || kart_state == 3) && maxw(spin, 0.5) == 0 ? (maxw(slide_kick, 0.3) > 0.06 && maxw(slide_kick, 0.3) >= -minw(slide_kick, 0.3) '
             '? 1 : (minw(slide_kick, 0.3) < -0.06 ? -1 : 0)) : 0', "Side of a hit, +1 right, -1 left, 0 not known: the way it knocks the "
             "kart sideways, about 0.1 s after the hit, outside drifts. Alexis's sides (11 November 2026): right for all five hits she "
             'named (96.05 and 248.64 s left, 120.2 and 134.77 s right, 231.75 s left), never the wrong way at her ten other marked '
             'hits, and 0 for gentle bumps and hits in or just after a drift.' + src),
        calc('lap', 'racing ? min(laps_done + 1, max(laps_total, 1)) : 0', 'The lap the HUD shows (1 on the first lap).'),
        calc('final_lap', 'racing && laps_total > 0 && laps_done == laps_total - 1', '1 on the last lap.'),
        calc('leader', 'racing && position == 1', '1 while you lead, for a lamp.'),
        calc('place_gained', 'racing && maxw(delta(position) < 0, 0.5) > 0', '1 for 0.5 s after the HUD position goes up (you pass someone).'),
        calc('place_lost', 'racing && maxw(delta(position) > 0, 0.5) > 0', '1 for 0.5 s after the HUD position goes down (you are passed).'),
    ]
    p['MaxSpeed'] = 160.0   # Alexis, 11 November 2026: racing pace at 100cc is 140 to 150, boosts reach 217
    p['MaxRevs'] = 10000.0  # racing revs 8000 to 9300
    at = next(i for i, r in enumerate(p['Variables']) if r['Name'] == 'landed')
    p['Variables'] = [r for r in p['Variables'] if r['Name'] != 'landed']
    p['Variables'][at:at] = rows
    return p
_mk_derived(P[-2], MK118_REC.replace(" From the game's code (v1.18), checked", ' Checked'))
_mk_derived(P[-1], " Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded.")

# GTI Club Supermini Festa (gti3japkey.exe, 32-bit, fixed base 0x400000). Everything but the FFB plugin's three force bytes and
# in_menu comes from reading the game's code (8 November 2026, claude/GTICLUB3-exe-20261108.md), starting from Alexis's CT:
# * <main>+67FCC8 holds the player car + 0x300 (written once at race set-up, 0x55799F; never cleared, so stale between races).
#   The dash function (0x533690) fills +640 tacho, +644 gear, +648 speedo, +64C mph flag; the car's own fields sit at the
#   other offsets (position, laps and lap times from the position code at 0x55DB20, surfaces and rumble from 0x5475D0).
# * <main>+67FAC8 is the race session; +2C8 its I_RaceStat (cleared after a race), whose +34 is the race state.
# * <main>+680460 points at the race display: the race code copies its time left (ms) to +2C4 each frame (0x558A34,
#   0x55CC36) and the mph setting to +244. (<main>+67FB98, which the first pack read, is the variety modes' timer.)
# Alexis's recording (8 November 2026, claude/GTICLUB3-capture-20261108.md) checked speed (always km/h), revs, tacho, gears,
# positions, laps and the finish, and sorted the game's hit vibration by its level: 50 landing, 36 another car, 63 a
# full-stop crash, 10 to 27 a wall or a kerb (a kerb jolt comes with a wheel on the kerb; a wall either has no kerb under the
# car or loses speed). Alexis confirmed 99.42 s (a wall, no speed lost) and 148.20 s (a kerb) on 8 November.
GTI = " From the game's code (gti3japkey.exe, read 8 November 2026); not yet checked in a recording."
GTI_OK = " Checked in Alexis's recording (8 November 2026)."
GTI_CAR = '67FCC8'
def gti(name, typ, off, notes, formula='race_loaded ? value : 0', base=GTI_CAR):
    return mem(name, typ, base, notes + ('' if notes.endswith(GTI_OK) else GTI), offsets=off, formula=formula)
GTI_STATES = ('0 none, 1 start camera, 2 start sync, 3 countdown, 4 start race, 5 go race, 6 wait time up, 7 goal wait, 8 time up, '
              '9 time up sync, 10 to 12 rank display, 13 result display, 14 end race, 15 interrupt game (the game\'s own names)')
gti_code = lambda n, c: f'band(surface{n}, 255) == {c} && band(surface{n}, 256) == 0'
gti_last = '0'
for n in range(1, 8): gti_last = f'(laps_done == {n} ? lap{n} : {gti_last})'
P.append(profile('GTICLUB3', 'GTI Club Supermini Festa', [
    mem('ffb_main', 'Byte', '918CBC', "Force byte of the 4-byte packet the game sends its force board (absolute address): the game "
        "sets it as a signed value, -127 to 127, from the angle in force_angle (strongest from 50 degrees), 0 below 10 km/h. "
        "The force row decodes it as the FFB Arcade Plugin does." + GTI, module=''),
    mem('ffb_vibration', 'Byte', '918CBD', "Second byte of the force packet (absolute address): the low 6 bits are the vibration, "
        "0 to 63 (the game's rumble level x 72); the top two bits are something else the game keeps." + GTI_OK, module=''),
    mem('ffb_other', 'Byte', '918CBE', "Third byte of the force packet (absolute address; the FFB plugin only logs it): the vibration "
        "pattern. 15 for hits and other events, 14 on surface 5, 10 to 16 on surface 2 (higher the faster above 50 km/h); it keeps "
        "its last value." + GTI_OK, module=''),
    dict(mem('ffb_flags', 'Byte', '918CBD', "The top two bits of the vibration byte, 0 to 3 (meaning unknown: recorded so a capture "
             "shows when they change). Always 0 in Alexis's recording." + GTI, module='', formula='shr(value, 6)'), Enabled=False),
    mem('in_menu', 'Byte', '518E8E', 'Non-zero in the menus; the FFB plugin plays no effects then.' + GTI_OK),
    calc('force', 'in_menu == 0 ? clamp(ffb_main > 128 ? (257 - ffb_main) / 128 : (ffb_main > 0 && ffb_main < 128 ? -ffb_main / 127 : 0), -1, 1) : 0',
         'Decoded force, -1 to 1. ' + DIR),
    calc('vibration', 'in_menu == 0 ? band(ffb_vibration, 63) / 63 : 0',
         "The game's vibration, 0 to 1: landings 0.79, other cars 0.57, walls and kerbs 0.29 to 0.43, a full-stop crash 1, kerb "
         "rumble 0.17 to 0.46, each fading away."),
    # race state and timing
    mem('race_state', 'Int32', '67FAC8', f'Race state: {GTI_STATES}. Not readable outside a race (the game clears the pointer).' + GTI_OK,
        offsets='2C8, 34'),
    calc('in_race', 'valid(race_state, 0) == 5 && finished == 0',
         "1 while racing (race state 5, go race) until you cross the finish line: the game keeps state 5 and drives the car on "
         "its own for a while after the finish." + GTI_OK),
    dict(calc('race_loaded', 'valid(race_state, 0) >= 1 && valid(race_state, 0) <= 9',
              "1 from the start camera to time up: the car values below read 0 outside this, because the game leaves its "
              "pointer to the player car stale between races."), Enabled=False),
    mem('game_mode', 'Int32', '67FAC8', "Game mode: 0 in a race (Alexis's recording, intermediate course); the variety modes' "
        "numbers are still to be found." + GTI, offsets='90'),
    mem('time_left', 'Int32', '680460', "Time left, seconds, as the race display shows it (the race code copies its milliseconds "
        "there each frame): counts down while racing and jumps up at each checkpoint. 0 outside a race." + GTI, offsets='2C4',
        formula='race_loaded ? value / 1000 : 0'),
    calc('checkpoint', 'in_race && maxw(delta(time_left) > 0.01, 1) > 0', '1 for a second from each time extension (the time left going up), for a lamp.'),
    calc('hurry', 'in_race && time_left > 0 && time_left <= 10', '1 in the last 10 seconds, where the game starts its warning.'),
    gti('position', 'Int32', 'CB8', 'Race position, 1 = first (the game stores 0 for first). 0 outside a race.' + GTI_OK,
        formula='race_loaded ? value + 1 : 0'),
    calc('leader', 'in_race && position == 1', '1 while you lead, for a lamp.'),
    gti('laps_done', 'Int32', 'CBC', 'Laps completed: 0 on the first lap. 0 outside a race.' + GTI_OK),
    mem('laps_total', 'Int32', '549458', "Laps in this race (3 by default; the operator's RACE LAP MAX setting)." + GTI_OK),
    calc('final_lap', 'in_race && laps_total > 0 && laps_done == laps_total - 1', '1 on the last lap.'),
    gti('finished', 'Byte', 'CC8', '1 once you have crossed the finish line.' + GTI_OK),
    gti('lap_time', 'Int32', 'CE8', "Current lap time, seconds. The game adds 1 each update and shows it as x 1000 / 30 ms, so this "
        "divides by 30 (it matched the lap times in Alexis's recording)." + GTI_OK, formula='race_loaded ? value / 30 : 0'),
    *[dict(gti(f'lap{n}', 'Int32', f'{0xCCC + 4 * (n - 1):X}', f'Time of lap {n} once completed, milliseconds.' + GTI_OK, formula=''), Enabled=False)
      for n in range(1, 8)],
    calc('last_lap', f'{gti_last} / 1000', 'Last completed lap time, seconds (0 on the first lap).'),
    # the player car
    gti('speed', 'Float', '648', "Speed as the speedo works it out, always km/h (with the display set to mph the game converts it "
        "only for the screen). The game caps the speedo at 220 km/h. 0 outside a race. Divided by Max speed." + GTI_OK,
        formula='race_loaded ? value / max_speed : 0'),
    gti('true_speed', 'Float', '1A4', "The car's real speed, km/h, not capped (the game keeps m/s; x 3.6 here). 0 outside a race." + GTI_OK,
        formula='race_loaded ? value * 3.6 : 0'),
    dict(mem('speedo_mph', 'Int32', '680460', "1 when the game's speed display is set to mph, 0 for km/h (the race display's copy "
         "of the setting)." + GTI, offsets='244', formula='race_loaded ? value : 0'), Enabled=False),
    gti('rpm', 'Float', '174', "Engine revs (the game keeps revs a second; x 60 here). The tacho follows these; above 7500 the game "
        "makes the needle bounce (the limiter, the same for every car); the engine itself reaches about 8000 with the wheels in "
        "the air. 0 outside a race. Divided by Max revs." + GTI_OK,
        formula='race_loaded ? value * 60 / max_revs : 0'),
    gti('rpm_tacho', 'Float', 'B8', "Revs as the tacho shows them (smoothed: the needle moves at most 500 a frame). 0 outside a "
        "race." + GTI_OK),
    gti('gear', 'Int32', '644', 'Gear as the dash shows it: 1 upwards, -1 reverse. 0 outside a race.' + GTI_OK),
    dict(gti('gear_stored', 'Byte', '164', "The gear as the game stores it, signed: matched the dash (1 to 5) all through Alexis's "
             "recording." + GTI_OK, formula='race_loaded ? signed8(value) : 0'), Enabled=False),
    gti('gearbox', 'Byte', 'F1', "1 with the manual gearbox (Alexis's recording); probably 0 with the automatic." + GTI_OK),
    *[gti(f'surface{n}', 'Int32', f'{0x42C + 4 * (n - 1):X}', f"Surface under wheel {n} (1 and 2 are the front pair: they cross a jump's lip first; left and right not known yet): the low "
          "byte is the surface code: 1 road, 2 kerb (every kerb in Alexis's recording), and the game also rumbles on 5 (not seen yet); "
          "with 256 added it skips the wheel. The upper bits change as the wheels cross the lips of jumps; what they mean is "
          "unknown.", formula='') for n in range(1, 5)],
    calc('kerb', f'in_race && true_speed > 5 ? (({gti_code(1, 2)}) + ({gti_code(2, 2)}) + ({gti_code(3, 2)}) + ({gti_code(4, 2)})) / 4 : 0',
         'Wheels on a kerb (surface code 2), 0 to 1 (a quarter per wheel), while moving.' + GTI_OK),
    calc('rough_ground', f'in_race && true_speed > 5 ? (({gti_code(1, 5)}) + ({gti_code(2, 5)}) + ({gti_code(3, 5)}) + ({gti_code(4, 5)})) / 4 : 0',
         "Wheels on surface code 5, which the game also rumbles on, 0 to 1 (a quarter per wheel), while moving. Not seen in "
         "Alexis's recording: perhaps grass or gravel elsewhere."),
    gti('force_angle', 'Float', '238', "The angle (radians) the game works the wheel force out from: + and - by side. Perhaps the "
        "slip or steering angle: recorded to find out (it may give drifting).", formula=''),
    dict(calc('jolt', 'in_race && ffb_other == 15 && delta(band(ffb_vibration, 63)) > 6 ? band(ffb_vibration, 63) : 0',
              "The level of each new jolt the game sends the vibration motor (pattern 15), 0 between them: 50 a landing, 36 another "
              "car, 63 a full-stop crash, 10 to 27 a wall or mounting a kerb." + GTI_OK), Enabled=False),
    calc('landing', 'maxw(jolt == 50, 0.25) > 0', '1 for 0.25 s from each landing after a jump (13 out of 13 in Alexis\'s recording).'),
    calc('car_hit', 'maxw(jolt == 36, 0.3) > 0', '1 for 0.3 s from each hit with another car, a rub or a head-on (14 in Alexis\'s '
         'recording). No side.'),
    dict(calc('wall_jolt', 'jolt > 0 && jolt < 30 && maxw(kerb > 0, 0.1) == 0',
              "A jolt of 10 to 27 with no wheel on a kerb in the last 0.1 s: a wall (mounting a kerb gives the same jolt, with "
              "a wheel already on it)." + GTI_OK), Enabled=False),
    calc('wall_hit', 'in_race && (maxw(wall_jolt, 0.3) > 0 || maxw(jolt > 0 && jolt < 30, 0.3) > 0 && maxw(true_speed, 0.3) - true_speed > 8)',
         "1 from a wall hit, held 0.3 s: a jolt of 10 to 27 with no wheel on a kerb, or one that costs more than 8 km/h within "
         "0.3 s (a wall hit while riding a kerb; this comes on up to 0.2 s after the jolt, as the speed falls). No side."),
    calc('crash', 'maxw(jolt == 63, 0.5) > 0', '1 for 0.5 s from a full-stop crash (the game\'s strongest jolt).'),
    calc('hit', 'crash ? 1 : (wall_hit || car_hit ? clamp(0.5 + (maxw(true_speed, 0.3) - true_speed) / 60, 0.5, 1) : 0)',
         'Walls and other cars, 0.5 to 1 by the km/h lost in the last 0.3 s (0.5 + loss / 60), and 1 for a full-stop crash. '
         'Landings are separate (landing).'),
    calc('accel_g', 'ema(slope(true_speed, 0.1), 0.05) / 3.6 / g', 'Longitudinal G from true_speed (km/h). + speeding up, - slowing down.'),
] + force_tail(), 'GTIClubSuperminiFesta', max_speed=160, max_revs=7500))
# 7500: the game's fixed limiter (needle bounce above it). 160: a little under the 163 km/h Alexis reached in the recording.

P.append(profile('RTUNED', 'R-Tuned: Ultimate Street Racing', [
    mem('crash_spring', 'Byte', '8519D18', '255 in a crash, 4 with the centring spring on (absolute address).' + UNVERIFIED, module=''),
    mem('boost_level', 'Byte', '8519D10', 'Boost strength (absolute address).' + UNVERIFIED, module=''),
    mem('boosting', 'Byte', '8519D20', '127 while boosting (absolute address).' + UNVERIFIED, module=''),
    mem('ffb_enable', 'Byte', '8519C58', "The game's force feedback switch. The FFB plugin changes 1 to 9 here to turn force feedback on; this plugin only reads, so if the values above stay 0, run the FFB plugin too (absolute address)." + UNVERIFIED, module=''),
    calc('crash', 'crash_spring == 255', '1 during a crash.'),
    calc('spring_on', 'crash_spring == 4', '1 while the game wants the centring spring.'),
    calc('boost', 'boosting == 127 ? boost_level / 400 : 0', 'Boost rumble strength as the FFB plugin scales it, 0 to about 0.64.'),
], 'R-Tuned'))

P.append(profile('DIRTYDRIVIN', "Dirty Drivin'", [
    mem('ffb_stiffness', 'Float', '886EC0', 'Centring stiffness the game asks for (absolute address); the FFB plugin reads but does not use it.' + UNVERIFIED, module=''),
    mem('ffb_raw', 'Float', '886EC4', 'Force the game asks for (absolute address).' + UNVERIFIED, module=''),
    mem('track', 'Byte', '96F770', 'Selected track (absolute address). On tracks 8 to 14 the FFB plugin swaps the force direction.' + UNVERIFIED, module=''),
    calc('force', 'clamp(-ffb_raw * (track >= 8 && track <= 14 ? -1 : 1), -1, 1)', 'Decoded force, -1 to 1. ' + DIR),
] + force_tail(), 'DirtyDrivin'))

P.append(profile('SONICASR', 'Sonic & Sega All-Stars Racing', [
    mem('ffb_cmd', 'Byte', '5CD864', "Force byte: 1 to 18 one way, 238 to 255 the other. The FFB plugin also writes 3 to the byte 12 before this to switch the game's force feedback on; this plugin only reads, so if this stays 0, run the FFB plugin too." + UNVERIFIED),
    calc('force', 'ffb_cmd > 0 && ffb_cmd < 19 ? ffb_cmd / 18 : (ffb_cmd > 237 ? -(256 - ffb_cmd) / 18 : 0)', 'Decoded force, -1 to 1. ' + DIR),
] + force_tail(), 'SonicAllStarsRacing'))

def ttx(prefix, display, base, single_masks, double_mask, table, right_high, ob):
    m = 4294967295 - sum(single_masks)
    code = f'band(ffb_raw, {m})'
    if double_mask:
        code = f'band({code}, {double_mask}) == {double_mask} ? {code} - {double_mask} : {code}'
    level = '0'
    for k, v in reversed(table):
        level = f'(ffb_code == {k} ? {v} : {level})'
    hi = f'(31 - ffb_level) / 15'; lo = f'(16 - ffb_level) / 15'
    force = (f'ffb_level > 15 ? {hi} : (ffb_level > 0 ? -{lo} : 0)' if right_high
             else f'ffb_level > 15 ? -{hi} : (ffb_level > 0 ? {lo} : 0)')
    return profile(prefix, display, [
        mem('ffb_raw', 'Int32', base, 'Output word the game sends its force feedback board: force code plus lamp bits.' + UNVERIFIED, offsets='45'),
        calc('ffb_code', code, 'ffb_raw with the lamp bits removed.'),
        calc('ffb_level', level, 'Force level, 1 to 15 one way and 16 to 30 the other, from the FFB plugin\'s table.'),
        calc('force', force, 'Decoded force, -1 to 1. ' + DIR),
    ] + force_tail(), ob)

def table(fn, path):
    s = open(path, encoding='latin-1').read()
    body = re.search(r'int\s+' + fn + r'\s*\(.*?\{(.*?)\n\}', s, re.S).group(1)
    return [(int(a), int(b)) for a, b in re.findall(r'case\s+(\d+)\s*:\s*return\s+(\d+)\s*;', body)]

GF = os.path.join(os.path.dirname(__file__), '..', 'ffbsrc', 'repo', 'Game Files')
P.append(ttx('CHASEHQ2', 'Chase H.Q. 2', '130B558', [16, 1024, 512, 128, 8, 256], 16385,
             table('ttx2chasehq2', f'{GF}/ChaseHQ2.cpp'), False, 'ChaseHQ2'))
P.append(ttx('WACKYRACES', 'Wacky Races', '7E00590', [16, 1024, 512, 128, 8, 256, 16384], None,
             table('ttx2wr', f'{GF}/WackyRaces.cpp'), True, 'WackyRaces'))

P.append(profile('SEGARACETV', 'Sega Race TV', [
    mem('ffb_cmd', 'Int32', '8B44210', 'Force value: 1 to 127 one way, 129 to 255 the other (absolute address).' + UNVERIFIED, module=''),
    calc('force', 'ffb_cmd > 0 && ffb_cmd < 128 ? -(128 - ffb_cmd) / 127 : (ffb_cmd > 128 ? clamp((ffb_cmd - 128) / 127, 0, 1) : 0)', 'Decoded force, -1 to 1. ' + DIR),
] + force_tail(), 'SegaRaceTV'))

# Battle Gear 4 Tuned (Japan): the FFB Arcade Plugin's addresses, then a read of Alexis's game.exe (9 November 2026,
# claude/BG4JP-exe-20261109.md; OutputBlaster's checksum 0xBAFACA7B, "Battle Gear 4 Tuned"). The cars are 8 records of
# 0x1BE0 bytes from <main>+42EA90 (the player's index at <main>+494808): +24C speed (the speedo shows its size), +254 engine
# revs (700 idle, capped at the car's limiter), +260 gear (-1 reverse), +18C race position (0 first), +121..123 contact flags.
# The FFB plugin reads car 0, and so does this profile.
# Alexis's recording of 10 November 2026 (claude/BG4JP-capture-20261110.md: Golf GTI, course 23, 4 cars) checked speed, revs,
# gears, positions and the contact bits against her notes. in_race stays 1 in the menus once a credit stops the attract demo
# (the car values freeze there), so the race rows also need view != 12 (the attract and menu camera).
BG4 = " From the game's code (9 November 2026); not yet checked in a recording."
BG4_OK = " Checked in Alexis's recording (10 November 2026)."
BG4_RACE = 'in_race && view != 12'
# The game froze twice in Alexis's recordings (26 s and 14 s: every value held, the race clock too), so `live` checks the race clock moves.
BG4_LIVE = '!(valid(time_left, -1) >= 0) || maxw(abs(delta(time_left)), 0.5) > 0'
P.append(profile('BG4JP', 'Battle Gear 4 Tuned (Japan)', [
    mem('speed', 'Float', '42ECDC', 'Speed, km/h, as the speedo shows it (car 0; the game keeps it signed, so the size is taken).' + BG4_OK + NORM['speed'][1],
        formula='abs(value) / max_speed'),
    mem('rpm', 'Float', '42ECE4', "Engine revs (car 0): 700 at idle, capped at the car's own limiter (Golf GTI 7500, Citro\u00ebn 2.0 VTS about "
        "8000)." + BG4_OK),
    mem('gear', 'Int32', '42ECF0', 'Gear (car 0): -1 reverse, 0 neutral, 1 to 6; the FFB plugin plays its shift effect when this changes. '
        'Int32: as a Byte, reverse read 255.' + BG4_OK),
    dict(mem('speed_ffb', 'Float', '3F3000', 'Speed as the FFB plugin reads it (it treats 180 as full strength): the same value as '
             '`speed` in Alexis\'s recording.' + BG4_OK), Enabled=False),
    mem('in_race', 'Byte', '4A9508', 'The game\'s race flag (set in race phases 6 and 7). It also reads 1 in the menus once a credit stops '
        'the attract demo (the car values freeze there), so the race rows also check `view`.' + BG4_OK),
    mem('race_phase', 'Int32', '42CCA8', 'The game\'s race phase: 1 to 5 while the race loads, 6 the countdown, 7 racing (it stays 7 in '
        'the menus afterwards); 8 for one frame as you cross the finish line, then 9 while the car rolls to a stop, and 0 about '
        '9 s later; 11 at time up, then 0 about 5 s later.' + BG4_OK, offsets='64'),
    mem('position', 'Int32', '42EC1C', 'Race position, 1 = first (car 0; the game keeps 0 for first and sorts the cars by how far round '
        'they are). Reads 1 in the countdown, before the first sort.' + BG4_OK, formula='value + 1'),
    calc('live', BG4_LIVE, '1 while the race clock moves (0 if the game freezes; 1 if the clock can\'t be read).'),
    calc('racing', BG4_RACE + ' && race_phase == 7 && live', '1 from the green light to the finish or time up, not in the countdown, '
         'the menus or a freeze.'),
    # From the exe (10 November 2026), for her next recording: the race scene <main>+4B1758 holds the race timer task at +34,
    # whose +1C counts the time left down in frames (60 a second); the checkpoint code (0x4B0191) adds each checkpoint's
    # seconds x 60 to it, and it reaching 0 sets race phase 10 (time up). Phase 8 is set when you finish. The session
    # <main>+3F25DC has a 0x980 block per player (player 0 first): +984 the lap, +160 the checkpoint number.
    mem('time_left', 'Int32', '4B1758', 'Race time left, seconds (the RT the screen shows): the game counts it in frames, 60 a second, '
        'and adds each checkpoint\'s extension.' + BG4_OK, offsets='34, 1C', formula='value / 60'),
    calc('checkpoint', 'racing && maxw(delta(time_left) > 1, 2) > 0', '1 for 2 s after a checkpoint adds time (checked: 113.25 to '
         '173.23 s at Alexis\'s checkpoint, 10 November 2026).'),
    mem('lap', 'Int32', '3F25DC', 'Laps completed by player 0: 0 on the first lap, 1 after the first line crossing.' + BG4_OK, offsets='984'),
    # Nitro (0x47D510): car +290 shots left; using one sets +294 to 420 frames (7 s) and it counts down to 0.
    mem('nitro_left', 'Int32', '42ED20', 'Nitro shots left (car 0): 3 at the start of a race, one fewer at each nitro.' + BG4_OK),
    dict(mem('nitro_time', 'Int32', '42ED24', 'Nitro frames left while one burns: 420 (7 s) when used, counting down to 0 (car 0); '
             'the same spans as wall_contact bit 2.' + BG4_OK), Enabled=False),
    calc('boost', 'racing && band(wall_contact, 2) > 0', '1 while a nitro burns (7 s a shot; wall_contact bit 2, the same as the nitro '
         'timer at each of Alexis\'s nitro marks, 10 November 2026).'),
    # Brake! (Alexis would like it as a value): the HUD (0x45E8BB) shows its automatic_brake overlay while bit 2 of the
    # player's car +CCC is set, and fades it 10 frames after; bit 1 shows the automatic_return overlay (0x45E945).
    mem('assist_flags', 'Byte', '42F75C', 'The car\'s driving-aid flags (car 0 +CCC): 2 the game\'s automatic brake, 1 its '
        'automatic return (its brake assist, which wasn\'t on in Alexis\'s races).' + BG4),
    dict(mem('car_flags', 'Int32', '42EBB0', 'The car\'s state flags (car 0 +120; bit 1 switches on the game\'s automatic brake code). '
             'Recorded to name more of them.' + BG4), Enabled=False),
    # Brake! (Alexis, 10 November 2026: yellow italic text under "Extended Time!", above the curve markers) belongs to the car
    # navigation (CNaviTask, the CARNAVI setting): the race scene keeps it at +3C; its update (0x4B8D00) walks the course's
    # navi entries: the low 12 bits a curve sign (+44, shown while +40 is 1), the top 4 bits a second sign (+4C, shown while
    # +48 is 1; 0x2000 clears it), 0xE00/0xF00 switch the signs on and off. Alexis's 08:56 recording (11 November): the +40/+48
    # flags are one-frame triggers, +4C holds 4096 (Brake!), +44 holds the curve code until the next (3328 = none).
    mem('navi_curve', 'Int32', '4B1758', 'The curve marker the car navigation shows, held until the next: 1 hairpin right, 2 medium right, '
        '4 hairpin left, 5 medium left, 9 slight left, 6 snake left-right-left, 48 snake right-left (Alexis\'s readings); 3328 none.'
        + BG4_OK, offsets='3C, 44'),
    dict(mem('navi_curve_on', 'Int32', '4B1758', '1 for a frame as a new curve marker appears.' + BG4_OK, offsets='3C, 40'), Enabled=False),
    dict(mem('navi_sign', 'Int32', '4B1758', 'The car navigation\'s other sign: 4096 for Brake!.' + BG4_OK, offsets='3C, 4C'), Enabled=False),
    dict(mem('navi_sign_on', 'Int32', '4B1758', '1 for a frame as Brake! appears.' + BG4_OK, offsets='3C, 48'), Enabled=False),
    calc('brake_warning', 'racing && maxw(navi_sign_on > 0, 1.5) > 0', '1 for 1.5 s from each Brake! (checked: it came about half a second '
         'before each of Alexis\'s Brake! marks, and with the one she saw just after a checkpoint, 11 November 2026).'),
    calc('corner_ahead', 'racing && navi_curve > 0 && navi_curve != 3328', '1 while the car navigation shows a curve marker.'),
    # Codes named by Alexis against her 08:56 recording (11 November 2026): 1 hairpin right, 2 medium right, 4 hairpin left,
    # 5 medium left, 9 slight left, 6 snake left-right-left, 48 snake right-left. Others not seen yet (left at side 0).
    calc('corner_side', 'corner_ahead ? (navi_curve == 1 || navi_curve == 2 || navi_curve == 48 ? 1 : (navi_curve == 4 || navi_curve == 5 || '
         'navi_curve == 9 || navi_curve == 6 ? -1 : 0)) : 0',
         'The corner coming up: +1 right, -1 left (a snake by its first bend), 0 none or a marker not yet named.'),
    calc('corner_sharpness', 'corner_ahead ? (navi_curve == 1 || navi_curve == 4 ? 1 : (navi_curve == 2 || navi_curve == 5 || navi_curve == 6 || '
         'navi_curve == 48 ? 0.6 : (navi_curve == 9 ? 0.3 : 0))) : 0',
         'How sharp the corner coming up is: 1 hairpin, 0.6 medium or a snake, 0.3 slight, 0 none or a marker not yet named.'),
    calc('auto_brake', 'racing && band(assist_flags, 2) > 0', '1 while the game\'s automatic brake assist acts (its overlay shows).'),
    # Drift angle (Alexis's 20:58 recording): car +100/+108 is the position in metres and +D0/+D8 a unit vector along the
    # car's heading (it lines up with the direction of travel within a degree when driving straight). The angle between
    # the heading and the travel direction is the drift angle; + is a right-hand drift (it follows the wheel, as Alexis says).
    dict(mem('pos_x', 'Float', '42EB90', 'Car position x, metres (car 0 +100).' + BG4_OK), Enabled=False),
    dict(mem('pos_z', 'Float', '42EB98', 'Car position z, metres (car 0 +108).' + BG4_OK), Enabled=False),
    dict(mem('head_x', 'Float', '42EB60', 'The car\'s heading, x (car 0 +D0; a unit vector).' + BG4_OK), Enabled=False),
    dict(mem('head_z', 'Float', '42EB68', 'The car\'s heading, z (car 0 +D8).' + BG4_OK), Enabled=False),
    dict(calc('vel_x', 'slope(pos_x, 0.1)', 'Travel speed along x, m/s (from the position over 0.1 s).'), Enabled=False),
    dict(calc('vel_z', 'slope(pos_z, 0.1)', 'Travel speed along z, m/s.'), Enabled=False),
    calc('drift_angle', 'racing && hypot(vel_x, vel_z) * 3.6 > 10 ? -atan2(vel_x * head_z - vel_z * head_x, vel_x * head_x + vel_z * head_z) '
         '* 57.29578 : 0', 'Drift angle, degrees: between where the car points and where it is going, + pointing right of its path '
         '(a right-hand drift). 0 below 10 km/h and outside a race. Alexis\'s drifts read 20 to 50 degrees.'),
    calc('drift', '(1 - pow(1 - clamp((abs(drift_angle) - 5) / 45, 0, 1), 2)) * sqrt(clamp((speed * max_speed - 20) / 80, 0, 1))',
         'Drifting, 0 to 1, with ID6\'s weighting (Alexis, 10 November 2026): nothing under 5 degrees, full at 50; nothing under '
         '20 km/h, full from 100 km/h.'),
    calc('leader', 'racing && position == 1', '1 while you lead (for a lamp).'),
    dict(mem('my_car', 'Int32', '494808', "The player's car number. The car rows read car 0, as the FFB plugin does: 0 in Alexis's "
             'recording.' + BG4_OK), Enabled=False),
    mem('ground_contact', 'Byte', '42EBB1', 'Ground and drive flags (car 0 +121): 128 wheelspin (full throttle pulling away), 4, 8 and 32 '
        'a gear change (each shift), 32 and 64 revving on the grid.' + BG4_OK),
    mem('wall_contact', 'Byte', '42EBB2', 'Wall flags: 16 a hit on the left, 32 on the right (the moment of the hit), 64 touching or '
        'scraping a wall on the left, 128 on the right; 2 a nitro burning (7 s a shot: the FFB plugin\'s boost effect; it matches the '
        'game\'s nitro timer exactly in Alexis\'s 21:47 recording); 4 not known (on for long stretches of some races).' + BG4_OK),
    mem('car_contact', 'Byte', '42EBB3', 'Car contact flags: 1 your front (hitting the car ahead), 2 your right side, 4 your rear, '
        '8 your left side.' + BG4_OK),
    mem('view', 'Byte', '3F2654', 'Camera: 12 in the attract demo and the menus, 0 while a race loads, 1 then 2 as the camera swings into '
        'the cockpit.' + BG4_OK),
    calc('impact_side', '(band(wall_contact, 16) > 0 || band(car_contact, 8) > 0) ? -1 : ((band(wall_contact, 32) > 0 || band(car_contact, 2) > 0) ? 1 : 0)',
         'A hit on a wall or car side: +1 right, -1 left, 0 none (front and rear bumps have no side).'),
    calc('contact', 'band(wall_contact, 48) > 0 || band(car_contact, 15) > 0', '1 while hitting a wall or touching another car on any side.'),
    calc('wall_touch', 'band(wall_contact, 64) > 0 ? -1 : (band(wall_contact, 128) > 0 ? 1 : 0)',
         'Touching or scraping a wall: -1 left, +1 right, 0 none.'),
    calc('car_bump', 'band(car_contact, 5) > 0', '1 while bumping the car ahead or being bumped from behind.'),
    calc('wheelspin', 'racing && band(ground_contact, 128) > 0', '1 while the driven wheels spin (pulling away hard in a low gear).'),
    calc('shift', 'maxw(delta(gear) != 0 && gear != 0, 0.2)', '1 for 0.2 s after a gear change.'),
    accel(),
], 'BattleGear4Tuned', max_speed=200, max_revs=8000))

P.append(profile('BATMAN', 'Batman (arcade)', [
    mem('ffb_raw', 'Float', '7EF524', 'Force the game asks for.' + UNVERIFIED),
    calc('force', 'clamp(ffb_raw / 1.2, -1, 1)', 'Decoded force, -1 to 1. ' + DIR),
] + force_tail(), 'batman'))

P.append(profile('SNOCROSS', 'Winter X Games SnoCross', [
    mem('ffb_raw', 'Float', '99AB6C', 'Force the game asks for (absolute address).' + UNVERIFIED, module=''),
    calc('force', 'clamp(ffb_raw / 1.2401, -1, 1)', 'Decoded force, -1 to 1. ' + DIR),
] + force_tail()))

P.append(profile('CRAZYTAXI', 'Crazy Taxi', [
    mem('speed', 'Float', '106A010', 'Speed (units unknown; the FFB plugin treats 10 as full strength).' + UNVERIFIED),
    mem('timer', 'Int32', '12A41A4', 'Game timer; 0 outside play.' + UNVERIFIED),
    mem('ingame_flag', 'Byte', '12AA314', 'The FFB plugin plays effects while this is 0 and the timer is running.' + UNVERIFIED),
    mem('surface', 'Byte', '1AB0D74', 'Ground: 0 road, 3 grass, 5 shoreline, 9 sand, 10 footpath, 14 underwater, 17-20 stairs, 21 subway, 255 hitting something.' + UNVERIFIED),
    mem('wall_left', 'Float', '126214C', 'Above 0 while touching a wall on the left.' + UNVERIFIED),
    mem('wall_right', 'Float', '12621D0', 'Above 0 while touching a wall on the right.' + UNVERIFIED),
    mem('crazy_moves1', 'Byte', '12EF892', 'Crazy moves flags; 16 = a crazy move.' + UNVERIFIED),
    mem('crazy_moves2', 'Byte', '12EF893', 'Non-zero during other crazy moves.' + UNVERIFIED),
    mem('game_rumble', 'Byte', '12EF93B', "The game's own rumble." + UNVERIFIED),
    calc('playing', 'ingame_flag == 0 && timer != 0', '1 during play.'),
    calc('impact_side', 'surface == 255 ? (wall_right > 0 ? 1 : (wall_left > 0 ? -1 : 0)) : 0', 'Hitting a wall: +1 right, -1 left.'),
    calc('collision', 'maxw(surface == 255 && wall_right <= 0 && wall_left <= 0, 0.3)', '1 for 0.3 s after hitting something that isn\'t a wall (cars, objects).'),
    calc('crazy_move', 'band(crazy_moves1, 16) > 0 || crazy_moves2 != 0', '1 during a crazy move.'),
    calc('off_road', 'surface == 3 || surface == 5 || surface == 9 || surface == 14', '1 on grass, shoreline, sand or underwater.'),
    calc('stairs', 'surface >= 17 && surface <= 20', '1 on stairs.'),
]))

# GRID: checked against Alexis's recording of 3 November 2026 (TeknoParrot, FFB plugin in its Custom mode, G25 over USB).
GR = " Checked in Alexis's recording of 3 November 2026."
GR12 = " Checked in Alexis's recordings of 12 November 2026 (GRID.exe, claude/GRID-capture-20261112.md)."
GR16 = " From GRID.exe (16 November 2026); not yet read in a recording."
P.append(profile('GRID', 'GRID (arcade)', [
    # The on-screen dial (Alexis's Cheat Engine work, 4 November 2026): the revs OutputBlaster's hook reads (fstp [esi+2C] at
    # GRID.exe+91C747) sit in GRID's 'dialinterface' object at +284, with the speed, gear, throttle and shift lights the dash
    # shows. Its address never moves (the dial is made when the game loads), but the profile reads it by pointer chains that
    # held through restarts, a reboot, other cars and tracks. Checked in four recordings that afternoon.
    *[mem(n, t, 'B1B100', note, offsets='200, 120, ' + off, formula=f)
      for n, t, off, f, note in [
        ('speed', 'Float', '298', 'value * 3.6 / max_speed',
         "Speed in km/h as the speedo shows it, from the on-screen dial (it keeps m/s; x 3.6 here): 95.7, 156.2, 211.7 and 265.3 where "
         "Alexis noted 95, 156, 211 and 265 on the limiter in 1st to 4th, 138 and 196 in another car, 61 in reverse (it reads + in reverse too). "
         "Smooth, unlike wheel_speed. Divided by Max speed."),
        ('rpm', 'Float', '284', 'value / max_revs',
         "Engine RPM, from the on-screen dial: the value OutputBlaster's hook reads, so OutputBlaster isn't needed. It stops at each car's "
         "limiter (6500 to 8200, so far). 1000 to 1500 in the menus and at the start line, 0 while a race loads. Divided by Max revs."),
        ('rev_frac', 'Float', '3B4', '',
         "Revs as a fraction of this car's limiter (the dial's needle), 0 to 1: 1.0 at 8000 in the fastest class, at 8200 in another car "
         "(it never passes 1). Feeds Car_rpm_frac (plugin 0.17.0), so the rev limiter effect fires at every car's own limiter."),
        ('gear', 'Byte', '278', 'value >= 9 ? -1 : value',
         "Gear as the dial shows it: 1 to 6 (the fastest class has six), -1 reverse (the game stores 9). 1 at the start line; no neutral seen."),
        ('throttle', 'Float', '27C', '',
         "Throttle, 0 to 1, as the game uses it (it follows the pedal; the game cuts it at some gear changes). Feeds Car_throttle."),
        ('shift_lights', 'Int32', '254', '(band(value, 1) > 0) + (band(value, 256) > 0)',
         "The dial's shift lights, 0 to 2: one from about 85 to 88% of the car's limiter, both from about 95%, flashing at the limiter."),
        ('distance', 'Float', '29C', '',
         "Distance driven in this race, metres; back to 0 in the menus."),
      ]],
    # From GRID.exe (12 November 2026, claude/GRID-exe-20261112.md): the dial's game code fills +280 from the car's brake input,
    # beside the throttle at +27C (both from the car physics' input channels 1 and 2).
    mem('brake', 'Float', 'B1B100', "Brake, 0 to 1, as the game uses it: the dial keeps it beside the throttle (+27C), both copied each frame "
        "from the car's own inputs (GRID.exe, 12 November 2026). It followed the G25's brake pedal (correlation 0.95 while racing) in "
        "Alexis's recording of 12 November 2026, and reads 1 while the game holds the car after TIME OVER.", offsets='200, 120, 280'),
    # The race (GRID.exe, 12 November 2026; checked in Alexis's recordings of 12 November, claude/GRID-capture-20261112.md). The dial
    # (+210) points at the HUD, whose +1F8 is the race; the race's +21A0 holds the race clock object at +F8 (racing flag +10,
    # finished +11, laps +14, clock +28 in microseconds, cars +60, one 0xC08 record per car from +68, how the race ends +F1B0).
    # Car 0 is the player (veh_id 0; the game takes her controls at car 0's last line). The dial's +258 is the car physics.
    *[mem(n, t, 'B1B100', note + GR12, offsets='200, 120, ' + off, formula=f)
      for n, t, off, f, note in [
        ('race_on', 'Byte', '210, 1F8, 21A0, 108', '',
         "1 from GO (the 'racestart' message) until the race is cleared in the menus; it stays 1 after the finish and TIME OVER "
         "(race_over marks those). 0 in the attract mode and menus."),
        ('race_over', 'Byte', '210, 1F8, 21A0, 109', '',
         "1 once the race has ended: at TIME OVER, and 1.1 s after the player's finish line; the race clock stops then."),
        ('race_clock', 'Int64', '210, 1F8, 21A0, 120', 'value / 1000000',
         "The race clock, seconds: the TT on screen (the game keeps microseconds and steps 1/120 s). 0 until GO; it stands still "
         "while paused and from race_over (Alexis's pause screen read 0:42.21 where this read 42.235)."),
        ('race_laps', 'Int32', '210, 1F8, 21A0, 10C', '', "Laps in this race (3 in both of Alexis's races; 1 in the menus)."),
        ('car0_laps', 'Int32', '210, 1F8, 21A0, 178', '',
         "Laps the player has completed: up by one at each lap line, so it reaches race_laps at the finish line."),
        ('car0_lap_time', 'Int64', '210, 1F8, 21A0, 190', 'value / 1000000',
         "The player's own race time, seconds: the same as race_clock until the finish line, then held at the finishing time "
         "(3:18.777 against the 3:18.77 on screen)."),
      ]],
    mem('steer', 'Float', 'B1B100', "Steering, -1 full left to 1 full right, as the car's physics gets it (input channel 6, which "
        "the game keeps the other way round: this row flips it). Checked against the G25's own steering over USB (correlation 0.93) in "
        "Alexis's recording of 12 November 2026." + GR12, offsets='200, 120, 258, E30', formula='clamp(-value, -1, 1)'),
    # Position (GRID.exe, 16 November 2026): the HUD's race position element reads it from the HUD's +C0 -> +4, a list of up to three
    # players (one per linked cabinet), 0x70 bytes each from +8; +15C how many, +170 which one is this cabinet's. Each player's
    # +6C is its place, counted from 0 (the HUD adds 1), and +14 its car's number in the race's car records.
    *[dict(mem(n, 'Int32', 'B1B100', 'Raw: ' + note + GR16, offsets='200, 120, 210, C0, 4, ' + off), Enabled=False)
      for n, off, note in [
        ('place0', '74', "the first player's place, counted from 0."),
        ('place1', 'E4', "the second player's place, counted from 0 (linked cabinets)."),
        ('place2', '154', "the third player's place, counted from 0 (linked cabinets)."),
        ('me', '170', "which of the players is this cabinet's, 0 to 2."),
        ('players', '15C', "how many players (cabinets) are in the race."),
        ('my_car', '1C', "the first player's car number in the race's car records (0 if car 0 is the player)."),
      ]],
    # The game mode (GRID.exe, 16 November 2026): the race's +21C4 -> +10 is the game's context; its +48 -> +0 -> +C is the game
    # mode object, whose +54 the StateSetCareerSega... states set. The time left lives in the StateRaceCountdown state (+3C, a float
    # in seconds; +E8 checkpoints passed), which hangs off the game's state tree, so it has no fixed chain yet.
    dict(mem('game_mode', 'Int32', 'B1B100', "Raw: the game mode: 7 Championship, 8 Quick Race (set by the game's "
             "StateSetCareerSegaChampionship and ...QuickRace states); 1 is the linked mode, whose time runs on a shared clock." + GR16,
             offsets='200, 120, 210, 1F8, 21C4, 10, 48, 0, C, 54'), Enabled=False),
    *[dict(mem(n, t, 'B1B100', 'Raw: ' + note, offsets='200, 120, ' + off, formula=f), Enabled=False)
      for n, t, off, f, note in [
        ('veh_id', 'Int32', '2B0', '', "the number of the car the dial follows: 0 all through Alexis's recordings of 12 November 2026."),
        ('hud_mode', 'Int32', '210, 1FC', '', "the HUD's race display mode, 0 to 8 (the lap counter picks its layout from it)."),
        ('race_cars', 'Int32', '210, 1F8, 21A0, 158', '', "cars in this race: 6 in a race, 2 in the menus, 0 while loading."),
        ('race_type', 'Int32', '210, 1F8, 21A0, F2A8', '',
         "how the race ends: 1 in both of Alexis's races (yet the race ended 1.1 s after her line, not when the last car finished)."),
        ('car0_on', 'Byte', '210, 1F8, 21A0, 164', '', "the player's racing flag in the race's car records: the same as race_on."),
        ('car0_lap', 'Int32', '210, 1F8, 21A0, 17C', '',
         "the player's lap counter: -1 before the start line (the grid is 2 s behind it), then 0, 1, 2..."),
      ]],
    mem('rpm2', 'Float', '41CA50', "Engine RPM again, by a second pointer chain from Alexis's table, for if the first can't be read. "
        "Divided by Max revs.", offsets='2B8, 8, 5E0', formula='value / max_revs'),
    calc('rev_max', 'hold(valid(rpm, rpm2) * max_revs / rev_frac, rev_frac > 0.3 && rev_frac < 0.97)',
         "This car's limiter, from rpm / rev_frac: 8000 (fastest class), 8200, 7000 and 6500 in Alexis's cars."),
    *[dict(mem(n, t, b, note, module=m, offsets=o), Enabled=False) for n, t, b, m, o, note in [
        ('wheel_speed', 'Float', '28C008', MAIN, 'D0, 460, 184, 4F4',
         "The old speed row, kept for comparison: driven-wheel speed (wheelspin and locked brakes show), and not the speedo's km/h "
         "(the speedo reads 1.0 to 1.26 times it, by car). From the FFB Arcade Plugin's reading of this game."),
        ('gear_abs', 'Byte', '414F7898', '', '',
         "The old gear row, kept for comparison: one less than the dial's gear (0 = 1st), 0 in reverse; an absolute address that "
         "read 1 all race in one recording."),
      ]],
    dict(mem('dial_294', 'Float', 'B1B100', "Unknown, from the dial: about 2.5 to 2.8 on full throttle, about 1.3 at low revs, near 0 off the throttle "
             "(engine torque or load?). Kept for a look.", offsets='200, 120, 294'), Enabled=False),
    dict(mem('tacho_scale', 'Float', 'B1B100', "The tacho's full scale: 8000 or 10000 by car.", offsets='200, 120, 370'), Enabled=False),
    mem('hit_strength', 'Byte', 'A3FA34', 'Strength of the current hit, 0 to 8: wall hits from 80 to 220 km/h read 2 to 6, '
        'and it holds for 0.5 to 1.5 s. Scraping along a wall and low-speed touches read 0.' + GR, offsets='678, 14, 30, 2C'),
    mem('car_contact', 'Byte', 'A3FA34', 'How many contacts with other cars right now: 1, then 2 and up to 5 in a pile-up, counting back down '
        '(recordings of 4 November 2026). Not a side. A car touch does not always set hit_strength.' + GR, offsets='678, 14, 30, 3D4'),
    mem('skids', 'Byte', 'A3FA34', 'Tyre skid level: 12 with grip, 13 to 16 in slides.' + GR, offsets='678, 14, 30, 100'),
    mem('wheel_rumble', 'Byte', 'A3FA34', 'Surface rumble level, 0 to 37: 1 or 2 on kerbs.' + GR, offsets='678, 14, 30, B4'),
    mem('wall_side', 'Float', 'B1B7F0', 'Side of the last wall touched: above 0 right (+1 or about 0.5), below 0 left; '
        'it keeps its last value between hits. Every wall hit Alexis marked read the right side; it is not the side of a car hit.' + GR,
        offsets='730, 4, 4, 118'),
    calc('impact_side', 'hit_strength > 0 ? (wall_side > 0 ? hit_strength / 8 : (wall_side < 0 ? -hit_strength / 8 : 0)) : 0',
         'Wall hit strength, + right, - left: the force the FFB plugin sends, which the G25 got over USB to the frame (3 November 2026). ' + DIR),
    calc('car_hit', 'car_contact > 0 && hit_strength > 0 ? hit_strength / 8 : 0', 'Hit strength while touching another car, 0 to 1.'),
    calc('skid', 'speed > 0 && skids > 12 ? clamp((skids - 12) / 8, 0, 1) : 0', 'Skidding, 0 to 1.'),
    calc('road_rumble', 'clamp(wheel_rumble / 37, 0, 1)', 'Surface rumble, 0 to 1.'),
    calc('shift', 'maxw(delta(gear) != 0 && speed > 0, 0.2)', '1 for 0.2 s after a gear change.'),
    accel(),
    calc('clock_moving', 'maxw(delta(valid(race_clock, 0)) > 0, 0.1)', '1 while the race clock runs (held 0.1 s, as the plugin '
         'sometimes reads the same game frame twice); 0 while paused and once the race is over.'),
    calc('racing', 'valid(race_on, -1) < 0 ? 1 : (race_on == 1 && valid(race_over, 1) == 0 && valid(car0_laps, 0) < '
         'valid(race_laps, 0) && clock_moving)', '1 from GO to the finish line: the race is on and not over, the player has laps '
         'to go, and the race clock is moving (so 0 while paused, at TIME OVER, in the attract mode and menus). In Alexis\'s '
         'recording of 12 November 2026 it ran from GO to her pause, from the pause to TIME OVER, and from GO to the exact sample '
         'the game took her car at the finish line. If the race can\'t be read at all it counts as racing, so a failed read '
         'leaves the effects as they were before this row (it never failed in her recordings).'),
    calc('lap', 'race_laps > 0 ? clamp(car0_laps + 1, 1, race_laps) : 0', 'The lap the player is on, 1 to the laps in the race.'),
    calc('final_lap', 'racing && race_laps > 1 && lap == race_laps', '1 on the final lap.'),
    calc('lap_line', 'maxw(delta(car0_laps) > 0 && car0_laps > 0, 1)', '1 for 1 s at each lap line, the finish line included.'),
    calc('position', 'valid(me, 0) == 0 ? place0 + 1 : (me == 1 ? place1 + 1 : place2 + 1)',
         'The player\'s place, 1 = first, as the HUD shows it (the game counts from 0). From GRID.exe (16 November 2026); not '
         'yet read in a recording.'),
    calc('leader', 'racing && position == 1', '1 while in the lead.'),
], max_speed=280, max_revs=6900))   # Max speed 280 km/h (Alexis, 4 November 2026); Max revs 6900 now only scales the rpm row (effects use rev_frac)

P.append(profile('RF3D', 'Road Fighters 3D', [
    mem('ffb1', 'Byte', '7D2BB9', 'Force: 1 to 7 one way, 8 to 15 the other.' + UNVERIFIED, module='jgt.dll'),
    mem('ffb2', 'Byte', '7D2BBA', 'Vibration, 1 to 63.' + UNVERIFIED, module='jgt.dll'),
    mem('ffb3', 'Byte', '7D2BBB', 'Non-zero (with ffb4) while force feedback is active.' + UNVERIFIED, module='jgt.dll'),
    mem('ffb4', 'Byte', '7D2BBC', 'Non-zero (with ffb3) while force feedback is active.' + UNVERIFIED, module='jgt.dll'),
    mem('gear', 'Int32', '953F70', 'Gear, 1 to 6.' + UNVERIFIED, module='jgt.dll', offsets='5C, 390, 18'),
    mem('menu', 'Int32', '94BFFC', '0 while racing, as the FFB plugin uses it.' + UNVERIFIED, module='jgt.dll', offsets='46C'),
    mem('timer', 'Int32', '954394', 'Game timer.' + UNVERIFIED, module='jgt.dll'),
    calc('active', 'ffb3 != 0 && ffb4 != 0', '1 while force feedback is active.'),
    calc('force', 'active ? (ffb1 > 0 && ffb1 < 8 ? -ffb1 / 7 : (ffb1 > 7 && ffb1 < 16 ? (16 - ffb1) / 8 : 0)) : 0', 'Decoded force, -1 to 1. ' + DIR),
    calc('vibration', 'active && ffb2 > 0 && ffb2 < 64 ? ffb2 / 63 : 0', 'Vibration, 0 to 1.'),
] + force_tail()))

P.append(profile('CRUISNBLAST', "Cruis'n Blast", [
    mem('ffb_menu', 'Float', '8BABBAC', 'Force in the menus; in races the FFB plugin takes the force from a hook instead, so this plugin has no race force for this game (absolute address).' + UNVERIFIED, module=''),
    mem('on_road', 'Byte', '8BABBA8', 'Drops to 0 off the road (absolute address).' + UNVERIFIED, module=''),
    mem('in_game', 'Int32', '8BABBC0', '0 in the menus, 1 in a race (absolute address).' + UNVERIFIED, module=''),
], 'CruisnBlast'))

DIR5 = ("+ = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, "
        "a left-hand wall hit -0.5).")

def wmmt(prefix, display, a, ob, max_speed=None, max_revs=None):
    # Checked against three WMMT5DX+ recordings (29 October 2026, plugin 0.9.0 with the 64-bit helper,
    # G25 USB capture alongside; 1 November 2026, a full race in a five-speed car with low-speed joints).
    # The other versions use the same layout at their own addresses.
    here = prefix == 'WMMT5DXP'
    def src(checked=True):
        if here and checked:
            return " From the FFB Arcade Plugin's reading of this game; checked in recordings (29 October and 1 November 2026)." + BIT64
        return UNVERIFIED + (' The same value was checked on WMMT5DX+ (29 October and 1 November 2026).' if checked else '') + BIT64
    f = int(a['ffb'], 16)
    rows = [
        mem('speed', 'Int32', a['speed'], 'Speed, km/h, in whole numbers.' + src()),
        mem('rpm', 'Int32', a['rpm'], 'Engine RPM. The limiter is soft and depends on the car: revs creep up to about 8250 on one WMMT5DX+ car and 8500 on another. Before the race starts it can read nonsense (99999 seen).' + src()),
        # One row (3 November 2026): the stored value is the gear, so the old gear_raw + gear = gear_raw pair was redundant.
        mem('gear', 'Byte', a['gear'][0], 'Gear in play, as the game stores it: 1 = first, 0 = neutral (as at a rolling start until you select a gear). Checked on WMMT5DX+ in a five-speed car (1 November 2026: 1 to 5 from a standing start, 0 while revving in neutral). Outside a race it shows whatever the game left there.' + src(), offsets=a['gear'][1]),
        mem('race_time', 'Float', a['time'], 'Race time, seconds: starts at the green light and stops at the finish, where it settles on the finishing time (5:34.191 read 334.191). Holds its value on the results screen and when the game freezes.' + src(), offsets='18'),
        calc('in_race', 'race_time > 0 && maxw(delta(race_time) > 0, 0.1)',
             '1 while the race clock is running: off before the start, after the finish line (results screen) and while the game is frozen. Checked on WMMT5DX+ (1 November 2026).'),
        mem('tire_slip', 'Float', a['ffb'], 'Tyre slip, signed: - turning or sliding right, + left. Small in ordinary corners (0.04), 0.1 and more in slides, and never above 0.1125 (the game caps it).' + src()),
        mem('spring', 'Float', f"{f + 4:X}", 'Centring spring the game asks for, 0 to 1: about 0.53 while driving, easing off in slides and hits, 0 in a big crash, on a jump and before the race starts. On WMMT5DX+ the wheel got exactly this.' + src()),
        mem('friction', 'Float', f"{f + 8:X}", 'Friction the game asks for, 0 to 1 (stayed at 0.5 on WMMT5DX+).' + src()),
        mem('collisions', 'Float', f"{f + 12:X}", 'The force the game sends the wheel for joints, ripple strips and walls: short kicks for joints and strips (0.21 up to about 100 km/h, rising to 0.31 at 240), 0.5 or more for hits, and 0.2 held while the car is pushed along a wall after a hit. + right, - left. Above 100 km/h the wheel got exactly this; at low speed the FFB Arcade Plugin sent the wheel less (0.07 at 15 km/h).' + src()),
        calc('road_joint', 'abs(collisions) > 0.001 && abs(collisions) < 0.35 && maxw(abs(collisions) >= 0.35, 0.25) == 0 && minw(abs(collisions) > 0.001, 0.1) == 0 ? abs(collisions) : 0',
             'Expansion joints and ripple strips, 0 to about 0.3, no direction: the game sends each as a kick under 0.1 s long, one per axle (front then rear, closer together the faster you go). Kicks just after a hit, or held 0.1 s or more, are wall contact instead. On WMMT5DX+ 0.21 from walking pace to 100 km/h, 0.31 at 240; caught at 15, 40, 60 and 80 km/h (1 November 2026).'),
        calc('rumble_strip', 'maxw(avg(maxw(road_joint > 0, 0.07), 0.45) > 0.85, 0.3)',
             '1 on a ripple strip: the game kicks every 0.07 to 0.13 s for as long as you are on it, where a joint is one kick per axle (two joints close together make 3 or 4). Needs about five kicks, so it comes on about 0.4 s into a strip (as a short strip ends) and stays on 0.3 s after. Checked on WMMT5DX+: long strips at 100 to 240 km/h, five short ones (5 or 6 kicks) and one crossed in a slide, confirmed from video (1 November 2026); on and off while drifting across one.'),
        calc('impact', 'abs(collisions) >= 0.35 ? clamp(collisions, -1, 1) : 0',
             'Hits, -1 to 1: the game sends 0.5 for most hits and more in a big crash (0.78 seen). Sliding along a wall gives a run of 0.5 kicks. ' + DIR5),
        calc('impact_side', 'maxw(impact, 0.3) + minw(impact, 0.3)', 'Hit held for 0.3 s so SimHub sees it, -1 to 1. ' + DIR5),
        calc('wall_contact', 'minw(maxw(abs(collisions) >= 0.35 || minw(abs(collisions) > 0.001, 0.1), 0.15), 0.3) ? valid(hold(sign(collisions), abs(collisions) > 0.001), 0) : 0',
             'Scraping along a wall, +1 right, -1 left, 0 otherwise: on after 0.3 s of steady contact (hits under 0.15 s apart, or 0.2 held). Single hits show on impact instead. Checked on WMMT5DX+ (three walls, 29 October 2026).'),
        calc('airborne', 'minw(in_race, 0.5) > 0 && maxw(spring, 0.05) < 0.01 && maxw(abs(collisions) >= 0.35 || minw(abs(collisions) > 0.001, 0.1), 0.5) == 0',
             '1 while the game holds the centring spring at 0 with no hit or wall contact in the last 0.5 s. On WMMT5DX+ that happens whenever the car goes light: jumps, and crests even where the wheels stay down. The revs jump as the driven wheels lose grip, and a joint-sized kick often comes as it lands. Checked from video: one jump (29 October 2026) and six crests (1 November 2026: two with the rear wheels off the road, revs up 1260 to 1700; four with the wheels down, revs up about 800).'),
        calc('grip_loss', 'clamp(abs(tire_slip) / 0.1, 0, 1)', 'Sliding, 0 gripping to 1: tire_slip reaches about 0.1 in slides (WMMT5DX+). No direction.'),
        calc('accel_g', 'ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g',
             'Longitudinal G from speed (speed x Max speed undoes the division, so this stays in G). Speed is in whole km/h, so this jitters by about 0.1 G when cruising. + speeding up, - slowing down.'),
    ]
    extra_notes = {'car': 'Car number.', 'power': 'Power tune level (read 0 throughout on WMMT5DX+; unconfirmed).', 'handling': 'Handling tune level.'}
    for name, (base, offs) in a.get('extra', {}).items():
        rows.append(mem(name, 'Byte', base, extra_notes[name] + src(False), offsets=offs))
    return profile(prefix, display, rows, ob, max_speed, max_revs)

P.append(wmmt('WMMT5', 'Wangan Midnight Maximum Tune 5', dict(speed='196FEBC', rpm='1970038', gear=('199A450', '398'), time='199A468', ffb='196F188',
              extra={'car': ('1948F10', '240, 2C'), 'power': ('1948F10', '240, 98'), 'handling': ('1948F10', '240, 9C')}), 'WMMT5'))
P.append(wmmt('WMMT5DX', 'Wangan Midnight Maximum Tune 5DX', dict(speed='1C0342C', rpm='1C0359C', gear=('1C2C040', '398'), time='1C2C058', ffb='1C02750'), 'WMMT5DX'))
P.append(wmmt('WMMT5DXP', 'Wangan Midnight Maximum Tune 5DX+', dict(speed='1FA7C7C', rpm='1FA7DEC', gear=('1FD11B0', '398'), time='1FD11C8', ffb='1FA6F40',
              extra={'power': ('1F7D578', '268, AC')}), 'WMMT5DXPlus', max_speed=230, max_revs=8900))   # 8900 for rpm2 (Alexis, 3 November 2026; was 8250 for rpm)
P.append(wmmt('WMMT6', 'Wangan Midnight Maximum Tune 6', dict(speed='1E3D4DC', rpm='1E3D64C', gear=('1E5B5B0', '3A8'), time='1E5B5C8', ffb='1E3C610'), 'WMMT6'))
P.append(wmmt('WMMT6R', 'Wangan Midnight Maximum Tune 6R', dict(speed='204809C', rpm='204820C', gear=('20681C0', '3AC'), time='20681D8', ffb='2047128'), 'WMMT6R'))
P.append(wmmt('WMMT6RR', 'Wangan Midnight Maximum Tune 6RR', dict(speed='1F2612C', rpm='1F2629C', gear=('20681C0', '3AC'), time='20681D8', ffb='1F25260'), None))

# More games, and rows for existing ones: MasterRaver's cheat tables, OutputBlaster-only games,
# Model 2 Emulator, Supermodel, MAME and Flycast (moregames.py, 2 November 2026).
import moregames
moregames.add(P, dict(mem=mem, calc=calc, profile=profile, hold0=hold0, force_tail=force_tail, accel=accel, MAIN=MAIN))

# ---------------------------------------------------------------- processes
# From TeknoParrotUI's GameProfiles (ExecutableName, EmulatorType) and GameSetup (GameExecutableLocation).
# Lindbergh and ElfLdr2 games run inside BudgieLoader.exe; TeknoMacaw games inside TeknoMacaw.exe; the
# rest are their own exe, which TeknoParrot or OpenParrot starts and injects.
PROC = {
    'H2OVERDRIVE': 'sdaemon.exe', 'SEGARACINGCLASSIC': 'd1a.exe', 'OUTRUN2SP': 'BudgieLoader.exe',
    'DAYTONA3': 'Daytona.exe', 'DAYTONA3NSE': 'Daytona.exe',
    'ID4': 'BudgieLoader.exe', 'ID4JP': 'BudgieLoader.exe', 'ID5': 'BudgieLoader.exe',
    'ID0V131': 'InitialD0_DX11_Nu.exe', 'ID0V211': 'InitialD0_DX11_Nu.exe', 'ID0V230': 'InitialD0_DX11_Nu.exe',
    'IDTA': 'GameProject-Win64-Shipping.exe', 'SWDC': 'Todoroki-Win64-Shipping.exe', 'KODRIVE': 'M-DriveR_RingWide.exe',
    'MKGPDX110': 'MK_AGP3_FINAL.exe', 'MKGPDX118': 'MK_AGP3_FINAL.exe', 'MKGPDXUSA': 'MK_AGP3_FINAL.exe',
    'GTICLUB3': 'gti3japkey.exe', 'RTUNED': 'BudgieLoader.exe', 'DIRTYDRIVIN': 'sdaemon.exe', 'SONICASR': 'game.exe',
    'CHASEHQ2': 'game.exe', 'WACKYRACES': 'Launcher.exe', 'SEGARACETV': 'BudgieLoader.exe', 'BG4JP': 'game.exe',
    'BATMAN': 'sdaemon.exe', 'SNOCROSS': 'sdaemon.exe', 'GRID': 'GRID.exe', 'RF3D': 'TeknoMacaw.exe',
    'CRUISNBLAST': 'BudgieLoader.exe',
    'WMMT5': 'wmn5r.exe', 'WMMT5DX': 'wmn5r.exe', 'WMMT5DXP': 'wmn5r.exe',
    'WMMT6': 'wmn6r.exe', 'WMMT6R': 'wmn6r.exe', 'WMMT6RR': 'wmn6r.exe',
    # CRAZYTAXI: not a TeknoParrot game (the FFB plugin supports the PC release), so left blank.
}
PROC.update(moregames.PROC)
# 64-bit per TeknoParrotUI (Is64Bit); the WMMT5/6 rows already say so.
BIT64_GAMES = {'ID0V131', 'ID0V211', 'ID0V230', 'IDTA', 'SWDC'} | moregames.BIT64
for p in P:
    p['ProcessName'] = PROC.get(p['Prefix'], '')
    if p['Prefix'] in BIT64_GAMES:
        for v in p['Variables']:
            if v['Source'] == 'Memory' and BIT64 not in v['Notes']:
                v['Notes'] += BIT64

# ---------------------------------------------------------------- write
import packlayout
packlayout.migrate(PACK)    # profiles from the old flat layout move into their emulator folders first
for p in P:
    d = packlayout.folder(PACK, p['Prefix'])
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, p['Prefix'] + '.json'), 'w', newline='\n') as f:
        json.dump(p, f, indent=2, ensure_ascii=False)

# speed rows for two existing shared-memory profiles
def add_rows(prefix, rows, process):
    path = packlayout.path(PACK, prefix)
    p = json.load(open(path))
    p['ProcessName'] = process
    by_name = {r['Name']: r for r in rows}
    p['Variables'] = [by_name.pop(v['Name'], v) for v in p['Variables']] + list(by_name.values())
    with open(path, 'w', newline='\n') as f:
        json.dump(p, f, indent=2, ensure_ascii=False)

add_rows('D1GP', [mem('speed', 'Float', '2150F4', "Speedometer, from the FFB plugin's reading of this game. Needs the game's Process set." + UNVERIFIED), accel()], 'game.exe')
add_rows('SRG', [mem('speed', 'Float', '10BE22D8', "Speedometer. Needs the game's Process set." + UNVERIFIED),
                 mem('racing', 'Byte', '10BD5B20', "1 during a race. Needs the game's Process set." + UNVERIFIED), accel()], 'racing.exe')

print(len(P), 'profiles written:', ' '.join(p['Prefix'] for p in P))

# Rows for hand-maintained profiles from the cheat tables (WMMT3DX+).
moregames.add_hand(PACK)

# Outputs (lamps, RPM...) read straight from game memory wherever OutputBlaster's own code is plain
# memory reads; the rest stay as OutputBlaster outputs. Also converts profiles memgames doesn't make.
import oblamps
oblamps.apply_pack(PACK)
moregames.fix_m2_lamps(PACK)   # Sega Rally's lamps live elsewhere (see moregames.py)
moregames.fix_mk118_lamps(PACK)   # OutputBlaster reads these lamp words as bytes
moregames.fix_mkusa_lamps(PACK)   # the USA version's lamps: v1.18's words, moved with its I/O block

# car_ rows: map each game's rows onto the common values (TPTelemetry.Car_*) the SimHub effects read.
import commonrows
print(commonrows.apply_pack(PACK), 'car_ rows')

# Tidy every table: merge single-use reads into the row that uses them, then order the rows (game values,
# speed/revs/gear first; calculated values; car_ rows last).
import tidytable
for k, m in tidytable.apply_pack(PACK).items(): print(k, 'merged', ', '.join(m))

# Game_Formulas.md: every game's formulas, written from the profiles so it always matches them.
import gameformulas
print(*gameformulas.main(PACK))

# Game_Setup.md: how to set up each game (index, emulator steps, what each needs), from the profiles.
import gamesetup
print(*gamesetup.main(PACK))
