"""Writes a replay fixture for the plugin's tests from one of Alexis's SWDC recordings (19 November 2026).
    python3 -I capfixture.py <recording.csv> <out.csv.gz> [from_s] [to_s] [max_speed]
Memory rows are written raw: rows recorded through a formula are worked back (speed2 x Max speed of the recording's profile,
230 by default; gear2, brake, position and class_rank were `in_race ? value : 0`, so they read 0 outside a race, as now).
revs_game is written as revs_record, position as overall and class_rank as position (renamed 19 November 2026); recordings made
with the new names are read as they are. USB columns become usb_force, usb_spring, usb_steer, usb_brake."""
import csv, gzip, sys
src, out = sys.argv[1], sys.argv[2]
t0 = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0
t1 = float(sys.argv[4]) if len(sys.argv) > 4 else 1e9
max_speed = float(sys.argv[5]) if len(sys.argv) > 5 else 230.0
MEM = ['revs', 'speed2', 'speed1', 'gear2', 'gear1', 'ver103_tag', 'ver230_tag', 'ffb_raw103', 'ffb_str103', 'ffb_raw230', 'ffb_str230',
       'player_no', 'cars', 'grid_no', 'car_state', 'kmh', 'revs_game', 'shift', 'brake', 'spark_l', 'spark_r', 'afterfire', 'position',
       'class_rank', 'lap', 'sector', 'course_point', 'lane', 'race_secs', 'time_left', 'pos_x', 'pos_y', 'pos_z', 'yaw', 'pitch', 'roll']
RENAME = {'revs_game': 'revs_record', 'position': 'overall', 'class_rank': 'position'}
USB = {'FFB_force': 'usb_force', 'FFB_spring': 'usb_spring', 'FFB_steer': 'usb_steer', 'FFB_brake': 'usb_brake'}
def fmt(v):
    if v == '': return ''
    f = float(v)
    return ('%d' % f) if f == int(f) and abs(f) < 1e15 else ('%.7g' % f)
with open(src, newline='') as fh, gzip.open(out, 'wt', newline='') as go:
    rd = csv.reader(fh); head = next(rd); col = {h: i for i, h in enumerate(head)}
    new = 'SWDC_overall' in col
    names = ['time_s', 'marker'] + [RENAME.get(m, m) for m in MEM] + ['tp_jvs%d' % i for i in range(16)] + ['tp_connected'] + list(USB.values())
    w = csv.writer(go); w.writerow(names)
    for r in rd:
        t = float(r[col['time_s']])
        if t < t0 or t > t1: continue
        row = [fmt(r[col['time_s']]), r[col['marker']]]
        for m in MEM:
            c = 'SWDC_' + (RENAME.get(m, m) if new else m)   # recordings made after the renames use the new names
            v = r[col[c]] if c in col else ''   # rows dropped since (time_left) are left blank
            if m in ('speed2', 'speed1') and v != '': v = str(float(v) * max_speed)
            row.append(fmt(v))
        row += [fmt(r[col['TP_jvs%d' % i]]) for i in range(16)] + [fmt(r[col['TP_connected']])]
        row += [fmt(r[col[k]]) for k in USB]
        w.writerow(row)
