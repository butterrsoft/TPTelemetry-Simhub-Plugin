"""Replaces game profiles' OutputBlaster output rows (formula out_<Name>) with rows that read the
game's memory directly, using obmem.translate. Run by memgames.py after it writes the pack, and on
its own for profiles memgames doesn't make:  python3 oblamps.py <pack folder>

* Each output row keeps its name and place, so SimHub properties don't change.
* No more rows than the outputs need: an output with a read of its own becomes a memory row whose
  formula works on `value`; an output that is just a read becomes a plain memory row others can use;
  only reads shared between outputs get an unticked ob_ row (just before the first output row).
  Values OutputBlaster works out on the way are written into the formulas. A read at exactly the
  address, offsets and type of an existing memory row uses that row instead.
* Re-running it redoes its own earlier conversions (recognised by their notes), so hand-maintained
  profiles pick up rule changes too.
* Outputs OutputBlaster works out with hooks, helpers or state kept between loops stay as out_ rows
  (they still need OutputBlaster), and say so in their notes.
* FFB outputs that only repeat an existing row (WMMT's FFB1-4 are tire_slip etc. x 100) are dropped.
"""
import json, os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
import obmem
import packlayout
from obnames import MAP as OB_NAMES

# profile prefix -> (OutputBlaster game file, 64-bit, process to set if the profile has none)
# Process names from TeknoParrotUI's GameSetup (GameExecutableLocation).
GAMES = {
    'ARCTICTHUNDER': ('ArcticThunder', False, 'snow.exe'),
    'BATMAN': ('batman', False, None),
    'BG4JP': ('BattleGear4Tuned', False, None),
    'CHASEHQ2': ('ChaseHQ2', False, None),
    'CRUISNBLAST': ('CruisnBlast', False, None),
    'DAYTONA3': ('DaytonaChampionshipUSA', False, None),
    'DAYTONA3NSE': ('DaytonaChampionshipUSANSE', False, None),
    'DEADHEAT': ('DeadHeat', False, 'BudgieLoader.exe'),
    'DIRTYDRIVIN': ('DirtyDrivin', False, None),
    'GRID': ('GRID', False, None),
    'GTICLUB3': ('GTIClubSuperminiFesta', False, None),
    'H2OVERDRIVE': ('H2Overdrive', False, None),
    'ID0V131': ('ID0V131', True, None),
    'ID0V211': ('ID0V211', True, None),
    'ID4': ('InitialD4', False, None),
    'ID5': ('InitialD5', False, None),
    'ID7': ('InitialD7', False, 'InitialD7_GLW_RE_SBYD.exe'),
    'ID8': ('InitialD8', False, 'InitialD8_GLW_RE_SBZZ_redumped_.exe'),
    'MKGPDX110': ('MarioKartGPDXJP1.10', False, None),
    'MKGPDX118': ('MarioKart1.18', False, None),
    'OUTRUN2SP': ('Outrun2SP', False, None),
    'RTUNED': ('R-Tuned', False, None),
    'SEGARACETV': ('SegaRaceTV', False, None),
    'SEGARACINGCLASSIC': ('SegaRacingClassic', False, None),
    'SONICASR': ('SonicAllStarsRacing', False, None),
    'SR3': ('SegaRally3', False, 'Rally.exe'),
    'SRG': ('SRG', False, None),
    'WACKYRACES': ('WackyRaces', False, None),
    'WMMT5': ('WMMT5', True, None),
    'WMMT5DX': ('WMMT5DX', True, None),
    'WMMT5DXP': ('WMMT5DXPlus', True, None),
    'WMMT6': ('WMMT6', True, None),
    'WMMT6R': ('WMMT6R', True, None),
    # added 2 November 2026 (moregames.py)
    'BG4': ('BattleGear4', False, None),
    'HARLEY': ('HarleyDavidson', False, None),
    'MOTOGP': ('MotoGP', False, None),
    'FNFDRIFT': ('FNFDrift', False, None),
    'FNFSC': ('FNFSupercars', False, None),
    'FNFSB2': ('SuperBikes2', False, None),
    'HUMMER': ('Hummer', False, None),
    'HUMMEREXTREME': ('HummerExtreme', False, None),
    'CARS': ('Cars', False, None),
    'CRAZYRIDE': ('CrazyRide', True, None),
    'M2DAYTONA': ('M2Emulator', False, None),
    'M2INDY500': ('M2Emulator', False, None),
    'M2STCC': ('M2Emulator', False, None),
    'M2OVERREV': ('M2Emulator', False, None),
    'M2SGT24H': ('M2Emulator', False, None),
    'M2SRALLY': ('M2Emulator', False, None),
}
# Left on OutputBlaster's outputs, and why.
SKIP = {
    'ID4JP': "OutputBlaster only knows the export version of Initial D 4, so these outputs have no memory addresses for this one",
    'ID6': "OutputBlaster reads different addresses for v1.0 and v1.2 and tells them apart by a checksum, so these stay as OutputBlaster's outputs",
}
FROM_MEM = " From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified."
NEEDS_OB = " Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory."
WRITES = " OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well."
SKIP_NOTE = " Needs OutputBlaster running: {}."

def safe(name): return re.sub(r'[^A-Za-z0-9_]', '_', name)

def hexs(n): return f'{n:X}' if n >= 0 else '-' + f'{-n:X}'

def mem_key(v):
    try:
        offs = tuple(int(o, 16) for o in re.split(r'[,\s]+', v['Offsets'].strip()) if o)
        return (v['Module'], int(v['BaseOffset'], 16), offs, v['Type'])
    except ValueError:
        return None

def is_copy(f):
    """Just a read, or a read scaled by a constant (WMMT's FFB1-4 are floats x 100)."""
    if f[0] == 'read': return True
    return f[0] == 'bin' and f[1] in ('*', '/') and {f[2][0], f[3][0]} == {'read', 'num'}

def unscale(f):
    """OutputBlaster sends RPM divided by 100 (10 on OutRun 2) to fit a byte for MAMEHooker. Undo that: the row gives RPM."""
    if f[0] == 'bin' and f[1] == '/' and f[3][0] == 'num' and f[3][1] in (10, 100, 10.0, 100.0):
        return f[2], int(f[3][1])
    return f, None

# Games whose RPM float is itself RPM / 10 (OutputBlaster divides it by 10 again for MAMEHooker).
# OutRun 2: idles at about 163 and tops out near 930 (Alexis's recordings, 2 November 2026).
RAW_RPM_FACTOR = {'Outrun2SP': 10}
RPM_NOTE_RAW = ("Engine RPM, read from game memory as OutputBlaster does (no OutputBlaster needed). The game stores RPM / 10 "
                "(idle about 163, top about 930 in Alexis's recordings, 2 November 2026), so this multiplies by 10. Divided by Max revs.")

RPM_NOTE = ("Engine RPM, read from game memory as OutputBlaster does (no OutputBlaster needed); OutputBlaster itself sends it "
            "divided by {}. Divided by Max revs (blank = 1, so RPM; set it to the redline to make this run 0 to 1). Unverified.")

# Games whose RPM row has been checked in a recording: the note says what was seen instead of "Unverified".
RPM_CHECKED = {'SegaRally3': " Checked in Alexis's recording of 2 November 2026 (19:22): limiter about 6930 in neutral, 5th and 6th, "
                             "7397 when overrevved on a downshift, 0 on the grid until the throttle is pressed."}

def rpm_note(game, scale):
    n = RPM_NOTE.format(scale)
    return n[:-len(' Unverified.')] + RPM_CHECKED[game] if game in RPM_CHECKED else n

def fix_rpm_rows(p):
    """Rows converted by an earlier version (rpm = ob_rpm / 100) get the same treatment: real RPM over Max revs."""
    n = 0
    for v in p['Variables']:
        m = re.fullmatch(r'(ob_\w+) / (10|100)', v.get('Formula') or '')
        if v['Name'] == 'rpm' and v['Source'] == 'Computed' and m:
            v['Formula'] = f'{m.group(1)} / max_revs'
            v['Notes'] = RPM_NOTE.format(m.group(2))
            n += 1
    return n

def is_flag(f):
    return f[0] == 'bin' and f[1] in ('==', '!=', '<', '<=', '>', '>=', '&&', '||') or f[0] == 'un' and f[1] == '!'

OUT_NOTE = re.compile(r'^(.+?) output[,:]')

def inline(f):
    """The formula with every named intermediate value written out in place, so it needs no rows of its own."""
    if not isinstance(f, tuple): return f
    if f[0] == 'var': return inline(f[2])
    if f[0] == 'read': return f
    if f[0] == 'call': return ('call', f[1], [inline(a) for a in f[2]])
    return tuple(inline(x) if isinstance(x, tuple) else x for x in f)

def was_converted(v):
    """An output row an earlier run of this script read from memory (recognised by its notes)."""
    n = v.get('Notes') or ''
    return (FROM_MEM.strip() in n or 'OutputBlaster always sends' in n or n.startswith('Engine RPM, read from game memory as OutputBlaster does'))

def unconvert(p):
    """Puts back the out_ rows (and removes the ob_ rows) an earlier run made, so a re-run with
    different rules starts from OutputBlaster's outputs again. Profiles memgames makes come fresh;
    this is for the hand-maintained ones (SR3, ID7, ID8, SRG...)."""
    rows = p['Variables']
    names = {}
    for v in rows:
        if not was_converted(v): continue
        n = v['Notes']
        ob = 'RPM' if n.startswith('Engine RPM') else OUT_NOTE.match(n).group(1)
        names[v['Name']] = ob
    if not names: return False
    for v in rows:
        if v['Name'] in names:
            v.update(Source='Computed', Type='Float', Module='', BaseOffset='0', Offsets='',
                     Formula='out_' + safe(names[v['Name']]), Notes=f'Output from OutputBlaster: {names[v["Name"]]}.')
    p['Variables'] = [v for v in rows if not (v['Name'].startswith('ob_') and not (v['Formula'] or '').startswith('out_')
                                              and 'OutputBlaster' in (v.get('Notes') or ''))]
    return True

def apply(p):
    """Turns out_ rows into rows that read memory, with no more rows than the outputs need:
    * an output that reads one value nothing else uses becomes a memory row, its formula working on
      `value` (the read);
    * an output that is just a read becomes a memory row with no formula, and other outputs using the
      same read refer to it by name;
    * only reads shared between outputs and not hosted that way get a row of their own (unticked ob_);
    * values OutputBlaster works out on the way are written into each formula, not given rows."""
    prefix = p['Prefix']
    unconvert(p)
    rows = p['Variables']
    out_rows = [(i, v) for i, v in enumerate(rows) if v['Source'] == 'Computed' and (v['Formula'] or '').startswith('out_')]
    if not out_rows: return 0
    if prefix in SKIP:
        for _, v in out_rows:
            if SKIP_NOTE.format(SKIP[prefix]) not in v['Notes']: v['Notes'] += SKIP_NOTE.format(SKIP[prefix])
        return 0
    if prefix not in GAMES: raise KeyError(f'{prefix}: which OutputBlaster game?')
    game, bits64, process = GAMES[prefix]
    res = obmem.translate(game, bits64)
    by_out = {safe(OB_NAMES[e]): (e, f) for e, f in res.outputs.items() if e in OB_NAMES}
    writes = WRITES if res.writes else ''

    existing = {}
    for v in rows:
        if v['Source'] == 'Memory':
            k = mem_key(v)
            if k: existing[k] = v['Name']
    def key(r): return (r.module, r.base, r.offsets, r.type)
    taken = {v['Name'].lower() for v in rows}
    def unique(base):
        n = base; i = 2
        while n.lower() in taken: n = f'{base}_{i}'; i += 1
        taken.add(n.lower()); return n

    # 1. what each output does
    todo, dropped, converted = [], [], 0
    for i, v in out_rows:
        e, f = by_out.get(v['Formula'][4:], (None, None))
        if f is None:
            if e == 'OutputRPM':
                # Only GRID so far: OutputBlaster works its RPM out in a hook and sends whole hundreds.
                v.update(Formula=f"{v['Formula']} * 100 / max_revs",
                         Notes="Engine RPM from OutputBlaster, which sends it in hundreds (multiplied back by 100 here). "
                               "Divided by Max revs (blank = 1, so RPM; set it to the redline to make this run 0 to 1)." + NEEDS_OB)
                continue
            if e is not None and NEEDS_OB not in v['Notes']: v['Notes'] += NEEDS_OB
            continue
        f = inline(f)
        reads = list(dict.fromkeys(obmem.reads_in(f, [])))
        if e.startswith('OutputFFB') and is_copy(f) and all(key(r) in existing for r in reads):
            dropped.append(v['Name']); continue    # only repeats rows the profile already has
        rpm_scale = None
        if e == 'OutputRPM':
            f, rpm_scale = unscale(f)
        todo.append((v, e, f, reads, rpm_scale))

    uses = {}
    for v, e, f, reads, _ in todo:
        for r in reads: uses[key(r)] = uses.get(key(r), 0) + 1
    # 2. which row holds each read
    host = {}          # read key -> output row that reads it
    for v, e, f, reads, sc in todo:      # outputs that are just a read publish the raw value: others can use them
        if f[0] == 'read' and sc is None and key(f[1]) not in existing and key(f[1]) not in host:
            host[key(f[1])] = v['Name']
    hosting = {}       # output row name -> the read it holds
    for k, n in host.items(): hosting[n] = k
    for v, e, f, reads, sc in todo:      # outputs with a read of their own
        if v['Name'] in hosting: continue
        for r in reads:
            if key(r) not in existing and key(r) not in host and uses[key(r)] == 1:
                host[key(r)] = v['Name']; hosting[v['Name']] = key(r); break
    raw_rows, ob_names = [], {}
    for v, e, f, reads, sc in todo:      # reads left over need a row of their own
        for r in reads:
            k = key(r)
            if k in existing or k in host or k in ob_names: continue
            n = unique('ob_' + (r.var or 'read').lower())
            ob_names[k] = n
            raw_rows.append(dict(Name=n, Enabled=False, Source='Memory', Type=r.type, Module=r.module, BaseOffset=hexs(r.base),
                                 Offsets=', '.join(hexs(o) for o in r.offsets), Formula='',
                                 Notes=f"Raw value OutputBlaster's {game} reads for more than one of this game's outputs; the output rows decode it. Unverified."))

    # 3. write the output rows
    first_at = None
    for v, e, f, reads, sc in todo:
        mine = hosting.get(v['Name'])
        names = {}
        for r in reads:
            k = key(r)
            names[r.key()] = 'value' if k == mine else existing.get(k) or ob_names.get(k) or host[k]
        text = obmem.text(f, names) if reads or f[0] != 'read' else ''
        if mine is not None:
            r = next(r for r in reads if key(r) == mine)
            v.update(Source='Memory', Type=r.type, Module=r.module, BaseOffset=hexs(r.base), Offsets=', '.join(hexs(o) for o in r.offsets))
            if text == 'value': text = ''
        else:
            v.update(Source='Computed', Type='Float', Module='', BaseOffset='0', Offsets='')
        if first_at is None: first_at = v['Name']
        if sc:
            if game in RAW_RPM_FACTOR:
                v.update(Formula=f'{text or "value"} * {RAW_RPM_FACTOR[game]} / max_revs', Notes=RPM_NOTE_RAW + writes)
            else:
                v.update(Formula=(text or 'value') + ' / max_revs', Notes=rpm_note(game, sc) + writes)
        elif not reads:
            v.update(Formula=text, Notes=f"{OB_NAMES[e]} output: OutputBlaster always sends {text} for this game.")
        elif text == '':
            v.update(Formula='', Notes=f"{OB_NAMES[e]} output: the raw value OutputBlaster sends." + FROM_MEM + writes)
        else:
            unit = '0 or 1' if is_flag(f) else 'the value OutputBlaster sends'
            v.update(Formula=text, Notes=f"{OB_NAMES[e]} output, {unit}." + FROM_MEM + writes)
        converted += 1

    p['Variables'] = [v for v in rows if v['Name'] not in dropped]
    if raw_rows or todo:
        if raw_rows:
            at = next(i for i, v in enumerate(p['Variables']) if v['Name'] == first_at)
            p['Variables'][at:at] = raw_rows
        if not p['ProcessName'] and process:
            p['ProcessName'] = process
    return converted

def apply_pack(pack):
    total = 0
    for f in packlayout.files(pack):
        prefix = os.path.basename(f)[:-5]
        with open(f, encoding='utf-8') as fh: p = json.load(fh)
        before = json.dumps(p, indent=2, ensure_ascii=False)
        names_before = [v['Name'] for v in p['Variables']]
        n = apply(p)
        fix_rpm_rows(p)
        gone = [x for x in names_before if x not in {v['Name'] for v in p['Variables']}]
        if gone: print(f'{prefix}: dropped {gone} (they repeat rows the profile already has)')
        after = json.dumps(p, indent=2, ensure_ascii=False)
        if after != before:
            with open(f, 'w', encoding='utf-8', newline='\n') as fh: fh.write(after)
        total += n
        if n: print(f'{prefix}: {n} outputs read from memory')
    return total

if __name__ == '__main__':
    print(apply_pack(sys.argv[1]), 'outputs in all')
