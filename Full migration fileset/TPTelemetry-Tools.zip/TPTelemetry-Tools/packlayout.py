"""Where each profile lives in the game profiles pack: one folder per emulator (Alexis, 2 November 2026),
then one folder per profile:  <pack>/<emulator>/<PREFIX>/<PREFIX>.json

* Teknoparrot: TeknoParrot games (the default).
* Flycast, MAME, Supermodel, Model 2 Emulator: games read from those emulators (prefixes FLY, MAME, SM, M2).
* PC: PC releases that aren't TeknoParrot games (Crazy Taxi).
A game TeknoParrot also runs gets a separate profile per emulator, each with that emulator's prefix.
"""
import glob, os

SUPERMODEL = {'SMDAYTONA2', 'SMDAYTO2PE', 'SMSCUD', 'SMLEMANS24', 'SMDIRTDEVILS', 'SMSRALLY2', 'SMECA'}
PC = {'CRAZYTAXI'}
GROUPS = ['Teknoparrot', 'Flycast', 'MAME', 'Model 2 Emulator', 'Supermodel', 'PC']

def group(prefix):
    if prefix.startswith('FLY'): return 'Flycast'
    if prefix.startswith('MAME'): return 'MAME'
    if prefix in SUPERMODEL: return 'Supermodel'
    if prefix.startswith('M2'): return 'Model 2 Emulator'
    if prefix in PC: return 'PC'
    return 'Teknoparrot'

def folder(pack, prefix):
    return os.path.join(pack, group(prefix), prefix)

def path(pack, prefix):
    return os.path.join(folder(pack, prefix), prefix + '.json')

def files(pack):
    """Every profile in the pack, sorted by prefix."""
    return sorted(glob.glob(os.path.join(pack, '*', '*', '*.json')), key=lambda f: os.path.basename(f))

def migrate(pack):
    """Moves profiles from the old flat layout (<pack>/<PREFIX>/) into their emulator folders."""
    import shutil
    moved = 0
    for d in sorted(os.listdir(pack)):
        src = os.path.join(pack, d)
        if d in GROUPS or not os.path.isfile(os.path.join(src, d + '.json')): continue
        dst = folder(pack, d)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if os.path.exists(dst): shutil.rmtree(dst)
        shutil.move(src, dst); moved += 1
    return moved
