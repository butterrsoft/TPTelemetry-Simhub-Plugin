"""Turns OutputBlaster's game outputs into TP Telemetry rows that read game memory directly.

OutputBlaster (Boomslangnz, GPL-3.0) gets most games' outputs (lamps, LEDs, RPM...) by reading
game memory in a function called WindowsLoop, then calling Outputs->SetValue(OutputX, expression).
This reads those functions and translates them: each read becomes a memory row (pointer chains,
module-relative and absolute addresses included), each SetValue a computed row whose formula does
what OutputBlaster's C expression does. Only facts (addresses, masks, scales) are used.

What can't be translated faithfully (code hooks, helper functions, loops, switch tables, state kept
between loops, memory writes) is reported, and the caller keeps OutputBlaster's own output for it.

    from obmem import translate
    res = translate('WMMT5DXPlus', bits64=True)
    res.outputs   -> {'LampView1': Formula AST or None, ...}  (None = can't translate)
    res.reasons   -> {'LampView1': 'why not', ...}
    res.reads     -> [Read(...), ...] referenced by the formulas
    res.writes    -> True if OutputBlaster writes game memory for this game
"""
import os, re

OB = os.path.join(os.path.dirname(__file__), '..', 'refsrc', 'ob')
MAIN = '<main>'

# ------------------------------------------------------------------ tokens
TOK = re.compile(r"""
    (?P<ws>\s+)
  | (?P<num>0[xX][0-9a-fA-F]+[uUlL]*|(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?[fFuUlL]*)
  | (?P<str>"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')
  | (?P<id>[A-Za-z_]\w*)
  | (?P<op><<=|>>=|->|::|\+\+|--|<<|>>|<=|>=|==|!=|&&|\|\||\+=|-=|\*=|/=|%=|&=|\|=|\^=|[-+*/%<>=!~&|^?:;,.(){}\[\]])
""", re.X)

def strip_comments(s):
    s = re.sub(r'/\*.*?\*/', ' ', s, flags=re.S)
    s = re.sub(r'//[^\n]*', ' ', s)
    return re.sub(r'(?m)^\s*#.*$', ' ', s)  # preprocessor lines

def tokenize(s):
    out, i = [], 0
    while i < len(s):
        m = TOK.match(s, i)
        if not m: raise SyntaxError('bad char %r' % s[i])
        i = m.end()
        if m.lastgroup != 'ws': out.append((m.lastgroup, m.group()))
    return out

# ------------------------------------------------------------------ expressions (C subset)
class Bad(Exception):
    pass

BIN_PREC = {'||': 1, '&&': 2, '|': 3, '^': 4, '&': 5, '==': 6, '!=': 6, '<': 7, '<=': 7, '>': 7, '>=': 7,
            '<<': 8, '>>': 8, '+': 9, '-': 9, '*': 10, '/': 10, '%': 10}
TYPES = {'UINT8', 'BYTE', 'uint8_t', 'INT8', 'int8_t', 'char', 'UINT16', 'uint16_t', 'INT16', 'int16_t', 'short', 'WORD',
         'UINT32', 'uint32_t', 'INT32', 'int32_t', 'int', 'DWORD', 'UINT', 'unsigned', 'signed', 'long', 'INT_PTR',
         'UINT_PTR', 'uintptr_t', 'intptr_t', 'DWORD_PTR', 'float', 'double', 'bool', 'BOOL', 'auto', 'size_t', 'const'}
INT_TYPES = TYPES - {'float', 'double', 'auto', 'const'}

class P:
    """Parser over a token list."""
    def __init__(self, toks): self.t, self.i = toks, 0
    def peek(self, k=0): return self.t[self.i + k] if self.i + k < len(self.t) else (None, None)
    def next(self): tok = self.peek(); self.i += 1; return tok
    def accept(self, v):
        if self.peek()[1] == v: self.i += 1; return True
        return False
    def expect(self, v):
        if not self.accept(v): raise SyntaxError(f'expected {v!r}, got {self.peek()[1]!r}')

    def is_cast(self):
        if self.peek()[1] != '(': return False
        j = self.i + 1; seen = False
        while j < len(self.t) and (self.t[j][1] in TYPES or self.t[j][1] == '*'): j += 1; seen = True
        return seen and j < len(self.t) and self.t[j][1] == ')'

    def expr(self, minp=0):
        if minp == 0:
            c = self.expr(1)
            if self.accept('?'):
                a = self.expr(0); self.expect(':'); b = self.expr(0)
                return ('?', c, a, b)
            return c
        left = self.unary()
        while True:
            op = self.peek()[1]
            p = BIN_PREC.get(op)
            if p is None or p < minp: return left
            self.next()
            right = self.expr(p + 1)
            left = ('bin', op, left, right)

    def unary(self):
        k, v = self.peek()
        if v in ('!', '-', '+', '~'):
            self.next(); return ('un', v, self.unary())
        if self.is_cast():
            self.next(); ty = []
            while self.peek()[1] != ')': ty.append(self.next()[1])
            self.next()
            return ('cast', ' '.join(ty), self.unary())
        return self.postfix(self.primary())

    def primary(self):
        k, v = self.next()
        if v == '(':
            e = self.expr(0); self.expect(')'); return e
        if k == 'num': return ('num', v)
        if k == 'str': return ('str', v)
        if k == 'id':
            name = v
            while self.peek()[1] in ('->', '::', '.') and self.peek(1)[0] == 'id':
                name += self.next()[1] + self.next()[1]
            if self.accept('('):
                args = []
                if not self.accept(')'):
                    while True:
                        args.append(self.expr(0))
                        if self.accept(')'): break
                        self.expect(',')
                return ('call', name, args)
            return ('id', name)
        raise SyntaxError(f'unexpected {v!r}')

    def postfix(self, e):
        if self.peek()[1] in ('[', '++', '--'): raise Bad('indexing or ++/--')
        return e

# ------------------------------------------------------------------ statements
def parse_block(p):
    """Statements until the matching '}' (the '{' already consumed)."""
    out = []
    while not p.accept('}'):
        if p.peek()[0] is None: raise SyntaxError('unterminated block')
        out.append(parse_stmt(p))
    return out

def skip_stmt(p):
    """Skips one statement whatever it is; returns its tokens."""
    start, depth = p.i, 0
    while True:
        k, v = p.next()
        if v is None: break
        if v in '({[': depth += 1
        elif v in ')}]': depth -= 1
        if depth == 0 and v == ';': break
        if depth == 0 and v == '}': break
    return p.t[start:p.i]

def parse_stmt(p):
    k, v = p.peek()
    if v == '{':
        p.next(); return ('block', parse_block(p))
    if v == ';':
        p.next(); return ('block', [])
    if v == 'if':
        p.next(); p.expect('(')
        try: c = p.expr(0)
        except (SyntaxError, Bad) as e: c = ('bad', str(e))
        p.expect(')')
        then = parse_stmt(p)
        els = parse_stmt(p) if p.accept('else') else ('block', [])
        return ('if', c, then, els)
    if v in ('for', 'while', 'switch', 'do'):
        start = p.i; p.next()
        if v != 'do':
            p.expect('('); depth = 1
            while depth:
                t = p.next()[1]
                depth += t == '('; depth -= t == ')'
        body = parse_stmt(p)
        if v == 'do': skip_stmt(p)
        return ('other', p.t[start:p.i], v)
    if v == 'return':
        skip_stmt(p); return ('block', [])
    save = p.i
    try:
        # Outputs->SetValue(OutputX, expr);
        if v == 'Outputs' and p.peek(1)[1] == '->' and p.peek(2)[1] == 'SetValue':
            p.i += 3; p.expect('(')
            name = p.next()[1]
            p.expect(',')
            e = p.expr(0); p.expect(')'); p.expect(';')
            return ('set', name, e)
        # declaration: [static] TYPE[*] name [= expr] {, name [= expr]};
        static = p.accept('static')
        if p.peek()[1] in TYPES:
            ty = []
            while p.peek()[1] in TYPES or p.peek()[1] == '*': ty.append(p.next()[1])
            decls = []
            while True:
                name = p.next()[1]
                init = p.expr(0) if p.accept('=') else None
                decls.append(('decl', ' '.join(ty), name, init, static))
                if p.accept(';'): break
                p.expect(',')
            return ('block', decls) if len(decls) > 1 else decls[0]
        if static: raise Bad('static')
        # assignment: name op= expr;
        if p.peek()[0] == 'id' and p.peek(1)[1] in ('=', '+=', '-=', '*=', '/=', '|=', '&=', '^=', '<<=', '>>='):
            name = p.next()[1]; op = p.next()[1]
            e = p.expr(0); p.expect(';')
            return ('assign', name, op, e)
    except (SyntaxError, Bad):
        pass
    p.i = save
    toks = skip_stmt(p)
    return ('other', toks, 'statement')

# ------------------------------------------------------------------ symbolic values
class Read:
    """A memory read: where (module, base, pointer offsets) and what type."""
    def __init__(self, module, base, offsets, typ, var):
        self.module, self.base, self.offsets, self.type, self.var = module, base, tuple(offsets), typ, var
    def key(self): return (self.module, self.base, self.offsets, self.type)
    def __repr__(self):
        return f"Read({self.module or 'abs'}+{self.base:X} {list(map(hex, self.offsets))} {self.type} '{self.var}')"

class Loc:
    """An address: module + base, then a pointer walked for each offset."""
    def __init__(self, module, base, offsets=()): self.module, self.base, self.offsets = module, base, tuple(offsets)
    def plus(self, n):
        if not self.offsets: return Loc(self.module, self.base + n)
        return Loc(self.module, self.base, self.offsets[:-1] + (self.offsets[-1] + n,))

UNSET = ('unset',)

def cnum(tok):
    t = tok.rstrip('uUlLfF') if not tok.lower().startswith('0x') else tok.rstrip('uUlL')
    if t.lower().startswith('0x'): return int(t, 16), True
    if re.match(r'^\d+$', t): return int(t), True
    return float(t), False

class Translator:
    READS = {'helpers->ReadByte': 'Byte', 'helpers->ReadInt32': 'Int32', 'helpers->ReadFloat32': 'Float', 'helpers->ReadIntPtr': 'ptr'}
    CONSTS = {'MaxScaleOutput': (100, True), 'true': (1, True), 'false': (0, True), 'TRUE': (1, True), 'FALSE': (0, True)}

    MATHS = {'floor': 'floor', 'ceil': 'ceil', 'abs': 'abs', 'fabs': 'abs', 'fabsf': 'abs', 'round': 'round', 'roundf': 'round',
             'sqrt': 'sqrt', 'sqrtf': 'sqrt', 'pow': 'pow', 'powf': 'pow', 'min': 'min', 'max': 'max', 'fmin': 'min', 'fmax': 'max',
             'std::min': 'min', 'std::max': 'max', 'floorf': 'floor', 'ceilf': 'ceil'}

    def __init__(self, bits64, tables=None):
        self.ptr_type = 'Int64' if bits64 else 'Int32'
        self.reads = {}
        self.tables = tables or {}   # file-local lookup functions: name -> ([(case, value)], default)
        self.versions = {}

    def named(self, name, v):
        """Wraps a worked-out value in a named node, so it becomes its own row instead of being repeated."""
        if v[0] != 'f' or v[1][0] in ('read', 'num', 'var'): return v
        n = self.versions.get(name, 0) + 1; self.versions[name] = n
        return ('f', ('var', name if n == 1 else f'{name}_{n}', v[1]), v[2])

    def read(self, loc, typ, var):
        r = Read(loc.module, loc.base, loc.offsets, typ, var)
        if r.key() not in self.reads: self.reads[r.key()] = r
        return self.reads[r.key()]

    # value forms: ('f', ast, isint) formula; ('ptr', Loc) pointer read; ('mod', name) module base; ('loc', Loc) address
    def address(self, e, env, rel):
        """Evaluates an address argument to a Loc."""
        if e[0] == 'cast': return self.address(e[2], env, rel)
        if e[0] == 'num':
            v, isint = cnum(e[1])
            if not isint: raise Bad('float address')
            return Loc(MAIN if rel else '', v)
        if e[0] == 'id':
            v = env.get(e[1])
            if v and v[0] == 'ptr': return Loc(v[1].module, v[1].base, v[1].offsets + (0,))
            if v and v[0] == 'mod': return Loc(v[1], 0)
            if v and v[0] in ('loc', 'ptrarith'): return v[1]
            raise Bad(f'address from {e[1]}')
        if e[0] == 'bin' and e[1] in ('+', '-'):
            a, b = e[2], e[3]
            if a[0] == 'num' and e[1] == '+': a, b = b, a
            if b[0] != 'num': raise Bad('address arithmetic')
            n, isint = cnum(b[1])
            if not isint: raise Bad('float address')
            if e[1] == '-': n = -n
            return self.address(a, env, rel).plus(n)
        if e[0] == 'call' and e[1].startswith('GetModuleHandle'):
            v = self.value(e, env); return Loc(v[1], 0)
        raise Bad('address form')

    def value(self, e, env):
        """Evaluates an expression to a value form."""
        k = e[0]
        if k == 'num':
            v, isint = cnum(e[1]); return ('f', ('num', v), isint)
        if k == 'id':
            if e[1] in env:
                v = env[e[1]]
                if v[0] == 'bad': raise Bad(v[1])
                return v
            if e[1] in self.CONSTS:
                v, i = self.CONSTS[e[1]]; return ('f', ('num', v), i)
            raise Bad(f'unknown name {e[1]}')
        if k == 'call':
            fn, args = e[1], e[2]
            if fn in self.READS:
                if len(args) != 2: raise Bad('read arity')
                rel = args[1][0] == 'id' and args[1][1] in ('true', 'TRUE')
                if not rel and not (args[1][0] == 'id' and args[1][1] in ('false', 'FALSE')): raise Bad('relative flag')
                loc = self.address(args[0], env, rel)
                typ = self.READS[fn]
                if typ == 'ptr': return ('ptr', loc)
                return ('f', ('read', self.read(loc, typ, None)), typ != 'Float')
            if fn in ('GetModuleHandleA', 'GetModuleHandle', 'GetModuleHandleW'):
                if len(args) == 1 and args[0][0] == 'str': return ('mod', args[0][1].strip('"'))
                raise Bad('module handle of the game itself')
            if fn in self.MATHS:
                vals = [self.asf(self.value(a, env)) for a in args]
                isint = fn in ('floor', 'ceil', 'round', 'floorf', 'ceilf', 'roundf') or all(v[2] for v in vals)
                return ('f', ('call', self.MATHS[fn], [v[1] for v in vals]), isint)
            if fn in self.tables and len(args) == 1:
                x = self.asf(self.value(args[0], env))[1]
                cases, default = self.tables[fn]
                f = ('num', default)
                for k, v in reversed(cases):
                    f = ('?', ('bin', '==', x, ('num', k)), ('num', v), f)
                return ('f', f, True)
            raise Bad(f'calls {fn}()')
        if k == 'cast':
            ty = e[1]
            if '*' in ty: raise Bad('pointer cast')
            v = self.value(e[2], env)
            if v[0] in ('ptr', 'mod', 'loc', 'ptrarith'):
                return v if ty in ('INT_PTR', 'uintptr_t', 'UINT_PTR', 'DWORD_PTR', 'intptr_t') else self.asf(v)
            f, isint = v[1], v[2]
            base = ty.replace('const', '').replace('unsigned', '').strip()
            if base in ('float', 'double'): return ('f', f, False)
            if base in ('bool', 'BOOL'): return ('f', ('bin', '!=', f, ('num', 0)), True)
            if base in ('UINT8', 'BYTE', 'uint8_t', 'char'):
                return ('f', f if isint and self.is_byte(f) else ('call', 'band', [self.trunc(f, isint), ('num', 255)]), True)
            return ('f', self.trunc(f, isint), True)
        if k == 'un':
            v = self.asf(self.value(e[2], env))
            if e[1] == '~': raise Bad('~')
            if e[1] == '!':
                inner = v[1]
                if inner[0] == 'un' and inner[1] == '!':  # !!x -> x != 0
                    return ('f', ('bin', '!=', inner[2], ('num', 0)), True)
                return ('f', ('un', '!', inner), True)
            return ('f', ('un', e[1], v[1]), v[2])
        if k == 'bin':
            op = e[1]
            if op in ('+', '-'):
                l = self.value(e[2], env)
                if l[0] in ('mod', 'loc'): return ('loc', self.address(e, env, False))
                if l[0] in ('ptr', 'ptrarith') and e[3][0] == 'num':
                    # an address if it's read from, a number if it's used in arithmetic
                    loc = self.address(e, env, False)
                    n = self.asf(self.value(e[3], env))
                    return ('ptrarith', loc, ('bin', op, self.asf(l)[1], n[1]), True)
            a = self.asf(self.value(e[2], env)); b = self.asf(self.value(e[3], env))
            both_int = a[2] and b[2]
            fa, fb = a[1], b[1]
            if op == '&': return ('f', ('call', 'band', [fa, fb]), True)
            if op == '|': return ('f', ('call', 'bor', [fa, fb]), True)
            if op == '^': return ('f', ('call', 'bxor', [fa, fb]), True)
            if op == '<<': return ('f', ('call', 'shl', [fa, fb]), True)
            if op == '>>': return ('f', ('call', 'shr', [fa, fb]), True)
            if op == '/' and both_int: return ('f', self.trunc(('bin', '/', fa, fb), False), True)
            if op in ('==', '!=', '<', '<=', '>', '>=', '&&', '||'): return ('f', ('bin', op, fa, fb), True)
            return ('f', ('bin', op, fa, fb), both_int)
        if k == '?':
            c = self.asf(self.value(e[1], env)); a = self.asf(self.value(e[2], env)); b = self.asf(self.value(e[3], env))
            return ('f', ('?', c[1], a[1], b[1]), a[2] and b[2])
        if k == 'bad': raise Bad(e[1])
        raise Bad(f'expression {k}')

    def asf(self, v):
        """A value used as a number: a pointer read becomes a read of the pointer itself."""
        if v[0] == 'f': return v
        if v[0] == 'ptrarith': return ('f', v[2], v[3])
        if v[0] == 'ptr': return ('f', ('read', self.read(v[1], self.ptr_type, None)), True)
        raise Bad('address used as a number')

    @staticmethod
    def is_byte(f): return f[0] == 'read' and f[1].type == 'Byte'
    @staticmethod
    def trunc(f, isint):
        if isint: return f
        return ('bin', '*', ('call', 'sign', [f]), ('call', 'floor', [('call', 'abs', [f])]))  # C truncates towards 0

    # ---------------------------------------------------------- statements
    def run(self, stmts, env, outs, bad_outs):
        for s in stmts: self.stmt(s, env, outs, bad_outs)

    def stmt(self, s, env, outs, bad_outs):
        k = s[0]
        if k == 'block': self.run(s[1], env, outs, bad_outs); return
        if k == 'decl':
            _, ty, name, init, static = s
            if static: env[name] = ('bad', 'kept between loops (static)'); return
            if init is None: env[name] = ('f', ('num', 0), True); return
            try:
                v = self.value(init, env)
                if v[0] == 'f' and ty.strip() in ('float', 'double'): v = ('f', v[1], False)
                elif v[0] == 'f' and any(t in INT_TYPES for t in ty.split()) and not v[2]: v = ('f', self.trunc(v[1], False), True)
                if v[0] in ('ptr', 'ptrarith') and not any(t in ('INT_PTR', 'uintptr_t', 'UINT_PTR', 'DWORD_PTR', 'intptr_t', 'auto') for t in ty.split()):
                    v = self.asf(v)
                env[name] = self.named(name, v)
            except Bad as e:
                env[name] = ('bad', str(e))
            return
        if k == 'assign':
            _, name, op, e = s
            try:
                if op != '=':
                    e = ('bin', op[:-1], ('id', name), e)
                cur = env.get(name)
                v = self.value(e, env)
                if cur and cur[0] == 'f' and v[0] == 'f' and cur[2] and not v[2]: v = ('f', self.trunc(v[1], False), True)
                env[name] = self.named(name, v)
            except Bad as ex:
                env[name] = ('bad', str(ex))
            return
        if k == 'set':
            _, out, e = s
            try:
                v = self.asf(self.value(e, env))
                outs[out] = v[1]; bad_outs.pop(out, None)
            except Bad as ex:
                outs.pop(out, None); bad_outs[out] = str(ex)
            return
        if k == 'if':
            _, c, then, els = s
            try:
                cv = self.asf(self.value(c, env))[1]
            except Bad as ex:
                cv = None; why = str(ex)
            e1, o1, b1 = dict(env), dict(outs), dict(bad_outs)
            e2, o2, b2 = dict(env), dict(outs), dict(bad_outs)
            self.stmt(then, e1, o1, b1); self.stmt(els, e2, o2, b2)
            for name in set(e1) | set(e2):
                a, b = e1.get(name), e2.get(name)
                if a is b: env[name] = a; continue
                if cv is not None and a is not None and b is not None and a[0] == 'f' and b[0] == 'f':
                    env[name] = self.named(name, ('f', ('?', cv, a[1], b[1]), a[2] and b[2]))
                else:
                    env[name] = ('bad', 'set under a condition that can\'t be translated' if cv is None else 'chosen between pointers')
            for out in set(o1) | set(o2) | set(b1) | set(b2):
                before = outs.get(out, UNSET)
                a, b = o1.get(out, UNSET), o2.get(out, UNSET)
                changed = a is not before or b is not before or out in b1 or out in b2
                if not changed: continue
                if out in b1 or out in b2 or cv is None:
                    outs.pop(out, None)
                    bad_outs[out] = b1.get(out) or b2.get(out) or ('condition: ' + why)
                    continue
                outs[out] = a if a is b else ('?', cv, a, b)
            return
        if k == 'other':
            # loops, switches, writes, calls: anything set inside can't be trusted
            toks = s[1]
            for i, (tk, tv) in enumerate(toks):
                if tk == 'id' and i + 1 < len(toks) and toks[i + 1][1] in ('=', '+=', '-=', '|=', '&=', '++', '--'):
                    env[tv] = ('bad', f'set inside a {s[2]}')
                if tv == 'SetValue' and i + 2 < len(toks):
                    out = toks[i + 2][1]
                    outs.pop(out, None); bad_outs[out] = f'set inside a {s[2]}'
            return
        raise Bad('statement ' + k)

# ------------------------------------------------------------------ formula text
def has_unset(f):
    if f is UNSET: return True
    if not isinstance(f, tuple): return False
    if f[0] == 'call': return any(has_unset(x) for x in f[2])
    return any(has_unset(x) for x in f[1:] if isinstance(x, tuple))

def set_cond(f):
    """1 where the output gets a value this loop, as a formula; follows ?: down to UNSET leaves."""
    if f is UNSET: return ('num', 0)
    if f[0] == '?':
        a, b = set_cond(f[2]), set_cond(f[3])
        if a == ('num', 1) and b == ('num', 1): return ('num', 1)
        return ('?', f[1], a, b)
    return ('num', 1)

def fill_unset(f):
    if f is UNSET: return ('num', 0)
    if f[0] == '?': return ('?', f[1], fill_unset(f[2]), fill_unset(f[3]))
    return f

def finalise(f):
    """An output OutputBlaster only sets on some loops keeps its last value: hold() does the same."""
    if not has_unset(f): return f
    return ('call', 'valid', [('call', 'hold', [fill_unset(f), set_cond(f)]), ('num', 0)])

def fmt_num(v):
    if isinstance(v, float):
        s = repr(v)
        return s[:-2] if s.endswith('.0') else s
    return str(v)

PREC = {'?': 0, '||': 1, '&&': 2, '==': 6, '!=': 6, '<': 7, '<=': 7, '>': 7, '>=': 7, '+': 9, '-': 9, '*': 10, '/': 10, '%': 10}

def text(f, names, prec=0):
    k = f[0]
    if k == 'num': return fmt_num(f[1]) if f[1] >= 0 else '(' + fmt_num(f[1]) + ')'
    if k == 'read': return names[f[1].key()]
    if k == 'var': return names[('var', f[1])]
    if k == 'call': return f[1] + '(' + ', '.join(text(a, names) for a in f[2]) + ')'
    if k == 'un': return f[1] + text(f[2], names, 11)
    if k == 'bin' and f[2][0] == 'num' and f[3][0] == 'num' and f[1] in ('+', '-', '*'):
        a, b = f[2][1], f[3][1]
        return text(('num', a + b if f[1] == '+' else a - b if f[1] == '-' else a * b), names, prec)
    if k == 'bin':
        p = PREC[f[1]]
        s = text(f[2], names, p) + ' ' + f[1] + ' ' + text(f[3], names, p + 1)
        return '(' + s + ')' if p < prec else s
    if k == '?':
        s = text(f[1], names, 1) + ' ? ' + text(f[2], names, 1) + ' : ' + text(f[3], names, 0)
        return '(' + s + ')' if prec > 0 else s
    raise ValueError(k)

def vars_in(f, acc):
    """Named values a formula uses, each after the ones it depends on."""
    if not isinstance(f, tuple): return acc
    if f[0] == 'var':
        vars_in(f[2], acc)
        if f not in acc: acc.append(f)
        return acc
    if f[0] == 'call':
        for a in f[2]: vars_in(a, acc)
        return acc
    for x in f[1:]:
        if isinstance(x, tuple): vars_in(x, acc)
    return acc

def reads_in(f, acc):
    if not isinstance(f, tuple): return acc
    if f[0] == 'read': acc.append(f[1]); return acc
    if f[0] == 'var': return reads_in(f[2], acc)
    if f[0] == 'call':
        for a in f[2]: reads_in(a, acc)
        return acc
    for x in f[1:]:
        if isinstance(x, tuple): reads_in(x, acc)
    return acc

# ------------------------------------------------------------------ per game
class Result:
    def __init__(self): self.outputs, self.reasons, self.reads, self.writes, self.hooks = {}, {}, [], False, False

def lookup_tables(src):
    """static int F(int x) { switch (x) { case K: return V; ... default: return D; } }  ->  {F: ([(K, V)...], D)}"""
    out = {}
    for m in re.finditer(r'(?:static\s+)?\w+\s+(\w+)\s*\(\s*\w+\s+(\w+)\s*\)\s*\{\s*switch\s*\(\s*\2\s*\)\s*\{(.*?)\}\s*\}', src, re.S):
        body = m.group(3)
        cases = re.findall(r'case\s+([0-9A-Fa-fxX]+)\s*:\s*return\s+(-?[0-9A-Fa-fxX]+)\s*;', body)
        d = re.search(r'default\s*:\s*return\s+(-?[0-9A-Fa-fxX]+)\s*;', body)
        rest = re.sub(r'case\s+[0-9A-Fa-fxX]+\s*:\s*return\s+-?[0-9A-Fa-fxX]+\s*;|default\s*:\s*return\s+-?[0-9A-Fa-fxX]+\s*;', '', body)
        if cases and d and not rest.strip():
            out[m.group(1)] = ([(int(k, 0), int(v, 0)) for k, v in cases], int(d.group(1), 0))
    return out

def find_function(toks, name):
    for i in range(len(toks) - 2):
        if toks[i][1] == name and toks[i + 1][1] == '(':
            j = i + 1; depth = 0
            while True:
                depth += toks[j][1] == '('; depth -= toks[j][1] == ')'; j += 1
                if depth == 0: break
            if j < len(toks) and toks[j][1] == '{': return j + 1
    return None

def translate(game, bits64):
    with open(os.path.join(OB, 'Game Files', game + '.cpp'), encoding='latin-1') as fh:
        src = strip_comments(fh.read())
    res = Result()
    res.writes = 'helpers->Write' in src
    res.hooks = bool(re.search(r'MH_CreateHook|safetyhook|injector::', src))
    toks = tokenize(src)
    start = find_function(toks, 'WindowsLoop')
    if start is None: return res
    p = P(toks); p.i = start
    body = parse_block(p)
    loop_end = p.i
    tables = lookup_tables(src)
    tr = Translator(bits64, tables)
    # outputs OutputBlaster also sets somewhere else (hooks, helpers) can't come from WindowsLoop alone
    elsewhere = set()
    for i, (k, v) in enumerate(toks):
        if v == 'SetValue' and not (start <= i < loop_end) and i + 2 < len(toks):
            elsewhere.add(toks[i + 2][1])
    env, outs, bad = {}, {}, {}
    tr.run(body, env, outs, bad)
    for name in list(outs):
        if name in elsewhere:
            outs.pop(name); bad[name] = 'also set outside WindowsLoop (hook or helper)'
    for name in elsewhere:
        if name not in bad: bad[name] = 'set outside WindowsLoop (hook or helper)'
    for name, f in outs.items():
        res.outputs[name] = finalise(f)
    for name, why in bad.items():
        res.outputs[name] = None; res.reasons[name] = why
    # name reads after the variables that hold them where possible
    for var, v in env.items():
        if v[0] == 'f' and v[1][0] == 'read' and v[1][1].var is None: v[1][1].var = var
        if v[0] == 'ptr':  # a pointer variable also used as a number
            r = tr.reads.get((v[1].module, v[1].base, v[1].offsets, tr.ptr_type))
            if r is not None and r.var is None: r.var = var
    used = []
    for f in res.outputs.values():
        if f is not None:
            for r in reads_in(f, []):
                if r not in used: used.append(r)
    res.reads = used
    vs = []
    for f in res.outputs.values():
        if f is not None: vars_in(f, vs)
    res.vars = vs
    return res

if __name__ == '__main__':
    import sys
    for g in sys.argv[1:]:
        bits = g.startswith(('WMMT', 'ID0'))
        r = translate(g, bits)
        names = {x.key(): (x.var or 'read%d' % i) for i, x in enumerate(r.reads)}
        for v in r.vars: names[('var', v[1])] = v[1]
        for v in r.vars: print(f'    var {v[1]} = {text(v[2], names)}')
        print(f'== {g}  writes={r.writes} hooks={r.hooks}')
        for x in r.reads: print('   ', x)
        for o, f in r.outputs.items():
            print(f'    {o:28s}', text(f, names) if f is not None else 'CAN\'T: ' + r.reasons[o])
