#!/usr/bin/env python3
"""Ranks Model 2 RAM candidates for speed, revs, gear, timer and more from a TPTRAM log.

    python3 m2ramscan.py TPTRAM_stcc_....txt notes.txt [--top 12]

notes.txt: one line per mark, "<mark number> <label>", labels from the test drive:
    idle             car still, foot off the gas
    rev              car still, gas held (revs up)
    shift            just after an upshift (manual)
    steady <speedo>  holding a steady speed; the speedo reading
    stopped          stopped after braking
    wall left / wall right, grass in / grass out, lap, overtake
Addresses are the game's own (0x200000 second RAM, 0x500000 work RAM). The TP Telemetry row for one:
Module <main>, Base 1AA8F4, Offsets "<address >> 16 x 0x10>, <address>" (printed for each candidate).
"""
import sys, re, struct, argparse
import numpy as np

FPS = 57.52

def load(path):
    series = {}            # offset -> ([frames], [values])
    marks = {}             # mark number -> frame
    frame, base = 0, 0
    with open(path, 'r', errors='replace') as f:
        for line in f:
            if line.startswith('# TPTRAM v1'):
                base = 0x500000          # v1 logs offsets from 0x500000
            if not line or line[0] == '#':
                continue
            p = line.split()
            if p[0] == 'F':
                frame = int(p[1])
            elif p[0] == 'M':
                marks[int(p[1])] = frame
            elif len(p) == 2:
                off, val = int(p[0], 16) + base, int(p[1], 16)
                s = series.setdefault(off, ([], []))
                s[0].append(frame); s[1].append(val)
    return series, marks, frame

def decodings(vals):
    v = np.asarray(vals, dtype=np.uint32)
    out = {
        'u32': v.astype(np.float64),
        's32': v.view(np.int32).astype(np.float64),
        'f32': v.view(np.float32).astype(np.float64),
    }
    for h, sh in (('lo', 0), ('hi', 16)):
        u = ((v >> sh) & 0xFFFF).astype(np.uint16)
        out['u16' + h] = u.astype(np.float64)
        out['s16' + h] = u.view(np.int16).astype(np.float64)
    for b in range(4):
        out['u8b%d' % b] = ((v >> (8 * b)) & 0xFF).astype(np.float64)
    return out

ADDR_ADJ = {'u32': 0, 's32': 0, 'f32': 0, 'u16lo': 0, 's16lo': 0, 'u16hi': 2, 's16hi': 2,
            'u8b0': 0, 'u8b1': 1, 'u8b2': 2, 'u8b3': 3}
CE_TYPE = {'u32': '4 Bytes', 's32': '4 Bytes', 'f32': 'Float', 'u16lo': '2 Bytes', 's16lo': '2 Bytes',
           'u16hi': '2 Bytes', 's16hi': '2 Bytes', 'u8b0': 'Byte', 'u8b1': 'Byte', 'u8b2': 'Byte', 'u8b3': 'Byte'}

def at(frames, values, f):
    i = np.searchsorted(frames, f, side='right') - 1
    return values[max(i, 0)] if len(values) else np.nan

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('log'); ap.add_argument('notes'); ap.add_argument('--top', type=int, default=12)
    a = ap.parse_args()
    series, marks, last = load(a.log)
    notes = {}
    for line in open(a.notes):
        m = re.match(r'\s*(\d+)\s+(.*\S)', line)
        if m: notes[int(m.group(1))] = m.group(2).lower()
    def mk(word):
        return [(n, marks[n], notes[n]) for n in sorted(notes) if n in marks and notes[n].startswith(word)]
    idle, rev, shifts, steady, stopped = mk('idle'), mk('rev'), mk('shift'), mk('steady'), mk('stopped')
    moving = sum(1 for v in series.values() if len(set(v[1])) > 1)
    print(f'{moving} words changed during the drive; {len(marks)} marks; {last} frames ({last / FPS:.0f} s)')
    win = int(0.8 * FPS)

    cands = {k: [] for k in ('speed', 'revs', 'gear', 'timer')}
    for off, (fr, vals) in series.items():
        if len(vals) < 3:
            continue
        fr = np.asarray(fr)
        for typ, d in decodings(vals).items():
            if not np.all(np.isfinite(d)) or np.ptp(d) == 0:
                continue
            if typ == 'f32' and (np.nanmax(np.abs(d)) > 1e7 or np.nanmax(np.abs(d)) < 1e-6):
                continue
            g = lambda f, fr=fr, d=d: at(fr, d, f)
            # tie-breaker: plausible magnitudes first (a float read as an integer runs to ~1e9), then resolution
            # Model 2 physics runs in floats, so a float that passes ranks above the same word read as integers
            nu = len(np.unique(d)) - (10**9 if np.nanmax(np.abs(d)) > 1e6 else 0) + (10**6 if typ == 'f32' else 0)
            rng = np.ptp(d)
            # speed: same low value at idle/rev/stopped, high at steady
            if idle and steady:
                lo = [g(f) for _, f, _ in idle + rev + stopped]
                hi = [g(f) for _, f, _ in steady]
                if np.ptp(lo) <= 0.02 * rng and min(abs(h - lo[0]) for h in hi) > 0.3 * rng:
                    sc = min(abs(h - lo[0]) for h in hi) / rng
                    cands['speed'].append((sc, nu, off, typ, g))
            # revs: rises from idle to rev while still; drops right after upshifts
            if idle and rev:
                di = g(rev[0][1]) - g(idle[0][1])
                if di > 0.2 * rng:
                    drops = [g(f - win) - g(f + win // 2) for _, f, _ in shifts]
                    ok = sum(1 for x in drops if x > 0.1 * rng)
                    cands['revs'].append((di / rng + ok, nu, off, typ, g))
            # gear: few distinct whole values, up by one across each upshift
            if shifts and typ[0] == 'u' and len(np.unique(d)) <= 9 and rng <= 8:
                ups = [g(f + win // 2) - g(f - win) for _, f, _ in shifts]
                ok = sum(1 for x in ups if x == 1)
                if ok >= max(1, len(shifts) - 1):
                    cands['gear'].append((ok, -nu, off, typ, g))
            # timer: falls steadily most of the time
            if len(d) > 20:
                dd = np.diff(d)
                down = np.mean(dd < 0); up = np.mean(dd > 0)
                if down > 0.6 and up < 0.1:
                    cands['timer'].append((down - up, nu, off, typ, g))

    labels = [f'{n}:{notes.get(n, "?")}' for n in sorted(marks)]
    for role, lst in cands.items():
        lst.sort(key=lambda x: (-round(x[0], 1), -x[1]))
        print(f'\n== {role}: {len(lst)} candidates')
        if not lst:
            continue
        print('address  type   CE type   TP offsets       score  | ' + ' | '.join(labels))
        for sc, _, off, typ, g in lst[:a.top]:
            o = off + ADDR_ADJ[typ]
            vals = ' | '.join(f'{g(marks[n]):.4g}' for n in sorted(marks))
            tp = f'{(o >> 16) * 16:X}, {o:X}'
            print(f'{o:06X}  {typ:6s} {CE_TYPE[typ]:8s} {tp:16s} {sc:6.2f} | {vals}')

if __name__ == '__main__':
    main()
