"""Adds the car_ rows to every profile in the pack: each maps the game's own rows onto one of the
common values the plugin publishes as TPTelemetry.Car_* (plugin 0.13.0, CommonValues.cs), so one set
of SimHub effects works for every game. Rows are unticked (they feed Car_*, not a per-game property)
and go at the end of the table. Existing car_ rows are replaced, so running it twice changes nothing.

Run by memgames.py after oblamps.py; on its own for profiles memgames doesn't make:
    python3 commonrows.py <pack folder>
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import packlayout

# The common values' row names (CommonValues.Sources in the plugin). Only these car_ rows belong to
# this script: games have rows of their own that happen to start car_ (GRID car_hit, BG4 car_contact).
COMMON = ['in_race', 'speed', 'rpm', 'gear', 'accel_g', 'impact', 'impact_side', 'wall_contact', 'road_bump',
          'rumble_strip', 'off_road', 'grip_loss', 'cornering', 'airborne', 'boost', 'vibration', 'throttle',   # throttle: plugin 0.14.0
          'rpm_frac',   # plugin 0.17.0
          'drift', 'drift_angle']   # plugin 0.18.0
EFFECTS = list(COMMON)   # the values the SimHub effects are built from
# Dashboard values (plugin 0.20.0): shown as the game gives them, so one dashboard serves every game.
DASH = ['speed_kmh', 'rev_limit_rpm', 'position', 'lap', 'laps_total', 'time_left', 'race_time', 'lap_time', 'brake', 'steer', 'gap']
COMMON += DASH
# Common lamps (plugin 0.20.0): rows lamp_<name>, published as TPTelemetry.Lamp_<name>, never tied to racing.
LAMPS = ['start', 'view', 'view1', 'view2', 'view3', 'view4', 'select_up', 'select_down', 'select_left', 'select_right', 'action',
         'leader', 'checkpoint', 'final_lap', 'shift', 'warning', 'boost', 'red', 'green', 'blue', 'white', 'marquee', 'brake']
OURS = {'car_' + n for n in COMMON} | {'lamp_' + n for n in LAMPS}

APPROX = ' Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found.'

def rows_for(p):
    have = {v['Name'] for v in p['Variables'] if v['Name'] not in OURS}
    pre = p['Prefix']
    wmmt56 = pre.startswith(('WMMT5', 'WMMT6')) and 'collisions' in have   # 6RR Plus has no force rows yet
    out = []
    def add(name, formula, note):
        assert name in COMMON, name
        out.append(dict(Name='car_' + name, Enabled=False, Source='Computed', Type='Float', Module='', BaseOffset='0', Offsets='',
                        Formula=formula, Notes=f'Common value Car_{name}: {note}'))

    # in_race
    if pre == 'ID6' and 'countdown_live' in have:   # Alexis's recording, 9 November 2026: the rolling start runs with live revs
        add('in_race', 'in_race || countdown_live', '1 while racing, and in the countdown once the engine runs (the rolling start drives '
            'the car at 170 to 185 km/h for 6 s before the race clock starts).')
    elif pre == 'BG4JP' and 'view' in have:   # Alexis's recordings, 10 November 2026: in_race stays 1 in the menus; the game froze twice
        add('in_race', 'in_race && view != 12 && race_phase <= 7 && (race_phase != 7 || live)', '1 in the countdown and the race, '
            'off from the finish line (race phase 8) and at time up (10, 11); not in the attract demo or the menus (camera 12), where '
            'the game\'s own flag can stay on with the car values frozen, nor while the game freezes.')
    elif pre == 'OUTRUN2SP' and 'racing' in have:   # from the game's own code (its `jennifer`), 11 November 2026
        add('in_race', 'racing', '1 from GO to the finish line or time up: the game\'s main sequence in GAME with no goal or time up '
            '(not in the attract mode). Checked in Alexis\'s recording of 11 November 2026 (19:06): GO to the finish line.')
    elif pre == 'WMMT3DXP' and 'race_state' in have:   # from the game's own code (its `main`), 11 November 2026
        add('in_race', 'in_race', '1 from the countdown (driver\'s view) to the finish line, off while paused: the game\'s race state '
            '(checked in Alexis\'s recording of 11 November 2026, 18:36).')
    elif pre == 'SR3' and 'player_state' in have:   # from the game's own code (Rally.exe); checked 16 November 2026
        add('in_race', 'racing', '1 from GO to the finish line: the game\'s player state is racing (3); 0 in the attract mode and '
            'menus (state 0), the intro and from the line. Checked in Alexis\'s recording of 16 November 2026 (10:24).')
    elif pre == 'GRID' and 'racing' in have:   # from GRID.exe; checked in Alexis's recording of 12 November 2026
        add('in_race', 'racing', '1 from GO to the finish line, 0 while paused, at TIME OVER, in the attract mode and menus: the '
            'race clock object\'s flags and clock (checked in Alexis\'s recording of 12 November 2026).')
    elif pre == 'FLYINITD3' and 'racing' in have:   # Alexis's recordings, 17 November 2026
        add('in_race', 'racing', '1 from GO (the car on the road and out of neutral) until the race clock stops: the finish line, '
            'time up or a pause. Checked in Alexis\'s recording of 17 November 2026 (16:57).')
    elif pre == 'SMSCUD' and 'racing' in have:   # Scud Race in Supermodel, the game's own memory (18 November 2026)
        add('in_race', 'racing || valid(grid, 0)', '1 from GO to the finish line or time up, from the rolling start\'s 3-2-1 on the '
            'Beginner courses, and on the grid before GO on Medium and Expert (where only revs and gear run: Alexis, 18 November '
            '2026). Not in the attract mode\'s demo race or the rolling start\'s camera shots. Checked in five recordings.')
    elif pre == 'SMDAYTO2PE' and 'racing' in have:   # Daytona USA 2 Power Edition in Supermodel (18 November 2026)
        add('in_race', 'racing || countdown', '1 from the start (the rolling start on Beginner, kept as Alexis asked; the grid on '
            'Advanced and Expert) to the finish line or time up; not in the attract mode. Checked in her three recordings of 18 November 2026.')
    elif pre == 'ID0V230' and 'race_loaded' in have:   # from the v2.30 exe (16 November 2026)
        add('in_race', 'in_race', '1 from GO to your finish line: the race and your car racing (state 4), not in the attract demo '
            'or a replay, and not while paused.')
    elif pre.startswith('MKGPDX') and 'racing' in have:   # Alexis's v1.18 recording, 11 November 2026
        add('in_race', 'racing', '1 from GO to the finish line (race state 6, with the FFB plugin\'s race flag).')
    elif 'in_race' in have: add('in_race', 'in_race != 0', '1 while racing.')
    elif 'playing' in have: add('in_race', 'playing', '1 during play.')
    elif 'racing' in have: add('in_race', 'racing != 0', '1 while racing.')
    elif 'game_state' in have: add('in_race', 'game_state == 22', '1 while racing (game state 22, as the FFB plugin uses it).')
    elif 'race_time' in have: add('in_race', 'race_time > 0', '1 once the race clock is running.')
    elif 'menu' in have: add('in_race', 'menu == 0', '1 outside the menus.')
    elif 'in_game' in have: add('in_race', 'in_game == 1', '1 in a race.')
    elif 'in_menu' in have: add('in_race', 'in_menu == 0', '1 outside the menus.')

    # speed, revs, gear, G
    if pre == 'WMMT5DXP' and 'speed2' in have:   # Alexis, 3 November 2026: speed2 lined up with speed in a recording
        add('speed', 'valid(speed2, speed) * max_speed', 'speed in km/h, raw, from speed2 (to a fraction, 60 times a second), or the speed row when speed2 can\'t be read.')
    elif pre == 'SWDC' and 'kmh' in have:   # the speedo's km/h from your car's record (v2.30 exe, 18 November 2026)
        add('speed', 'kmh', 'speed in km/h as the speedo shows it, from your car\'s record (checked 19 November 2026).')
    elif pre == 'SWDC' and 'speed2' in have:   # Alexis's table, 3 November 2026: speed2 and gear2 are the ones to use
        add('speed', 'speed2 * max_speed', 'speed in the game\'s units, raw (about 87 at the top; speed_kmh has the speedo\'s km/h).')
    elif pre == 'GRID' and 'wheel_speed' in have:   # the dial's speed (4 November 2026)
        add('speed', 'speed * max_speed', 'speed in km/h as the speedo shows it, raw (the speed row divides by Max speed; this undoes it).')
    elif pre == 'OUTRUN2SP' and 'speed_kmh' in have:   # the speedo (its `jennifer`), checked 11 November 2026
        add('speed', 'valid(speed_kmh, speed * max_speed)', 'speed in km/h as the speedo shows it (the game\'s own speedo value; the speed '
            'row, 0.7 km/h a unit, when it can\'t be read).')
    elif 'speed' in have: add('speed', 'speed * max_speed', 'speed in the game\'s units, raw (the speed row divides by Max speed; this undoes it).')
    if pre == 'WMMT5DXP' and 'rpm2' in have:   # Alexis, 3 November 2026: use rpm2 (wider scale than rpm; Max revs set for it)
        add('rpm', 'valid(rpm2, rpm) * max_revs', 'engine RPM, raw, from rpm2, or the rpm row when rpm2 can\'t be read.')
    elif pre == 'GRID' and 'rpm2' in have:   # two pointer chains to the same revs (Alexis's table, 4 November 2026)
        add('rpm', 'valid(rpm, rpm2) * max_revs', 'engine RPM, raw, from rpm, or rpm2 when the first chain can\'t be read.')
    elif pre == 'SWDC' and 'revs' in have: add('rpm', 'revs', 'engine RPM, raw (the table\'s revs; 0 outside a race).')
    elif 'rpm' in have: add('rpm', 'rpm * max_revs', 'engine RPM, raw (the rpm row divides by Max revs; this undoes it).')
    if pre == 'SWDC' and 'shift' in have: add('gear', 'shift', 'gear, 1 to 6, from your car\'s record (the same as the table\'s gears2).')
    elif pre == 'SWDC' and 'gear2' in have: add('gear', 'gear2', 'gear (the table\'s gears2).')
    elif 'gear' in have: add('gear', 'gear', 'gear.')
    if 'accel_g' in have: add('accel_g', 'accel_g', 'forward G (+ speeding up, - slowing down).')
    dash_rows(pre, have, out, add)
    if pre == 'OUTRUN2SP' and 'racing' in have:   # Alexis, 12 November 2026: 0 outside a race, like the effects (this game only)
        for r in out:
            if r['Name'] in ('car_speed', 'car_speed_kmh', 'car_rpm', 'car_gear', 'car_accel_g'):
                r['Formula'] = 'racing ? ' + r['Formula'] + ' : 0'
                r['Notes'] += ' 0 outside a race (attract mode, menus), as Alexis asked for this game.'

    # hits
    ffb = 'force_kick' in have
    if wmmt56 and pre == 'WMMT5DXP' and 'speed2' in have:   # harder hits feel harder (Alexis, 3 November 2026)
        add('impact', 'abs(impact) > 0 ? clamp(max(abs(impact) / 0.8, 0.5 + (maxw(valid(speed2, speed) * max_speed, 0.3) - valid(speed2, speed) * max_speed) / 120), 0, 1) : 0',
            'hits, 0 to 1: the game\'s hit (0.5 reads about 0.6), or more by the km/h lost in the last 0.3 s (0.5 + loss / 120: 68 km/h lost reads 1), whichever is bigger.')
        add('impact_side', 'sign(impact_side)', 'side of the hit, -1 left, 1 right.')
    elif wmmt56:
        add('impact', 'clamp(abs(impact) / 0.8, 0, 1)', 'hits, 0 to 1: an ordinary hit (0.5) reads about 0.6, a big crash 1.')
        add('impact_side', 'sign(impact_side)', 'side of the hit, -1 left, 1 right.')
    elif pre == 'WMMT3DXP':
        add('impact', 'max(impact > 0 ? clamp(0.6 + (-long_g_fast - 1.5) / 20, 0.6, 1) : 0, valid(hit_car, 0))', 'wall hits, 0.6 for an '
            'ordinary hit, rising to 1 the harder the car slows; car and traffic hits by the game\'s contact strength (0.25 a nudge '
            'to 1 a crash).')
        add('impact_side', 'impact_side != 0 ? impact_side : valid(car_side, 0)', 'side of the hit, -1 left, 1 right: walls from '
            'TeknoParrot\'s slot 9, car hits from its sign on car hits (Alexis\'s answers, 11 November 2026).')
    elif pre == 'OUTRUN2SP':
        if 'crash_motion' in have:   # the game's crash motion starts with the hit; the speed row only falls 0.5 s later (11 November 2026)
            add('impact', 'maxw(crash_motion && !prev(crash_motion), 0.3) ? 1 : (max(crash, wall_hit, hard_hit, valid(car_hit, 0)) > 0 ? '
                'clamp(0.5 + (-minw(g_fast, 0.3) - 10) / 70, 0.5, 1) : 0)',
                'traffic, wall and other hits, 0.5 to 1 by how hard the car slowed (checked on two recordings, 2 November 2026); 1 the '
                'moment the game starts a crash motion (a spin or flip), which comes 0.5 s before the speed row falls (11 November 2026); '
                'car hits from the game\'s own contact words too (12 November 2026).')
        else:
            add('impact', 'max(crash, wall_hit, hard_hit) > 0 ? clamp(0.5 + (-minw(g_fast, 0.3) - 10) / 70, 0.5, 1) : 0',
                'traffic, wall and other hits, 0.5 to 1 by how hard the car slowed (checked on two recordings, 2 November 2026).')
        if 'car_side' in have:   # the game's own car-hit side (12 November 2026)
            add('impact_side', 'valid(car_side, 0) != 0 ? car_side : wall_side', 'side of a hit, -1 left, 1 right: a car hit\'s side from '
                'the game\'s contact words (no USB needed; checked against the wheel force, 12 November 2026), else the wall side. '
                'With USB capture on, the plugin still fills any 0 from the wheel force.')
        else:
            add('impact_side', 'wall_side', 'side of a wall hit, -1 left, 1 right (0 when the game gives no side, and for traffic; '
                'with USB capture on, plugin 0.16.0 takes the side of those from the wheel force: the FFB plugin pushes from the side of wall and traffic hits).')
    elif pre == 'BG4JP':   # bits checked in Alexis's recording, 10 November 2026
        add('impact', 'maxw(contact && !prev(contact), 0.2)', 'the moment a wall hit or contact with another car starts (any side, '
            'front and rear included), held 0.2 s.')
        add('impact_side', 'impact_side', 'side of the contact, -1 left, 1 right.')
    elif pre == 'SWDC' and 'car_contact' in have:   # sideways jolts from the position, checked against her answers (19 November 2026)
        add('impact', 'max(contact_strength, hit ? clamp(0.5 + (maxw(speed_kmh, 0.6) - speed_kmh) / 120, 0.5, 1) : 0)', 'car contacts and wall hits: '
            'the sideways jolt (0.4 to 1) or the speed falling at more than 4 G (0.5 + km/h lost / 120, up to 1), whichever is bigger. '
            'The game\'s wheel kicks are left out: they come at slips and for show too (Alexis, 19 November 2026).')
        add('impact_side', 'contact_side', 'side of a car contact or wall hit, -1 left, 1 right, from the way the game shoves the car (right in '
            'all twelve in her race of 19 November 2026); 0 for a head-on hit.')
    elif pre == 'SWDC' and 'hit' in have:   # Alexis's recordings, 3 November 2026
        add('impact', 'max(force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0, hit ? clamp(0.5 + (maxw(speed_kmh, 0.6) - speed_kmh) / 120, 0.5, 1) : 0)',
            'hits: the speed falling at more than 4 G (walls and cars), 0.5 to 1 by the km/h lost (0.5 + loss / 120), or a big force kick, whichever is bigger.')
        if True:   # 19 November 2026: the game's sparks didn't come at her wall and car hits, so the side stays the force kick's
            add('impact_side', 'force_kick > 0.5 ? sign(force) : 0', 'side of a big force kick (+ = from the right); 0 for hits found from the speed, whose side isn\'t known.' + APPROX)
    elif pre == 'SR3':
        # From the speed (Alexis's recording, 2 November 2026): the wheel force is too busy to find hits in.
        add('impact', 'hit ? clamp(0.5 + (maxw(-delta(speed * max_speed), 0.3) - 3) / 40, 0.5, 1) : 0',
            'wall hits, 0.5 to 1 by how many mph the car lost in one game frame (3 mph 0.5, 23 mph or more 1; checked on a recording, 2 November 2026).')
        add('impact_side', 'hit_side', 'side of the hit, -1 left, 1 right, from the wheel force at the hit (a rear hit read the other side once).')
    elif pre == 'GRID':
        add('impact', 'max(abs(impact_side), car_hit)', 'wall and car hits, 0 to 1 by strength.')
        add('impact_side', 'sign(impact_side)', 'side of a wall hit, -1 left, 1 right.')
    elif pre == 'CRAZYTAXI':
        add('impact', 'max(abs(impact_side), collision)', 'wall hits and other collisions, 0 or 1.')
        add('impact_side', 'impact_side', 'side of a wall hit, -1 left, 1 right.')
    elif pre == 'M2STCC' and 'wall_hit' in have:   # Alexis's recording, 6 November 2026
        add('impact', 'max(maxw(wall_hit, 0.2), force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0)',
            'wall contacts (held 0.2 s), or a big kick in the wheel force (other hits), 0 to 1.')
        add('impact_side', '0', 'not known: the wheel force pushed the same way for left and right wall hits, so it gives no side.')
    elif pre == 'M2SRALLY' and 'hit_now' in have:   # Alexis's RAM logs and recordings, 8 November 2026
        add('impact', 'max(maxw(hit_now, 0.2) > 0 ? clamp(0.4 + maxw(hit_now, 0.2) / 200, 0.4, 1) : 0, '
                      'force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0)',
            'wall and car hits, 0.4 to 1 by the game\'s own strength (24 reads 0.5, 120 or more 1), held 0.2 s, or a big kick in the wheel force.')
        add('impact_side', 'maxw(hit_now, 0.2) > 0 ? valid(hold(sign(hit), delta(hit) != 0 && hit != 0), 0) : 0',
            'side of the hit, -1 left, 1 right (the game\'s own sign; the wheel force agreed at every wall hit in the recordings).')
    elif pre == 'M2DAYTONA' and 'hit' in have:   # Alexis's RAM log, 8 November 2026
        add('impact', 'max(maxw(delta(hit) > 0 ? hit / 15 : 0, 0.2), force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0)',
            'wall hits and side-on contact, 0 to 1 by the game\'s own strength (held 0.2 s), or a big kick in the wheel force (rear-end bumps).')
        add('impact_side', 'force_kick > 0.5 ? sign(force) : 0', 'side of a big force kick (+ = from the right); the game\'s hit value has no side.' + APPROX)
    elif pre == 'ID6' and 'wall_left' in have:   # from the v1.2 exe's event flags (8 November 2026; recording 9 November)
        add('impact', 'hit ? clamp(0.5 + (maxw(speed * max_speed, 0.3) - speed * max_speed) / 60, 0.5, 1) : 0',
            'contact with a wall, guard rail or the other car, 0.5 to 1 by the km/h lost in the last 0.3 s (0.5 + loss / 60). '
            'Checked in a recording, 9 November 2026.')
        add('impact_side', 'hit ? sign(maxw(wall_right, 0.3) - maxw(wall_left, 0.3)) : 0',
            'side of a wall or guard rail hit, -1 left, 1 right (0 for the other car, whose side the game doesn\'t give).')
    elif pre == 'FLYINITD3' and 'hit' in have:   # the game's own contact knock (Alexis's recordings and answers, 17 November 2026)
        add('impact', 'hit', 'a hard knock against a rail, wall or the other car, 0 to 1 (light touches are Car_wall_contact only).')
        add('impact_side', 'hit_side', 'side of a hard knock, -1 left, 1 right.')
    elif pre == 'SMDAYTO2PE' and 'hit' in have:   # as Scud Race (18 November 2026)
        add('impact', 'hit', 'hits, 0 to 1: 1 for a big crash (the game\'s crash timer), 0.4 to 1 touching another car, otherwise by the km/h lost touching a wall; not in a pit stop.')
        add('impact_side', 'hit_side', 'side of a hit, -1 left, 1 right: walls from the wheels, car hits from the game\'s roll command (outputs on); front-corner car hits none.')
    elif pre == 'SMSCUD' and 'hit' in have:   # the game's crash timer (18 November 2026)
        add('impact', 'hit', 'hits, 0 to 1: 1 for a big crash (the game\'s crash timer), otherwise by the km/h lost while touching a wall or another car.')
        add('impact_side', 'hit_side', 'side of a hit, -1 left, 1 right, from the touching car or the wheels against the wall (0 when not known).')
    elif pre == 'ID0V230' and 'wall_left' in have:   # the same event flags as ID6 (v2.30 exe, 16 November 2026)
        add('impact', 'hit ? clamp(0.5 + (maxw(speed * max_speed, 0.3) - speed * max_speed) / 60, 0.5, 1) : 0',
            'contact with a wall, guard rail or the other car, 0.5 to 1 by the km/h lost in the last 0.3 s (0.5 + loss / 60), as in ID6.')
        add('impact_side', 'hit ? sign(maxw(wall_right, 0.3) - maxw(wall_left, 0.3)) : 0',
            'side of a wall or guard rail hit, -1 left, 1 right (0 for the other car, whose side the game doesn\'t give).')
    elif pre == 'GTICLUB3' and 'wall_hit' in have:   # Alexis's recording, 8 November 2026; no side found
        add('impact', 'hit', 'walls and other cars, 0.5 to 1 by the km/h lost, and 1 for a full-stop crash, from the jolts the game sends its '
            'vibration motor (landings go to Car_road_bump). No side: the wheel force gave none at the walls in the recording.')
    elif pre.startswith('MKGPDX') and 'hit_race' in have:   # Alexis's v1.18 recording, 11 November 2026
        add('impact', 'max(hit_race, knocked)', 'walls, karts and items hitting you (the game\'s big shake), and being knocked about '
            'by an item (spun out, flipped or bumped up), 0 or 1.')
        if 'hit_side' in have:
            add('impact_side', 'hit_side', 'side of a hit, -1 left, 1 right, 0 not known: the way it knocks the kart sideways (Alexis\'s '
                'v1.18 recording, 11 November 2026).')
    elif 'hit' in have:
        add('impact', 'hit', 'walls, karts and items hitting you, 0 or 1.')
    elif 'crash' in have:
        add('impact', 'crash', 'crashes, 0 or 1.')
    elif ffb:
        add('impact', 'force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0', 'the biggest force kicks, 0 to 1.' + APPROX)
        add('impact_side', 'force_kick > 0.5 ? sign(force) : 0', 'side of a big kick, from the force direction (+ = from the right).' + APPROX)

    # wall contact
    if wmmt56: add('wall_contact', 'wall_contact', 'scraping a wall, -1 left, 1 right.')
    elif pre == 'CRAZYTAXI': add('wall_contact', 'wall_right > 0 ? 1 : (wall_left > 0 ? -1 : 0)', 'touching a wall, -1 left, 1 right.')
    elif pre == 'BG4JP': add('wall_contact', 'wall_touch', 'touching or scraping a wall, -1 left, 1 right.')
    elif pre == 'WMMT3DXP': add('wall_contact', 'wall_contact', 'scraping along a wall, -1 left, 1 right.')
    elif pre in ('ID6', 'ID0V230', 'FLYINITD3') and 'wall_contact' in have: add('wall_contact', 'wall_contact', 'scraping along a wall or guard rail, -1 left, 1 right.')
    elif pre == 'SMDAYTO2PE' and 'wall_contact' in have:   # as Scud Race (18 November 2026)
        add('wall_contact', 'wall_contact', 'touching or scraping a wall, -1 left, 1 right: the wheels on that side are off the road\'s strip.')
    elif pre == 'SMSCUD' and 'wall_contact' in have:   # wheels off the road's strip (18 November 2026)
        add('wall_contact', 'wall_contact', 'touching or scraping a wall, -1 left, 1 right: the wheels on that side are off the road\'s strip. To check against Alexis\'s video.')

    # road surface
    if wmmt56: add('road_bump', 'clamp(road_joint / 0.3, 0, 1)', 'expansion joints and bumps, 0 to 1.')
    elif 'road_bump' in have: add('road_bump', 'road_bump', 'expansion joints and bumps, 0 to 1.')
    # SR3's force kicks are road texture and steering all the time (a recording, 2 November 2026): no road bump.
    # An explicit 0 row, so the plugin (0.15.0) doesn't fill it from the USB force instead.
    if pre == 'SR3': add('road_bump', '0', 'none: the wheel force is steering and road texture all the time (Sega Rally 3 recording, 2 November 2026). '
                         'The 0 row also stops the plugin working it out from the USB force.')
    # GRID's FFB plugin (Custom mode) sends only hits, gear changes and kerb sines (a recording, 3 November 2026): the USB
    # force would read gear changes as bumps and hits as cornering, so both are explicit 0 rows.
    elif pre == 'GRID': add('road_bump', '0', 'none: the wheel force is only hits, gear changes and kerbs (GRID recording, 3 November 2026; kerbs are in Car_off_road). '
                            'The 0 row also stops the plugin working it out from the USB force, which would read each gear change as a bump.')
    # GTI Club's wheel force is worked out from an angle (steering or slip), and rough surfaces come through the vibration,
    # so force kicks would be steering changes, not bumps (from the game's code, 8 November 2026; to be checked in a recording).
    elif pre in ('ID6', 'ID0V230') and 'road_joint' in have:
        add('road_bump', 'max(maxw(road_joint, 0.15) * 0.6, landing)', 'road joints (0.6, held 0.15 s) and landings (1 for 0.25 s), '
            'from the events the game plays their sounds from.')
    elif pre == 'GTICLUB3' and 'landing' in have:
        add('road_bump', 'landing', 'landings after a jump, 1 for 0.25 s, from the game\'s landing jolt (13 out of 13 in Alexis\'s recording, '
            '8 November 2026). The wheel force is worked out from an angle (steering or slip), so the plugin must not read bumps from it.')
    elif pre.startswith('MKGPDX') and 'hop_landed' in have:   # the wheel force here is the slide, not the road (11 November 2026)
        add('road_bump', 'max(landed, hop_landed * 0.5)', 'landing from the air (1) or from a drift hop (0.5). The wheel force is the '
            'kart\'s slide, so force kicks are no road bumps.')
    elif ffb and pre != 'SR3': add('road_bump', 'force_kick <= 0.5 ? force_kick * 2 : 0', 'small force kicks (bumps, joints), 0 to 1.' + APPROX)
    if pre == 'SWDC' and 'kerb' in have: add('rumble_strip', 'kerb', 'on a solid kerb (the game\'s long-period vibration; painted kerbs give nothing).')
    elif 'rumble_strip' in have: add('rumble_strip', 'rumble_strip', '1 on a ripple strip.')
    elif pre == 'GTICLUB3' and 'kerb' in have: add('rumble_strip', 'kerb', 'wheels on a kerb, 0 to 1 (a quarter per wheel).')
    if pre == 'SWDC' and 'verge' in have:   # the game's short-period vibration pulses (19 November 2026)
        add('off_road', 'verge', 'on the grass verge (the game\'s short-period vibration pulses).')
    elif pre == 'FLYINITD3' and 'gutter' in have:   # Alexis, 17 November 2026: gutters are driven in, not only hit
        add('off_road', 'gutter', 'a wheel in a gutter or on a kerb (surface codes 18, 32, 48, 49).')
    for src, note in (('off_road', 'off the road'), ('rough_ground', 'on rough ground'), ('rough', 'on rough ground'), ('road_rumble', 'surface rumble, 0 to 1')):
        if src in have:
            add('off_road', src, note + '.'); break

    # handling
    if pre.startswith('MKGPDX') and 'drift_strength' in have:
        add('grip_loss', 'max(drift_strength, spin)', 'sliding: the drift (0 to 1), or 1 in a spin-out.')
    elif pre in ('SMSCUD', 'SMDAYTO2PE', 'SWDC') and 'drift' in have:   # no slip value of its own (18 November 2026)
        add('grip_loss', 'drift', 'sliding: follows Car_drift (0 to 1), as the game gives no slip value of its own.')
    elif pre == 'OUTRUN2SP' and 'drift_angle' in have:
        pass   # no grip_loss row: the plugin falls back to Car_drift (graded), not the 0/1 drift flag
    elif pre == 'BG4JP' and 'drift' in have and 'wheelspin' in have:   # 10 November 2026
        add('grip_loss', 'max(drift, wheelspin)', 'sliding: the drift (0 to 1) or wheelspin (1), whichever is bigger.')
    else:
        for src, note in (('grip_loss', 'sliding, 0 to 1'), ('skid', 'skidding, 0 to 1'), ('drift', 'drifting, 0 or 1'),
                          ('wheelspin', 'wheelspin, 0 or 1')):
            if src in have:
                add('grip_loss', src, note + '.'); break
    # drifting (plugin 0.18.0): Car_drift, and Car_grip_loss for games with no slip value of their own
    if pre.startswith('MKGPDX') and 'drift_strength' in have:   # Alexis's v1.18 recording, 11 November 2026
        add('drift', 'drift_strength', 'drifting, 0 to 1: the drift angle with ID6\'s weighting while the game\'s drift flag is on.')
        add('drift_angle', 'drift_angle', 'the drift angle in degrees, + pointing right of the kart\'s path (a right-hand drift), - left.')
    elif 'drift' in have and pre.startswith('MKGPDX'): add('drift', 'drift', 'drifting, 0 or 1 (the game\'s drift flag).')
    if pre == 'WMMT3DXP' and 'drift_angle' in have:   # the game's own slip angle (its `main`, 11 November 2026)
        # Started from ID6's weighting (Alexis, 10 November 2026); WMMT's slides are shallower, so it may need easing once recorded.
        add('drift', '(1 - pow(1 - clamp((abs(drift_angle) - 5) / 45, 0, 1), 2)) * sqrt(clamp((speed * max_speed - 20) / 80, 0, 1))',
            'drifting, 0 to 1: the game\'s slip angle with ID6\'s weighting (nothing under 5 degrees or 20 km/h; full at 50 degrees and '
            '100 km/h). WMMT\'s slides are shallower than Initial D\'s, so this may read low: to tune after a recording.')
        add('drift_angle', 'drift_angle', 'the slip angle in degrees, + a right-hand drift (confirmed, 11 November 2026).')
    if pre == 'OUTRUN2SP' and 'drift_angle' in have:   # the game's rear-tyre slip angle (its `jennifer`, 11 November 2026)
        # OutRun 2's drifts run 60 to 78 degrees, so full strength is at 75 here (Alexis, 11 November 2026); other games keep 50.
        add('drift', '(1 - pow(1 - clamp((abs(drift_angle) - 5) / 70, 0, 1), 2)) * sqrt(clamp((speed_kmh - 20) / 80, 0, 1))',
            'drifting, 0 to 1: the rear tyres\' slip angle with ID6\'s curve stretched for OutRun\'s deeper drifts (nothing under 5 '
            'degrees or 20 km/h; full at 75 degrees and 100 km/h; Alexis, 11 November 2026, for this game only).')
        add('drift_angle', 'drift_angle', 'the rear tyres\' slip angle in degrees, + a right-hand drift (confirmed 11 November 2026; 0 under 10 km/h).')
    if pre == 'BG4JP' and 'drift_angle' in have:   # Alexis's 20:58 recording, 10 November 2026: heading against travel direction
        add('drift', 'drift', 'drifting, 0 to 1: the drift angle with ID6\'s weighting (nothing under 5 degrees or 20 km/h; full at 50 '
            'degrees and 100 km/h).')
        add('drift_angle', 'drift_angle', 'the drift angle in degrees, + pointing right of the car\'s path (a right-hand drift), - left.')
    if pre == 'ID6' and 'drift_angle' in have:   # from the v1.2 exe's physics; checked in two drifting recordings (9 November 2026)
        # Alexis, 10 November 2026: more weight on the angle, a little less on the speed. The angle part eases out (x(2 - x), so
        # it climbs fast through the mid angles) and the speed part is a square root, full from 100 km/h.
        add('drift', '(1 - pow(1 - clamp((abs(drift_angle) - 5) / 45, 0, 1), 2)) * sqrt(clamp((speed * max_speed - 20) / 80, 0, 1))',
            'drifting, 0 to 1: the drift angle part (nothing under 5 degrees, as ordinary cornering stays under about 7; climbing fast '
            'through the mid angles to full at 50, Alexis\'s extreme drifts) times the speed part (nothing under 20 km/h, then a square '
            'root up to full at 100 km/h). Alexis, 10 November 2026: a gentle drift at 134 km/h reads about 0.5, a moderate hairpin at '
            '73 km/h about 0.75, an extreme hairpin at 74 km/h about 0.8. With no slip value of its own, ID6\'s Car_grip_loss follows it.')
        add('drift_angle', 'drift_angle', 'the drift angle in degrees, + pointing right of the car\'s path (a right-hand drift), - left.')
    if pre == 'FLYINITD3' and 'drift' in have:   # heading against travel; Alexis's drift recording, 17 November 2026 (19:33)
        add('drift', 'drift', 'drifting, 0 to 1: ID6\'s weighting made full at 45 degrees, so her hardest drifts read about 0.62 '
            '(Alexis: 0.6 to 0.65, in line with the other Initial D games); not raised by a rail contact. With no slip value of its '
            'own, Car_grip_loss follows it.')
        add('drift_angle', 'drift_angle', 'the drift angle in degrees, + pointing right of the car\'s path (a right-hand drift), - left.')
    if pre == 'SWDC' and 'drift_angle' in have:   # heading against travel from your car's record (v2.30 exe, 18 November 2026)
        add('drift', 'drift', 'drifting, 0 to 1: ID6\'s weighting to start with (nothing under 5 degrees or 20 km/h; full at 50 degrees '
            'and 100 km/h). With no slip value of its own, Car_grip_loss follows it. To tune by feel.')
        add('drift_angle', 'drift_angle', 'the drift angle in degrees, + pointing right of the car\'s path (a right-hand drift), - left. The sign is to check.')
    if pre == 'SMDAYTO2PE' and 'drift' in have:   # Scud Race's scale (18 November 2026)
        add('drift', 'drift', 'drifting, 0 to 1: from 10 degrees, eased, full at 82 (her three points: about 0.45 at 26 to 30, 0.8 at 64, 1 at 82), times the speed part.')
        add('drift_angle', 'drift_angle', 'the drift angle in degrees, + pointing right of the car\'s path (a right-hand drift), - left.')
    if pre == 'SMSCUD' and 'drift' in have:   # heading against travel, as Initial D 3 (18 November 2026)
        add('drift', 'drift', 'drifting, 0 to 1: straight from 14 to 58 degrees (Alexis\'s two F40 drifts: 0.9 at 53.5 degrees, 0.65 '
            'at 42.5), times the speed part; 0 going backwards.')
        add('drift_angle', 'drift_angle', 'the drift angle in degrees, + pointing right of the car\'s path (a right-hand drift), - left.')
    if pre == 'ID0V230' and 'drift_angle' in have:   # from the v2.30 exe's physics (16 November 2026): ID6's weighting
        # Alexis, 10 November 2026: start every other Initial D game's drift from ID6's curve.
        add('drift', '(1 - pow(1 - clamp((abs(drift_angle) - 5) / 45, 0, 1), 2)) * sqrt(clamp((speed * max_speed - 20) / 80, 0, 1))',
            'drifting, 0 to 1: the drift angle with ID6\'s weighting (nothing under 5 degrees or 20 km/h; full at 50 degrees and '
            '100 km/h). With no slip value of its own, Car_grip_loss follows it.')
        add('drift_angle', 'drift_angle', 'the drift angle in degrees, + pointing right of the car\'s path (a right-hand drift), - left.')
    if pre == 'WMMT3DXP': add('cornering', 'clamp(cornering, -1, 1)', 'cornering load from the wheel force, + turning right.')
    elif wmmt56: add('cornering', 'clamp(-tire_slip / 0.1, -1, 1)', 'cornering from tyre slip, + turning right.' + ' Approximate: WMMT5/6 send no cornering force.')
    elif pre == 'OUTRUN2SP': add('cornering', '0', "none: the FFB plugin's hook sends OutRun 2 no steering force, only hits, sand and rough ground, "
                                 "and a small sine at gear changes (a recording with USB capture, 3 November 2026). The 0 row also stops the plugin "
                                 "working it out from the USB force, which would read a hit as cornering.")
    elif pre == 'GRID': add('cornering', '0', 'none: the FFB plugin sends GRID no cornering force (a recording, 3 November 2026). '
                            'The 0 row also stops the plugin working it out from the USB force, which would read a wall hit as cornering.')
    elif pre == 'FLYINITD3' and 'steer' in have:   # as Initial D Zero (17 November 2026): weak game force, and outputs optional
        add('cornering', 'clamp(ema(steer, 0.1) / 0.8 * sqrt(clamp(speed * max_speed / 120, 0, 1)), -1, 1)',
            'cornering from the steering and speed, + turning right, as Initial D Zero: the steering (0.8 reads full) times the '
            'square root of the speed (full from 120 km/h). Hard bends read 0.6 to 1 in Alexis\'s recordings of 17 November 2026. '
            'Doesn\'t need Flycast\'s outputs; the game\'s own wheel force is weak.')
    elif pre == 'SMDAYTO2PE' and 'steer' in have:   # as Scud Race (18 November 2026)
        add('cornering', 'clamp(ema(steer, 0.1) / 0.8 * sqrt(clamp(speed * max_speed / 120, 0, 1)), -1, 1)',
            'cornering from the steering and speed, + turning right, as Scud Race. A starting point.')
    elif pre == 'SMSCUD' and 'steer' in have:   # the game's own steering (Alexis's recordings, 18 November 2026), as Initial D 3
        add('cornering', 'clamp(ema(steer, 0.1) / 0.8 * sqrt(clamp(speed * max_speed / 120, 0, 1)), -1, 1)',
            'cornering from the steering and speed, + turning right, as Initial D 3: the steering (0.8 reads full) times the square '
            'root of the speed (full from 120 km/h). Doesn\'t need Supermodel\'s outputs. A starting point.')
    elif pre == 'ID0V230' and 'steer' in have:   # Alexis, 16 November 2026: the game's wheel force is weak, so not from it
        add('cornering', 'clamp(ema(steer, 0.1) / 0.3 * sqrt(clamp(speed * max_speed / 120, 0, 1)), -1, 1)',
            'cornering from the steering and speed, + turning right: the physics\' steering (which the game already eases with '
            'speed; 0.3 reads full) times the square root of the speed (full from 120 km/h). Hard bends read 0.6 to 0.9 in Alexis\'s '
            'recordings of 16 November 2026, the game\'s own wheel force only about 0.3.')
    elif 'force_smooth' in have: add('cornering', 'clamp(force_smooth, -1, 1)', 'sustained wheel force, + turning right.' + APPROX)
    if pre.startswith('MKGPDX') and 'airborne' in have:
        add('airborne', 'airborne', '1 in the air for more than 0.1 s (kite glides and jumps; not drift hops or ripple-strip logs).')
    elif pre == 'WMMT3DXP' and 'load' in have:   # the game's own tyre load (its `main`), checked 11 November 2026
        add('airborne', 'airborne ? 1 : (light ? 0.3 : 0)', '1 in the air (0.25 s with almost no load on the tyres), 0.3 while the '
            'car is light over a crest (Alexis: a light effect there, 11 November 2026).')
    elif pre == 'OUTRUN2SP' and 'crash_air' in have:   # crash motions (Alexis, 11 November 2026)
        add('airborne', 'crash_air', '1 through a flipping crash, 0.5 as a rear-end crash lifts the rear wheels (the game\'s crash motions).')
    elif pre == 'SMSCUD' and 'airborne' in have:   # free fall in move_y (Alexis's jump marks, 18 November 2026)
        add('airborne', 'airborne ? 1 : (valid(light, 0) ? 0.5 : 0)', '1 in the air (the car falling freely: Alexis\'s jump marks in '
            'three recordings, 18 November 2026), 0.5 going light over a crest (the front wheels lifting).')
    elif 'airborne' in have: add('airborne', 'airborne', '1 in the air (a guess so far).')
    elif 'on_ground' in have: add('airborne', 'on_ground == 0', '1 with the kart off the ground.')
    if pre == 'RTUNED': add('boost', 'clamp(boost / 0.64, 0, 1)', 'boost, 0 to 1.')
    elif pre == 'WMMT3DXP' and 'turbo_max' in have:   # from the game's own code, 11 November 2026
        add('boost', 'turbo_max > 0 ? clamp(turbo / turbo_max, 0, 1) : 0', "turbo boost, 0 to 1: the boost over this car's full boost "
            '(0.6 to 1.5 bar by tuning), 0 off the throttle. Not yet checked in a recording.')
    elif pre == 'WMMT5DXP' and 'turbo' in have:   # Alexis, 3 November 2026
        add('boost', 'clamp(turbo / 1.5, 0, 1)', 'turbo boost, 0 to 1: the gauge reads 1.5 at full boost (1), dips at each upshift and drops below 0 off the throttle (0).')
    elif 'boost' in have: add('boost', 'boost', 'boost, 0 or 1.')
    if pre == 'SWDC' and 'vibration' in have:   # the game sends 0.016 to 0.11 (verges, wall grinds): scaled so 0.1 is full
        add('vibration', 'clamp(vibration / 0.1, 0, 1)', "the game's own vibration command, scaled: it sends 0.016 to 0.11 on verges and grinding along walls (more the faster you go), so 0.1 reads 1.")
    elif pre == 'ID6' and 'vibration' in have:   # Alexis's recording, 9 November 2026
        add('vibration', 'clamp(vibration / 0.15, 0, 1)', "the game's own vibration command, scaled: it sends 0.16 (20 of 127) as a wheel "
            "drops into or out of the gutter, 0.06 pulses while scraping a wall and 0.04 at contact with the other car, so 0.15 and over reads 1.")
    elif 'vibration' in have: add('vibration', 'vibration', "the game's own vibration command, 0 to 1.")
    elif 'vibration_on' in have: add('vibration', 'vibration_on', "1 while the game asks for vibration.")
    if pre == 'WMMT3DXP' and 'rpm_frac' in have:   # the game's own rev rate (its `main`, 11 November 2026)
        add('rpm_frac', 'rpm_frac', "revs as a fraction of this car's own limiter, as the game's tacho works it out: the rev limiter "
            'and engine effects follow every car (plugin 0.17.0; older plugins use revs / Max revs). Not yet checked in a recording.')
    if pre == 'GRID' and 'rev_frac' in have:   # the dial's needle (Alexis's table, 4 November 2026): each car's own limiter
        add('rpm_frac', 'rev_frac', "revs as a fraction of this car's limiter (6500 to 8200 by car): the rev limiter and engine effects follow every car (plugin 0.17.0; older plugins use revs / Max revs).")
    if pre == 'GRID' and 'throttle' in have:
        add('throttle', 'throttle', 'throttle, 0 to 1, as the game uses it: the engine effects run at 60% off the throttle, full at full throttle.')
    if pre in ('ID6', 'ID0V230') and 'throttle' in have:
        add('throttle', 'throttle', 'throttle, 0 to 1: the engine effects run at 60% off the throttle, full at full throttle.')
    if pre == 'SMDAYTO2PE' and 'rpm_frac' in have:   # each car class's limiter (Alexis's recordings, 18 November 2026)
        add('rpm_frac', 'rpm_frac', "revs as the rev counter shows them, as a fraction of this car's rev limit (EASY and SPECIAL 7650, NORMAL and HARD 8500), so "
            'the rev limiter and engine effects reach full on every car.')
    if pre == 'SMSCUD' and 'rpm_frac' in have:   # each car's limiter (Alexis's recordings, 18 November 2026)
        add('rpm_frac', 'rpm_frac', "revs as a fraction of this car's rev limit (7200 Porsche and Viper, 8500 McLaren, 9000 F40), so "
            'the rev limiter and engine effects follow every car.')
    if pre == 'SMDAYTO2PE' and 'throttle' in have:
        add('throttle', 'throttle', 'throttle, 0 to 1, as the game uses it: the engine effects run at 60% off the throttle, full at full throttle.')
    if pre == 'SMSCUD' and 'throttle' in have:   # the game's own throttle (18 November 2026)
        add('throttle', 'throttle', 'throttle, 0 to 1, as the game uses it: the engine effects run at 60% off the throttle, full at full throttle.')
    if pre == 'FLYINITD3' and 'throttle' in have:   # Alexis's recordings, 17 November 2026
        add('rpm_frac', 'rpm_frac', "revs as a fraction of this car's own rev limit (9000 Civic and GT-R, 7000 RX-7), so the rev limiter "
            'and engine effects follow every car.')
        add('throttle', 'throttle', 'throttle, 0 to 1 (follows the pedal over USB): the engine effects run at 60% off the throttle, full at full throttle.')
    if pre == 'WMMT3DXP' and 'throttle' in have:   # from the game's own code, 11 November 2026
        add('throttle', 'clamp(throttle, 0, 1)', 'throttle pedal, 0 to 1, as the game uses it: the engine effects run at 60% off the '
            'throttle, full at full throttle. Not yet checked in a recording.')
    if pre == 'WMMT5DXP' and 'throttle' in have:   # plugin 0.14.0: the engine effects follow the throttle (Alexis, 3 November 2026)
        add('throttle', 'throttle', 'throttle pedal, 0 to 1 (checked against the G25 over USB): the engine effects run at 60% off the throttle, full at full throttle.')
    # Alexis, 16 November 2026: "zero all race data when not in game; only FFB and lamps should work in menus" (Sega Rally 3, and
    # GRID with its new race rows). Every common value but Car_in_race reads 0 outside a race.
    if pre in ('SR3', 'GRID') and 'racing' in have:
        for r in out:
            if r['Name'] != 'car_in_race' and r['Formula'] != '0':
                r['Formula'] = f"racing ? ({r['Formula']}) : 0"
                r['Notes'] += ' 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026).'
    if pre == 'SWDC' and 'in_race' in have:   # Alexis, 19 November 2026: everything stops outside the race (rolling start to the line)
        for r in out:
            if r['Name'] != 'car_in_race' and r['Formula'] != '0':
                r['Formula'] = f"in_race ? ({r['Formula']}) : 0"
                r['Notes'] += ' 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026).'
    if pre == 'FLYINITD3' and 'racing' in have:   # and for Initial D 3 in Flycast (17 November 2026)
        for r in out:
            if r['Name'] != 'car_in_race' and r['Formula'] != '0':
                r['Formula'] = f"racing ? ({r['Formula']}) : 0"
                r['Notes'] += ' 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026).'
    if pre == 'SMSCUD' and 'racing' in have:   # and for Scud Race in Supermodel (18 November 2026)
        for r in out:
            if r['Name'] in ('car_rpm', 'car_rpm_frac', 'car_gear', 'car_rev_limit_rpm'):   # revs and gear on the grid too (Alexis, 18 November 2026)
                r['Formula'] = f"racing || valid(grid, 0) ? ({r['Formula']}) : 0"
                r['Notes'] += ' 0 outside a race (attract mode, menus, after the line), but running on the grid before GO.'
            elif r['Name'] == 'car_throttle':   # Alexis, 18 November 2026: on the grid the engine follows the revs alone
                r['Formula'] = f"racing ? ({r['Formula']}) : (valid(grid, 0) ? 1 : 0)"
                r['Notes'] += ' 0 outside a race; 1 on the grid, so the engine effects follow the revs alone there (Alexis, 18 November 2026).'
            elif r['Name'] != 'car_in_race' and r['Formula'] != '0':
                r['Formula'] = f"racing ? ({r['Formula']}) : 0"
                r['Notes'] += ' 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026).'
    if pre == 'SMDAYTO2PE' and 'racing' in have:   # Daytona USA 2 Power Edition (18 November 2026)
        for r in out:
            if r['Name'] == 'car_throttle':   # Alexis, 18 November 2026: on the grid the engine follows the revs, as Scud Race
                r['Formula'] = f"racing ? ({r['Formula']}) : (countdown ? 1 : 0)"
                r['Notes'] += ' 0 outside a race; 1 on the grid and in the rolling start, so the engine effects follow the revs alone there (Alexis, 18 November 2026).'
            elif r['Name'] != 'car_in_race' and r['Formula'] != '0':
                r['Formula'] = f"racing || countdown ? ({r['Formula']}) : 0"
                r['Notes'] += ' 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start.'
    if pre == 'ID0V230' and 'race_loaded' in have:   # the same for Initial D Zero, its rows being new (16 November 2026)
        for r in out:
            if r['Name'] != 'car_in_race' and r['Formula'] != '0':
                r['Formula'] = f"in_race ? ({r['Formula']}) : 0"
                r['Notes'] += ' 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026).'
    lamp_rows(pre, have, out)
    return out

# Speed units (plugin 0.20.0, Car_speed_kmh and Car_speed_mph): games whose car_speed is km/h, and Sega Rally 3's mph.
KMH = {'WMMT5': 'km/h (the FFB Arcade Plugin\'s reading, checked on WMMT5DX+)', 'WMMT5DX': 'km/h (checked on WMMT5DX+)',
       'WMMT5DXP': 'km/h (checked)', 'WMMT6': 'km/h (as WMMT5DX+; not yet checked)', 'WMMT6R': 'km/h (as WMMT5DX+; not yet checked)',
       'WMMT6RR': 'km/h (as WMMT5DX+; not yet checked)', 'WMMT3DXP': 'km/h (the game\'s own speed)', 'OUTRUN2SP': 'km/h (the speedo)',
       'SWDC': 'km/h (the speedo)', 'GRID': 'km/h (the speedo)', 'BG4JP': 'km/h (the speedo)', 'M2DAYTONA': 'km/h (the speedo)',
       'M2SRALLY': 'km/h (about 1% under the speedo)', 'M2STCC': 'km/h', 'SMSCUD': 'km/h (the screen)', 'SMDAYTO2PE': 'km/h (the screen)',
       'GTICLUB3': 'km/h (the speedo, even with the display in mph)', 'ID6': 'km/h (the speedo)', 'ID0V230': 'km/h (the speedo)',
       'FLYINITD3': 'km/h (the speedo)', 'IDTA': 'probably km/h (not yet checked)', 'IDTAS5': 'probably km/h (not yet checked)',
       'MKGPDX110': 'the game\'s own units, taken as km/h (a kart has no speedo)', 'MKGPDX118': 'the game\'s own units, taken as km/h (a kart has no speedo)',
       'MKGPDXUSA': 'the game\'s own units, taken as km/h (a kart has no speedo)'}
MPH = {'SR3': 'mph as the screen shows it'}

def dash_rows(pre, have, out, add):
    """The dashboard values (plugin 0.20.0): speed in km/h, the car's rev limit, position, laps, clocks, pedals, steering and the
    gap to a rival, each in one agreed unit, so one SimHub dashboard serves every game. Added before the games' race gating, so a
    game whose values read 0 outside a race (Alexis's wish for SR3, GRID, SWDC and the emulator games) does the same here."""
    def has(*names): return all(n in have for n in names)
    spd = next((r for r in out if r['Name'] == 'car_speed'), None)
    if spd and pre in KMH:
        add('speed_kmh', spd['Formula'], f'speed in km/h for dashboards: {KMH[pre]}. Car_speed_mph is this / 1.609344.')
    elif spd and pre in MPH:
        add('speed_kmh', f"({spd['Formula']}) * 1.609344", f'speed in km/h for dashboards, from {MPH[pre]}. Car_speed_mph is this / 1.609344.')
    # the car's own rev limit, RPM (else the plugin gives Max revs)
    if pre in ('FLYINITD3', 'SMDAYTO2PE', 'SMSCUD', 'WMMT3DXP') and has('rev_limit'):
        add('rev_limit_rpm', 'rev_limit', "this car's rev limit, RPM (the rev_limit row), for a dashboard's redline.")
    elif pre == 'OUTRUN2SP' and has('rev_limit'):
        add('rev_limit_rpm', 'valid(rev_limit, 0)', "this car's rev limit, RPM, from the game's car data (not yet checked in a recording); "
            'the plugin gives Max revs when it reads 0.')
    elif pre == 'GRID' and has('rev_frac', 'rpm'):
        add('rev_limit_rpm', 'rev_frac > 0.3 ? round(rpm * max_revs / rev_frac / 100) * 100 : 0', "this car's limiter, RPM, worked out from the "
            "revs and the dial's fraction of the limiter (6500 to 8200 by car); 0 at low revs, where the plugin gives Max revs.")
    # position, 1 = first
    if pre == 'WMMT5DXP' and has('place', 'in_race'):
        add('position', 'in_race ? place : 0', 'race position, 1 to 4, while racing (the place row reads 1 outside a race).')
    elif has('position'):
        add('position', 'position', 'race position, 1 = first' + (' (your class place, as the screen shows it).' if pre == 'SWDC' else '.'))
    # lap you are on, 1 = first
    if pre == 'BG4JP' and has('lap', 'racing'):
        add('lap', 'racing ? lap + 1 : 0', 'the lap you are on, 1 = first (the lap row counts laps completed); 0 outside a race.')
    elif pre == 'M2DAYTONA' and has('laps_done', 'game_state'):
        add('lap', 'game_state == 22 ? laps_done + 1 : 0', 'the lap you are on, 1 = first (laps completed + 1); 0 outside a race.')
    elif pre == 'M2STCC' and has('laps_done', 'in_race'):
        add('lap', 'in_race ? laps_done + 1 : 0', 'the lap you are on, 1 = first (laps completed + 1); 0 outside a race.')
    elif pre == 'GTICLUB3' and has('laps_done', 'laps_total', 'in_race'):
        add('lap', 'in_race ? min(laps_done + 1, max(laps_total, 1)) : 0', 'the lap you are on, 1 = first (laps completed + 1); 0 outside a race.')
    elif pre == 'SWDC' and has('lap'):
        add('lap', 'max(lap, 1)', 'the lap you are on, 1 = first (the game counts 0 on the rolling start).')
    elif has('lap'):
        add('lap', 'lap', 'the lap you are on, 1 = first.')
    if pre == 'GRID' and has('race_laps', 'racing'):
        add('laps_total', 'race_laps', 'laps in the race (the game reads 1 in the menus, so 0 outside a race below).')
    elif has('laps_total'):
        add('laps_total', 'laps_total', 'laps in the race.')
    # time left (RT), seconds
    if has('rt'):
        add('time_left', 'rt', 'time left (RT) as the screen shows it, seconds.')
    elif has('time_left'):
        add('time_left', 'time_left', 'time left (RT), seconds' + (' (this stage\'s).' if pre == 'OUTRUN2SP' else '.'))
    elif pre in ('FNFSB2', 'HYDROTHUNDER', 'IDTA', 'IDTA21', 'IDTAS4', 'IDTAS5', 'IDTAS5V321', 'THRILLDRIVE4') and has('timer'):
        add('time_left', 'timer', 'time left, seconds, from the cheat table\'s timer (not yet checked in a recording).')
    # race clock (TT), seconds
    if pre == 'ID0V230' and has('race_clock'):
        add('race_time', 'max(race_clock, 0)', 'the race clock (TT), seconds from GO (0 in the countdown).')
    elif has('race_clock'):
        add('race_time', 'race_clock', 'the race clock (TT), seconds.')
    elif pre == 'SWDC' and has('race_secs'):
        add('race_time', 'race_secs', 'the race clock (TT), seconds from the rolling start.')
    elif pre == 'WMMT5DXP' and has('race_time2', 'race_time'):
        add('race_time', 'valid(race_time2, race_time)', 'the race clock (TT), seconds.')
    elif has('race_time'):
        add('race_time', 'race_time', 'the race clock (TT), seconds.')
    # the current lap's or stage's time
    if has('lap_time'):
        add('lap_time', 'lap_time', "the current lap's time, seconds.")
    elif pre in ('M2SRALLY', 'OUTRUN2SP') and has('stage_time'):
        add('lap_time', 'stage_time', "this stage's time so far, seconds.")
    # pedals, steering, gap
    if pre in ('GRID', 'ID0V230', 'ID6', 'SMDAYTO2PE', 'SMSCUD', 'SWDC', 'WMMT3DXP', 'WMMT5DXP') and has('brake'):
        add('brake', 'brake', 'brake pedal, 0 to 1, as the game uses it.')
    if pre in ('FLYINITD3', 'GRID', 'ID0V230', 'MKGPDX118', 'OUTRUN2SP', 'SMDAYTO2PE', 'SMSCUD', 'WMMT3DXP') and has('steer'):
        add('steer', 'steer', 'steering, -1 full left to 1 full right, as the game uses it.')
    if pre in ('FLYINITD3', 'ID0V230') and has('gap'):
        add('gap', 'gap', 'distance to the rival, metres: + ahead, - behind (ADVANTAGE on screen); 0 with no rival.')
    elif pre == 'WMMT3DXP' and has('rival_gap'):
        add('gap', 'rival_gap', 'distance to the CPU rival, metres: + ahead, - behind; 0 with no rival.')

def lamp_rows(pre, have, out):
    """The common lamps (plugin 0.20.0): rows lamp_<name>, 0 to 1, from the game's own lamp rows or made from its race values.
    Never tied to racing: a cabinet lights its lamps in the attract mode and menus too (Alexis, 11 November 2026)."""
    def lamp(name, formula, note):
        assert name in LAMPS, name
        out.append(dict(Name='lamp_' + name, Enabled=False, Source='Computed', Type='Float', Module='', BaseOffset='0', Offsets='',
                        Formula=formula, Notes=f'Common lamp Lamp_{name}: {note}'))
    def first(*names): return next((n for n in names if n in have), None)
    simple = [('start', 'lampstart', 'the Start button lamp'), ('view1', 'lampview1', 'view button 1'), ('view2', 'lampview2', 'view button 2'),
              ('view3', 'lampview3', 'view button 3'), ('view4', 'lampview4', 'view button 4'),
              ('select_up', 'lampselectup', 'menu select up'), ('select_down', 'lampselectdown', 'menu select down'),
              ('select_left', 'lampselectleft', 'menu select left'), ('select_right', 'lampselectright', 'menu select right')]
    for name, row, what in simple:
        if row in have: lamp(name, row, f'{what} (the game\'s `{row}`).')
    a = first('lampaction', 'lampinterruptionbutton')
    if a: lamp('action', a, f'the cabinet\'s extra button (the game\'s `{a}`).')
    # leader: the game's own leader lamp, else one made from the race values; Model 2 Sega Rally's own lamp never lit for the lead
    ld = first('leader', 'lampleader') if pre == 'M2SRALLY' else first('lampleader', 'leader')
    if ld: lamp('leader', ld, 'in the lead' + (' (the game\'s own leader lamp).' if ld == 'lampleader' else ', made from the race values (`leader`).'))
    c = first('lampcheckpoint', 'checkpoint')
    if c: lamp('checkpoint', c, f'a checkpoint passed or time extended (`{c}`).')
    if 'final_lap' in have: lamp('final_lap', 'final_lap', 'on the final lap.')
    if pre == 'GRID' and 'shift_lights' in have:
        lamp('shift', 'shift_lights / 2', "the dial's shift lights: 0.5 with one lit (85 to 88% of the car's limiter), 1 with both.")
    else:
        sh = first('lampoverrev', 'shift_light')
        if sh: lamp('shift', sh, f'shift or over-rev light (the game\'s `{sh}`).')
    warn = [n for n in ('wrong_way', 'brake_warning', 'shift_warning') if n in have]
    if warn:
        lamp('warning', f'max({", ".join(warn)})' if len(warn) > 1 else warn[0],
             'an on-screen warning: ' + ', '.join({'wrong_way': 'WRONG WAY', 'brake_warning': 'Brake!', 'shift_warning': 'SHIFT UP'}[n] for n in warn) + '.')
    if 'boost_lamp' in have: lamp('boost', 'boost_lamp', 'the boost lamp.')
    elif all(n in have for n in ('boost_lamp_red', 'boost_lamp_green', 'boost_lamp_blue')):
        lamp('boost', 'max(boost_lamp_red, boost_lamp_green, boost_lamp_blue)', 'the boost lamp, any colour.')
    scale = ' / 100' if pre == 'BG4JP' else ''   # BG4JP's colour lamps are 0 to 100 (brightness)
    for col in ('red', 'green', 'blue', 'white'):
        if 'lamp' + col in have: lamp(col, 'lamp' + col + scale, f'the cabinet\'s {col} lamp (`lamp{col}`).')
    bb = [n for n in ('billboard_red', 'billboard_green', 'billboard_blue', 'billboard_white') if n in have]
    m = first('billboardlamp')
    if m: lamp('marquee', m, 'the billboard lamp.')
    elif bb: lamp('marquee', f'max({", ".join(bb)})', 'the billboard, any colour.')
    else:
        m = first('lampside', 'seatlamp1')
        if m: lamp('marquee', m, f'cabinet lighting (`{m}`).')
    if '1p_brake_lamp' in have: lamp('brake', '_1p_brake_lamp', 'the brake lamp.')

def apply_pack(pack):
    n = 0
    for f in packlayout.files(pack):
        with open(f, encoding='utf-8') as fh: p = json.load(fh)
        before = json.dumps(p, indent=2, ensure_ascii=False)
        p['Variables'] = [v for v in p['Variables'] if v['Name'] not in OURS] + rows_for(p)
        after = json.dumps(p, indent=2, ensure_ascii=False)
        if after != before:
            with open(f, 'w', encoding='utf-8', newline='\n') as fh: fh.write(after)
        n += sum(1 for v in p['Variables'] if v['Name'] in OURS)
    return n

if __name__ == '__main__':
    print(apply_pack(sys.argv[1]), 'car_ and lamp_ rows in all')
