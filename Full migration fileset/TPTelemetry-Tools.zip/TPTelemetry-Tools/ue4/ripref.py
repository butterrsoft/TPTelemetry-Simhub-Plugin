# Find RIP-relative references (lea/mov etc. with disp32) in .text to target RVAs. Builds an index once (npz).
import sys, os, numpy as np, pefile
exe = sys.argv[1]
idx = exe + '.ripidx.npz'
pe = pefile.PE(exe, fast_load=True)
text = [s for s in pe.sections if s.Name.startswith(b'.text')][0]
if not os.path.exists(idx):
    data = np.frombuffer(text.get_data(), dtype=np.uint8)
    n = len(data) - 4
    disp = (data[:n].astype(np.int64) | (data[1:n+1].astype(np.int64) << 8) | (data[2:n+2].astype(np.int64) << 16) | (data[3:n+3].astype(np.int64) << 24))
    disp = np.where(disp >= 2**31, disp - 2**32, disp)
    # candidate: disp field at position p, instruction ends at p+4 (no imm) -> target = rva(p)+4+disp
    pos = np.arange(n, dtype=np.int64)
    tgt = text.VirtualAddress + pos + 4 + disp
    # keep only where preceding byte is a modrm with mod=00 rm=101
    modrm = np.zeros(n, dtype=np.uint8); modrm[1:] = data[:n-1]
    keep = (modrm & 0xC7) == 0x05
    np.savez(idx, pos=pos[keep], tgt=tgt[keep])
z = np.load(idx)
pos, tgt = z['pos'], z['tgt']
for a in sys.argv[2:]:
    t = int(a, 16)
    hits = pos[tgt == t]
    print(a, [hex(text.VirtualAddress + p - 3) for p in hits][:40], len(hits))
