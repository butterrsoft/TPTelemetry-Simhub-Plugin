import sys
rows = []
for l in open(sys.argv[1]):
    p = l.strip().split(' ', 1)
    if len(p) == 2:
        try: rows.append((int(p[0], 16), p[1]))
        except ValueError: pass
before = int(sys.argv[2]); after = int(sys.argv[3])
for name in sys.argv[4:]:
    for i, (o, s) in enumerate(rows):
        if s == name:
            print('---', name, hex(o)); print(' | '.join(x[1] for x in rows[max(0, i - before):i + after])); break
