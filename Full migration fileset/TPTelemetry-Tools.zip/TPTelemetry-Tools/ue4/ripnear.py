# RIP-relative refs to targets within [T-back, T+fwd] (approx, ignores trailing immediates of up to 4 bytes)
import sys, numpy as np
z = np.load(sys.argv[1] + '.ripidx.npz'); pos, tgt = z['pos'], z['tgt']
TV = 0x1000
back = int(sys.argv[3], 16) if len(sys.argv) > 3 else 0x200
for a in sys.argv[2].split(','):
    t = int(a, 16)
    m = (tgt >= t - back - 4) & (tgt <= t + 4)
    import collections
    c = collections.Counter(tgt[m].tolist())
    print(a, [(hex(k), v) for k, v in sorted(c.items())][-30:])
