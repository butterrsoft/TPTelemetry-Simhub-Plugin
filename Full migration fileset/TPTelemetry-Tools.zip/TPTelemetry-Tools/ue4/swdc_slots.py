# For a UObject constructor, map member offsets to data-model slots (Q + const) via the registry pattern.
import sys, re
sys.argv = ['x', 'bin.exe']; sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__))); import fdis
def body(a, n=0x200):
    g = fdis.func(a); s, e = (g[0], g[1]) if g else (a, a + n)
    out = []
    for i in fdis.md.disasm(fdis.rd(s, e - s), s):
        out.append(i)
        if not g and i.mnemonic in ('ret', 'jmp'): break
    return out
def slot_of(init):
    # init(rcx=this+X, rdx=initializer): calls 0x2fa230 then a thunk(rcx=reg, rdx, r8) that adds 0x30 and calls leaf adding const
    cs = [int(i.op_str, 16) for i in body(init) if i.mnemonic == 'call' and i.op_str.startswith('0x')]
    for c in cs:
        if c in (0x2f9de0, 0x2fa230, 0x495b90, 0x30e8b0) : continue
        b = body(c, 0x30)
        if len(b) < 12 and any(i.mnemonic == 'add' and i.op_str == 'rcx, 0x30' for i in b):
            leafc = [int(i.op_str, 16) for i in b if i.mnemonic == 'call']
            if leafc:
                lb = body(leafc[0], 0x20)
                for i in lb:
                    m = re.match(r'rax, (0x[0-9a-f]+)$', i.op_str)
                    if i.mnemonic == 'add' and m: return 'Q+%s' % m.group(1)
                    m = re.match(r'rax, qword ptr \[rcx \+ (0x[0-9a-f]+)\]', i.op_str)
                return 'leaf %x: %s' % (leafc[0], '; '.join('%s %s' % (i.mnemonic, i.op_str) for i in lb[:5]))
    return None
ctor = int(sys.argv[1] if len(sys.argv) > 1 and False else '0', 16)
