# Class sizes from GetPrivateStaticClass functions (call to GetPrivateStaticClassBody 0x86b350)
import sys, re
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__))); import fdis
text = [s for s in fdis.secs if s.Name.startswith(b'.text')][0]
d = text.get_data(); TV = text.VirtualAddress
import struct
out = []
i = d.find(b'\xe8')
target = 0x86b350
# find call rel32 to target
import numpy as np
a = np.frombuffer(d, dtype=np.uint8)
idx = np.nonzero(a[:-5] == 0xE8)[0]
rel = a[idx+1].astype(np.int64) | (a[idx+2].astype(np.int64) << 8) | (a[idx+3].astype(np.int64) << 16) | (a[idx+4].astype(np.int64) << 24)
rel = np.where(rel >= 2**31, rel - 2**32, rel)
calls = idx[(TV + idx + 5 + rel) == target]
for c in calls:
    f = fdis.func(TV + int(c))
    if not f: continue
    name = size = None
    for ins in fdis.md.disasm(fdis.rd(f[0], f[1] - f[0]), f[0]):
        m = re.search(r'\[rip \+ (0x[0-9a-f]+)\]', ins.op_str)
        if ins.mnemonic == 'lea' and m and name is None:
            s = fdis.sstr(ins.address + ins.size + int(m.group(1), 16))
            if s and s.startswith('L"'): name = s[2:-1]
        mm = re.match(r'dword ptr \[rsp \+ 0x20\], (0x[0-9a-f]+)$', ins.op_str)
        if ins.mnemonic == 'mov' and mm: size = int(mm.group(1), 16)
    out.append((name, size, f[0]))
names = sys.argv[2:]
for n, sz, f in sorted(out, key=lambda x: str(x[0])):
    if not names or any(re.search(x, str(n)) for x in names): print('%-45s %-7s getclass=%x' % (n, hex(sz) if sz else '?', f))
print(len(out), 'classes', file=sys.stderr)
