# Disassemble the .pdata function containing an RVA; annotate RIP targets that are wide/ascii strings.
import sys, bisect, pefile, capstone, struct, re
exe = sys.argv[1]
pe = pefile.PE(exe, fast_load=True)
img = pe.get_memory_mapped_image() if False else None
secs = pe.sections
def rd(rva, n):
    for s in secs:
        if s.VirtualAddress <= rva < s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            off = rva - s.VirtualAddress
            d = s.get_data()
            return d[off:off+n]
    return b''
pd = [s for s in secs if s.Name.startswith(b'.pdata')][0].get_data()
fns = sorted(struct.unpack_from('<III', pd, i) for i in range(0, len(pd) - 11, 12))
fns = [f for f in fns if f[0]]
starts = [f[0] for f in fns]
def func(rva):
    i = bisect.bisect_right(starts, rva) - 1
    return fns[i] if i >= 0 and fns[i][0] <= rva < fns[i][1] else None
def sstr(rva):
    b = rd(rva, 200)
    try:
        w = b.decode('utf-16le', 'ignore').split('\0')[0]
        if len(w) >= 2 and re.fullmatch(r'[\x20-\x7e]+', w): return 'L"%s"' % w
    except Exception: pass
    a = b.split(b'\0')[0]
    if len(a) >= 3 and re.fullmatch(rb'[\x20-\x7e]+', a): return '"%s"' % a.decode()
    return None
md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
def dis(start, end, out=print):
    code = rd(start, end - start)
    for ins in md.disasm(code, 0x140000000 + start):
        ops = ins.op_str
        note = ''
        m = re.search(r'\[rip ([+-]) (0x[0-9a-f]+)\]', ops)
        if m:
            t = ins.address + ins.size + (int(m.group(2), 16) if m.group(1) == '+' else -int(m.group(2), 16))
            ops = ops.replace(m.group(0), '[%#x]' % t)
            s = sstr(t - 0x140000000)
            note = ('  ; ' + s) if s else ''
        out('%x: %s %s%s' % (ins.address - 0x140000000, ins.mnemonic, ops, note))
if __name__ == '__main__':
    for a in sys.argv[2:]:
        r = int(a, 16); f = func(r)
        print('== function', hex(f[0]), hex(f[1]) if f else None)
        dis(f[0], f[1])
