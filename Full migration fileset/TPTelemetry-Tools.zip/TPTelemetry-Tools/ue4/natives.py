# UE 4.17 native function tables in .rdata: runs of (char* name, exec function) pairs, as FNativeFunctionRegistrar
# gets them. Usage: natives.py <exe> [from-to rdata RVA range, hex] > natives.txt
import sys, struct, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fdis
rd = [s for s in fdis.secs if s.Name.startswith(b'.rdata')][0]; d = rd.get_data()
tx = [s for s in fdis.secs if s.Name.startswith(b'.text')][0]
B = fdis.pe.OPTIONAL_HEADER.ImageBase; RV = rd.VirtualAddress; RE = RV + len(d)
lo, hi = (int(x, 16) for x in sys.argv[2].split('-')) if len(sys.argv) > 2 else (RV, RE)
def astr(rva):
    if not (RV <= rva < RE): return None
    o = rva - RV; e = d.find(b'\0', o, o + 80)
    if e <= o: return None
    s = d[o:e]
    return s.decode() if all(32 < c < 127 for c in s) and s[:1].isalpha() else None
def code(a): return B + tx.VirtualAddress <= a < B + tx.VirtualAddress + tx.Misc_VirtualSize
i = 0; n = len(d) - 16
while i < n:
    a, b = struct.unpack_from('<QQ', d, i)
    if B + RV <= a < B + RE and code(b):
        j = i; items = []
        while j < n:
            a, b = struct.unpack_from('<QQ', d, j)
            s = astr(a - B) if B + RV <= a < B + RE else None
            if s and code(b): items.append((s, b - B)); j += 16
            else: break
        if len(items) >= 2 and lo <= RV + i < hi: print('%x: %s' % (RV + i, ' '.join('%s=%x' % x for x in items)))
        i = j if j > i else i + 8
    else: i += 8
