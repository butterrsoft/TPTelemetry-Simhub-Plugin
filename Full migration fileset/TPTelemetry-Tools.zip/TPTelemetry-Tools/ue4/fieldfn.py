# Functions whose code uses all the given structure displacements ([reg + 0xNNN]); prints the matching instructions.
# Usage: fieldfn.py bin.exe 0x298 0x348 [...]
import sys, re, struct
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
import fdis
offs = [int(a, 16) for a in sys.argv[2:]]
text = [s for s in fdis.secs if s.Name.startswith(b'.text')][0]
d = text.get_data(); TV = text.VirtualAddress
import bisect
cand = None
for o in offs:
    pat = struct.pack('<I', o); s = set(); i = d.find(pat)
    while i >= 0:
        f = fdis.func(TV + i)
        if f: s.add(f)
        i = d.find(pat, i + 1)
    cand = s if cand is None else cand & s
print(len(cand), 'functions')
pats = [re.compile(r'\[r\w+ \+ %s\]' % hex(o)) for o in offs]
for f in sorted(cand):
    lines = []
    for ins in fdis.md.disasm(fdis.rd(f[0], f[1] - f[0]), f[0]):
        if any(p.search(ins.op_str) for p in pats): lines.append('   %x: %s %s' % (ins.address, ins.mnemonic, ins.op_str))
    hit = [all(p.search(l) is None for l in lines) for p in pats]
    if not any(hit) and lines:
        print('== %x-%x' % f[:2]); print('\n'.join(lines[:12]))
