# UE 4.17 reflection: list a class's (or struct's) properties: name, offset, property ctor, alloc size.
# Usage: uprops.py bin.exe ClassName [...]   (class name with prefix, e.g. UCarMovementComponent)
import sys, re, numpy as np, collections
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
import fdis
exe = sys.argv[1]
z = np.load(exe + '.ripidx.npz'); pos, tgt = z['pos'], z['tgt']
TEXTVA = 0x1000
wides = {}
rdata = [s for s in fdis.secs if s.Name.startswith(b'.rdata')][0]
def find_wide(name):
    pat = name.encode('utf-16le') + b'\0\0'
    d = rdata.get_data(); out = []; i = d.find(pat)
    while i >= 0:
        if i % 2 == 0 and (i < 2 or d[i-2:i] == b'\0\0'): out.append(rdata.VirtualAddress + i)
        i = d.find(pat, i + 1)
    return out
def refs(t): return [TEXTVA + int(p) - 3 for p in pos[tgt == t]]
md = fdis.md
def construct_fn(name):
    # FCompiledInDefer: lea rax,L"Name"; ...; lea r9,L"/Script/.."; lea r8, StaticClass; lea rdx, Z_Construct
    for s in find_wide(name):
        for r in refs(s):
            f = fdis.func(r)
            if not f or f[1] - f[0] > 0x80: continue
            code = fdis.rd(f[0], f[1] - f[0]); last = {}
            for ins in md.disasm(code, f[0]):
                m = re.match(r'(r\w+), \[rip \+ (0x[0-9a-f]+)\]', ins.op_str)
                if ins.mnemonic == 'lea' and m: last[m.group(1)] = ins.address + ins.size + int(m.group(2), 16)
            if 'rdx' in last and 'r9' in last and fdis.sstr(last['r9']) and '/Script' in fdis.sstr(last['r9']):
                return last['rdx']
    return None
def props(fn):
    f = fdis.func(fn); code = fdis.rd(f[0], f[1] - f[0])
    out = []; cur = None
    regs = {}
    for ins in md.disasm(code, f[0]):
        m = re.search(r'\[rip \+ (0x[0-9a-f]+)\]', ins.op_str)
        if ins.mnemonic == 'lea' and m and ins.op_str.startswith('rdx'):
            s = fdis.sstr(ins.address + ins.size + int(m.group(1), 16))
            if s and s.startswith('L"'):
                if cur: out.append(cur)
                cur = {'name': s[2:-1], 'off': None, 'ctor': None, 'size': None, 'flags': None, 'at': ins.address}
                continue
        if cur is None: continue
        if ins.mnemonic == 'mov' and ins.op_str.startswith('ecx, 0x') and cur['size'] is None: cur['size'] = int(ins.op_str[5:], 16)
        if ins.mnemonic == 'mov' and ins.op_str.startswith('r9d, 0x'): cur['r9'] = int(ins.op_str[5:], 16)
        if ins.mnemonic == 'xor' and ins.op_str == 'r9d, r9d': cur['r9'] = 0
        if ins.mnemonic == 'movabs': cur['flags'] = ins.op_str.split(', ')[1]
        if ins.mnemonic == 'call' and cur['size'] is not None and ins.op_str.startswith('0x'):
            t = int(ins.op_str, 16)
            if t in (0x98f6c0, 0x98fc80): continue
            if cur.get('alloc') is None: cur['alloc'] = t; cur['r9'] = None
            elif cur['ctor'] is None and cur.get('r9') is not None: cur['ctor'] = t; cur['off'] = cur['r9']
            else: cur['r9'] = None
    if cur: out.append(cur)
    return out
if __name__ == '__main__':
    for name in sys.argv[2:]:
        fn = construct_fn(name)
        print('==', name, 'Z_Construct', hex(fn) if fn else None)
        if not fn: continue
        for p in props(fn - 0x140000000 if fn > 0x140000000 else fn):
            print('  %-40s off=%-6s size=%-5s ctor=%s flags=%s' % (p['name'], hex(p['off']) if p['off'] is not None else '?', hex(p['size']) if p['size'] else '?', hex(p['alloc']) if p.get('alloc') else '?', p['flags']))
