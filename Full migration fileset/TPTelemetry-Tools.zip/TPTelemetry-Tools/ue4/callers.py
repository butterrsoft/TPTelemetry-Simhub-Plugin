import sys, numpy as np
sys.argv = ['x', 'bin.exe'] + sys.argv[1:]; sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__))); import fdis
text = [s for s in fdis.secs if s.Name.startswith(b'.text')][0]; d = text.get_data(); TV = text.VirtualAddress
a = np.frombuffer(d, dtype=np.uint8)
idx = np.nonzero((a[:-5] == 0xE8) | (a[:-5] == 0xE9))[0]
rel = (a[idx+1].astype(np.int64) | (a[idx+2].astype(np.int64) << 8) | (a[idx+3].astype(np.int64) << 16) | (a[idx+4].astype(np.int64) << 24))
rel = np.where(rel >= 2**31, rel - 2**32, rel)
tg = TV + idx + 5 + rel
for t in sys.argv[2:]:
    t = int(t, 16)
    hits = [TV + int(i) for i in idx[tg == t]]
    print(hex(t), [(hex(h), hex(fdis.func(h)[0]) if fdis.func(h) else None) for h in hits][:12])
