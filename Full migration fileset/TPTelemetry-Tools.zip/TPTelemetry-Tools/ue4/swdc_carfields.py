import sys, re
sys.argv = ['x', 'bin.exe']; sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__))); import fdis
B = 0
def body(a, maxlen=0x120):
    g = fdis.func(a)
    s, e = (g[0], g[1]) if g else (a, a + maxlen)
    out = []
    for i in fdis.md.disasm(fdis.rd(s, e - s), s):
        out.append(i)
        if not g and i.mnemonic in ('ret',) : break
        if not g and i.mnemonic == 'jmp' and i.op_str.startswith('0x'): break
    return out
def calls(a):
    return [int(i.op_str, 16) - B for i in body(a) if i.mnemonic in ('call', 'jmp') and i.op_str.startswith('0x')]
line = [l for l in open('natives.txt') if l.startswith('2fbad80')][0]
lib = dict(kv.split('=') for kv in line.split()[1:])
for name, ex in lib.items():
    c = [x for x in calls(int(ex, 16)) if x not in (0x97df60, 0x97df90)]
    if not c: print(name, 'no call'); continue
    nat = c[-1]
    nc = calls(nat)
    print('%-32s %x -> %s' % (name, nat, ' '.join('%x' % x for x in nc[:5])))
print('-----')
acc = {}
for name, ex in lib.items():
    c = [x for x in calls(int(ex, 16)) if x not in (0x97df60, 0x97df90)]
    if not c: continue
    nc = calls(c[-1])
    if nc and 0x37d000 <= nc[0] < 0x37f000: acc[name] = nc[0]
    elif not nc:
        # tail jump style (test rcx; jne X)
        b = body(c[-1], 0x20)
        j = [int(i.op_str, 16) for i in b if i.mnemonic == 'jne' and i.op_str.startswith('0x')]
        if j: acc[name] = j[0]
def desc(a):
    cs = calls(a)
    parts = []
    for x in cs:
        if x == 0x37de80: parts.append('rec')
        elif x == 0x2df670: continue
        else:
            b = body(x, 0x30)
            parts.append('%x[%s]' % (x, '; '.join('%s %s' % (i.mnemonic, i.op_str) for i in b[:3])))
    return parts
for name, a in acc.items():
    print('%-30s %x: %s' % (name, a, ' | '.join(desc(a))[:260]))
