"""Tidies every profile's table (Alexis, 3 November 2026). Run by memgames.py after commonrows.py, before
gameformulas.py; on its own for hand edits:
    python3 tidytable.py <pack folder> [more profile files...]

1. Merges redundant rows. A memory read that only one plain computed row uses (no time-based functions,
   no other rows) becomes that row: the computed row's formula moves onto the read, with `value` for the
   raw number, and the computed row's name and tick are kept. The raw number still shows in the table's
   Raw column. So WMMT5's `gear_raw` + `gear = gear_raw` is one `gear` row, and `steer_raw` +
   `steer = (steer_raw - 127.5) / 127.5` is one `steer` row reading memory. Rows OutputBlaster's
   conversion owns (ob_ rows, notes naming OutputBlaster) and the car_ rows are left alone.
2. Orders the table:
   * values read from the game: memory reads, and rows worked out only from TeknoParrot's shared
     memory, game outputs, USB values or the clock (no other rows);
   * then values calculated from other rows;
   * then the car_ rows that feed the common values (TPTelemetry.Car_*) and so the SimHub effects.
   Within the first two groups speed rows come first, then revs, then gear, then the rest in the
   order they were in (OutputBlaster's shared raw ob_ reads last among the game values).
Running it twice changes nothing.
"""
import json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import packlayout
from commonrows import OURS

IDENT = re.compile(r'\b[A-Za-z_]\w*\b')
STATEFUL = re.compile(r'\b(slope|deriv|avg|minw|maxw|ema|smooth|prev|delta|rate|unwrap|integrate|hold)\s*\(')
KINDS = [re.compile(r'^(speed|speedo)\d*$'), re.compile(r'^(rpm|revs)\d*$'), re.compile(r'^gear(\d+|_raw)?$')]

def refs(formula, names):
    return set(IDENT.findall(formula or '')) & names

# Notes oblamps.py writes on the rows it owns (it recognises them by these on its next run).
OB_NOTES = ('the same reads OutputBlaster makes', 'OutputBlaster always sends', 'Engine RPM, read from game memory as OutputBlaster does',
            "Raw value OutputBlaster's", 'Output from OutputBlaster', 'Needs OutputBlaster running')

def ob_owned(v):
    n = v.get('Notes') or ''
    return v['Name'].startswith(('ob_', 'out_')) or (v.get('Formula') or '').startswith('out_') or any(k in n for k in OB_NOTES)

def merge(p):
    """Folds single-use memory reads into the plain computed row that uses them. Returns the merges made."""
    done = []
    while True:
        rows = p['Variables']; names = {v['Name'] for v in rows}
        users = {n: [v for v in rows if v['Name'] != n and n in refs(v['Formula'], names)] for n in names}
        pick = None
        for x in rows:
            if x['Source'] != 'Memory' or ob_owned(x) or x['Name'] in OURS: continue
            u = users[x['Name']]
            if len(u) != 1: continue
            c = u[0]
            if c['Source'] != 'Computed' or c['Name'] in OURS or ob_owned(c): continue
            if refs(c['Formula'], names) != {x['Name']} or STATEFUL.search(c['Formula']): continue
            pick = (x, c); break
        if pick is None: return done
        x, c = pick
        inner = 'value' if not (x['Formula'] or '').strip() else f"({x['Formula'].strip()})"
        f = re.sub(r'\b' + re.escape(x['Name']) + r'\b', inner, c['Formula'])
        if f.strip() == 'value': f = ''
        notes = (c['Notes'] or '').rstrip()
        if (x['Notes'] or '').strip(): notes += ' Raw: ' + x['Notes'].strip()
        merged = dict(x, Name=c['Name'], Enabled=c['Enabled'], Formula=f, Notes=notes)
        p['Variables'] = [merged if v is x else v for v in rows if v is not c]
        done.append(f"{x['Name']} + {c['Name']}")

def kind(name):
    for i, k in enumerate(KINDS):
        if k.match(name): return i
    return len(KINDS)

def order(p):
    rows = p['Variables']; names = {v['Name'] for v in rows}
    def group(v):
        if v['Name'] in OURS: return 2
        if v['Source'] == 'Memory' or not (refs(v['Formula'], names) - {v['Name']}): return 0
        return 1
    # OutputBlaster's shared raw reads (unticked ob_ rows) go after the other game values: oblamps.py puts
    # them back in at a different place on each run, so this keeps the order the same run to run.
    def sub(v):
        if group(v) == 2: return 0
        k = kind(v['Name'])
        return k + 1 if k == len(KINDS) and v['Name'].startswith('ob_') else k
    keyed = [(group(v), sub(v), i, v) for i, v in enumerate(rows)]
    p['Variables'] = [v for *_, v in sorted(keyed, key=lambda k: k[:3])]

def tidy_file(f):
    with open(f, encoding='utf-8') as fh: p = json.load(fh)
    before = json.dumps(p, indent=2, ensure_ascii=False)
    merged = merge(p)
    order(p)
    after = json.dumps(p, indent=2, ensure_ascii=False)
    if after != before:
        with open(f, 'w', encoding='utf-8', newline='\n') as fh: fh.write(after)
    return merged

def apply_pack(pack):
    out = {}
    for f in packlayout.files(pack):
        m = tidy_file(f)
        if m: out[os.path.basename(f)[:-5]] = m
    return out

if __name__ == '__main__':
    for a in sys.argv[1:]:
        if os.path.isdir(a):
            for k, m in apply_pack(a).items(): print(k, 'merged', ', '.join(m))
        else:
            m = tidy_file(a)
            if m: print(os.path.basename(a), 'merged', ', '.join(m))
