# TP Telemetry tools (19 November 2026)

Every script for the profile pack, Model 2 work, exe reading and Linux (ELF) game reading. The same files are in the claude.ai project under
`claude/tools/`, `claude/tools/exe/` and `claude/tools/elf/`.

## Pack generators

Run from a folder that also holds `ffbsrc/repo` (a clone of Boomslangnz/FFBArcadePlugin) and `refsrc/ob`
(a clone of Boomslangnz/OutputBlaster), with these scripts in `tools/`:

    python3 -I tools/memgames.py <copy of the TPTelemetry-GameProfiles folder>

The pipeline is memgames, moregames, oblamps, `moregames.fix_m2_lamps`, `moregames.fix_mk118_lamps`, `moregames.fix_mkusa_lamps`, commonrows, tidytable, gameformulas,
gamesetup. A second run changes nothing. Hand edits go in these scripts, never in the profile JSON; the pack
README is the only hand-edited file in the pack.

| Script | What it does | First written | Last changed |
|---|---|---|---|
| `memgames.py` | Memory-read profiles, and runs the whole pipeline | 28 October | 16 November (GRID: the race rows checked and ticked, `racing` (from GO to the line, off while paused and at TIME OVER), `steer`, laps and lap lines; position list and game mode from the exe as raw reads; damage rows gone); 12 November (GRID from its exe: `brake` from the dial, and unticked raw reads of the race (running and finished flags, clock, laps, cars, race type, car 0's record), steering input and damage) |
| `moregames.py` | Hand-built profiles (Model 2, ID6 and others), Model 2 lamps, WMMT3DX+'s, Sega Rally 3's and Initial D Zero v2.30's rows from the game | 2 November | 19 November, 14:10 (Supermodel lamp rows renamed `lampstart`, `lampview1`..., `lampleader`: `lamp_` is now the common lamps' prefix); 19 November, 13:00 (Initial D 3: Flycast v2.7-1's RAM pointer, `FLY_RAM` 29D0C10); 19 November, 12:30 (SWDC: `contact_side` from the first shove, Car_drift refitted to her seven values); 19 November, 11:40 (SWDC: `checkpoint` ticked, `contact_side` from the biggest shove); 19 November, 11:00 (SWDC from her answers: `vel_lat`, `jolt`, `car_contact`, `contact_side`, `contact_strength`, `verge`, `kerb`, Car_drift fitted to her values, `position` the class place, `overall`, `time_left` dropped, `hit` 5 G while braking); 19 November, 09:30 (SWDC checked in her race: `in_race` = race state 2, every value 0 outside the race, `revs_record`, sparks' notes, `backfire` 0 to 1); 18 November, evening (`swdc_rows`: Sega World Drivers Championship from its v2.30 exe: your car's record through plugin 0.19.0's indexed offset: race state, speedo km/h, revs, gear, brake, sparks, backfire, place, lap, sector, position and heading, drift angle; time left; the old `in_race` kept as `in_race_revs`, the fallback; Max speed 230 km/h); 18 November, 19:10 (Daytona 2 PE: `rpm` from the rev counter +0x1E0, `rpm_wheels`, limiters EASY and SPECIAL 7650); 18 November, 19:00 (Daytona 2 PE: candidate revs rows `engine_rpm`, `rpm_1e0`); 18 November, 18:50 (Daytona 2 PE: `rev_limit` by car class, `rpm_frac`); 18 November, 17:50 (Daytona 2 PE: car-hit side from the roll command, Car_drift from her three points); 18 November, 17:10 (Daytona 2 PE from her recordings: `car_contact`, `car_touch`, `pit_stop`, hits from car touches, edges exclusive, Max revs 8500); 18 November, 15:00 (Daytona USA 2 Power Edition: `d2pe_rows`, the new `SMDAYTO2PE` profile from Supermodel's RAM; `short_force` shared with Scud Race; Scud Race: F40 limit 9040 from her fifth recording); 18 November, 13:45 (Scud Race: her answers: car-touch hits, `light`, drift from her two points, `grid`, F40 limit 9000, `force` 0.1 s); 18 November, 13:00 (Scud Race checked in her four recordings: `racing` ends at the clock stop, finishing place, pit stop, airborne from free fall, car number and rev limits, car contact, wrong way, drift full at 70, `wheel_angle` was not); 18 November, afternoon (`sm_ram`, `sm_lamps`, `smscud_rows`: Scud Race read from Supermodel's emulated RAM: race phase, clocks, laps, position, speed, revs, gear, pedals, steering, crash timer, wheels against walls, drift angle; the cabinet lamps from outputs; `supermodel.exe` as its process); 18 November (Initial D 3: `ram_probe` back, for testing newer Flycast builds); 17 November, evening (Initial D 3 wrapped up: drift tuned, gutter and grooved-road codes, lamps untied from racing, `ram_probe` removed); 17 November, 18:30 (Initial D 3: ripple strips, drift angle, contact side and hits, Max speed and revs); 17 November, 17:30 (Initial D 3: `race_ok` guards `racing` and the lamps; rows marked checked); 17 November, 16:00 (`fly_ptr`: rows through the game's pointers with `@` offsets; Initial D 3's `rt`, `race_clock`, `lap`, `lampcheckpoint`, `contact`, `gutter`); 17 November, 15:00 (`fly_id3_game` from recordings 3 and 4: throttle, steering, rev limit, `racing`, `lampleader`; heap rows removed); 17 November, afternoon (`fly_id3_game`: Initial D 3's speed, revs, gear, gap, clocks and candidate rows from save states); 17 November (`fly_ram`, `fly_id3_rows`: Flycast's emulated RAM, Initial D 3's lamp bits and RAM probe; `flycast.exe` as its process); 16 November, night (`id0_rows`: `lampleader`, `lampcheckpoint` made from race values); 16 November, evening (`id0_rows` checked in three recordings: automatic revs (the counter shows P+B04 x 0.885), steering sign, ripple strips from the vibration, gap only against a rival, Max speed and revs); 16 November, afternoon (`id0_rows`: Initial D Zero v2.30 from its exe: race and car state, game mode, race clock, time left and checkpoints, gap to the rival, speed, revs and rev limit, gear, pedals, steering, drift angle, the car's events (ID6's bits) and surface sounds, for both slots and yours; the cheat table's other two reads renamed `menu_timer` and `hud_meter`); 16 November (`add_sr3` replaces rows in place; Sega Rally 3 checked in her recording: notes, `position` held 0.1 s, `wrong_way` only while racing, `checkpoint` not at GO or the start line, `racing` 1 if the state can't be read; the hand-maintained `hit` row tuned from her answers: the drop rises with hard slowing, 0.7 s after airborne; `race_time` and `rt`, RT as the screen shows it); 12 November (`add_sr3`: Sega Rally 3 from its exe: player state, time left, checkpoints, laps, position, wrong way); 11 November, night (`add_wmmt3`: WMMT3DX+ read from the game's own variables, checked in her recordings: countdown gate, tacho, tyre load and crests, car hits and their side; OutRun 2 from its `jennifer`, checked: speedo as Car_speed, crash motions, fork arrow, redline light; 12 November: car hits and their side from the game's contact words, mode numbers, redline light 8,270, hearts and challenges) |
| `commonrows.py` | The car_ rows behind the common Car_ values, and the lamp_ rows behind the common Lamp_ lamps | 31 October | 19 November, 14:10 (plugin 0.20.0: dashboard rows `car_speed_kmh` (km/h where the units are known, SR3's mph converted), `car_rev_limit_rpm`, `car_position`, `car_lap`, `car_laps_total`, `car_time_left`, `car_race_time`, `car_lap_time`, `car_brake`, `car_steer`, `car_gap`, gated like each game's other rows; common lamp rows `lamp_...` from the games' own lamps, never gated); 19 November, 11:00 (SWDC: Car_impact and side from contacts, Car_off_road from the verge, Car_rumble_strip from solid kerbs); 19 November, 09:30 (SWDC: every Car_ value 0 outside the race; Car_rpm from `revs`; no spark wall contact or hit side); 18 November, evening (SWDC: Car_speed the speedo's km/h and Car_gear from your car's record, falling back to the table; wall contact and hit side from the game's sparks; drift from heading against travel); 18 November, 19:10 (Daytona 2 PE: limiter note); 18 November, 18:50 (Daytona 2 PE: Car_rpm_frac from each class's limiter); 18 November, 17:50 (Daytona 2 PE: Car_throttle 1 on the grid and rolling start, drift note); 18 November, 17:10 (Daytona 2 PE: notes, checked); 18 November, 15:00 (Daytona USA 2 PE: in race from the start, impact, wall contact, drift, cornering, throttle, all 0 outside a race; Scud Race: Car_throttle 1 on the grid so the engine follows the revs); 18 November, 13:45 (Scud Race: in race on the grid, revs and gear then; airborne 0.5 over crests; drift from her two points); 18 November, 13:00 (Scud Race: cornering from steering, airborne, rpm_frac per car, drift full at 70, hits with car contact); 18 November (Scud Race in Supermodel: in race from the countdown to the line, impact from the crash timer, wall contact, drift, cornering from the wheels' angle, throttle; all 0 outside a race); 17 November (Initial D 3: in_race, throttle, rpm_frac, impact, wall contact, drift tuned to her 0.62 top, cornering from steering, off_road from gutters; all 0 outside a race); 16 November, night (Initial D Zero: Car_cornering from steering and speed); 16 November, evening (Initial D Zero: Car_rpm_frac removed); 16 November, afternoon (Initial D Zero v2.30: as ID6's, plus Car_rpm_frac from the car's rev limit; every value but Car_in_race 0 outside a race); 16 November (SR3 and GRID: Car_in_race is `racing`, and every other common value reads 0 outside a race); 12 November (SR3: Car_in_race from the player state, 1 if it can't be read); 11 November, night (WMMT3DX+: in race from the race state, boost, per-car rev fraction, throttle, drift, airborne and crests, car-hit impact and side; OutRun 2: in race, Car_speed from the speedo, drift full at 75 degrees for this game only, airborne from crash motions, impact at a crash motion's start; 12 November: impact from car hits, side from the game; speed, revs, gear and G 0 outside a race for this game only) |
| `gamesetup.py` | Writes Game_Setup.md | 3 November | 19 November, 14:20 (the common dashboard values and lamps by their full property names); 19 November, 14:10 (each game's common dashboard values and lamps; dashboard rows don't count as effect rows); 19 November, 13:00 (Initial D 3: the Flycast build it's for); 19 November (SWDC: checked, values only in the race; 11:00 contacts, surfaces, class place); 18 November, evening (SWDC: the game's own data, plugin 0.19.0 needed); 18 November, 19:10 (Daytona 2 PE: revs from the rev counter); 18 November, 18:50 (Daytona 2 PE: limiters by class); 18 November, 17:10 (Daytona 2 PE checked); 18 November, 15:00 (Daytona USA 2 PE notes; Scud Race's grid throttle; the outputs-required line left off for emulator games read from memory: Initial D 3, Scud Race, Daytona 2 PE); 18 November, 13:00 (Scud Race checked in her recordings); 18 November, afternoon (Scud Race in Supermodel: what the memory rows read, outputs optional, NVRAM link setting); 18 November (Initial D 3: `ram_probe` explained again); 17 November, evening (Initial D 3: checked, outputs optional); 17 November, afternoon (Initial D 3: the game rows, outputs not needed); 17 November (Initial D 3 in Flycast: what the recording profile reads); 16 November, evening (Initial D Zero: checked rows); 16 November, afternoon (Initial D Zero v2.30: segatools or TeknoParrot, what its rows are, not yet checked); 16 November (GRID and SR3: what her recordings checked, the new rows); 12 November (GRID: the new brake and raw race rows; SR3: the rows from its exe); 11 November, night (WMMT3DX+ and OutRun 2: what is checked in her recordings, and notes on the new rows) |
| `oblamps.py`, `obmem.py`, `obnames.py` | Lamp rows from OutputBlaster's source | 28 to 29 October | by 3 November |
| `tidytable.py` | Merges single-use reads and orders rows | 2 November | by 3 November |
| `gameformulas.py` | Writes Game_Formulas.md | 30 October | by 3 November |
| `packlayout.py` | The pack's emulator folders | 2 November | 18 November, 15:00 (`SMDAYTO2PE` in the Supermodel folder); by 3 November |

"By 3 November": identical to the copies in Alexis's own export from about then.

## Model 2

| Script | What it does | Date |
|---|---|---|
| `tptram.lua` | Emulator Lua RAM logger (v2), loaded after a game's own script; kept for future value hunting | 4 November |
| `m2ramscan.py` | Ranks speed, revs, gear and timer candidates from a `tptram.lua` log plus mark notes | 4 November |
| `i960.py` | Disassembles i960 program ROM ranges: `python3 i960.py <program.bin> <from>-<to>` | 8 November |

## Linux game programs (`elf/`)

| Script | What it does | Date |
|---|---|---|
| `elfsyms.py` | Finds named globals and functions in a 32-bit Linux game program that BudgieLoader runs (WMMT3DX+'s `main` keeps 61,106 C++ names; OutRun 2's `jennifer` isn't stripped at all): by name, by address, or reads floats from the file. Its docstring has the objdump line for reading a function | 11 November |

Such a program is mapped at its own fixed addresses, so a global's address is a TP Telemetry row with Module blank.
Needs binutils (`readelf`, `c++filt`, `objdump`).

## Exe reading (`exe/`)

The scripts used on gti3japkey.exe, the Initial D 6 exe (8 November), Battle Gear 4's game.exe (9 November), the Mario Kart exes, GRID.exe and Sega Rally 3's Rally.exe (12 November: `fstart.py`, `regs.py`, `cowrite.py`, `vtables.py` added), and Initial D Zero's 64-bit exe (16 November: every script reads 64-bit exes too, from `base.txt` that `dis.py` writes); see `exe/README.md`.


## SH-4 and Flycast save states (`sh4/`, 17 November 2026)

For NAOMI and NAOMI 2 games in Flycast, whose program is on a GD-ROM and so only readable from the running game.
Needs capstone 5.

| Script | Use |
|---|---|
| `sh4/flystate.py <state> <prefix>` | Unpacks a Flycast v2.5 save state: `<prefix>.png` (the screenshot in the state, with the HUD), `.raw` (the whole state) and `.ram` (the game's 32 MB of RAM, 0x0C000000 first). |
| `sh4/sh4dis.py <ram> dis|fn|lit ...` | Disassembles SH-4 code from the RAM image at a game address, showing the constants it loads; `lit` finds where a 32-bit value is stored (code that refers to an address). |

## Supermodel (`supermodel/`, 18 November 2026)

For Model 3 games in Supermodel (Scud Race; Daytona USA 2 Power Edition, 18 November 2026: claude/SMDAYTO2PE-supermodel-20261118.md). The values are found by running Supermodel itself, built
from the same source as Alexis's `supermodel.exe` with a small logger added, on her ROM set, headless (Xvfb, Mesa's software
OpenGL), driving races with keys sent by `xdotool`, and comparing a per-frame RAM log with screenshots. Needs Python 3 with
numpy, capstone 5; to run the emulator, a Linux build of Supermodel (`apt-get install libsdl2-dev libsdl2-net-dev
libgl1-mesa-dev libglu1-mesa-dev zlib1g-dev xvfb xdotool imagemagick`, then `make -f Makefiles/Makefile.UNIX`) with the
patch applied. claude/SMSCUD-supermodel-20261118.md has the whole method.

| Script | Use |
|---|---|
| `tptanalysis.patch` | For Supermodel's `Src/Model3/Model3.cpp` (git 0b82a98): with `SM_DUMP_DIR` set, writes `ranges.bin` (every frame: frame number, time, the drive-board and lamp bytes, and the RAM ranges listed in `ranges.txt`), a whole-RAM dump `f<frame>.bin` whenever a file `trigger` appears (or every `SM_DUMP_EVERY` frames), `wwatch.out` (which PowerPC instructions wrote the RAM ranges in `wwatch.txt`), and pokes the words in `poke.txt` each frame while it exists. |
| `runsm.sh <dump folder> <every> [options]` | Runs the patched Supermodel headless on display :99 (`SMRUN` = the folder with `supermodel`, `Config`, `Assets`, `ROMs`, `NVRAM`; `GAME` = the ROM zip, `scud.zip` unless set, e.g. `dayto2pe.zip`). |
| `key.sh <key> [seconds]`, `shot.sh <png>`, `snaps.sh <out> <count> <seconds>` | A key press in the emulator's window; a screenshot; screenshots each with a whole-RAM dump (`SNAPD` = the dump folder). |
| `drive.py <out> <script>` | Plays a timed key script and takes a screenshot every second, logging the wall-clock times. |
| `shotframes.py <capture folder> <dump folder>` | Which logged frame each screenshot and key press fell on. |
| `hudsheet.sh <capture folder> <out.png> <crop> <shot>...` | A labelled contact sheet of screenshots (shot and frame). |
| `rlog.py` | Reads `ranges.bin`: a series per frame for any game address, as the PowerPC sees it (bytes at A ^ 3, 16-bit at A ^ 2 in Supermodel's RAM). |
| `findval.py`, `exact.py`, `exactfull.py` | Finds RAM values proportional or equal to values read off the screen, in whole-RAM dumps or the log. |
| `aipath.py`, `autopilot.py` | Records the computer cars' paths from a log, then drives the player's car along them, with timed events (brake, let go of the wheel, steer into a wall, poke extra time). Scud Race's car record; `GAME=d2` for Daytona 2 PE's (18 November). `MANUAL=1` changes gear itself at `UP`/`DOWN` revs (6800/3800 unless set). |
| `menu_d2mt.sh` | Daytona 2 PE from the attract mode: coin, start, Beginner, NORMAL car, MANUAL (holding the wheel right while choosing selects it). |
| `fixture.py` | Writes a replay fixture for the plugin's tests from a log and a profile. |
| `capfixture.py <recording.csv> <profile> <step> <out.csv.gz> [max revs]` | Writes a replay fixture from one of Alexis's SMSCUD recordings (SMDAYTO2PE with `PRE=SMDAYTO2PE`, 18 November, with the drive commands as `out_RawDrive`; maps the 18:57 recording's two revs columns), raw values worked back from the recorded rows (Max speed 350; Max revs 7500 unless given), marks kept. |
| `buildcrom.py <rom folder> <out> [files]` | Interleaves the four program ROMs into the 2 MB fixed program (0xFFE00000 up) as the PowerPC sees it. |
| `ppcidx.py <crom> <base> <out.pkl>`, `ppcat.py`, `sda.py` | Disassembles PowerPC code and finds code using a global through `r13` (Scud Race's small-data base 0x108000; `R13` for another game) or a `lis`/`addi` pair. |

## Unreal Engine 4 exes (`ue4/`, 18 November 2026)

For 64-bit UE 4.17 games (Sega World Drivers Championship's `Todoroki-Win64-Shipping.exe`; Initial D The Arcade is UE4 too).
Needs `pefile`, `capstone` and `numpy`. Copy the exe to `bin.exe` in a working folder and run from there with `python3 -I`.
UE4 shipping exes have no RTTI for the game's classes, but the engine's reflection data names them: every class's properties
(name, offset, type) are built in its `Z_Construct_UClass_*` function, and every native function sits in a table of ANSI
name and exec-function pairs. claude/SWDC-exe-20261118.md has the method.

| Script | Use |
|---|---|
| `ripref.py <exe> <rva>...` | Code using a global through RIP-relative addressing (the first run writes an index, `<exe>.ripidx.npz`, 2 s). |
| `ripnear.py <exe> <rva> [back]` | Globals referenced just below an address: finds the object or array a static address sits in. |
| `fdis.py <exe> <rva>...` | Disassembles the `.pdata` function containing an address, showing the strings its `lea`s point to. |
| `uprops.py <exe> <Class>...` | A class's reflected properties: name, offset, allocation size (the property type: 0x78 float/int, 0x80 object, struct, array, delegate). Its two skipped helper calls are SWDC's addresses. |
| `csizes.py <exe> [regex]` | Every class's size and `GetPrivateStaticClass` (from its call to `GetPrivateStaticClassBody`; SWDC's address). |
| `natives.py <exe> [rva range]` | The native function tables: `Name=exec function` per class (the exec thunk calls the C++ function last). |
| `callers.py <rva>...` | Direct calls and jumps to a function (reads `bin.exe`). |
| `fieldfn.py <exe> <0xoff>...` | Functions using every one of some structure offsets. |
| `wnear.py <wide strings file> <before> <after> <name>...` | The reflected names around a class name (from `strings -el -t x`). |
| `swdc_slots.py`, `swdc_carfields.py` | SWDC's data model: which model slot each object reads (the registry adds a constant to the model), and each UCarLibrary getter's record offset (needs `natives.txt` from `natives.py`). |

## Sega World Drivers Championship (`swdc/`, 19 November 2026)

| Script | Use |
|---|---|
| `capfixture.py <recording.csv> <out.csv.gz> [from_s] [to_s] [max_speed]` | A replay fixture from one of Alexis's SWDC recordings: memory rows raw (speed2 times the recording's Max speed, 230 unless given; recordings with the new row names read as they are; `revs_game` as `revs_record`, `position` as `overall`, `class_rank` as `position`), TeknoParrot slots, USB force, spring, steering and brake. |

