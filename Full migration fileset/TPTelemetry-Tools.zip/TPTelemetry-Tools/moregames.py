"""More game profiles, and rows added to existing ones, from three sources (2 November 2026):

* MasterRaver's TeknoParrot cheat tables (the 04.10.26 pack Alexis supplied). Only telemetry-like
  values are taken (speed, revs, gear, timers, nitro, damage, pedals); cheats, scores and cosmetics
  are left out. Where a table gives a value a profile already has at a different address, the new
  row gets the next free name (speed2, gear2...) and nothing existing is changed.
* OutputBlaster games not yet in the pack (lamps only; their force feedback comes from hooks).
* Emulators the FFB Arcade Plugin supports, where TP Telemetry can read the same thing:
  - Model 2 Emulator (memory: the force byte in the emulator, OutputBlaster's lamps);
  - Supermodel, MAME and Flycast (their network outputs, which TP Telemetry already receives).

Facts only (addresses, encodings, output names); no code from either project or the tables.
memgames.py calls add(P, profile, helpers) after its own games, before writing the pack.
"""

UNVERIFIED_OR2 = " From the FFB Arcade Plugin's reading of this game."
CT = " From MasterRaver's TeknoParrot cheat table (04.10.26 pack). Not yet checked in a recording."

def add(P, H):
    """P: memgames' profile list. H: memgames' helpers (row, mem, calc, force_tail, accel, profile, hold0, MAIN)."""
    mem, calc, profile, hold0, force_tail, accel, MAIN = H['mem'], H['calc'], H['profile'], H['hold0'], H['force_tail'], H['accel'], H['MAIN']
    by = {p['Prefix']: p for p in P}

    def same_read(a, b):
        return a['Source'] == b['Source'] == 'Memory' and (a['Module'], a['BaseOffset'].upper(), a['Offsets'].upper().replace(' ', ''), a['Type']) == \
               (b['Module'], b['BaseOffset'].upper(), b['Offsets'].upper().replace(' ', ''), b['Type'])

    def extend(prefix, rows):
        """Adds rows to a profile; a name already taken by a different value gets the next free number."""
        p = by[prefix]
        renamed = {}
        for r in rows:
            for k, v in renamed.items():   # computed rows refer to renamed reads by their new names
                if r['Formula']:
                    import re
                    r['Formula'] = re.sub(r'\b' + k + r'\b', v, r['Formula'])
            names = {v['Name'] for v in p['Variables']}
            old = next((v for v in p['Variables'] if v['Name'] == r['Name']), None)
            if old is not None and same_read(old, r):
                if 'cheat table' not in old['Notes']:
                    old['Notes'] += " The same address is in MasterRaver's TeknoParrot cheat table (04.10.26 pack)."
                continue
            if old is not None:
                base, i = r['Name'], 2
                while f'{base}{i}' in names: i += 1
                renamed[base] = f'{base}{i}'
                r['Name'] = f'{base}{i}'
            p['Variables'].append(r)

    # ------------------------------------------------------------ OutRun 2 SP SDX: the table, then the recordings
    # One profile (the Legacy copy was removed on 2 November at Alexis's request).
    or2_rows = lambda: [
        dict(mem('select_timer', 'Int16', '082932B0', 'Car select countdown (absolute address); the table holds it at 1200.' + CT, module=''), Enabled=True),
        mem('stage_timer', 'Int32', '0830B748', 'Stage time left, raw (absolute address); the table holds it at 5940.' + CT, module=''),
        dict(mem('vel_x', 'Float', '08279F4C', "Car velocity, first axis (absolute address)." + CT, module=''), Enabled=False),
        dict(mem('vel_y', 'Float', '08279F50', "Car velocity, second axis: the table's speed boosts push this one, so it may be forwards." + CT, module=''), Enabled=False),
        dict(mem('vel_z', 'Float', '08279F54', "Car velocity, third axis." + CT, module=''), Enabled=False),
        calc('speed', 'sqrt(vel_x * vel_x + vel_y * vel_y + vel_z * vel_z)',
             "Speed from the car's velocity, in the game's own units (not km/h; compare with the speedo row in a recording to find the scale). "
             "In Alexis's recordings of 2 November 2026 the velocity addresses read nonsense (not tied to speed), so this row doesn't work in her build."),
    ]
    extend('OUTRUN2SP', or2_rows())
    # From Alexis's two recordings (2 November 2026, 15:30 and 15:38), with her notes for the second.
    R = " From Alexis's recordings of 2 November 2026."
    OR2_KMH = 0.7   # km/h per game unit: the speedo shows about 300 km/h at the top, where the speed row reads about 431 (Alexis)
    extend('OUTRUN2SP', [
        calc('time_left', 'stage_timer / 60', 'Stage time left, seconds: the stage timer counts down 60 a second (frames).' + R),
        calc('checkpoint', 'maxw(delta(stage_timer) > 60 && prev(stage_timer) > 0, 1)', '1 for 1 s after a checkpoint: the stage timer jumps up when time is added.' + R),
        calc('wall_hit', 'maxw(delta(side_hit_count) > 1000000, 0.3)',
             "1 for 0.3 s when a wall hit starts. side_hit_count is really a countdown the game starts at each wall hit (about 1.1 s), so only its jump up counts: all ten walls in the two recordings, nothing else." + R),
        calc('wall_side', 'wall_hit * sign(maxw(side_hit_dir == 2, 0.4) - maxw(side_hit_dir == 1, 0.4))',
             'Side of the wall hit, +1 right, -1 left, 0 unknown. side_hit_dir reads 1 near a left-hand wall and 2 near a right-hand one, '
             'from up to 0.1 s before the hit to 0.4 s after; at one hit it came only 0.02 s after the start, and at one (a right-hand wall) not at all. '
             'So this takes the side seen in the last 0.4 s. The wheel force (USB capture) had the right side at all twelve walls.' + R),
        calc('g_fast', 'ema(slope(speed * max_speed, 0.05), 0.02) / 3.6 / g', 'Quick longitudinal G, for spotting hits (speed x Max speed is km/h, 0.7 a game unit).'),
        calc('hard_hit', 'maxw(g_fast < -21 && speed * max_speed > 14, 0.3)',
             "1 for 0.3 s when the car loses speed at more than 21 G: the bus, the semitrailer and the midsize car (24 to 46 G), which crash_count misses. "
             "Braking stays under 7 G, but the speed reading dips at 14 to 18 G as some drifts start, so the line sits above that. Wall hits are 9 to 17 G (wall_hit catches them). "
             "Not when the speed reads under 20 (14 km/h): after the flip the game puts the car back on the track at 0, which isn't a hit." + R),
        calc('off_road', 'surface == 4 || surface == 8 || surface == 16 || surface == 8192',
             'On grass (4, with 8192 at its edge) or sand (8); 16 is the FFB plugin\'s third rough surface.' + R),
        calc('rumble_strip', 'surface == 1024 || surface == 2048',
             'On a striped verge (1024) or the edge of sand or a verge (2048). On the road surface reads 2.' + R),
        # Two more values the FFB Arcade Plugin's OutRun 2 "fake" mode reads but doesn't use.
        dict(mem('ffb_wall', 'Int32', '08273FAC', "Read by the FFB Arcade Plugin's OutRun 2 fake mode as 'ffwall', but not used there. Meaning unknown: recorded so a capture can show it.", module=''), Enabled=False),
        dict(mem('ffb_float', 'Float', '08273AD4', "Read by the FFB Arcade Plugin's OutRun 2 fake mode, but not used there. Meaning unknown: recorded so a capture can show it.", module=''), Enabled=False),
    ])
    # Alexis, 2 November 2026 (17:51): the speedo shows about 300 km/h at the top; Max speed 280 km/h; Max revs about 9300.
    o = by['OUTRUN2SP']
    o['MaxSpeed'] = 280.0   # km/h (Alexis's choice); Car_speed is the speedo's km/h since 11 November 2026
    o['MaxRevs'] = 9300.0
    vs = {v['Name']: v for v in o['Variables']}
    vs['speed']['Notes'] = ("Speed in the game's own units (car_work +330; the FFB Arcade Plugin calls it the speedo). Not km/h: it reads about 431 "
                            "where the speedo shows about 300 km/h (Alexis, 2 November 2026), so one unit is 0.7 km/h, as used here; the "
                            "speedo itself (speed_kmh) reads 1.8% more (11 November 2026). Times 0.7, over Max speed (280 km/h).")
    vs['speed']['Formula'] = f'value * {OR2_KMH} / max_speed'
    vs['accel_g']['Formula'] = 'ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g'
    vs['accel_g']['Notes'] = ("Longitudinal G from speed (speed x Max speed undoes the division, in km/h). "
                              "+ speeding up, - slowing down.")
    vs['transmission']['Notes'] = ("Gearbox: 1 manual, 0 automatic (Alexis's recordings, 2 November 2026). "
                                   "The FFB plugin only shifts for you when this is 1.")
    vs['gear']['Notes'] = ("Gear, 1 to 5 (absolute address). On manual the game shifted up one at two wall hits in 3rd and 4th, 0.02 to 0.03 s "
                           "after the hit; after the flip (automatic) it dropped to 1 in 0.05 s.")
    vs['side_hit_count']['Notes'] = ("A countdown the game starts at each wall hit (jumps to about 2,367,000, back to 0 in about 1.1 s); "
                                     "the speed reading freezes for the first 0.5 s of it. Use wall_hit." + R)

    # From the game itself (Alexis's `jennifer`, 11 November 2026). OutRun 2 SP is a 32-bit Linux program that BudgieLoader
    # maps at its own fixed addresses, and it isn't stripped: every global and function has its name. The player's car is
    # the first of 24 tagEVWORK_CAR records (0x10E0 bytes each) from evwork_car, 0x08279DA0, which the gear (+3C0), revs
    # (+3D4), surface (+400) and wall rows above already read. Details in claude/OUTRUN2SP-exe-20261111.md.
    J = " From the game's own code (its `jennifer`, 11 November 2026). Not yet checked in a recording."
    JOK = " From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06."
    def jm(name, typ, base, notes, formula='', on=True, ok=False):
        return dict(mem(name, typ, base, notes + (JOK if ok else J), module='', formula=formula), Enabled=on)
    def jc(name, formula, notes, on=True, ok=False):
        return dict(calc(name, formula, notes + (JOK if ok else J)), Enabled=on)
    extend('OUTRUN2SP', [
        jm('speed_kmh', 'Float', '0827A150', "The speedo's km/h (car +3B0): what DispSpeedMeter prints (times 0.6214 when the cabinet is set "
           "to mph). The game works it out from the car's speed (+3A0, metres a frame) x 216.72 x the car's own speedo factor, capped at 300 "
           "for some cars. The speed row is another value, about 0.7 km/h a unit: the speedo read 1.018 x that through the race "
           "(1.016 to 1.033 by speed), up to 312 km/h. Feeds Car_speed.", ok=True),
        jm('drift', 'Byte', '0827AB86', "1 while the game counts the car as drifting (car +DE6, HamIsDrift): a brake tap or a lift and "
           "re-press of the throttle starts a 40-frame window, which the slip angle keeps open. 15 drifts of 2 to 10 s in the "
           "recording, at 60 to 78 degrees.", 'value > 0 && value < 128', ok=True),
        jm('drift_angle', 'Int16', '08279DF6', "Slip angle of the rear tyres, degrees (car +56: the average of the two rear tyres' angles, "
           "in 65536ths of a turn), + a right-hand drift (Alexis: right turns at 93 and 226 s read +66 and +72, left turns at 133 and "
           "285 s -75 and -60, in her recording of 11 November 2026, 19:06). The game keeps a drift going above about 4 degrees. "
           "0 under 10 km/h, where the angle of a car barely moving swings to 180.", 'speed_kmh > 10 ? value * 360 / 65536 : 0', ok=True),
        jm('front_slip', 'Int16', '08279DF4', "Slip angle of the front tyres, degrees (car +54); the deluxe cabinet's wheel motor "
           "presets are chosen from it.", 'value * 360 / 65536', on=False),
        jm('slipstream', 'Float', '0827ACB8', "Slipstream strength, 0 to 1 (car +F18, CheckSlipStream): behind another car, more the closer "
           "and straighter. The speedo shows its slipstream sign above 0.18: 50 times in the recording, up to 12 s."),
        jm('shift_warning', 'Int32', '0827ACCC', "1 while the SHIFT UP warning shows (car +F2C, CheckShiftWarning): after 3 s at nearly full "
           "throttle above the gear's shift speed, not drifting, for up to 5 s."),
        jm('crash_flags', 'Byte', '0827A244', "The car's crash motion (car +4A4, SetCrushMotion): bit 1 for the motion's first frame, "
           "bit 2 while it runs, bits 4 to 64 its kind (kept afterwards).", on=False),
        jc('crash_motion', 'band(crash_flags, 3) != 0', "1 while the game plays a crash motion on the car (a spin, flip or knock from "
           "traffic, a wall or a bomb): in the recording 1.5 s for two traffic crashes (kind 7) and 2.5 s for a wall crash (kind 1), "
           "with bit 1 set for a frame and bit 2 throughout.", ok=True),
        jc('crash_kind', 'crash_motion ? floor(band(crash_flags, 124) / 4) : 0', "Which crash motion, 0 to 19: 7 running into the back "
           "of a truck or bus with the rear wheels leaving the ground, 1 a big wall crash with the car flying and flipping (Alexis, "
           "recording of 11 November 2026, 19:06); 3 is the other car-hit motion in the code.", ok=True),
        jc('crash_air', 'crash_motion ? (crash_kind == 1 ? 1 : (crash_kind == 7 && minw(crash_motion, 0.6) == 0 ? 0.5 : 0)) : 0',
           "The car off the ground in a crash: 1 through a flipping crash (kind 1, about 2.5 s), 0.5 for the first 0.6 s of a "
           "rear-end crash that lifts the rear wheels (kind 7). Feeds Car_airborne.", ok=True),
        jm('main_mode', 'Int32', '08303CF4', "The game's main sequence (current_mode, GetModeStr): 3 attract, 4 title, 9 menu, 10 car and "
           "music select, 13 start, 14 restart, 15 GAME (racing), 16 give up, 17 GOAL, 18 TIME UP, 20 result, 21 continue, 22 ending, "
           "23 route map, 24 time ranking, 26 game over."),
        jm('game_mode', 'Int32', '08303D00', "Which game (GetGameMode): 0 Time Attack, 1 OutRun, 2 Heart Attack, -1 in the menus "
           "(Alexis's recordings of 11 and 12 November 2026); the attract demo reads 0 or 1.", ok=True),
        jm('observer_flag', 'Byte', '0830B740', "The race's events (observer_flag): 1 time up, 4 goal; 2 and 8 for one frame at a stage "
           "gate; 64 and 32 for one frame twice in each stage, about 45 and 13 s before the gate: 32 brings up the fork's \"easy\" "
           "arrow, 64 shows nothing (Alexis, 11 November 2026). 64 came 12 to 15 s into stage 1 in OutRun, Time Attack and Heart "
           "Attack alike (12 November 2026), with nothing on screen; in Heart Attack the passenger's request may become active "
           "about half a second before it.", on=False),
        jc('fork_sign', 'maxw(band(observer_flag, 32) != 0, 3)', "1 for 3 s from when the game brings up the fork's \"easy\" arrow, "
           "about 13 s before the end of each stage (observer_flag 32; Alexis matched it at 83.6 s in her recording of 11 November "
           "2026, 19:06, and says 3 s is about how long it stays up).", ok=True),
        calc('shift_light', 'rpm * max_revs >= 8270', "The redline light on the rev dial: on from 8,270 RPM. From Alexis's video on four "
             "cars (11 and 12 November 2026): the 250 GTO, 512 BB and Enzo (2nd gear) lit at 8,260 to 8,270, the Testarossa at "
             "8,370 (TT 0:07.375, 3rd), the Enzo in 1st 0.3 s after the revs passed it. The game draws a dial per car (ten dial "
             "designs, each to 10,000 RPM, from the car's dial type at car +0A and smoothed display revs at car +3C4), so the light "
             "may differ a little by car; good enough as an indication (Alexis)."),
        # Raw reads for the next recordings (12 November 2026): the side of traffic hits without USB, each car's own rev
        # limit for the redline light, and the course event byte behind observer_flag 32 and 64. Unticked and unused, so
        # they stay as their own rows.
        jm('hit_dir', 'Byte', '0827AE7E', "Raw: the side code of the last hit on another car (car +10DE), which SetCollisionImpactPlcar "
           "stores from CheckWhichSideColiHappen2 at every car hit and holds until the next: 4 right, 8 left (checked against the "
           "wheel force in Alexis's recordings of 12 November 2026), with 1 or 2 added (front and back of that side, or a "
           "straight hit: 2 alone gave no side). Used by car_hit and car_side.", on=False),
        jm('hit_box1', 'Int32', '0827A468', "Raw: contact word (car +6C8), set for a moment when another car hits the right-hand side "
           "(with hit_box2; 12 November 2026, against the wheel force). Used by car_hit and car_side.", on=False),
        jm('hit_box2', 'Int32', '0827A46C', "Raw: contact word (car +6CC), right-hand side, as hit_box1.", on=False),
        jm('hit_box3', 'Int32', '0827A470', "Raw: contact word (car +6D0), set for a moment when another car hits the left-hand side "
           "(with hit_box4).", on=False),
        jm('hit_box4', 'Int32', '0827A474', "Raw: contact word (car +6D4), left-hand side, as hit_box3.", on=False),
        jc('car_hit', 'maxw(valid(hit_box1, 0) || valid(hit_box2, 0) || valid(hit_box3, 0) || valid(hit_box4, 0) || '
           '(valid(hit_dir, 0) != valid(prev(hit_dir), 0) && valid(hit_dir, 0) != 0), 0.3)',
           "1 for 0.3 s when another car hits: a contact word set, or the side code changing. In Alexis's recordings of 12 November "
           "2026 it caught all 16 car hits, one (at 92.9 s in the 10:05 recording) that nothing else did.", ok=True),
        jc('car_side', 'maxw(valid(hit_box1, 0) || valid(hit_box2, 0), 0.4) ? 1 : (maxw(valid(hit_box3, 0) || valid(hit_box4, 0), 0.4) ? -1 : '
           '(car_hit ? (band(valid(hit_dir, 0), 4) != 0 ? 1 : (band(valid(hit_dir, 0), 8) != 0 ? -1 : 0)) : 0))',
           "Side of a hit by another car, +1 right, -1 left, without USB capture: the contact words, or else the side code. It "
           "matched the wheel force's side at every car hit that had one in Alexis's recordings of 12 November 2026.", ok=True),
        dict(mem('rev_limit', 'Float', '0827A20C', "Raw: this car's rev limit, RPM (car data +1068 through car +46C, kept in tens like "
             "the revs: CalcRearWheels compares the revs with it). To compare with the redline light (8,380 on Alexis's car) across "
             "cars." + J, module='', offsets='1068', formula='value * 10'), Enabled=False),
        dict(mem('rev_1030', 'Float', '0827A20C', "Raw: a second rev value from the car data (+1030, in tens), which AccelOperation "
             "compares with the revs. Meaning to find." + J, module='', offsets='1030', formula='value * 10'), Enabled=False),
        jm('course_event', 'Byte', '0830B744', "Raw: the course event byte Observer_Ctrl turns into observer_flag 32 (the fork's easy "
           "arrow) and 64 (nothing on screen in OutRun mode); bits 1 to 32 come in pairs (requested, done). 8 comes with observer "
           "64, about 13 to 15 s into stage 1 in all three modes.", on=False),
        jc('goal', 'band(observer_flag, 4) != 0', "1 from the moment the car crosses the finish line of the last stage (CheckGoal)."),
        jc('time_up', 'band(observer_flag, 1) != 0', "1 once the time has run out (CheckGameTimer)."),
        jc('racing', 'main_mode == 15 && !goal && !time_up', "1 from GO to the finish line or time up: the game's main sequence in GAME, "
           "with no goal or time up. Not in the attract mode (sequence 3). In the recording: GO at 34.18 s (after 13 s of the start "
           "sequence, 13), the finish line at 331.90 s (her mark 332.07).", ok=True),
        jm('stage', 'Int32', '0830B8CC', "Stage, 1 to 5: the stage gates passed (check_point_count) plus 1.", 'value + 1', ok=True),
        jm('race_time', 'Int32', '0830B74C', "Race clock, seconds (total_timer, 60 a second): 4:55.75 at the finish line.", 'value / 60', ok=True),
        jm('stage_time', 'Int32', '0830B750', "This stage's time so far, seconds (now_lap_time; restarts at each stage gate).", 'value / 60', ok=True),
        jm('last_stage_time', 'Int32', '0830B754', "The last stage's time, seconds (prev_lap_time).", 'value / 60', on=False),
        jm('hearts', 'Int32', '082FCD04', "Heart Attack: the hearts won so far (GetTrueHeartValue keeps them x 10,000). In Alexis's "
           "Heart Attack run of 12 November 2026 (10:09) it went 0, 172 and 397 as she finished two challenges (TT 0:34.05 and "
           "0:46.73: 172 hearts, then 225 more); the display ticks up to it over a moment.", 'value / 10000', ok=True),
        jc('challenge_won', 'maxw(delta(hearts) > 0, 1)', "Heart Attack: 1 for 1 s when a challenge is finished and its hearts "
           "are awarded (the hearts total jumps).", ok=True),
        jm('paused', 'Byte', '08303D09', "The game's pause flag (pause_flag).", on=False),
    ])
    vs = {v['Name']: v for v in o['Variables']}
    vs['in_race']['Notes'] = ("The HUD's navigation display flag (navipub_disp_flg, absolute address), on during a race and switched off by "
                              "the GOAL and TIME UP displays. `racing` is the game's own race state (11 November 2026)." + UNVERIFIED_OR2)

    # ------------------------------------------------------------ Initial D The Arcade (64-bit, Unreal)
    extend('IDTA', [
        mem('speed', 'Int32', '3A62C60', 'Speed, from the table\'s "output pointers" (probably km/h, whole numbers).' + CT, offsets='40, 1B0, 20, 20, 20, 230, 26C'),
        mem('rpm', 'Int32', '3A62C60', 'Engine RPM, from the table\'s "output pointers".' + CT, offsets='40, 1B0, 20, 20, 20, 230, 3AC'),
        mem('timer', 'Float', '3EBFF10', 'Time left on the clock, seconds.' + CT, offsets='128, 348, 22C'),
        accel(),
    ])
    for pre, disp, timer in [('IDTA21', 'Initial D The Arcade v2.1 (Season 3)', ('3EAF350', '128, 348, 22C')),
                             ('IDTAS4', 'Initial D The Arcade Season 4 v2.5', ('3ECD6D0', '128, 348, 22C')),
                             ('IDTAS5V321', 'Initial D The Arcade Season 5 v3.21 (ARCADEZONE.CN)', ('3F74910', '128, 348, 22C'))]:
        P.append(profile(pre, disp, [mem('timer', 'Float', timer[0], 'Time left on the clock, seconds. The only driving value in this version\'s table.' + CT, offsets=timer[1])]))
    P.append(profile('IDTAS5', 'Initial D The Arcade Season 5 v3.10', [
        mem('speed', 'Int32', '3A4A498', 'Speed, from the table\'s "output pointers" (probably km/h, whole numbers).' + CT, offsets='800, 8, 2C8, 3A8, 230, 27C'),
        mem('rpm', 'Int32', '3A4A498', 'Engine RPM, from the table\'s "output pointers".' + CT, offsets='800, 8, 2C8, 3A8, 230, 3C4'),
        mem('timer', 'Float', '3F3EB90', 'Time left on the clock, seconds.' + CT, offsets='128, 348, 22C'),
        accel(),
    ]))

    # ------------------------------------------------------------ Initial D Zero v2.30
    # Race, car and event rows from the game's own code (16 November 2026, id0_rows below); the cheat table's two other
    # reads are kept, unticked, under names that say what the table uses them for.
    by['ID0V230']['MaxSpeed'] = 220.0   # Alexis's recordings, 16 November 2026: the Trueno reached 203 km/h
    by['ID0V230']['MaxRevs'] = 8140.0    # the Trueno's limiter (as in ID6); the RX-7's is about 7,070
    extend('ID0V230', id0_rows() + [
        dict(mem('menu_timer', 'Float', '18B4E20', "The menus' countdown, seconds (the table's \"Ttl_Tmr\", which it holds at 99 for "
                 "its \"Unlimited Menu Timer\")." + CT, offsets='8, 18, 0, 1C'), Enabled=False),
        dict(mem('hud_meter', 'Float', '18B4E18', "The table's \"Steering\" read, which its \"Steering Wheel / Challenge Meter Always "
                 "Empty / Full\" script holds at 0: a value of the race display (the HUD object's data +94), not the steering input "
                 "(that is `steer`)." + CT, offsets='0, 94'), Enabled=False),
    ])

    # ------------------------------------------------------------ Maximum Tune 6, 6R, 6RR, 6RR Plus
    def pedals(a1, a2, b1, b2):
        return [mem('throttle', 'Int32', a1, 'Accelerator as the game sees it, raw (range still to be checked).' + CT),
                mem('throttle2', 'Int32', a2, 'Accelerator, second copy in the table, raw.' + CT),
                mem('brake', 'Int32', b1, 'Brake as the game sees it, raw (range still to be checked).' + CT),
                mem('brake2', 'Int32', b2, 'Brake, second copy in the table, raw.' + CT)]
    GEAR = 'Gear as the game stores it (on WMMT5DX+ the stored value is the gear, 0 neutral; to be checked here).'
    extend('WMMT6', [
        mem('gear', 'Int32', '1E61874', GEAR + CT),
        mem('race_time', 'Float', '1E5B894', 'Race timer, seconds ("GTimer1" in the table).' + CT),
        mem('power', 'Int32', '1E183F8', 'Power tune level.' + CT, offsets='2D8, 74'),
        mem('handling', 'Int32', '1E183F8', 'Handling tune level.' + CT, offsets='2D8, 80'),
    ])
    R6 = " The 6R table lists the same speed and RPM addresses as the 6RR table, so these may belong to 6RR only."
    extend('WMMT6R', [
        mem('gear', 'Int32', '206E494', GEAR + CT),
        mem('race_time', 'Float', '20684A4', 'Race timer, seconds ("GTimer1" in the table).' + CT),
        mem('timer', 'Int32', '1FF6F10', 'Timer, raw ("TTimer1" in the table).' + CT, offsets='8, 18'),
        mem('power', 'Int32', '2022A68', 'Power tune level.' + CT, offsets='2E8, 74'),
        mem('handling', 'Int32', '2022A68', 'Handling tune level.' + CT, offsets='2E8, 80'),
        mem('speed', 'Int32', '1F2612C', 'Speed, km/h.' + CT + R6),
        mem('rpm', 'Float', '29B3E0', 'Engine RPM, from the game\'s Wg6Enma DLL.' + CT + R6, module='Wg6Enma_Release_IDL0.dll', offsets='368'),
    ] + pedals('206D5E4', '206D6F4', '206D990', '206E568'))
    extend('WMMT6RR', [
        mem('speed', 'Int32', '1F2612C', 'Speed, km/h.' + CT),
        mem('rpm', 'Float', '29B3E0', 'Engine RPM, from the game\'s Wg6Enma DLL.' + CT, module='Wg6Enma_Release_IDL0.dll', offsets='368'),
        mem('gear', 'Int32', '1F48F74', GEAR + ' The profile\'s first gear row uses the 6R address.' + CT),
        mem('race_time', 'Float', '29B4F8', 'Race timer, seconds ("GTimer1" in the table), from the Wg6Enma DLL. The profile\'s first race_time uses the 6R address.' + CT, module='Wg6Enma_Release_IDL0.dll'),
        mem('timer', 'Int32', '1ED3DF0', 'Timer, raw ("TTimer1"; the FANTASY 6RR table has it behind 1FF6F10 instead).' + CT, offsets='8, 18'),
        mem('power', 'Int32', '2022A68', 'Power tune level (same address as the 6R table).' + CT, offsets='2E8, 74'),
        mem('handling', 'Int32', '2022A68', 'Handling tune level (same address as the 6R table).' + CT, offsets='2E8, 80'),
    ] + pedals('1F480C4', '1F481D4', '1F48470', '1F49048'))
    P.append(profile('WMMT6RRP', 'Wangan Midnight Maximum Tune 6RR Plus v4.00.13', [
        mem('gear', 'Int32', '1FDC374', GEAR + CT),
        mem('race_timer', 'Float', '29F658', 'Race timer, seconds ("GTimer1"), from the Wg6Enma DLL. Not called race_time until it is checked: that name would switch the effects on and off with it.' + CT, module='Wg6Enma_Release_IDL0.dll'),
        mem('timer', 'Int32', '1F659D0', 'Timer, raw ("TTimer1").' + CT, offsets='8, 18'),
        mem('power', 'Int32', '1F93A78', 'Power tune level.' + CT, offsets='320, 74'),
        mem('handling', 'Int32', '1F93A78', 'Handling tune level.' + CT, offsets='320, 80'),
    ] + pedals('1FDB4C4', '1FDB5D4', '1FDB870', '1FDC448')))

    # ------------------------------------------------------------ Maximum Tune 5DX+: the "Output Blaster Support" script
    # A Cheat Engine Lua script Alexis supplied (2 November 2026) that copies race values into a block it
    # allocates. The block moves every time, so these read the script's sources instead. Its race
    # structure is the pointer at wmn5r.exe+1FD11B0, the one the checked gear row already uses (+398).
    OS = (" From MasterRaver's Outputs script (a Cheat Engine script Alexis supplied, 2 November 2026); the pointer at wmn5r.exe+1FD11B0 "
          "is the one the checked gear row uses. Not yet checked in a recording.")
    C3 = " Checked in Alexis's recording of 3 November 2026 (10:13)."
    extend('WMMT5DXP', [
        mem('speed', 'Float', '1FD11B0', 'Speed, km/h, to a fraction of a km/h: the game stores it in mm per second (the script multiplies by 0.0036). '
            'The speed row is the same speed in whole km/h (the speedo): this reads about 0.5 km/h above it and updates 60 times a second where the whole number changes only when it passes the next km/h. Feeds the common values (Car_speed, and Car_accel_g through accel_g). Divided by Max speed.' + OS.replace(' Not yet checked in a recording.', '') + C3,
            offsets='BEC', formula='abs(value) * 0.0036 / max_speed'),
        mem('rpm', 'Float', '1FD11B0', 'Engine RPM as a float. Not the same scale as the rpm row: it moves with rpm (same moments) but swings further, about 1.285 x rpm - 1920 (rpm2 8700 at the limiter in 2nd where rpm reads 8270; 4700 where rpm reads 5150). Feeds the common values (Car_rpm) since 3 November 2026 (Alexis\'s choice); the rpm row stays. Max revs 8900 suits this row: the limiter in 2nd, about 8700, is 97.8% of it. Divided by Max revs.' + OS.replace(' Not yet checked in a recording.', '') + C3, offsets='D94', formula='value < 0 ? 0 : value / max_revs'),
        mem('race_time', 'Float', '1FD11B0', 'Race clock, seconds (the script sends it in milliseconds). Read the same as the race_time row to the frame in the 3 November 2026 recording. Feeds in_race (Alexis\'s choice), falling back to race_time when it can\'t be read.' + OS.replace(' Not yet checked in a recording.', '') + C3, offsets='2E4'),
        mem('turbo', 'Float', '1FD11B0', 'Turbo gauge (the script shows it x 100): 1.5 on full throttle on this car, -0.5 off the throttle, dipping at hits and lifts.' + OS.replace(' Not yet checked in a recording.', '') + C3, offsets='3F0'),
        dict(mem('pedals_a', 'Int32', '1FD5904', 'Pedals as the game reads them: throttle in the low byte, brake in the third, each 0 to 85. The throttle and brake rows decode it.' + OS), Enabled=False),
        dict(mem('pedals_b', 'Int32', '1FD5A14', 'Second copy of the pedals (the script takes the higher of the two).' + OS), Enabled=False),
        calc('throttle', 'clamp(max(band(pedals_a, 255), band(pedals_b, 255)) / 85, 0, 1)', 'Throttle, 0 to 1 (the game reads 0 to 85). Matched the G25\'s throttle over USB.' + OS.replace(' Not yet checked in a recording.', '') + C3),
        calc('brake', 'clamp(max(bits(pedals_a, 16, 8), bits(pedals_b, 16, 8)) / 85, 0, 1)', 'Brake, 0 to 1 (the game reads 0 to 85).' + OS),
        dict(mem('progress', 'Float', '1FD11B0', 'How far along the course the car is, in road units (1000 a metre).' + OS, offsets='A78'), Enabled=False),
        dict(mem('start_ref', 'Float', '1FD11B0', 'Road position of the start line, road units.' + OS, offsets='158, 28'), Enabled=False),
        calc('distance', 'max((progress - start_ref) / 1000, 0)', 'Distance from the start line, metres: grew 1895 m in the recording, where the speed gives 1899 m.' + OS.replace(' Not yet checked in a recording.', '') + C3),
    ] + [dict(mem(f'order{i + 1}', 'Int32', f'{0x1FD17E0 + 4 * i:X}', f'Race order, place {i + 1}: 0 where the player is.' + OS), Enabled=False) for i in range(4)] + [
        calc('place', 'order1 == 0 ? 1 : (order2 == 0 ? 2 : (order3 == 0 ? 3 : (order4 == 0 ? 4 : 0)))',
             'Race position, 1 to 4 (0 if the player isn\'t in the order). Outside a race the order may read all 0, which gives 1. '
             'Read 1 throughout the 3 November 2026 recording (order 0, 1, 2, 3): still to be checked in a race with rivals.' + OS),
    ])
    # speed2 feeds the common values from 3 November 2026 (Alexis): smoother than the whole-km/h speed row, which stays.
    # valid() falls back to the speed row whenever speed2 can't be read (its pointer may be empty outside a race).
    w5 = {v['Name']: v for v in by['WMMT5DXP']['Variables']}
    w5['accel_g']['Formula'] = 'ema(slope(valid(speed2, speed) * max_speed, 0.1), 0.05) / 3.6 / g'
    w5['accel_g']['Notes'] = ('Longitudinal G from speed2 (km/h to a fraction, 60 times a second), or from the speed row when speed2 '
                              "can't be read; speed x Max speed undoes the division, so this stays in G. In the 3 November 2026 recording "
                              'it jittered about 0.07 G when accelerating steadily, against 0.1 G from the whole-km/h speed row. '
                              '+ speeding up, - slowing down.')
    # race_time2 drives in_race from 3 November 2026 (Alexis); race_time stays and is the fallback.
    w5['in_race']['Formula'] = 'valid(race_time2, race_time) > 0 && maxw(delta(valid(race_time2, race_time)) > 0, 0.1)'
    w5['in_race']['Notes'] = ('1 while the race clock is running: off before the start, after the finish line (results screen) and while '
                              "the game is frozen. Uses race_time2, or race_time when race_time2 can't be read (the two read the same "
                              'in the 3 November 2026 recording). Checked on WMMT5DX+ with race_time (1 November 2026).')

    # ------------------------------------------------------------ Sega World Drivers Championship: Alexis's table (3 November 2026)
    # SWDC.CT: revs (static), and speed/gear in two places each. Speed and gear read nonsense until the revs
    # reach 3000, when the autodrive starts before a session hands over control; with control the revs never
    # go below 3000 (brake held, standing still) and top out at 12000 (redline about 11800). She prefers
    # speed2 and gears2. Raw speed tops out about 87 where the speedo shows 220 km/h; her speedo readings
    # fit km/h = 2.0625 x raw + 0.005467 x raw^2 within 2.5 km/h (a straight line is out by up to 8).
    SW = " From Alexis's Cheat Engine table (SWDC.CT, 3 November 2026), version 2.30."
    SW19 = " Checked in Alexis's recording of 19 November 2026 (SWDC-11)."
    R3 = " Checked in Alexis's recordings of 3 November 2026 (17:59 to 18:06)."
    LIVE = ' 0 outside a race (see in_race): before then it reads nonsense.'
    extend('SWDC', [
        mem('revs', 'Float', '9EAF670', 'Engine RPM as the game stores it (the engine sound\'s feed): exactly 3000 when the session loads, frozen (about 9326) '
            'through the countdown to the rolling start, then 3000 to 12000 while driving (redline about 11800; it sits at 12000 on the limiter); '
            'it freezes at the finish line and keeps its last value in the menus and the attract mode, so this row reads 0 outside a race. '
            'Your car\'s record has no engine revs (revs_record).' + SW + R3 + SW19, formula='in_race ? value : 0'),
        calc('rpm', 'revs / max_revs', 'Engine RPM in a race (revs), 0 otherwise. Divided by Max revs (12200: the rev limiter effect, at 97%, '
             'starts about the 11800 redline).' + SW),
        mem('speed2', 'Float', '9D1AAE8', 'Speed in the game\'s own units (the table\'s speed2, which Alexis prefers): about 87 at the speedo\'s 220 km/h, '
            'not in proportion (see speed_kmh). Rises and falls in straight lines (the game\'s speed changes at fixed rates). Divided by Max speed (87).' + LIVE + SW + R3,
            offsets='DD0, 20, 298', formula='in_race ? value / max_speed : 0'),
        dict(mem('speed1', 'Float', '9E29F58', 'The table\'s other speed (speed1). Read nonsense in all four recordings of 3 November 2026 (values up to 10^38), so use speed2. Divided by Max speed.' + LIVE + SW,
                 offsets='98, 10, 188', formula='in_race ? value / max_speed : 0'), Enabled=False),
        mem('gear2', 'Int32', '9D1AAE8', 'Gear, 1 to 6 (the table\'s gears2, which Alexis prefers). The game has no neutral or reverse.' + LIVE + SW + R3,
            offsets='DD0, 20, 348', formula='in_race ? value : 0'),
        dict(mem('gear1', 'Int32', '9E29F58', 'The table\'s other gear (gears1). Read nonsense in all four recordings of 3 November 2026 (values up to 2 billion), so use gear2.' + LIVE + SW,
                 offsets='98, 10, 238', formula='in_race ? value : 0'), Enabled=False),
        calc('speed_kmh', 'speed2 * max_speed * (2.0625 + 0.005467 * speed2 * max_speed)',
             'Speed as the speedo shows it, km/h: fitted to 17 readings Alexis took off the speedo (0 to 220 km/h), within 2.5 km/h. '
             'The raw speed is not in proportion to the speedo (2.1 km/h a unit at low speed, 2.5 at the top). Read 183 where Alexis noted 183 km/h.' + SW + R3),
        calc('accel_g', 'minw(in_race, 0.3) ? ema(slope(speed_kmh, 0.1), 0.05) / 3.6 / g : 0',
             'Longitudinal G from speed_kmh (the speedo\'s km/h; the raw unit isn\'t one the G could be worked out from), 0 for the first 0.3 s of a race so '
             'the speed coming on doesn\'t read as a jolt. + speeding up, - slowing down.'),
        calc('hit', 'maxw(in_race && slope(speed_kmh, 0.05) / 3.6 / g < (brake > 0.5 ? -5 : -4), 0.3)',
             '1 for 0.3 s while the car loses speed at more than 4 G (5 G while braking): the game slows the car at a fixed 4.6 to 5.6 G for 0.1 '
             'to 0.4 s at wall hits and head-on car hits; hard braking reaches 4.0 G at 220 km/h (her 19 November race, TT 2:26.55), and '
             'grinding along a wall about 2 G. No side: car_contact gives the side of most hits.' + R3 + SW19),
    ])
    extend('SWDC', swdc_rows(mem, calc))
    by['SWDC']['MaxSpeed'] = 230.0    # km/h (18 November 2026: Car_speed is now the speedo's km/h; her table's raw 87 was the speedo's 220)
    by['SWDC']['MaxRevs'] = 12200.0   # tops out at 12000, redline about 11800: 97% of 12200 is 11834

    # ------------------------------------------------------------ Cruis'n Blast, Road Fighters 3D
    extend('CRUISNBLAST', [
        mem('nos', 'Int32', '08CCB27C', "Nitro bottles left (absolute address; the table's v1.25)." + CT, module=''),
        calc('boost', 'maxw(delta(nos) < 0, 2)', '1 for 2 s after a nitro bottle is used (the burst length is a guess).'),
        mem('timer', 'Float', '458538', 'Race timer, seconds.' + CT, offsets='23C, 8, 10'),
        mem('timer2', 'Float', '458538', 'Second race timer in the table.' + CT, offsets='23C, 8, 14'),
    ])
    extend('RF3D', [
        mem('damage', 'Int32', '946E04', 'Player damage, raw.' + CT, module='jgt.dll', offsets='10'),
        mem('cpu_damage', 'Int32', '946E04', 'Rival damage, raw.' + CT, module='jgt.dll', offsets='48'),
        calc('hit', 'maxw(delta(damage) > 0, 0.2)', '1 for 0.2 s whenever the player\'s damage goes up (a guess: damage may count the other way).'),
        mem('timer', 'Int32', '4F38BC', 'Timer, raw ("MTime").' + CT, offsets='B3C'),
    ])

    # ------------------------------------------------------------ WMMT3DX+ is hand-maintained: done in add_hand()

    # ------------------------------------------------------------ new TeknoParrot games from the tables
    P.append(profile('FNFSB2', 'The Fast and the Furious Super Bikes 2', [
        mem('timer', 'Float', '4E295C', 'Time left, seconds.' + CT),
        mem('boosts', 'Int32', '4E27E0', 'Boosts left.' + CT, offsets='210'),
        calc('boost', 'maxw(delta(boosts) < 0, 1.5)', '1 for 1.5 s after a boost is used (the boost length is a guess).'),
    ], 'SuperBikes2'))
    P.append(profile('THRILLDRIVE4', 'Crazy Streets - Thrill Drive 4', [
        mem('timer', 'Float', '4A3638', 'Time left, seconds.' + CT, offsets='534'),
        mem('nos', 'Int32', '4A38E4', 'Nitro left.' + CT, offsets='48, 4C, 28C'),
        calc('boost', 'maxw(delta(nos) < 0, 1)', '1 while nitro is being used (held 1 s after it last went down).'),
    ]))
    P.append(profile('HYDROTHUNDER', 'Hydro Thunder', [
        mem('timer', 'Float', '52F00C', 'Time left, seconds. ' + NOTES['HYDROTHUNDER'] + CT),
        mem('boost_level', 'Float', '52BCEC', 'Boost left.' + CT),
        calc('boost', 'maxw(delta(boost_level) < 0, 0.15)', '1 while the boost is draining, that is, while boosting.'),
    ]))

    # ------------------------------------------------------------ OutputBlaster games (lamps; no readable force)
    for pre, disp, ob in [('BG4', 'Battle Gear 4', 'BattleGear4'), ('HARLEY', 'Harley-Davidson: King of the Road', 'HarleyDavidson'),
                          ('MOTOGP', 'MotoGP (2015)', 'MotoGP'), ('FNFDRIFT', 'The Fast and the Furious Drift', 'FNFDrift'),
                          ('FNFSC', 'The Fast and the Furious SuperCars', 'FNFSupercars'), ('HUMMER', 'Hummer', 'Hummer'),
                          ('HUMMEREXTREME', 'Hummer Extreme Edition', 'HummerExtreme'), ('CARS', 'Cars', 'Cars'),
                          ('CRAZYRIDE', 'Crazy Ride', 'CrazyRide')]:
        P.append(profile(pre, disp, [], ob))

    # ------------------------------------------------------------ Dead Heat Riders (TeknoParrot shared memory)
    P.append(profile('DEADHEATRIDERS', 'Dead Heat Riders', [
        calc('tp_ok', 'tp_connected', "1 while TeknoParrot's shared memory is available."),
        calc('spring', 'clamp(tp_jvs6 / 500, 0, 1)', 'Centring spring (slot 6), 0 to 1: the FFB plugin divides this game\'s spring by 500, not 63.'),
        calc('friction', 'clamp(tp_jvs7 / 63, 0, 1)', 'Friction (slot 7), 0 to 1.'),
        calc('force', 'clamp(tp_jvs9 > 0 && tp_jvs9 <= 63 ? tp_jvs9 / 63 : (tp_jvs9 > 63 ? -(255 - tp_jvs9) / 63 : '
                      '(tp_jvs8 > 0 && tp_jvs8 <= 63 ? -tp_jvs8 / 63 : (tp_jvs8 < 0 ? -tp_jvs8 / 63 : 0))), -1, 1)',
             'Force, -1 to 1, from slot 9 (reflect) or else slot 8 (centre offset), decoded as the FFB plugin does. + = force from the right.'),
    ] + force_tail()))

    # ------------------------------------------------------------ Model 2 Emulator (memory)
    M2 = (" Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know)."
          " TeknoParrot's own Model 2 emulator may differ.")
    # Any game address through the emulator's own page table, the way its Lua I960_Read* functions find it:
    # host = [[exe+1AA8F4] + (address >> 16) * 16] + address. Reaches the second RAM (0x200000) too, where
    # STCC and Sega Rally keep their variables. (exe+1AA888 then +100 reaches only work RAM at 0x500000.)
    def m2(address):
        return '1AA8F4', f'{(address >> 16) * 16:X}, {address:X}'
    M2LUA = " From the Model 2 Emulator's own SCRIPTS\\{} (sent by Alexis, 4 November 2026)."
    M2LAMPS = (" The lamp byte at RAM+824 only exists when the emulator's script reroutes the game's lamp port there;"
               " Daytona's own daytona.lua does, {}.")
    def m2_daytona_ffb(c='ffb_cmd'):
        return [
            calc('force', hold0(f'{c} >= 80 && {c} <= 87 ? ({c} - 79) / 8 : ({c} >= 96 && {c} <= 103 ? -({c} - 95) / 8 : 0)',
                                f'({c} >= 80 && {c} <= 87) || ({c} >= 96 && {c} <= 103)'),
                 'Force, -1 to 1, kept until the next force command ("roll left" + from the right, "roll right" -).'),
            calc('spring', hold0(f'{c} >= 10 && {c} <= 23 ? clamp(({c} - 15) / 8, 0, 1) : clamp(({c} - 47) / 13, 0, 1)',
                                 f'({c} >= 10 && {c} <= 23) || ({c} >= 48 && {c} <= 60)'), 'Centring spring, 0 to 1, kept until changed.'),
            calc('friction', hold0(f'clamp(({c} - 31) / 8, 0, 1)', f'{c} >= 32 && {c} <= 39'), 'Friction ("clutch"), 0 to 1, kept until changed.'),
            calc('vibration', f'{c} >= 64 && {c} <= 71 ? ({c} - 63) / 8 : 0', 'Vibration ("uncentering"), 0 to 1.'),
        ] + force_tail()
    m2games = [('M2DAYTONA', 'Daytona USA (Model 2 Emulator)', '17285B'), ('M2INDY500', 'Indianapolis 500 (Model 2 Emulator)', '17285B'),
               ('M2STCC', 'Sega Touring Car Championship (Model 2 Emulator)', '17285B'), ('M2OVERREV', 'Over Rev (Model 2 Emulator)', '17285B'),
               ('M2SGT24H', 'Super GT 24h (Model 2 Emulator)', '17285B')]
    for pre, disp, a in m2games:
        rows = [mem('ffb_cmd', 'Byte', a, 'Force feedback command byte in the emulator.' + M2)] + m2_daytona_ffb()
        if pre == 'M2DAYTONA':
            ram = ('1AA888', '100, ')
            rows += [
                mem('game_state', 'Byte', ram[0], 'Game state, raw: 0x16 (22) racing, 0x03 to 0x07 attract mode (the emulator\'s daytona.lua); '
                    'the FFB plugin uses it for its multiplayer hacks. Car_in_race follows game state 22.' + M2, offsets=ram[1] + '10A4'),
                mem('track', 'Byte', ram[0], 'Track.' + M2, offsets=ram[1] + '1460'),
                mem('countdown', 'Byte', ram[0], 'Start countdown.' + M2, offsets=ram[1] + '1850'),
                mem('cars_in_front', 'Byte', ram[0], 'Cars ahead of you.' + M2, offsets=ram[1] + '51EC'),
                calc('position', 'game_state == 22 ? cars_in_front + 1 : 0', 'Race position, 1 = leading (cars ahead + 1); 0 outside a race '
                     '(the count is 0 in attract mode and the menus).'),
                mem('time_left', 'UInt16', ram[0], 'Time left on the race clock in 1/64 s; its "Infinite Time" cheat holds it at 50 x 64.'
                    + M2LUA.format('daytona.lua') + M2, offsets=ram[1] + '10D0', formula='value / 64'),
            ]
            # Alexis's RAM log of 8 November 2026 (TPTRAM_daytona_20261108_115416, Beginner, manual, three lap crossings)
            # with her readings from video. Daytona's clocks count 64 frames to the second.
            DLOG = (" Found in Alexis's RAM log of 8 November 2026 against her readings from video (three laps of the Beginner course,"
                    " manual gears); the time extensions also match her TP Telemetry recordings of that day.")
            def dmem(name, typ, address, notes, formula=''):
                return mem(name, typ, m2(address)[0], notes + DLOG + M2, offsets=m2(address)[1], formula=formula)
            dsurf = lambda test: ' + '.join(f'({test(f"bits({w}, {s}, 16)")})' for w in ('wheels_front', 'wheels_rear') for s in (16, 0))
            rows += [
                dmem('speed', 'UInt32', 0x505198, "The speedo's km/h, whole numbers (320 at the rolling start's GO, 330 flat out in a slipstream).",
                     formula='value / max_speed'),
                dmem('rpm', 'UInt16', 0x5052D8, 'Engine revs as the tacho shows them (7400 at GO, 8500 on the limiter).', formula='value / max_revs'),
                dmem('gear', 'Byte', 0x5052CC, 'Gear, stored 0 to 3 (1 added here, so 1 to 4), for manual and automatic: it matched every shift in '
                     'the manual log and every marked upshift in the automatic one (8 November 2026, 15:29). Keeps the last gear through neutral. '
                     '(0x5FE122 has the H pattern\'s switches, manual only.)', formula='value + 1'),
                dmem('race_time', 'UInt32', 0x5010CC, 'Elapsed race time in seconds (frames from GO, 64 to the second).', formula='value / 64'),
                dmem('lap_start', 'UInt16', 0x5051E4, 'Race time when you last crossed the line, in frames (0 on the first lap).'),
                calc('lap_time', 'max(race_time - lap_start / 64, 0)', 'Current lap time in seconds (race time less the time at the last crossing): '
                     'matched the 24.12, 22.54 and 20.90 laps on screen.'),
                dmem('last_lap', 'UInt16', 0x5051E8, 'Last lap time in seconds (a best lap time sits in the other half of the word; '
                     'both were the same in the log, so which is which isn\'t certain).', formula='value / 64'),
                dmem('laps_done', 'Byte', 0x5010E0, 'Laps completed: 0 on the first lap, 1 after crossing the line, and so on.'),
                dmem('checkpoint', 'Byte', 0x5010D4, '1 while TIME EXTENSION shows after crossing the line (2 s). '
                     'Raw: a countdown the game starts at 128 and lowers by 1 a frame (255 ignored: Sega Rally\'s timer reads 255 mid-frame '
                     'once it has run out, and this may too).', formula='value > 0 && value <= 128'),
                dmem('wheels_front', 'UInt32', 0x50533C, 'Surface under the front wheels, 16 bits each (left wheel in the top half): '
                     '2 road, 4 grass, 6 pit lane, plus 0x100 on a kerb (0x102 kerb, 0x106 pit lane kerb). '
                     '0x20 came up on the right-hand wheels at two right-side contacts.'),
                dmem('wheels_rear', 'UInt32', 0x505340, 'Surface under the rear wheels, as wheels_front.'),
                calc('rumble_strip', f'speed * max_speed > 5 ? ({dsurf(lambda x: f"band({x}, 256) != 0")}) / 4 : 0',
                     'Wheels on a kerb, 0 to 1 (a quarter per wheel), while moving.'),
                calc('off_road', f'speed * max_speed > 5 ? ({dsurf(lambda x: f"band({x}, 15) == 4")}) / 4 : 0',
                     'Wheels on grass, 0 to 1 (a quarter per wheel), while moving.'),
                dmem('surface_rumble', 'Byte', 0x5053E9, 'Rumble from the surface, 0 to 1: the game sets 47 on grass and kerbs and lets it die away.',
                     formula='clamp(value / 47, 0, 1)'),
                dmem('squeal', 'Byte', 0x505219, 'Tyre squeal, raw 0 to 21: up through each slide in the log (0x05 to 0x15), 0 with grip.'),
                calc('grip_loss', 'clamp(squeal / 21, 0, 1)', 'Sliding, 0 to 1, from the tyre squeal.'),
                dmem('hit', 'Byte', 0x5053EB, 'Wall hits and side-on contact with a car, raw: jumps to 15 (9 for a lighter one) and dies away over '
                     'about half a second. Seen at a left wall hit, a right wall hit and a right-side car contact; rear-end bumps don\'t set it.'),
            ]
        if pre == 'M2STCC':
            # Alexis's RAM log of 5 November 2026 (TPTRAM_stcc_20261105_170400), with her readings from video:
            # speedo, tacho bar, gear, race time and elapsed time at seven marks and through the first gears.
            LOG = (" Found in Alexis's RAM logs of 5 and 6 November 2026 against her readings from video, and checked in her"
                   " TP Telemetry recording of 6 November 2026 (12:07).")
            def m2mem(name, typ, address, notes, formula=''):
                return mem(name, typ, m2(address)[0], notes + LOG + M2, offsets=m2(address)[1], formula=formula)
            surf = lambda n: ' + '.join(f'(bits(surfaces, {s}, 4) == {n})' for s in (12, 8, 4, 0))
            rows += [
                mem('host_state', 'Byte', *m2(0x202094)[:1], 'Game state of this cabinet ("host state"), raw. The emulator\'s stcc.lua reads it to '
                    'fix link play (4 = waiting for the other cabinets). In the 5 November log: 1 from coin-up, 5 and 7 through the menus '
                    '(7 = name entry), 9 from loading the race to the end of the log.' + M2LUA.format('stcc.lua') + M2, offsets=m2(0x202094)[1]),
                m2mem('speed', 'Float', 0x20893C, 'Car speed, x 64 = km/h (126, 157 and 208 at the 2nd, 3rd and 4th gear limits, 274 flat out in 5th). '
                      'Keeps reading after the finish as the car slows.', formula='value * 64 / max_speed'),
                m2mem('speed_kmh', 'UInt16', 0x204634, "The speedo's own km/h, whole numbers. Stops at the finish line (the display freezes)."),
                m2mem('rpm', 'Float', 0x208788, "The engine's own revs (Alexis's choice, 8 November 2026): 12190 revving on the grid, 13130 launching in "
                      '1st, about 12800 on the limiter (both cars seen), and they stay up when the wheels spin, so the tacho reads lower in skids.',
                      formula='value / max_revs'),
                m2mem('rpm_tacho', 'Float', 0x208914, 'Revs as the tacho bar shows them, raw (x 1.078: the bar read 12.5k to 12.8k at the gear limits, '
                      '9.8k to 11.4k in skids). Keeps reading after the finish.', formula='value * 1.078'),
                m2mem('rpm_display', 'UInt16', 0x20463C, 'The revs the tacho bar shows, raw: x 1.2 matched Alexis\'s readings of the bar '
                      '(3705 = 4.5k, 11545 = 14k at the 1st gear limiter). Stops at the finish line.'),
                m2mem('gear', 'Byte', 0x208934, 'Gear: 0 before the race, 1 to 5 (manual; checked at each upshift in the 5 November log). '
                      'Reverse not seen yet. A copy the display uses is at 0x20462C.'),
                m2mem('race_time', 'Float', 0x2022CC, 'Elapsed race time in seconds, for the whole race (it doesn\'t restart at each lap); stops at '
                      'the finish and starts again from 0 for the next race.'),
                m2mem('laps_done', 'Byte', 0x2022F0, 'Laps completed: 0 on the first lap, 1 after crossing the line.'),
                m2mem('checkpoint', 'UInt16', 0x2061D4, '1 while "TIME EXTENDED" is on screen (about 2.7 s) after crossing the line or a checkpoint. '
                      'Raw: a countdown the game starts at 158 and lowers by 1 a frame.', formula='value > 0'),
                calc('in_race', 'maxw(delta(race_time) > 0, 1)', '1 while the race clock runs (from GO to the finish line), held 1 s.'),
                m2mem('time_left', 'UInt16', 0x2022EC, 'Race time left (the countdown), stored in 1/64 s like Daytona\'s.', formula='value / 64'),
                m2mem('surfaces', 'UInt16', 0x208886, 'Surface under each wheel, one hex digit per wheel: 0 in the air, 2 road, 3 kerb, 4 grass or dirt. Digits 1 and 3 '
                      '(from the left, 0x4_4_) are the right-hand wheels, 2 and 4 the left: 0x2323 on a left kerb, 0x4242 on a right verge, '
                      '0x3333 with all four on a kerb, 0x2222 on the road.'),
                calc('rumble_strip', f'speed * max_speed > 5 ? ({surf(3)}) / 4 : 0', 'Wheels on a kerb, 0 to 1 (a quarter per wheel), while moving.'),
                calc('off_road', f'speed * max_speed > 5 ? ({surf(4)}) / 4 : 0', 'Wheels on grass, 0 to 1 (a quarter per wheel), while moving.'),
                m2mem('off_track', 'Byte', 0x20AC70, '1 with any wheel off the road (kerb or grass), raw.'),
                m2mem('slip_front', 'Float', 0x208950, 'Front tyre slip angle (radians, + in right-hand turns): under 0.1 on the straight, '
                      '0.3 to 0.4 cornering hard, 0.5 to 0.85 in skids. 0x208958 is the other front tyre; 0 with the wheels off the ground.'),
                m2mem('slip_rear', 'Float', 0x208960, 'Rear tyre slip angle (radians, + in right-hand turns): under 0.25 cornering, 0.3 to 0.45 in slight '
                      'skids, 0.6 to 0.65 in big ones. 0x208968 is the other rear tyre.'),
                calc('grip_loss', 'clamp((abs(slip_rear) - 0.2) / 0.4, 0, 1)', 'Sliding, 0 to 1, from the rear slip angle: about 0.3 in a slight skid, '
                     '0.5 to 0.6 in a moderate one, 1 in a big one, 0 on the straight.'),
                m2mem('skid_flag', 'Byte', 0x20AD90, '1 through skids and tyre squeal (comes on and off with grip_loss, a little later). Raw.'),
                m2mem('wall_hit', 'Byte', 0x20AC8C, '1 for a frame or two at each wall contact, left or right, and again if the car lands on the wall. '
                      'No side; car-to-car contact doesn\'t set it.'),
                m2mem('air_frames', 'Byte', 0x20ACD4, 'Frames with wheels off the ground, counting up (19 over the dip, 23 after a hard wall hit), '
                      '0 on the ground.'),
                calc('airborne', 'air_frames > 0', '1 with wheels off the ground (the front or the back thrown up counts).'),
            ]
        maxes = {'M2STCC': {'max_speed': 320, 'max_revs': 12900}, 'M2DAYTONA': {'max_speed': 340, 'max_revs': 8500}}
        P.append(profile(pre, disp, rows, 'M2Emulator', **maxes.get(pre, {})))
        # STCC: Max speed 320 (tops seen 278 and 335, two cars); Max revs 12900 for the engine revs: 97% (12513) is reached on the
        # limiter (about 12800), and when the wheels spin there.
    def srally_rows():
        # Alexis's RAM logs of 8 November 2026 (TPTRAM_srallyc_20261108_134906 with notes: Desert, then Forest until the time ran out;
        # 134427 without notes) and her TP Telemetry recording of the first. Sega Rally's clocks count 60 frames to the second.
        SLOG = (" Found in Alexis's RAM logs of 8 November 2026 (srallyc) against her readings from video, and checked in her"
                " TP Telemetry recording of that day where it has the value. For the srallyc romset; others may keep it elsewhere.")
        def smem(name, typ, address, notes, formula=''):
            return mem(name, typ, m2(address)[0], notes + SLOG + M2, offsets=m2(address)[1], formula=formula)
        wheels = ('surface_fl', 'surface_fr', 'surface_rl', 'surface_rr')
        return [
            smem('race_state', 'Byte', 0x214120, 'Race state, raw: 0 before the start (and in attract mode), 1 racing, 2 after the finish or time up.'),
            calc('in_race', 'race_state == 1', '1 from GO to the finish line or time up.'),
            smem('speed', 'Float', 0x500080, 'Car speed, x 64 = km/h (about 1% under the speedo: 216.8 for 220, 206.9 for 207). '
                 'In the player car\'s block, set up at coin-up.', formula='value * 64 / max_speed'),
            smem('rpm', 'Float', 0x50007C, 'Engine revs: 8800 on the limiter, where the tacho reads 8k (the tacho shows revs / 1.1).',
                 formula='value / max_revs'),
            calc('rpm_tacho', 'rpm * max_revs / 1.1', 'Revs as the tacho shows them (8000 on the limiter).'),
            smem('gear', 'Byte', 0x500078, 'Gear, 1 to 4 (4 on the start line; matched each shift Alexis noted).'),
            smem('total_time', 'UInt32', 0x2020B8, 'Total time in seconds, for the whole game (it carries on into the next stage).', formula='value / 60'),
            smem('stage_time', 'UInt32', 0x2020BC, 'This stage\'s time in seconds (the LT on screen).', formula='value / 60'),
            smem('time_left', 'UInt16', 0x20B0B0, 'Time left in seconds (stored in frames; +20 s at the Desert checkpoint). The emulator\'s srallyc.lua '
                 'reads it to stop the time going up in link play. Reads oddly for a moment while the next stage loads.', formula='value / 60'),
            calc('checkpoint', 'race_state == 1 && maxw(delta(time_left) > 1, 1) > 0', '1 for a second from each time extension, for a lamp: '
                 'when the time left jumps up during a race. The game\'s own message timer (0x20AEA0, counting down from 60) reads 255 '
                 'partway through a frame once it has run out, so TP Telemetry caught it stuck on; the time left doesn\'t have that problem.'),
            smem('position', 'Byte', 0x20AB40, 'Race position as shown (15 at the start in a race, 1 or 2 in practice; matched every change Alexis noted).'),
            calc('leader', 'in_race == 1 && position == 1', '1 while you lead, for a lamp (the game\'s own lamps haven\'t lit one for the lead in any log).'),
        ] + [smem(n, 'Byte', a, f'Surface under the {w} wheel: 0 tarmac, 2 dry dirt or sand, 3 wetter dirt (Alexis, from video), 6 grass verge, '
                  '9 tarmac in the Forest tunnel, 128 for a moment at the edge of the verge (all from Alexis\'s video).')
             for n, a, w in zip(wheels, (0x2138EC, 0x213910, 0x213934, 0x213958), ('front left', 'front right', 'rear left', 'rear right'))] + [
            calc('off_road', f'speed * max_speed > 5 ? ({" + ".join(f"({w} == 6)" for w in wheels)}) / 4 : 0',
                 'Wheels on the grass verge, 0 to 1 (a quarter per wheel), while moving.'),
            smem('wheels_down', 'Byte', 0x213974, 'Wheels on the ground, one bit each (1 front left, 2 front right, 4 rear left, 8 rear right): '
                 '15 on the ground, 0 in the air, 12 with the front up over a crest, 5 with the right side lifted.'),
            calc('airborne', 'race_state == 1 && wheels_down == 0', '1 with all four wheels off the ground (every jump in Alexis\'s notes).'),
            smem('slip_front', 'Float', 0x213880, 'Front left tyre slip (+ in left-hand slides): under 0.15 on the straight, 0.3 to 0.6 cornering, '
                 'up to 1 in big slides; 0 in the air. 0x213884 is the front right.'),
            smem('slip_rear', 'Float', 0x213888, 'Rear left tyre slip, as slip_front: 0.5 to 0.85 through the long drifts. 0x21388C is the rear right.'),
            calc('grip_loss', 'clamp((abs(slip_rear) - 0.2) / 0.4, 0, 1)', 'Sliding, 0 to 1, from the rear slip (as STCC).'),
            smem('hit', 'Int32', 0x213968, 'The last hit\'s strength, signed: + on the right, - on the left (24 to 331 seen). It keeps the '
                 'value until the next hit, so a hit is when it changes: one new value for a wall hit (the wheel force kicks full the other '
                 'way at the same moment, every time in the 15:44 recording), several in a row for contact with a car.'),
            calc('hit_now', 'delta(hit) != 0 ? abs(hit) : 0', 'The strength of a hit in the moment it happens (0 otherwise).'),
        ]
    P.append(profile('M2SRALLY', 'Sega Rally Championship (Model 2 Emulator)', [
        mem('ffb_cmd', 'Byte', '174CF4', 'Force feedback command byte in the emulator.' + M2),
        calc('force', hold0('ffb_cmd >= 192 && ffb_cmd <= 223 ? (ffb_cmd - 191) / 32 : (ffb_cmd >= 128 && ffb_cmd <= 159 ? -(ffb_cmd - 127) / 32 : 0)',
                            '(ffb_cmd >= 128 && ffb_cmd <= 159) || (ffb_cmd >= 192 && ffb_cmd <= 223)'),
             'Force, -1 to 1, kept until the next force command (0xC0 up = from the right, 0x80 up = from the left).'),
        calc('vibration', hold0('ffb_cmd > 16 && ffb_cmd <= 31 ? 1 : 0', 'ffb_cmd >= 16 && ffb_cmd <= 31'),
             'Rumble on (1) or off (0), kept until changed: the game sends 0x15 on the grass verge, scraping walls and at some landings, '
             'and 0x10 to stop. The FFB Arcade Plugin ignores these.'),
    ] + srally_rows() + force_tail(), 'M2Emulator', max_speed=240, max_revs=8800))

    # ------------------------------------------------------------ Supermodel, MAME, Flycast (network outputs)
    SM = (" From Supermodel's network outputs (-outputs=net), as the FFB Arcade Plugin reads them;"
          " TeknoParrot's Model 3 emulator may not send them.")
    MAME = (" From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them;"
            " TeknoParrot's own builds may not send them.")
    FLY = (' From Flycast\'s network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin'
           " reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them.")

    def out_profile(pre, disp, rows, **kw):
        P.append(profile(pre, disp, rows, **kw))

    # ------------------------------------------------------------ Scud Race in Supermodel: the game's own memory (18 November 2026)
    # Alexis sent supermodel.exe (Supermodel 0.4-dev, git 0b82a98 of 16 November 2026, 64-bit, MD5
    # 440c8330529f89714047740b9b45831e) and scud.zip (Supermodel's `scudau`: Scud Race, Australia, Twin/DX).
    # claude/SMSCUD-supermodel-20261118.md has the details. The PowerPC core keeps a pointer to its fetch regions at
    # <main>+AE6280 (ppc.fetch); region 0 is the game's 8 MB of RAM, its pointer at +8. So game address A is
    # [[<main>+AE6280] + 8] + A. The PowerPC is big-endian and Supermodel keeps its RAM as 32-bit words in the PC's byte
    # order: 32-bit values read as they are, a 16-bit value at A sits at A ^ 2 and a byte at A ^ 3 (sm_ram does that).
    # The values were found by running the same Supermodel source, with a RAM logger added, on Alexis's ROM set and
    # driving races on the Beginner course (an autopilot following the computer cars' paths), against the screen.
    SM_RAM = 'AE6280'
    def sm_ram(name, typ, addr, notes, formula=''):
        a = addr ^ (3 if typ == 'Byte' else 2 if typ in ('Int16', 'UInt16') else 0)
        return mem(name, typ, SM_RAM, notes, offsets=f'8, {a:X}', formula=formula)
    def sm_lamps():
        # The cabinet's lamps: Supermodel sends them as outputs (Model 3 lamp port, as the FFB Arcade Plugin knows it).
        # Named as OutputBlaster names them (lampstart...) since 19 November 2026: lamp_<name> is now the common lamps' row name.
        L = " From Supermodel's network outputs (-outputs=net)."
        return [calc('lampstart', 'valid(out_LampStart, 0)', 'Start button lamp (0 or 1).' + L),
                calc('lampview1', 'valid(out_LampView1, 0)', 'VR1 view button lamp.' + L),
                calc('lampview2', 'valid(out_LampView2, 0)', 'VR2 view button lamp.' + L),
                calc('lampview3', 'valid(out_LampView3, 0)', 'VR3 view button lamp.' + L),
                calc('lampview4', 'valid(out_LampView4, 0)', 'VR4 view button lamp.' + L),
                calc('lampleader', 'valid(out_LampLeader, 0)', 'Leader lamp.' + L),
                calc('lamp_bits', 'valid(out_RawLamps, 0)', 'The lamp port as one number (4 start, 8/16/32/64 the four view buttons, '
                     '128 leader), so a recording shows every lamp in one column.' + L)]
    def smscud_rows():
        F = ' Found by running the game in the same Supermodel build (18 November 2026).'
        A = (" Checked in Alexis's four recordings of 18 November 2026 (Porsche manual and Viper manual on Beginner night, "
             "McLaren manual on Medium, F40 automatic on Expert).")
        E = ' Found in the emulator (18 November 2026, after her recordings, so not yet in one).'
        C = ' Candidate, not identified: recorded so a capture can show what it is.'
        def cand(name, typ, addr, what):
            return dict(sm_ram(name, typ, addr, what + C), Enabled=False)
        return [
            sm_ram('ram_probe', 'UInt32', 0x100, "Plumbing check, not telemetry: the game's code at game address 0x100, which it copies "
                   "into RAM at power-on. A steady 2087778982 shows the plugin reads the game's memory (all four of Alexis's recordings "
                   "of 18 November 2026); 0 or an error means this supermodel.exe keeps its RAM pointer somewhere else "
                   "(claude/SMSCUD-supermodel-20261118.md says how to find it)."),
            sm_ram('state', 'UInt32', 0x10525C, "The game's race sequence: byte 1 (bits 8 to 15) is the phase (2 loading the race, 3 the "
                   "rolling start's camera shots, 4 the driver's view on), byte 2 is 1 in the Beginner course's rolling start until GO, "
                   "and the top byte is your finishing place less 1, set where the race clock stops (finish line or time up) and kept "
                   "into the attract mode and the next race. The Medium and Expert courses' standing starts leave it at 4 throughout."
                   + A),
            calc('phase', 'bits(state, 8, 8)', "Race phase from `state`: 2 loading, 3 the rolling start's camera shots, 4 the driver's "
                 "view (countdown and race); it stays 4 after the race."),
            calc('countdown', 'phase == 4 && bits(state, 16, 8) == 1', "1 in the Beginner course's rolling start 3-2-1 (the driver's "
                 "view, with the game driving the car at about 300 km/h), 0 from GO. The standing starts on Medium and Expert don't use it."),
            calc('final_position', 'bits(state, 24, 8) + 1', 'Your place when the last race ended (finish line or time up), as the '
                 'result screen gives it: 21st and 33rd, 29th and 20th in the four recordings. Kept until the next race ends.'),
            sm_ram('rt', 'Int32', 0x104010, 'Time left (RT), seconds: the game counts it in frames, 57 to its second (60 s is 3420). '
                   'Extended at each lap line on Beginner (26.67 s at night) and at each checkpoint on Medium and Expert (14.23 s); '
                   'frozen while the pit crew works (Expert); held after the finish line; -1 frame at time up, read as 0.' + A,
                   formula='max(value, 0) / 57'),
            sm_ram('race_clock', 'Int32', 0x10400C, "Race clock (TT), seconds: frames from GO, 57 to the second, as the result "
                   "screen's TOTAL TIME shows it (5092 frames was 1'29\"33). Stops at the finish line and at time up and holds until "
                   "the next race." + A, formula='value / 57'),
            calc('racing', 'phase == 4 && bits(state, 24, 8) == valid(hold(bits(state, 24, 8), race_clock == 0), bits(state, 24, 8)) && '
                 '(countdown ? race_clock == 0 && rt > 0 : maxw(valid(delta(race_clock), 0) > 0, 0.1) > 0)',
                 "1 from GO (on Beginner from the rolling start's 3-2-1) to the finish line or time up: the race phase, the race clock "
                 "moving, and the finishing place not yet set (the game sets it the moment the clock stops). 0 in the attract mode "
                 "(whose demo race drives the same car), the menus and the rolling start's camera shots. In Alexis's four recordings "
                 "of 18 November 2026 it ended within 0.04 s of the clock stopping (two time ups, one finish line)."),
            calc('finished', 'phase == 4 && !racing && race_clock > 0 && rt > 0', '1 after crossing the finish line (the clock stopped '
                 'with time left), 0 after time up; kept into the attract mode until the next race.'),
            calc('grid', 'phase == 4 && !countdown && race_clock == 0 && rt > 0', "1 on the grid before GO on Medium and Expert (the "
                 "standing starts), once the time left is set: Car_in_race, Car_rpm, Car_rpm_frac and Car_gear run then, the rest from GO "
                 "(Alexis, 18 November 2026)."),
            calc('pit_stop', 'racing && race_clock > 0 && rt > 0 && maxw(valid(delta(rt), 0) < 0, 0.25) == 0', '1 while the time left stands '
                 'still in a race: in the pits on Expert, where the game takes the wheel and the time stops (Alexis\'s F40 recording, '
                 '18 November 2026: from TT 1:07.74 in the pit lane until 1:24.42).'),
            sm_ram('lap', 'Byte', 0x181198, "Lap, counting the first as 1 (the car's completed laps + 1; 5 once past Beginner's fourth "
                   "lap line)." + A, formula='value + 1'),
            sm_ram('lap_start', 'Int32', 0x1811CC, 'The race clock at the last lap line, seconds (0 in the first lap).' + F,
                   formula='value / 57'),
            calc('lap_time', 'race_clock - lap_start', "The current lap's time, seconds: the lap clock on screen."),
            sm_ram('best_lap', 'UInt16', 0x1811D0, 'Best lap so far, seconds (0 until the first lap line): BEST LAP on screen.' + F,
                   formula='value / 57'),
            sm_ram('last_lap', 'UInt16', 0x1811D2, 'The last lap, seconds.' + F, formula='value / 57'),
            sm_ram('position', 'Byte', 0x1811D4, 'Race position, 1 = leading, as POSITION shows it (40th at the start of a '
                   '40-car race on Beginner).' + F, formula='value + 1'),
            sm_ram('retire', 'Byte', 0x10404D, "The RETIRE count under the position." + F),
            calc('time_extended', 'maxw(race_clock > 0 && valid(delta(rt), 0) > 1 && valid(delta(rt), 0) < 120, 2) > 0',
                 'TIME EXTENSION!: 1 for 2 s when the time left jumps up (lap lines on Beginner, checkpoints on Medium and Expert). '
                 'Not at the start, where the time is first set.'),
            sm_ram('car', 'Byte', 0x181105, 'Which car: 4 Porsche 911, 5 Dodge Viper, 6 Ferrari F40, 7 McLaren F1.' + E),
            sm_ram('speed', 'Int32', 0x181118, 'Speed, km/h, as the screen shows it (matched at 34 readings, 103 to 328 km/h). In the '
                   'attract mode it is the demo car\'s speed.' + A),
            sm_ram('rpm', 'Int32', 0x181244, "Engine revs, RPM, as the rev counter's needle shows them. Each car's limiter: 7200 the "
                   "Porsche and the Viper, 8500 the McLaren (Alexis's recordings); the F40's automatic reached 9370." + A),
            sm_ram('gear', 'Int32', 0x18123C, 'Gear, 1 to 4, manual or automatic.' + A),
            calc('rev_limit', 'car == 7 ? 8500 : (car == 6 ? 9040 : 7200)', "This car's rev limit: 7200 the Porsche and the Viper, "
                 "8500 the McLaren, 9040 the F40 (where each sat on the limiter in Alexis's recordings; the F40 at TT 0:15.30 in her "
                 "13:30 recording, about 9k on its 10k dial)."),
            calc('rpm_frac', 'car >= 4 && car <= 7 ? clamp(rpm * max_revs / rev_limit, 0, 1.1) : rpm * max_revs / 7200', "Revs as a "
                 "fraction of this car's rev limit (the Porsche's 7200 for a car number not seen)."),
            accel(),
            sm_ram('throttle', 'Byte', 0x1811E7, 'Throttle as the game uses it, 0 to 1 (0 to 255): follows the pedal over USB '
                   '(correlation 0.85 to 0.97).' + A, formula='value / 255'),
            sm_ram('brake', 'Byte', 0x1811BF, 'Brake as the game uses it, 0 to 1: nothing until the pedal is about half way down '
                   '(over USB).' + A, formula='value / 255'),
            sm_ram('steer', 'Int32', 0x1811C0, 'Steering input, -1 full left to 1 full right (the game holds -32766 to 32766): follows '
                   'the wheel over USB (correlation 0.96 to 0.98).' + A, formula='value / 32766'),
            sm_ram('head_x', 'Float', 0x181158, "Where the car points: the x part of its forward direction." + F),
            sm_ram('head_z', 'Float', 0x181170, "Where the car points: the z part of its forward direction, turned round (+ is "
                   "backwards along z)." + F),
            sm_ram('move_x', 'Float', 0x181178, 'How far the car moved in the last frame along x, metres (with move_z, x 57.5 x '
                   '3.6 gives the km/h).' + F),
            sm_ram('move_y', 'Float', 0x18117C, 'How far the car moved in the last frame up (+) or down, metres. In the air it '
                   'falls 0.00287 m a frame more each frame (the game\'s gravity).' + A),
            sm_ram('move_z', 'Float', 0x181180, 'How far the car moved in the last frame along z, metres.' + F),
            calc('light', 'racing && minw(slope(move_y, 0.15) < -0.12, 0.1) > 0', 'The car going light over a crest (or in the air): '
                 'falling at 0.7 g or more for 0.1 s. Alexis\'s Porsche at TT 1:03.0 to 1:04.2, where only the front wheels leave the '
                 'ground ("pronounced, if not so much as a jump"), reads 1 for 0.9 s.'),
            calc('airborne', 'racing && minw(abs(slope(move_y, 0.15) + 0.165) < 0.03, 0.1) > 0', '1 in the air: the car falling '
                 'freely (its downward speed growing by the game\'s gravity, 0.165 m a frame each second) for 0.1 s. Alexis\'s jump '
                 'marks in three recordings (Beginner night, Medium) all read 1 within 0.4 s; smaller hops read too.'),
            calc('drift_angle', 'racing && speed * max_speed > 10 ? atan2(-(move_x * head_z + move_z * head_x), move_x * head_x - '
                 'move_z * head_z) * 57.29578 : 0', 'Drift angle, degrees: between where the car points and where it is going, + '
                 'pointing right of its path (a right-hand drift), - left. Over 120 is the car going backwards (reversing or spun '
                 'round). 0 under 10 km/h and outside a race. Her slides reached 40 to 77 degrees.'),
            calc('drift', 'abs(drift_angle) > 120 ? 0 : clamp((abs(drift_angle) - 14) / 44, 0, 1) * sqrt(clamp((speed * max_speed - '
                 '20) / 80, 0, 1))', "Drifting, 0 to 1: straight from 14 to 58 degrees, set by Alexis's two F40 drifts (18 November "
                 '2026: 53.5 degrees at TT 0:39.33 to read 0.9, 42.5 degrees at 1:40.30 to read 0.65), times the speed part (nothing '
                 'under 20 km/h, full from 100); 0 going backwards.'),
            sm_ram('crash', 'Byte', 0x1811B7, "The game's crash timer: set to 28 at a big crash (100 km/h or more lost, the car "
                   "spinning) and counting down a frame at a time. Ordinary wall hits and scrapes don't set it." + A),
            sm_ram('seg', 'Int32', 0x181288, "The strip of road under the car's middle, a number that runs up along the course (0 at "
                   "the lap line; the pit lane has its own)." + A),
            sm_ram('seg_fl', 'Int32', 0x18128C, 'The strip under the front left wheel: the same as `seg` on the road, several '
                   'hundred off it while the wheel is against a wall or barrier (or on the edge strip).' + F),
            sm_ram('seg_fr', 'Int32', 0x181290, 'The strip under the front right wheel.' + F),
            sm_ram('seg_rl', 'Int32', 0x181294, 'The strip under the rear left wheel.' + F),
            sm_ram('seg_rr', 'Int32', 0x181298, 'The strip under the rear right wheel.' + F),
            calc('edge_left', 'racing && (abs(seg_fl - seg) > 300 || abs(seg_rl - seg) > 300)', "1 while a left wheel is off the road's "
                 "strip: against a wall or barrier on the left (sparks on the left in the emulator), or the edge. Both sides at once "
                 "at the lap line and in the air."),
            calc('edge_right', 'racing && (abs(seg_fr - seg) > 300 || abs(seg_rr - seg) > 300)', "The same for the right wheels."),
            calc('wall_contact', 'edge_left && !edge_right ? -1 : (edge_right && !edge_left ? 1 : 0)', 'Touching or scraping a '
                 'wall on the left (-1) or right (1), from which wheels are off the road\'s strip; 0 when neither or both. To check '
                 'against Alexis\'s video.'),
            sm_ram('car_contact', 'Byte', 0x1812F7, 'Touching another car: 255 none, 0 a car on your left, 2 on your right, 3 ahead '
                   '(your nose into its tail), 1 behind (hit from behind). Found in the emulator; confirmed in Alexis\'s F40 recording '
                   '(18 November 2026, 13:30): up the back of a car (3), then cars on her left, right and left (0, 2, 0).'),
            calc('car_side', 'racing ? (car_contact == 0 ? -1 : (car_contact == 2 ? 1 : 0)) : 0', 'Side of a touching car, -1 left, '
                 '1 right, 0 none or nose to tail.'),
            calc('car_touch', 'racing && car_contact >= 0 && car_contact <= 3', '1 while touching another car on any side.'),
            sm_ram('near_car', 'Byte', 0x181101, 'Another car within about 5 m (bit 4, value 16; the byte is 128 or 144).' + E,
                   formula='bits(value, 4, 1)'),
            calc('hit', 'racing ? max(maxw(valid(delta(crash), 0) > 10, 0.3) > 0 ? 1 : 0, maxw(car_touch && !prev(car_touch), 0.2) > 0 '
                 '? 0.5 : 0, maxw(wall_contact != 0 || car_touch, 0.3) > 0 ? clamp(0.4 + (maxw(speed * max_speed, 0.25) - speed * '
                 'max_speed - 10) / 60, 0, 1) * (maxw(speed * max_speed, 0.25) - speed * max_speed > 10) : 0) : 0', "A hit, 0 to 1: 1 "
                 "for a big crash (the game's crash timer); 0.5 for 0.2 s as another car first touches; touching a wall or another car "
                 "while losing speed, 0.4 at 10 km/h lost in 0.25 s up to 1 at 46 km/h. Braking alone doesn't count. Alexis's F40 "
                 "recording (18 November 2026): her nose into a car's tail read 0.97, the big crash 1, the wall hits 0.6 to 0.8."),
            calc('hit_side', 'hit > 0 ? (maxw(car_side != 0, 0.3) > 0 ? valid(hold(car_side, car_side != 0), 0) : '
                 'sign(maxw(edge_right, 0.3) - maxw(edge_left, 0.3))) : 0', 'Side of a hit, -1 left, 1 right: the touching car\'s '
                 'side, or the wheels against the wall; 0 when not known (nose to tail, both sides).'),
            calc('wrong_way', 'racing && speed * max_speed > 20 && ema(clamp(valid(delta(seg), 0), -5, 5), 1) < -0.03', '1 while '
                 'driving the wrong way: the road strip numbers running backwards. Read 1 in Alexis\'s Porsche recording at '
                 '1:35.14 after a spin; also at the Expert pit lane, whose strips are numbered differently. To check with REVERSE! '
                 'on screen.'),
            cand('flag_38c', 'Int32', 0x18138C, '0 or 1 in spells of a whole number of thirds of a second, starting at jumps and '
                 'some slides and bumps (not car contact).'),
            cand('area_388', 'Int32', 0x181388, 'A small number (about 1 to 300) that changes along the course, at jumps and '
                 'leaving the pits: perhaps the area or surface the car is on.'),
            cand('grip_258', 'Float', 0x181258, 'About 50 to 72 on the road, dropping to -70 to -220 at times (by car) and '
                 'flickering in the air; 0 in the attract mode.'),
            cand('engine_334', 'Float', 0x181334, 'The revs in radians a second (revs / 9.55).'),
            cand('speed_338', 'Float', 0x181338, "Follows the speed at 0.86 of the km/h: another speed in the game's own units."),
            cand('misc_2c4', 'Int32', 0x1812C4, 'Read -25 to 25 with keys in the emulator, but -165 to 313 and unrelated to the '
                 "wheel in Alexis's recordings: not the front wheels' angle."),
        ]
    # ------------------------------------------------------------ Daytona USA 2 Power Edition in Supermodel (18 November 2026)
    # Alexis sent dayto2pe.zip, daytona2.zip (its parent set) and her NVRAM. The same supermodel.exe, so the same RAM pointer
    # (her recording with the Scud profile read ram_probe right). Values found by running the game in the analysis build on
    # the Beginner course (Three Seven Speedway, 8 laps) with the autopilot, against the screen: SMDAYTO2PE-supermodel-20261118.md.
    # The car record is 0x1000 a car from 0x501000 (40 cars); its layout is Scud's moved down 0x80 to +0x160, then 0x64 to 0x68.
    def d2pe_rows():
        F = (' Found by running the game in the same Supermodel build, then read right in Alexis\'s three recordings of 18 November '
             '2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop).')
        C = ' Candidate, not identified: recorded so a capture can show what it is.'
        def cand(name, typ, addr, what):
            return dict(sm_ram(name, typ, addr, what + C), Enabled=False)
        return [
            sm_ram('ram_probe', 'UInt32', 0x100, "Plumbing check, not telemetry: the game's code at game address 0x100. A steady "
                   "2087778982 (as in Scud Race; Alexis's Daytona 2 recording of 18 November 2026 read it) shows the plugin reads the "
                   "game's memory."),
            sm_ram('playing', 'Byte', 0x1065E7, '255 from the course select to the moment the race clock stops (finish line or time '
                   'up), 0 in the attract mode, the results and name entry.' + F, formula='value == 255'),
            sm_ram('rt', 'Int32', 0x105010, 'Time left (RT), seconds: frames, 57 to the game\'s second (60 s is 3420); extended at '
                   'the lap lines; held after the finish line; -1 frame at time up, read as 0.' + F, formula='max(value, 0) / 57'),
            sm_ram('race_clock', 'Int32', 0x10500C, "Race clock (TT), seconds: frames from GO, 57 to the second (7914 frames was "
                   "TOTAL TIME 02'18\"835 on the result screen, which counts thousandths its own way, so this is within about 0.01 s). "
                   "Stops at the finish line and time up; the attract mode sets it to replay times." + F, formula='value / 57'),
            calc('countdown', 'playing && race_clock == 0 && rt > 0', 'The start: from the time set to 60 s to GO. On Beginner the '
                 'rolling start (the game drives; effects on there, as Alexis asked); on Advanced and Expert the grid (5.4 s, revs '
                 'up to about 9,100).'),
            calc('racing', 'playing && valid(rt, 0) > 0 && maxw(valid(delta(race_clock), 0) > 0 && valid(delta(race_clock), 0) < 0.1, 0.1) > 0',
                 '1 from GO to the finish line or time up: in a game (`playing`) with the race clock moving a frame at a time. 0 in the '
                 'attract mode, whose replays set the clock.'),
            calc('finished', '!playing && rt > 0 && race_clock > 0', '1 after crossing the finish line (the clock stopped with time '
                 'left); kept into the attract mode until the next race.'),
            calc('time_extended', 'maxw(race_clock > 0 && valid(delta(rt), 0) > 1 && valid(delta(rt), 0) < 120, 2) > 0',
                 'Time extended: 1 for 2 s when the time left jumps up (the lap lines on Beginner). Not at the start.'),
            sm_ram('lap', 'UInt16', 0x501118, 'Lap, counting the first as 1 (laps completed + 1; 9 once past the eighth line on '
                   'Beginner).' + F, formula='value + 1'),
            sm_ram('lap_start', 'Int32', 0x501168, 'The race clock at the last lap line, seconds.' + F, formula='value / 57'),
            calc('lap_time', 'race_clock - lap_start', "The current lap's time, seconds: the lap clock on screen."),
            sm_ram('best_lap', 'UInt16', 0x50116C, 'Best lap so far, seconds.' + F, formula='value / 57'),
            sm_ram('last_lap', 'UInt16', 0x50116E, 'The last lap, seconds (the list on screen: 18"626, 19"085, 20"841...).' + F,
                   formula='value / 57'),
            sm_ram('position', 'Byte', 0x501149, 'Race position, 1 = leading, as POSITION shows it (15 screenshots, 34th to 20th).'
                   + F, formula='value + 1'),
            sm_ram('speed', 'Int32', 0x501098, 'Speed, km/h, as the screen shows it (14 readings, 93 to 275 km/h).' + F),
            sm_ram('rpm', 'Int32', 0x5011E0, 'Engine revs, RPM, as the rev counter shows them: like `rpm_wheels` while the clutch '
                   'is in, but it races ahead when the wheels spin or the clutch slips at a standing start (8,500, the limiter, at '
                   '42 to 50 km/h in first, where Alexis saw the dial stuck at 8.2k with the limiter light on; her SPECIAL '
                   'recording of 18:57, 18 November 2026) and lags a moment across a gear change. Limiters: NORMAL and HARD 8,500 '
                   '(8.2k on the dial), EASY about 7,650, SPECIAL 7,000 to 7,800 (7.4k on the dial); 10000 is a ceiling, changing '
                   'down too fast (8.8k on the dial). Max revs 8500.' + F),
            sm_ram('rpm_wheels', 'Int32', 0x5011DC, 'The revs the wheels would give in this gear: as `rpm`, but no wheelspin or clutch '
                   'slip (3,500 where the dial showed 8.2k). The profile used this as `rpm` until 19:10, 18 November 2026.' + F),
            sm_ram('gear', 'Int32', 0x5011D4, 'Gear, 1 to 4 (the bracketed number beside the speed; manual and automatic).' + F),
            accel(),
            sm_ram('car_class', 'Byte', 0x501085, 'The car chosen: 0 EASY, 1 NORMAL, 2 HARD, 3 SPECIAL.' + F),
            calc('rev_limit', 'car_class == 0 || car_class == 3 ? 7650 : 8500', "This car's rev limit, where the revs sit in "
                 "Alexis's recordings (18 November 2026): NORMAL and HARD 8,500 (8.2k on the dial); EASY 7,650 (first 7,880, second "
                 '7,640, third 7,610); SPECIAL 7,650, the same place on the dial as 8,500 is to 8.2k, for her 7.4k (second and third '
                 'sat at 6,990 in one recording and 7,800 in the next; the automatic changes up at about 7,400). First gear\'s '
                 '8,500 reads full on every car.'),
            calc('rpm_frac', 'car_class >= 0 && car_class <= 3 ? clamp(rpm * max_revs / rev_limit, 0, 1.1) : rpm * max_revs / 8500',
                 "Revs as a fraction of this car's rev limit, so the rev limiter and engine effects reach full on every car."),
            sm_ram('throttle', 'Byte', 0x501183, 'Throttle as the game uses it, 0 to 1 (0 to 255).' + F, formula='value / 255'),
            sm_ram('brake', 'Byte', 0x50113F, 'Brake, 0 to 1.' + F, formula='value / 255'),
            sm_ram('steer', 'Int32', 0x501140, 'Steering input, -1 full left to 1 full right (the game holds -32766 to 32766).' + F,
                   formula='value / 32766'),
            sm_ram('head_x', 'Float', 0x5010D8, "Where the car points: the x part of its forward direction." + F),
            sm_ram('head_z', 'Float', 0x5010F0, "Where the car points: the z part of its forward direction, turned round." + F),
            sm_ram('move_x', 'Float', 0x5010F8, 'How far the car moved in the last frame along x, metres.' + F),
            sm_ram('move_y', 'Float', 0x5010FC, 'How far the car moved in the last frame up (+) or down, metres.' + F),
            sm_ram('move_z', 'Float', 0x501100, 'How far the car moved in the last frame along z, metres.' + F),
            calc('drift_angle', 'racing && speed * max_speed > 10 ? atan2(-(move_x * head_z + move_z * head_x), move_x * head_x - '
                 'move_z * head_z) * 57.29578 : 0', 'Drift angle, degrees: between where the car points and where it is going, + '
                 'pointing right of its path (worked out as for Scud Race, whose sign Alexis confirmed); over 120 the car is going '
                 'backwards. 0 under 10 km/h and outside a race.'),
            calc('drift', 'abs(drift_angle) > 120 ? 0 : pow(clamp((abs(drift_angle) - 10) / 72, 0, 1), 0.6) * sqrt(clamp((speed * '
                 'max_speed - 20) / 80, 0, 1))', "Drifting, 0 to 1: from 10 degrees, eased, full at 82, set from Alexis's three points "
                 '(18 November 2026): 26 to 30 degrees about 0.45 (Advanced, lap 2 0:33.26), 64 degrees about 0.8 (Beginner, lap 4 '
                 '0:13.54), 82 degrees 1 (Expert, lap 1 2:14.81); times the speed part (full from 100 km/h; her drifts were all at '
                 '260 to 295 km/h); 0 going backwards.'),
            sm_ram('crash', 'Byte', 0x501137, "The game's crash timer: 28 at a big crash (302 to 143 km/h into the wall in the "
                   "emulator), counting down." + F),
            sm_ram('seg', 'Int32', 0x501220, "The strip of road under the car's middle, numbered along the course." + F),
            sm_ram('seg_fl', 'Int32', 0x501224, 'The strip under the front left wheel: several hundred off `seg` against a wall.' + F),
            sm_ram('seg_fr', 'Int32', 0x501228, 'The strip under the front right wheel.' + F),
            sm_ram('seg_rl', 'Int32', 0x50122C, 'The strip under the rear left wheel.' + F),
            sm_ram('seg_rr', 'Int32', 0x501230, 'The strip under the rear right wheel.' + F),
            calc('edge_left', 'racing && (abs(seg_fl - seg) > 300 || abs(seg_rl - seg) > 300) && !(abs(seg_fr - seg) > 300 || '
                 'abs(seg_rr - seg) > 300)', "1 while a left wheel is off the road's strip (against a wall, or on the edge) and no "
                 'right wheel is: both sides at once is the lap line or a fork, where the strips are numbered afresh.'),
            calc('edge_right', 'racing && (abs(seg_fr - seg) > 300 || abs(seg_rr - seg) > 300) && !(abs(seg_fl - seg) > 300 || '
                 'abs(seg_rl - seg) > 300)', 'The same for the right wheels.'),
            calc('wall_contact', 'edge_left ? -1 : (edge_right ? 1 : 0)', 'Touching or scraping a wall on the left (-1) or right '
                 '(1). As in Scud Race, a verge lane can read as the far wall.'),
            sm_ram('near_car', 'Byte', 0x501081, 'Another car within about 5 m (bit 4, value 16), as in Scud Race.' + F,
                   formula='bits(value, 4, 1)'),
            sm_ram('car_contact', 'Float', 0x5013C0, 'Touching another car: how hard, 0.002 to 0.55, 0 when not (no side). Found in '
                   'the emulator as a candidate; in Alexis\'s recordings it fires at her car-hit marks with a car close, never at '
                   'walls (18 November 2026).'),
            calc('car_touch', 'maxw(car_contact, 0.2) > 0', '1 while touching another car (held 0.2 s; the value flickers).'),
            calc('pit_stop', 'racing && rt > 0 && maxw(rt, 0.3) == minw(rt, 0.3)', '1 in a pit stop: the time left stands still '
                 'while the race clock runs (Alexis\'s Beginner recording: from just after the lap line to the end of the stop, '
                 'then the game drives out of the pit lane with the time running).'),
            calc('hit', 'racing && !pit_stop ? max(maxw(valid(delta(crash), 0) > 10, 0.3) > 0 ? 1 : 0, maxw(car_contact > 0 ? '
                 'clamp(0.4 + car_contact * 1.2, 0.4, 1) : 0, 0.2), maxw(wall_contact != 0 || car_touch, 0.3) > 0 ? clamp(0.4 + '
                 '(maxw(speed * max_speed, 0.25) - speed * max_speed - 10) / 60, 0, 1) * (maxw(speed * max_speed, 0.25) - speed * '
                 'max_speed > 10) : 0) : 0', "A hit, 0 to 1: 1 for a big crash (the game's crash timer); touching another car 0.4 "
                 'to 1 by how hard, for 0.2 s; losing speed while touching a wall or a car, 0.4 at 10 km/h lost in 0.25 s up to 1 '
                 'at 46 km/h. Not in a pit stop (the game brakes into the pit lane).'),
            calc('hit_side', 'hit > 0 ? (maxw(car_touch, 0.3) > 0 && maxw(abs(force), 0.3) > 0 ? sign(valid(hold(force, force != 0), '
                 '0)) : sign(maxw(edge_right, 0.3) - maxw(edge_left, 0.3))) : 0', 'Side of a hit, -1 left, 1 right. A car hit takes '
                 'the side of the game\'s roll command sent with it (`force`, so -outputs=net is needed): her left-rear, left-rear, '
                 'right-rear and right-side hits got roll right, roll right, roll left, roll left (18 November 2026). Hits on the '
                 'front corners send another command (175), so no side; nor without the outputs. A wall hit takes the side of the '
                 'wheels against it (her crashes: left, right, left then right, all as she saw them).'),
            cand('speed_2cc', 'Float', 0x5012CC, "Follows the speed at 0.87 of the km/h, another speed in the game's units."),
        ]
    def rawdrive_daytona2(src, note):
        c = 'ffb_cmd'
        return [calc(c, f'valid({src}, 0)', 'The force feedback command the game sends.' + note),
                calc('force', hold0(f'{c} >= 80 && {c} <= 95 ? -({c} - 79) / 16 : ({c} >= 96 && {c} <= 111 ? ({c} - 95) / 16 : 0)',
                                    f'({c} >= 80 && {c} <= 111) || {c} == 128'),
                     'Force, -1 to 1, kept until the next force command ("roll right" -, "roll left" +, 0x80 stops it).'),
                calc('spring', hold0(f'{c} >= 10 && {c} <= 31 ? clamp(({c} - 9) / 16, 0, 1) : 0', f'({c} >= 10 && {c} <= 31) || ({c} >= 64 && {c} <= 79)'),
                     'Centring spring, 0 to 1, kept until changed (0 while "uncentering").'),
                calc('friction', hold0(f'clamp(({c} - 31) / 16, 0, 1)', f'{c} >= 32 && {c} <= 47'), 'Friction ("clutch"), 0 to 1, kept until changed.'),
                calc('vibration', f'{c} >= 48 && {c} <= 63 ? ({c} - 47) / 16 : 0', 'Vibration ("centering"), 0 to 1.'),
                ] + force_tail()
    def short_force():
        rows = rawdrive_daytona2('out_RawDrive', SM)
        for r in rows:   # Scud and Daytona 2 PE (18 November 2026): a roll command lasts 0.1 s, as the wheel force over USB showed
            if r['Name'] == 'force':
                r['Formula'] = ('maxw((ffb_cmd >= 80 && ffb_cmd <= 111), 0.1) > 0 ? valid(hold(ffb_cmd >= 80 && ffb_cmd <= 95 ? '
                                '-(ffb_cmd - 79) / 16 : (ffb_cmd - 95) / 16, ffb_cmd >= 80 && ffb_cmd <= 111), 0) : 0')
                r['Notes'] = ('Force, -1 to 1 ("roll right" -, "roll left" +), for 0.1 s after each roll command. Kept until the next '
                              "command (as SMDAYTONA2 and SMLEMANS24 still do), it matched the wheel force over USB poorly in Alexis's "
                              'Scud Race and Daytona 2 recordings (correlation 0 to 0.4); like this 0.15 to 0.8 (18 November 2026).')
        return rows
    out_profile('SMDAYTO2PE', 'Daytona USA 2 Power Edition (Supermodel)', short_force() + sm_lamps() + d2pe_rows(), max_speed=350, max_revs=8500)
    for pre, disp in [('SMDAYTONA2', 'Daytona USA 2 (Supermodel)'), ('SMSCUD', 'Scud Race (Supermodel)'), ('SMLEMANS24', 'Le Mans 24 (Supermodel)')]:
        if pre == 'SMSCUD':
            out_profile(pre, disp, short_force() + sm_lamps() + smscud_rows(), max_speed=350, max_revs=9500)
        else:
            out_profile(pre, disp, rawdrive_daytona2('out_RawDrive', SM))
    out_profile('SMDIRTDEVILS', 'Dirt Devils (Supermodel)', [
        calc('ffb_cmd', 'valid(out_RawDrive, 0)', 'The force feedback command the game sends.' + SM),
        calc('spring', hold0('0.7', 'ffb_cmd == 16'), 'Centring spring: the FFB plugin sets 0.7 for command 0x10.'),
        calc('vibration', 'ffb_cmd == 47 ? 1 : 0', 'Vibration (command 0x2F).'),
    ])
    for pre, disp in [('SMSRALLY2', 'Sega Rally 2 (Supermodel)'), ('SMECA', 'Emergency Call Ambulance (Supermodel)')]:
        out_profile(pre, disp, [
            calc('ffb_cmd', 'valid(out_RawDrive, 0)', 'The force feedback command the game sends.' + SM),
            calc('force', hold0('ffb_cmd > 0 && ffb_cmd <= 63 ? ffb_cmd / 64 : -(ffb_cmd - 64) / 64', 'ffb_cmd > 0 && ffb_cmd <= 127'),
                 'Force, -1 to 1, kept until the next command (1 to 63 from the right, 64 to 127 from the left).'),
        ] + force_tail())
    out_profile('MAMEVR', 'Virtua Racing (MAME)', [
        calc('ffb_cmd', 'valid(out_digit0, 0)', 'The force feedback command (output digit0).' + MAME),
        calc('force', hold0('ffb_cmd == 80 || ffb_cmd == 95 ? 0.5 : -0.5', 'ffb_cmd == 80 || ffb_cmd == 95 || ffb_cmd == 96 || ffb_cmd == 111'),
             'Force, +0.5 or -0.5 ("roll left" from the right, "roll right" from the left), kept until the next.'),
        calc('spring', hold0('ffb_cmd >= 48 && ffb_cmd <= 63 ? clamp((ffb_cmd - 47) / 11, 0, 1) : 0.8',
                             'ffb_cmd == 3 || ffb_cmd == 7 || ffb_cmd == 9 || ffb_cmd == 16 || (ffb_cmd >= 48 && ffb_cmd <= 63)'), 'Centring spring, 0 to 1.'),
        calc('vibration', 'ffb_cmd == 64 || ffb_cmd == 70 || ffb_cmd == 74 ? 0.4 : 0', 'Vibration (0.4, as the FFB plugin plays it).'),
    ] + force_tail())
    def wheel_full(src, sign):
        return [calc('ffb_cmd', src, 'The wheel motor value the game sends, 0 to 255.' + MAME),
                calc('force', f'ffb_cmd > 128 && ffb_cmd < 256 ? {"-" if sign > 0 else ""}(256 - ffb_cmd) / 126 : (ffb_cmd > 0 && ffb_cmd < 128 ? {"" if sign > 0 else "-"}ffb_cmd / 126 : 0)',
                     'Force, -1 to 1 (above 128 one way, below the other), as the FFB plugin decodes it.')] + force_tail()
    for pre, disp in [('MAMECALSPEED', 'California Speed (MAME)'), ('MAMEHYPRDRIV', 'Hyperdrive (MAME)'),
                      ('MAMESF2049', 'San Francisco Rush 2049 (MAME)'), ('MAMEVAPORTRX', 'Vapor TRX (MAME)')]:
        out_profile(pre, disp, wheel_full('valid(out_wheel, valid(out_wheel_motor, 0))', 1))
    for pre, disp in [('MAMECRUSNUSA', "Cruis'n USA (MAME)"), ('MAMECRUSNWLD', "Cruis'n World (MAME)"), ('MAMEOFFROADC', 'Off Road Challenge (MAME)'),
                      ('MAMESFRUSH', 'San Francisco Rush (MAME)'), ('MAMESFRUSHRK', 'San Francisco Rush: The Rock (MAME)')]:
        out_profile(pre, disp, wheel_full('valid(out_wheel, 0)', -1))
    VIB1 = ('valid(out_MA_Steering_Wheel_motor, 0) == 1 || valid(out_upright_wheel_motor, 0) == 1 || valid(out_Vibration_motor, 0) == 1 || '
            'valid(out_Wheel_vibration, 0) == 1 || valid(out_Wheel_Vibration, 0) == 1')
    for pre, disp in [('MAMEORUNNERS', 'OutRunners (MAME)'), ('MAMETOUTRUN', 'Turbo Out Run (MAME)'), ('MAMECBOMBERS', 'Cadash Bombers / Chase Bombers (MAME)'),
                      ('MAMEDBLAXLE', 'Double Axle (MAME)')]:
        out_profile(pre, disp, [calc('vibration', VIB1, '1 while the game runs its wheel shaker motor (the only force these games send).' + MAME)])
    for pre, disp in [('MAMECISCHEAT', 'Cisco Heat (MAME)'), ('MAMEF1GPSTAR', 'F1 Grand Prix Star (MAME)')]:
        out_profile(pre, disp, [calc('vibration', 'valid(out_led2, 0) == 1', '1 while the game runs its wheel shaker (output led2).' + MAME)])
    out_profile('MAMEOUTRUN', 'Out Run (MAME)', [
        calc('bank_dir', 'valid(out_Bank_Motor_Direction, 0)', 'Deluxe cabinet bank motor direction: 1 one way, 2 the other.' + MAME),
        calc('bank_speed', 'valid(out_Bank_Motor_Speed, 0)', 'Bank motor speed, 0 to 7.' + MAME),
        calc('force', 'bank_dir == 1 ? -(1 + bank_speed) / 8 : (bank_dir == 2 ? (1 + bank_speed) / 8 : 0)', 'Force from the bank motor, -1 to 1, as the FFB plugin plays it.'),
        calc('vibration', 'valid(out_Vibration_motor, 0) == 1', '1 while the shaker motor runs.' + MAME),
    ] + force_tail())
    out_profile('MAMEPDRIFT', 'Power Drift (MAME)', [
        calc('bank_pos', 'valid(out_bank_motor_position, 4)', 'Bank motor position, 1 to 7 (4 = centre).' + MAME),
        calc('force', 'bank_pos > 0 && bank_pos < 4 ? -(4 - bank_pos) / 3 : (bank_pos > 4 && bank_pos < 8 ? (bank_pos - 4) / 3 : 0)', 'Force from the bank motor, -1 to 1.'),
        calc('vibration', 'max(valid(out_vibration_motor, 0) / 7, valid(out_upright_wheel_motor, 0) == 1)', 'Vibration, 0 to 1 (deluxe shaker level, or the upright shaker on).' + MAME),
    ] + force_tail())

    # Flycast's emulated RAM (17 November 2026, from Alexis's flycast.exe: v2.5-219-g27a913fc0, 64-bit, MD5
    # d0def34950920645bce4acdfa21bb36e; claude/FLYINITD3-flycast-20261117.md). The mapping set-up at <main>+140929 stores
    # ram_base + 0x0C000000 in mem_b.data, the global at <main>+2840C90 (ram_base itself is <main>+2253CE0). So a game
    # address 0x0Cxxxxxx (or its mirror 0x8Cxxxxxx) is read as <main>+2840C90 -> + (address & 0x1FFFFFF): NAOMI 2 has
    # 32 MB of RAM (NAOMI 16 MB: & 0xFFFFFF). Another Flycast build needs its own base offset.
    # 19 November 2026: Alexis moved to Flycast v2.7-1-g44e4c7b50 (64-bit, MD5 d8db8f697e26e5384a186eb2c8b79289), where every
    # memory row read nothing. The same set-up code (<main>+147DF9: lea rdx, [rax + 0xc000000]; add rax, 0xa000000) stores to
    # mem_b.data through the pointer at <main>+129D910, which holds <main>+29D0C10; the fallback reads at <main>+18EB37 use
    # the same global, and ram_base is <main>+24236E0. Hence FLY_RAM 29D0C10 (v2.5-219-g27a913fc0's was 2840C90).
    FLY_RAM = '29D0C10'
    def fly_ram(name, typ, addr, notes, formula='', ram=0x1FFFFFF):
        return mem(name, typ, FLY_RAM, notes, offsets=f'{addr & ram:X}', formula=formula)
    def fly_ptr(name, typ, chain, notes, formula=''):
        # A value reached through the game's own pointers (32-bit game addresses): `chain` is the fixed game address of the
        # first pointer, then the offset added after each pointer. Written with "@" offsets, which the plugin follows inside
        # the emulated RAM from 0.18.2 (helper 0.17.1).
        offs = [f'{chain[0] & 0x1FFFFFF:X}'] + [f'@{o:X}' for o in chain[1:]]
        return mem(name, typ, FLY_RAM, notes, offsets=', '.join(offs), formula=formula)
    def fly_id3_rows():
        # Lamps: Flycast's JVS board sends each changed output bit as "lamp<bit>" (bit 0 to 31; the first output byte is
        # bits 0 to 7). Which bit is which lamp isn't known yet: a recording settles it.
        bits = ' + '.join(f'valid(out_lamp{i}, 0) * {1 << i}' for i in range(16))
        return ([calc(f'lamp{i}', f'valid(out_lamp{i}, 0)',
                      f"The cabinet's output bit {i} (0 or 1), as Flycast sends it. Which lamp it is still needs a recording." + FLY)
                 for i in range(8)] + [
            calc('lamp_bits', bits, "Output bits 0 to 15 in one number (bit 0 = 1, bit 1 = 2, ...), so a recording shows every "
                 "lamp change in one column, including any bit above 7. In Alexis's recordings of 17 November 2026 bit 3 blinked once a "
                 "second from the grid through the race (and stayed on for a few seconds in a menu), and bit 7 came on briefly once; "
                 "no bit follows the lead." + FLY),
            fly_ram('ram_probe', 'UInt32', 0x0C020000, "Plumbing check, not telemetry: the first four bytes of the game's program "
                    "in Flycast's emulated RAM (game address 0x0C020000). A steady 3509307139 while the game runs (every sample of "
                    "eight recordings of 17 November 2026) shows the plugin reads the game's memory. 0 or a read error on another "
                    "Flycast build means its RAM pointer has moved from <main>+29D0C10 (v2.7-1-g44e4c7b50; 2840C90 in v2.5-219): every memory row "
                    "then reads nothing until it is found again (claude/FLYINITD3-flycast-20261117.md says how)."),
        ] + fly_id3_game())
    # ram_probe: removed on 17 November 2026 (evening), put back on 18 November at Alexis's request, to test newer Flycast
    # builds with.

    # Initial D 3's own values, from two of Alexis's save states (17 November 2026, GT-R, Akina Lake, vs Iggy; the HUD in each
    # state's screenshot): claude/FLYINITD3-states-20261117.md. The player's car is a static structure around 0x0C9008A4 to
    # 0x0C9017F8 (the game's code refers to 0x0C900954, 0x0C900F00, 0x0C900E88, 0x0C900EA4, 0x0C901650 directly).
    def fly_id3_game():
        ST = ' Matched the HUD in two save states (174 km/h, 4th, 9,300 and 202 km/h, 5th, 8,650; 17 November 2026).'
        R = " Alexis's recordings of 17 November 2026 (Civic, automatic, Irohazaka time trial; RX-7, manual, Akagi story race)."
        C = ' Candidate, not identified: recorded so a capture can show what it is.'
        def cand(name, typ, addr, what):
            return dict(fly_ram(name, typ, addr, what + C), Enabled=False)
        return [
            fly_ram('speed', 'Float', 0x0C900C2C, 'Speed: the car\'s forward speed in m/s x 3.6, which is the km/h the speedo shows '
                    '(it shows the whole number below).' + ST + ' Divided by Max speed (blank = 1, so km/h).',
                    formula='value * 3.6 / max_speed'),
            fly_ram('rpm', 'Float', 0x0C900EA4, 'Engine revs, RPM, as the rev counter shows them.' + ST),
            fly_ram('gear', 'Int32', 0x0C900E88, 'Gear, 1 to 5 (or 6); 0 on the grid until GO, with a manual or an automatic.' + ST),
            accel(),
            fly_ram('gap', 'Float', 0x0C901650, 'ADVANTAGE: metres ahead of the rival (+) or behind (-); 0 with no rival (time trial).' + ST),
            fly_ram('thr_revs', 'Float', 0x0C900E9C, 'The revs the throttle is asking for: 800 with the pedal up, rising to the car\'s '
                    'rev limit with it down (9000 Civic and GT-R, 7000 RX-7), and 0 when no car is on the road. Follows the pedal over '
                    'USB (correlation 0.96).' + R),
            fly_ram('rpm_top', 'Float', 0x0C900EA8, 'Revs over the top of this car\'s scale, which is its rev limit + 500 (9500 Civic and '
                    'GT-R, 7500 RX-7: revs / this value is that number on every sample).' + R),
            calc('live', 'thr_revs > 0', '1 while your car is on the road: from the grid (before the countdown ends) on. 0 in the menus '
                 'and while a race loads.'),
            calc('rev_limit', 'valid(hold(round(rpm * max_revs / rpm_top / 500) * 500 - 500, rpm_top > 0.3 && live), 0)',
                 "This car's rev limit, RPM, worked out from the two rows above once the engine is past 30% of its scale (to the "
                 "nearest 500: the two rows are read a moment apart)."),
            calc('rpm_frac', 'rev_limit > 0 ? clamp(rpm * max_revs / rev_limit, 0, 1.1) : 0', "Revs as a fraction of this car's rev limit."),
            calc('throttle', 'live && rev_limit > 800 ? clamp((thr_revs - 800) / (rev_limit - 800), 0, 1) : 0',
                 'Throttle, 0 to 1, from the revs the throttle asks for (800 = pedal up, the rev limit = pedal down).'),
            fly_ram('steer', 'Float', 0x0C900BB8, 'Steering as the game uses it, -1 full left to 1 full right (the game\'s own value is + '
                    'left: turned round here). Follows the wheel over USB (correlation 0.98).' + R, formula='-value'),
            fly_ptr('rt', 'Int32', (0x0C8FF174, 0x418, 0x8), 'Time left (RT), seconds: the race\'s countdown timer, which the game '
                    'counts in 1/6000 s. Reached through the game\'s pointer to the race (0x0C8FF174), so it follows the race from '
                    'one to the next; matched the screen in three save states (37, 48 and 27 s; GT-R story race and a time trial) '
                    'and ran 90 s down with two extensions in a recording (17 November 2026, 16:57). Needs plugin 0.18.2.', formula='value / 6000'),
            fly_ptr('race_clock', 'Int32', (0x0C8FF174, 0x588), 'Race clock (TT), seconds, in the same race object: matched the screen '
                    'in three save states (1:52.18, 2:40.88, 2:30.83); starts at GO and stops at the line (3:09.83 in the recording '
                    'of 17 November 2026, 16:57). Needs plugin 0.18.2.',
                    formula='value / 6000'),
            fly_ptr('lap', 'Int32', (0x0C8FF174, 0x590), 'Lap or section, counting the first as 1 (2, 3 and 3 in the three save '
                    'states, as the screen\'s list showed; 1, 2, 3 at the lap lines in a recording). Needs plugin 0.18.2.', formula='value + 1'),
            calc('race_ok', 'valid(lap, 0) >= 1 && valid(lap, 0) <= 99 && valid(rt, -1) > 0 && valid(rt, -1) < 1000 && '
                 'valid(race_clock, -1) >= 0 && valid(race_clock, -1) < 7200',
                 '1 while the race object reads sensibly (lap 1 to 99, time left above 0 and under 1000 s, race clock 0 to 2 hours), so 0 at time up. As a race is '
                 'cleared away its memory holds rubbish for about half a second (Alexis\'s recording of 17 November 2026, 16:57), '
                 'which this keeps out of the rows below.'),
            calc('racing', 'live && gear > 0 && race_ok && maxw(valid(delta(race_clock), 0) > 0 && valid(delta(race_clock), 0) < 0.5, 0.3) > 0',
                 '1 from GO to the finish line or time up: the car is on the road and out of neutral (the game holds the gear at 0 '
                 'through the countdown) and the race clock is moving, so it also drops while the game is paused. Checked in '
                 'Alexis\'s recording of 17 November 2026 (16:57): on at GO, off at the line (TT 3:09.83), nothing in the menus.'),
            calc('lampleader', 'live && race_ok && valid(race_clock, 0) > 0 && gap >= 0',
                 'Leader lamp, made from the race values: 1 from GO while level with or ahead of the rival (ADVANTAGE 0 or more), so '
                 'lit throughout a time trial, where there is no rival; it keeps its state after the finish line until the race is '
                 'cleared away, as Initial D Zero\'s does (lamps aren\'t tied to racing). Not a cabinet output.'),
            calc('lampcheckpoint', 'maxw(race_ok && valid(delta(rt), 0) > 0.5 && valid(delta(rt), 0) < 300, 2) > 0',
                 'Checkpoint lamp, 0 or 1: lit for 2 s when the time left jumps up (time extended at a checkpoint or lap line). '
                 'Made from the race values, as Alexis asked. Checked in her recording of 17 November 2026 (16:57): at both lap '
                 'lines (17 s to 77 s, 18 s to 77 s), within 0.1 s of her marks.'),
            fly_ram('contact', 'Int32', 0x0C900B40, '1 while the car touches a guard rail, wall, the edge of a gutter or the other car: '
                    'on at each contact Alexis described in two recordings (17 November 2026).'),
            fly_ram('kick_x', 'Float', 0x0C900C48, 'The sideways knock a contact gives the car, about -0.3 to 0.3: - for a contact on '
                    'the left, + on the right. Right for six of the seven rail, wall and gutter contacts whose side Alexis gave '
                    '(one rear-left slide into a rail read +).'),
            fly_ram('kick_y', 'Float', 0x0C900C4C, 'The lengthways knock of a contact: - when the front hits (her nose into the rival\'s '
                    'tail read -0.26).'),
            calc('contact_side', 'valid(hold(sign(kick_x), contact && abs(kick_x) > 0.02), 0)', 'Side of the latest contact, -1 left, 1 right, '
                 'from the sideways knock, kept while the contact lasts.'),
            calc('wall_contact', 'racing && contact ? contact_side : 0', 'Touching or scraping a guard rail, wall or gutter edge: -1 on the '
                 'left, 1 on the right, 0 otherwise. Alexis, 17 November 2026: treat these as guard rails rather than wall hits.'),
            calc('hit', 'racing ? clamp((hypot(kick_x, kick_y) - 0.1) / 0.2, 0, 1) : 0', 'A hard knock, 0 to 1: nothing for the light '
                 'touches (a knock under 0.1), full at 0.3 (her hardest rail hits and the nose into the rival\'s tail).'),
            calc('hit_side', 'hit > 0 ? sign(kick_x) : 0', 'Side of a hard knock, -1 left, 1 right.'),
            calc('gutter', 'racing && (wheel_a == 18 || wheel_a == 32 || wheel_a == 48 || wheel_a == 49 || wheel_b == 18 || wheel_b == 32 || wheel_b == 48 || wheel_b == 49 || wheel_c == 18 || wheel_c == 32 || wheel_c == 48 || wheel_c == 49 || wheel_d == 18 || wheel_d == 32 || wheel_d == 48 || wheel_d == 49)',
                 '1 while a wheel is in a gutter or on a kerb: surface codes 48 (Akagi\'s gutter), 49 (Irohazaka\'s gutter, full of '
                 'leaves), 18 (Irohazaka\'s kerb with leaves) and 32 (Myogi\'s right-hand kerb and gutter; also beside the rails on '
                 'Akagi and Irohazaka), as Alexis named them (17 November 2026). Other courses may use other codes.'),
            calc('grooved_road', 'racing && (wheel_a == 21 || wheel_b == 21 || wheel_c == 21 || wheel_d == 21)',
                 '1 on grooved concrete (surface code 21, Myogi): lines pressed into the road along its length, as Alexis described it. '
                 'The game doesn\'t shake the wheel for it.'),
            calc('rumble_strip', 'racing && (wheel_a == 20 || wheel_b == 20 || wheel_c == 20 || wheel_d == 20)',
                 '1 while a wheel is on a ripple strip: surface code 20, the only surface the game shakes the wheel hard for (vibration '
                 '0.22 against 0.01 on plain road): 48 spells in her three-lap race on Myogi (16:57), 16 in another (17:50). '
                 'Alexis confirmed the one at TT 0:06.10 (17 November 2026).'),
            fly_ram('yaw', 'Float', 0x0C9008C0, 'Where the car points: its heading in radians, running on past a full turn (the unit '
                    'vector beside it at 0x0C900D10 is its sine and cosine; three save states).'),
            fly_ram('move_x', 'Float', 0x0C9008B0, 'Distance the car moved in the last frame along x, m (x 216 with move_z gives km/h: '
                    '173.7, 202.9 and 111.6 in three save states; follows the path within a degree in three recordings).'),
            fly_ram('move_z', 'Float', 0x0C9008B8, 'Distance the car moved in the last frame along z, m.'),
            calc('drift_angle', 'racing && speed * max_speed > 10 ? -wrap(yaw * 57.29578 - atan2(-move_x, -move_z) * 57.29578, 360) : 0',
                 'Drift angle, degrees: between where the car points and where it is going, + pointing right of its path (a '
                 'right-hand drift). 0 below 10 km/h and outside a race. Checked in Alexis\'s drift recording of 17 November 2026 '
                 '(19:33, RX-7 on Akagi): + in every right-hand drift and - in every left (99% of samples over 15 degrees), her '
                 'drifts peaking at 18 to 21 degrees. A rail contact can swing it (32 degrees against a rail there).'),
            calc('drift_curve', '(1 - pow(1 - clamp((abs(drift_angle) - 5) / 40, 0, 1), 2)) * sqrt(clamp((speed * max_speed - 20) / 80, 0, 1))',
                 'Drifting, 0 to 1: ID6\'s curve (nothing under 5 degrees or 20 km/h, eased, full from 100 km/h) made full at 45 '
                 'degrees instead of 50, so her hardest drifts read about 0.62, as Alexis asked (0.6 to 0.65, in line with the '
                 'other Initial D games; 17 November 2026).'),
            calc('drift', 'contact ? min(drift_curve, valid(hold(drift_curve, !contact), 0)) : drift_curve',
                 'Drifting, 0 to 1 (Car_drift): drift_curve, but never more during a contact than just before it, so a rail '
                 'knocking the car sideways doesn\'t read as a big drift (it read 0.93 for a moment in her recording; 0.62 is the '
                 'top of her real drifts).'),
            dict(fly_ram('steer_raw', 'Int32', 0x0C901688, 'The steering input as the game reads it from the cabinet: 0 to 16383, about 8192 '
                         'centred, higher to the left.' + R), Enabled=False),
            cand('contact_code', 'Int32', 0x0C900B44, '0 to 3, changing as `contact` comes on and during it, and held afterwards; it didn\'t line up with the side in five described contacts.'),
            cand('contact_level', 'Float', 0x0C900B48, '0 to 0.30, rising with `contact`: perhaps how hard.'),
            cand('wheel_a', 'Int32', 0x0C900A74, 'What a wheel is on, one of four (a and b the front pair): 16 plain road, 20 ripple strip, 21 grooved concrete '
                 '(Myogi), 48 and 49 the gutter (Akagi, Irohazaka), 18 kerb with leaves (Irohazaka), 32 kerb and gutter (Myogi; '
                 'beside rails elsewhere), 14 against a rail; 22, 26, 27, 28, 57 seen briefly. Names from Alexis, 17 November 2026.'),
            cand('wheel_b', 'Int32', 0x0C900A78, 'The second of the four.'),
            cand('wheel_c', 'Int32', 0x0C900A7C, 'The third of the four.'),
            cand('wheel_d', 'Int32', 0x0C900A80, 'The fourth of the four.'),
            cand('progress', 'Int32', 0x0C900B08, 'Counts up along the course (8 on the Akagi grid, 504 two and a half minutes on).'),
            cand('speed_abs', 'Float', 0x0C900C28, 'Speed in m/s: matches the speed worked out from the position.'),
            cand('vel_side', 'Float', 0x0C900C30, 'Next to the forward speed: -0.13 to 0.53.'),
            cand('vel_c24', 'Float', 0x0C900C24, 'Before the speed: -0.46 to 0.53.'),
            cand('in_c14', 'Float', 0x0C900C14, '0 to 120.'),
            cand('in_c38', 'Float', 0x0C900C38, '0 to 0.71.'),
            cand('in_c3c', 'Float', 0x0C900C3C, '-1 whenever the throttle is up (also after the finish line), up to 1 under power in the low gears: drive, not the brake.'),
            cand('in_bd4', 'Float', 0x0C900BD4, '-1 to 1; follows the steering loosely (0.62).'),
            cand('in_bd8', 'Float', 0x0C900BD8, '-0.225 to 0.2875 in a few dozen steps.'),
            cand('in_be4', 'Float', 0x0C900BE4, '0 to 1.8.'),
            cand('in_df8', 'Float', 0x0C900DF8, '0 to 0.2875 in about ten steps.'),
            cand('pos_x', 'Float', 0x0C9009F0, 'Car position, first axis (m).'),
            cand('pos_y', 'Float', 0x0C9009F4, 'Car position, height (m).'),
            cand('pos_z', 'Float', 0x0C9009F8, 'Car position, third axis (m).'),
            cand('blk_3a8', 'Int32', 0x0C2FB3A8, '0 to 10, in a small block with copies of the gear and revs.'),
            cand('misc_1e8', 'Int32', 0x0C8FF1E8, 'Counts up quickly from 0 for a second or two, then starts again.'),
        ]

    def midi(pre, disp):
        v = 'valid(out_midiffb, 0)'
        out_profile(pre, disp, [
            calc('ffb_raw', v, 'The MIDI force feedback message: byte 2 = command, byte 1 = direction or period, byte 0 = strength.' + FLY),
            calc('ffb_cmd', 'byte(ffb_raw, 2)', 'Command: 0x84 (132) force, 0x85 (133) vibration, 0x86 (134) spring, 0x80 (128) full spring.'),
            calc('ffb_str', 'byte(ffb_raw, 0)', 'Strength, 0 to 127.'),
            calc('force', hold0('byte(ffb_raw, 1) == 0 ? -(128 - ffb_str) / 127 : ffb_str / 127', 'ffb_cmd == 132 && ffb_str > 0 && ffb_str < 128'),
                 'Force, -1 to 1, kept until the next force command (direction 0 from the left, 1 from the right).'),
            calc('spring', hold0('ffb_cmd == 134 ? ffb_str / 127 : 1', '(ffb_cmd == 134 && ffb_str > 0 && ffb_str < 128) || (ffb_cmd == 128 && ffb_str == 1)'),
                 'Centring spring, 0 to 1, kept until changed.'),
            calc('vibration', 'ffb_cmd == 133 && byte(ffb_raw, 1) > 0 ? ffb_str / 127 : 0', 'Vibration strength while the game asks for it, 0 to 1.'),
        ] + force_tail() + ([
            calc('rpm', 'valid(out_tachometer, 0) / max_revs', 'Engine RPM, from the driving simulator\'s tachometer output (whole hundreds). Divided by Max revs.' + FLY),
            calc('speed', 'valid(out_speedometer, 0) / max_speed', 'Speed, from the driving simulator\'s speedometer output (units still to be checked). Divided by Max speed.' + FLY),
        ] if pre == 'FLYSGDRVSIM' else []) + (fly_id3_rows() if pre == 'FLYINITD3' else []), **(dict(max_speed=205, max_revs=9000) if pre == 'FLYINITD3' else {}))
    for pre, disp in [('FLYINITD', 'Initial D Arcade Stage (Flycast)'), ('FLYINITD2', 'Initial D Arcade Stage Ver. 2 (Flycast)'),
                      ('FLYINITD3', 'Initial D Arcade Stage Ver. 3 (Flycast)'), ('FLYINITDCY', 'Initial D Arcade Stage Ver. 3 Cycraft (Flycast)'),
                      ('FLYCLUBKART', 'Club Kart (Flycast)'), ('FLYKINGRT66', 'The King of Route 66 (Flycast)'),
                      ('FLYSGDRVSIM', 'Sega Driving Simulator (Flycast)')]:
        midi(pre, disp)
    for pre, disp in [('FLYMAXSPEED', 'Maximum Speed (Flycast)'), ('FLYFTSPEED', 'Faster Than Speed (Flycast)')]:
        out_profile(pre, disp, [
            calc('ffb_cmd', 'valid(out_awffb, 0)', 'The Atomiswave wheel output: bit 0 = direction, bits 1 to 4 = strength.' + FLY),
            calc('force', 'ffb_cmd > 0 ? (band(ffb_cmd, 1) ? -(ffb_cmd + 1) / 32 : ffb_cmd / 32) : 0',
                 'Force, -1 to 1: odd values from the left, even from the right, as the FFB plugin\'s table decodes them.'),
        ] + force_tail())
    def m3(pre, disp):
        c = 'ffb_cmd'
        def r(a, b): return f'({c} > {a} && {c} < {b})'
        force_expr = (f'{r(80, 96)} ? -({c} - 80) / 15 : ({r(96, 112)} ? ({c} - 96) / 15 : ({r(128, 144)} ? ({c} - 128) / 15 : '
                      f'({r(144, 160)} ? -({c} - 144) / 15 : ({r(160, 176)} ? -({c} - 160) / 15 : ({c} == 191 ? 1 : '
                      f'({r(224, 233)} ? -({c} - 224) / 8 : ({r(232, 240)} ? ({c} - 232) / 8 : 0)))))))')
        out_profile(pre, disp, [
            calc(c, 'valid(out_m3ffb, 0)', 'The motor board command the game sends.' + FLY),
            calc('force', hold0(f'clamp({force_expr}, -1, 1)', f'{r(80, 96)} || ({r(96, 112)} && ({c} < 104 || {c} > 107)) || {r(128, 176)} || {c} == 191 || {r(224, 240)} || {c} == 192'),
                 'Force, -1 to 1, kept until the next force command (0xC0 stops everything).'),
            calc('spring', hold0(f'{r(16, 32)} ? clamp(({c} - 10) / 15, 0, 1) : ({r(64, 80)} ? ({c} - 64) / 15 : ({r(192, 208)} ? ({c} - 192) / 15 : 0))',
                                 f'{r(16, 32)} || {r(64, 80)} || {r(192, 208)} || {c} == 192'), 'Centring spring, 0 to 1, kept until changed.'),
            calc('friction', hold0(f'{r(32, 48)} ? ({c} - 32) / 15 : ({r(208, 224)} ? ({c} - 208) / 15 : 0)', f'{r(32, 48)} || {r(208, 224)} || {c} == 192'),
                 'Friction, 0 to 1, kept until changed.'),
            calc('vibration', f'{r(48, 64)} ? ({c} - 48) / 15 : ({r(176, 192)} ? ({c} - 176) / 15 : 0)', 'Vibration, 0 to 1.'),
        ] + force_tail())
    for pre, disp in [('FLY18WHEELER', '18 Wheeler: American Pro Trucker (Flycast)'), ('FLYF355', 'Ferrari F355 Challenge (Flycast)')]:
        m3(pre, disp)


PROC = {
    'IDTA21': 'GameProject-Win64-Shipping.exe', 'IDTAS4': 'GameProject-Win64-Shipping.exe',
    'IDTAS5': 'GameProject-Win64-Shipping.exe', 'IDTAS5V321': 'GameProject-Win64-Shipping.exe', 'WMMT6RRP': 'wmn6r.exe',
    'FNFSB2': 'sdaemon.exe', 'THRILLDRIVE4': 'td4.exe', 'HYDROTHUNDER': 'HYDRO_x64.exe',
    'BG4': 'game.exe', 'HARLEY': 'BudgieLoader.exe', 'MOTOGP': 'BudgieLoader.exe', 'FNFDRIFT': 'sdaemon.exe', 'FNFSC': 'sdaemon.exe',
    'HUMMER': 'BudgieLoader.exe', 'HUMMEREXTREME': 'BudgieLoader.exe', 'CARS': 'sdaemon.exe',
    'CRAZYRIDE': 'CrazyTaxiGame-Win64-Shipping.exe', 'DEADHEATRIDERS': 'BudgieLoader.exe',
    'M2DAYTONA': 'emulator_multicpu.exe', 'M2INDY500': 'emulator_multicpu.exe', 'M2STCC': 'emulator_multicpu.exe',
    'M2OVERREV': 'emulator_multicpu.exe', 'M2SGT24H': 'emulator_multicpu.exe', 'M2SRALLY': 'emulator_multicpu.exe',
    'FLYINITD3': 'flycast.exe',   # reads Flycast's emulated RAM (17 November 2026); the other Flycast games use outputs only
    'SMSCUD': 'supermodel.exe', 'SMDAYTO2PE': 'supermodel.exe',   # reads Supermodel's emulated RAM (18 November 2026); the other Supermodel games use outputs only
}
BIT64 = {'IDTA21', 'IDTAS4', 'IDTAS5', 'IDTAS5V321', 'WMMT6RRP', 'CRAZYRIDE', 'FLYINITD3', 'SMSCUD', 'SMDAYTO2PE'}
NOTES = {
    'HYDROTHUNDER': "The tables cover three builds: HYDRO_x64.exe (unpatched), HYDRO_x64_x64.exe and HYDRO_x64_x86.exe (patched). "
                    "The addresses are the same in all three; change Process to match yours.",
}


# ---------------------------------------------------------------- Initial D Arcade Stage 6 AA (ID6), from its exe
# Alexis sent InitialD6_GLW_RE_SBUU_dump.exe (8 November 2026): v1.2 (OutputBlaster's checksum 0x08D4BACE, its
# "InitialD6Update"), built 15 August 2011, fixed base 0x400000. Read in claude/ID6-exe-20261108.md:
# * <main>+C6E210 is the game session (cGameSession); +20C its cRace. The race's +4 is its state (2 set-up, 3 start
#   and countdown, 4 racing, 5 a car has reached the goal, 6 after), +34 the player's slot, +28 + 4 x slot the cars
#   (cActor), each holding its cMoriCar at +28.
# * cMoriCar: +8 -> +0 a status block (+8 km/h, +C revs x a factor for each car, +10 gear); +F8C its physics (+790 m/s,
#   +9A8 engine revs, +208 throttle, +230 brake, +1C0 car contact); +1AB4 last frame's event flags (walls, guard rails,
#   car contact, gutters, landings, road joints, rumble strips: the flags the game plays its collision sounds from).
# The player can be in slot 0 or 1, so each value is read for both and picked by the player's slot.
# Checked in Alexis's recording of 9 November 2026 (story prologue, R32 GT-R, manual; claude/ID6-capture-20261109.md):
# speed = the speedo, rpm = the revs on screen (rpm_tacho is 1.08 x rpm in this car), gears, brake, slot 0, the lamps;
# events 0x1/0x2 are the gutter (left/right), not drains; the car-contact flag flickers off for a frame every 0.2 s.
# Initial D Arcade Stage Zero v2.30 (InitialD0_DX11_Nu.exe, 64-bit, MD5 2e506fe5e3d36fc4eff0d44389f4757b) from the game's own
# code (16 November 2026; claude/ID0V230-exe-20261116.md). The same engine as ID6 (the RTTI names cGameSession, cRace, cActor,
# cMoriCar survive), with 8-byte pointers:
#   <main>+18B4E50 -> cGameSession: +8 game mode (byte 0: 1 test, 2 time attack, 3 story, 4 in-store VS, 5 online, 7/9/11 the
#     attract demo's replays (9 also the live race), 15 2-on-2 VS, 16 tutorial, 17 beginner online), +290 cRace.
#   cRace: +8 state (2 set-up, 3 countdown, 4 racing, 5 a car reached the goal, 6 over), +18 gap to the rival (float, + ahead,
#     2-car races), +24 race clock ms (negative in the countdown; held while paused), +38/+40 the cars (cActor), +48 how many,
#     +4C the player's slot, +178 time left ms (the cheat table's "Stage_Tmr"), +17C extension still being added (ms).
#   cActor: +1C state (4 racing, 5 reached the goal, 6 race over), +38 the car (cMoriCar).
#   cMoriCar: +10 -> +0 the status block S (+8 km/h as the speedo shows it, +C tacho revs, +14 gear), +10B0 the physics P
#     (+260 throttle, +2A4 brake, +2C8 steering (+ left), +8F4 drift angle, radians, +B08 engine revs with a manual gearbox,
#     +B04 with an automatic; +B18 is 10000 for every car, the gauge's top, not a limit),
#     +1D8C last frame's event flags (the same bits as ID6), +1DA1 the surface sound area.
ID0X = " From the game's own code (v2.30 exe, 16 November 2026). Not yet checked in a recording."
ID0OK = (" From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: "
         "story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, "
         "automatic, USB capture on; claude/ID0V230-capture-20261116.md).")
ID0_ID6 = " The same bit as ID6's, whose meaning was checked in Alexis's ID6 recordings; not yet seen in Initial D Zero."
ID0_SEEN = " The same bit as ID6's; seen in Alexis's Initial D Zero recordings of 16 November 2026 where she said it happened."
ID0_SLOTS = [   # name, type, offsets after the cActor, note, formula on the player's value, checked, player row ticked
    ('state', 'Int32', '1C', 'Car state: 4 racing (from GO), 5 over the finish line, 6 race over (the other car finished and the '
     'race ended).', 'race_loaded ? {v} : 0', True, True),
    ('speed', 'Float', '38, 10, 0, 8', 'Speed, km/h: the speedo (all five of Alexis\'s readings matched to the km/h: 160, 167 and 203 '
     'in the Trueno, 113 and 105 in the RX-7).', 'race_loaded ? {v} / max_speed : 0', True, True),
    ('rpm', 'Float', '38, 10B0, B08', 'The rev counter. With a manual gearbox the engine revs (the Trueno\'s bounce 7,940 to 8,140 '
     'on the limiter, where Alexis read 7.7k to 7.9k); with an automatic this value is 0, so it is rpm_auto x 0.885 (the Silvia\'s '
     'counter read 0.879 to 0.889 of it at five readings, 16 November 2026).',
     'race_loaded ? ({v} > 0 ? {v} : rpm_auto * 0.885) / max_revs : 0', True, True),
    ('rpm_auto', 'Float', '38, 10B0, B04', 'Engine revs as the game keeps them with an automatic gearbox (about the tacho value: '
     'the Silvia\'s factor 0.99). The rev counter shows 0.885 of it (Alexis\'s Silvia readings: 5.8k at 6,598, 5.45k at 6,133, '
     '6.2k at 6,993, 6.075k at 6,872, 5.95k at 6,716).', 'race_loaded ? {v} : 0', True, False),
    ('rpm_tacho', 'Float', '38, 10, 0, C', 'Engine revs times a factor for each car (1.21 the Trueno, 1.14 the RX-7): not what the rev '
     'counter shows (the Trueno\'s reads 9,849 on the limiter, its counter under 8k).', 'race_loaded ? {v} : 0', True, False),
    ('gear', 'Int32', '38, 10, 0, 14', 'Gear, 1 up (at least 1): manual 1 to 5, automatic 1 to 4.', 'race_loaded ? {v} : 0', True, True),
    ('throttle', 'Float', '38, 10B0, 260', 'Throttle, 0 to 1, as the physics uses it (from the pedal).', 'race_loaded ? {v} : 0', True, True),
    ('brake', 'Float', '38, 10B0, 2A4', 'Brake, 0 to 1, as the physics uses it (from the pedal).', 'race_loaded ? {v} : 0', True, True),
    ('steer', 'Float', '38, 10B0, 2C8', 'Steering as the physics uses it, + right, - left: the game\'s own value is + left, so this '
     'is turned round. It follows the wheel (USB, r -0.95 and -0.97 before turning) at about a quarter to a third of its turn: the game '
     'eases the steering the faster the car goes.', 'race_loaded ? -{v} : 0', True, True),
    ('drift_angle', 'Float', '38, 10B0, 8F4', 'Drift angle, degrees: between where the car points and where it is going (the physics\' '
     'own, worked out as in ID6: body heading less the direction of travel, wrapped to +-180). + a right-hand drift, - left (Alexis: '
     'right at TT 0:16.10 and 0:28.46, left at 0:11.12 and 0:36.77). About 15 to 30 degrees in the Trueno\'s quick bends, up to '
     '68 in the RX-7\'s hairpin drifts. 0 below 10 km/h.', 'race_loaded && speed * max_speed > 10 ? -{v} * 57.29578 : 0', True, True),
    ('events', 'Int32', '38, 1D8C', "The car's event flags from the last frame: the game plays its collision, gutter, landing and "
     'joint sounds from these, with the same bits as ID6. The rows after decode them.', 'race_loaded ? {v} : 0', True, True),
    ('area', 'Byte', '38, 1DA1', 'The surface the game plays a looping sound for: 0 road, 1 leaves (surface 0x12 or 0x32), 2 striped '
     'surface (0x14 or 0x15: the ripple strips in ID0-1, and Irohazaka\'s painted strips, which the game doesn\'t shake for), 3 the '
     'sound named "glass area" (0x19 or 0x39: probably grass; not seen yet), 4 the road gutter (0x2X).', 'race_loaded ? {v} : 0', True, True),
]

# ---------------------------------------------------------------- Sega World Drivers Championship: the game's own data (18 November 2026)
# From Todoroki-Win64-Shipping.exe v2.30 (Unreal Engine 4.17, built 5 December 2019, MD5 94ed0ba0...): notes in
# claude/SWDC-exe-20261118.md. The game keeps a data model at [[[<main>+4B07438] + 278] + 10] (Q): Q+16D0 is your car number
# (counted from 1), Q+2550 points to the per-car records (0x578 bytes each), Q+2C18 is the race's time left in seconds.
# UCarLibrary's getters (GetKilosPerHour, GetRevsPerMinute, GetShiftPosition, GetSparkLValue, GetTotalRank, GetLap, ...) read
# these records; the blueprints set them each frame. A record is reached with plugin 0.19.0's indexed offset: [-E80]*578
# reads your car number beside the records' pointer (Q+2550 - E80 = Q+16D0) and steps that many records on (hence - 578
# in the field offsets: car 1 is the first record).
SWDC_EXE = ' From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026.'
SWDC_19 = " Checked in Alexis's recording of 19 November 2026 (SWDC-11)."

SWDC_Q = '4B07438'
def swdc_rec(field):
    """Offsets from <main>+4B07438 to a field of your car's record."""
    d = field - 0x578
    return '278, 10, 2550, [-E80]*578, ' + ('-%X' % -d if d < 0 else '%X' % d)

def swdc_rows(mem, calc):
    def rec(name, typ, field, notes, formula='', on=True):
        r = mem(name, typ, SWDC_Q, notes + SWDC_EXE, offsets=swdc_rec(field), formula=formula)
        r['Enabled'] = on
        return r
    def q(name, typ, off, notes, formula='', on=True):
        r = mem(name, typ, SWDC_Q, notes + SWDC_EXE, offsets='278, 10, %X' % off, formula=formula)
        r['Enabled'] = on
        return r
    def c(name, formula, notes, on=True):
        r = calc(name, formula, notes)
        r['Enabled'] = on
        return r
    G = 'in_race ? value : 0'
    return [
        q('player_no', 'Int32', 0x16D0, 'Your car number in the race (1 to 45), which picks your record among the cars\'. 0 in the menus '
          'and the attract mode; 35 in her race of 19 November 2026 (45 cars).' + SWDC_19),
        q('cars', 'Int32', 0x2558, 'How many car records there are (45: the array\'s size, whatever the field).', on=False),
        rec('grid_no', 'Int32', 0x8, 'Your record\'s car number (GetStartingGridNo): the same as player_no when the record read is yours, '
            'which is how the game itself tells your car (UCarLibrary::IsPlayer). Rubbish in the menus.', on=False),
        c('player_ok', 'version != 103 && player_no >= 1 && player_no <= cars && grid_no == player_no', '1 when your car\'s record can be '
          'read (your car number in range and the record carrying it): from car select to the results screen in her recording.', on=False),
        rec('car_state', 'Byte', 0x2E0, 'Your car\'s race state: 0 none, 1 from the course loading through the countdown (the screen '
            'held, revs frozen), 2 racing, from the rolling start (the car moving at about 100 km/h), 3 from your finish line, 4 to 6 retired '
            '(time out, interruption and so on). Rubbish in the attract mode (player_ok 0 there).', on=False),
        c('finished', 'valid(player_ok, 0) && car_state == 3', '1 from your finish line (race state 3) to the results.', on=False),
        calc('in_race', 'valid(player_ok, 0) && car_state == 2', 'In a race: your car\'s race state 2, from the rolling start (the car '
             'moving at about 100 km/h) to your finish line (or retiring, time out). Every game value here reads 0 outside it, and so do the '
             'SimHub effects. Checked in her recording of 19 November 2026: on as the car starts moving, off on the line.' + SWDC_EXE),
        rec('kmh', 'Int32', 0x460, 'Speed as the speedo shows it, whole km/h (GetKilosPerHour): within 3 km/h of the table\'s speed2 '
            'through her speedo fit, up to 224 km/h in her race.' + SWDC_19, formula=G, on=False),
        rec('revs_record', 'Int32', 0x470, 'The revs in your car\'s record (GetRevsPerMinute): not the engine revs for your car (0, 8000 and '
            'odd values in her race, while revs ran 6,900 to 12,000). Kept to look at.', formula=G, on=False),
        rec('shift', 'Int32', 0x490, 'Gear in your car\'s record (GetShiftPosition): the same as the table\'s gears2 throughout her race.' + SWDC_19,
            formula=G, on=False),
        rec('brake', 'Float', 0x480, 'Brake in your car\'s record (GetBrake), 0 to 1: follows the brake pedal (USB) mostly.', formula=G),
        rec('spark_l', 'Byte', 0x498, 'Sparks on the left (GetSparkLValue): 1 while the car throws sparks on its left side. In her race they came '
            'as she downshifted under braking (TT 0:54.05, 1:51.83), not at hits.' + SWDC_19, formula=G, on=False),
        rec('spark_r', 'Byte', 0x499, 'Sparks on the right (GetSparkRValue), as spark_l.', formula=G, on=False),
        rec('afterfire', 'Byte', 0x49A, 'Flames from the exhaust (GetAfterFireValue): 127 as they start, then fading by 16 a frame, mostly '
            'on lifts and shifts.', formula=G, on=False),
        rec('overall', 'Int32', 0x410, 'Your place among every car (GetTotalRank): 35 to 16 in her GT300 race of 19 November 2026 (45 cars, '
            'GT500 and GT300 together). The screen shows your class place (`position`).', formula=G, on=False),
        rec('position', 'Int32', 0x420, 'Your place in your class, GT500 or GT300, as the screen and the results show it (GetClassRank): 20 to 1 in '
            'her GT300 race, 1st at the line as her results showed.' + SWDC_19, formula=G),
        rec('lap', 'Int32', 0x1E8, 'Laps: 0 from the rolling start to the start line, then 1, 2, 3 and 4 at the finish (GetLap).', formula=G, on=False),
        rec('sector', 'Int32', 0x1D8, 'The course sector your car is in, 1 to 3 (GetSector).', formula=G, on=False),
        rec('course_point', 'Int32', 0x280, 'Your car\'s point along the course\'s centre line (GetCourseCenterPoint).', formula=G, on=False),
        rec('lane', 'Float', 0x2A0, 'Your car\'s distance to the side of the course\'s centre line (GetLaneSideOffset).', formula=G, on=False),
        rec('race_secs', 'Float', 0x4B8, 'Seconds since the rolling start (GetElapseSeconds): the race clock (TT), 3:16.29 at her finish line.',
            formula=G),
        rec('pos_x', 'Float', 0x2F8, 'Your car\'s position (GetLocation), X, centimetres.', formula=G, on=False),
        rec('pos_y', 'Float', 0x2FC, 'Your car\'s position, Y.', formula=G, on=False),
        rec('pos_z', 'Float', 0x300, 'Your car\'s position, Z (height).', formula=G, on=False),
        rec('yaw', 'Float', 0x314, 'Your car\'s heading in degrees (GetRotation\'s yaw; + turns to the right).', formula=G, on=False),
        rec('pitch', 'Float', 0x310, 'Your car\'s pitch in degrees.', formula=G, on=False),
        rec('roll', 'Float', 0x318, 'Your car\'s roll in degrees.', formula=G, on=False),
        c('checkpoint', 'maxw(in_race && minw(in_race, 0.5) && (delta(sector) != 0 || delta(lap) > 0), 1)', '1 for a second as you cross a '
          'sector line or a lap line (three a lap; not at the rolling start): the game\'s checkpoints. It has no time extensions (the lap '
          'time limit it keeps isn\'t shown). Checked in her races of 19 November 2026.' + SWDC_19),
        c('wall_side', 'in_race ? (spark_r ? 1 : 0) - (spark_l ? 1 : 0) : 0', 'Which side is throwing sparks, -1 left, 1 right (0 none or both).', on=False),
        c('backfire', 'in_race && afterfire > 0 ? afterfire / 127 : 0', 'The exhaust\'s flames, 1 as they start and fading, in a race.', on=False),
        c('speedo_fit', 'in_race && speed2 > 0 ? kmh / (speed2 * max_speed) : 0', 'km/h on the speedo per unit of '
          'the table\'s speed2: a check on Alexis\'s speedo fit (2.45 to 2.70 in her race).', on=False),
        c('travel', 'minw(in_race, 0.3) ? atan2(slope(pos_y, 0.1), slope(pos_x, 0.1)) * 180 / pi : 0', 'The direction your car is moving, '
          'degrees, from its position.', on=False),
        c('pos_kmh', 'minw(in_race, 0.3) ? hypot(slope(pos_x, 0.1), slope(pos_y, 0.1)) * 0.036 : 0', 'Speed from the position, km/h: 3% under '
          'the speedo in her race.', on=False),
        c('vel_lat', 'minw(in_race, 0.3) ? (cos(yaw * pi / 180) * slope(pos_y, 0.1) - sin(yaw * pi / 180) * slope(pos_x, 0.1)) / 100 : 0',
          'How fast the car moves sideways, m/s, + to the right (from its position and heading).', on=False),
        c('jolt', 'minw(in_race, 0.5) ? slope(vel_lat, 0.1) / g : 0', 'Sideways jolt in G, + pushed to the right: at a car contact or a '
          'wall the game shoves the car sideways, 4.3 to 10 G over a game frame or two. In her race of 19 November 2026 every car contact '
          'and wall hit she named, apart from a head-on hit (TT 0:17.44) and a light one against the left wall (0:25.84, 3.4 G), went over '
          '4.3 G, always pushed away from the side hit; slips and corrections stay under 3.8 G, and the slides\' own swings (to 5.8 G) '
          'are left out by the drift angle.', on=False),
        c('car_contact', 'maxw(in_race && abs(jolt) > 4 && maxw(abs(drift_angle), 0.5) < 25, 0.3)', '1 for 0.3 s at a car contact or wall '
          'hit: a sideways jolt over 4 G while not sliding (the drift itself swings the heading). Twelve in her race of 19 November 2026, '
          'all real, the side right every time.' + SWDC_19, on=False),
        c('contact_side', 'car_contact ? valid(hold(-sign(jolt), abs(jolt) > 4 && prev(maxw(abs(jolt), 0.25)) <= 4), 0) : 0', 'Side of the car '
          'hit at a contact, -1 left, 1 right: the other way from the first shove over 4 G (a rebound the other way, sometimes as big, '
          'follows it). Checked against her answers: all twelve sides in her GT300 race, and eight of ten she could tell in her GT500 race '
          '(a car pushing her from the inside of a left-hander at TT 0:42.59 read the other side; at 0:12.96 the shove of a car hitting her '
          'front centre was taken, not the one on her front right 0.15 s later).' + SWDC_19, on=False),
        c('contact_strength', 'car_contact ? clamp(0.4 + (maxw(abs(jolt), 0.3) - 4) / 10, 0.4, 1) : 0', 'How hard a contact was, 0.4 to 1 by the '
          'jolt (4 G 0.4, 10 G 1).', on=False),
        c('verge', 'maxw(in_race && vibration > 0 && vibration < 0.2 && vibration_period_ms < 20, 0.3)', 'On the grass verge: the game\'s '
          'vibration command at under 0.2 strength with a short period (7 to 9 ms), which it sends in pulses while wheels are on the verge '
          '(her race of 19 November 2026: TT 0:25.29 to 0:28.26, 1:14.13 to 1:14.67, 1:15.95 on, 1:25.30). Painted kerbs send nothing.', on=False),
        c('kerb', 'maxw(in_race && vibration >= 0.37 && vibration_period_ms >= 25, 0.3)', 'On a solid kerb: the game\'s vibration command at about '
          '0.4 with a long period (34 to 43 ms): TT 1:16.93 to 1:17.45 in her race, as her right wheels crossed the kerb.', on=False),
        c('drift_angle', 'minw(in_race, 0.3) && pos_kmh > 30 ? wrap(yaw - travel, 360) : 0', 'Drift angle in degrees: your heading against '
          'the direction you\'re moving, + pointing right of your path (a right-hand drift), - left; 0 under 30 km/h. + in right-hand turns '
          'in her race (it follows the turn and the steering); her slides reached 40 to 55 degrees.', on=False),
        c('drift', 'maxw(car_contact, 0.5) ? 0 : clamp(0.072 * pow(max(abs(drift_angle) - 10, 0), 0.6) * sqrt(min(kmh, 150) / 100), 0, 1)',
          'Drifting, 0 to 1: the angle past 10 degrees, eased (power 0.6), times the square root of the speed over 100 km/h (counted up to '
          '150), fitted to Alexis\'s seven slide values of 19 November 2026 (her values in brackets): GT300 race TT 0:55.8 43 degrees at '
          '121 km/h 0.64 (0.65), 1:04 31 at 141 0.53 (0.6), 1:06 35 at 134 0.57 (0.5 to 0.55), 1:36 50 at 95 0.64 (0.6), 1:54 40 at 118 '
          '0.60 (0.55), 2:28 55 at 96 0.69 (0.75); GT500 race 0:24.87 45 at 133 0.70 (0.7). Her small slides in the GT500 race (20 to 23 '
          'degrees at 140 to 190 km/h) read about 0.3. 0 for 0.5 s after a contact, whose shove swings the heading.', on=False),
    ]

def id0_rows():
    """Initial D Zero v2.30's rows from the game's own code (see above), checked in Alexis's recordings of 16 November 2026."""
    G = '18B4E50'
    def mem(name, typ, offs, notes, formula='', on=True, ok=True):
        return dict(Name=name, Enabled=on, Source='Memory', Type=typ, Module='<main>', BaseOffset=G, Offsets=offs,
                    Formula=formula, Notes=notes + (ID0OK if ok else ID0X))
    def calc(name, formula, notes, on=True, src=True, ok=True):
        return dict(Name=name, Enabled=on, Source='Computed', Type='Float', Module='', BaseOffset='0', Offsets='',
                    Formula=formula, Notes=notes + ((ID0OK if ok else ID0X) if src else ''))
    rows = [
        mem('race_state', 'Int32', '290, 8', 'Race state: 2 set-up, 3 the intro and countdown, 4 racing (from GO), 5 a car has reached '
            'the goal (yours, or the rival\'s outside the story and tutorial), 6 race over. No value outside a race.'),
        mem('game_mode', 'Int32', '8', 'Game mode: 1 test, 2 time attack, 3 story, 4 in-store VS, 5 online battle, 7, 9 and 11 the '
            'attract demo\'s replays (9 is also the live race), 15 2-on-2 VS, 16 tutorial (the story\'s intro race for a course), '
            '17 beginner online. Seen: 16 and 2.', formula='band(value, 255)'),
        mem('my_slot', 'Int32', '290, 4C', "The race's slot for your car, 0 or 1 (the other is the rival).", on=False),
        mem('cars', 'Int32', '290, 48', 'Cars in the race: 2 in both recordings (time attack keeps a second, unseen car).', on=False),
        mem('race_ms', 'Int32', '290, 24', 'The race clock, milliseconds from GO: about -200 s through the intro, -3 s from the '
            'countdown, then the TT on screen; it stops while the game is paused (the tutorial\'s how-to demos).', on=False),
        calc('replay', 'valid(game_mode, 0) >= 7 && valid(game_mode, 0) <= 12', '1 in the attract demo and replays (game modes 7 to 12, '
             'which the game itself treats as not played).', on=False, ok=False),
        calc('race_loaded', 'valid(race_state, 0) >= 3 && valid(race_state, 0) <= 6 && (valid(game_mode, 0) < 7 || valid(game_mode, 0) > 12)',
             '1 from the intro to after the goal in a race you play: the car rows read 0 outside this.', on=False),
        calc('live', 'maxw(delta(race_ms) != 0, 0.2)', '1 while the race clock moves: 0 while the game is paused (the tutorial\'s '
             'how-to demos stopped it twice in ID0-1, at TT 0:02.05 and 0:52.13).', on=False),
        calc('rival_race', 'valid(game_mode, 0) != 2 && valid(cars, 1) == 2', '1 in a race against a rival: not time attack, whose second '
             'car is never seen (Alexis, 16 November 2026) and whose gap means nothing.', on=False),
    ]
    for name, typ, offs, note, f, ok, tick in ID0_SLOTS:
        for k in (0, 1):
            rows.append(mem(f'{name}_{k}', typ, f'290, {0x38 + 8 * k:X}, {offs}', f'Slot {k} car: {note}', on=False, ok=ok))
        rows.append(calc(name, f.format(v=f'(valid(my_slot, 0) == 1 ? {name}_1 : {name}_0)'), note + ' Your car, whichever slot it is in.',
                         on=tick, ok=ok))
    rows += [
        calc('in_race', 'valid(race_state, 0) == 4 && state == 4 && !replay && live', '1 while racing: from GO to your finish line, '
             'not in the attract demo or a replay, and not while paused (the race clock stands still: the tutorial\'s how-to demos).'),
        calc('race_clock', 'race_loaded && race_ms > -10000 ? race_ms / 1000 : 0', 'The race time (TT), seconds from GO; negative in '
             'the countdown, 0 outside a race and through the intro.'),
        mem('time_left', 'Int32', '290, 178', 'Time left (RT, on screen in both the tutorial and time attack), seconds (the game keeps '
            'milliseconds: the cheat table\'s "Stage_Tmr"). 120 at GO in both recordings; each checkpoint\'s extension is added over '
            'a second or so (see time_extension); online battles can run 2 s past 0.', formula='race_loaded ? value / 1000 : 0'),
        mem('time_extension', 'Int32', '290, 17C', 'Time still being added from the last checkpoint, milliseconds (the game adds it '
            '50 times faster than the clock runs).', on=False),
        calc('checkpoint', 'in_race && maxw(delta(time_extension) > 0, 2) > 0', '1 for 2 s after a checkpoint that extends the time '
             '(Extended Time!): all six in the two recordings, Alexis\'s marks 0.1 to 0.2 s after.'),
        mem('gap', 'Float', '290, 18', 'Distance to the rival along the course, + you ahead, - behind (the game\'s units, probably '
            'metres: the game\'s own difference between the two cars\' progress). Only against a rival (not time attack). In ID0-1 '
            'it changed sign at each of Alexis\'s passes (TT 0:38.86, 0:50.41, 0:59.95) and read 51 at the line.',
            formula='race_loaded && rival_race ? value : 0'),
        calc('leader', 'in_race && rival_race && gap > 0', '1 while ahead of the rival.'),
        # Lamps from race values (Alexis, 16 November 2026: OutputBlaster has no v2.30 entry). Not tied to Car_in_race.
        calc('lampleader', 'race_loaded && (rival_race ? gap > 0 : valid(race_state, 0) >= 4)', 'Leader lamp, 0 or 1: lit while '
             'you lead the rival (first place), and from GO in time attack, where you run alone. It keeps the last standing past '
             'the line until the race is over. Made from the race values, as Alexis asked (OutputBlaster has no v2.30 entry).', ok=False),
        calc('lampcheckpoint', 'maxw(delta(time_extension) > 0, 2) > 0', 'Checkpoint lamp, 0 or 1: lit for 2 s as a checkpoint\'s '
             'time extension starts (Extended Time!), as `checkpoint`. Made from the race values, as Alexis asked.', ok=False),
    ]
    seen = {'wall_left', 'wall_right', 'car_contact', 'leaves', 'gutter'}
    for name, bits, note, _ in ID6_EVENTS:
        rows.append(calc(name, f'in_race && band(events, {bits}) != 0', f'1 while {note} (event bits {bits:#x}).' +
                         (ID0_SEEN if name in seen else ID0_ID6), src=False))
    rows += [
        calc('landing', 'in_race && maxw(band(events, 256) != 0 && prev(band(events, 256)) == 0, 0.25) > 0',
             '1 for 0.25 s as the car lands (event bit 0x100 coming on; the game leaves it on until the car next leaves the ground): '
             'both jumps in ID0-1 and both kerb drops in ID0-2.'),
        calc('rumble_strip', 'in_race && (band(events, 512) != 0 || maxw(ffb_cmd == 133 && ffb_v1 > 0 && byte(ffb_raw, 2) == 5, 0.3) > 0)',
             'On a ripple strip: the game\'s vibration at level 5 (its period follows the speed), held 0.3 s, as for ID6. All five '
             'ripple strips in ID0-1 came through; Irohazaka\'s painted strips (ID0-2) don\'t shake, so they don\'t count. The game\'s '
             'levels: 2 contact with the other car, 4 scraping a wall or guard rail, 5 a ripple strip.'),
        calc('grass', 'in_race && area == 3', 'On the surface whose sound the game calls "glass area" (probably grass; not seen yet).', ok=False),
    ]
    W = 'wall_left || wall_right || wall_front'
    rows += [
        calc('hit', f'in_race && maxw((({W}) && prev(maxw({W}, 0.15)) == 0) || (car_contact && prev(maxw(car_contact, 0.15)) == 0), 0.3) > 0',
             '1 for 0.3 s from the start of a contact with a wall, guard rail or the other car (where the game plays its collision sound). '
             'Touches less than 0.15 s apart count as one, as in ID6. Alexis confirmed the bumps with the other car in ID0-1 and the '
             'guard rail and wall touches she checked in ID0-2 (leaves alone never count).'),
        calc('hit_side', 'valid(hold(wall_right - wall_left, wall_right != wall_left), 0)', 'Side of the last wall contact, +1 right, -1 left.'),
        calc('wall_contact', 'minw(wall_left || wall_right, 0.3) ? (wall_right - wall_left) : 0', 'Scraping along a wall or guard rail '
             'for 0.3 s or more: +1 right, -1 left.'),
        calc('rough_ground', 'gutter || drain || leaves || grass', '1 with a wheel in the gutter, over a drain cover, on leaves or grass.'),
        calc('shift', 'in_race && maxw(delta(gear) != 0, 0.2) > 0', '1 for 0.2 s after a gear change.', src=False),
        calc('accel_g', 'ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g', 'Longitudinal G from speed (km/h). + speeding up, - slowing down.',
             src=False),
    ]
    return rows

ID6_V12_STAMP = 1313406292   # the exe's build time stamp (header +0x120): 15 August 2011, v1.2
ID6 = " From the game's code (v1.2 exe, read 8 November 2026)."
ID6_SEEN = " Checked in Alexis's recordings of 9 November 2026."
ID6_UNSEEN = " Not seen yet (none in the 9 November 2026 recordings)."
ID6_TAG = '(ID6 v1.2 code)'
ID6_EVENTS = [   # name, bits, note, seen in the 9 November recording
    ('wall_left', 0x8000 | 0x1000, 'touching a wall (0x8000) or guard rail (0x1000) on the left', True),
    ('wall_right', 0x20000 | 0x4000, 'touching a wall (0x20000) or guard rail (0x4000) on the right', True),
    ('wall_front', 0x10000 | 0x2000, 'touching a wall or guard rail ahead', False),
    ('car_contact', 0x80000, 'touching the other car (while the cars grind it drops out for a frame or so every 0.2 s)', True),
    ('gutter', 0x1 | 0x2, 'a wheel is in the roadside gutter (0x1 left, 0x2 right). Wall hits mostly come with it, since '
     'the gutter runs along the wall; on its own it is the wheels running in the gutter', True),
    ('road_joint', 0x800, 'crossing a road joint', False),
    ('gutter_drop', 0x40 | 0x80, 'the gutter technique sound ("mizootoshi"), left or right', False),
    ('drain', 0x4 | 0x8, 'running over a drain cover', False),
    ('oil', 0x10 | 0x20, 'on oil', False),
    ('leaves', 0x400, 'a wheel in the leaves at the side of the road (Irohazaka)', True),
]

def add_id6(pack):
    import json, os
    import packlayout
    path = packlayout.path(pack, 'ID6')
    if not os.path.isfile(path): return
    with open(path, encoding='utf-8') as fh: p = json.load(fh)
    lamps = ['lampstart', 'lampview1', 'lampselectup', 'lampselectdown', 'lampselectleft', 'lampselectright']
    keep = [v for v in p['Variables'] if ID6_TAG not in v['Notes'] and v['Name'] not in lamps]
    def mem(name, typ, base, offs, notes, formula='', on=True, seen=True):
        return dict(Name=name, Enabled=on, Source='Memory', Type=typ, Module='<main>', BaseOffset=base, Offsets=offs,
                    Formula=formula, Notes=notes + ID6 + (ID6_SEEN if seen else '') + ' ' + ID6_TAG)
    def calc(name, formula, notes, on=True):
        return dict(Name=name, Enabled=on, Source='Computed', Type='Float', Module='', BaseOffset='0', Offsets='',
                    Formula=formula, Notes=notes + ' ' + ID6_TAG)
    S = 'C6E210'
    rows = [
        mem('build_stamp', 'Int32', '120', '', "The exe's build time stamp: 1313406292 for v1.2 (15 August 2011). The memory rows are for "
            "v1.2; on another version they read 0 (v1.0's addresses differ: only its lamps are known).", on=False),
        calc('v12', f'build_stamp == {ID6_V12_STAMP}', '1 on v1.2, the version these memory rows are for.', on=False),
        mem('race_state', 'Int32', S, '20C, 4', 'Race state: 2 set-up, 3 the rolling start and countdown (7 s in the story prologue), '
            '4 racing (from the moment the race clock starts), 5 a car has reached the goal, 6 after. Not readable outside a race.',
            formula='v12 ? value : 0'),
        calc('in_race', 'valid(race_state, 0) == 4', '1 while racing: race state 4, from the start to the finish line (the event flags '
             'only count then). Checked in a recording, 9 November 2026: on at the start, off on the line.'),
        dict(calc('race_loaded', 'valid(race_state, 0) >= 3 && valid(race_state, 0) <= 6', '1 from the start to after the goal: the car rows '
                  'read 0 outside this.'), Enabled=False),
        calc('countdown_live', 'valid(race_state, 0) == 3 && rpm * max_revs > 850', '1 in the countdown once the engine runs: in the '
             'rolling start the car is driven at 170 to 185 km/h with live revs for the last 6 s before the race clock starts '
             '(recording, 9 November 2026). Car_in_race includes it, so the engine effects start with the engine.'),
        mem('my_slot', 'Int32', S, '20C, 34', "The race's slot for your car, 0 or 1 (the other is the rival). 0 in the story prologue.", on=False),
    ]
    # each value for both slots, then the player's
    per = [  # name, type, offsets after the cMoriCar, note, formula on the player's value
        ('speed', 'Float', '8, 0, 8', 'Speed, km/h: the speedo, to within 1 km/h at 30 of Alexis\'s readings (the game keeps m/s; the status '
         'block has km/h).', 'race_loaded ? {v} / max_speed : 0'),
        ('rpm', 'Float', 'F8C, 9A8', 'Engine revs: the GT-R\'s on-screen revs within about 150 at 30 readings, and the Trueno\'s rev '
         'counter reads 8k at the limiter. Idles at 800; the R32 GT-R and AE86 Trueno both limit at 8140.', 'race_loaded ? {v} / max_revs : 0'),
        ('rpm_tacho', 'Float', '8, 0, C', 'Engine revs times a factor for each car (1.08 R32 GT-R, 1.23 AE86 Trueno, 1.035 Civic). Not what '
         'the screen shows in the GT-R or the Trueno (the Trueno\'s would read 10,000 on the limiter).', 'race_loaded ? {v} : 0'),
        ('gear', 'Int32', '8, 0, 10', 'Gear, 1 up (the game keeps at least 1 here): every change in the recording.', 'race_loaded ? {v} : 0'),
        ('throttle', 'Float', 'F8C, 208', 'Throttle, 0 to 1 (the game counts 5 s at 0 as the player gone idle).', 'race_loaded ? {v} : 0'),
        ('brake', 'Float', 'F8C, 230', 'Brake, 0 to 1: read 1 with the throttle off and the car slowing hard.', 'race_loaded ? {v} : 0'),
        ('drift_angle', 'Float', 'F8C, 7C4', 'Drift angle, degrees: between where the car points and where it is going (the physics\' own: '
         'body yaw P+124 less the direction of travel P+148, wrapped to +-180, which the game turns into its sideways grip). + the car '
         'pointing right of its path (a right-hand drift), - left; 0 below 10 km/h. Under about 7 degrees in ordinary cornering, 15 to 20 '
         'in a gentle drift, 25 to 40 moderate, about 50 extreme. From the exe, and checked in two drifting recordings (9 November 2026).',
         'race_loaded && speed * max_speed > 10 ? -{v} * 57.29578 : 0'),
        ('events', 'Int32', '1AB4', "The car's event flags from the last frame: the game plays its collision, gutter, landing and joint sounds "
         'from these. The rows after decode them.', 'race_loaded ? {v} : 0'),
    ]
    for name, typ, offs, note, f in per:
        for k in (0, 1):
            rows.append(mem(f'{name}_{k}', typ, S, f'20C, {0x28 + 4 * k:X}, 28, {offs}', f'Slot {k} car: {note}', formula='v12 ? value : 0', on=False))
        rows.append(calc(name, f.format(v=f'(valid(my_slot, 0) == 1 ? {name}_1 : {name}_0)'), note + ' Your car, whichever slot it is in.'))
    for name, bits, note, seen in ID6_EVENTS:
        rows.append(calc(name, f'in_race && band(events, {bits}) != 0', f'1 while {note} (event bits {bits:#x}).' + (ID6_SEEN if seen else ID6_UNSEEN)))
    rows += [
        calc('landing', 'in_race && maxw(band(events, 256) != 0 && prev(band(events, 256)) == 0, 0.25) > 0',
             '1 for 0.25 s as the car lands (event bit 0x100 coming on). The game leaves the bit on until the car next leaves the '
             'ground, so only its start counts. Both landings in Alexis\'s Irohazaka recording of 9 November 2026 came through.'),
        calc('rumble_strip', 'in_race && (band(events, 512) != 0 || maxw(abs(vibration * 127 - 10) < 0.5, 0.3) > 0)',
             'On a rumble strip: the game\'s vibration command at level 10 (its period follows the speed), held 0.3 s. Every ripple '
             'strip Alexis marked on Irohazaka (9 November 2026) came through this way; the event bit 0x200 ("gensokutai") never came on.'),
    ]
    W = 'wall_left || wall_right || wall_front'
    rows += [
        calc('hit', f'in_race && maxw((({W}) && prev(maxw({W}, 0.15)) == 0) || (car_contact && prev(maxw(car_contact, 0.15)) == 0), 0.3) > 0',
             '1 for 0.3 s from the start of a contact with a wall, guard rail or the other car (where the game plays its collision sound). '
             'Touches less than 0.15 s apart count as one, so a grind along the other car is one hit, not one every 0.2 s. '
             'Checked in a recording, 9 November 2026.'),
        calc('hit_side', 'valid(hold(wall_right - wall_left, wall_right != wall_left), 0)', 'Side of the last wall contact, +1 right, -1 left.'),
        calc('wall_contact', 'minw(wall_left || wall_right, 0.3) ? (wall_right - wall_left) : 0', 'Scraping along a wall or guard rail '
             'for 0.3 s or more: +1 right, -1 left.'),
        calc('rough_ground', 'gutter || drain || leaves', '1 with a wheel in the gutter, over a drain cover or on leaves.'),
        calc('shift', 'in_race && maxw(delta(gear) != 0, 0.2) > 0', '1 for 0.2 s after a gear change.'),
        calc('accel_g', 'ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g', 'Longitudinal G from speed (km/h). + speeding up, - slowing down.'),
    ]
    # lamps, from memory for both versions (OutputBlaster's own addresses and bits)
    rows += [
        mem('lamps_a12', 'Byte', 'CF4988', '', 'Lamp byte 1, v1.2 (as OutputBlaster reads it).', on=False),
        mem('lamps_b12', 'Byte', 'CF4989', '', 'Lamp byte 2, v1.2.', on=False),
        mem('lamps_a10', 'Byte', 'CF2E8D', '', 'Lamp byte 1, v1.0 (as OutputBlaster reads it).', on=False, seen=False),
        mem('lamps_b10', 'Byte', 'CF2E8E', '', 'Lamp byte 2, v1.0.', on=False, seen=False),
    ]
    for name, byte, bit in [('lampstart', 'a', 128), ('lampview1', 'a', 64), ('lampselectup', 'a', 2), ('lampselectdown', 'a', 1),
                            ('lampselectleft', 'b', 128), ('lampselectright', 'b', 64)]:
        rows.append(calc(name, f'band(v12 ? lamps_{byte}12 : lamps_{byte}10, {bit}) != 0',
                         f'Lamp, 0 or 1, from game memory at the address OutputBlaster uses for this version (no OutputBlaster needed).'))
    p['Variables'] = keep + rows
    p['ProcessName'] = 'InitialD6_GLW_RE_SBUU_dump.exe'
    # Alexis's recordings, 9 November 2026: the R32 GT-R and the AE86 Trueno both limit at 8140 engine revs (the Trueno's
    # screen reads 8k); Max speed 220 (Alexis: the Trueno reached 215 km/h, untuned cars a little over later)
    p['MaxSpeed'] = 220.0
    p['MaxRevs'] = 8140.0
    with open(path, 'w', encoding='utf-8', newline='\n') as fh: fh.write(json.dumps(p, indent=2, ensure_ascii=False))

def add_hand(pack):
    """Rows for hand-maintained profiles (not made by memgames): replaced on each run, so running twice changes nothing."""
    import json, os
    import packlayout
    add_id6(pack)
    add_wmmt3(pack)
    add_sr3(pack)

# Sega Rally 3 from its exe (Rally.exe, 12 November 2026; claude/SR3-exe-20261112.md). The game keeps its six cars'
# records in one static array (0x9DBAC8, 0x1F18 bytes each); car 0 is the cabinet's own player (the game reads car 0's
# player state directly at 0x5CA260, and OutputBlaster's revs are car 0 +3BC). In car 0's record:
#   +1AF8 the player state (CSR_PlayerState: 1 intro, 2 countdown, 3 racing, 4 race finished wait, 5 post race),
#   +1B48 the race progress block: +0 checkpoints passed, +4 laps done (the HUD shows +1), +C position (1 = first),
#   +4 its car object, whose +1CBC is the wrong-way flag the HUD shows.
# Time left is a 64-bit count of milliseconds at 0x9DB4C8 (the HUD's GAME OVER comes when it reaches 0; each
# checkpoint adds to it; it counts down in game mode 6, the arcade race). Laps in the race 0x728A28, game mode 0x728598.
SR3X = " From the game's own code (Rally.exe, 12 November 2026). Not yet checked in a recording."
SR3OK = (" From the game's own code (Rally.exe, 12 November 2026). Checked in Alexis's recording of 16 November 2026 (10:24, "
         "game mode 5, three laps; claude/SR3-capture-20261116.md).")
SR3_STATES = ('0 attract mode and menus, 1 intro, 2 countdown, 3 racing, 4 finished (waiting for the others), 5 post race '
              '(16 November 2026: 0, then 1 for 4 s, 3 from GO, 5 from the finish line; 2 and 4 didn\'t show)')

def sr3_rows():
    def mem(name, typ, base, notes, offs='', formula='', on=True, ok=False):
        return dict(Name=name, Enabled=on, Source='Memory', Type=typ, Module='<main>', BaseOffset=base, Offsets=offs,
                    Formula=formula, Notes=notes + (SR3OK if ok else SR3X))
    def calc(name, formula, notes, on=True, ok=False, src=True):
        return dict(Name=name, Enabled=on, Source='Computed', Type='Float', Module='', BaseOffset='0', Offsets='',
                    Formula=formula, Notes=notes + ((SR3OK if ok else SR3X) if src else ''))
    return [
        mem('player_state', 'Int32', '5DD5C0', f"The player's state (car 0's CSR_PlayerState): {SR3_STATES}.", ok=True),
        mem('time_left', 'Int64', '5DB4C8', "Time given, seconds (the game keeps milliseconds): set at GO (70 s on Alexis's course) and "
            "added to at each checkpoint and lap line (+25 s, +30 s). In game mode 6 the game counts it down to GAME OVER; in Quick "
            "Race (game mode 5) it only goes up, and the screen shows it less the race time (see rt).", formula='value / 1000', ok=True),
        mem('checkpoints', 'Int32', '5DD610', "Lines crossed: -1 on the grid, 0 once over the start line (the grid is behind it), "
            "then one more at each lap line and the finish (3 at the end of three laps).", ok=True),
        mem('lap', 'Int32', '5DD614', "Lap number: 1 once over the start line (2.9 s after GO), then 2 and 3 at the lap lines; 0 on the "
            "grid (the game counts laps done; the HUD shows one more).", formula='value + 1', ok=True),
        mem('laps_total', 'Int32', '328A28', "Laps in this race.", ok=True),
        mem('position', 'Int32', '5DD61C', "Position, 1 = first. The game's own value flicks between two places for a few "
            "hundredths of a second when cars run side by side, so this holds a new place only once it has stood for 0.1 s.",
            formula='valid(hold(value, maxw(value, 0.1) == minw(value, 0.1)), value)', ok=True),
        mem('wrong_way', 'Int32', '5DBACC', "1 while the WRONG WAY sign shows (car 0's car object +1CBC): on while Alexis turned "
            "round, and while she reversed with the car facing forward (her answer, 16 November 2026). The game leaves it set in "
            "the menus, so it only counts while racing.", offs='1CBC', formula='racing && value != 0', ok=True),
        mem('game_mode', 'Int32', '328598', "Raw: the game mode number: 5 in Alexis's recording of 16 November 2026 (time_left only "
            "counts down in mode 6; 3, 7 and 8 are other modes, not yet named).", on=False),
        calc('racing', 'valid(player_state, 3) == 3', "1 from GO to the finish line: the player state is racing (3). If the "
             "state can't be read at all it counts as racing, so a failed read leaves the effects as they were before this row "
             "(it never failed in Alexis's recording).", ok=True),
        calc('finished', 'player_state >= 4 && player_state <= 5', "1 from the finish line (the player state's race finished, "
             "then post race).", ok=True),
        calc('checkpoint', 'maxw(racing && ((delta(checkpoints) > 0 && checkpoints > 0) || (delta(time_left) > 1 && prev(time_left) > 0)), 2)',
             "1 for 2 s after a checkpoint or lap line: the line count goes up or the time jumps up (time extended); not at GO "
             "(the time is set then) or over the start line from the grid. Alexis's three checkpoint marks came 0.4 to 0.5 s after it.",
             ok=True),
        calc('final_lap', 'racing && laps_total > 1 && lap == laps_total', "1 on the final lap.", ok=True),
        calc('race_time', 'racing ? t - valid(hold(t, racing && !prev(racing)), t) : 0', "The race time (TT), seconds from GO; 0 "
             "outside a race. Alexis's finish at TT 3:10.76 matched.", ok=True),
        calc('rt', 'racing ? max(0, valid(game_mode, 5) == 6 ? time_left : time_left - race_time) : 0', "The time left as the screen "
             "shows it (RT), seconds: the time given less the race time in Quick Race (game mode 5); in game mode 6 the game counts "
             "time_left down itself (from its code, not yet seen). The screen shows whole seconds, cut off, not rounded: Alexis read 33 "
             "at TT 0:36.43 (70 less TT: 33.57) and 56 at TT 0:38.73 (95 less TT: 56.27). The game adds an extension at once (TT 0:36.12 "
             "here) while the screen keeps the old time until its TIME EXTENSION message has flashed, so rt goes up about 2 s before "
             "the screen does. 0 outside a race.", ok=True),
        calc('leader', 'racing && position == 1', "1 while in the lead."),
        # Hand-maintained row (2 November 2026), tuned 16 November 2026 from Alexis's answers on the 12 November recordings.
        calc('hit', 'maxw(-delta(speed * max_speed) > 3 + 0.05 * max(0, -prev(slope(speed * max_speed, 0.2))) && '
             'speed * max_speed > 10 && !maxw(airborne, 0.7), 0.3)',
             "1 for 0.3 s when the speed drops by more than 3 mph in one game frame (a thirtieth of a second: over 4 G) from a "
             "steady speed. Walls are a one-frame drop; when the car is already slowing hard (a big slide: 204 to 44 km/h in "
             "0.8 s, which Alexis says was no hit) the drop it takes rises with the slowing (by 0.05 mph a frame for each mph a "
             "second), so a slide or the automatic's downshifts don't count. Not counted within 0.7 s of airborne, so a landing "
             "(and the speed jitter just after it) is Car_landed only. Every wall in Alexis's recording of 2 November 2026 and "
             "every wall she named in her 12 November quick race.", src=False),
    ]

def add_sr3(pack):
    """Sega Rally 3 rows read from the game's own variables, replaced on each run (so running twice changes nothing).
    A row already in the profile is replaced where it stands (the hand-maintained hit row keeps its place)."""
    import json, os
    import packlayout
    path = packlayout.path(pack, 'SR3')
    if not os.path.isfile(path): return
    with open(path, encoding='utf-8') as fh: p = json.load(fh)
    rows = {r['Name']: r for r in sr3_rows()}
    have = {v['Name'] for v in p['Variables']}
    p['Variables'] = [rows.get(v['Name'], v) for v in p['Variables']] + [r for n, r in rows.items() if n not in have]
    with open(path, 'w', encoding='utf-8', newline='\n') as fh: fh.write(json.dumps(p, indent=2, ensure_ascii=False))

# WMMT3DX+ from the game itself (Alexis's `main`, 11 November 2026). The game is a 32-bit Linux program that
# TeknoParrot's BudgieLoader maps at its own fixed addresses (as for OutRun 2), and it still has its symbol names, so
# every row below reads the game's own variables by absolute address: unlike the cheat table's BudgieLoader.exe+...
# chains, TeknoParrot updates can't move them. Details in claude/WMMT3DXP-exe-20261111.md.
#   yt::CSeq::pMachine 0x098138E4 -> the player's car (yt::CMachine): +AE0 speed mm/s (the speedo shows x 0.0036),
#     +2C4 the transmission (its +0 the engine data, whose +8C is the limiter; +8 engine rad/s, so machine +2CC;
#     +3C gear, so machine +300), +340 the turbo (+4 boost bar, +28 blow-off), +36C the backfire (+30 counter),
#     +AF8 slip angle (16 bits a turn), +AFC wheel slip ratio, +90/+D4 car and wall contact, +970 odometer mm.
#   yt::CSeq::pIO 0x098138E0 -> +0 steering (the game's sign flipped), +4 throttle, +8 brake.
#   yt::CSeq::pTimeKeeper 0x098138C8 -> +0 sections to the goal, +C race clock s, +14 sections passed.
#   yt::CSeq::pRivalCarAry 0x098138B4 -> the first rival car, +7F4 its odometer mm.
#   yt::CState::eState 0x09813A78, fTDec_Rest 0x09813A6C (the cheat table's "GTimer1"), fTDec_CountDown 0x09813A68,
#     bReverseBuf 0x09813A58; yt::CSeq::bIsInitialized 0x09813970 (1 from a race's start to its end: CSeq::End frees
#     the car without clearing the pointer, so every car row is gated on it).
WM3 = ' From the game\'s own code (its `main`, 11 November 2026). Not yet checked in a recording.'
WM3_OK = (" From the game's own code (its `main`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 18:36 "
          "(story mode, C class, Hakone inbound, manual).")
WM3_CE = (" Kept unticked to compare with the row read from the game's own variables in the next recording; this is in "
          "BudgieLoader's memory, so TeknoParrot updates move it (October 2026's did). Remove once the game's row is checked.")
WM3_STATES = ('0 none, 1 countdown, 2 racing (Run), 3 retired (going the wrong way too long), 4 slowing down (the time ran out), '
              '5 stop wait, 6 time up, 7 at the goal (GoalWait: from the moment the car crosses the finish line), 8 goal, 9 defeated, '
              '10 suspended')

def wmmt3_rows():
    M, IO, TK = '098138E4', '098138E0', '098138C8'
    def mem(name, typ, base, offs, notes, formula='', on=True):
        return dict(Name=name, Enabled=on, Source='Memory', Type=typ, Module='', BaseOffset=base, Offsets=offs,
                    Formula=formula, Notes=notes + WM3)
    def calc(name, formula, notes, on=True):
        return dict(Name=name, Enabled=on, Source='Computed', Type='Float', Module='', BaseOffset='0', Offsets='',
                    Formula=formula, Notes=notes + WM3)
    def ok(r, extra=''):
        r['Notes'] = r['Notes'].replace(WM3, extra + WM3_OK); return r
    def ce(name, typ, base, offs, formula, notes):
        return dict(Name=name, Enabled=False, Source='Memory', Type=typ, Module='BudgieLoader.exe', BaseOffset=base, Offsets=offs,
                    Formula=formula, Notes=notes + WM3_CE)
    G = 'seq_active ? '
    rows = [
        mem('speed', 'Float', M, 'AE0', 'Speed, km/h: the car\'s speed in mm per second times 0.0036, exactly as the game works out its '
            'speedo. Divided by Max speed (220).', G + 'value * 0.0036 / max_speed : 0'),
        mem('rpm', 'Float', M, '2CC', 'Engine revs: the engine\'s speed in radians a second times 60 / 2 pi, the value the game\'s tacho '
            'and rev lamp work from (this car\'s limiter is 10,000). Divided by Max revs (10000). The dial shows less: see tacho.',
            G + 'value * 60 / (2 * pi) / max_revs : 0'),
        mem('gear', 'Int32', M, '300', 'Gear in play: 1 = first, 0 = neutral, -1 reverse (the transmission\'s own gear; with a manual '
            'shifter it is the shifter\'s position, up to the car\'s top gear).', G + 'value : 0'),
        mem('rev_limit', 'Float', M, '2C4, 8C', 'This car\'s limiter, RPM, from its engine data (the game\'s tacho and rev lamp are '
            'worked out against it).', G + 'value : 0'),
        calc('rpm_frac', 'rev_limit > 0 ? clamp(rpm * max_revs / rev_limit, 0, 1) : 0', 'Revs as a fraction of this car\'s own '
             'limiter, 0 to 1, as the game works it out for the tacho.'),
        calc('tacho', 'seq_active ? (rpm_frac > 0.1 ? 0.96 * rpm_frac + 0.04 : 5 * rpm_frac * rpm_frac + 0.05) * 8000 : 0',
             'Revs as the dial shows them, RPM: the game sets the needle to 0.96 x the rev rate + 0.04 (yt::CSeq::Get2DInfoMeter), '
             'and the needle\'s full travel ends at the 8,000 mark (the dial is printed to 9,000 on every car, and the needle never gets '
             'there: Alexis). Her readings of 7.6k, 6.8k and 7.5k against 7,560, 6,890 and 7,480 from this; the engine itself was at '
             '9,430, 8,557 and 9,323.'),
        calc('shift_light', 'rpm_frac > 0.86', 'The meter\'s rev lamp: on above 86% of the limiter, where the game lights it (the game '
             'blinks it; this holds it on).'),
        mem('turbo', 'Float', M, '344', 'Turbo boost, bar: -0.5 off the throttle up to this car\'s full boost (turbo_max). The boost '
            'gauge reads it.', G + 'value : 0'),
        mem('turbo_max', 'Float', M, '340, 44', 'This car\'s full boost, bar, from its turbo table by tuning: 0.6 untuned, then 0.9, 1.2, '
            'and 1.5 fully tuned.', G + 'value : 0'),
        mem('blowoff', 'Byte', M, '368', '1 while the boost falls away fast (from over 0.2 bar, by more than 0.27 in a frame): the game '
            'plays the blow-off valve then.', G + 'value : 0'),
        mem('backfire', 'Int32', M, '39C', '1 for about 0.4 s from the exhaust flame: lifting off sharply at high revs starts a count '
            'of 35 or 38 frames and the game shows the flame as it passes 26.', G + '(value > 0 && value <= 26) : 0'),
        mem('drift_angle', 'Int16', M, 'AF8', 'Slip angle, degrees: the angle between where the car points and where it is going, '
            'from its sideways and forward speed (the game keeps it in 65536ths of a turn), + a right-hand drift (confirmed by Alexis: '
            'a right-hander at 75 s and a left hairpin at 81 s in her recording of 11 November 2026, 18:36).', G + '-value * 360 / 65536 : 0'),
        mem('wheel_slip', 'Float', M, 'AFC', 'Wheel slip: the driven wheels\' speed against the car\'s, as a fraction (+ wheelspin, '
            '- locking, -1 locked).', G + 'value : 0'),
        mem('wall_touch', 'Byte', M, 'D4', '1 while the car touches a wall (the game\'s own contact flag, set each frame).', G + 'value : 0'),
        mem('wall_force', 'Float', M, '110', 'Strength of the wall contact, in the game\'s units (it shakes the camera by it).',
            G + 'value : 0', on=False),
        mem('car_touch', 'Byte', M, '90', '1 while the car touches another car (the game\'s own contact flag, set each frame).',
            G + 'value : 0'),
        mem('car_force', 'Float', M, 'CC', 'Strength of contact with another car, in the game\'s units: about 1,000 for a nudge on the '
            'rival, 2,000 to 6,000 for a swipe on traffic, 15,000 to 19,000 running into the back of traffic at 200 km/h or a truck '
            'shunting the car (' + "Alexis's recordings of 11 November 2026" + ').', G + 'value : 0', on=False),
        calc('hit_car', 'maxw(car_touch ? clamp(sqrt(car_force / 15000), 0, 1) : 0, 0.15)', 'Hits on other cars and traffic, 0 to 1, '
             'held 0.15 s: the square root of the contact strength over 15,000, so a nudge reads 0.25, a swipe 0.4 to 0.65, a crash 1. '
             'TeknoParrot\'s reflect slot misses these (it gives car hits 59 of 63, under the wall-hit threshold). In ' + "Alexis's recording of 11 November 2026, 20:15" + ' it caught all 13 contacts with a strength (a 14th, with none, ran into a wall a frame later).'),
        calc('car_side', 'maxw(maxw(car_touch, 0.1) && tp_reflect < -0.9 && tp_reflect > -0.97, 0.15) - '
             'maxw(maxw(car_touch, 0.1) && tp_reflect > 0.9 && tp_reflect < 0.97, 0.15)', 'Side of a car or traffic hit, +1 right, -1 left, '
             'held 0.15 s: TeknoParrot\'s slot 9 gives car hits 59 of 63, signed the opposite way to wall hits (-59 for a hit on the right). '
             'Alexis\'s answers for 11 November 2026: her front right on the rival twice and on traffic twice read right, a truck along her '
             'left side read left. Straight-on hits get a side from whichever corner touched first; a hit from behind read left.'),
        mem('odometer', 'Float', M, '970', 'Distance along the course, metres (the game keeps it in mm).', G + 'value / 1000 : 0'),
        mem('rival_odometer', 'Float', '098138B4', '7F4', 'The CPU rival\'s distance along the course, metres (the first rival car; '
            'none in time attack or linked play).', G + 'value / 1000 : 0', on=False),
        calc('rival_gap', 'valid(odometer - rival_odometer, 0)', 'Metres ahead of the CPU rival (+ ahead, - behind); 0 with no rival. '
             'The same distances the race display measures to the goal.'),
        calc('leader', 'rival_gap > 0', '1 while ahead of the CPU rival.'),
        mem('seq_active', 'Byte', '09813970', '', '1 from the start of a race (or other drive) to its end (yt::CSeq::bIsInitialized). '
            'The car rows read 0 outside it, as the game frees the car without clearing its pointer.', on=False),
        mem('race_state', 'Int32', '09813A78', '', 'Race state (yt::CState::eState): ' + WM3_STATES + '.', G + 'value : 0'),
        calc('in_race', 'seq_active && maxw(race_time != prev(race_time) || countdown != prev(countdown), 0.25) && '
             '(race_state == 2 || race_state == 1 && countdown < 3.99)',
             '1 from the start of the countdown (the driver\'s view) to the finish line: race state 1 with the countdown running, '
             'then 2. The game moves to 7 the moment the car crosses the line, and to 4 when the time runs out. Off while the '
             'clocks stand still (a pause). The story mode\'s opening shot before the race also sets state 1 for a moment, but with '
             'the countdown held at 4, so it stays off.'),
        mem('time_left', 'Float', '09813A6C', '', 'Time left, seconds (yt::CState::fTDec_Rest; the cheat table\'s "GTimer1", which was '
            'the race_timer row): counts down while racing; at 0 the race slows to a stop.', G + 'value : 0'),
        mem('countdown', 'Float', '09813A68', '', 'The start countdown, seconds (yt::CState::fTDec_CountDown).', G + 'value : 0', on=False),
        mem('race_time', 'Float', TK, 'C', 'Race clock, seconds (the time keeper\'s, which the split times come from).', G + 'value : 0'),
        mem('sections', 'Int32', TK, '0', 'Sections in the race: the finish line is the last.', G + 'value : 0'),
        mem('sections_passed', 'Int32', TK, '14', 'Section lines passed so far; the race is finished when it reaches sections.',
            G + 'value : 0'),
        calc('checkpoint', 'maxw(sections_passed > prev(sections_passed) && sections_passed < sections, 2)', '1 for 2 s after each '
             'section line before the finish (where any extra time is added).'),
        mem('reversing', 'Int32', '09813A58', '', '1 while the game counts the car as going the wrong way (yt::CState::bReverseBuf; too '
            'long and the race state goes to 3, retired).', G + '(band(value, 16777215) != 0) : 0'),
        mem('throttle', 'Float', IO, '4', 'Throttle pedal, 0 to 1, as the game uses it.', G + 'value : 0'),
        mem('brake', 'Float', IO, '8', 'Brake pedal, 0 to 1, as the game uses it.', G + 'value : 0'),
        mem('steer', 'Float', IO, '0', 'Steering, -1 to 1, + right (the game keeps it with the sign flipped; confirmed by Alexis, '
            'recording of 11 November 2026, 18:36).',
            G + '-value : 0'),
    ]
    R3 = "Alexis's recording of 11 November 2026, 18:36"
    checked = {
        'speed': ' It matched the old cheat-table row (a copy of the meter) to 0.1 km/h through the race.',
        'gear': (" It matched the old row apart from a frame's lag at each change, and held 5th where the old row (the meter) "
                 "showed the shifter in 6th on this five-speed car."),
        'rival_gap': ' Behind at the start, then ahead, passed and ahead again, as the race went.',
        'leader': '',
        'in_race': (' Race state 2 from GO (47.68 s) to the finish line (263.76 s); the countdown from 43.6 s is the driver\'s view '
                    '(Alexis: start there, not in the opening shot from 34 s). The attract mode (recording of 11 November 2026, '
                    '16:59) never ran the race code. Her pause in the first recording that day froze every clock for 3.4 s.'),
        'time_left': ' 300 at GO, stopping at the finish line.',
        'race_time': ' 216.06 s at the line: the time from GO.',
    }
    for r in rows:
        if r['Name'] in checked:
            r['Notes'] = r['Notes'].replace(WM3, checked[r['Name']] + WM3_OK)
        if r['Name'] in ('sections', 'sections_passed'):
            r['Enabled'] = False
        if r['Name'] == 'sections':
            r['Notes'] = r['Notes'].replace(WM3, ' Story mode read 2 throughout, and sections_passed 2 too, so checkpoint never '
                                            'fired there (the story race ends on the rival, not on sections).' + WM3)
        if r['Name'] == 'wheel_slip':
            r['Notes'] = ("Wheel slip, the game's own measure of the driven wheels against the car: about -0.1 cruising, more "
                          "negative as the wheels spin up (-0.3 with the car in the air, -0.6 pulling away in first), a little above 0 "
                          "under braking (" + R3 + ")." + WM3_OK)
    at = [r['Name'] for r in rows].index('wheel_slip') + 1
    rows[at:at] = [
        mem('load', 'Float', M, 'AE4', "Load on the tyres as a fraction of the car's weight: 1 on the flat, more in a dip or on "
            "landing, 0 in the air. The game works its wheel spring out from it (load x 1.6 - 0.6, so the spring is gone below "
            "0.375). In " + R3 + " it went under that only over crests and at the jump (252.3 s).", G + 'value : 0'),
        calc('light', 'maxw(seq_active && load < 0.5, 0.1)', "1 while the car is light over a crest (load under half its weight; "
             "held 0.1 s, as the load jitters). Alexis: the car goes slightly light over the crests at 50.5 s and 218.9 s in " + R3 +
             ", not airborne, and wants a light effect there."),
        calc('airborne', 'minw(seq_active && load < 0.375, 0.25)', "1 once the car has had too little load to steer for 0.25 s: "
             "in the air. In " + R3 + " the wheel spring that follows the load read 0 for 0.48 s at the jump (252.34 s, the rear in the "
             "air as Alexis described) and 0.19 s and 0.08 s over the crests, which she says were light, not airborne."),
    ]
    # Raw contact vectors and the car's orientation, unticked and unused, to work out the side of car hits from a recording
    # (the game pushes the car along these; HitReaction and WallReaction turn them with the matrix at +A4C).
    raw = [('carhit_x', 'C0'), ('carhit_y', 'C4'), ('carhit_z', 'C8'), ('wallhit_x', '104'), ('wallhit_y', '108'), ('wallhit_z', '10C'),
           ('mat_00', 'A4C'), ('mat_01', 'A50'), ('mat_02', 'A54'), ('mat_10', 'A5C'), ('mat_20', 'A6C')]
    for n, o in raw:
        rows.append(mem(n, 'Float', M, o, "Raw, for working out the side of hits: the push the game gives the car on a car contact "
                        "(carhit_), a wall contact (wallhit_), and the car's orientation matrix (mat_ row, column). Not used yet.",
                        G + 'value : 0', on=False))
    return rows

def add_wmmt3(pack):
    """WMMT3DX+ rows read from the game's own variables, replaced on each run (so running twice changes nothing)."""
    import json, os
    import packlayout
    path = packlayout.path(pack, 'WMMT3DXP')
    if not os.path.isfile(path): return
    with open(path, encoding='utf-8') as fh: p = json.load(fh)
    rows = wmmt3_rows()
    mine = {r['Name'] for r in rows} | {'race_timer', 'race_timer2', 'speed_ce', 'gear_ce', 'rpm_ce'}
    p['Variables'] = [v for v in p['Variables'] if v['Name'] not in mine and 'cheat table (04.10.26 pack)' not in v['Notes']]
    p['Variables'][0:0] = rows
    p['MaxRevs'] = 10000.0   # the engine revs; Alexis's car's limiter (11 November 2026)
    with open(path, 'w', encoding='utf-8', newline='\n') as fh: fh.write(json.dumps(p, indent=2, ensure_ascii=False))

# Lamps for STCC and Sega Rally. Both games build their lamp byte in their own RAM (STCC 0x20B2E4, Sega Rally
# 0x20204C) and write it, with two input-select bits, to I/O port 0x01C0000A (STCC stob at 0x69A60, Sega Rally
# stob at 0x247C). The emulator keeps the last value written to that port at exe+174CF0 (its port handler at
# 0x4C870C / 0x4CB6B0: port 0x0A -> [0x574CF0], port 0x08 -> [0x574CF4], Sega Rally's drive board byte). That is
# exactly what Alexis's STCC build of OutputBlaster reads (Int32 at exe+174CF0, bits 4 start, 128 leader, 8/16/32/64
# view 1-4), which lights her STCC leader lamp through MAMEHooker. Neither game's own script moves the lamps to
# RAM+824 (Daytona's does), so the regular OutputBlaster build sees nothing for them. Both games also read their
# controls back through port 0x01C0001E, which is what the old TPT_LAMP_PATCH moved and why it froze them.
LAMP_LATCH = '174CF0'
GAME_LAMPS = {
    'M2SRALLY': "In Alexis's logs of 8 November 2026 only bit 5 (32, lampview3) ever lit, blinking from coin-up to the end, "
                "including while she led in practice: nothing lit for the lead (use the leader row).",
    'M2STCC': "Alexis's STCC build of OutputBlaster reads this same value, and its LampLeader (128) drives her leader lamp. "
              "In her logs of 8 November 2026 she never led; bit 3 (8, lampview1) blinked for a few seconds around the start.",
}

def fix_m2_lamps(pack):
    """Runs after oblamps.py: points the STCC and Sega Rally rawlamps rows at the emulator's lamp-port latch."""
    import json, os
    import packlayout
    n = 0
    for pre, seen in GAME_LAMPS.items():
        path = packlayout.path(pack, pre)
        if not os.path.isfile(path): continue
        with open(path, encoding='utf-8') as fh: p = json.load(fh)
        for v in p['Variables']:
            if v['Name'] == 'rawlamps' and v['Source'] == 'Memory':
                v.update(Module='<main>', BaseOffset=LAMP_LATCH, Offsets='', Type='Byte',
                         Notes="Lamps, one bit each (4 start, 128 leader, 8/16/32/64 view 1 to 4; the bottom two bits are an "
                               "input select, not lamps): the emulator's copy of what the game last wrote to its lamp port "
                               "(0x01C0000A), as OutputBlaster's STCC build reads it. No script or patch needed. Not RAM+824: "
                               "this game's script doesn't move the lamps there. " + seen)
                n += 1
            elif 'rawlamps' in (v['Formula'] or ''):
                v['Notes'] = (v['Notes'].split(' From game memory')[0] + " From the emulator's lamp-port value (see rawlamps); "
                              "no OutputBlaster needed.")
        with open(path, 'w', encoding='utf-8', newline='\n') as fh: fh.write(json.dumps(p, indent=2, ensure_ascii=False))
    return n

def fix_mk118_lamps(pack):
    """Runs after oblamps.py. OutputBlaster's MarioKart1.18 reads its side, billboard and under lamps as single bytes but tests
    bits up to 0xF0000000, so every output above the low byte can never light. Read the words as 32 bits instead: the low
    byte (and so the outputs that worked) is unchanged, and the high bits become readable. Unverified until a recording."""
    import json, os
    import packlayout
    path = packlayout.path(pack, 'MKGPDX118')
    if not os.path.isfile(path): return 0
    with open(path, encoding='utf-8') as fh: p = json.load(fh)
    n = 0
    for v in p['Variables']:
        if v['Name'] in ('ob_kanbansidelampdata', 'ob_underlampdata') and v['Source'] == 'Memory':
            v['Type'] = 'Int32'
            if 'as 32 bits' not in v['Notes']:
                v['Notes'] += (" Read as 32 bits: OutputBlaster reads one byte here but tests bits up to 0xF0000000, so its outputs above "
                               "the low byte never light. Alexis's recording (11 November 2026): the word is LED colour levels, 0 to 15 "
                               "a hex digit, five digits in use (a rainbow cycling through them in the attract mode), so the on/off "
                               "rows below flicker; which digit is which LED colour is still to be found in the game's code.")
            n += 1
        elif v['Name'] == 'ob_buttondata' and 'item button' not in v['Notes']:
            v['Notes'] += (" Alexis's recording (11 November 2026): 4 the item button's lamp (lit from an item box until the item is "
                           "used or lost; blinking in the attract mode), 8 lit while driving in a race (off for drift hops, "
                           "spin-outs and gliding).")
    with open(path, 'w', encoding='utf-8', newline='\n') as fh: fh.write(json.dumps(p, indent=2, ensure_ascii=False))
    return n

MKUSA_JVS = 0xCF880   # the USA version's I/O block sits this far above v1.18's (memgames.py JVS_USA)

def fix_mkusa_lamps(pack):
    """Runs after fix_mk118_lamps. OutputBlaster has no build for the USA version, but its I/O (JVS) block is v1.18's moved up
    0xCF880 (the item byte and the FFB plugin's shake word sit exactly there; 11 November 2026, claude/MKGPDXUSA-exe-20261111.md).
    So the USA profile gets v1.18's lamp rows reading the same words at the moved addresses. Unverified until a recording."""
    import json, os, re
    import packlayout
    src, dst = packlayout.path(pack, 'MKGPDX118'), packlayout.path(pack, 'MKGPDXUSA')
    if not (os.path.isfile(src) and os.path.isfile(dst)): return 0
    with open(src, encoding='utf-8') as fh: p118 = json.load(fh)
    with open(dst, encoding='utf-8') as fh: p = json.load(fh)
    raw = [v for v in p118['Variables'] if v['Name'].startswith('ob_') and v['Source'] == 'Memory']
    names = {v['Name'] for v in raw}
    lamps = [v for v in p118['Variables'] if v['Source'] == 'Computed' and 'the same reads OutputBlaster makes' in (v['Notes'] or '')
             and set(re.findall(r'\bob_\w+', v['Formula'] or '')) <= names]
    have = {v['Name'] for v in p['Variables']}
    add = []
    for v in raw:
        if v['Name'] in have: continue
        add.append(dict(v, BaseOffset=f"{int(v['BaseOffset'], 16) + MKUSA_JVS:X}",
                        Notes=f"Raw lamp word: the one OutputBlaster's MarioKart1.18 reads at <main>+{v['BaseOffset']}, at this version's "
                              "address (the I/O block sits 0xCF880 higher; OutputBlaster has no USA build). The output rows decode it. "
                              "Unverified." + (" Read as 32 bits, as for v1.18." if v['Type'] == 'Int32' else '')))
    for v in lamps:
        if v['Name'] in have: continue
        out = v['Notes'].split(' output')[0]
        add.append(dict(v, Notes=f"{out} output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this "
                                 "version's I/O block (no OutputBlaster needed). Unverified."))
    if not add: return 0
    p['Variables'] += add
    with open(dst, 'w', encoding='utf-8', newline='\n') as fh: fh.write(json.dumps(p, indent=2, ensure_ascii=False))
    return len(add)
