# Setting up each game

How to get each game in the pack working with TP Telemetry, all in one place. Find your game in the
index, then follow its section.

**Before any game:**

1. **Set up the plugin itself** (its README, Build and install), and import the game's profile from
   this pack (README, Installing a profile).
2. **USBPcap may be needed.** USB capture reads the force feedback your wheel gets
   (the plugin's USB_Capture.md: install USBPcap, run SimHub as administrator, choose your wheel once).
   No game here *needs* it, but for games marked **USB adds** it fills effects the game has no values
   for (hits, road bumps, cornering, rumble), from the wheel force.
3. **OutputBlaster** is needed only for the rows marked **OutputBlaster** below (it must run with
   `OutputsSystem=1`; the plugin's Game_Outputs.md). Every other lamp and output reads game memory.

**Tags in the index:**

| Tag | Means |
|---|---|
| TP shared memory | reads TeknoParrot's shared memory: nothing to set up beyond TeknoParrot running |
| 64-bit | read through the plugin's 64-bit helper (`TPTelemetryHelper64.exe`, next to the plugin; nothing to set up) |
| OutputBlaster | some rows need OutputBlaster running |
| outputs | an emulator's network outputs must be switched on |
| USB adds | USB capture fills effects this game has no values for |
| no car_ rows | the game gives no values the effects use (lamps, timers or dashboard values only): only USB capture's hits, bumps, cornering and rumble reach the effects |
| USB needed | rows that read the USB capture |
| checked | checked against real recordings; the rest are starting points (send a recording if something looks wrong) |

This file is generated from the profiles (`tools/gamesetup.py`), so it always matches them.


## Index

| Game | Profile | Runs in | Tags |
|---|---|---|---|
| [Arctic Thunder](#arcticthunder) | `ARCTICTHUNDER` | TeknoParrot | TP shared memory |
| [Batman (arcade)](#batman) | `BATMAN` | TeknoParrot | OutputBlaster, USB adds |
| [Battle Gear 4](#bg4) | `BG4` | TeknoParrot | no car_ rows, USB adds |
| [Battle Gear 4 Tuned (Japan)](#bg4jp) | `BG4JP` | TeknoParrot | USB adds, checked |
| [Cars](#cars) | `CARS` | TeknoParrot | no car_ rows, USB adds |
| [Chase H.Q. 2](#chasehq2) | `CHASEHQ2` | TeknoParrot | USB adds |
| [Crazy Ride](#crazyride) | `CRAZYRIDE` | TeknoParrot | OutputBlaster, no car_ rows, USB adds |
| [Crazy Streets - Thrill Drive 4](#thrilldrive4) | `THRILLDRIVE4` | TeknoParrot | USB adds |
| [Cruis'n Blast](#cruisnblast) | `CRUISNBLAST` | TeknoParrot | OutputBlaster, USB adds |
| [D1 Grand Prix](#d1gp) | `D1GP` | TeknoParrot | TP shared memory |
| [Daytona Championship USA](#daytona3) | `DAYTONA3` | TeknoParrot |  |
| [Daytona Championship USA New Season Edition](#daytona3nse) | `DAYTONA3NSE` | TeknoParrot |  |
| [Dead Heat](#deadheat) | `DEADHEAT` | TeknoParrot | TP shared memory, OutputBlaster, USB adds |
| [Dead Heat Riders](#deadheatriders) | `DEADHEATRIDERS` | TeknoParrot | TP shared memory, USB adds |
| [Dirty Drivin'](#dirtydrivin) | `DIRTYDRIVIN` | TeknoParrot | USB adds |
| [Ford Racing](#fordracing) | `FORDRACING` | TeknoParrot | TP shared memory, USB adds |
| [GRID (arcade)](#grid) | `GRID` | TeknoParrot | checked |
| [GTI Club Supermini Festa](#gticlub3) | `GTICLUB3` | TeknoParrot | checked |
| [H2Overdrive](#h2overdrive) | `H2OVERDRIVE` | TeknoParrot | OutputBlaster, USB adds |
| [Harley-Davidson: King of the Road](#harley) | `HARLEY` | TeknoParrot | no car_ rows, USB adds |
| [Hummer](#hummer) | `HUMMER` | TeknoParrot | no car_ rows, USB adds |
| [Hummer Extreme Edition](#hummerextreme) | `HUMMEREXTREME` | TeknoParrot | no car_ rows, USB adds |
| [Hydro Thunder](#hydrothunder) | `HYDROTHUNDER` | TeknoParrot | USB adds |
| [Initial D Arcade Stage 4 (export)](#id4) | `ID4` | TeknoParrot |  |
| [Initial D Arcade Stage 4 (Japan)](#id4jp) | `ID4JP` | TeknoParrot | OutputBlaster |
| [Initial D Arcade Stage 5](#id5) | `ID5` | TeknoParrot |  |
| [Initial D Arcade Stage 6 AA](#id6) | `ID6` | TeknoParrot | TP shared memory, checked |
| [Initial D Arcade Stage 7 AAX](#id7) | `ID7` | TeknoParrot | TP shared memory |
| [Initial D Arcade Stage 8 Infinity](#id8) | `ID8` | TeknoParrot | TP shared memory |
| [Initial D Arcade Stage Zero v1.31](#id0v131) | `ID0V131` | TeknoParrot | 64-bit |
| [Initial D Arcade Stage Zero v2.11](#id0v211) | `ID0V211` | TeknoParrot | 64-bit |
| [Initial D Arcade Stage Zero v2.30](#id0v230) | `ID0V230` | TeknoParrot | 64-bit, checked |
| [Initial D The Arcade Season 4 v2.5](#idtas4) | `IDTAS4` | TeknoParrot | 64-bit, no car_ rows, USB adds |
| [Initial D The Arcade Season 5 v3.10](#idtas5) | `IDTAS5` | TeknoParrot | 64-bit, USB adds |
| [Initial D The Arcade Season 5 v3.21 (ARCADEZONE.CN)](#idtas5v321) | `IDTAS5V321` | TeknoParrot | 64-bit, no car_ rows, USB adds |
| [Initial D The Arcade v2.1 (Season 3)](#idta21) | `IDTA21` | TeknoParrot | 64-bit, no car_ rows, USB adds |
| [Initial D The Arcade v2.31](#idta) | `IDTA` | TeknoParrot | 64-bit |
| [KO Drive](#kodrive) | `KODRIVE` | TeknoParrot |  |
| [Mario Kart Arcade GP DX (USA)](#mkgpdxusa) | `MKGPDXUSA` | TeknoParrot | USB adds, checked |
| [Mario Kart Arcade GP DX v1.10](#mkgpdx110) | `MKGPDX110` | TeknoParrot | USB adds |
| [Mario Kart Arcade GP DX v1.18](#mkgpdx118) | `MKGPDX118` | TeknoParrot | USB adds, checked |
| [MotoGP (2015)](#motogp) | `MOTOGP` | TeknoParrot | no car_ rows, USB adds |
| [OutRun 2 SP SDX](#outrun2sp) | `OUTRUN2SP` | TeknoParrot | USB adds, checked |
| [R-Tuned: Ultimate Street Racing](#rtuned) | `RTUNED` | TeknoParrot | USB adds |
| [Road Fighters 3D](#rf3d) | `RF3D` | TeknoParrot |  |
| [Sega Race TV](#segaracetv) | `SEGARACETV` | TeknoParrot | USB adds |
| [Sega Racing Classic](#segaracingclassic) | `SEGARACINGCLASSIC` | TeknoParrot |  |
| [Sega Rally 3](#sr3) | `SR3` | TeknoParrot | TP shared memory, USB adds, checked |
| [Sega World Drivers Championship](#swdc) | `SWDC` | TeknoParrot | 64-bit, checked |
| [Sonic & Sega All-Stars Racing](#sonicasr) | `SONICASR` | TeknoParrot | USB adds |
| [Storm Racer G](#srg) | `SRG` | TeknoParrot | TP shared memory, USB adds |
| [The Fast and the Furious Drift](#fnfdrift) | `FNFDRIFT` | TeknoParrot | no car_ rows, USB adds |
| [The Fast and the Furious Super Bikes 2](#fnfsb2) | `FNFSB2` | TeknoParrot | OutputBlaster, USB adds |
| [The Fast and the Furious SuperCars](#fnfsc) | `FNFSC` | TeknoParrot | no car_ rows, USB adds |
| [Wacky Races](#wackyraces) | `WACKYRACES` | TeknoParrot | USB adds |
| [Wangan Midnight Maximum Tune 3 DX+](#wmmt3dxp) | `WMMT3DXP` | TeknoParrot | TP shared memory, USB adds, checked |
| [Wangan Midnight Maximum Tune 5](#wmmt5) | `WMMT5` | TeknoParrot | 64-bit, USB adds |
| [Wangan Midnight Maximum Tune 5DX](#wmmt5dx) | `WMMT5DX` | TeknoParrot | 64-bit, USB adds |
| [Wangan Midnight Maximum Tune 5DX+](#wmmt5dxp) | `WMMT5DXP` | TeknoParrot | 64-bit, USB adds, checked |
| [Wangan Midnight Maximum Tune 6](#wmmt6) | `WMMT6` | TeknoParrot | 64-bit, USB adds |
| [Wangan Midnight Maximum Tune 6R](#wmmt6r) | `WMMT6R` | TeknoParrot | 64-bit, USB adds |
| [Wangan Midnight Maximum Tune 6RR](#wmmt6rr) | `WMMT6RR` | TeknoParrot | 64-bit, USB adds |
| [Wangan Midnight Maximum Tune 6RR Plus v4.00.13](#wmmt6rrp) | `WMMT6RRP` | TeknoParrot | 64-bit, USB adds |
| [Winter X Games SnoCross](#snocross) | `SNOCROSS` | TeknoParrot | USB adds |
| [18 Wheeler: American Pro Trucker (Flycast)](#fly18wheeler) | `FLY18WHEELER` | Flycast | outputs |
| [Club Kart (Flycast)](#flyclubkart) | `FLYCLUBKART` | Flycast | outputs |
| [Faster Than Speed (Flycast)](#flyftspeed) | `FLYFTSPEED` | Flycast | outputs, USB adds |
| [Ferrari F355 Challenge (Flycast)](#flyf355) | `FLYF355` | Flycast | outputs |
| [Initial D Arcade Stage (Flycast)](#flyinitd) | `FLYINITD` | Flycast | outputs |
| [Initial D Arcade Stage Ver. 2 (Flycast)](#flyinitd2) | `FLYINITD2` | Flycast | outputs |
| [Initial D Arcade Stage Ver. 3 (Flycast)](#flyinitd3) | `FLYINITD3` | Flycast | 64-bit, outputs, checked |
| [Initial D Arcade Stage Ver. 3 Cycraft (Flycast)](#flyinitdcy) | `FLYINITDCY` | Flycast | outputs |
| [Maximum Speed (Flycast)](#flymaxspeed) | `FLYMAXSPEED` | Flycast | outputs, USB adds |
| [Sega Driving Simulator (Flycast)](#flysgdrvsim) | `FLYSGDRVSIM` | Flycast | outputs |
| [The King of Route 66 (Flycast)](#flykingrt66) | `FLYKINGRT66` | Flycast | outputs |
| [Cadash Bombers / Chase Bombers (MAME)](#mamecbombers) | `MAMECBOMBERS` | MAME | outputs, USB adds |
| [California Speed (MAME)](#mamecalspeed) | `MAMECALSPEED` | MAME | outputs, USB adds |
| [Cisco Heat (MAME)](#mamecischeat) | `MAMECISCHEAT` | MAME | outputs, USB adds |
| [Cruis'n USA (MAME)](#mamecrusnusa) | `MAMECRUSNUSA` | MAME | outputs, USB adds |
| [Cruis'n World (MAME)](#mamecrusnwld) | `MAMECRUSNWLD` | MAME | outputs, USB adds |
| [Double Axle (MAME)](#mamedblaxle) | `MAMEDBLAXLE` | MAME | outputs, USB adds |
| [F1 Grand Prix Star (MAME)](#mamef1gpstar) | `MAMEF1GPSTAR` | MAME | outputs, USB adds |
| [Hyperdrive (MAME)](#mamehyprdriv) | `MAMEHYPRDRIV` | MAME | outputs, USB adds |
| [Off Road Challenge (MAME)](#mameoffroadc) | `MAMEOFFROADC` | MAME | outputs, USB adds |
| [Out Run (MAME)](#mameoutrun) | `MAMEOUTRUN` | MAME | outputs |
| [OutRunners (MAME)](#mameorunners) | `MAMEORUNNERS` | MAME | outputs, USB adds |
| [Power Drift (MAME)](#mamepdrift) | `MAMEPDRIFT` | MAME | outputs |
| [San Francisco Rush (MAME)](#mamesfrush) | `MAMESFRUSH` | MAME | outputs, USB adds |
| [San Francisco Rush 2049 (MAME)](#mamesf2049) | `MAMESF2049` | MAME | outputs, USB adds |
| [San Francisco Rush: The Rock (MAME)](#mamesfrushrk) | `MAMESFRUSHRK` | MAME | outputs, USB adds |
| [Turbo Out Run (MAME)](#mametoutrun) | `MAMETOUTRUN` | MAME | outputs, USB adds |
| [Vapor TRX (MAME)](#mamevaportrx) | `MAMEVAPORTRX` | MAME | outputs, USB adds |
| [Virtua Racing (MAME)](#mamevr) | `MAMEVR` | MAME | outputs |
| [Daytona USA (Model 2 Emulator)](#m2daytona) | `M2DAYTONA` | Model 2 Emulator | checked |
| [Indianapolis 500 (Model 2 Emulator)](#m2indy500) | `M2INDY500` | Model 2 Emulator |  |
| [Over Rev (Model 2 Emulator)](#m2overrev) | `M2OVERREV` | Model 2 Emulator |  |
| [Sega Rally Championship (Model 2 Emulator)](#m2srally) | `M2SRALLY` | Model 2 Emulator | checked |
| [Sega Touring Car Championship (Model 2 Emulator)](#m2stcc) | `M2STCC` | Model 2 Emulator | checked |
| [Super GT 24h (Model 2 Emulator)](#m2sgt24h) | `M2SGT24H` | Model 2 Emulator |  |
| [Daytona USA 2 (Supermodel)](#smdaytona2) | `SMDAYTONA2` | Supermodel | outputs |
| [Daytona USA 2 Power Edition (Supermodel)](#smdayto2pe) | `SMDAYTO2PE` | Supermodel | 64-bit, outputs |
| [Dirt Devils (Supermodel)](#smdirtdevils) | `SMDIRTDEVILS` | Supermodel | outputs, USB adds |
| [Emergency Call Ambulance (Supermodel)](#smeca) | `SMECA` | Supermodel | outputs, USB adds |
| [Le Mans 24 (Supermodel)](#smlemans24) | `SMLEMANS24` | Supermodel | outputs |
| [Scud Race (Supermodel)](#smscud) | `SMSCUD` | Supermodel | 64-bit, outputs |
| [Sega Rally 2 (Supermodel)](#smsrally2) | `SMSRALLY2` | Supermodel | outputs, USB adds |
| [Crazy Taxi](#crazytaxi) | `CRAZYTAXI` | PC | USB adds |

## Common steps by emulator

<a id="steps-teknoparrot"></a>
### TeknoParrot

1. Run the game in TeknoParrot. The plugin finds it by its Process name (filled in for you) and selects it, or select it in the Game list, or from a launch line (the plugin's README, Choosing the game from a launch script).
2. If TeknoParrot runs as administrator, SimHub must too, or the plugin can't read the game or TeknoParrot's shared memory.

<a id="steps-flycast"></a>
### Flycast

1. In Flycast: Settings, Network, tick **Broadcast Digital Outputs**. Without it the profile reads nothing. Needs plugin 0.13.3 or later.
2. No process: select the game in the Game list (or from a launch line). See the plugin's Game_Outputs.md.

<a id="steps-mame"></a>
### MAME

1. Switch MAME's outputs on: in `mame.ini`, set `output` to `network`. Without it the profile reads nothing.
2. No process: select the game in the Game list (or from a launch line). See the plugin's Game_Outputs.md.

<a id="steps-model-2-emulator"></a>
### Model 2 Emulator

1. Use `emulator_multicpu.exe`, the build the FFB Arcade Plugin and OutputBlaster know (TeknoParrot's own Model 2 emulator may differ).
2. Keep each game's own script in the emulator's `SCRIPTS` folder (it ships with the emulator); TP Telemetry needs no scripts of its own. If you renamed one to `<romname>_orig.lua` for TP Telemetry's RAM logger, rename it back and delete the logger's copy.
3. If the emulator runs as administrator, SimHub must too.

<a id="steps-supermodel"></a>
### Supermodel

1. Start Supermodel with `-outputs=net`. Without it the profile reads nothing.
2. No process: select the game in the Game list (or from a launch line). See the plugin's Game_Outputs.md.

<a id="steps-pc"></a>
### PC

1. Set the profile's Process to your copy's exe if it's blank.

## Games

## TeknoParrot games

<a id="arcticthunder"></a>
### Arctic Thunder (`ARCTICTHUNDER`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `snow.exe`.
* **TeknoParrot shared memory:** force feedback rows read it, so they work as soon as TeknoParrot runs the game.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="batman"></a>
### Batman (arcade) (`BATMAN`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `sdaemon.exe`.
* **OutputBlaster needed** for: `base`, `billboard_white`, `billboardlamp`, `dash`, `lampblue`, `lampgreen`, `lampred`, `lampstart`, `seat_right`, `shoot1p`, `speaker_1`, `speaker_2`, `speaker_3`. Without it those rows read 0 and the rest work.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_green`, `TPTelemetry.Lamp_blue`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* Lamps come from OutputBlaster (it only sends them while a flag it keeps is on).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="bg4"></a>
### Battle Gear 4 (`BG4`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `game.exe`.
* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_shift` (Common_Lamps.md).
* For the export version: lamps only. The Japanese Battle Gear 4 Tuned is `BG4JP`.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="bg4jp"></a>
### Battle Gear 4 Tuned (Japan) (`BG4JP`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `game.exe`.
* **USB capture adds** road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_position`, `TPTelemetry.Car_lap`, `TPTelemetry.Car_time_left` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_checkpoint`, `TPTelemetry.Lamp_shift`, `TPTelemetry.Lamp_warning`, `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_green`, `TPTelemetry.Lamp_blue`, `TPTelemetry.Lamp_white` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 200 and Max revs 8000 set.
* For Battle Gear 4 Tuned (Japan) v2.07, the version the FFB Arcade Plugin supports (its GameId 13).
* `speed` is the speedo's km/h and `rpm` the engine's revs (700 idle), read from car 0 like the FFB plugin does; `gear` is -1 in reverse and 0 in neutral. `racing` is 1 from the green light.
* The game's race flag stays on in the menus after a credit stops the attract demo (the car values freeze there), so Car_in_race also needs the camera (`view`) not to be 12. It goes off at the finish line (race phase 8) and at time up.
* Max speed 200 km/h (Alexis: most races stay under it, and above it the cars barely steer; the fast cars reach about 295). Max revs 8000 (the Citroën's limiter; the Golf GTI's is 7500, a tuned car's 9000).
* `brake_warning`, `corner_ahead`, `corner_side` and `corner_sharpness` come from the car navigation (the CARNAVI setting must be on). `drift_angle` and `drift` feed Car_drift; `time_left` is the race time (RT), `lap` the laps completed, `checkpoint` 1 for 2 s after a checkpoint adds time; `wheelspin` feeds Car_grip_loss.
* If every row reads 0 or never changes while the game runs, TP Telemetry is reading another copy of game.exe: use plugin 0.18.1 or later, which always reads the newest.
* **Checked:** Alexis's recordings of 10 November 2026 (a Golf GTI race with four cars; a time trial in a fast car to the finish; reverse in a Trueno): speed, revs, gears, positions, the leader, wall hits and scrapes by side, car contact on every side, and the menu problem (the race flag stays on), the nitro (wall bit 2), the finish (race phases 8 and 9), reverse, time left, laps and a checkpoint, wheelspin, time up, the drift angle (her drifts read 20 to 48 degrees, following the wheel), the nitro against the game's nitro timer, the Brake! warning (from the car navigation, 11 November).

<a id="cars"></a>
### Cars (`CARS`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `sdaemon.exe`.
* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="chasehq2"></a>
### Chase H.Q. 2 (`CHASEHQ2`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `game.exe`.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="crazyride"></a>
### Crazy Ride (`CRAZYRIDE`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `CrazyTaxiGame-Win64-Shipping.exe`.
* **OutputBlaster needed** for: `lampstart`, `lampview1`, `lampview2`. Without it those rows read 0 and the rest work.
* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="thrilldrive4"></a>
### Crazy Streets - Thrill Drive 4 (`THRILLDRIVE4`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `td4.exe`.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_time_left` (besides speed, revs and gear; Common_Dashboard.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="cruisnblast"></a>
### Cruis'n Blast (`CRUISNBLAST`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **OutputBlaster needed** for: `lampstart`, `lampview1`, `lampview2`, `lampview3`, `lampview4`. Without it those rows read 0 and the rest work.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4` (Common_Lamps.md).
* Race force feedback comes from a hook, so there's none to read: USB capture fills the effects from the wheel force.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="d1gp"></a>
### D1 Grand Prix (`D1GP`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `game.exe`.
* **TeknoParrot shared memory:** force feedback rows read it, so they work as soon as TeknoParrot runs the game.
* **USB capture:** not needed; the game's own values cover the effects.
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* Force feedback from TeknoParrot's shared memory; `speed` reads `game.exe`.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="daytona3"></a>
### Daytona Championship USA (`DAYTONA3`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `Daytona.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4` (Common_Lamps.md).
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="daytona3nse"></a>
### Daytona Championship USA New Season Edition (`DAYTONA3NSE`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `Daytona.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4`, `TPTelemetry.Lamp_leader` (Common_Lamps.md).
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="deadheat"></a>
### Dead Heat (`DEADHEAT`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **TeknoParrot shared memory:** force feedback rows read it, so they work as soon as TeknoParrot runs the game.
* **OutputBlaster needed** for: `base`, `billboardlamp`, `dash`, `keypad`, `lampstart`, `lampview1`, `seatlamp1`. Without it those rows read 0 and the rest work.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* Lamps come from OutputBlaster (it works them out in code hooks).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="deadheatriders"></a>
### Dead Heat Riders (`DEADHEATRIDERS`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **TeknoParrot shared memory:** force feedback rows read it, so they work as soon as TeknoParrot runs the game.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="dirtydrivin"></a>
### Dirty Drivin' (`DIRTYDRIVIN`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `sdaemon.exe`.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_view1` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="fordracing"></a>
### Ford Racing (`FORDRACING`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** none (selected in the Game list).
* **TeknoParrot shared memory:** force feedback rows read it, so they work as soon as TeknoParrot runs the game.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* Force feedback from TeknoParrot's shared memory; no process needed.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="grid"></a>
### GRID (arcade) (`GRID`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `GRID.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_rev_limit_rpm`, `TPTelemetry.Car_position`, `TPTelemetry.Car_lap`, `TPTelemetry.Car_laps_total`, `TPTelemetry.Car_race_time`, `TPTelemetry.Car_brake`, `TPTelemetry.Car_steer` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_final_lap`, `TPTelemetry.Lamp_shift` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 280 and Max revs 6900 set.
* Force feedback: the FFB Arcade Plugin's Custom mode, made from the same values this profile reads, so USB capture adds nothing.
* Speed, revs, gear, throttle and shift lights come from the game's on-screen dial (Alexis's Cheat Engine work), so OutputBlaster isn't needed. Speed is the speedo's km/h; gear 1 to 6, -1 reverse.
* Each car's limiter (6500 to 8200) is read too, so with plugin 0.17.0 or later the rev limiter and engine effects follow every car; Max revs then only scales the rpm row.
* From the game's own code (12 November 2026), checked in her recordings: `brake`, `steer` (+ right), the race clock (`race_clock`, the TT on screen), `racing` (Car_in_race: GO to the finish line, off while paused and at TIME OVER), `lap`, `final_lap`, `lap_line`. Every other common value reads 0 outside a race.
* `position` and `leader` from the HUD's position list, and the unticked `game_mode` (7 Championship, 8 Quick Race), are from the game's code (16 November 2026) and not yet read in a recording. Time left and checkpoints are still to find (a Cheat Engine pointer scan).
* **Checked:** a recording of 3 November 2026, with USB capture; the dial values (speed, revs, limiter, gear, throttle) in Cheat Engine and seven recordings (4 November 2026); the race rows from the game's code in two recordings of 12 November 2026 (GO, the pause, TIME OVER, three laps to the finish line, the attract mode) and her answers (the TT on screen, lap times).

<a id="gticlub3"></a>
### GTI Club Supermini Festa (`GTICLUB3`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `gti3japkey.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_position`, `TPTelemetry.Car_lap`, `TPTelemetry.Car_laps_total`, `TPTelemetry.Car_time_left`, `TPTelemetry.Car_lap_time` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_select_up`, `TPTelemetry.Lamp_select_down`, `TPTelemetry.Lamp_select_left`, `TPTelemetry.Lamp_select_right`, `TPTelemetry.Lamp_action`, `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_checkpoint`, `TPTelemetry.Lamp_final_lap` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 160 and Max revs 7500 set.
* Speed, revs, gear, position, laps, lap times, time left, race state, surfaces and hits read the game's memory (from its code, starting from Alexis's Cheat Engine table, and checked in her recording of 8 November 2026); no OutputBlaster needed.
* `speed` is the speedo's km/h (km/h even with the display set to mph); `true_speed` is the car's real km/h. `rpm` is the engine's revs, `rpm_tacho` the tacho's. Max revs 7500 is the game's own limiter; Max speed 160 km/h is a little under the 163 km/h reached in the recording.
* The game's vibration jolts tell the events apart: `landing` after a jump, `car_hit`, `wall_hit` and `crash`; `hit` sizes walls and cars by the speed lost. `kerb` counts the wheels on a kerb. None of these has a side.
* The car values read 0 outside a race (the game leaves its car pointer stale between races), and `in_race` ends at the finish line.
* `checkpoint`, `leader`, `final_lap` and `hurry` (last 10 s) are there for lamps.
* **Checked:** found in the game's code from Alexis's Cheat Engine table, and checked in her recording of 8 November 2026 (intermediate course, manual, three laps); the time left still to check.

<a id="h2overdrive"></a>
### H2Overdrive (`H2OVERDRIVE`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `sdaemon.exe`.
* **OutputBlaster needed** for: `boost_lamp`, `digit1speed`, `digit2speed`, `digit3speed`, `digit4speed`, `keypad`, `speedo`, `throttle1`, `throttle2`, `throttle3`. Without it those rows read 0 and the rest work.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_boost` (Common_Lamps.md).
* The boost lamp, keypad, throttle and speedo digits come from OutputBlaster; the other outputs read memory.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="harley"></a>
### Harley-Davidson: King of the Road (`HARLEY`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_leader` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="hummer"></a>
### Hummer (`HUMMER`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_white` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="hummerextreme"></a>
### Hummer Extreme Edition (`HUMMEREXTREME`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_white` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="hydrothunder"></a>
### Hydro Thunder (`HYDROTHUNDER`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `HYDRO_x64.exe`.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_time_left` (besides speed, revs and gear; Common_Dashboard.md).
* The patched builds are `HYDRO_x64_x64.exe` and `HYDRO_x64_x86.exe`: change Process to match yours.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="id4"></a>
### Initial D Arcade Stage 4 (export) (`ID4`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_select_up`, `TPTelemetry.Lamp_select_down`, `TPTelemetry.Lamp_select_left`, `TPTelemetry.Lamp_select_right` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="id4jp"></a>
### Initial D Arcade Stage 4 (Japan) (`ID4JP`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **OutputBlaster needed** for: `lampselectdown`, `lampselectleft`, `lampselectright`, `lampselectup`, `lampstart`, `lampview1`, `ob_ffb`. Without it those rows read 0 and the rest work.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_select_up`, `TPTelemetry.Lamp_select_down`, `TPTelemetry.Lamp_select_left`, `TPTelemetry.Lamp_select_right` (Common_Lamps.md).
* OutputBlaster only knows the export version's addresses, so the lamps come from it.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="id5"></a>
### Initial D Arcade Stage 5 (`ID5`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_select_up`, `TPTelemetry.Lamp_select_down`, `TPTelemetry.Lamp_select_left`, `TPTelemetry.Lamp_select_right` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="id6"></a>
### Initial D Arcade Stage 6 AA (`ID6`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `InitialD6_GLW_RE_SBUU_dump.exe`.
* **TeknoParrot shared memory:** force feedback rows read it, so they work as soon as TeknoParrot runs the game.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_brake` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_select_up`, `TPTelemetry.Lamp_select_down`, `TPTelemetry.Lamp_select_left`, `TPTelemetry.Lamp_select_right` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 220 and Max revs 8140 set.
* Force feedback from TeknoParrot's shared memory, which works with any process name.
* Speed, revs, gear, pedals, race state and the car's events (walls and guard rails by side, the other car, the gutter, landings, road joints, rumble strips) read the memory of **v1.2** (the exe's own code, 8 November 2026). Process is set to `InitialD6_GLW_RE_SBUU_dump.exe`: change it if yours is named differently. On v1.0 those rows read 0.
* `speed` is the speedo's km/h and `rpm` the revs on screen; `rpm_tacho` is the revs times a factor for each car, not what the screen shows. Max revs 8140 is the limiter of the R32 GT-R and the AE86 Trueno; Max speed 220 km/h (the Trueno reached 215).
* `hit` is the start of a contact with a wall, guard rail or the other car (a grind along the other car counts once); `gutter` (Akina) and `leaves` (Irohazaka) are wheels off the edge of the road and feed Car_off_road; ripple strips come from the game's vibration, landings from the start of its landing flag. The other car's side isn't known.
* `drift_angle` is the physics' own drift angle in degrees (+ a right-hand drift, - left; checked in two drifting recordings). Car_drift (plugin 0.18.0) is the angle (5 to 50 degrees) times the speed (20 to 120 km/h), and Car_grip_loss follows it.
* Car_in_race starts in the rolling start's countdown once the engine runs (`countdown_live`), so the engine effects start with the engine; `in_race` itself starts with the race clock.
* The lamps read memory on both versions (the addresses OutputBlaster uses for each), so OutputBlaster isn't needed.
* **Checked:** found in the v1.2 exe's code (8 November 2026), and checked in Alexis's recordings of 9 November 2026 (story prologue in an R32 GT-R and an AE86 Trueno, manual; Irohazaka time trial in a Civic, automatic; USB capture on): speed, revs, gear, brake, walls, guard rails, gutters, leaves, ripple strips, landings, the other car, lamps.

<a id="id7"></a>
### Initial D Arcade Stage 7 AAX (`ID7`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `InitialD7_GLW_RE_SBYD.exe`.
* **TeknoParrot shared memory:** force feedback rows read it, so they work as soon as TeknoParrot runs the game.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_select_up`, `TPTelemetry.Lamp_select_down`, `TPTelemetry.Lamp_select_left`, `TPTelemetry.Lamp_select_right` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="id8"></a>
### Initial D Arcade Stage 8 Infinity (`ID8`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `InitialD8_GLW_RE_SBZZ_redumped_.exe`.
* **TeknoParrot shared memory:** force feedback rows read it, so they work as soon as TeknoParrot runs the game.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_select_up`, `TPTelemetry.Lamp_select_down`, `TPTelemetry.Lamp_select_left`, `TPTelemetry.Lamp_select_right` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="id0v131"></a>
### Initial D Arcade Stage Zero v1.31 (`ID0V131`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `InitialD0_DX11_Nu.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_select_up`, `TPTelemetry.Lamp_select_down`, `TPTelemetry.Lamp_select_left`, `TPTelemetry.Lamp_select_right` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="id0v211"></a>
### Initial D Arcade Stage Zero v2.11 (`ID0V211`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `InitialD0_DX11_Nu.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_select_up`, `TPTelemetry.Lamp_select_down`, `TPTelemetry.Lamp_select_left`, `TPTelemetry.Lamp_select_right` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="id0v230"></a>
### Initial D Arcade Stage Zero v2.30 (`ID0V230`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `InitialD0_DX11_Nu.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture:** not needed; the game's own values cover the effects.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_time_left`, `TPTelemetry.Car_race_time`, `TPTelemetry.Car_brake`, `TPTelemetry.Car_steer`, `TPTelemetry.Car_gap` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_checkpoint` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 220 and Max revs 8140 set.
* Every row (the force feedback too) reads the game's own memory, so it works the same whether the game runs under segatools or TeknoParrot (both run `InitialD0_DX11_Nu.exe`); TeknoParrot's shared memory isn't used. The rows are for the v2.30 exe whose MD5 is 2e506fe5e3d36fc4eff0d44389f4757b: on another build they may read nothing.
* Speed (the speedo), revs (the rev counter, manual or automatic: an automatic's counter shows 0.885 of the engine value), gear, pedals, steering, the drift angle, the race and car states, game mode, race clock (TT), time left (RT), checkpoints, the gap to the rival and the car's events (walls and guard rails by side, the other car, the gutter, leaves, landings) come from the game's own code, the same engine as Initial D 6. Ripple strips come from the game's own vibration (level 5), so Irohazaka's painted strips don't count.
* Max speed 220 km/h (the Trueno reached 203); Max revs 8140, the Trueno's limiter (the RX-7's is about 7,070). Car_drift uses ID6's weighting.
* Effects run from GO to your finish line, not in the attract demo, a replay, a pause or the tutorial's how-to demos; every common value but Car_in_race reads 0 outside a race. Car_cornering comes from the steering and speed, not the game's weak wheel force.
* Lamps made from the race values (OutputBlaster has no v2.30 entry): `lampleader` while you lead the rival (all race in time attack, where you run alone), `lampcheckpoint` for 2 s at each Extended Time!.
* **Checked:** found in the v2.30 exe's code (16 November 2026), and checked in Alexis's recordings of 16 November 2026 (the story's intro race in an AE86 Trueno, manual, with the tutorial's how-to demos; an Irohazaka time attack in a Savanna RX-7, automatic; USB capture on): speed, revs, gear, steering and drift signs, the race clock, checkpoints, places, contact with the other car, walls and guard rails by side, gutter, leaves, jumps and kerb drops, ripple strips. and the automatic's rev counter (a Silvia story race on Akina Lake, five readings).

<a id="idtas4"></a>
### Initial D The Arcade Season 4 v2.5 (`IDTAS4`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `GameProject-Win64-Shipping.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_time_left` (besides speed, revs and gear; Common_Dashboard.md).
* The force address isn't known for this build: timer only.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="idtas5"></a>
### Initial D The Arcade Season 5 v3.10 (`IDTAS5`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `GameProject-Win64-Shipping.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_time_left` (besides speed, revs and gear; Common_Dashboard.md).
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="idtas5v321"></a>
### Initial D The Arcade Season 5 v3.21 (ARCADEZONE.CN) (`IDTAS5V321`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `GameProject-Win64-Shipping.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_time_left` (besides speed, revs and gear; Common_Dashboard.md).
* The force address isn't known for this build: timer only.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="idta21"></a>
### Initial D The Arcade v2.1 (Season 3) (`IDTA21`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `GameProject-Win64-Shipping.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_time_left` (besides speed, revs and gear; Common_Dashboard.md).
* The force address isn't known for this build: timer only.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="idta"></a>
### Initial D The Arcade v2.31 (`IDTA`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `GameProject-Win64-Shipping.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture:** not needed; the game's own values cover the effects.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_time_left` (besides speed, revs and gear; Common_Dashboard.md).
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="kodrive"></a>
### KO Drive (`KODRIVE`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `M-DriveR_RingWide.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mkgpdxusa"></a>
### Mario Kart Arcade GP DX (USA) (`MKGPDXUSA`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `MK_AGP3_FINAL.exe`.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_position`, `TPTelemetry.Car_lap`, `TPTelemetry.Car_laps_total`, `TPTelemetry.Car_race_time` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_final_lap`, `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_green`, `TPTelemetry.Lamp_blue`, `TPTelemetry.Lamp_white`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 160 and Max revs 10000 set.
* For the USA version (MK_AGP3_FINAL.exe built 8 November 2016, 7,033,856 bytes). v1.10 and v1.18 run an exe of the same name: tick the profile for the version you run.
* OutputBlaster has no USA build, so the lamp rows read v1.18's lamp words where this version keeps them (its I/O block sits 0xCF880 higher). No OutputBlaster needed; they light in the menus and the race. The item lamp flashes at times in this version; `item_held` bridges the flashes.
* `force` here is the kart's sideways slide, which the FFB Arcade Plugin's Real mode sends to the wheel: near 0 driving straight. `drift_angle` gives it in degrees.
* The same rows and surfaces as v1.18 (see MKGPDX118), at this exe's addresses, checked in two races. Effects stop at the finish line (race state 7), though the FFB plugin's race flag stays on 2 s longer.
* Worked out from Alexis's USA exe, which she believes is a modified build that uses more memory. Its header carries the large-address flag (as her v1.18 exe's does), which moves nothing; if another USA exe reads nothing, its code differs and needs a look.
* **Checked:** the game's code (Alexis's MK_AGP3_FINAL.exe, USA, 11 November 2026) and her two recordings of 11 November 2026 (Bowser Jr cup courses 3 and 2, three laps each): speed, revs, steering, the race state and racing gate, drifts and their side and angle, glides, place, laps, race time, the courses' surfaces, the metal grilles, bomb blasts and item tumbles, hit sides, the item lamp (it flashes), the lamp words in menus and race.

<a id="mkgpdx110"></a>
### Mario Kart Arcade GP DX v1.10 (`MKGPDX110`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `MK_AGP3_FINAL.exe`.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_green`, `TPTelemetry.Lamp_blue`, `TPTelemetry.Lamp_white`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mkgpdx118"></a>
### Mario Kart Arcade GP DX v1.18 (`MKGPDX118`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `MK_AGP3_FINAL.exe`.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_position`, `TPTelemetry.Car_lap`, `TPTelemetry.Car_laps_total`, `TPTelemetry.Car_race_time`, `TPTelemetry.Car_steer` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_final_lap`, `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_green`, `TPTelemetry.Lamp_blue`, `TPTelemetry.Lamp_white`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 160 and Max revs 10000 set.
* `racing` (race state 6 with the FFB plugin's flag) gates the effects: on from GO to the finish line, off in the countdown, while the game drives you after the line, and in the attract demo (race state 6, but the FFB plugin's flag stays 0).
* `position` (updated once a second, as the HUD is), `laps_done`, `laps_total`, `lap`, `final_lap`, `leader` and `race_time` (seconds, the game's clock: 16 ms a frame, about 4% slower than real time) checked in a recording.
* `drift_angle` (+ right-hand) and `drift_strength` feed Car_drift; `airborne` is the kite glides and jumps (not the drift hops), `rumble_strip` the log strips, `item_held` the item button's lamp, `coins` the coins collected.
* `force` is the kart's slide (the sine of the drift angle), which the FFB Arcade Plugin sends the wheel, so Car_road_bump comes from landings, not force kicks.
* `terrain` codes are the game's surface kinds, shared by surfaces that look different (Alexis's names): 0 rebound-ace road (Mario cup), boost ramps (Bowser Jr cup), or in the air; 2 metal grille; 3 dirt road; 4 grassy verge; 5 checkerplate; 7 water; 8 wood (floorboards, platforms, ripple-strip logs); 9 carpet; 10 planked bridge, boost rings; 11 rebound-ace verge; 12 pavement; 13 jungle floor, striped glass; 14 sand; 15 cloud.
* Car_off_road: 1 on a verge (grass, rebound-ace) or sand, 0.5 on the planked bridge, 0.3 on wood; 0 on everything else. Car_rumble_strip: the log ripple strips and the metal grilles.
* `spin` covers spin-outs on the ground (a banana peel) and being thrown into the air spinning (items, a bomb blast); `knocked` adds bumps from behind and flips.
* `hit_side` (Car_impact_side) is -1 for a hit on the left, 1 on the right, 0 when it can't tell (hits from in front or behind, gentle bumps, hits in a drift or a spin).
* **Checked:** the game's code (Alexis's MK_AGP3_FINAL.exe, 9 November 2026) and her recording of 11 November 2026 (a 100cc Grand Prix race, two laps): speed, revs, steering, the race state, drifts and their side and angle, drift hops, boosts, the kite glides, landings, the log ripple strips, the course's surfaces, water, hits and their side, spin-outs, coins, the item lamp; the attract demo checked to give no effects. Her second recording (11 November 2026, Mario cup course 1, four laps): place, laps, race time, the course's surfaces, item flips and a banana spin, hit sides. Drift meter stage and the LED colours still to find.

<a id="motogp"></a>
### MotoGP (2015) (`MOTOGP`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_brake` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="outrun2sp"></a>
### OutRun 2 SP SDX (`OUTRUN2SP`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **USB capture adds** road bumps, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_rev_limit_rpm`, `TPTelemetry.Car_time_left`, `TPTelemetry.Car_race_time`, `TPTelemetry.Car_lap_time`, `TPTelemetry.Car_steer` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_checkpoint`, `TPTelemetry.Lamp_shift`, `TPTelemetry.Lamp_warning` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 280 and Max revs 9300 set.
* Force feedback comes from the FFB Arcade Plugin's hook ("Real" mode, GameId 35), so the profile reads none. With **USB capture** on, the plugin takes the side of wall and traffic hits from the wheel force when the game gives none, and road bumps (the sand divider, say). Cornering stays 0: the hook sends no steering force.
* Manual or automatic both work; `transmission` says which.
* Since 11 November 2026 the profile also reads the game's own variables, found by name in its program (`jennifer`): the speedo's km/h (`speed_kmh`), the drift state and rear slip angle (`Car_drift`), slipstream, the SHIFT UP warning, crash motions, the stage, race and stage clocks, and the main sequence, so `Car_in_race` (`racing`) runs from GO to the finish line or time up, and not in the attract mode (checked 11 November 2026). `Car_speed` is the speedo's km/h (Max speed 280). `Car_drift` is full at 75 degrees here (OutRun's drifts are deep); `shift_light` lights at 8,270 RPM, as the rev dial's redline light did on four cars. `Car_speed`, `Car_rpm`, `Car_gear` and `Car_accel_g` read 0 outside a race (attract demo, menus).
* Car hits and their side come from the game itself (`car_hit`, `car_side`), so USB capture is no longer needed for traffic-hit sides. `game_mode`: 0 Time Attack, 1 OutRun, 2 Heart Attack. Heart Attack: `hearts` (the hearts won) and `challenge_won`. Unticked raw rows (`hit_dir`, `hit_box1` to `hit_box4`, `rev_limit`, `rev_1030`, `course_event`) stay unticked; the recorder keeps them.
* **Checked:** recordings of 2 and 3 November 2026 (the last with USB capture), and the rows from the game's own code in a recording of 11 November 2026 and her answers (GO to the finish line, the speedo, stages, crash motions and what they are, drift sign, slipstream, the fork arrow), and three of 12 November (car hits and their side without USB, the modes, time up, attract mode).

<a id="rtuned"></a>
### R-Tuned: Ultimate Street Racing (`RTUNED`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **USB capture adds** road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_boost`, `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_blue` (Common_Lamps.md).
* The FFB Arcade Plugin switches this game's force feedback on by writing to its memory. This plugin only reads, so if the values stay at 0, run the FFB Arcade Plugin as well.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="rf3d"></a>
### Road Fighters 3D (`RF3D`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `TeknoMacaw.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="segaracetv"></a>
### Sega Race TV (`SEGARACETV`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_boost`, `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_blue` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="segaracingclassic"></a>
### Sega Racing Classic (`SEGARACINGCLASSIC`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `d1a.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4`, `TPTelemetry.Lamp_leader` (Common_Lamps.md).
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="sr3"></a>
### Sega Rally 3 (`SR3`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `Rally.exe`.
* **TeknoParrot shared memory:** force feedback rows read it, so they work as soon as TeknoParrot runs the game.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_position`, `TPTelemetry.Car_lap`, `TPTelemetry.Car_laps_total`, `TPTelemetry.Car_time_left`, `TPTelemetry.Car_race_time` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_checkpoint`, `TPTelemetry.Lamp_final_lap`, `TPTelemetry.Lamp_warning` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 125 and Max revs 7100 set.
* Speed is in mph, whatever the screen shows.
* From the game's own code (Rally.exe, 12 November 2026), checked in a recording of 16 November 2026: `player_state` (0 menus, 1 intro, 2 countdown, 3 racing, 4 finished, 5 post race), `racing` (Car_in_race: GO to the finish line), `checkpoint` (2 s after each checkpoint and lap line), `lap`, `laps_total`, `final_lap`, `position`, `leader`, `wrong_way`. Every other common value reads 0 outside a race.
* `rt` is the time left as the screen shows it (RT; the screen cuts off the decimals) and `race_time` the TT from GO. `time_left` is the time given (70 s at GO, +25 at a checkpoint, +30 at a lap line); in Quick Race RT is that less TT, checked against Alexis's readings.
* **Checked:** a recording of 2 November 2026, with USB capture; four of 12 November (attract mode, the jumps, hits she named) and one of 16 November 2026 with the rows from the game's code (the player state from the attract mode to the results, checkpoints, lap lines, laps, position, WRONG WAY).

<a id="swdc"></a>
### Sega World Drivers Championship (`SWDC`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `Todoroki-Win64-Shipping.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture:** not needed; the game's own values cover the effects.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_position`, `TPTelemetry.Car_lap`, `TPTelemetry.Car_race_time`, `TPTelemetry.Car_brake` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_checkpoint` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 230 and Max revs 12200 set.
* For version 2.30 (`version` says which it found). Needs plugin 0.19.0 or later (with its helper): the rows from your car's record use its indexed offsets (`[-E80]*578`), which older plugins can't read.
* Your car's record in the game's own data (its exe, v2.30), found by your car number (`player_no`; `player_ok` 1 when it reads): race state, the speedo's km/h, gear, brake, place, lap, sector, race clock, position and heading.
* Values reach SimHub only from the rolling start (race state 2) to your finish line: 0 in the countdown, after the line, in the menus and the attract mode (Alexis, 19 November 2026). The force feedback rows still show what the game sends the wheel.
* Revs are Alexis's table's `revs` (the record's own revs aren't the engine's); `speed2`/`gear2` stay to compare.
* `position` is your class place, as the screen and results show it (`overall` among every car).
* Car contacts and wall hits come from the sideways shove the game gives the car (`jolt`, `car_contact`), with their side; head-on hits from the speed falling at more than 4 G. The grass verge (Car_off_road) and solid kerbs (Car_rumble_strip) come from the game's own vibration command. Car_drift is fitted to Alexis's six slides of 19 November 2026.
* **Checked:** four recordings of 3 November 2026 (version 2.30), one with USB capture; the rows from the game's own data in her race of 19 November 2026 (SWDC-11).

<a id="sonicasr"></a>
### Sonic & Sega All-Stars Racing (`SONICASR`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `game.exe`.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_green`, `TPTelemetry.Lamp_blue` (Common_Lamps.md).
* The FFB Arcade Plugin switches this game's force feedback on, and OutputBlaster its outputs, by writing to its memory. This plugin only reads, so if values or lamps stay at 0, run the FFB Arcade Plugin (or OutputBlaster) as well.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="srg"></a>
### Storm Racer G (`SRG`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `racing.exe`.
* **TeknoParrot shared memory:** force feedback rows read it, so they work as soon as TeknoParrot runs the game.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* Force feedback from TeknoParrot's shared memory; `speed` and `racing` read `racing.exe`.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="fnfdrift"></a>
### The Fast and the Furious Drift (`FNFDRIFT`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `sdaemon.exe`.
* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="fnfsb2"></a>
### The Fast and the Furious Super Bikes 2 (`FNFSB2`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `sdaemon.exe`.
* **OutputBlaster needed** for: `dash`, `fog_light_1`, `lampleader`, `lampstart`, `lampview1`, `lampview2`, `ledrearcover`, `wooferledblue`. Without it those rows read 0 and the rest work.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_time_left` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_leader` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="fnfsc"></a>
### The Fast and the Furious SuperCars (`FNFSC`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `sdaemon.exe`.
* **No `car_` rows for the effects:** the game gives no speed, revs or hits here, so most TP SimHub effects stay idle without USB capture.
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="wackyraces"></a>
### Wacky Races (`WACKYRACES`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `Launcher.exe`.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="wmmt3dxp"></a>
### Wangan Midnight Maximum Tune 3 DX+ (`WMMT3DXP`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `BudgieLoader.exe`.
* **TeknoParrot shared memory:** force feedback rows read it, so they work as soon as TeknoParrot runs the game.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_rev_limit_rpm`, `TPTelemetry.Car_time_left`, `TPTelemetry.Car_race_time`, `TPTelemetry.Car_brake`, `TPTelemetry.Car_steer`, `TPTelemetry.Car_gap` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_checkpoint`, `TPTelemetry.Lamp_shift` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 220 and Max revs 10000 set.
* The memory rows read the game's own variables at the fixed addresses the game itself uses (it is a Linux program that BudgieLoader maps where it was built to run), so TeknoParrot updates can't move them, unlike the old cheat-table rows. `rpm` is the engine's revs (Max revs 10000, this car's limiter); `tacho` is what the dial shows.
* Effects run from the countdown (the driver's view) to the finish line, not in the story mode's opening shot or a pause. Car and traffic hits come from the game's own contact strength. Per-car limiter (`rev_limit`, so `Car_rpm_frac`), turbo boost against the car's own full boost (`Car_boost`), throttle (`Car_throttle`), the slip angle (`Car_drift`) and the load on the tyres (`Car_airborne`) come from the game too.
* **Checked:** the force rows (joints, hits, walls, slides) in recordings of 29 October and 1 November 2026. The memory rows read the game's own variables, found in its code (Alexis's `main`, 11 November 2026), and were checked in her recording of 11 November 2026 (18:36 and 20:15): speed, gear, the dial, race state from the countdown to the line, time left, rival gap, slide and steering signs, the jump, car hits. The side of car hits is still to work out.

<a id="wmmt5"></a>
### Wangan Midnight Maximum Tune 5 (`WMMT5`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `wmn5r.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_race_time` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_action`, `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_green`, `TPTelemetry.Lamp_blue`, `TPTelemetry.Lamp_white`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="wmmt5dx"></a>
### Wangan Midnight Maximum Tune 5DX (`WMMT5DX`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `wmn5r.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_race_time` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_action`, `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_green`, `TPTelemetry.Lamp_blue`, `TPTelemetry.Lamp_white`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="wmmt5dxp"></a>
### Wangan Midnight Maximum Tune 5DX+ (`WMMT5DXP`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `wmn5r.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_position`, `TPTelemetry.Car_race_time`, `TPTelemetry.Car_brake` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_action`, `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_green`, `TPTelemetry.Lamp_blue`, `TPTelemetry.Lamp_white`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 230 and Max revs 8900 set.
* Uses MasterRaver's Outputs script values (`speed2`, `rpm2`, `race_time2`) where they're better; nothing extra to run.
* Max revs 8900 suits `rpm2`; the limiter varies by car, so change it to suit yours.
* **Checked:** recordings of 29 October, 1 and 3 November 2026.

<a id="wmmt6"></a>
### Wangan Midnight Maximum Tune 6 (`WMMT6`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `wmn6r.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_race_time` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_action`, `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_green`, `TPTelemetry.Lamp_blue`, `TPTelemetry.Lamp_white`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="wmmt6r"></a>
### Wangan Midnight Maximum Tune 6R (`WMMT6R`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `wmn6r.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_race_time` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_action`, `TPTelemetry.Lamp_red`, `TPTelemetry.Lamp_green`, `TPTelemetry.Lamp_blue`, `TPTelemetry.Lamp_white`, `TPTelemetry.Lamp_marquee` (Common_Lamps.md).
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="wmmt6rr"></a>
### Wangan Midnight Maximum Tune 6RR (`WMMT6RR`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `wmn6r.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_race_time` (besides speed, revs and gear; Common_Dashboard.md).
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="wmmt6rrp"></a>
### Wangan Midnight Maximum Tune 6RR Plus v4.00.13 (`WMMT6RRP`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `wmn6r.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture adds** hits, road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* The force address isn't known for this build. MasterRaver's Outputs script for 6RR is on its way.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="snocross"></a>
### Winter X Games SnoCross (`SNOCROSS`)

* **Runs in:** TeknoParrot ([common steps](#steps-teknoparrot)). **Process:** `sdaemon.exe`.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

## Flycast games

<a id="fly18wheeler"></a>
### 18 Wheeler: American Pro Trucker (Flycast) (`FLY18WHEELER`)

* **Runs in:** Flycast ([common steps](#steps-flycast)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="flyclubkart"></a>
### Club Kart (Flycast) (`FLYCLUBKART`)

* **Runs in:** Flycast ([common steps](#steps-flycast)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="flyftspeed"></a>
### Faster Than Speed (Flycast) (`FLYFTSPEED`)

* **Runs in:** Flycast ([common steps](#steps-flycast)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="flyf355"></a>
### Ferrari F355 Challenge (Flycast) (`FLYF355`)

* **Runs in:** Flycast ([common steps](#steps-flycast)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="flyinitd"></a>
### Initial D Arcade Stage (Flycast) (`FLYINITD`)

* **Runs in:** Flycast ([common steps](#steps-flycast)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="flyinitd2"></a>
### Initial D Arcade Stage Ver. 2 (Flycast) (`FLYINITD2`)

* **Runs in:** Flycast ([common steps](#steps-flycast)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="flyinitd3"></a>
### Initial D Arcade Stage Ver. 3 (Flycast) (`FLYINITD3`)

* **Runs in:** Flycast ([common steps](#steps-flycast)). **Process:** `flycast.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture:** not needed; the game's own values cover the effects.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_rev_limit_rpm`, `TPTelemetry.Car_lap`, `TPTelemetry.Car_time_left`, `TPTelemetry.Car_race_time`, `TPTelemetry.Car_steer`, `TPTelemetry.Car_gap` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_checkpoint` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 205 and Max revs 9000 set.
* Reads the game's own memory inside `flycast.exe`: speed (km/h, the speedo), revs, gear, ADVANTAGE, throttle, steering and each car's rev limit from the player's car; time left (RT), race clock (TT) and lap through the game's pointer to the race (**plugin 0.18.2 and helper 0.17.1**: older ones show an error on those rows); what each wheel is on (ripple strips, gutters and kerbs, grooved concrete); contacts with their side and knock; the drift angle from the car's heading against its travel. Car_in_race runs from GO to the finish line or time up, and every other Car_ value is 0 outside it.
* `lampleader` (from GO, ahead of or level with the rival; lit through a time trial; held after the line until the race is cleared) and `lampcheckpoint` (2 s when the time left jumps up) are made from memory, not cabinet outputs, so they work with Flycast's outputs off.
* **Broadcast Digital Outputs is optional.** Only `ffb_raw` and the rows made from it (`ffb_cmd`, `ffb_str`, `force`, `spring`, `vibration`, `force_abs`, `force_smooth`, `force_kick`, and Car_road_bump and Car_vibration) and `lamp0` to `lamp7` and `lamp_bits` use it. With the FFB Arcade Plugin's files in Flycast's folder the game froze in the menus with outputs on (Alexis, 17 November 2026): remove them, or leave outputs off.
* The memory rows are for Flycast v2.7-1-g44e4c7b50 (flycast.exe MD5 d8db8f697e26e5384a186eb2c8b79289; from 19 November 2026, before which they were for v2.5-219-g27a913fc0) and the export game (`initdv3e`). Another Flycast build keeps its RAM pointer elsewhere, and every memory row then reads nothing: `ram_probe` shows it at once (a steady 3509307139 is right; 0 or an error means the pointer has to be found again, as the FLYINITD3 notes say).
* **Checked:** found in Flycast's emulated RAM with three save states (17 November 2026), and checked in Alexis's recordings of 17 November 2026 (Civic, GT-R, RX-7, Trueno and others; Akina Lake, Irohazaka, Akagi, Myogi; story mode and time trial, manual and automatic; through the finish line and time up): speed, revs, gear, ADVANTAGE, throttle and steering against USB, rev limits, time left, race clock, laps, both checkpoint lamps, the leader lamp, Car_in_race from GO to the line, ripple strips, gutters, contact sides, the drift angle's sign and Car_drift's size.

<a id="flyinitdcy"></a>
### Initial D Arcade Stage Ver. 3 Cycraft (Flycast) (`FLYINITDCY`)

* **Runs in:** Flycast ([common steps](#steps-flycast)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="flymaxspeed"></a>
### Maximum Speed (Flycast) (`FLYMAXSPEED`)

* **Runs in:** Flycast ([common steps](#steps-flycast)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="flysgdrvsim"></a>
### Sega Driving Simulator (Flycast) (`FLYSGDRVSIM`)

* **Runs in:** Flycast ([common steps](#steps-flycast)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="flykingrt66"></a>
### The King of Route 66 (Flycast) (`FLYKINGRT66`)

* **Runs in:** Flycast ([common steps](#steps-flycast)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

## MAME games

<a id="mamecbombers"></a>
### Cadash Bombers / Chase Bombers (MAME) (`MAMECBOMBERS`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** hits, road bumps, cornering from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamecalspeed"></a>
### California Speed (MAME) (`MAMECALSPEED`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamecischeat"></a>
### Cisco Heat (MAME) (`MAMECISCHEAT`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** hits, road bumps, cornering from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamecrusnusa"></a>
### Cruis'n USA (MAME) (`MAMECRUSNUSA`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamecrusnwld"></a>
### Cruis'n World (MAME) (`MAMECRUSNWLD`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamedblaxle"></a>
### Double Axle (MAME) (`MAMEDBLAXLE`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** hits, road bumps, cornering from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamef1gpstar"></a>
### F1 Grand Prix Star (MAME) (`MAMEF1GPSTAR`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** hits, road bumps, cornering from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamehyprdriv"></a>
### Hyperdrive (MAME) (`MAMEHYPRDRIV`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mameoffroadc"></a>
### Off Road Challenge (MAME) (`MAMEOFFROADC`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mameoutrun"></a>
### Out Run (MAME) (`MAMEOUTRUN`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mameorunners"></a>
### OutRunners (MAME) (`MAMEORUNNERS`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** hits, road bumps, cornering from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamepdrift"></a>
### Power Drift (MAME) (`MAMEPDRIFT`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamesfrush"></a>
### San Francisco Rush (MAME) (`MAMESFRUSH`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamesf2049"></a>
### San Francisco Rush 2049 (MAME) (`MAMESF2049`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamesfrushrk"></a>
### San Francisco Rush: The Rock (MAME) (`MAMESFRUSHRK`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mametoutrun"></a>
### Turbo Out Run (MAME) (`MAMETOUTRUN`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** hits, road bumps, cornering from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamevaportrx"></a>
### Vapor TRX (MAME) (`MAMEVAPORTRX`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="mamevr"></a>
### Virtua Racing (MAME) (`MAMEVR`)

* **Runs in:** MAME ([common steps](#steps-mame)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

## Model 2 Emulator games

<a id="m2daytona"></a>
### Daytona USA (Model 2 Emulator) (`M2DAYTONA`)

* **Runs in:** Model 2 Emulator ([common steps](#steps-model-2-emulator)). **Process:** `emulator_multicpu.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_position`, `TPTelemetry.Car_lap`, `TPTelemetry.Car_time_left`, `TPTelemetry.Car_race_time`, `TPTelemetry.Car_lap_time` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4`, `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_checkpoint` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 340 and Max revs 8500 set.
* The emulator's own `SCRIPTS\daytona.lua` moves the lamps to RAM+824, so keep it: the lamp rows rely on it.
* `speed` is the speedo's km/h and `rpm` the tacho's revs (8500 on the limiter).
* `gear` works with manual and automatic gears; it keeps the last gear through neutral.
* `checkpoint` is 1 for the 2 s TIME EXTENSION shows after each lap, for a lamp. Laps, lap time and last lap are there too.
* Grass and kerbs come from the surface under each wheel, sliding from the tyre squeal, wall hits and side-on contact from `hit`; rear-end bumps only show in the wheel force.
* **Checked:** found in Alexis's RAM logs of 8 November 2026 (three laps with manual gears, and a run with automatic gears) against her readings and marks; the time extensions match her TP Telemetry recordings of that day.

<a id="m2indy500"></a>
### Indianapolis 500 (Model 2 Emulator) (`M2INDY500`)

* **Runs in:** Model 2 Emulator ([common steps](#steps-model-2-emulator)). **Process:** `emulator_multicpu.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4`, `TPTelemetry.Lamp_leader` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="m2overrev"></a>
### Over Rev (Model 2 Emulator) (`M2OVERREV`)

* **Runs in:** Model 2 Emulator ([common steps](#steps-model-2-emulator)). **Process:** `emulator_multicpu.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4`, `TPTelemetry.Lamp_leader` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="m2srally"></a>
### Sega Rally Championship (Model 2 Emulator) (`M2SRALLY`)

* **Runs in:** Model 2 Emulator ([common steps](#steps-model-2-emulator)). **Process:** `emulator_multicpu.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_position`, `TPTelemetry.Car_time_left`, `TPTelemetry.Car_lap_time` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4`, `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_checkpoint` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 240 and Max revs 8800 set.
* For the `srallyc` romset (Sega Rally Championship): the other versions may keep their values elsewhere.
* Max revs is the limiter, 8800, where the tacho reads 8k; `rpm_tacho` has the tacho's figure.
* `checkpoint` is 1 for a second at each time extension checkpoint, and `leader` is 1 while you lead: both for lamps.
* Jumps come from the wheels on the ground (`wheels_down`), sliding from the rear tyre's slip, the grass verge from the surface under each wheel, wall and car hits (with their side) from `hit`.
* The lamp rows read the emulator's copy of the game's lamp port (exe+174CF0), so no script or patch is needed. Only `lampview3` has lit so far (blinking from coin-up), never a lead lamp, so use `leader` (1 while you're in 1st) for one.
* **Checked:** found in Alexis's RAM logs of 8 November 2026 (srallyc: a championship run, and Forest practice with automatic gears) against her readings and marks, and checked in two TP Telemetry recordings that day (the second with this profile).

<a id="m2stcc"></a>
### Sega Touring Car Championship (Model 2 Emulator) (`M2STCC`)

* **Runs in:** Model 2 Emulator ([common steps](#steps-model-2-emulator)). **Process:** `emulator_multicpu.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_lap`, `TPTelemetry.Car_time_left`, `TPTelemetry.Car_race_time` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4`, `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_checkpoint` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 320 and Max revs 12900 set.
* The lamp rows read the emulator's copy of the game's lamp port (exe+174CF0), as the STCC build of OutputBlaster does: `lampleader` is the leader lamp. No script or patch needed. The regular OutputBlaster build reads RAM+824, which STCC doesn't use.
* Max speed 320 and Max revs 12900 are set (rpm is the engine's own revs). Top speed depends on the car (278 and 335 km/h seen). `speed_kmh`, `rpm_tacho` and `rpm_display` are the screen's own figures.
* Kerbs and grass come from the surface under each wheel (`surfaces`), sliding from the rear tyres' slip angle, jumps from `air_frames`, wall hits from `wall_hit` (no side) plus the wheel force.
* `checkpoint` is 1 while TIME EXTENDED is on screen, for a lamp.
* **Checked:** found in Alexis's RAM logs of 5 and 6 November 2026 against her readings from video, and checked in her TP Telemetry recording of 6 November 2026 (qualifying lap and a two-lap race).

<a id="m2sgt24h"></a>
### Super GT 24h (Model 2 Emulator) (`M2SGT24H`)

* **Runs in:** Model 2 Emulator ([common steps](#steps-model-2-emulator)). **Process:** `emulator_multicpu.exe`.
* **USB capture:** not needed; the game's own values cover the effects.
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4`, `TPTelemetry.Lamp_leader` (Common_Lamps.md).
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

## Supermodel games

<a id="smdaytona2"></a>
### Daytona USA 2 (Supermodel) (`SMDAYTONA2`)

* **Runs in:** Supermodel ([common steps](#steps-supermodel)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="smdayto2pe"></a>
### Daytona USA 2 Power Edition (Supermodel) (`SMDAYTO2PE`)

* **Runs in:** Supermodel ([common steps](#steps-supermodel)). **Process:** `supermodel.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture:** not needed; the game's own values cover the effects.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_rev_limit_rpm`, `TPTelemetry.Car_position`, `TPTelemetry.Car_lap`, `TPTelemetry.Car_time_left`, `TPTelemetry.Car_race_time`, `TPTelemetry.Car_lap_time`, `TPTelemetry.Car_brake`, `TPTelemetry.Car_steer` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4`, `TPTelemetry.Lamp_leader` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 350 and Max revs 8500 set.
* Reads the game's own memory inside `supermodel.exe` (Supermodel 0.4-dev, git 0b82a98 of 16 November 2026, MD5 440c8330529f89714047740b9b45831e) for the `dayto2pe` ROM set (Daytona USA 2 Power Edition): speed (km/h, as on screen), revs, gear, the car class, throttle, brake, steering, time left (RT), race clock (TT), lap, lap times, position, pit stops, big crashes, touching other cars (how hard, no side), wheels against walls and the drift angle. Car_in_race runs from the time being set (on Beginner the rolling start, on Advanced and Expert the grid) to the finish line or time up, and every Car_ value is 0 outside it.
* Found in the emulator, then checked in Alexis's three recordings of 18 November 2026 (Advanced NORMAL manual, Expert HARD manual, Beginner SPECIAL automatic with a pit stop) and two on Mixed (EASY and SPECIAL, manual, on the limiter). Max revs 8500; Car_rpm is the rev counter's revs (wheelspin and clutch slip included) and Car_rpm_frac follows each car class's limiter (EASY and SPECIAL 7650, NORMAL and HARD 8500).
* **`-outputs=net` is optional:** only the force rows (`ffb_cmd` and those made from it, so Car_road_bump and Car_vibration) and the `lamp_` rows need it.
* `SMDAYTONA2` (the force and lamps only, for the original Daytona USA 2) is unchanged.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="smdirtdevils"></a>
### Dirt Devils (Supermodel) (`SMDIRTDEVILS`)

* **Runs in:** Supermodel ([common steps](#steps-supermodel)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** hits, road bumps, cornering from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="smeca"></a>
### Emergency Call Ambulance (Supermodel) (`SMECA`)

* **Runs in:** Supermodel ([common steps](#steps-supermodel)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="smlemans24"></a>
### Le Mans 24 (Supermodel) (`SMLEMANS24`)

* **Runs in:** Supermodel ([common steps](#steps-supermodel)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture:** not needed; the game's own values cover the effects.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="smscud"></a>
### Scud Race (Supermodel) (`SMSCUD`)

* **Runs in:** Supermodel ([common steps](#steps-supermodel)). **Process:** `supermodel.exe`, 64-bit (read through the 64-bit helper, plugin 0.9.0 or later).
* **USB capture:** not needed; the game's own values cover the effects.
* **Common dashboard values:** `TPTelemetry.Car_speed_kmh` and `TPTelemetry.Car_speed_mph`, `TPTelemetry.Car_rev_limit_rpm`, `TPTelemetry.Car_position`, `TPTelemetry.Car_lap`, `TPTelemetry.Car_time_left`, `TPTelemetry.Car_race_time`, `TPTelemetry.Car_lap_time`, `TPTelemetry.Car_brake`, `TPTelemetry.Car_steer` (besides speed, revs and gear; Common_Dashboard.md).
* **Common lamps:** `TPTelemetry.Lamp_start`, `TPTelemetry.Lamp_view1`, `TPTelemetry.Lamp_view2`, `TPTelemetry.Lamp_view3`, `TPTelemetry.Lamp_view4`, `TPTelemetry.Lamp_leader`, `TPTelemetry.Lamp_warning` (Common_Lamps.md).
* **Max speed / Max revs:** Max speed 350 and Max revs 9500 set.
* Reads the game's own memory inside `supermodel.exe` (Supermodel 0.4-dev, git 0b82a98 of 16 November 2026, MD5 440c8330529f89714047740b9b45831e): speed (km/h, as on screen), revs and each car's rev limit, gear, throttle, brake, steering, the race phase, time left (RT), race clock (TT), lap, lap times, position, the finishing place, pit stops, big crashes, wheels against walls, touching other cars, jumps (free fall), the wrong way and the drift angle from the car's heading against its travel. Car_in_race runs from GO (on Beginner from the rolling start's 3-2-1, on Medium and Expert from the grid, where only revs and gear run, with Car_throttle at 1 so the engine follows the revs) to the finish line or time up, and every other Car_ value is 0 outside it. Car_drift is set from Alexis's two F40 drifts (0.9 at 53.5 degrees, 0.65 at 42.5).
* **`-outputs=net` is optional:** only the force rows (`ffb_cmd` and those made from it, so Car_road_bump and Car_vibration) and the `lamp_` rows need it.
* Checked in Alexis's four recordings of 18 November 2026 (memory read, race gate, clocks, laps, checkpoints, gears, pedals and steering against USB, rev limits, jumps, the front wheels lifting over a crest, car contact by side, wall hits by side, REVERSE!). Driving along a grass verge is still read as the wrong side's wall. Max speed 350, Max revs 9500.
* Another Supermodel build may keep its RAM pointer elsewhere: `ram_probe` reading a steady 2087778982 means the memory rows read; 0 or an error means the pointer has to be found again (claude/SMSCUD-supermodel-20261118.md says how). With a fresh NVRAM the game stops at NETWORK BOARD NOT PRESENT: set LINK ID to SINGLE in the test menu's GAME ASSIGNMENTS.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

<a id="smsrally2"></a>
### Sega Rally 2 (Supermodel) (`SMSRALLY2`)

* **Runs in:** Supermodel ([common steps](#steps-supermodel)). **Process:** none (selected in the Game list).
* **Outputs must be switched on** in the emulator (common steps above), or nothing reads.
* **USB capture adds** rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.

## PC games

<a id="crazytaxi"></a>
### Crazy Taxi (`CRAZYTAXI`)

* **Runs in:** PC ([common steps](#steps-pc)). **Process:** **blank: set it to your exe**.
* **USB capture adds** road bumps, cornering, rumble (from rumble motors, so pads more than wheels) from the wheel force (plugin 0.15.0 or later), if the game's force feedback reaches your wheel. Optional.
* **Max speed / Max revs:** not set yet. Fill them in from a run to top speed and the redline, so speed and revs effects scale (README, Speed and revs).
* The PC release, not a TeknoParrot game: set Process to your copy's exe.
* **Checked:** not yet: a starting point from the FFB Arcade Plugin, OutputBlaster or a cheat table.
