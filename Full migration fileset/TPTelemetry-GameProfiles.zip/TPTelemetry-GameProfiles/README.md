# TP Telemetry game profiles

Ready-made profiles for the TP Telemetry SimHub plugin, kept apart from the plugin so either can be
updated without the other. Profiles are grouped by the emulator that runs the game, then each game
has its own folder holding the profile (`.json`) and, where there is one, the Cheat Engine table it
came from (`.CT`):

| Folder | Games | Prefixes |
|---|---|---|
| `Teknoparrot` | TeknoParrot games | the game's own (`WMMT5DXP`, `SR3`...) |
| `Flycast` | NAOMI, NAOMI 2 and Atomiswave games in Flycast | `FLY...` |
| `MAME` | games in MAME | `MAME...` |
| `Supermodel` | Model 3 games in Supermodel | `SM...` |
| `Model 2 Emulator` | Model 2 games in the Model 2 Emulator | `M2...` |
| `PC` | PC releases (Crazy Taxi) | the game's own |

A game that runs in more than one emulator gets a separate profile for each, with that emulator's
prefix, since the addresses and outputs differ: Daytona USA, for example, is `M2DAYTONA` in the
Model 2 Emulator. The folders don't matter to the plugin: import the `.json` from wherever it is.

**[Game_Setup.md](Game_Setup.md)** says how to set up each game: an index of every game, what each
needs (TeknoParrot, OutputBlaster, an emulator's outputs, USB capture) and what's been checked.
Start there.

**[Game_Formulas.md](Game_Formulas.md)** lists every game's formulas with what each row does: handy
for copying a pattern into another game. The formula language itself is in the plugin's
Formula_Reference.md.

## Installing a profile

In SimHub, open **TP Telemetry**, click **Import…** and choose the game's `.json`. Import
never overwrites a game you already have; if the prefix is taken, the imported copy gets a number
added (e.g. `WMMT3DXP2`).

**Updating to a newer pack:** because import never overwrites, select the old game in TP Telemetry,
click **Delete Game**, then import the new `.json`. Any rows you added or changed in the old one
are lost, so note them first (or **Export…** a copy). Max speed and Max revs are saved in the
profile too, so note those as well.

To copy files in by hand instead, **back up `SimHub\PluginsData\TPTelemetry\Profiles\` first** and
close SimHub. A copied file with the same name replaces your profile, along with any changes you've
made to it.

The `.CT` tables can also be brought in with **Import…**, or opened in Cheat Engine to look for
better addresses.

## How the tables are laid out (3 November 2026)

Every profile's table runs in the same order:

1. **Values read from the game**: memory reads, and values worked out only from TeknoParrot's shared
   memory, the game's outputs or the clock. Speed rows first, then revs, then gear, then the rest.
   OutputBlaster's shared raw reads (unticked `ob_` rows) come last in this group.
2. **Values calculated from other rows** (acceleration, hits, rumble strips, lamps decoded from a raw
   byte...).
3. **The `car_` rows** that feed the common values and so the SimHub effects.

Redundant rows are gone: where a memory read fed only one simple calculated row, the two are now one
row that reads memory and decodes it in its formula (the table's **Raw** column still shows the number
as read). So `gear_raw` + `gear` is `gear` (WMMT5 and 6), `steer_raw` + `steer` is `steer` (OutRun 2,
Mario Kart), and in the same way `force` (Batman, H2Overdrive, Mario Kart, Sega Race TV, Snocross,
Sonic), `force_alt` (Daytona Championship USA), `spring` (H2Overdrive), `hit` (Mario Kart),
`road_rumble` (GRID) and `position` (Daytona USA on Model 2). The raw rows' SimHub properties (for
example `TPTelemetry.OUTRUN2SP_steer_raw`) no longer exist; use the decoded one. Delete and re-import a
profile to get the new layout.

## Common values (car_ rows) and SimHub effects

Every profile ends with a few unticked `car_` rows (`car_impact`, `car_speed`, `car_rumble_strip`...).
Each maps the game's own values onto a common meaning, which the plugin (0.13.0 or later) publishes as
`TPTelemetry.Car_...` from whichever game is selected. The plugin's ready-made SimHub effects ("TP -
Collision", "TP - Engine"...) read only those, so one SimHub profile serves every game: see the
plugin's SimHub_Effects.md.

`car_throttle` (WMMT5DX+) needs plugin 0.14.0 or later, where the engine effects follow the throttle;
older versions ignore it.

* A game without a particular `car_` row simply leaves that effect silent.
* Where a game has no direct value, the row is worked out from the force feedback (big kicks as hits,
  small kicks as bumps, sustained force as cornering) and its note says it's approximate.
* Game_Formulas.md lists every game's `car_` rows with the rest of its formulas.

**When effects run, and when lamps do (Alexis, 11 November 2026).** Effects (every `Car_` value) run only
while racing: from the start to the finish line. The plugin zeroes them whenever `car_in_race` is 0, so
each game's `car_in_race` should end at the finish line, not when the game hands back to the menus (many
games drive the car for you after the line). Lamps are the opposite: a cabinet lights its lamps in the
attract mode and the menus too, so no lamp row is ever tied to racing, and the plugin passes lamp values
through whatever the race state. Where a game's finish is known, `car_in_race` stops there: GTI Club,
Initial D 6, Battle Gear 4 Tuned, both Mario Karts, SWDC, WMMT5DX+, WMMT3DX+ (from its own race state,
confirmed in a recording on 11 November 2026), OutRun 2 (from its own race state, confirmed the same
day), the Model 2 STCC and Sega Rally, Sega Rally 3 (from its own player state, confirmed in a recording on 16 November
2026) and GRID (from its race clock object, confirmed in a recording of 12 November 2026). Daytona (Model 2) still needs a
recording through the finish line to the results to set it. On Sega Rally 3 and GRID every other common value reads 0
outside a race too (Alexis, 16 November 2026: only force feedback and lamps work in the menus), as on OutRun 2.
Initial D Zero v2.30 does the same from its own race and car state, from GO to your finish line (confirmed in two
recordings on 16 November 2026, with the tutorial's how-to demos off).
Initial D 3 in Flycast does the same from its own car and race clock, from GO to the finish line or time up (confirmed
in recordings on 17 November 2026).
Scud Race in Supermodel does the same from its own race phase and race clock, from GO (on Beginner from the rolling
start's 3-2-1, and Car_in_race with revs and gear on the grid on Medium and Expert) to the finish line or time up
(confirmed in five recordings on 18 November 2026).
Daytona USA 2 Power Edition in Supermodel does the same from its own in-game flag and race clock, from the time being set
(the rolling start on Beginner, kept as Alexis asked; the grid on Advanced and Expert) to the finish line or time up
(confirmed in three recordings on 18 November 2026).

### Common dashboard values and lamps (19 November 2026, plugin 0.20.0)

The same `car_` rows now also carry dashboard values in one unit for every game, and new unticked `lamp_` rows map
each game's lamps onto common names, so one SimHub dashboard and one LED set-up serve every game:

* **Dashboard:** `car_speed_kmh` (so `Car_speed_kmh` and `Car_speed_mph`; 26 games, where the speed's units are known:
  Sega Rally 3's mph converted, Mario Kart's own units taken as km/h), `car_rev_limit_rpm`, `car_position`, `car_lap`
  (the lap you are on, 1 = first, also where the game counts laps done), `car_laps_total`, `car_time_left` (RT),
  `car_race_time` (TT), `car_lap_time`, `car_brake`, `car_steer` and `car_gap`. Like the effects' rows they read 0
  outside a race where Alexis asked for that (Sega Rally 3, GRID, SWDC, Initial D 3 and Zero, Scud Race, Daytona 2 PE).
  The plugin's Common_Dashboard.md lists them.
* **Lamps:** `lamp_start`, `lamp_view1` to `lamp_view4`, `lamp_select_up`/`down`/`left`/`right`, `lamp_action`,
  `lamp_leader`, `lamp_checkpoint`, `lamp_final_lap`, `lamp_shift`, `lamp_warning` (WRONG WAY, Brake!, SHIFT UP),
  `lamp_boost`, `lamp_red`/`green`/`blue`/`white`, `lamp_marquee` and `lamp_brake`, from the game's own lamp rows or
  its made-up ones (`leader`, `checkpoint`). Never tied to racing. The plugin's Common_Lamps.md lists them.
* Game_Setup.md lists each game's under **Common dashboard values** and **Common lamps**.
* Scud Race's and Daytona 2 PE's own lamp rows are now `lampstart`, `lampview1`... (they were `lamp_start`...), as
  OutputBlaster names them in every other game: `lamp_` names are the common lamps only.

## Without USB capture (USBPcap)

**No profile in this pack uses USB capture.** Every common value comes from game memory,
TeknoParrot's shared memory or a game's network outputs. With USB capture off, or USBPcap not
installed, every `Car_` value in every game reads as the profile gives it.

**With USB capture on (plugin 0.15.0 or later)**, the plugin fills the force-based common values a game
has no row for (`Car_impact` and its side, `Car_road_bump`, `Car_cornering`, `Car_vibration`) from the
force your wheel got, whatever produced it (TeknoParrot, the FFB Arcade Plugin's hooks, MAME's own
force feedback). The games in the table below gain those effects; games that have the values keep
their own. See the plugin's USB_Capture.md.

What USB capture adds:

* the `FFB_` values (`TPTelemetry.FFB_force` and so on: the force feedback as it reached your wheel)
  and the wheel's steering and pedals, for your own SimHub effects or dashboards;
* a way to check a profile's force decoding against what the wheel really got.

Where it would matter is a game whose force feedback is made by a code hook (the FFB Arcade Plugin or
FFB Blaster patches the game and drives the wheel itself). The force then never appears in game
memory or in TeknoParrot's shared memory, so USB capture is the only place the plugin could see it.
Your wheel still gets its force feedback; the plugin just can't read it. In those games the
force-based common values are missing unless the profile rebuilds them from other values:

| Common value | Usually comes from |
|---|---|
| `Car_impact`, `Car_impact_left/right`, `Car_impact_side` | force kicks, or a hit value in memory |
| `Car_road_bump` | small force kicks (joints, bumps) |
| `Car_wall_left/right` | force held while scraping a wall |
| `Car_cornering`, `Car_corner_left/right` | sustained force |
| `Car_grip_loss` | the spring dropping in a slide |
| `Car_vibration` | the game's rumble command |

Speed, revs, gear, `Car_accel_g`, braking, accelerating, engine, rev limiter, shift, `Car_in_race`
and the surface values come from memory and don't depend on force feedback at all.

### Games whose force isn't read, and what that costs

| Game(s) | Why | Common values it still has | Missing |
|---|---|---|---|
| `OUTRUN2SP` | FFB plugin hook ("Real" mode, GameId 35) | in race, speed, revs, gear, G, hits (walls and traffic, from memory), hit side, off road, rumble strip | road bumps, wall scrapes, cornering, grip loss, airborne, vibration. Hit side is 0 at some wall hits and all traffic hits; with USB capture (plugin 0.16.0) those take the side from the wheel force, which pushes from the side of wall and traffic hits (not rear-end ones). USB also gives road bumps (the sand divider); `car_cornering` is a 0 row, as the hook sends no steering force. |
| `GRID` | the FFB plugin makes the force (Custom mode) from values this profile reads too; matched over USB, 3 November 2026 | speed, revs (with each car's limiter), gear, throttle, G, hits and side, off road, grip loss | road bumps, wall scrapes, cornering, vibration: the force has none of them (only hits, gear changes and kerbs), so `car_road_bump` and `car_cornering` are 0 rows and USB capture adds nothing here |
| `BG4JP`, `CRAZYTAXI` | force not read | hits and side, wall contact, speed (BG4JP also revs, gear, G, in race, boost; Crazy Taxi off road) | road bumps, cornering, grip loss, vibration |
| `CRUISNBLAST` | race force from a hook | in race, boost | everything force-based, and speed |
| `CARS`, `FNFDRIFT`, `FNFSC`, `FNFSB2`, `HUMMER`, `HUMMEREXTREME` | hooks | lamps only (FNFSB2: boost) | all common values |
| `BG4`, `HARLEY`, `MOTOGP`, `CRAZYRIDE` | OutputBlaster lamps only; force not known | lamps only | all common values |
| `RTUNED`, `HYDROTHUNDER`, `THRILLDRIVE4` | force not read (cheat-table values only) | boost (R-Tuned also impact) | the rest |
| `IDTA21`, `IDTAS4`, `IDTAS5`, `IDTAS5V321`, `WMMT6RRP` | the force address isn't known for these builds | timers; IDTAS5 speed, revs, G; WMMT6RRP gear | all force-based values |
| MAME `MAMECBOMBERS`, `MAMECISCHEAT`, `MAMEDBLAXLE`, `MAMEF1GPSTAR`, `MAMEORUNNERS`, `MAMETOUTRUN`; Supermodel `SMDIRTDEVILS` | the outputs carry no force | vibration (shaker or motor outputs) | the rest |

The "Missing" column is without USB capture. With it on (plugin 0.15.0), the plugin fills each
game's missing hits, road bumps, cornering and vibration from the wheel force (for games whose force
reaches the wheel at all). Your own formulas can mix the two as well: the `ffb_` values are empty
with capture off, so `valid(ffb_based, memory_based)` uses the wheel force when it's there and falls
back otherwise.

Games that read TeknoParrot's shared memory (WMMT3DX+, Sega Rally 3, Initial D 6 to 8, Ford Racing,
Arctic Thunder, Dead Heat, D1 Grand Prix, Storm Racer G) need no USB capture either, but if
TeknoParrot runs as administrator, SimHub must too.

## Speed and revs (Max speed, Max revs)

Every `speed` row divides by the game's **Max speed**, and every `rpm` row by its **Max revs** (the
boxes above the table, plugin 0.12.0 or later): `value / max_speed`, `value / max_revs`. Left blank,
they count as 1, so the rows publish the raw value as before. Set Max speed to the game's top speed
(in the units of its speed row) and Max revs to its redline, and the rows run 0 to 1, so a SimHub
effect scaled by speed or revs feels the same in every game whatever its units or top speed. The
smallest value allowed is 1.

* `accel_g` multiplies speed back by Max speed, so it stays in G whichever you choose.
* `rpm` is engine RPM in every profile. OutputBlaster sends it divided by 100 (by 10 on OutRun 2) to
  fit MAMEHooker; the rows now undo that, so Max revs is a real redline such as 8000.
* Speed units are known for WMMT5/6 (km/h), OutRun 2 SP (`Car_speed` the speedo's km/h; the `speed` row 0.7 km/h a game unit), Sega Rally 3 (mph,
  whatever the screen shows), Sega World Drivers Championship (`Car_speed` the speedo's km/h from the game's own data, 18 November 2026; the table's `speed2` in game units, `speed_kmh` converts), GRID (km/h as the speedo shows it, from the on-screen dial), km/h as the speedo shows it on Battle Gear 4 Tuned (from the game's code); elsewhere they are unconfirmed. A run to top speed with a note of the speedo reading
  confirms both the units and the Max speed to use.
* **Limiters differ by car** in some games (GRID: 6500 to 8200). Max revs is one number per game, set from one car, so in
  a car that revs higher or lower the rev limiter effect fires late or early. GRID reads each car's limiter (plugin
  0.17.0, `car_rpm_frac`); for the others, a recording in a second car on the limiter shows whether it matters
  (WMMT5DX+'s limiter is known to vary).
* WMMT3DXP has Max speed 220 and Max revs 10000 filled in (the game's top speed, and the engine's
  limiter on Alexis's car; the dial shows less, see its section). Since 11 November 2026 it also reads each car's own limiter from the game
  (`rev_limit`, feeding `car_rpm_frac`), so the rev limiter effect follows every car. WMMT5DXP has Max speed 230 and Max revs 8900 (set for `rpm2`, which
  feeds Car_rpm; 8250 suits the `rpm` row. The limiter varies by car, so change it to suit yours).
* MKGPDX118 and MKGPDXUSA have Max speed 160 and Max revs 10000 (v1.18's recording raced at 140 to
  150 and 8000 to 9300 revs on 100cc; boosts go past both, up to 217 and 12,600).

## Games

Profiles marked **TeknoParrot shared memory** read the force feedback commands TeknoParrot
publishes (see the plugin's README), so they need no memory addresses or USB capture and keep
working through TeknoParrot updates. Several also read a little memory (lamps, speed), so they have
a process name; their force feedback rows still update before the game is found (plugin 0.11.0 or
later), and only the memory rows wait for it.

**Direction convention.** Decoded forces use + for force from the right. On WMMT3DX+ that matched
right-hand corners and right-side hits on a G25; whether every game follows the same convention is
still to be confirmed (Sega Rally 3, Sega World Drivers Championship and GRID follow it: checked against USB, 2 and 3 November 2026). Where a game's value comes out backwards, put a minus in front of `force`.

**Status.** The decoding of each game's values comes from the open-source FFB Arcade Plugin
(Boomslangnz, GPL-3.0), which drives real wheels with them; the lamps and other outputs come from
OutputBlaster (Boomslangnz, GPL-3.0). Only facts (addresses, bit masks, scales) are taken from
either; no code is used. Only WMMT3DX+, WMMT5DX+, OutRun 2 SP SDX, Sega Rally 3, Sega World Drivers Championship, GRID, GTI Club Supermini Festa,
Initial D Arcade Stage 6 AA, Initial D Arcade Stage Zero v2.30 and the Model 2 Emulator's STCC, Daytona USA and Sega Rally have been checked here against
real recordings: treat the others as starting points, and send a recording if something looks wrong.

**Lamps and other outputs** come straight from game memory, using the same reads and bit masks
OutputBlaster's own code uses (see [Outputs](#outputs-lamps-rpm-and-so-on)), so OutputBlaster isn't
needed for them. A few still come from OutputBlaster: see that section for which and why.

| Profile | Game | Force feedback (TeknoParrot shared memory) | Outputs |
|---|---|---|---|
| `SR3` | Sega Rally 3 | slot 2: 1 to 15 one way, 16 to 31 the other → `force` (+ from the right, checked against USB); from memory (Cheat Engine table): `speed` (mph, whatever the screen shows; Max speed 125), `accel_g`, `gear` (-1 before the driver's view, 0 neutral, 1 to 6); `hit`, `hit_side`, `airborne` (checked on a recording: see [Sega Rally 3](#sega-rally-3)); from the game's code (checked 16 November 2026): `player_state`, `racing` (Car_in_race), `time_left`, `checkpoint`, `lap`, `position`, `leader`, `wrong_way`; Max revs 7100 | LampStart, LampView1, LampView2, `rpm` |
| `ID6`, `ID7`, `ID8` | Initial D Arcade Stage 6 AA, 7 AAX, 8 Infinity | slot 2 packs a command and two values: `force` (command 4), `spring` (6), `vibration` (5). ID6 v1.2 also reads speed, revs, gear, pedals, race state and the car's events from memory, checked in a recording (see [Initial D Arcade Stage 6 AA](#initial-d-arcade-stage-6-aa)) | LampStart, LampView1, LampSelectUp/Down/Left/Right (ID6: from memory, both versions) |
| `FORDRACING` | Ford Racing | slot 2 → `force` | none known |
| `ARCTICTHUNDER` | Arctic Thunder | slot 7 `vibration`, slot 8 `force` around 128 | LampStart, LampView1 |
| `DEADHEAT` | Dead Heat | slots 6 to 9 like WMMT3DX+: `tp_spring`, `tp_friction`, `tp_center`, `tp_reflect`, `force`, `grip_loss` (unconfirmed) | LampStart, LampView1-4, SeatLamp1, BillboardLamp, `dash`, `keypad`, `base` |
| `D1GP` | D1 Grand Prix | slot 6 `force`, slot 7 effect: `spring_on`, `vibration_on`, `shake_on`. Also `speed` and `accel_g` from memory (process `game.exe`) | none known |
| `SRG` | Storm Racer G | slot 6 `force`, slot 7 `shake`, slot 8 ground (raw). Also `speed`, `racing` and `accel_g` from memory (process `racing.exe`) | LampStart, LampView1, LampSide, LampSide2, BillboardLamp, `dash` |

Each also has `force_abs`, `force_smooth` (sustained, cornering-like load) and `force_kick` (short
kicks: bumps, joints, hits), built the same way as the WMMT3DX+ formulas checked on a G25.

## Outputs (lamps, RPM and so on)

OutputBlaster gets most games' outputs by reading game memory and testing bits. The pack's
`oblamps.py` step translates that code into profile rows, so the plugin reads the same memory
itself:

* Each output row keeps its name (`lampstart`, `rpm`, `sideledred`...), so SimHub properties are
  unchanged. It reads 0 or 1, or the value OutputBlaster sends, except `rpm`, which is real RPM
  divided by Max revs (see [Speed and revs](#speed-and-revs-max-speed-max-revs)).
* No more rows than the outputs need. An output that reads a byte nothing else uses is a memory row
  itself (its formula works on `value`, and the Raw column shows the byte). A byte several outputs
  share (one bit per lamp) sits just above them as an unticked `ob_` row: shown in the table, not
  published. Where OutputBlaster reads a value the profile already has (WMMT's force floats,
  Daytona's force byte), the output uses that row, and OutputBlaster's plain copies (`ob_ffb1` to
  `ob_ffb4` on WMMT5/6, `ob_ffb` on Daytona, Sega Racing Classic and Sonic) are left out.
* Profiles that had no process name now have one, from TeknoParrot's own game setup: Sega Rally 3
  `Rally.exe`, Arctic Thunder `snow.exe`, Initial D 7 `InitialD7_GLW_RE_SBYD.exe`, Initial D 8
  `InitialD8_GLW_RE_SBZZ_redumped_.exe`. If your exe is named differently, change Process to match.
* Sonic & Sega All-Stars Racing: OutputBlaster also writes a byte to switch the game's outputs on.
  If its lamps stay at 0, run OutputBlaster or the FFB Arcade Plugin as well.
* None of this has been checked on the real games yet.

Still from OutputBlaster (needs it running, with OutputsSystem=1; see the plugin's Game_Outputs.md):

| Profile | Outputs | Why |
|---|---|---|
| `BATMAN` | all 13 | only sent while a "lights enabled" flag OutputBlaster keeps is on |
| `CRUISNBLAST`, `DEADHEAT` | all (Dead Heat's View2-4 are always 0 and read as 0) | worked out in code hooks |
| `H2OVERDRIVE` | boost lamp, keypad, throttle, speedo digits | worked out in code hooks and counters kept between updates (its 13 other outputs read memory) |
| `ID4JP` | all | OutputBlaster only knows the export version's addresses |
| `ID6` | all | OutputBlaster reads different addresses for v1.0 and v1.2, told apart by a checksum |

## Games read from memory

These profiles read the memory addresses the FFB Arcade Plugin reads to drive real wheels in each
game. That plugin depends on them staying put, so they should survive TeknoParrot updates as long as
the game's own files don't change; a different game version (say v1.10 against v1.18) has its own
profile.

**Process names** come from TeknoParrot's own game profiles (TeknoParrotUI, which names each
game's executable and how it's run), so they're filled in already:

* Lindbergh and ElfLdr2 games (OutRun 2 SP, Initial D 4 and 5, R-Tuned, Sega Race TV and Cruis'n
  Blast) run inside TeknoParrot's loader, `BudgieLoader.exe`, the same as WMMT3DX+.
* Road Fighters 3D runs inside `TeknoMacaw.exe`, TeknoParrot's loader for Konami PC games, which
  loads the game's `jgt.dll`.
* The rest are their own Windows program (`Daytona.exe`, `MK_AGP3_FINAL.exe`, `sdaemon.exe` for
  most Raw Thrills games, `game.exe` for several others, and so on). Their addresses use Module
  `<main>`, meaning "the process's own exe", so they'd still work if the exe were renamed.
* Crazy Taxi isn't a TeknoParrot game (the FFB plugin supports the PC release), so its Process is
  left blank: set it to whatever your copy's exe is called.

If a game's Status still says "not attached" while it's running, look at Task Manager's **Details**
tab for the program using the CPU and put that name in Process.

**Signs and units** follow the FFB Arcade Plugin: + is its "force from the right", the same
convention as the other profiles. Speeds are whatever unit the game keeps (usually km/h).
None of these has been checked against a real game here yet.

| Profile | Game | Addresses | What you get | Lamps and outputs |
|---|---|---|---|---|
| `H2OVERDRIVE` | H2Overdrive | exe | `force`, `spring` | intakes, base, seat, Infinity, leader, boost, keypad, throttle, speed digits, `speedo` |
| `SEGARACINGCLASSIC` | Sega Racing Classic | absolute | `force`, `spring`, `friction`, `vibration` | Start, Leader, View1-4, woofer and rear RGB, `rpm`, `ob_ffb` |
| `OUTRUN2SP` | OutRun 2 SP SDX | absolute | `speed`, `gear`, `steer`, `in_race`, `impact_side`, `crash`, `rough_ground`, `accel_g` (no force: the FFB plugin hooks it instead); from recordings `wall_hit`, `wall_side`, `hard_hit`, `off_road`, `rumble_strip`, `time_left`, `checkpoint` (see below) | Leader, Leader2, Start, View1, driver left/right, `rpm` |
| `DAYTONA3`, `DAYTONA3NSE` | Daytona Championship USA, and New Season Edition | exe | `force`, `spring`, `vibration`, `track`, `game_state` | Start, View1-4 (NSE: and Leader), `rpm`, `ob_ffb` |
| `ID4`, `ID4JP`, `ID5` | Initial D Arcade Stage 4 (export, Japan), 5 | absolute | `force`, `spring`, `vibration`, decoded like ID6-8 | Start, View1, Select up/down/left/right, `ob_ffb` |
| `ID0V131`, `ID0V211`, `ID0V230`, `IDTA` | Initial D Arcade Stage Zero v1.31, v2.11, v2.30; The Arcade v2.31 | exe | the same **; v2.30 also race, car and event rows from the game's code, checked in two recordings (see [Initial D Arcade Stage Zero v2.30](#initial-d-arcade-stage-zero-v230)) | v1.31 and v2.11: Start, View1, Select up/down/left/right |
| `SWDC` | Sega World Drivers Championship | exe | the same, for v1.03 or v2.30 (`version` says which it found) **; v2.30 also your car's record from the game's code (speedo km/h, revs, gear, race state, place, lap, sector, sparks left and right, brake, position and heading), needing plugin 0.19.0; see [Sega World Drivers Championship](#sega-world-drivers-championship) | none known |
| `KODRIVE` | KO Drive | exe | the same | none known |
| `MKGPDX110`, `MKGPDX118`, `MKGPDXUSA` | Mario Kart Arcade GP DX v1.10, v1.18, USA | exe, pointer chains | `force`, `speed`, `steer`, `in_race`, `terrain`, `on_ground`, `drift`, `boost`, `hit`, `landed`, `coin_pickup`, `item_change`, `rough_ground`, `in_water`; v1.18 and USA also `rpm`, `drift_side`, `race_state`, `racing`, `drift_angle` (degrees, from the slide sine the FFB plugin sends as force), `drift_strength`, `hop`, `gliding`, `spin`, `knocked`, `airborne`, `rumble_strip`, `off_road`, `item_held`, `hit_side`, `position`, `laps_done`, `laps_total`, `lap`, `final_lap`, `leader`, `race_time` (and unticked `slip`, `kart_state`, `kart_flags`, position rows), from the game's code; v1.18 and USA checked in four recordings (11 November 2026, see Game_Setup.md); effects from GO to the finish line only | buttons, billboard, side LEDs, RGB lamps (USA: v1.18's lamp words moved with its I/O block; OutputBlaster has no USA build) |
| `GTICLUB3` | GTI Club Supermini Festa | exe, absolute | `force`, `vibration`, `in_menu`; from the game's code, checked in a recording: speed, revs, gear, race state, position, laps, kerbs, landings, car and wall hits, crashes; time left still to check (see [GTI Club Supermini Festa](#gti-club-supermini-festa)) | Action, Start, Select up/down/left/right, `ob_ffb` |
| `RTUNED` | R-Tuned: Ultimate Street Racing | absolute | `crash`, `spring_on`, `boost` * | Start, View1, red and blue lamps, boost RGB |
| `DIRTYDRIVIN` | Dirty Drivin' | absolute | `force` (direction swapped on tracks 8-14, as the FFB plugin does) | indicators, fog lights, speakers, dials, base, View1 |
| `SONICASR` | Sonic & Sega All-Stars Racing | exe | `force` * | Start, Leader, RGB, side, woofer and item LEDs, `ob_ffb` |
| `CHASEHQ2`, `WACKYRACES` | Chase H.Q. 2, Wacky Races | exe, pointer | `force`, decoded from the output word with the FFB plugin's table | Chase H.Q. 2: Start, Pato lamps; Wacky Races: Start, View1, panel, slot and seat lamps; both `ob_ffb` |
| `SEGARACETV` | Sega Race TV | absolute | `force` | Start, View1, boost, red and blue lamps |
| `BG4JP` | Battle Gear 4 Tuned (Japan, v2.07: the version the FFB Arcade Plugin supports, its GameId 13; its addresses match Alexis's working FFB plugin files, 3 November 2026) | exe | `speed`, `gear`, `in_race`, `impact_side`, `car_bump`, `shift`, `accel_g`; from the game's code (9 November 2026) and checked in a recording (10 November): `speed` (the speedo), `rpm`, `gear` as Int32 (-1 reverse), `position`, `leader`, `race_phase`, `racing`, `contact`, `wall_touch`, and from the code `time_left`, `checkpoint`, `lap`, `nitro_left`, `wheelspin`, `drift_angle`, `drift`, `live`; `boost` from the nitro bit (see [Battle Gear 4 Tuned](#battle-gear-4-tuned)) | Start, View1, Hazard, Key, Online, Overrev, colour lamps |
| `BATMAN` | Batman (arcade) | exe | `force` | Start, Shoot, billboard, speakers, dash, seat, RGB, base |
| `SNOCROSS` | Winter X Games SnoCross | absolute | `force` | none known |
| `CRAZYTAXI` | Crazy Taxi (PC release; Process left blank) | exe | `speed`, `playing`, `surface`, `impact_side`, `collision`, `crazy_move`, `off_road`, `stairs` | none known |
| `GRID` | GRID (arcade) | exe, pointer chains | `speed` (km/h), `rpm`, `rev_frac`, `gear`, `throttle`, `brake`, `steer`, `shift_lights`, `distance`, `race_clock` (TT), `racing` (Car_in_race), `lap`, `final_lap`, `lap_line`, `position`, `leader`, `impact_side`, `car_hit`, `skid`, `road_rumble`, `shift`, `accel_g` (see [GRID](#grid)) | none needed (OutputBlaster's only GRID output is RPM, read from the dial instead) |
| `RF3D` | Road Fighters 3D | `jgt.dll` | `force`, `vibration`, `gear`, `menu`, `timer` | none known |
| `CRUISNBLAST` | Cruis'n Blast | absolute | `in_game`, `on_road`, `ffb_menu` (race force comes from a hook, so there's none here) | Start, View1-4 |
| `WMMT5`, `WMMT5DX`, `WMMT5DXP`, `WMMT6`, `WMMT6R`, `WMMT6RR` | Wangan Midnight Maximum Tune 5, 5DX, 5DX+, 6, 6R, 6RR | exe | `speed`, `rpm`, `gear`, `race_time`, `in_race`, `tire_slip`, `spring`, `friction`, `collisions`, `road_joint`, `rumble_strip`, `impact`, `impact_side`, `wall_contact`, `airborne`, `grip_loss`, `accel_g` (WMMT5 also `car`, `power`, `handling`; 5DX+ `power`) ** (see [below](#wmmt5-and-wmmt6)) | View1, interruption button, RGB/white, side, `ob_ffb1` to `ob_ffb4` (not 6RR) |

\* The FFB Arcade Plugin switches these games' force feedback on by writing to their memory. This
plugin only reads, so if the values stay at 0, run the FFB Arcade Plugin as well.

\** These games are 64-bit (TeknoParrot's profiles say so). SimHub is 32-bit, so the plugin reads them
through its 64-bit helper, `TPTelemetryHelper64.exe`, which needs plugin 0.9.0 or later. With an older
plugin their Status reads "Target is 64-bit but SimHub is running as 32-bit". WMMT5DX+ has been
checked in a real recording; the others haven't been tried yet.

Values with `_count`, `_raw` or a code in their name are what the game stores; the rows after them
turn those into something usable. Short events (`crash`, `landed`, `coin_pickup`...) stay at 1 for
0.2 to 0.3 s so SimHub, which reads less often than the plugin, doesn't miss them.

Not done: Cars' force feedback (it is hooked, not read; its lamps are in the pack), the original
Mario Kart GP DX, and flying and shooting games. The emulators are covered in
[Added 2 November 2026](#added-2-november-2026).

### WMMT5 and WMMT6

Process `wmn5r.exe` or `wmn6r.exe`, 64-bit: read through the plugin's 64-bit helper (plugin 0.9.0
or later). All six versions share one layout at their own addresses. **WMMT5DX+** was checked
against three recordings: on 29 October 2026, 79 seconds on the freeway at about 200 km/h (expansion
joints, a ripple strip, 18 hits and a big crash, with USB capture alongside) and 46 seconds at 100
to 140 km/h (a ripple strip, a jump, three walls, a drift across a strip and seven gear changes);
on 1 November 2026, a whole race in a five-speed car (rolling start, standing start, joints from
15 to 240 km/h, 249 km/h top speed, the finish line and the results screen, with USB capture).
The other five are unverified.

* `speed` (whole km/h), `rpm`, `race_time` (seconds): read correctly on 5DX+. Speed and rpm divide
  by Max speed and Max revs (5DX+ ships with 230 and 8900, the revs set for `rpm2` below). The limiter
  is soft and varies by car: on the `rpm` row revs creep up to about 8250 on one car, 8500 on another.
* `in_race` (0 or 1): 1 while the race clock is running. The clock stops at the finish line and
  holds the finishing time on the results screen, and it also stops if the game freezes, so this
  is off before the start, after the finish and while frozen. The SimHub effects use it.
* `gear`: the stored gear, 1 = first, 0 = neutral (a rolling start leaves you in neutral until you
  pick a gear). Checked in a five-speed car that reached a stored 5; the earlier reading of "one
  low" (29 October) was wrong. Outside a race it shows whatever the game left there. `power` read
  0 throughout.
* `collisions` is the force the game sends the wheel; above 100 km/h the wheel got exactly this over
  USB. Joints and ripple strips are short kicks, 0.21 up to about 100 km/h and rising to 0.31 at
  240, one kick per axle; hits are 0.5
  or more, and after a hit the game holds 0.2 while the car is pushed along the wall. + is the
  right, - the left. `spring` likewise reaches the wheel exactly: about 0.53 while driving, less in
  slides and hits, 0 in a big crash, on a jump and before the race starts. The game sends no
  cornering force.
* `road_joint` (0 to about 0.3): expansion joints and ripple strips. Each is a kick under 0.1 s
  long; contact held longer, or just after a hit, counts as the wall instead.
* `rumble_strip` (0 or 1): on a strip the game kicks every 0.07 to 0.13 s for as long as you are on
  it, where a joint is one kick per axle. It needs about five kicks, so it comes on about 0.4 s into
  a strip (just as a short one ends) and goes off 0.3 s after. Drifting across a strip, it comes and
  goes with the wheels. Five short strips and one crossed in a slide were confirmed from video.
* `impact` and `impact_side` (-1 to 1): hits, 0.35 or more. The game sends 0.5 for most hits and
  more in a big crash (0.78 seen). + is a hit on the right, - on the left (checked on three walls).
* `wall_contact` (-1, 0 or 1): scraping along a wall, on after 0.3 s of steady contact. Single hits
  show on `impact` only.
* `airborne` (0 or 1): the game holds the spring at 0 with no hit or wall contact in the last 0.5 s.
  It does this whenever the car goes light, on jumps and on crests even where the wheels stay down,
  and the revs jump as the driven wheels lose grip; a joint-sized kick often comes on landing.
  Confirmed from video on one jump and six crests (two with the rear wheels off the road).
* `grip_loss` (0 to 1): from `tire_slip`, which is - turning or sliding right and + left, about
  0.04 in ordinary corners and 0.1 or more in slides. The game never sends more than 0.1125.
* Replaying the recordings through the profile (in the plugin's tests): every joint marker had a
  `road_joint` just before it, at every speed from 15 km/h up; all 18 hits were `impact`s and no
  joint was; `rumble_strip` was on along all three strips and off at every joint and wall, and on
  at every strip marker in the race; `wall_contact` showed all three walls (and the big crash) with
  the right sign; `airborne` came on at the jump and the crests; `gear` changed at every noted
  shift; `in_race` went off at the finish line and during a 16 second freeze; and `grip_loss` read
  0 cruising and 1 in the slides.
* Lamps read straight from memory (two bytes, as OutputBlaster reads them). On 5DX+ the View 1 lamp
  blinked once a second during the race; the red, green, blue, white and side lamps stayed on.
  OutputBlaster's `ob_ffb1` to `ob_ffb4` are gone, being `tire_slip`, `spring`, `friction` and
  `collisions` x 100.

**More WMMT5DX+ rows (2 November 2026; checked on a recording, 3 November)**, from **MasterRaver**'s
"Output Blaster Support" Cheat Engine script (thanks to MasterRaver; Alexis supplied it). The script copies race values into a block of memory it
allocates, which moves every time, so these rows read the same sources directly. Most hang off the
pointer at `wmn5r.exe+1FD11B0`, the race structure the checked `gear` row already reads, so they're
likely right for the build checked here; other WMMT5 and 6 versions would need their own addresses.

| Row | What |
|---|---|
| `speed2` | speed in km/h to a fraction (the game keeps it in mm per second), over Max speed. The same speed as `speed`, about 0.5 km/h above it (the whole number is rounded down), updated 60 times a second. **Feeds `Car_speed` and `accel_g` (so `Car_accel_g`)** since 3 November, falling back to `speed` whenever it can't be read; `speed` stays in the table. |
| `rpm2` | revs as a float, over Max revs. Moves with `rpm` at the same moments but on a wider scale (about 1.285 x rpm - 1920: 8700 at the limiter in 2nd where `rpm` reads 8270, 4700 where it reads 5150). **Feeds `Car_rpm`** since 3 November (Alexis), falling back to `rpm`; **Max revs 8900** to suit it (the limiter in 2nd, about 8700, is 97.8%, so the rev limiter effect comes in at the limiter only). |
| `race_time2` | the race clock, seconds, at another address: the same as `race_time` to the frame. **Feeds `in_race`** (so `Car_in_race`) since 3 November, falling back to `race_time`. |
| `turbo` | turbo gauge: 1.5 on full throttle on the recorded car, -0.5 off the throttle. |
| `throttle`, `brake` | pedals, 0 to 1 (the game reads 0 to 85), the higher of two copies; read from `pedals_a` and `pedals_b` (unticked). The throttle matched the G25's over USB; the brake wasn't used in the recording. |
| `distance` | metres from the start line, from `progress` and `start_ref` (unticked, road units of 1000 a metre). Grew 1895 m where the speed gives 1899 m. |
| `place` | race position, 1 to 4, from the race order (`order1` to `order4`, unticked: the player is 0). Read 1 throughout the recording: still to be checked in a race with rivals. |

Left out: the script's shift light (its own 8000 rpm threshold, not the game's), distance to go and
course length (a goal position typed in per course), rival gaps and names, story rank, and the
exhaust after-fire (found by scanning memory for an object, which the plugin can't do). The original
`speed`, `rpm` and `race_time` rows all stay in the table.

**Common values from the new rows (3 November 2026):**

* `Car_boost` = `turbo` / 1.5 (0 to 1): 1 at full boost, dipping at each upshift and after a hit, 0 off
  the throttle. It drives "TP - Boost" and "TP - Wind: Boost gust", which in WMMT are on most of the
  time; turn their gain down if that's too much.
* `Car_throttle` = `throttle` (plugin 0.14.0 or later): the engine effects run at 60% off the throttle
  and full at full throttle.
* `Car_impact`: the game's hit (0.5 reads about 0.6), or 0.5 + the km/h lost in the last 0.3 s / 120,
  whichever is bigger. The hit at 221 to 153 km/h in the recording reads 1, the light ones about 0.6.

**Ideas not built yet** (from the same rows):

* Turbo blow-off: a short burst of noise on the gas pedal and seat when the turbo drops from full boost
  to below 0 as the throttle is lifted.
* Brake pedal: a firm buzz on the brake pedal shaker growing with the pedal and the speed, from the
  pedal itself rather than the slowing down. Needs a recording with braking.
* Place: a leader lamp in 1st, or a pulse when passing or being passed. Needs a race with rivals.
* Shift feel: upshifts on full throttle (the turbo dips) kicking harder than lifted ones.

### WMMT3DXP: Wangan Midnight Maximum Tune 3 DX+

Process `BudgieLoader.exe`, 32-bit. Max speed 220 (km/h, the game's top speed; 230 has been seen, which
the effects treat as 1) and Max revs 10000 (the engine's limiter on Alexis's car, 11 November 2026).

**Read from the game itself (11 November 2026).** The game is a Linux program (`main`) that TeknoParrot's
BudgieLoader loads at the fixed addresses it was built for, and it still carries its own variable names.
So the memory rows now read the game's own variables at those addresses (no module, as on OutRun 2),
not the cheat table's `BudgieLoader.exe+...` pointers, which live in BudgieLoader's memory and moved with
TeknoParrot's October 2026 release. TeknoParrot updates can't move these; only a different build of the
game could. Checked in Alexis's recording of 11 November 2026 (18:36; story mode, C class, Hakone inbound,
manual) and a traffic recording (20:15): speed and gear match the old meter rows, effects run from the
countdown to the finish line, time left, race time and the rival gap all behaved, and the slip angle and
steering read + to the right. `rpm` is the engine's revs; the dial shows less (`tacho`: the game sets the
needle to 0.96 x the rev rate + 0.04, its full travel ending at the dial's 8,000 mark, which matched her readings). Every car row reads 0 outside a race (`seq_active`), as the
game frees the car at the end without clearing its pointer.

| Row | Game variable | What it is |
|---|---|---|
| `speed`, `rpm`, `gear` | the player's car (`yt::CSeq::pMachine`, 0x098138E4): +AE0, +2CC, +300 | speed (mm/s x 0.0036, as the speedo works it out), engine revs (rad/s x 60 / 2 pi, as the tacho), gear (1 first, 0 neutral, -1 reverse) |
| `rev_limit`, `rpm_frac`, `shift_light` | car +2C4 -> +8C | this car's limiter; revs as a fraction of it (feeds `Car_rpm_frac`); the meter's rev lamp, on above 86% |
| `turbo`, `turbo_max`, `blowoff` | car +344; +340 -> +44; +368 | boost in bar (-0.5 to full); this car's full boost (0.6 to 1.5 by tuning); the blow-off valve. `Car_boost` is turbo / turbo_max |
| `backfire` | car +39C | 1 for about 0.4 s from the exhaust flame after a sharp lift at high revs |
| `tacho` | from `rpm_frac` | revs as the dial shows them (the dial is printed to 9,000, but the needle's travel ends at the 8,000 mark) |
| `drift_angle`, `wheel_slip` | car +AF8, +AFC | the slip angle in degrees (+ right-hand drift), feeding `Car_drift` with Initial D 6's weighting; the driven wheels' slip (about -0.1 cruising, more negative with wheelspin) |
| `load`, `light`, `airborne` | car +AE4 | load on the tyres as a fraction of the car's weight (1 flat, 0 in the air; the game's wheel spring is worked out from it); `light` under 0.5 (crests), `airborne` after 0.25 s under 0.375. `Car_airborne` is 1 airborne, 0.3 light |
| `wall_touch`, `car_touch`, `hit_car` | car +D4, +90 | the game's own contact flags for walls and other cars, each frame (strengths in the unticked `wall_force`, `car_force`); `hit_car` is a car or traffic hit, 0.25 for a nudge to 1 for a crash, added to `Car_impact` (TeknoParrot's slot 9 misses most car hits) |
| `car_side` | TeknoParrot slot 9 | side of a car hit, +1 right, -1 left: slot 9 gives car hits 59 of 63, signed opposite to wall hits (checked against Alexis's account of seven traffic hits and two rival nudges). `Car_impact_side` is the wall side, or else this |
| `odometer`, `rival_gap`, `leader` | car +970; first rival car +7F4 | metres along the course; metres ahead of the CPU rival; 1 while ahead |
| `race_state`, `in_race` | `yt::CState::eState`, 0x09813A78 | 0 none, 1 countdown, 2 racing, 3 retired, 4 slowing (time ran out), 5 stop wait, 6 time up, 7 at the goal (from the line), 8 goal, 9 defeated, 10 suspended. `in_race` (so `Car_in_race`) runs from the countdown (the driver's view) to the finish line, and is off while the clocks stand still (a pause) and in the story mode's opening shot |
| `time_left`, `countdown` | 0x09813A6C, 0x09813A68 | time left (the cheat table's "GTimer1", the old `race_timer` row); the start countdown |
| `race_time`, `sections`, `sections_passed`, `checkpoint` | the time keeper (0x098138C8): +C, +0, +14 | race clock; section lines to the goal and passed (unticked: story mode read 2 and 2 throughout); 1 for 2 s after each line before the finish |
| `reversing` | 0x09813A58 | the game's wrong-way flag |
| `throttle`, `brake`, `steer` | the game's controls (0x098138E0): +4, +8, +0 | 0 to 1, 0 to 1, -1 to 1 (+ right). `Car_throttle` is the throttle |
| `carhit_*`, `wallhit_*`, `mat_*` | car +C0, +104, +A4C | unticked raw reads (the push the game gives the car on a contact, and its orientation), to work out the side of car hits from a recording |

The old cheat-table rows are gone (the game's own match them, and the old revs row was neither the engine
nor the dial). The plugin's tests replay the 1 November recordings through the new rows (their speed, revs
and gear converted to the game's units), and Alexis's two recordings of 11 November (`Wmmt3GameTests`):
effects from the countdown to the line, her dial readings, the slide and steering signs, the jump and
crests, and every car hit. Details in
`claude/WMMT3DXP-exe-20261111.md`. `WMMT3DXPexp.CT` still has every cheat-table candidate.

* `accel_g`: longitudinal G from speed
* No lamp outputs: OutputBlaster doesn't support WMMT3DX+.
* From TeknoParrot shared memory (no setup, any wheel):
  * `tp_spring` (slot 6), `tp_friction` (7), `tp_center` (8, centre offset) and `tp_reflect` (9),
    scaled to 0..1 or -1..1, and `tp_force`: the constant force the wheel gets (centre offset when
    there is one, otherwise reflect). Signed values use **+ = right, - = left**.
  * `grip_loss` (0 gripping, 1 sliding), `cornering` (+ right-hand corner, - left) and
    `cornering_abs`
  * The reflect slot (9) carries the road and the walls:
    * expansion joints are short pulses of 26 to 33 (of 63), bigger the faster you go, usually two
      about 0.07 s apart (front then rear wheels): `road_joint`, and `road_bump` (0 to 1)
    * a hit on a wall or car reads 63 (+ right, - left): `impact` (held 0.15 s) and `impact_side`
    * scraping along a wall gives repeated 63s, or exactly 25 held while the car is pushed along
      it: `wall_contact` (+1 right, -1 left). Only 25 counts as held: two joints running together
      can give 0.2 s of 30s and 32s with no gap.
* USB capture values aren't in the profile. To see them, use **Add FFB values to table** in the
  plugin (plugin 0.10.0 or later).
* From speed: `impact_front`, `impact_rear` (0 to 1), `impact_long` (+ front, - rear) and
  `impact_long_abs`. FFB can't tell front from rear, since the wheel only turns, so these look for
  speed changing faster than brakes or engine can manage (1.5 G slowing, 1.2 G speeding up).

Checked against two recordings on 1 November 2026 (freeway, 26 marked joints, six crashes into
walls, three each side): `road_joint` caught every marked joint and nothing during the crashes;
`impact` read the right side for all six; `wall_contact` held while the car scraped or was pushed
along each wall, on the right side. The plugin's tests replay both recordings, so a change that
breaks any of this shows up.

The first set of formulas came from a 57-second G25 capture (29 October): grip_loss reads 0
driving straight and 0.85 to 0.95 in the slides. Those don't use memory addresses, so TeknoParrot
updates don't affect them.

### Replacing the old WMMT3DXP profile in SimHub

Importing over an existing game never replaces it: you'd get a second game, `WMMT3DXP2`, and
command lines using `Activate_WMMT3DXP` would still point at the old one. Instead:

1. In TP Telemetry, select the old WMMT3DX+ game and click **Delete Game**.
2. Click **Import…** and choose `WMMT3DXP\WMMT3DXP.json` from this pack.

It keeps the prefix `WMMT3DXP`, so your launch scripts carry on working. SimHub formulas that read
`WMMT3DXP_speed1`, `WMMT3DXP_revs1` or `WMMT3DXP_gears1` need changing to `WMMT3DXP_speed`,
`WMMT3DXP_rpm` and `WMMT3DXP_gear` (speed and rpm now run 0 to 1; or use `TPTelemetry.Car_speed`
and `Car_rpm`, which stay in km/h and RPM).

**11 November 2026:** the rows now read the game's own variables, so delete and re-import once more.
`speed`, `rpm` and `gear` keep their names; `WMMT3DXP_race_timer` is now `WMMT3DXP_time_left`.

## Added 2 November 2026

Three sources: MasterRaver's TeknoParrot cheat tables (the 04.10.26 pack), OutputBlaster games that
weren't in the pack yet, and the emulators the FFB Arcade Plugin supports. **Everything here is
unverified.** Where a table gives a value a profile already had at a different address, the new row
has the next free name (`speed2`, `gear2`...), and nothing existing was changed. Only telemetry was
taken from the tables (speed, revs, gear, timers, nitro, damage, pedals), not their cheats, scores or
cosmetics.

### OutRun 2 SP SDX

One profile, `OUTRUN2SP` (**OutRun 2 SP SDX**). The Legacy copy (`OUTRUN2SPLEGACY`) has gone: if
you imported it into SimHub, delete it there.

From the cheat table: `select_timer`, `stage_timer`, and `speed2` (from the car's velocity,
`vel_x`/`vel_y`/`vel_z`). In my recordings the velocity addresses read nonsense, so `speed2`
doesn't work in this build.

**Max speed 280 (km/h), Max revs 9300.** `Car_speed`, `Car_rpm`, `Car_gear` and `Car_accel_g` read 0 outside a race
here (the attract demo and menus), like the effects (Alexis, 12 November 2026; this game only). Since 11 November 2026 `Car_speed` is the speedo's own km/h
(`speed_kmh`, up to 312 seen). The `speed` row is another game value in units of about 0.7 km/h (it reads
about 431 where the speedo shows about 300); the row converts it to km/h before dividing by Max speed, so
its fraction is the same as before (400 units = 280 km/h), and `accel_g` and `g_fast` work in km/h.

Checked on three recordings (2 November 2026), and these rows added:

| Row | What |
|---|---|
| `wall_hit` | 1 for 0.3 s when a wall hit starts. `side_hit_count` is a countdown the game starts at each wall hit, so only its jump up counts: all ten walls in the two recordings, nothing else. |
| `wall_side` | the side of that wall, +1 right, -1 left, from `side_hit_dir` in the last 0.4 s; 0 when the game gives no side (once in twelve). |
| `g_fast`, `hard_hit` | quick deceleration, and 1 for 0.3 s past 21 G: the bus, the semitrailer and the midsize car, which `crash_count` (and so `crash`) misses. Braking stays under 7 G; some drift starts dip to 18 G. Not below 14 km/h, so the car being put back on the track after a flip doesn't count. |
| `off_road` | grass (4, and 8192 at its edge) or sand (8). |
| `rumble_strip` | striped verge (1024) or the edge of sand or a verge (2048). |
| `time_left`, `checkpoint` | stage time left in seconds (the timer counts 60 a second), and 1 for 1 s when a checkpoint adds time. |

* `Car_impact` is now any of `crash`, `wall_hit` and `hard_hit`, 0.5 to 1 by how hard the car
  slowed; `Car_impact_side` is `wall_side`; `Car_off_road` and `Car_rumble_strip` come from the
  new rows.
* `rpm`: the game stores RPM / 10 (idle about 160, top about 980), so the row now multiplies by 10.
  It read a tenth of the real revs before.
* `impact_side` and `rough_ground` are kept but not used for the common values: `impact_side`
  fires on every step of the countdown, and `rough_ground` misses the grass edge (8192).
* At every wall hit the speed reading freezes for 0.5 s, then drops. In the hit where the car flips
  over, it then falls from 411 to 101 (`hard_hit`, so Car_impact 1 about 0.5 s after the wall);
  the game holds about 101 for 2 s, then puts the car back on the track at 0.
* `transmission` is 1 on manual, 0 on automatic. On manual the gear went up one at two wall hits
  (3rd and 4th); after the flip on automatic it dropped to 1.
* `ffb_wall` and `ffb_float` (unticked) are two values the FFB Arcade Plugin's fake mode reads but
  doesn't use; they're there so a recording can show what they are.
* The car leaving the ground comes from the game's crash motions (11 November 2026): `crash_air`, so
  `Car_airborne`, is 0.5 as a rear-end crash lifts the rear wheels and 1 through a flipping crash.
* **USB capture is optional, and helps.** The FFB plugin hooks this game's force feedback, so
  TeknoParrot's shared memory stays empty and the force never reaches memory; every row above is
  worked out from other game values. With USB capture on you also get the wheel force (`FFB_force`):
  -0.5 to -1 for a left-hand wall, +0.4 to +0.8 for a right-hand one. A fourth recording with USB
  capture (3 November 2026, 20:48) showed what the hook sends: a full push (0.8) from the side at
  side-on wall and traffic hits, nothing at rear-end hits (the truck, mark 2), about 0.55 across the
  sand divider, and a small sine (0.06) at each gear change; no steering force. So:
  * the flip wall (the same place as on 2 November) gave no side from the game this time, and the
    wheel force's push from the left gives it (`Car_impact_side` -1, plugin 0.16.0); two unmarked
    traffic hits get their sides the same way;
  * `Car_road_bump` comes from the wheel force (strong on the sand divider, weak at gear changes);
  * `car_cornering` is 0, so a hit doesn't read as cornering.
* `steer`: + is right (it follows the G25's own steering over USB).

**Read from the game itself (11 November 2026).** OutRun 2 SP is a Linux program (`jennifer`) that
BudgieLoader loads at the fixed addresses it was built for, and it isn't stripped: every variable and
function has its name. The rows above turn out to be the game's own variables: the player's car is the
first of 24 car records (`evwork_car`, 0x08279DA0, 0x10E0 bytes each), and `gear`, `rpm`, `surface` and the
wall rows read it; `speed` is another car value (`car_work` +330), not the speedo; `in_race` is the HUD's
navigation display flag. New rows, checked in Alexis's recording of 11 November 2026 (19:06, five
stages to the goal) except where the table says:

| Row | Game variable | What it is |
|---|---|---|
| `speed_kmh` | car +3B0 | the speedo's km/h, exactly what it prints (the car's speed times its own speedo factor, capped at 300 for some cars) |
| `drift`, `drift_angle` | car +DE6, +56 | the game's drift state (a brake tap or a lift-off opens it; the slip angle keeps it): 15 drifts of 2 to 10 s at 60 to 78 degrees. The rear tyres' slip angle in degrees (+ a right-hand drift, confirmed; 0 under 10 km/h). `Car_drift` from them with Initial D 6's curve stretched to full at 75 degrees (OutRun's drifts run 60 to 78; this game only, other games keep 50); `Car_grip_loss` falls back to it |
| `slipstream` | car +F18 | slipstream strength, 0 to 1; the speedo shows its sign above 0.18 (50 times in the recording; to match against the screen) |
| `shift_warning` | car +F2C | 1 while SHIFT UP shows (never set in the recording; to check) |
| `crash_motion`, `crash_kind`, `crash_air` | car +4A4 | 1 while the game plays a crash motion on the car: kind 7 running into the back of a truck or bus with the rear wheels lifting (1.5 s), kind 1 a big wall crash with the car flying and flipping (2.5 s). `Car_impact` is 1 the moment one starts, 0.5 s before the speed row falls; `crash_air` (`Car_airborne`) 0.5 as the rear lifts, 1 through a flip |
| `fork_sign` | `observer_flag` bit 32 | 1 for 3 s when the fork's "easy" arrow comes up, about 13 s before the end of each stage (about as long as it shows) |
| `shift_light` | from `rpm` | the redline light on the rev dial, on from 8,270 RPM: where it came on in Alexis's video on the 250 GTO, 512 BB and Enzo (8,260 to 8,270) and the Testarossa (8,370). Each car has its own dial, so it may differ a little by car |
| `hearts`, `challenge_won` | 0x082FCD04 | Heart Attack: the hearts won (the game keeps them x 10,000), and 1 for 1 s when a challenge's hearts are awarded |
| `main_mode`, `game_mode` | 0x08303CF4, 0x08303D00 | the game's main sequence (3 attract, 4 title, 13 start, 15 racing, 17 goal, 18 time up, 20 result...) and which game (0 Time Attack, 1 OutRun, 2 Heart Attack, -1 in the menus) |
| `car_hit`, `car_side` | car +6C8 to +6D4, +10DE | a hit by another car (the game's contact words, or its side code changing), and its side, +1 right, -1 left, with no USB capture needed: it matched the wheel force at every car hit in the 12 November recordings. `Car_impact` includes car hits; `Car_impact_side` is the car hit's side, else the wall's |
| `goal`, `time_up`, `racing` | `observer_flag` 0x0830B740 | the finish line of the last stage, the time running out, and racing between them: **`Car_in_race` is now `racing`**, so effects stop at the finish line and stay off in the attract mode |
| `stage`, `race_time`, `stage_time` | 0x0830B8CC, 0x0830B74C, 0x0830B750 | stage 1 to 5, the race clock and this stage's time in seconds |

Unticked: `front_slip`, `crash_flags`, `observer_flag`, `last_stage_time`, `hearts` (Heart Attack's
rating), `paused`, and the raw reads `hit_dir` (car +10DE, the side code the game stores at every hit on
another car: 4 right, 8 left) and `hit_box1` to `hit_box4` (car +6C8 to +6D4, contact words: 1 and 2 right,
3 and 4 left), which `car_hit` and `car_side` use; `rev_limit` and `rev_1030` (car data +1068 and +1030: 8,901 and
1,571 on all three cars recorded on 12 November) and `course_event` (the byte behind `observer_flag` 32 and 64). The plugin's tests replay the four earlier recordings with the new gate (fed from the HUD
flag they were made with) and get the same hits, walls and sides as before, and the 11 November recording
(`Or2GameTests`): effects from GO to the finish line, the speedo, the stage gates, the crash motions and
the drifts; and the 12 November traffic recording: every car hit's side from the game alone. Details in
`claude/OUTRUN2SP-exe-20261111.md`.

### Sega Rally 3

Checked on one recording (2 November 2026: one lap of three, manual, with notes), with the force the
G25 received over USB alongside.

* **Speed is mph**, whatever the screen shows: mph x 1.609 matched the speedo at every speed noted
  (186, 196, 201 and 193 km/h). Top 130 mph (210 km/h) on this car and track. **Max speed 125 mph**
  (about 201 km/h; was 110), a little under the top so the speed effects reach full strength before it.
* **Gear** -1 before the driver's view comes up, 0 (neutral) on the grid, then the game drops it into
  1st at the start and it follows the shifter, 1 to 6.
* **Revs** reach a limiter of about 6930 in neutral, 5th and 6th, and 7397 when overrevved on a
  downshift; they read 0 on the grid until the throttle is pressed. **Max revs 7100** (was 6600, at
  which `Car_rev_limit` buzzed above 6400 rpm, over 40% of the lap): the limiter, about 6930, is 97.6%
  of it, so the rev limiter effect comes in at the limiter only.
* **Force** (`force`) is what the wheel gets: the USB force was the same, about 0.02 s later. + is
  force from the right, + when steering right. The game sends no more than 0.73 either way, and the
  force follows the steering with road texture on top, so the force-kick stand-ins for hits and bumps
  fired all the time (`Car_impact` a fifth of the time, `Car_road_bump` over 0.3 for 42%). They're
  replaced:

| Row | What |
|---|---|
| `hit` | 1 for 0.3 s when the speed drops by more than 3 mph in one game frame (a thirtieth of a second) from a steady speed: every wall hit and scrape in the recording and nothing else. Braking, drifts, water, downshifts and light brushes with cars lose under 2.4 mph a frame, so car brushes aren't caught. When the car is already slowing hard the drop it takes rises with the slowing (16 November 2026: a big slide from 204 to 44 km/h, the automatic's downshifts, and the speed jitter just after a landing had counted as hits; Alexis said none was). |
| `hit_side` | the side of the hit, +1 right, -1 left, from the wheel force just before the speed drops (the game kicks the wheel towards the side hit): right at six of the seven walls; a rear right-hand hit while drifting read left. |
| `airborne` | 1 when the game has sent no force for 0.4 s above 60 mph: both jumps, nothing else. A guess from two jumps. |

* `Car_impact` is `hit`, 0.5 to 1 by the mph lost in one frame (3 mph 0.5, 23 mph or more 1);
  `Car_impact_side` is `hit_side`; `Car_airborne` is `airborne`, so landings give `Car_landed`. A hit
  within 0.7 s of landing isn't counted (0.2 s until 16 November 2026), so a landing is a landing only.
* In Alexis's quick race of 12 November 2026 her paired marks bracketed every jump: `airborne` comes on about 0.4 s
  after takeoff (the force stops at takeoff) and ends at the landing. Her answers on eight hits: five walls on the
  side read, one front-left hit read right, and the two that weren't hits are gone with the change above.
* No `Car_road_bump`: nothing in the force tells bumps from the steering. `Car_cornering` still comes
  from the sustained force.
* Not found in the recording: water and the dips in the road (checkpoints and lap lines now come from the game's code, below).

**From the game's own code (`Rally.exe`, 12 November 2026), checked in Alexis's recording of 16 November 2026** (10:24:
attract mode, a three-lap race in game mode 5, the finish and the results). The game keeps its six
cars' records in one fixed array, and car 0 is the cabinet's own player (the game reads car 0's state directly, and the
revs row was already car 0's). So these are plain fixed addresses (`Rally.exe+` the offset), like the revs:

| Row | Address | What |
|---|---|---|
| `player_state` | 5DD5C0 | the player's state: 0 attract mode and menus, 1 intro, 2 countdown, 3 racing, 4 finished (waiting for the others), 5 post race. In the recording: 0, then 1 for 4 s, 3 from GO, 5 from the line |
| `racing` | | 1 from GO to the finish line (state 3); **feeds Car_in_race**, so the effects stop at the line |
| `finished` | | 1 from the finish line |
| `time_left` | 5DB4C8 | time given, seconds (kept in milliseconds): 70 at GO, +25 at each checkpoint and +30 at each lap line. In game mode 6 the game counts it down to GAME OVER; in Quick Race (mode 5) it only goes up |
| `race_time`, `rt` | | the race time (TT) from GO; the time left as the screen shows it (RT): the time given less TT in Quick Race (Alexis read 33 and 56 where this gave 33.57 and 56.27: the screen cuts off the decimals), `time_left` itself in mode 6. The game adds an extension about 2 s before the screen shows it (the screen holds the old time while TIME EXTENSION flashes) |
| `checkpoints` | 5DD610 | lines crossed: -1 on the grid, 0 over the start line, then +1 at each lap line and the finish |
| `checkpoint` | | 1 for 2 s after a checkpoint or lap line (the line count goes up, or the time jumps up); not at GO or the start line. Her checkpoint marks came 0.4 to 0.5 s after it |
| `lap`, `laps_total`, `final_lap` | 5DD614, 328A28 | the lap (0 on the grid, 1 over the start line), laps in the race, 1 on the last lap |
| `position`, `leader` | 5DD61C | position (1 = first), held until a new place has stood 0.1 s (the game's value flicks between two places when cars run side by side); 1 while leading |
| `wrong_way` | 5DBACC → 1CBC | 1 while WRONG WAY shows: turned round, or reversing with the car facing forward. The game leaves it set in the menus, so it counts only while racing |
| `game_mode` (unticked) | 328598 | the game mode (5 in this recording; the time only counts down in mode 6) |

* `car_in_race` is `racing`. If the player state can't be read at all it counts as racing, so a failed read leaves the
  effects as they were (it never failed in the recording).
* **0 outside a race** (Alexis, 16 November 2026): every other common value reads 0 when not racing. The game leaves the
  revs at the limiter on the results screen and after GAME OVER (6,758 and 6,934 in her recordings) and the gear row
  cycles 2 to 6 in the menus; the `rpm` and `gear` rows still show that, `Car_rpm` and `Car_gear` read 0.

### Sega World Drivers Championship

**18 November 2026: the game's own data (v2.30 exe; needs plugin 0.19.0 and its helper).** The game is
Unreal Engine 4.17; its own code keeps a data model at `[[[<main>+4B07438] + 278] + 10]` with every car's
record (0x578 bytes each) and your car number, and the blueprints fill your record each frame through
UCarLibrary (SetKilosPerHour, SetShiftPosition, SetSparkLValue ...). The rows below read your record with
plugin 0.19.0's indexed offset `[-E80]*578` (your car number, read beside the records' pointer, picks the
record). **Checked in Alexis's race of 19 November 2026 (SWDC-11)**, from 35th of 45 to 16th. Notes:
`claude/SWDC-exe-20261118.md`, `claude/SWDC-capture-20261119.md`.

| Row | What |
|---|---|
| `player_no`; `cars`, `grid_no`, `player_ok` (unticked) | your car number (35 in her race; 0 in the menus and attract mode); 45 records; your record's own car number; `player_ok` 1 when the record read is yours (the game's own IsPlayer test). |
| `car_state` (unticked), `in_race`, `finished` | your car's race state: 1 through the course loading and countdown, 2 from the rolling start (the car moving at about 100 km/h), 3 from your finish line, 4 to 6 retired. **`in_race` is state 2**: every game value and every SimHub effect is 0 outside it (Alexis, 19 November 2026: from the rolling start to the line or time up). |
| `kmh`, `shift` (unticked) | the speedo's km/h (within 3 km/h of her speedo fit, up to 224) and the gear (the same as `gear2` throughout). `Car_speed` = `kmh` (**Max speed 230**), `Car_gear` = `shift`. |
| `revs`, `rpm` | the table's revs: `Car_rpm`. The record's own revs (`revs_record`, unticked) aren't the engine's (0, 8000 and odd values). |
| `brake`, `position`, `race_secs`; `overall`, `lap`, `sector` (unticked) | brake 0 to 1 (follows the pedal), your place in your class as the screen and results show it (20 to 1st in her GT300 race), the race clock from the rolling start (3:16.29 at her line), your place among every car (35 to 16), laps (0 until the start line, 4 at the finish), sector 1 to 3. `checkpoint` is 1 for a second at each sector and lap line (three a lap: the game's checkpoints; there are no time extensions). In a GT500 race the class place is mostly the place overall (GT500 runs at the front). (The lap time limit, 300 s then 180 s a lap, isn't shown on screen: dropped.) |
| `spark_l`, `spark_r`, `wall_side` (unticked) | the game's sparks on each side: they come as you downshift under braking, not at hits; not used for effects. |
| `vel_lat`, `jolt`, `car_contact`, `contact_side`, `contact_strength` (unticked) | car contacts and wall hits: the game shoves the car sideways at each (4 to 10 G over a frame or two); over 4 G while not sliding is a contact, its side the one pushed from. All twelve contacts in her race found, sides right; Car_impact (0.4 to 1 by the shove, or by the km/h lost) and Car_impact_side (from the first shove, as a rebound the other way follows it; 12 of 12 sides right in her GT300 race, 8 of 10 in her GT500 race). Head-on hits come from `hit` (the speed falling at over 4 G; 5 G while braking, as hard braking reaches 4 G). The game's wheel kicks are left out of Car_impact: they come at slips and for show. |
| `verge`, `kerb` (unticked) | from the game's vibration command: short-period pulses under 0.2 on the grass verge (Car_off_road), about 0.4 with a long period on solid kerbs (Car_rumble_strip). Painted kerbs give nothing, and on her GT500 race's course the solid kerbs gave nothing either. |
| `afterfire` (unticked), `backfire` | flames from the exhaust: 127 as they start, fading. |
| `pos_x`, `pos_y`, `pos_z`, `yaw`, `pitch`, `roll`, `travel`, `pos_kmh`, `drift_angle`, `drift` (unticked) | position (centimetres) and heading; `drift_angle` is the heading against the direction of travel, + in right-hand turns (it follows the steering); her slides reached 31 to 55 degrees. `drift` (Car_drift, Car_grip_loss) is 0.072 x (angle - 10)^0.6 x the square root of the speed over 100 km/h (up to 150), fitted to her values for seven slides (each within 0.07: 0.65, 0.53, 0.57, 0.64, 0.60, 0.69 for her 0.65, 0.6, 0.5 to 0.55, 0.6, 0.55, 0.75; 0.70 for her GT500 slide's 0.7); 0 for 0.5 s after a contact. |

Speed, revs and gear from Alexis's Cheat Engine table (`SWDC.CT`, version 2.30), added to the `SWDC`
profile alongside its force feedback rows. Checked on four recordings (3 November 2026). Since 19
November 2026 `revs` gives Car_rpm and the rest stay to compare; all of them read 0 outside the race.

| Row | What |
|---|---|
| `revs` (unticked) | engine RPM as the game keeps it: 0 in the menus, exactly 3000 while the session loads, frozen (about 9326) through the countdown to the rolling start, 3000 to 12000 while driving (never below 3000, brake held at a standstill too; redline about 11800), frozen again from the finish line. |
| (removed 19 November 2026: `in_race`, then `in_race_revs`) | 1 while racing: revs above 3000 **and still moving** (they freeze at the finish, after which speed and gear read nonsense), and the game's centring spring at its driving strength (it drops to the menu strength at the finish line). In the recordings it came on 0.1 to 0.2 s after the rolling start, went off at the finish line 0.1 s before the speed went wrong, and never went off while driving. Everything below is 0 outside a race, and the SimHub effects are off. |
| `rpm` | revs in a race, over **Max revs 12200**: the rev limiter effect (97%) starts about the redline. |
| `speed2` | speed in the game's own units (the table's speed2), over Max speed (87 was its top; Max speed is 230 km/h since 18 November 2026). |
| `gear2` | gear, 1 to 6 (the game has no neutral or reverse). |
| `speed1`, `gear1` (unticked) | the table's other speed and gear: they read nonsense in every recording (values up to 10^38), so use `speed2` and `gear2`. |
| `speed_kmh` | the speed as the speedo shows it. The raw speed isn't in proportion to the speedo (2.1 km/h a unit at low speed, 2.5 at the top), so this uses a curve fitted to 17 speedo readings: km/h = 2.0625 x raw + 0.005467 x raw², within 2.5 km/h from 0 to 220 (it read 183 where Alexis noted 183). |
| `accel_g` | forward G from `speed_kmh`, 0 for the first 0.3 s of a race. |
| `hit` | 1 for 0.3 s when the car loses speed at more than 4 G. The game slows the car at a fixed 4.6 to 5.5 G for 0.1 to 0.4 s at every wall and car hit (11 to 66 km/h lost); nothing else passed 2.9 G (grinding along a wall is about 2 G). |

* Before 18 November 2026: `Car_speed` was the raw speed (raw / 87 for `Car_speed_frac`) and `Car_gear` was `gear2`.
* `Car_impact`: hits from the speed, 0.5 to 1 by the km/h lost (0.5 + loss / 120), or a big force kick,
  whichever is bigger. The side comes only from force kicks; hits found from the speed have no side.
* `Car_vibration`: the game's own vibration command, scaled so 0.1 reads 1 (it sends 0.016 to 0.11, on
  grass verges and when grinding along a wall, more the faster you go).
* The speed in this game rises and falls in straight lines: it changes at fixed rates.
* No signal was found in memory for ripple strips, checkpoints or the finish line beyond the revs freezing (the game's own data now gives sectors, laps and the finish).
* TeknoParrot's slot 2 reads 2 for a moment at most upshifts and 1 at some downshifts (the shift
  buttons, it seems); nothing uses it.
* USB capture (a fourth recording): the decoded `force` is what the wheel got (the FFB plugin scales it by
  about 0.93), + = force from the right. The wheel's spring doesn't follow the game's spring command:
  the FFB plugin applies its own spring settings.

### GRID

Checked on seven recordings under TeknoParrot with the G25 captured over USB (3 and 4 November 2026), the
FFB plugin in its Custom mode, and Alexis's Cheat Engine work on the game's on-screen dial. **Max speed
280** (km/h) and **Max revs 6900** are set in the profile.

**The on-screen dial (4 November 2026).** The revs OutputBlaster reads with a code hook sit in GRID's
`dialinterface` object, the dash, with the other values it shows. The dial is made when the game loads, so
its address doesn't move, but the profile reads it through pointer chains that held through TeknoParrot
restarts, a reboot, other cars and tracks (`GRID.exe+B1B100` → 200 → 120 → the offset below). OutputBlaster
isn't needed for GRID: TeknoParrot only loads it for games with an Enable Outputs option, and GRID has none.

| Row | Offset | What |
|---|---|---|
| `speed` | 298 | **km/h as the speedo shows it** (the dial keeps m/s; × 3.6). Read 95.7, 156.2, 211.7 and 265.3 where Alexis noted 95, 156, 211 and 265 on the limiter in 1st to 4th; 138 and 196 in another car; 61 in reverse (it reads + in reverse). Smooth, so `accel_g` uses it. |
| `rpm` | 284 | engine RPM. It stops at each car's limiter. 1000 to 1500 in the menus and at the start line, 0 while a race loads. `rpm2` reads it by a second chain (`GRID.exe+41CA50` → 2B8 → 8 → 5E0). |
| `rev_frac` | 3B4 | revs as a fraction of **this car's** limiter (the dial's needle), 0 to 1; it never passes 1. `rev_max` = revs / rev_frac gives the limiter: 8000 for the fastest class, 8200, 7000 and 6500 in the cars tried. |
| `gear` | 278 | the gear the dial shows: 1 to 6 (the fastest class has six), -1 reverse (stored as 9). 1 at the start line; no neutral seen. |
| `throttle` | 27C | throttle, 0 to 1, as the game uses it (it follows the pedal, and the game cuts it at some gear changes). |
| `shift_lights` | 254 | the dial's shift lights, 0 to 2: one from about 85 to 88% of the limiter, both from about 95%, flashing at the limiter. |
| `distance` | 29C | metres driven in this race; 0 in the menus. |
| `dial_294`, `tacho_scale` (unticked) | 294, 370 | an unknown that follows the throttle and revs (2.5 to 2.8 on full throttle, near 0 off it); the tacho's full scale (8000 or 10000 by car). |

* **Per-car revs (plugin 0.17.0):** `car_rpm_frac` is `rev_frac`, so `Car_rpm_frac`, the rev limiter and
  the engine effects follow every car's own limiter (6500 to 8200). Max revs then only scales the `rpm` row;
  with an older plugin, Car_rpm_frac is still revs / Max revs.
* `car_throttle` is `throttle`: the engine effects run at 60% off the throttle (plugin 0.14.0).
* The old rows stay, unticked, for comparison: `wheel_speed` (the old `speed`: driven-wheel speed, which shows
  wheelspin and locked brakes and reads 0.8 to 1.0 of the speedo by car) and `gear_abs` (the old `gear`: one
  less than the dial's gear, 0 in reverse, an absolute address that read 1 all race once).
* Pausing freezes every value; `racing` (below) now stops the effects while paused, in the menus and at the line.

**From the game's own code (`GRID.exe`, 12 November 2026), checked in Alexis's recordings of 12 November 2026** (an attract
mode recording, and one with two races: the first with a hard stop, a pause and a hard hit before TIME OVER, the second
three laps finished 2nd). The exe keeps no class names, but its commentary system and HUD code show what the dial's
neighbours are; all on the same `GRID.exe+B1B100` → 200 → 120 start as the dial rows:

| Row | Chain after 200 → 120 | What |
|---|---|---|
| `brake` | 280 | the brake, 0 to 1, as the game uses it: it followed the G25's pedal (0.95); 1 while the game holds the car after TIME OVER. |
| `race_on` | 210 → 1F8 → 21A0 → 108 | 1 from GO until the race is cleared in the menus (it stays 1 after the line). |
| `race_over` | ... → 109 | 1 at TIME OVER, and 1.1 s after the player's finish line. |
| `race_clock` | ... → 120 | **the TT on screen**, seconds (kept in microseconds): 0 until GO, still while paused (42.235 where her pause screen read 0:42.21), held from `race_over`. |
| `race_laps`, `car0_laps` | ... → 10C, 178 | laps in the race; laps the player has completed (**car 0 is the player**: the dial follows car 0, and the game takes her controls at car 0's last line). |
| `car0_lap_time` | ... → 190 | the player's own race time: `race_clock` until the finish, then held at the finishing time (3:18.777; 3:18.77 on screen). |
| `steer` | 258 → E30 | steering, -1 left to 1 right (the game keeps it the other way round; checked against the G25's own steering). |
| `racing` | | 1 from GO to the finish line: race on, not over, laps to go, race clock moving. **Feeds Car_in_race**: off while paused, at TIME OVER, at the finish line (the exact sample the game took the car) and in the attract mode and menus. |
| `lap`, `final_lap`, `lap_line` | | the lap (1 to the laps in the race), 1 on the last lap, 1 for 1 s at each lap line and the finish. |
| `veh_id`, `hud_mode`, `race_cars`, `race_type`, `car0_on`, `car0_lap` (unticked) | | the car the dial follows (0), the HUD's mode, 6 cars in a race, how the race ends (1), car 0's racing flag and lap counter (-1 before the start line). |

* The damage rows are gone: they read nothing (GRID arcade has no damage; Alexis).
* **0 outside a race** (Alexis, 16 November 2026): every common value but Car_in_race reads 0 when not racing (the revs
  idle in the menus before; the `rpm` row still shows them).

**Open (GRID parked, 16 November 2026):** the time left and checkpoints (below: a Cheat Engine pointer scan), `position`,
`leader` and `game_mode` to read in a recording, and a source for the side of car hits.

**Position and game mode (`GRID.exe`, 16 November 2026), not yet read in a recording.** The HUD's race position element
reads the place from the HUD's +C0 → +4: a list of up to three players, one per linked cabinet (0x70 bytes each from +8;
+15C how many, +170 which is this cabinet's). Each player's +6C is its place, counted from 0. Unticked raw reads `place0`,
`place1`, `place2` (210 → C0 → 4 → 74, E4, 154), `me` (... → 170), `players` (... → 15C) and `my_car` (... → 1C, the first
player's car record); `position` (1 = first) and `leader` from them. `game_mode` (210 → 1F8 → 21C4 → 10 → 48 → 0 → C → 54)
is 7 for a Championship and 8 for a Quick Race.

* **Time left and checkpoints:** the arcade countdown is `StateRaceCountdown` in the game's state machine: +3C the time
  left (float seconds, counted down each frame; each checkpoint's bonus added), +E8 the checkpoints passed, +30/+34 the
  levels where the cabinet's clock sounds change. In Championship and Quick Race it lives only there, and the state hangs
  off the game's state tree, which no fixed chain reaches. A Cheat Engine pointer scan is the next step (the linked mode
  keeps its time on a shared clock object instead, context +58 → +1110 → +10 → +1C4).

**Force feedback and hits.**

* **USB matches.** The force the G25 got is what the FFB plugin's Custom mode works out from the values
  in this profile: at a wall hit, `hit_strength` / 8 pushed from the side `wall_side` gives
  (`impact_side`; the same value one USB poll later in 88 to 95% of hit frames, and the rest are the
  first and last frame of a hit, a gear-change sine on top, or 0.03 more during car contact); a 0.49
  sine for 70 ms at every gear change; a small sine on kerbs (`road_rumble` 1 or 2 of 37). The skid and
  car-contact rumble the plugin sends doesn't reach a G25.
* **Sides**: + is a right-hand wall, as with the other games. Wall hits read the right side. In car
  contact `wall_side` flips back and forth, so a car hit's side is only sometimes right.
* **`car_contact` is a count**, not a side: 1, then 2 and up to 5 in a pile-up, counting back down.
* **What reads 0**: scraping along a wall, slow touches and some car contacts set no `hit_strength`, so
  no `Car_impact`. A rear-end hit with the brakes locked isn't in any game value either.
* `car_road_bump` and `car_cornering` are 0 rows: the force carries no road texture or cornering, so
  filling them from the USB force (plugin 0.15.0) would turn gear changes into bumps and wall hits into
  cornering.

### GTI Club Supermini Festa

From Alexis's Cheat Engine table (`GTIclub.CT`, in the profile's folder) and a read of the game's own code
(`gti3japkey.exe`, 8 November 2026), then **checked in Alexis's recording** of the same day (a 3-lap race on the
intermediate course, manual gearbox): speed, revs, tacho, gears, position, laps, lap times and the finish all
matched her notes. The exe isn't packed and always loads at the same address, so `<main>` here is fixed.
**Max revs 7500** is the game's own limiter (the tacho needle bounces above it, the same for every car; the engine
itself reaches about 8000 with the wheels in the air). **Max speed 160** km/h is a little under the 163 km/h she
reached.

* **The player car**: `<main>+67FCC8` holds a pointer the game sets when a race is set up (to the car + 0x300).
  The table's speed, revs and gear rows were all this car's dash, reached by several routes; the profile uses
  this one. The game never clears it, so between races it points at the last race's car: the car rows read 0
  unless the race state says a race is loaded.
* **Race state** `<main>+67FAC8` → 2C8 → 34, with the game's own names: 3 countdown, 5 go race, 6 wait time up,
  7 goal wait, 8 time up, 10 to 12 the ranking display, 13 the result display, 14 end race. Not readable outside a
  race. The game stays in state 5 after the finish and drives your car on its own for about 20 s, so `in_race` is
  state 5 until `finished`.
* **The race display** `<main>+680460`: the race code copies its time left (milliseconds) to +2C4 every frame, and
  the mph setting to +244. `<main>+67FB98`, which the first version of this profile read, is the variety modes'
  timer and read 0 in a race. **The time left is still to be checked in a recording.**

| Row | From | What |
|---|---|---|
| `speed` | car +648 | the speedo's speed, always km/h (with the display set to mph the game converts it only on screen). The game caps it at 220 km/h. |
| `true_speed` | car +1A4 | the car's real speed, km/h (m/s × 3.6), not capped; `accel_g` and the hit sizes use it. |
| `rpm` | car +174 | engine revs (revs a second × 60): what the tacho follows. `rpm_tacho` (+B8) is the tacho's smoothed reading. |
| `gear` | car +644 | the gear the dash shows: 1 up, -1 reverse. `gear_stored` (unticked) matched it throughout. |
| `gearbox` | car +F1 | 1 with the manual gearbox; probably 0 with the automatic. |
| `position`, `leader` | car +CB8 | race position, 1 = first; `leader` is 1 while you lead (for a lamp). |
| `laps_done`, `laps_total`, `final_lap`, `finished` | car +CBC, `<main>+549458`, car +CC8 | laps completed, laps in the race (3 by default), the last lap, over the line. |
| `lap_time`, `last_lap` | car +CE8, +CCC to +CE4 | the current lap (the game counts 30 a second) and the last completed lap, seconds. |
| `time_left`, `checkpoint`, `hurry` | race display +2C4 | the time left, seconds; `checkpoint` is 1 for a second when time is added, `hurry` in the last 10 s. `speedo_mph` (unticked) is +244. |
| `game_mode` | `<main>+67FAC8` → 90 | the game mode: 0 in a race; the variety modes' numbers are still to be found. |
| `surface1` to `surface4` | car +42C to +438 | the surface under each wheel (1 and 2 are the front pair; left and right not known yet): low byte 1 road, 2 kerb. The upper bits change as the wheels cross the lip of a jump. |
| `kerb` | the surfaces | wheels on a kerb, a quarter each: feeds Car_rumble_strip. `rough_ground` (code 5, which the game also rumbles on) never showed and feeds Car_off_road. |
| `landing`, `car_hit`, `wall_hit`, `crash` | the force packet | the jolts the game sends its vibration motor, told apart by their level (`jolt`, unticked): 50 a landing, 36 another car, 63 a full-stop crash, 10 to 27 a wall or mounting a kerb. A kerb jolt comes with a wheel already on the kerb, so `wall_hit` is a 10 to 27 jolt with no wheel on a kerb (`wall_jolt`, unticked), or one that costs more than 8 km/h within 0.3 s (a wall while riding a kerb). |
| `hit` | the above | walls and other cars, 0.5 to 1 by the km/h lost (0.5 + loss / 60), 1 for a crash: feeds Car_impact. Landings feed Car_road_bump. No side for any of them. |
| `force_angle` | car +238 | the angle the game makes the wheel force from; perhaps slip or steering angle. |

* **The force packet** (`<main>+518CBC`, 4 bytes; the FFB Arcade Plugin's addresses): the force, signed (-127 to
  127); the vibration in the low 6 bits of the second byte (`vibration` masks the top two, `ffb_flags`, which
  stayed 0); the vibration pattern in the third (`ffb_other`: 15 for jolts, 11 to 14 kerb rumble); a constant in the
  fourth.
* In the recording, 13 of 13 landings, 14 car hits, 17 wall hits (including the RHS wall at 99.42 s, which cost no
  speed) and the barrier crash each came through once, and the 4 kerb jolts (148.20 s: the rear right onto the LHS
  kerb) didn't count as hits.
* There's no `car_impact_side`: the wheel force gave no side at the walls, so with USB capture on the plugin takes
  a hit's side from the wheel force.

### Initial D Arcade Stage 6 AA

From a read of the game's own code (`InitialD6_GLW_RE_SBUU_dump.exe`, 8 November 2026): **v1.2**, the build
OutputBlaster calls "Initial D 6 AA Updated" (its checksum 0x08D4BACE; built 15 August 2011), then **checked in
Alexis's recordings** of 9 November 2026: the story prologue against the computer in an R32 GT-R (manual, 30 readings
off the screen) and an AE86 Trueno, and a time trial on Irohazaka in a Civic (automatic, with notes), all with USB capture. The force feedback comes from TeknoParrot's shared memory, as before (it matched the
wheel's USB force, r 0.998). The memory rows check the exe's build stamp (`v12`) and read 0 on another version.
Process is set to `InitialD6_GLW_RE_SBUU_dump.exe`: change it if yours is named differently.

* **The way in**: the game session at `<main>+C6E210` → its race at +20C. The race keeps its state at +4 (2 set-up,
  3 the rolling start and countdown, **4 racing**, 5 a car has reached the goal, 6 after), the player's slot at +34
  (0 or 1; 0 in the story), and the two cars at +28 and +2C. Each car's physics and status hang off it, so every car
  value is read for both slots (`speed_0`, `speed_1`..., unticked) and the row without a number is yours. Car values
  read 0 outside a race.
* **Max speed 220, Max revs 8140**: the R32 GT-R and the AE86 Trueno both limit at 8140 engine revs (the Trueno's rev
  counter reads 8k there); the Trueno reached 215 km/h. Tuned cars will go a little faster.

| Row | What |
|---|---|
| `speed` | km/h: the speedo, within 1.5 km/h at all 30 readings. |
| `rpm`, `rpm_tacho` | `rpm` is the revs on screen (within 350 at every GT-R reading away from a shift; the Trueno's counter reads 8k on the limiter; idle 800). `rpm_tacho` is `rpm` times a factor for each car (1.08 GT-R, 1.23 Trueno, 1.035 Civic), not what the screen shows. |
| `gear`, `shift` | the gear (1 up), right at every reading; at a shift the game's value changes a frame or two after the screen. `shift` 1 for 0.2 s after a change. |
| `throttle`, `brake` | the pedals as the game uses them, 0 to 1. `car_throttle` follows the throttle. |
| `drift_angle` | the drift angle in degrees, from the game's physics (car physics +7C4: where the car points, less the direction it's going, the angle the game works its sideways grip from); + a right-hand drift (the car pointing right of its path), - left; 0 below 10 km/h. Under about 7 degrees in ordinary cornering, 15 to 20 in a gentle drift, 25 to 40 moderate, about 50 extreme. **Checked in two drifting recordings** (9 November 2026: an RX-7 on Akina, an Impreza on Irohazaka in the wet): every drift read the right way. |
| `car_drift` | Car_drift, 0 to 1: the drift angle (nothing under 5 degrees, full at 50) times the speed (nothing under 20 km/h, full from 120 km/h). An extreme drift through a 70 km/h hairpin reads about 0.5, a moderate one about 0.4. Car_grip_loss follows it, as ID6 has no slip value of its own. |
| `race_state`, `in_race`, `countdown_live` | the state above; `in_race` is state 4, from the race clock's start to the finish line (and throughout a time trial). In the rolling start the car is driven at 170 to 185 km/h with live revs for the last 6 s of the countdown: `countdown_live` is that, and Car_in_race includes it so the engine effects start with the engine. |
| `events` | the car's event flags from the last frame: the game plays its collision, gutter, landing and joint sounds from them. Decoded as `wall_left`, `wall_right`, `wall_front` (walls and guard rails), `car_contact`, `gutter`, `leaves`, `road_joint`, `gutter_drop`, `drain`, `oil`. The recordings had walls and guard rails both sides, the other car, the gutter and leaves; the rest are from the code, not seen yet. |
| `landing` | 1 for 0.25 s as the car lands: the game sets its landing bit then and leaves it on until the car next leaves the ground, so only its start counts. All three landings on Irohazaka came through. |
| `rumble_strip` | ripple strips: the game's vibration command at level 10 (its period follows the speed), held 0.3 s. Every strip marked on Irohazaka came through; the event bit for them never came on. |
| `leaves` | a wheel in the leaves at the side of the road (Irohazaka); feeds `rough_ground`. |
| `gutter` | a wheel in the roadside gutter (bits 0x1 left, 0x2 right). Most wall hits come with it (the gutter runs along the wall); on its own it is the wheels running in the gutter. |
| `hit`, `hit_side`, `wall_contact` | `hit` 1 for 0.3 s from the start of a contact with a wall, guard rail or the other car; touches less than 0.15 s apart count as one, so a grind along the other car (its flag drops out for a frame every 0.2 s) is one hit. `hit_side` the side of the last wall touched; `wall_contact` scraping a wall for 0.3 s or more (+1 right, -1 left). |
| `rough_ground` | the gutter, a drain cover or leaves (feeds Car_off_road). On Irohazaka a wall flag on the same side often comes with the leaves, with the game's wall-scrape vibration, so those count as wall contacts too. |

* **Common values**: Car_impact is a contact, 0.5 to 1 by the km/h lost (the 202 km/h wall at 12.3 s read 1, a touch
  of the other car 0.5); Car_impact_side the wall's side (0 for the other car: the game gives no side for it);
  Car_wall_contact; Car_off_road in the gutter; Car_vibration the game's own vibration, scaled so its strongest (as a
  wheel drops into the gutter) reads 1; Car_road_bump from road joints and landings, Car_rumble_strip from rumble
  strips; Car_cornering from the wheel force; Car_drift and Car_grip_loss from `drift_angle` (plugin 0.18.0).
* In the recording, all 17 contacts came through once each (the 11 she noted, plus two touches of the right wall in a
  drifting right turn and the other car pushing past against the left guard rail), the gutter alone (right tyres at
  102.8 s, left at 120.9 s) read as rough ground with no hit, and the grind along the other car from 86.9 to 89 s was
  one hit.
* **Lamps** read memory for both versions (the addresses OutputBlaster uses for v1.0 and v1.2), so OutputBlaster
  isn't needed for them. On v1.2 the start lamp blinked in attract and the select lamps on the card screens.
* Not found yet: time left, laps, position and the gap to the other car.

### Initial D Arcade Stage Zero v2.30

From a read of the game's own code (`InitialD0_DX11_Nu.exe`, v2.30, 64-bit, MD5 2e506fe5e3d36fc4eff0d44389f4757b,
16 November 2026), then **checked in Alexis's recordings** of 16 November 2026: the story's intro race for a course (the
tutorial, game mode 16) against the computer in an AE86 Trueno, manual, with two how-to demos; and an Irohazaka downhill
time attack in a Savanna RX-7, automatic, with force feedback on; and a story race on Akina Lake in a Nissan Silvia,
automatic, with five rev counter readings. USB capture in all three. It is the same engine as Initial D 6
(the same class names survive: cGameSession, cRace, cActor, cMoriCar), so the rows follow ID6's: every car value is read
for both of the race's slots (`speed_0`, `speed_1`..., unticked) and the row without a number is your car's. Car values read
0 outside a race and in the attract demo's replays.

**Segatools or TeknoParrot:** both run the same `InitialD0_DX11_Nu.exe`, and every row here (the force feedback too)
reads the game's own memory, so the profile works the same either way: TeknoParrot's shared memory isn't used. The rows
assume the same build of the exe (the FFB Arcade Plugin's force address for v2.30 matches this one); on a different build
they read nothing. OutputBlaster has no v2.30 entry, so the lamps are made from race values (below).

* **The way in**: the game session at `<main>+18B4E50` (the cheat table's base too) → its race at +290. The race keeps
  its state at +8 (2 set-up, 3 intro and countdown, **4 racing**, 5 a car has reached the goal, 6 race over), the race
  clock at +24 (ms from GO), time left at +178 (ms: the table's "Stage_Tmr"), the gap to the rival at +18, the player's
  slot at +4C and the two cars at +38 and +40. Game mode at session +8.
* **Max speed 220, Max revs 8140**: the Trueno reached 203 km/h and limits at 8,140 engine revs (its rev counter bounces
  7.7k to 7.9k there); the automatics' counters show less (see `rpm`).

| Row | What |
|---|---|
| `speed` | km/h: the speedo, to the km/h at all five of Alexis's readings. |
| `rpm`, `rpm_auto`, `rpm_tacho` | `rpm` the rev counter. With a manual gearbox it is the engine's revs; with an automatic the game keeps them elsewhere (`rpm_auto`) and the counter shows 0.885 of that (the Silvia's counter at five readings: within 60 revs). `rpm_tacho` is the revs times a factor for each car (1.21 Trueno, 0.99 Silvia), not what the counter shows. |
| `gear`, `shift` | the gear (1 up; manual 1 to 5, automatic 1 to 4); `shift` 1 for 0.2 s after a change. |
| `throttle`, `brake`, `steer` | the pedals and steering as the physics uses them. `steer` is + right (the game's own value is + left, so it's turned round); it follows the wheel at a quarter to a third of its turn, as the game eases steering with speed. |
| `drift_angle` | the drift angle in degrees, from the physics (car physics +8F4, as ID6's +7C4): + a right-hand drift, - left (checked on two right and two left bends). 15 to 30 degrees in the Trueno's quick bends, up to 68 in the RX-7's hairpins. Car_drift uses ID6's weighting (Alexis: the Trueno's 0.4 to 0.8 feel right). |
| `race_state`, `state`, `in_race` | the race's state and your car's (4 racing, 5 over the line, 6 race over); `in_race` from GO to your finish line, off while paused (the tutorial's how-to demos stop the race clock) and in the attract demo. |
| `game_mode` | 1 test, 2 time attack, 3 story, 4 in-store VS, 5 online battle, 7, 9 and 11 the attract demo's replays, 15 2-on-2 VS, 16 tutorial (the story's intro race), 17 beginner online. |
| `race_clock`, `time_left`, `checkpoint` | the race time (TT) and time left (RT), seconds; `checkpoint` 1 for 2 s as a checkpoint's extension is added (all six in the recordings). |
| `gap`, `leader` | the distance to the rival along the course, + ahead (probably metres); `leader` while ahead: right at all three of Alexis's place changes. Against a rival only: time attack keeps an unseen second car, so they read 0 there. |
| `events` | the car's event flags from the last frame, the same bits as ID6: `wall_left`, `wall_right`, `wall_front`, `car_contact`, `gutter`, `leaves`, `road_joint`, `gutter_drop`, `drain`, `oil`, `landing`. Walls, guard rails and the other car came through on the sides Alexis gave; leaves alone never count as a hit. |
| `landing` | 1 for 0.25 s as the car lands: both jumps (Trueno) and both kerb drops (RX-7). |
| `rumble_strip` | ripple strips, from the game's own vibration at level 5 (2 is contact with the other car, 4 scraping a wall or guard rail): all five in the Trueno race. Irohazaka's painted strips play a striped-surface sound (`area` 2) but don't shake, so they don't count. |
| `area`, `grass` | the surface the game plays a looping sound for: 1 leaves, 2 striped surface, 3 the sound named "glass area" (probably grass; not seen yet), 4 the road gutter. |
| `hit`, `hit_side`, `wall_contact`, `rough_ground` | as ID6's. Bumping and leaning on the other car counts a hit each time the game's contact flag comes back. |
| `lampleader`, `lampcheckpoint` | lamps made from race values (Alexis): the leader lamp while you lead the rival (from GO in time attack, where you run alone; it keeps the standing past the line until the race is over), the checkpoint lamp for 2 s at each Extended Time!. |

* **Common values**: as ID6's (Car_impact by the km/h lost, its side from the wall flags, Car_wall_contact,
  Car_road_bump from joints and landings, Car_rumble_strip, Car_off_road, Car_drift and Car_drift_angle,
  Car_throttle). Car_cornering comes from the steering and speed (the steering over 0.3 times the square root of the
  speed over 120 km/h, + right): hard bends read 0.6 to 0.9, where the game's own wheel force only reaches about 0.3. Every
  common value but Car_in_race reads 0 outside a race, as on Sega Rally 3 and GRID.
* The cheat table's two other reads are kept, unticked: `menu_timer` (the menus' countdown) and `hud_meter` (its
  "Steering" value, which belongs to the race display, not the wheel).
* Force feedback: the game's force agrees in direction with the wheel's USB force (the RX-7 recording).
* **Force feedback feel** (Alexis, Silvia race): kicky while drifting, little at wall hits, not strong. That is the game's
  own force through segatools: the game's constant force tops out at about a quarter of full strength, and it often sends
  nothing at a wall. The effects don't use it (hits come from the game's contact flags; Car_cornering from the steering).
* Still to see: grass, drains, oil, road joints by name.

### Initial D Arcade Stage Ver. 3 (Flycast)

`FLYINITD3`, from Flycast's copy of the game's memory (17 November 2026). Process `flycast.exe` (64-bit); choose the
game in the Game list as before. Needs **plugin 0.18.2 and helper 0.17.1** (the race rows follow the game's own pointers).
For Flycast v2.7-1-g44e4c7b50 (`flycast.exe` MD5 d8db8f697e26e5384a186eb2c8b79289; 19 November 2026) and the export game
(`initdv3e`). Before 19 November the pack was for v2.5-219-g27a913fc0, whose pointer was `<main>+2840C90`.
Max speed 205, Max revs 9000. Checked in Alexis's recordings of 17 November 2026: five cars, Akina Lake, Irohazaka, Akagi
and Myogi, story and time trial, manual and automatic, through the finish line and time up.

| Rows | From | Checked |
|---|---|---|
| `speed` (km/h), `rpm`, `gear`, `accel_g`, `gap` (ADVANTAGE, m) | the player's car, a fixed structure in the game's memory | save states' screens and every recording |
| `thr_revs`, `rpm_top`, `rev_limit`, `rpm_frac`, `throttle`, `steer` | the same structure | throttle and steering against the wheel over USB; rev limits 7000 to 9000 by car |
| `rt` (time left), `race_clock` (TT), `lap`, `race_ok` | the race object, through the game's own pointer to it (`@` offsets) | three save states and a whole race: 90 s at the start, both lap-line extensions, laps 1 to 3, the clock stopping at the line |
| `live`, `racing` | car on the road; out of neutral (GO) with the race clock moving | GO, the finish line, time up, nothing in the menus |
| `lampleader`, `lampcheckpoint` | made from the race values: ahead or level from GO (lit through a time trial; held until the race is cleared); 2 s when the time left jumps up | the lead changes in a story race; both lap lines |
| `contact`, `kick_x`, `kick_y`, `contact_side`, `wall_contact`, `hit`, `hit_side` | touching a rail, wall, gutter edge or the rival, and the knock it gives (- left, + right) | the contacts Alexis described: the side right in six of seven |
| `rumble_strip`, `gutter`, `grooved_road`, `wheel_a` to `wheel_d` | what each wheel is on: 20 ripple strip, 18/32/48/49 gutter or kerb, 21 grooved concrete | named by Alexis on Akagi, Irohazaka and Myogi |
| `yaw`, `move_x`, `move_z`, `drift_angle`, `drift_curve`, `drift` | the car's heading against its travel; ID6's drift curve made full at 45 degrees | + in right-hand drifts; her hardest drifts read 0.62 (her target 0.6 to 0.65) |
| `ram_probe` | the first four bytes of the game's program (game address 0x0C020000) | 3509307139 on every sample of eight recordings: a check that the memory read works, for testing newer Flycast builds |
| unticked rows from `steer_raw` to `misc_1e8` | the car structure and nearby | candidates, not identified |
| `ffb_raw`, the force rows, `lamp0` to `lamp7`, `lamp_bits` | Flycast's outputs (Broadcast Digital Outputs) | arrive; bit 3 blinks through the race, no bit follows the lead |

* Car_in_race, Car_speed, Car_rpm, Car_gear, Car_accel_g, Car_throttle, Car_rpm_frac, Car_impact, Car_wall_contact,
  Car_rumble_strip, Car_off_road (gutter), Car_drift, Car_drift_angle, Car_grip_loss and Car_cornering (from steering
  and speed) come from memory; all but Car_in_race read 0 outside a race.
* **Broadcast Digital Outputs is optional.** With it off, `ffb_raw` and the rows made from it, the `lamp` rows, and
  Car_road_bump and Car_vibration read 0; everything else, both made-up lamps included, still works. With the FFB Arcade
  Plugin's files in Flycast's folder the game froze in the menus when outputs were on; removing them stopped it.
* Flycast's emulated RAM is `<main>+29D0C10` -> + (game address & 0x1FFFFFF) in v2.7-1. Another build may keep the pointer
  elsewhere: `ram_probe` reading a steady 3509307139 means it reads; 0 or an error means the pointer has to be found again.

### Daytona USA 2 Power Edition (Supermodel)

`SMDAYTO2PE`, from Supermodel's copy of the game's memory (18 November 2026). Process `supermodel.exe` (64-bit); choose
the game in the Game list as before. For the same Supermodel build as Scud Race (git 0b82a98, MD5
440c8330529f89714047740b9b45831e) and the `dayto2pe` ROM set (with its parent `daytona2`). Max speed 350, Max revs 8500.
`SMDAYTONA2` (force and lamps only, for the original Daytona USA 2) is unchanged. Found by running the same Supermodel
source on Alexis's ROM sets and NVRAM (the Beginner course, Three Seven Speedway, 8 laps, with an autopilot, against the
screen), then checked in Alexis's three recordings of 18 November 2026: Advanced (NORMAL, manual), Expert (HARD, manual),
Beginner (SPECIAL, automatic, with a pit stop, to the finish line); and two on Mixed on the limiter (EASY and SPECIAL,
manual).

| Rows | From | Checked |
|---|---|---|
| `speed` (km/h), `rpm` (the rev counter), `rpm_wheels`, `gear`, `accel_g`, `throttle`, `brake`, `steer`, `car_class`, `rev_limit`, `rpm_frac` | the player's car record (game address 0x501000, 0x1000 bytes; the 39 computer cars follow it) | speed at 14 screen readings; gears 1 to 4; steering, throttle and brake against the wheel over USB (0.92 to 0.98, 0.76 to 0.95, 0.71 to 0.81); the manual limiter 8,500 (NORMAL and HARD; about 8.2k on the dial), 10000 a ceiling changing down too fast (8.8k on the dial); the SPECIAL automatic changes up at about 7,400 (7.3k on the dial); `car_class` 0 EASY, 1 NORMAL, 2 HARD, 3 SPECIAL; `rpm` is the rev counter's value (+0x1E0): it shows wheelspin and clutch slip at a standing start (8,500 with the dial stuck at 8.2k), where `rpm_wheels` (+0x1DC, the profile's `rpm` until 19:10) doesn't; limiters: NORMAL and HARD 8,500, EASY and SPECIAL 7,650, so Car_rpm_frac reaches 1 on every car |
| `playing`, `countdown`, `racing`, `finished`, `pit_stop` | the in-game flag (255 from the course select until the clock stops), the clocks, the time left standing still | the rolling start and the grid to GO; GO to the finish line and to time up in her recordings; 0 in the attract mode; her pit stop |
| `rt` (time left), `race_clock` (TT), `lap`, `lap_start`, `lap_time`, `best_lap`, `last_lap`, `position`, `time_extended` | the race globals and the car record (frames, 57 to the game's second) | 60 s at the start, extended at the lap lines; laps 1 to 8; last laps against the screen (18"626...); 15 position readings |
| `move_x`, `move_y`, `move_z`, `head_x`, `head_z`, `drift_angle`, `drift` | the car's movement each frame against its heading; Car_drift from 10 degrees, eased, full at 82 | + right in her drifts; her three drifts read 0.46, 0.84 and 1 (she asked for about 0.45, 0.8 and 1) |
| `crash`, `seg`, `seg_fl` to `seg_rr`, `edge_left`, `edge_right`, `wall_contact`, `near_car`, `car_contact`, `car_touch`, `hit`, `hit_side` | the crash timer, the strip of road under the car and each wheel, another car within about 5 m, how hard another car touches (no side) | big crashes and their sides (four, as she saw them); car contact at her car-hit marks, its side from the game's roll command (four of four; none for front-corner hits); no hit braking into the pits |
| `ram_probe` | the game's code at game address 0x100 | 2087778982 in all her recordings |
| unticked `speed_2cc` | the car record | a candidate, not identified |
| `ffb_cmd` and the force rows, the `lamp_` rows | Supermodel's outputs (`-outputs=net`) | as Scud Race; `force` lasts 0.1 s after each roll command |

* Car_in_race, Car_speed, Car_rpm, Car_gear, Car_accel_g, Car_throttle, Car_impact, Car_wall_contact, Car_drift,
  Car_drift_angle, Car_grip_loss and Car_cornering come from memory, from the start to the finish line or time up; all
  read 0 outside it. No Car_airborne (no jumps on the oval). Car_road_bump and Car_vibration come from the outputs.
* **`-outputs=net` is optional**: without it the force rows and the lamp rows read 0, and car hits have no side.
* Car hits take their side from the game's roll command; hits on the front corners send another command and have no side
  (with USB capture on, the plugin then takes the wheel's kick).
* Effects run through the grid (Car_throttle 1 there, so the engine follows the revs, as Scud Race), the rolling start,
  the pit stop and the game's drive out of the pit lane (Alexis, 18 November 2026).
* Supermodel's RAM as in Scud Race below; `ram_probe` reading a steady 2087778982 means it reads.

### Scud Race (Supermodel)

`SMSCUD`, from Supermodel's copy of the game's memory (18 November 2026). Process `supermodel.exe` (64-bit); choose the
game in the Game list as before. For Supermodel 0.4-dev, git 0b82a98 of 16 November 2026 (`supermodel.exe` MD5
440c8330529f89714047740b9b45831e), and the `scudau` ROM set (Scud Race, Australia, Twin/DX). Max speed 350, Max revs 9500.
Found by running the same Supermodel source on that ROM set (driving the Beginner course with an autopilot, against the
screen), then checked in Alexis's four recordings of 18 November 2026: Porsche and Viper (manual) on Beginner night, McLaren
(manual) on Medium, F40 (automatic, with a pit stop) on Expert.

| Rows | From | Checked |
|---|---|---|
| `speed` (km/h), `rpm`, `gear`, `accel_g`, `throttle`, `brake`, `steer` | the player's car record (game address 0x181000, 0x300 bytes; the 39 computer cars follow it) | speed at 34 screen readings; gears 1 to 4 manual and automatic; throttle and steering against the wheel over USB (0.85 to 0.98); the brake reads from about half pedal |
| `car`, `rev_limit`, `rpm_frac` | the car number (4 Porsche, 5 Viper, 6 F40, 7 McLaren) and each car's limiter | limiters 7200 (Porsche, Viper), 8500 (McLaren) and 9040 (F40, TT 0:15.30 in her fifth recording, about 9k on its dial); `car` 6 in her F40 recordings |
| `state`, `phase`, `countdown`, `racing`, `grid`, `final_position`, `finished`, `pit_stop` | the race sequence word (whose top byte is your finishing place, set where the clock stops) and the clocks | GO or the rolling start's 3-2-1 to the finish line or time up in all four, within 0.04 s; 21st, 33rd, 29th, 20th; the F40's pit stop |
| `rt` (time left), `race_clock` (TT), `lap`, `lap_start`, `lap_time`, `best_lap`, `last_lap`, `position`, `retire`, `time_extended` | the race globals and the car record (clocks in frames, 57 to the game's second) | 60 s at the start; +26.67 s at Beginner night's lap lines, +14.23 s at Medium and Expert checkpoints; laps 1 to 4 and the finish (TT 2:18.42) |
| `move_x`, `move_y`, `move_z`, `airborne`, `light` | the car's movement each frame; in the air it falls by the game's gravity; going light over a crest it falls at 0.7 g or more | her jump marks in three recordings; the front wheels lifting at TT 1:03.3 (Car_airborne 0.5) |
| `head_x`, `head_z`, `drift_angle`, `drift` | the car's heading against its travel; Car_drift straight from 14 to 58 degrees, 0 going backwards | + with the wheel turned right (her left and right drifts); her two F40 drifts read 0.9 and 0.65 as she asked |
| `crash`, `seg`, `seg_fl` to `seg_rr`, `edge_left`, `edge_right`, `wall_contact`, `car_contact`, `car_side`, `car_touch`, `near_car`, `hit`, `hit_side` | the game's crash timer (big crashes), the strip of road under the car and each wheel (a wheel against a wall is on another), and which side another car touches | big crashes; car contact ahead, left and right and wall hits left and right, in the order she gave (F40 recording); a grass verge still reads as the wall on the other side |
| `wrong_way` | the road strip numbers running backwards | REVERSE! after a spin in the Porsche recording (TT 1:35.14) |
| `ram_probe` | the game's code at game address 0x100 | 2087778982 in all four recordings |
| unticked `flag_38c`, `area_388`, `grip_258`, `engine_334`, `speed_338`, `misc_2c4` | the car record | candidates, not identified (`misc_2c4` is not the wheels' angle after all) |
| `ffb_cmd` and the force rows, `lampstart`, `lampview1` to `lampview4`, `lampleader` (called `lamp_start`... before 19 November 2026), `lamp_bits` | Supermodel's outputs (`-outputs=net`) | arrive; View3 (and once View4) light in the race; `force` lasts 0.1 s after each roll command, as the wheel force over USB showed |

* Car_in_race, Car_speed, Car_rpm, Car_rpm_frac, Car_gear, Car_accel_g, Car_throttle, Car_impact, Car_wall_contact,
  Car_airborne, Car_drift, Car_drift_angle, Car_grip_loss and Car_cornering (from the steering and speed) come from memory;
  all but Car_in_race read 0 outside a race. On the grid (Medium and Expert) Car_rpm and Car_gear run and Car_throttle
  reads 1, so the engine effects follow the revs alone (Alexis, 18 November 2026). Car_road_bump and Car_vibration come from the drive board commands (outputs).
* **`-outputs=net` is optional** for this game: without it only the force rows and the lamp rows read 0.
* Supermodel's RAM: `[[<main>+AE6280] + 8] + game address` (the PowerPC core's fetch regions; region 0 is RAM). The
  PowerPC is big-endian and Supermodel keeps RAM as 32-bit words in the PC's order, so a byte at game address A is read at
  A ^ 3 and a 16-bit value at A ^ 2 (the Offsets column already has this). Another build may keep the pointer elsewhere:
  `ram_probe` reading a steady 2087778982 means it reads.
* With a fresh NVRAM the game stops at NETWORK BOARD NOT PRESENT: set LINK ID to SINGLE in the test menu's GAME ASSIGNMENTS.

### Battle Gear 4 Tuned

From a read of Alexis's `game.exe` (9 November 2026): OutputBlaster's checksum 0xBAFACA7B, its "Battle Gear 4 Tuned",
the Japanese version the FFB Arcade Plugin supports (built 18 June 2007, not packed). Her FFB plugin (`d3d9.dll`, GameId
13) and OutputBlaster hold the same addresses the profile already had. **Checked in her recordings of 10 November 2026**
(a Golf GTI race with four cars, a fast car's time trial to the finish, reverse in a Trueno).

* **The cars**: 8 records of 0x1BE0 bytes from `<main>+42EA90`; the player's number is at `<main>+494808` (0 in her
  recording). Like the FFB plugin, the profile reads car 0.

| Row | From | What |
|---|---|---|
| `speed` | car +24C | km/h: what the speedo shows (the game keeps it signed; the speedo shows its size). `speed_ffb` (unticked) is the FFB plugin's speed: the same value. |
| `rpm` | car +254 | engine revs: 700 at idle, capped at the car's own limiter (Golf GTI 7500, Citroën about 8000). |
| `gear` | car +260 | -1 reverse, 0 neutral, 1 to 6. Int32: as a Byte, reverse read 255. |
| `position`, `leader` | car +18C | race position, 1 = first (reads 1 in the countdown, before the first sort); `leader` while you lead, for a lamp. |
| `race_phase`, `racing`, `live` | `<main>+42CCA8` → 64 | 1 to 5 loading, 6 the countdown, 7 racing, 8 for a frame at the finish line, 9 rolling to a stop, 11 time up, 0 after; `racing` is 1 from the green light to the finish, and `live` 0 while the game is paused (its race clock stops). |
| `wall_contact` | car +122 | 16/32 a hit on the left/right, 64/128 touching or scraping a wall on the left/right, 2 a nitro burning (7 s a shot; the same as the nitro timer). |
| `car_contact` | car +123 | 1 your front, 2 your right, 4 your rear, 8 your left. |
| `view` | `<main>+3F2654` | camera: 12 in the attract demo and the menus, 1 and 2 in the cockpit. |
| `time_left`, `checkpoint` | `<main>+4B1758` → 34 → 1C | race time left in seconds (the game counts frames, 60 a second); `checkpoint` for 2 s after a checkpoint adds time (checked: +60 s at Alexis's checkpoint). |
| `lap` | `<main>+3F25DC` → 984 | laps completed: 0 on the first lap, 1 after the first line crossing (checked). |
| `brake_warning`, `corner_ahead`, `corner_side`, `corner_sharpness`, `navi_curve` | `<main>+4B1758` → 3C (the car navigation) | `brake_warning` 1 for 1.5 s from each Brake! (checked against all of Alexis's Brake! sightings); `corner_ahead` while a curve marker shows; `corner_side` +1 right, -1 left (a snake by its first bend); `corner_sharpness` 1 hairpin, 0.6 medium or snake, 0.3 slight. Codes (Alexis's readings): 1 hairpin right, 2 medium right, 4 hairpin left, 5 medium left, 9 slight left, 6 snake left-right-left, 48 snake right-left; 3328 none. Needs the CARNAVI setting on. `auto_brake` (car +CCC) is the game's brake assist. |
| `drift_angle`, `drift` | car +100/+108 (position), +D0/+D8 (heading) | the angle between where the car points and where it is going, degrees, + a right-hand drift; `drift` 0 to 1 with ID6's weighting. Feed Car_drift_angle, Car_drift and (with wheelspin) Car_grip_loss. |
| `wheelspin` | car +121 bit 128 | the driven wheels spinning when pulling away hard (feeds Car_grip_loss). Bits 4, 8 and 32 mark gear changes. |
| `nitro_left`, `nitro_time`, `boost` | car +290, +294; car +122 bit 2 | nitro shots left (3 a race) and frames left (420 = 7 s); `boost` (Car_boost) is wall_contact bit 2, the same spans as the nitro timer (checked). |

* The game's race flag (`in_race`) stays on in the menus once a credit stops the attract demo, with the car values
  frozen, so Car_in_race and `racing` also need `view` not to be 12, and `live` (the race clock moving).
* Car_impact is the start of any wall hit or car contact (front and rear bumps too); Car_impact_side its side; Car_wall_contact
  the side of a wall you're touching or scraping.
* Max speed 200 km/h (Alexis: most races stay under it, and above it the cars barely steer; fast cars reach about 295).
  Max revs 8000 (Citroën about 8000, Golf GTI 7500, a tuned car 9000).
* Lamps read memory as before, so OutputBlaster isn't needed for them.

### Rows added to existing profiles (cheat tables)

| Profile | Added |
|---|---|
| `IDTA` (v2.31, Season 3) | `speed`, `rpm` (the table's output pointers), `timer`, `accel_g` |
| `ID0V230` | `stage_timer` (since 16 November 2026 `time_left`, read from the game's code), `total_timer` (now `menu_timer`, the menus' countdown) and `steer` (now `hud_meter`: a value of the race display, not the steering; `steer` is now the physics' steering) |
| `WMMT6` | `gear2`, `race_time2`, `power`, `handling` |
| `WMMT6R` | `gear2`, `race_time2`, `timer`, `power`, `handling`, `throttle`/`throttle2`, `brake`/`brake2`, and `speed2`/`rpm2` (the 6R table lists 6RR's addresses for these, so they may not apply) |
| `WMMT6RR` | `rpm2` (from the Wg6Enma DLL), `gear2`, `race_time2`, `timer`, `power`, `handling`, `throttle`/`throttle2`, `brake`/`brake2`. The table's speed address is the one the profile already had. The FANTASY 6RR table is the same apart from its timer. |
| `WMMT3DXP` | `race_timer` (Export version): since 11 November 2026 `time_left`, which is what it turned out to be (the game's time left, found in its code) |
| `CRUISNBLAST` | `nos` (bottles left), `boost` (2 s after a bottle is used), `timer`, `timer2` |
| `RF3D` | `damage`, `cpu_damage`, `hit` (damage going up), `timer2` |

### New profiles: TeknoParrot games

| Profile | Game | Process | From | Rows |
|---|---|---|---|---|
| `IDTA21` | Initial D The Arcade v2.1 (Season 3) | `GameProject-Win64-Shipping.exe` (64-bit) | table | `timer` |
| `IDTAS4` | Initial D The Arcade Season 4 v2.5 | same | table | `timer` |
| `IDTAS5` | Initial D The Arcade Season 5 v3.10 | same | table | `speed`, `rpm`, `timer`, `accel_g` |
| `IDTAS5V321` | Initial D The Arcade Season 5 v3.21 (ARCADEZONE.CN) | same | table | `timer` |
| `WMMT6RRP` | Wangan Midnight Maximum Tune 6RR Plus v4.00.13 | `wmn6r.exe` (64-bit) | table | `gear`, `race_timer`, `timer`, `power`, `handling`, pedals |
| `FNFSB2` | The Fast and the Furious Super Bikes 2 | `sdaemon.exe` | table, OutputBlaster | `timer`, `boosts`, `boost`; lamps need OutputBlaster |
| `THRILLDRIVE4` | Crazy Streets - Thrill Drive 4 | `td4.exe` | table | `timer`, `nos`, `boost` |
| `HYDROTHUNDER` | Hydro Thunder | `HYDRO_x64.exe` (the patched builds are `HYDRO_x64_x64.exe` and `HYDRO_x64_x86.exe`: change Process to match) | table | `timer`, `boost_level`, `boost` |
| `DEADHEATRIDERS` | Dead Heat Riders | `BudgieLoader.exe` | FFB plugin | TeknoParrot shared memory: `spring` (divided by 500 for this game), `friction`, `force` |
| `BG4` | Battle Gear 4 (the export version; the Japanese Battle Gear 4 Tuned is `BG4JP`) | `game.exe` | OutputBlaster | Start, View1, Hazard, Overrev lamps |
| `HARLEY` | Harley-Davidson: King of the Road | `BudgieLoader.exe` | OutputBlaster | Start, Leader lamps |
| `MOTOGP` | MotoGP (2015) | `BudgieLoader.exe` | OutputBlaster | Start, Leader, View1-3, brake lamp |
| `FNFDRIFT`, `FNFSC` | The Fast and the Furious Drift, SuperCars | `sdaemon.exe` | OutputBlaster | Start, View1-4 lamps |
| `HUMMER`, `HUMMEREXTREME` | Hummer, Hummer Extreme Edition | `BudgieLoader.exe` | OutputBlaster | Start, View1-2, white lamps |
| `CARS` | Cars | `sdaemon.exe` | OutputBlaster | Start, View1-3, seat lamps |
| `CRAZYRIDE` | Crazy Ride | `CrazyTaxiGame-Win64-Shipping.exe` (64-bit) | OutputBlaster | Start, View1-2 lamps (need OutputBlaster) |

The force feedback of FnF Drift, SuperCars, Hummer and Cars comes from code hooks, so there is none
to read; their lamps are read from memory.

### New profiles: Model 2 Emulator (memory)

`M2DAYTONA`, `M2INDY500`, `M2STCC` (Touring Car), `M2OVERREV`, `M2SGT24H` (Super GT 24h),
`M2SRALLY`, for `emulator_multicpu.exe` (the build the FFB Arcade Plugin and OutputBlaster know;
TeknoParrot's own Model 2 emulator may differ). Each reads the force feedback byte in the emulator and
decodes `force`, `spring`, `friction` and `vibration` as the FFB plugin does (Sega Rally has force,
plus the rumble commands the FFB plugin ignores), and OutputBlaster's six lamps. Daytona also has `track`, `countdown` and `position` (the
cars ahead, read from memory, + 1).

**4 November 2026, from the emulator's own Lua scripts** (`SCRIPTS\daytona.lua`, `stcc.lua`,
`srallyc.lua`):

* `M2DAYTONA`: `game_state` (was `m2_game_state`; 0x16 = racing, 0x03 to 0x07 attract), which now
  drives Car_in_race, and `time_left` in seconds (stored in 1/64 s).
* `M2STCC`: `host_state`, the game's state byte (9 from loading the race onwards in the 5 November log).
* `M2SRALLY`: `time_left_raw` (now `time_left`, in seconds: see 8 November below).
* STCC (and, going by its script, Sega Rally) keeps its variables in the second RAM area (0x200000), which the old
  `1AA888, 100` path can't reach. These rows use the emulator's page table instead: Base
  `1AA8F4`, Offsets `<address ÷ 0x10000 × 0x10>, <address>`, e.g. `200, 202094` for 0x202094 and
  `500, 500824` for RAM+824. It works for any game address.
* `M2STCC` (5 and 6 November 2026, from Alexis's RAM logs and her readings from video, checked in a TP
  Telemetry recording): `speed` (x 64 = km/h), `rpm` (the engine's own revs), `rpm_tacho`, `gear`,
  `race_time` (whole race; drives Car_in_race), `time_left`, `laps_done`, `checkpoint` (1 while TIME
  EXTENDED shows), `surfaces` (per wheel: 0 in the air, 2 road, 3 kerb, 4 grass) for Car_rumble_strip and
  Car_off_road, `grip_loss` from the rear tyres' slip angle, `airborne` (wheels off the ground),
  `wall_hit` (with the wheel force, Car_impact; no side), `skid_flag`, and the screen's own `speed_kmh`
  and `rpm_display`. Max speed 320, Max revs 12900.
* `M2DAYTONA` (8 November 2026, from Alexis's RAM log of three laps with manual gears and her readings
  from video; the time extensions also match her TP Telemetry recordings): `speed` (the speedo's km/h),
  `rpm` (the tacho's revs), `gear` (manual and automatic, checked on a run with each; it keeps the last
  gear through neutral), `race_time`, `lap_time`, `last_lap`, `laps_done`, `checkpoint` (1 for the 2 s TIME EXTENSION
  shows at each lap), the surface under each wheel (`wheels_front`, `wheels_rear`: 2 road, 4 grass,
  6 pit lane, + 0x100 on a kerb) for Car_rumble_strip and Car_off_road, `surface_rumble`, `grip_loss`
  from the tyre squeal, and `hit` (wall hits and side-on contact, with the wheel force for Car_impact;
  rear-end bumps only show in the force). `position` now reads 0 outside a race. Max speed 340, Max revs 8500.
* `M2SRALLY` (8 November 2026, from Alexis's two RAM logs, `srallyc`, and her readings from video,
  checked in her TP Telemetry recording where it has the value): `race_state` (drives Car_in_race),
  `speed` (x 64 = km/h), `rpm` (8800 on the limiter) and `rpm_tacho` (the tacho's figure, revs / 1.1),
  `gear` (manual and automatic), `total_time`, `stage_time`, `time_left` (seconds), `checkpoint` (1 for a
  second at each time extension, from the time left jumping up), `position` and `leader` (1 while you lead,
  for a lamp), the surface under each wheel (0 tarmac, 2 dry dirt or sand, 3 wetter dirt, 6 grass verge,
  9 tarmac in the Forest tunnel)
  for Car_off_road,
  `wheels_down` and `airborne` (all four wheels off the ground), `slip_front` and `grip_loss` (rear slip),
  `hit` (wall and car hits, signed: + right, - left; it keeps the last value, so a hit is when it
  changes, which `hit_now` gives for Car_impact and Car_impact_side), and `vibration` (the rumble
  commands the game sends on the grass and when scraping walls). Max speed 240, Max revs 8800.
* Lamps: OutputBlaster's regular build reads RAM+824, which only holds the lamps when the emulator's
  game script moves them there, and only Daytona's does. STCC and Sega Rally send their lamps to I/O port
  0x01C0000A, and the emulator keeps that value at exe+174CF0: their lamp rows read it there, as a
  special STCC build of OutputBlaster does (Alexis's leader lamp works through it and MAMEHooker). Bits:
  4 start, 128 leader, 8/16/32/64 view 1 to 4. Sega Rally has never lit a lead lamp in any log, so use
  its `leader` row (from the position). No TP Telemetry Lua scripts are needed for any Model 2 game: the
  lamp patch some earlier versions offered froze STCC's and Sega Rally's controls, and the RAM logger
  was only for finding values. Keep each game's own emulator script.

### New profiles: Supermodel, MAME and Flycast (network outputs)

These read the force feedback the emulator sends as an output, decoded as the FFB Arcade Plugin does.
No process: they work whenever selected. **Switch the emulator's outputs on first** (the plugin's
Game_Outputs.md has the details):

* **Flycast:** Settings, Network, tick **Broadcast Digital Outputs**. Without it Flycast sends nothing.
  Flycast's values are hexadecimal, so plugin 0.13.3 or later is needed to read them.
* **MAME:** in `mame.ini`, set `output` to `network`.
* **Supermodel:** start it with `-outputs=net`.

Only one program can serve outputs on port 8000 at a time, which is fine with one game at a time.

| Emulator | Profiles | Output |
|---|---|---|
| Supermodel | `SMDAYTONA2`, `SMDAYTO2PE` (Daytona USA 2 Power Edition: the game's memory and the lamps, 18 November 2026: see below), `SMSCUD` (also the game's memory and the lamps since 18 November 2026: see Scud Race above), `SMLEMANS24`, `SMDIRTDEVILS`, `SMSRALLY2`, `SMECA` (Emergency Call Ambulance) | `RawDrive` |
| MAME | `MAMEVR` (Virtua Racing) | `digit0` |
| MAME | `MAMECALSPEED`, `MAMEHYPRDRIV`, `MAMESF2049`, `MAMEVAPORTRX` | `wheel` or `wheel_motor` |
| MAME | `MAMECRUSNUSA`, `MAMECRUSNWLD`, `MAMEOFFROADC`, `MAMESFRUSH`, `MAMESFRUSHRK` | `wheel` (the other way round) |
| MAME | `MAMEORUNNERS`, `MAMETOUTRUN`, `MAMECBOMBERS`, `MAMEDBLAXLE`, `MAMECISCHEAT`, `MAMEF1GPSTAR` | shaker motor on/off only (`vibration`) |
| MAME | `MAMEOUTRUN`, `MAMEPDRIFT` | deluxe cabinet bank motor (`force`) and shaker |
| Flycast | `FLYINITD`, `FLYINITD2`, `FLYINITD3`, `FLYINITDCY` (Initial D Arcade Stage 1, 2, 3, Cycraft), `FLYCLUBKART`, `FLYKINGRT66`, `FLYSGDRVSIM` (also `rpm` and `speed` from its tachometer and speedometer) | `midiffb` |
| Flycast | `FLYMAXSPEED`, `FLYFTSPEED` | `awffb` |
| Flycast | `FLY18WHEELER`, `FLYF355` | `m3ffb` |

### Not possible yet

* **MAME games the FFB plugin finds by searching memory for byte patterns** (Daytona USA, Indy 500, Sega GT,
  Sega Rally, Super Chase, Rave Racer, Dirt Dash, Ace Driver under MAME), and **Hard Drivin' / Race
  Drivin'** (its force is assembled from several outputs frame by frame).
* **Games whose force feedback comes only from code hooks** in the FFB plugin: The Fast and the
  Furious, Tokyo Cop, Gaelco Championship Tuning Race, Wasteland Racers 2071, Ring Riders, Sega Rally 3
  ("Other"), Ford Racing ("Other").
* Tables with nothing to read: XTrial Racing (cheats only), Initial D 8 (no driving values).

## Adding a game

Put the profile (exported with **Export…**) and any `.CT` in a new folder named after the game's
prefix, and add a section above with its process name, whether it's 32- or 64-bit, and what each
value is. Game_Formulas.md is rebuilt from the profiles each time the pack is released, so the new
game's formulas join it then.

To check every profile in this pack loads without errors, run the plugin's tests with this folder:

```
set TPT_PROFILE_DIRS=C:\path\to\TPTelemetry-GameProfiles
cd TPTelemetry\tests\CoreTests
dotnet run
```

## Credits

* **Boomslangnz** and the FFB Arcade Plugin's contributors, for the
  [FFB Arcade Plugin](https://github.com/Boomslangnz/FFBArcadePlugin) and
  [OutputBlaster](https://github.com/Boomslangnz/OutputBlaster) (both GPL-3.0): most of the force
  feedback and lamp addresses here come from them. Only facts are taken; no code.
* **MasterRaver**, for the TeknoParrot Cheat Engine tables and the WMMT5DX+ outputs script.
* **ElSemi**, **SailorSat** and **Vincerplay**, for the Model 2 Emulator and its game scripts:
  the `M2...` profiles' game states, timers, the lamp reroute to RAM+824 and the way into the
  emulator's memory come from their work.
