# Game formulas

Every formula in the game profiles pack, game by game (grouped by emulator, as the pack's folders are), with what each row does. A formula is a row's
recipe: it works the published value out from raw memory reads, TeknoParrot's shared memory, game
outputs or other rows. The formula language itself (functions, operators, names such as `tp_jvs2`,
`out_LampStart`, `max_speed`) is explained in **Formula_Reference.md**, which comes with the plugin.

Use these as examples to copy: the same pattern usually works in another game. Rows marked "not
exported" are working values other rows use; they show in the table but aren't SimHub properties.

This file is generated from the profiles (`tools/gameformulas.py`), so it always matches them. Most
formulas are unverified; the notes say which have been checked against recordings.


## Games


**Teknoparrot** (folder `Teknoparrot`)

* [Arctic Thunder](#arcticthunder) (ARCTICTHUNDER)
* [Batman (arcade)](#batman) (BATMAN)
* [Battle Gear 4](#bg4) (BG4)
* [Battle Gear 4 Tuned (Japan)](#bg4jp) (BG4JP)
* [Cars](#cars) (CARS)
* [Chase H.Q. 2](#chasehq2) (CHASEHQ2)
* [Crazy Ride](#crazyride) (CRAZYRIDE)
* [Crazy Streets - Thrill Drive 4](#thrilldrive4) (THRILLDRIVE4)
* [Cruis'n Blast](#cruisnblast) (CRUISNBLAST)
* [D1 Grand Prix](#d1gp) (D1GP)
* [Daytona Championship USA](#daytona3) (DAYTONA3)
* [Daytona Championship USA New Season Edition](#daytona3nse) (DAYTONA3NSE)
* [Dead Heat](#deadheat) (DEADHEAT)
* [Dead Heat Riders](#deadheatriders) (DEADHEATRIDERS)
* [Dirty Drivin'](#dirtydrivin) (DIRTYDRIVIN)
* [Ford Racing](#fordracing) (FORDRACING)
* [GRID (arcade)](#grid) (GRID)
* [GTI Club Supermini Festa](#gticlub3) (GTICLUB3)
* [H2Overdrive](#h2overdrive) (H2OVERDRIVE)
* [Harley-Davidson: King of the Road](#harley) (HARLEY)
* [Hummer](#hummer) (HUMMER)
* [Hummer Extreme Edition](#hummerextreme) (HUMMEREXTREME)
* [Hydro Thunder](#hydrothunder) (HYDROTHUNDER)
* [Initial D Arcade Stage 4 (export)](#id4) (ID4)
* [Initial D Arcade Stage 4 (Japan)](#id4jp) (ID4JP)
* [Initial D Arcade Stage 5](#id5) (ID5)
* [Initial D Arcade Stage 6 AA](#id6) (ID6)
* [Initial D Arcade Stage 7 AAX](#id7) (ID7)
* [Initial D Arcade Stage 8 Infinity](#id8) (ID8)
* [Initial D Arcade Stage Zero v1.31](#id0v131) (ID0V131)
* [Initial D Arcade Stage Zero v2.11](#id0v211) (ID0V211)
* [Initial D Arcade Stage Zero v2.30](#id0v230) (ID0V230)
* [Initial D The Arcade Season 4 v2.5](#idtas4) (IDTAS4)
* [Initial D The Arcade Season 5 v3.10](#idtas5) (IDTAS5)
* [Initial D The Arcade Season 5 v3.21 (ARCADEZONE.CN)](#idtas5v321) (IDTAS5V321)
* [Initial D The Arcade v2.1 (Season 3)](#idta21) (IDTA21)
* [Initial D The Arcade v2.31](#idta) (IDTA)
* [KO Drive](#kodrive) (KODRIVE)
* [Mario Kart Arcade GP DX (USA)](#mkgpdxusa) (MKGPDXUSA)
* [Mario Kart Arcade GP DX v1.10](#mkgpdx110) (MKGPDX110)
* [Mario Kart Arcade GP DX v1.18](#mkgpdx118) (MKGPDX118)
* [MotoGP (2015)](#motogp) (MOTOGP)
* [OutRun 2 SP SDX](#outrun2sp) (OUTRUN2SP)
* [R-Tuned: Ultimate Street Racing](#rtuned) (RTUNED)
* [Road Fighters 3D](#rf3d) (RF3D)
* [Sega Race TV](#segaracetv) (SEGARACETV)
* [Sega Racing Classic](#segaracingclassic) (SEGARACINGCLASSIC)
* [Sega Rally 3](#sr3) (SR3)
* [Sega World Drivers Championship](#swdc) (SWDC)
* [Sonic & Sega All-Stars Racing](#sonicasr) (SONICASR)
* [Storm Racer G](#srg) (SRG)
* [The Fast and the Furious Drift](#fnfdrift) (FNFDRIFT)
* [The Fast and the Furious Super Bikes 2](#fnfsb2) (FNFSB2)
* [The Fast and the Furious SuperCars](#fnfsc) (FNFSC)
* [Wacky Races](#wackyraces) (WACKYRACES)
* [Wangan Midnight Maximum Tune 3 DX+](#wmmt3dxp) (WMMT3DXP)
* [Wangan Midnight Maximum Tune 5](#wmmt5) (WMMT5)
* [Wangan Midnight Maximum Tune 5DX](#wmmt5dx) (WMMT5DX)
* [Wangan Midnight Maximum Tune 5DX+](#wmmt5dxp) (WMMT5DXP)
* [Wangan Midnight Maximum Tune 6](#wmmt6) (WMMT6)
* [Wangan Midnight Maximum Tune 6R](#wmmt6r) (WMMT6R)
* [Wangan Midnight Maximum Tune 6RR](#wmmt6rr) (WMMT6RR)
* [Wangan Midnight Maximum Tune 6RR Plus v4.00.13](#wmmt6rrp) (WMMT6RRP)
* [Winter X Games SnoCross](#snocross) (SNOCROSS)

**Flycast** (folder `Flycast`)

* [18 Wheeler: American Pro Trucker (Flycast)](#fly18wheeler) (FLY18WHEELER)
* [Club Kart (Flycast)](#flyclubkart) (FLYCLUBKART)
* [Faster Than Speed (Flycast)](#flyftspeed) (FLYFTSPEED)
* [Ferrari F355 Challenge (Flycast)](#flyf355) (FLYF355)
* [Initial D Arcade Stage (Flycast)](#flyinitd) (FLYINITD)
* [Initial D Arcade Stage Ver. 2 (Flycast)](#flyinitd2) (FLYINITD2)
* [Initial D Arcade Stage Ver. 3 (Flycast)](#flyinitd3) (FLYINITD3)
* [Initial D Arcade Stage Ver. 3 Cycraft (Flycast)](#flyinitdcy) (FLYINITDCY)
* [Maximum Speed (Flycast)](#flymaxspeed) (FLYMAXSPEED)
* [Sega Driving Simulator (Flycast)](#flysgdrvsim) (FLYSGDRVSIM)
* [The King of Route 66 (Flycast)](#flykingrt66) (FLYKINGRT66)

**MAME** (folder `MAME`)

* [Cadash Bombers / Chase Bombers (MAME)](#mamecbombers) (MAMECBOMBERS)
* [California Speed (MAME)](#mamecalspeed) (MAMECALSPEED)
* [Cisco Heat (MAME)](#mamecischeat) (MAMECISCHEAT)
* [Cruis'n USA (MAME)](#mamecrusnusa) (MAMECRUSNUSA)
* [Cruis'n World (MAME)](#mamecrusnwld) (MAMECRUSNWLD)
* [Double Axle (MAME)](#mamedblaxle) (MAMEDBLAXLE)
* [F1 Grand Prix Star (MAME)](#mamef1gpstar) (MAMEF1GPSTAR)
* [Hyperdrive (MAME)](#mamehyprdriv) (MAMEHYPRDRIV)
* [Off Road Challenge (MAME)](#mameoffroadc) (MAMEOFFROADC)
* [Out Run (MAME)](#mameoutrun) (MAMEOUTRUN)
* [OutRunners (MAME)](#mameorunners) (MAMEORUNNERS)
* [Power Drift (MAME)](#mamepdrift) (MAMEPDRIFT)
* [San Francisco Rush (MAME)](#mamesfrush) (MAMESFRUSH)
* [San Francisco Rush 2049 (MAME)](#mamesf2049) (MAMESF2049)
* [San Francisco Rush: The Rock (MAME)](#mamesfrushrk) (MAMESFRUSHRK)
* [Turbo Out Run (MAME)](#mametoutrun) (MAMETOUTRUN)
* [Vapor TRX (MAME)](#mamevaportrx) (MAMEVAPORTRX)
* [Virtua Racing (MAME)](#mamevr) (MAMEVR)

**Model 2 Emulator** (folder `Model 2 Emulator`)

* [Daytona USA (Model 2 Emulator)](#m2daytona) (M2DAYTONA)
* [Indianapolis 500 (Model 2 Emulator)](#m2indy500) (M2INDY500)
* [Over Rev (Model 2 Emulator)](#m2overrev) (M2OVERREV)
* [Sega Rally Championship (Model 2 Emulator)](#m2srally) (M2SRALLY)
* [Sega Touring Car Championship (Model 2 Emulator)](#m2stcc) (M2STCC)
* [Super GT 24h (Model 2 Emulator)](#m2sgt24h) (M2SGT24H)

**Supermodel** (folder `Supermodel`)

* [Daytona USA 2 (Supermodel)](#smdaytona2) (SMDAYTONA2)
* [Daytona USA 2 Power Edition (Supermodel)](#smdayto2pe) (SMDAYTO2PE)
* [Dirt Devils (Supermodel)](#smdirtdevils) (SMDIRTDEVILS)
* [Emergency Call Ambulance (Supermodel)](#smeca) (SMECA)
* [Le Mans 24 (Supermodel)](#smlemans24) (SMLEMANS24)
* [Scud Race (Supermodel)](#smscud) (SMSCUD)
* [Sega Rally 2 (Supermodel)](#smsrally2) (SMSRALLY2)

**PC** (folder `PC`)

* [Crazy Taxi](#crazytaxi) (CRAZYTAXI)

<a id="arcticthunder"></a>
## Arctic Thunder

Prefix `ARCTICTHUNDER` (properties `TPTelemetry.ARCTICTHUNDER_<row>`), process `snow.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `tp_ok` | `tp_connected` | 1 while TeknoParrot's shared memory is available. |
| `ffb_vib_raw` | `tp_jvs7` | Raw vibration value from TeknoParrot (slot 7); 255 means off. |
| `ffb_force_raw` | `tp_jvs8` | Raw force value from TeknoParrot (slot 8); 128 = centre. |
| `vibration` | `tp_jvs7 > 0 && tp_jvs7 != 255 ? tp_jvs7 / 255 : 0` | Vibration, 0 to 1. |
| `force` | `tp_jvs8 > 128 ? -(tp_jvs8 - 128) / 127 : (tp_jvs8 > 0 && tp_jvs8 < 128 ? (128 - tp_jvs8) / 127 : 0)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(ob_lampsout, 8) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_lampsout, 4) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |

<a id="batman"></a>
## Batman (arcade)

Prefix `BATMAN` (properties `TPTelemetry.BATMAN_<row>`), process `sdaemon.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `force` | memory read, then `clamp(value / 1.2, -1, 1)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). Raw: Force the game asks for. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `lampstart` | `out_LampStart` | Output from OutputBlaster: LampStart (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `shoot1p` | `out_Shoot1p` | Output from OutputBlaster: Shoot1p (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `billboard_white` | `out_Billboard_White` | Output from OutputBlaster: Billboard White (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `billboardlamp` | `out_BillboardLamp` | Output from OutputBlaster: BillboardLamp (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `speaker_1` | `out_Speaker_1` | Output from OutputBlaster: Speaker 1 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `speaker_2` | `out_Speaker_2` | Output from OutputBlaster: Speaker 2 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `speaker_3` | `out_Speaker_3` | Output from OutputBlaster: Speaker 3 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `dash` | `out_Dash` | Output from OutputBlaster: Dash (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `seat_right` | `out_Seat_Right` | Output from OutputBlaster: Seat Right (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampred` | `out_LampRed` | Output from OutputBlaster: LampRed (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampgreen` | `out_LampGreen` | Output from OutputBlaster: LampGreen (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampblue` | `out_LampBlue` | Output from OutputBlaster: LampBlue (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `base` | `out_Base` | Output from OutputBlaster: Base (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_red` (not exported) | `lampred` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_green` (not exported) | `lampgreen` | Common lamp Lamp_green: the cabinet's green lamp (`lampgreen`). |
| `lamp_blue` (not exported) | `lampblue` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |
| `lamp_marquee` (not exported) | `billboardlamp` | Common lamp Lamp_marquee: the billboard lamp. |

<a id="bg4"></a>
## Battle Gear 4

Prefix `BG4` (properties `TPTelemetry.BG4_<row>`), process `game.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampstart` | memory read, then `(value == 32 ? 8 : value == 28 ? 7 : value == 24 ? 6 : value == 20 ? 5 : value == 16 ? 4 : value == 12 ? 3 : value == 8 ? 2 : value == 4 ? 1 : 0) / 8 * 100` | LampStart output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | memory read, then `(value == 32 ? 8 : value == 28 ? 7 : value == 24 ? 6 : value == 20 ? 5 : value == 16 ? 4 : value == 12 ? 3 : value == 8 ? 2 : value == 4 ? 1 : 0) / 8 * 100` | LampView1 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamphazard` | memory read, then `(value == 32 ? 8 : value == 28 ? 7 : value == 24 ? 6 : value == 20 ? 5 : value == 16 ? 4 : value == 12 ? 3 : value == 8 ? 2 : value == 4 ? 1 : 0) / 8 * 100` | LampHazard output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampoverrev` | memory read, then `band(value, 1) != 0` | LampOverrev output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_shift` (not exported) | `lampoverrev` | Common lamp Lamp_shift: shift or over-rev light (the game's `lampoverrev`). |

<a id="bg4jp"></a>
## Battle Gear 4 Tuned (Japan)

Prefix `BG4JP` (properties `TPTelemetry.BG4JP_<row>`), process `game.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `abs(value) / max_speed` | Speed, km/h, as the speedo shows it (car 0; the game keeps it signed, so the size is taken). Checked in Alexis's recording (10 November 2026). Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `rpm` | memory read, then `value / max_revs` | Engine revs (car 0): 700 at idle, capped at the car's own limiter (Golf GTI 7500, Citroën 2.0 VTS about 8000). Checked in Alexis's recording (10 November 2026). Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). |
| `position` | memory read, then `value + 1` | Race position, 1 = first (car 0; the game keeps 0 for first and sorts the cars by how far round they are). Reads 1 in the countdown, before the first sort. Checked in Alexis's recording (10 November 2026). |
| `time_left` | memory read, then `value / 60` | Race time left, seconds (the RT the screen shows): the game counts it in frames, 60 a second, and adds each checkpoint's extension. Checked in Alexis's recording (10 November 2026). |
| `lampstart` | memory read, then `(value == 32 ? 8 : value == 28 ? 7 : value == 24 ? 6 : value == 20 ? 5 : value == 16 ? 4 : value == 12 ? 3 : value == 8 ? 2 : value == 4 ? 1 : 0) / 8 * 100` | LampStart output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | memory read, then `(value == 32 ? 8 : value == 28 ? 7 : value == 24 ? 6 : value == 20 ? 5 : value == 16 ? 4 : value == 12 ? 3 : value == 8 ? 2 : value == 4 ? 1 : 0) / 8 * 100` | LampView1 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamphazard` | memory read, then `(value == 32 ? 8 : value == 28 ? 7 : value == 24 ? 6 : value == 20 ? 5 : value == 16 ? 4 : value == 12 ? 3 : value == 8 ? 2 : value == 4 ? 1 : 0) / 8 * 100` | LampHazard output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampkey` | memory read, then `(value == 32 ? 8 : value == 28 ? 7 : value == 24 ? 6 : value == 20 ? 5 : value == 16 ? 4 : value == 12 ? 3 : value == 8 ? 2 : value == 4 ? 1 : 0) / 8 * 100` | LampKey output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamponline` | memory read, then `band(value, 1) != 0` | LampOnline output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampoverrev` | memory read, then `band(value, 1) != 0` | LampOverrev output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `live` | `!(valid(time_left, -1) >= 0) \|\| maxw(abs(delta(time_left)), 0.5) > 0` | 1 while the race clock moves (0 if the game freezes; 1 if the clock can't be read). |
| `racing` | `in_race && view != 12 && race_phase == 7 && live` | 1 from the green light to the finish or time up, not in the countdown, the menus or a freeze. |
| `checkpoint` | `racing && maxw(delta(time_left) > 1, 2) > 0` | 1 for 2 s after a checkpoint adds time (checked: 113.25 to 173.23 s at Alexis's checkpoint, 10 November 2026). |
| `boost` | `racing && band(wall_contact, 2) > 0` | 1 while a nitro burns (7 s a shot; wall_contact bit 2, the same as the nitro timer at each of Alexis's nitro marks, 10 November 2026). |
| `brake_warning` | `racing && maxw(navi_sign_on > 0, 1.5) > 0` | 1 for 1.5 s from each Brake! (checked: it came about half a second before each of Alexis's Brake! marks, and with the one she saw just after a checkpoint, 11 November 2026). |
| `corner_ahead` | `racing && navi_curve > 0 && navi_curve != 3328` | 1 while the car navigation shows a curve marker. |
| `corner_side` | `corner_ahead ? (navi_curve == 1 \|\| navi_curve == 2 \|\| navi_curve == 48 ? 1 : (navi_curve == 4 \|\| navi_curve == 5 \|\| navi_curve == 9 \|\| navi_curve == 6 ? -1 : 0)) : 0` | The corner coming up: +1 right, -1 left (a snake by its first bend), 0 none or a marker not yet named. |
| `corner_sharpness` | `corner_ahead ? (navi_curve == 1 \|\| navi_curve == 4 ? 1 : (navi_curve == 2 \|\| navi_curve == 5 \|\| navi_curve == 6 \|\| navi_curve == 48 ? 0.6 : (navi_curve == 9 ? 0.3 : 0))) : 0` | How sharp the corner coming up is: 1 hairpin, 0.6 medium or a snake, 0.3 slight, 0 none or a marker not yet named. |
| `auto_brake` | `racing && band(assist_flags, 2) > 0` | 1 while the game's automatic brake assist acts (its overlay shows). |
| `vel_x` (not exported) | `slope(pos_x, 0.1)` | Travel speed along x, m/s (from the position over 0.1 s). |
| `vel_z` (not exported) | `slope(pos_z, 0.1)` | Travel speed along z, m/s. |
| `drift_angle` | `racing && hypot(vel_x, vel_z) * 3.6 > 10 ? -atan2(vel_x * head_z - vel_z * head_x, vel_x * head_x + vel_z * head_z) * 57.29578 : 0` | Drift angle, degrees: between where the car points and where it is going, + pointing right of its path (a right-hand drift). 0 below 10 km/h and outside a race. Alexis's drifts read 20 to 50 degrees. |
| `drift` | `(1 - pow(1 - clamp((abs(drift_angle) - 5) / 45, 0, 1), 2)) * sqrt(clamp((speed * max_speed - 20) / 80, 0, 1))` | Drifting, 0 to 1, with ID6's weighting (Alexis, 10 November 2026): nothing under 5 degrees, full at 50; nothing under 20 km/h, full from 100 km/h. |
| `leader` | `racing && position == 1` | 1 while you lead (for a lamp). |
| `impact_side` | `(band(wall_contact, 16) > 0 \|\| band(car_contact, 8) > 0) ? -1 : ((band(wall_contact, 32) > 0 \|\| band(car_contact, 2) > 0) ? 1 : 0)` | A hit on a wall or car side: +1 right, -1 left, 0 none (front and rear bumps have no side). |
| `contact` | `band(wall_contact, 48) > 0 \|\| band(car_contact, 15) > 0` | 1 while hitting a wall or touching another car on any side. |
| `wall_touch` | `band(wall_contact, 64) > 0 ? -1 : (band(wall_contact, 128) > 0 ? 1 : 0)` | Touching or scraping a wall: -1 left, +1 right, 0 none. |
| `car_bump` | `band(car_contact, 5) > 0` | 1 while bumping the car ahead or being bumped from behind. |
| `wheelspin` | `racing && band(ground_contact, 128) > 0` | 1 while the driven wheels spin (pulling away hard in a low gear). |
| `shift` | `maxw(delta(gear) != 0 && gear != 0, 0.2)` | 1 for 0.2 s after a gear change. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed, assuming km/h (speed x Max speed undoes the division, so this stays in G). + speeding up, - slowing down. |
| `lampred` | `(ob_redoutput == 32 ? 8 : ob_redoutput == 28 ? 7 : ob_redoutput == 24 ? 6 : ob_redoutput == 20 ? 5 : ob_redoutput == 16 ? 4 : ob_redoutput == 12 ? 3 : ob_redoutput == 8 ? 2 : ob_redoutput == 4 ? 1 : 0) / 8 * 100` | LampRed output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampgreen` | `(ob_greenoutput == 32 ? 8 : ob_greenoutput == 28 ? 7 : ob_greenoutput == 24 ? 6 : ob_greenoutput == 20 ? 5 : ob_greenoutput == 16 ? 4 : ob_greenoutput == 12 ? 3 : ob_greenoutput == 8 ? 2 : ob_greenoutput == 4 ? 1 : 0) / 8 * 100` | LampGreen output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampblue` | `(ob_blueoutput == 32 ? 8 : ob_blueoutput == 28 ? 7 : ob_blueoutput == 24 ? 6 : ob_blueoutput == 20 ? 5 : ob_blueoutput == 16 ? 4 : ob_blueoutput == 12 ? 3 : ob_blueoutput == 8 ? 2 : ob_blueoutput == 4 ? 1 : 0) / 8 * 100` | LampBlue output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampyellow` | `band(ob_redoutput == 32 ? 8 : ob_redoutput == 28 ? 7 : ob_redoutput == 24 ? 6 : ob_redoutput == 20 ? 5 : ob_redoutput == 16 ? 4 : ob_redoutput == 12 ? 3 : ob_redoutput == 8 ? 2 : ob_redoutput == 4 ? 1 : 0, ob_greenoutput == 32 ? 8 : ob_greenoutput == 28 ? 7 : ob_greenoutput == 24 ? 6 : ob_greenoutput == 20 ? 5 : ob_greenoutput == 16 ? 4 : ob_greenoutput == 12 ? 3 : ob_greenoutput == 8 ? 2 : ob_greenoutput == 4 ? 1 : 0) / 8 * 100` | LampYellow output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampcyan` | `band(ob_greenoutput == 32 ? 8 : ob_greenoutput == 28 ? 7 : ob_greenoutput == 24 ? 6 : ob_greenoutput == 20 ? 5 : ob_greenoutput == 16 ? 4 : ob_greenoutput == 12 ? 3 : ob_greenoutput == 8 ? 2 : ob_greenoutput == 4 ? 1 : 0, ob_blueoutput == 32 ? 8 : ob_blueoutput == 28 ? 7 : ob_blueoutput == 24 ? 6 : ob_blueoutput == 20 ? 5 : ob_blueoutput == 16 ? 4 : ob_blueoutput == 12 ? 3 : ob_blueoutput == 8 ? 2 : ob_blueoutput == 4 ? 1 : 0) / 8 * 100` | LampCyan output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampmagneta` | `band(ob_blueoutput == 32 ? 8 : ob_blueoutput == 28 ? 7 : ob_blueoutput == 24 ? 6 : ob_blueoutput == 20 ? 5 : ob_blueoutput == 16 ? 4 : ob_blueoutput == 12 ? 3 : ob_blueoutput == 8 ? 2 : ob_blueoutput == 4 ? 1 : 0, ob_redoutput == 32 ? 8 : ob_redoutput == 28 ? 7 : ob_redoutput == 24 ? 6 : ob_redoutput == 20 ? 5 : ob_redoutput == 16 ? 4 : ob_redoutput == 12 ? 3 : ob_redoutput == 8 ? 2 : ob_redoutput == 4 ? 1 : 0) / 8 * 100` | LampMagneta output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampwhite` | `band(band(ob_blueoutput == 32 ? 8 : ob_blueoutput == 28 ? 7 : ob_blueoutput == 24 ? 6 : ob_blueoutput == 20 ? 5 : ob_blueoutput == 16 ? 4 : ob_blueoutput == 12 ? 3 : ob_blueoutput == 8 ? 2 : ob_blueoutput == 4 ? 1 : 0, ob_greenoutput == 32 ? 8 : ob_greenoutput == 28 ? 7 : ob_greenoutput == 24 ? 6 : ob_greenoutput == 20 ? 5 : ob_greenoutput == 16 ? 4 : ob_greenoutput == 12 ? 3 : ob_greenoutput == 8 ? 2 : ob_greenoutput == 4 ? 1 : 0), ob_redoutput == 32 ? 8 : ob_redoutput == 28 ? 7 : ob_redoutput == 24 ? 6 : ob_redoutput == 20 ? 5 : ob_redoutput == 16 ? 4 : ob_redoutput == 12 ? 3 : ob_redoutput == 8 ? 2 : ob_redoutput == 4 ? 1 : 0) / 8 * 100` | LampWhite output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_in_race` (not exported) | `in_race && view != 12 && race_phase <= 7 && (race_phase != 7 \|\| live)` | Common value Car_in_race: 1 in the countdown and the race, off from the finish line (race phase 8) and at time up (10, 11); not in the attract demo or the menus (camera 12), where the game's own flag can stay on with the car values frozen, nor while the game freezes. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the speedo). Car_speed_mph is this / 1.609344. |
| `car_position` (not exported) | `position` | Common value Car_position: race position, 1 = first. |
| `car_lap` (not exported) | `racing ? lap + 1 : 0` | Common value Car_lap: the lap you are on, 1 = first (the lap row counts laps completed); 0 outside a race. |
| `car_time_left` (not exported) | `time_left` | Common value Car_time_left: time left (RT), seconds. |
| `car_impact` (not exported) | `maxw(contact && !prev(contact), 0.2)` | Common value Car_impact: the moment a wall hit or contact with another car starts (any side, front and rear included), held 0.2 s. |
| `car_impact_side` (not exported) | `impact_side` | Common value Car_impact_side: side of the contact, -1 left, 1 right. |
| `car_wall_contact` (not exported) | `wall_touch` | Common value Car_wall_contact: touching or scraping a wall, -1 left, 1 right. |
| `car_grip_loss` (not exported) | `max(drift, wheelspin)` | Common value Car_grip_loss: sliding: the drift (0 to 1) or wheelspin (1), whichever is bigger. |
| `car_drift` (not exported) | `drift` | Common value Car_drift: drifting, 0 to 1: the drift angle with ID6's weighting (nothing under 5 degrees or 20 km/h; full at 50 degrees and 100 km/h). |
| `car_drift_angle` (not exported) | `drift_angle` | Common value Car_drift_angle: the drift angle in degrees, + pointing right of the car's path (a right-hand drift), - left. |
| `car_boost` (not exported) | `boost` | Common value Car_boost: boost, 0 or 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_leader` (not exported) | `leader` | Common lamp Lamp_leader: in the lead, made from the race values (`leader`). |
| `lamp_checkpoint` (not exported) | `checkpoint` | Common lamp Lamp_checkpoint: a checkpoint passed or time extended (`checkpoint`). |
| `lamp_shift` (not exported) | `lampoverrev` | Common lamp Lamp_shift: shift or over-rev light (the game's `lampoverrev`). |
| `lamp_warning` (not exported) | `brake_warning` | Common lamp Lamp_warning: an on-screen warning: Brake!. |
| `lamp_red` (not exported) | `lampred / 100` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_green` (not exported) | `lampgreen / 100` | Common lamp Lamp_green: the cabinet's green lamp (`lampgreen`). |
| `lamp_blue` (not exported) | `lampblue / 100` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |
| `lamp_white` (not exported) | `lampwhite / 100` | Common lamp Lamp_white: the cabinet's white lamp (`lampwhite`). |

<a id="cars"></a>
## Cars

Prefix `CARS` (properties `TPTelemetry.CARS_<row>`), process `sdaemon.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampstart` | memory read, then `band(value, 255) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | memory read, then `band(value, 255) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | memory read, then `band(value, 255) != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview3` | memory read, then `band(value, 255) != 0` | LampView3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `seatlamp1` | memory read, then `band(value, 255) != 0` | SeatLamp1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `seatlamp2` | memory read, then `band(value, 255) != 0` | SeatLamp2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_marquee` (not exported) | `seatlamp1` | Common lamp Lamp_marquee: cabinet lighting (`seatlamp1`). |

<a id="chasehq2"></a>
## Chase H.Q. 2

Prefix `CHASEHQ2` (properties `TPTelemetry.CHASEHQ2_<row>`), process `game.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampstart` | memory read, then `value / 255 * 100` | LampStart output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamppatobuttonr` | memory read, then `value / 255 * 100` | LampPatoButtonR output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamppatobuttonb` | memory read, then `value / 255 * 100` | LampPatoButtonB output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `ffb_code` | `band(band(ffb_raw, 4294965351), 16385) == 16385 ? band(ffb_raw, 4294965351) - 16385 : band(ffb_raw, 4294965351)` | ffb_raw with the lamp bits removed. |
| `ffb_level` | `(ffb_code == 28672 ? 30 : (ffb_code == 24640 ? 29 : (ffb_code == 28736 ? 28 : (ffb_code == 16624 ? 27 : (ffb_code == 30720 ? 26 : (ffb_code == 26688 ? 25 : (ffb_code == 30784 ? 24 : (ffb_code == 24608 ? 23 : (ffb_code == 28704 ? 22 : (ffb_code == 24672 ? 21 : (ffb_code == 28768 ? 20 : (ffb_code == 26656 ? 19 : (ffb_code == 30752 ? 18 : (ffb_code == 26720 ? 17 : (ffb_code == 30816 ? 16 : (ffb_code == 20480 ? 15 : (ffb_code == 16448 ? 14 : (ffb_code == 20544 ? 13 : (ffb_code == 18432 ? 12 : (ffb_code == 22528 ? 11 : (ffb_code == 18496 ? 10 : (ffb_code == 22592 ? 9 : (ffb_code == 16416 ? 8 : (ffb_code == 20512 ? 7 : (ffb_code == 16480 ? 6 : (ffb_code == 20576 ? 5 : (ffb_code == 18464 ? 4 : (ffb_code == 22560 ? 3 : (ffb_code == 18528 ? 2 : (ffb_code == 22624 ? 1 : 0))))))))))))))))))))))))))))))` | Force level, 1 to 15 one way and 16 to 30 the other, from the FFB plugin's table. |
| `force` | `ffb_level > 15 ? -(31 - ffb_level) / 15 : (ffb_level > 0 ? (16 - ffb_level) / 15 : 0)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lamppato` | `ffb_raw - 16384 == 256 ? 6 : ffb_raw - 16384 == 8 ? 5 : ffb_raw - 16384 == 128 ? 4 : ffb_raw - 16384 == 512 ? 3 : ffb_raw - 16384 == 1024 ? 2 : ffb_raw - 16384 == 16 ? 1 : 0` | LampPato output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |

<a id="crazyride"></a>
## Crazy Ride

Prefix `CRAZYRIDE` (properties `TPTelemetry.CRAZYRIDE_<row>`), process `CrazyTaxiGame-Win64-Shipping.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampstart` | `out_LampStart` | Output from OutputBlaster: LampStart (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampview1` | `out_LampView1` | Output from OutputBlaster: LampView1 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampview2` | `out_LampView2` | Output from OutputBlaster: LampView2 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |

<a id="thrilldrive4"></a>
## Crazy Streets - Thrill Drive 4

Prefix `THRILLDRIVE4` (properties `TPTelemetry.THRILLDRIVE4_<row>`), process `td4.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `boost` | `maxw(delta(nos) < 0, 1)` | 1 while nitro is being used (held 1 s after it last went down). |
| `car_time_left` (not exported) | `timer` | Common value Car_time_left: time left, seconds, from the cheat table's timer (not yet checked in a recording). |
| `car_boost` (not exported) | `boost` | Common value Car_boost: boost, 0 or 1. |

<a id="cruisnblast"></a>
## Cruis'n Blast

Prefix `CRUISNBLAST` (properties `TPTelemetry.CRUISNBLAST_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampstart` | `out_LampStart` | Output from OutputBlaster: LampStart (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampview1` | `out_LampView1` | Output from OutputBlaster: LampView1 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampview2` | `out_LampView2` | Output from OutputBlaster: LampView2 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampview3` | `out_LampView3` | Output from OutputBlaster: LampView3 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampview4` | `out_LampView4` | Output from OutputBlaster: LampView4 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `boost` | `maxw(delta(nos) < 0, 2)` | 1 for 2 s after a nitro bottle is used (the burst length is a guess). |
| `car_in_race` (not exported) | `in_game == 1` | Common value Car_in_race: 1 in a race. |
| `car_boost` (not exported) | `boost` | Common value Car_boost: boost, 0 or 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |

<a id="d1gp"></a>
## D1 Grand Prix

Prefix `D1GP` (properties `TPTelemetry.D1GP_<row>`), process `game.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speedometer, from the FFB plugin's reading of this game. Needs the game's Process set. Unverified: from the FFB Arcade Plugin's reading of this game. Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `tp_ok` | `tp_connected` | 1 while TeknoParrot's shared memory is available. |
| `ffb_force_raw` | `tp_jvs6` | Raw force from TeknoParrot (slot 6), in thousandths. |
| `ffb_effect` | `tp_jvs7` | Effect code from TeknoParrot (slot 7): 1 spring, 2 vibration, 4 shake. |
| `force` | `clamp(tp_jvs6 / 200, -1, 1)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring_on` | `tp_jvs7 == 1` | 1 while the game asks for a centring spring. |
| `vibration_on` | `tp_jvs7 == 2` | 1 while the game asks for vibration. |
| `shake_on` | `tp_jvs7 == 4` | 1 while the game asks for a shake. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed, assuming km/h (speed x Max speed undoes the division, so this stays in G). + speeding up, - slowing down. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration_on` | Common value Car_vibration: 1 while the game asks for vibration. |

<a id="daytona3"></a>
## Daytona Championship USA

Prefix `DAYTONA3` (properties `TPTelemetry.DAYTONA3_<row>`), process `Daytona.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `rpm` | memory read, then `value / max_revs` | Engine RPM, read from game memory as OutputBlaster does (no OutputBlaster needed); OutputBlaster itself sends it divided by 100. Divided by Max revs (blank = 1, so RPM; set it to the redline to make this run 0 to 1). Unverified. |
| `force_alt` | memory read, then `value > 15 ? -(31 - value) / 15 : (value > 0 ? (16 - value) / 15 : 0)` | ffb_alt decoded, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). Raw: Second force value the FFB plugin can use instead (absolute address): 1 to 15 one way, 16 to 31 the other. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `lampstart` | memory read, then `band(value, 1) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | memory read, then `band(value, 1) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | memory read, then `band(value, 1) != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview3` | memory read, then `band(value, 1) != 0` | LampView3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview4` | memory read, then `band(value, 1) != 0` | LampView4 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `mirrored` | `(track == 2 \|\| track == 4) && game_state == 22 ? -1 : 1` | -1 on the two tracks where the FFB plugin swaps the force direction, otherwise 1. |
| `force` | `valid(hold((ffb_cmd >= 145 && ffb_cmd <= 160 ? -(160 - ffb_cmd) / 15 : (ffb_cmd >= 161 && ffb_cmd <= 176 ? (176 - ffb_cmd) / 15 : 0)) * mirrored, ffb_cmd >= 145 && ffb_cmd <= 175), 0)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `valid(hold(ffb_cmd >= 129 && ffb_cmd <= 143 ? (144 - ffb_cmd) / 15 : (ffb_cmd >= 193 && ffb_cmd <= 207 ? (207 - ffb_cmd) / 15 : (ffb_cmd >= 225 && ffb_cmd <= 239 ? (ffb_cmd - 224) / 15 : (ffb_cmd - 240) / 15)), (ffb_cmd >= 129 && ffb_cmd <= 143) \|\| (ffb_cmd >= 193 && ffb_cmd <= 207) \|\| (ffb_cmd >= 225 && ffb_cmd <= 239) \|\| ffb_cmd >= 241), 0)` | Centring spring, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd >= 177 && ffb_cmd <= 191 ? (192 - ffb_cmd) / 15 : 0` | Vibration while the game asks for it, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_in_race` (not exported) | `game_state == 22` | Common value Car_in_race: 1 while racing (game state 22, as the FFB plugin uses it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |

<a id="daytona3nse"></a>
## Daytona Championship USA New Season Edition

Prefix `DAYTONA3NSE` (properties `TPTelemetry.DAYTONA3NSE_<row>`), process `Daytona.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `rpm` | memory read, then `value / max_revs` | Engine RPM, read from game memory as OutputBlaster does (no OutputBlaster needed); OutputBlaster itself sends it divided by 100. Divided by Max revs (blank = 1, so RPM; set it to the redline to make this run 0 to 1). Unverified. |
| `lampstart` | memory read, then `band(value, 1) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | memory read, then `band(value, 1) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | memory read, then `band(value, 1) != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview3` | memory read, then `band(value, 1) != 0` | LampView3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview4` | memory read, then `band(value, 1) != 0` | LampView4 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampleader` | memory read, then `band(value, 128) != 0` | LampLeader output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `mirrored` | `(track == 2 \|\| track == 4) && game_state == 22 ? -1 : 1` | -1 on the two tracks where the FFB plugin swaps the force direction, otherwise 1. |
| `force` | `valid(hold((ffb_cmd >= 145 && ffb_cmd <= 160 ? -(160 - ffb_cmd) / 15 : (ffb_cmd >= 161 && ffb_cmd <= 176 ? (176 - ffb_cmd) / 15 : 0)) * mirrored, ffb_cmd >= 145 && ffb_cmd <= 175), 0)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `valid(hold(ffb_cmd >= 129 && ffb_cmd <= 143 ? (144 - ffb_cmd) / 15 : (ffb_cmd >= 193 && ffb_cmd <= 207 ? (207 - ffb_cmd) / 15 : (ffb_cmd >= 225 && ffb_cmd <= 239 ? (ffb_cmd - 224) / 15 : (ffb_cmd - 240) / 15)), (ffb_cmd >= 129 && ffb_cmd <= 143) \|\| (ffb_cmd >= 193 && ffb_cmd <= 207) \|\| (ffb_cmd >= 225 && ffb_cmd <= 239) \|\| ffb_cmd >= 241), 0)` | Centring spring, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd >= 177 && ffb_cmd <= 191 ? (192 - ffb_cmd) / 15 : 0` | Vibration while the game asks for it, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_in_race` (not exported) | `game_state == 22` | Common value Car_in_race: 1 while racing (game state 22, as the FFB plugin uses it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |

<a id="deadheat"></a>
## Dead Heat

Prefix `DEADHEAT` (properties `TPTelemetry.DEADHEAT_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `tp_ok` | `tp_connected` | 1 while TeknoParrot's shared memory is available. |
| `tp_spring` | `tp_jvs6 / 63` | Centring spring from TeknoParrot (slot 6), 0 to 1. |
| `tp_friction` | `tp_jvs7 / 63` | Friction (viscosity) from TeknoParrot (slot 7), 0 to 1. |
| `tp_center` | `tp_jvs8 / 63` | Centre offset from TeknoParrot (slot 8), -1 to 1. |
| `tp_reflect` | `tp_jvs9 > 0 && tp_jvs9 <= 63 ? tp_jvs9 / 63 : (tp_jvs9 > 63 ? -(255 - tp_jvs9) / 63 : 0)` | Reflect from TeknoParrot (slot 9), decoded to -1 to 1. |
| `dash` | `out_Dash` | Output from OutputBlaster: dash display value. Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `keypad` | `out_Keypad` | Output from OutputBlaster: keypad lamps. Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `base` | `out_Base` | Output from OutputBlaster: base lamp. Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampstart` | `out_LampStart` | Output from OutputBlaster: LampStart (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampview1` | `out_LampView1` | Output from OutputBlaster: LampView1 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampview2` | `0` | LampView2 output: OutputBlaster always sends 0 for this game. |
| `lampview3` | `0` | LampView3 output: OutputBlaster always sends 0 for this game. |
| `lampview4` | `0` | LampView4 output: OutputBlaster always sends 0 for this game. |
| `seatlamp1` | `out_SeatLamp1` | Output from OutputBlaster: SeatLamp1 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `billboardlamp` | `out_BillboardLamp` | Output from OutputBlaster: BillboardLamp (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `force` | `clamp(tp_jvs8 != 0 ? -tp_center : tp_reflect, -1, 1)` | The constant force the wheel gets: centre offset when there is one, otherwise reflect. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `grip_loss` | `clamp((1 - tp_spring) / 0.3, 0, 1)` | If Dead Heat uses the spring like WMMT3 does: 0 gripping, 1 sliding. Unconfirmed. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_grip_loss` (not exported) | `grip_loss` | Common value Car_grip_loss: sliding, 0 to 1. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |
| `lamp_marquee` (not exported) | `billboardlamp` | Common lamp Lamp_marquee: the billboard lamp. |

<a id="deadheatriders"></a>
## Dead Heat Riders

Prefix `DEADHEATRIDERS` (properties `TPTelemetry.DEADHEATRIDERS_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `tp_ok` | `tp_connected` | 1 while TeknoParrot's shared memory is available. |
| `spring` | `clamp(tp_jvs6 / 500, 0, 1)` | Centring spring (slot 6), 0 to 1: the FFB plugin divides this game's spring by 500, not 63. |
| `friction` | `clamp(tp_jvs7 / 63, 0, 1)` | Friction (slot 7), 0 to 1. |
| `force` | `clamp(tp_jvs9 > 0 && tp_jvs9 <= 63 ? tp_jvs9 / 63 : (tp_jvs9 > 63 ? -(255 - tp_jvs9) / 63 : (tp_jvs8 > 0 && tp_jvs8 <= 63 ? -tp_jvs8 / 63 : (tp_jvs8 < 0 ? -tp_jvs8 / 63 : 0))), -1, 1)` | Force, -1 to 1, from slot 9 (reflect) or else slot 8 (centre offset), decoded as the FFB plugin does. + = force from the right. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="dirtydrivin"></a>
## Dirty Drivin'

Prefix `DIRTYDRIVIN` (properties `TPTelemetry.DIRTYDRIVIN_<row>`), process `sdaemon.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `left_indicator_1` | memory read, then `value / 4095 * 100` | Left Indicator 1 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `left_indicator_2` | memory read, then `value / 4095 * 100` | Left Indicator 2 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `left_indicator_3` | memory read, then `value / 4095 * 100` | Left Indicator 3 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `left_indicator_4` | memory read, then `value / 4095 * 100` | Left Indicator 4 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `right_indicator_1` | memory read, then `value / 4095 * 100` | Right Indicator 1 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `right_indicator_2` | memory read, then `value / 4095 * 100` | Right Indicator 2 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `right_indicator_3` | memory read, then `value / 4095 * 100` | Right Indicator 3 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `right_indicator_4` | memory read, then `value / 4095 * 100` | Right Indicator 4 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `fog_light_1` | memory read, then `value / 4095 * 100` | Fog Light 1 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `fog_light_2` | memory read, then `value / 4095 * 100` | Fog Light 2 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `fog_light_3` | memory read, then `value / 4095 * 100` | Fog Light 3 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `fog_light_4` | memory read, then `value / 4095 * 100` | Fog Light 4 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `speaker_1` | memory read, then `value / 4095 * 100` | Speaker 1 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `speaker_2` | memory read, then `value / 4095 * 100` | Speaker 2 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `speaker_3` | memory read, then `value / 4095 * 100` | Speaker 3 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `large_dials` | memory read, then `value / 4095 * 100` | Large Dials output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `force` | `clamp(-ffb_raw * (track >= 8 && track <= 14 ? -1 : 1), -1, 1)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `small_dial_left` | `band(ob_restoutputs, 64) != 0` | Small Dial Left output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `small_dial_right` | `band(ob_restoutputs, 8) != 0` | Small Dial Right output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `base` | `band(ob_restoutputs, 32) != 0` | Base output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_restoutputs, 128) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `extra` | `band(ob_restoutputs, 16) != 0` | Extra output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |

<a id="fordracing"></a>
## Ford Racing

Prefix `FORDRACING` (properties `TPTelemetry.FORDRACING_<row>`), process `(none: reads no game memory)`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `tp_ok` | `tp_connected` | 1 while TeknoParrot's shared memory is available. |
| `ffb_cmd` | `tp_jvs2` | Raw force feedback value from TeknoParrot (slot 2). |
| `force` | `clamp(tp_jvs2 < -65505 && tp_jvs2 > -65515 ? (-65505 - tp_jvs2) / 9 : (tp_jvs2 > 0 && tp_jvs2 < 16 ? -(16 - tp_jvs2) / 9 : 0), -1, 1)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="grid"></a>
## GRID (arcade)

Prefix `GRID` (properties `TPTelemetry.GRID_<row>`), process `GRID.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value * 3.6 / max_speed` | Speed in km/h as the speedo shows it, from the on-screen dial (it keeps m/s; x 3.6 here): 95.7, 156.2, 211.7 and 265.3 where Alexis noted 95, 156, 211 and 265 on the limiter in 1st to 4th, 138 and 196 in another car, 61 in reverse (it reads + in reverse too). Smooth, unlike wheel_speed. Divided by Max speed. |
| `rpm` | memory read, then `value / max_revs` | Engine RPM, from the on-screen dial: the value OutputBlaster's hook reads, so OutputBlaster isn't needed. It stops at each car's limiter (6500 to 8200, so far). 1000 to 1500 in the menus and at the start line, 0 while a race loads. Divided by Max revs. |
| `rpm2` | memory read, then `value / max_revs` | Engine RPM again, by a second pointer chain from Alexis's table, for if the first can't be read. Divided by Max revs. |
| `gear` | memory read, then `value >= 9 ? -1 : value` | Gear as the dial shows it: 1 to 6 (the fastest class has six), -1 reverse (the game stores 9). 1 at the start line; no neutral seen. |
| `shift_lights` | memory read, then `(band(value, 1) > 0) + (band(value, 256) > 0)` | The dial's shift lights, 0 to 2: one from about 85 to 88% of the car's limiter, both from about 95%, flashing at the limiter. |
| `race_clock` | memory read, then `value / 1000000` | The race clock, seconds: the TT on screen (the game keeps microseconds and steps 1/120 s). 0 until GO; it stands still while paused and from race_over (Alexis's pause screen read 0:42.21 where this read 42.235). Checked in Alexis's recordings of 12 November 2026 (GRID.exe, claude/GRID-capture-20261112.md). |
| `car0_lap_time` | memory read, then `value / 1000000` | The player's own race time, seconds: the same as race_clock until the finish line, then held at the finishing time (3:18.777 against the 3:18.77 on screen). Checked in Alexis's recordings of 12 November 2026 (GRID.exe, claude/GRID-capture-20261112.md). |
| `steer` | memory read, then `clamp(-value, -1, 1)` | Steering, -1 full left to 1 full right, as the car's physics gets it (input channel 6, which the game keeps the other way round: this row flips it). Checked against the G25's own steering over USB (correlation 0.93) in Alexis's recording of 12 November 2026. Checked in Alexis's recordings of 12 November 2026 (GRID.exe, claude/GRID-capture-20261112.md). |
| `road_rumble` | memory read, then `clamp(value / 37, 0, 1)` | Surface rumble, 0 to 1. Raw: Surface rumble level, 0 to 37: 1 or 2 on kerbs. Checked in Alexis's recording of 3 November 2026. |
| `rev_max` | `hold(valid(rpm, rpm2) * max_revs / rev_frac, rev_frac > 0.3 && rev_frac < 0.97)` | This car's limiter, from rpm / rev_frac: 8000 (fastest class), 8200, 7000 and 6500 in Alexis's cars. |
| `impact_side` | `hit_strength > 0 ? (wall_side > 0 ? hit_strength / 8 : (wall_side < 0 ? -hit_strength / 8 : 0)) : 0` | Wall hit strength, + right, - left: the force the FFB plugin sends, which the G25 got over USB to the frame (3 November 2026). + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `car_hit` | `car_contact > 0 && hit_strength > 0 ? hit_strength / 8 : 0` | Hit strength while touching another car, 0 to 1. |
| `skid` | `speed > 0 && skids > 12 ? clamp((skids - 12) / 8, 0, 1) : 0` | Skidding, 0 to 1. |
| `shift` | `maxw(delta(gear) != 0 && speed > 0, 0.2)` | 1 for 0.2 s after a gear change. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed, assuming km/h (speed x Max speed undoes the division, so this stays in G). + speeding up, - slowing down. |
| `clock_moving` | `maxw(delta(valid(race_clock, 0)) > 0, 0.1)` | 1 while the race clock runs (held 0.1 s, as the plugin sometimes reads the same game frame twice); 0 while paused and once the race is over. |
| `racing` | `valid(race_on, -1) < 0 ? 1 : (race_on == 1 && valid(race_over, 1) == 0 && valid(car0_laps, 0) < valid(race_laps, 0) && clock_moving)` | 1 from GO to the finish line: the race is on and not over, the player has laps to go, and the race clock is moving (so 0 while paused, at TIME OVER, in the attract mode and menus). In Alexis's recording of 12 November 2026 it ran from GO to her pause, from the pause to TIME OVER, and from GO to the exact sample the game took her car at the finish line. If the race can't be read at all it counts as racing, so a failed read leaves the effects as they were before this row (it never failed in her recordings). |
| `lap` | `race_laps > 0 ? clamp(car0_laps + 1, 1, race_laps) : 0` | The lap the player is on, 1 to the laps in the race. |
| `final_lap` | `racing && race_laps > 1 && lap == race_laps` | 1 on the final lap. |
| `lap_line` | `maxw(delta(car0_laps) > 0 && car0_laps > 0, 1)` | 1 for 1 s at each lap line, the finish line included. |
| `position` | `valid(me, 0) == 0 ? place0 + 1 : (me == 1 ? place1 + 1 : place2 + 1)` | The player's place, 1 = first, as the HUD shows it (the game counts from 0). From GRID.exe (16 November 2026); not yet read in a recording. |
| `leader` | `racing && position == 1` | 1 while in the lead. |
| `car_in_race` (not exported) | `racing` | Common value Car_in_race: 1 from GO to the finish line, 0 while paused, at TIME OVER, in the attract mode and menus: the race clock object's flags and clock (checked in Alexis's recording of 12 November 2026). |
| `car_speed` (not exported) | `racing ? (speed * max_speed) : 0` | Common value Car_speed: speed in km/h as the speedo shows it, raw (the speed row divides by Max speed; this undoes it). 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_rpm` (not exported) | `racing ? (valid(rpm, rpm2) * max_revs) : 0` | Common value Car_rpm: engine RPM, raw, from rpm, or rpm2 when the first chain can't be read. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_gear` (not exported) | `racing ? (gear) : 0` | Common value Car_gear: gear. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_accel_g` (not exported) | `racing ? (accel_g) : 0` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_speed_kmh` (not exported) | `racing ? (speed * max_speed) : 0` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the speedo). Car_speed_mph is this / 1.609344. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_rev_limit_rpm` (not exported) | `racing ? (rev_frac > 0.3 ? round(rpm * max_revs / rev_frac / 100) * 100 : 0) : 0` | Common value Car_rev_limit_rpm: this car's limiter, RPM, worked out from the revs and the dial's fraction of the limiter (6500 to 8200 by car); 0 at low revs, where the plugin gives Max revs. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_position` (not exported) | `racing ? (position) : 0` | Common value Car_position: race position, 1 = first. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_lap` (not exported) | `racing ? (lap) : 0` | Common value Car_lap: the lap you are on, 1 = first. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_laps_total` (not exported) | `racing ? (race_laps) : 0` | Common value Car_laps_total: laps in the race (the game reads 1 in the menus, so 0 outside a race below). 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_race_time` (not exported) | `racing ? (race_clock) : 0` | Common value Car_race_time: the race clock (TT), seconds. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_brake` (not exported) | `racing ? (brake) : 0` | Common value Car_brake: brake pedal, 0 to 1, as the game uses it. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_steer` (not exported) | `racing ? (steer) : 0` | Common value Car_steer: steering, -1 full left to 1 full right, as the game uses it. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_impact` (not exported) | `racing ? (max(abs(impact_side), car_hit)) : 0` | Common value Car_impact: wall and car hits, 0 to 1 by strength. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_impact_side` (not exported) | `racing ? (sign(impact_side)) : 0` | Common value Car_impact_side: side of a wall hit, -1 left, 1 right. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_road_bump` (not exported) | `0` | Common value Car_road_bump: none: the wheel force is only hits, gear changes and kerbs (GRID recording, 3 November 2026; kerbs are in Car_off_road). The 0 row also stops the plugin working it out from the USB force, which would read each gear change as a bump. |
| `car_off_road` (not exported) | `racing ? (road_rumble) : 0` | Common value Car_off_road: surface rumble, 0 to 1. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_grip_loss` (not exported) | `racing ? (skid) : 0` | Common value Car_grip_loss: skidding, 0 to 1. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_cornering` (not exported) | `0` | Common value Car_cornering: none: the FFB plugin sends GRID no cornering force (a recording, 3 November 2026). The 0 row also stops the plugin working it out from the USB force, which would read a wall hit as cornering. |
| `car_rpm_frac` (not exported) | `racing ? (rev_frac) : 0` | Common value Car_rpm_frac: revs as a fraction of this car's limiter (6500 to 8200 by car): the rev limiter and engine effects follow every car (plugin 0.17.0; older plugins use revs / Max revs). 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_throttle` (not exported) | `racing ? (throttle) : 0` | Common value Car_throttle: throttle, 0 to 1, as the game uses it: the engine effects run at 60% off the throttle, full at full throttle. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `lamp_leader` (not exported) | `leader` | Common lamp Lamp_leader: in the lead, made from the race values (`leader`). |
| `lamp_final_lap` (not exported) | `final_lap` | Common lamp Lamp_final_lap: on the final lap. |
| `lamp_shift` (not exported) | `shift_lights / 2` | Common lamp Lamp_shift: the dial's shift lights: 0.5 with one lit (85 to 88% of the car's limiter), 1 with both. |

<a id="gticlub3"></a>
## GTI Club Supermini Festa

Prefix `GTICLUB3` (properties `TPTelemetry.GTICLUB3_<row>`), process `gti3japkey.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `race_loaded ? value / max_speed : 0` | Speed as the speedo works it out, always km/h (with the display set to mph the game converts it only for the screen). The game caps the speedo at 220 km/h. 0 outside a race. Divided by Max speed. Checked in Alexis's recording (8 November 2026). |
| `rpm` | memory read, then `race_loaded ? value * 60 / max_revs : 0` | Engine revs (the game keeps revs a second; x 60 here). The tacho follows these; above 7500 the game makes the needle bounce (the limiter, the same for every car); the engine itself reaches about 8000 with the wheels in the air. 0 outside a race. Divided by Max revs. Checked in Alexis's recording (8 November 2026). |
| `gear` | memory read, then `race_loaded ? value : 0` | Gear as the dash shows it: 1 upwards, -1 reverse. 0 outside a race. Checked in Alexis's recording (8 November 2026). |
| `ffb_flags` (not exported) | memory read, then `shr(value, 6)` | The top two bits of the vibration byte, 0 to 3 (meaning unknown: recorded so a capture shows when they change). Always 0 in Alexis's recording. From the game's code (gti3japkey.exe, read 8 November 2026); not yet checked in a recording. |
| `time_left` | memory read, then `race_loaded ? value / 1000 : 0` | Time left, seconds, as the race display shows it (the race code copies its milliseconds there each frame): counts down while racing and jumps up at each checkpoint. 0 outside a race. From the game's code (gti3japkey.exe, read 8 November 2026); not yet checked in a recording. |
| `position` | memory read, then `race_loaded ? value + 1 : 0` | Race position, 1 = first (the game stores 0 for first). 0 outside a race. Checked in Alexis's recording (8 November 2026). |
| `laps_done` | memory read, then `race_loaded ? value : 0` | Laps completed: 0 on the first lap. 0 outside a race. Checked in Alexis's recording (8 November 2026). |
| `finished` | memory read, then `race_loaded ? value : 0` | 1 once you have crossed the finish line. Checked in Alexis's recording (8 November 2026). |
| `lap_time` | memory read, then `race_loaded ? value / 30 : 0` | Current lap time, seconds. The game adds 1 each update and shows it as x 1000 / 30 ms, so this divides by 30 (it matched the lap times in Alexis's recording). Checked in Alexis's recording (8 November 2026). |
| `true_speed` | memory read, then `race_loaded ? value * 3.6 : 0` | The car's real speed, km/h, not capped (the game keeps m/s; x 3.6 here). 0 outside a race. Checked in Alexis's recording (8 November 2026). |
| `speedo_mph` (not exported) | memory read, then `race_loaded ? value : 0` | 1 when the game's speed display is set to mph, 0 for km/h (the race display's copy of the setting). From the game's code (gti3japkey.exe, read 8 November 2026); not yet checked in a recording. |
| `rpm_tacho` | memory read, then `race_loaded ? value : 0` | Revs as the tacho shows them (smoothed: the needle moves at most 500 a frame). 0 outside a race. Checked in Alexis's recording (8 November 2026). |
| `gear_stored` (not exported) | memory read, then `race_loaded ? signed8(value) : 0` | The gear as the game stores it, signed: matched the dash (1 to 5) all through Alexis's recording. Checked in Alexis's recording (8 November 2026). |
| `gearbox` | memory read, then `race_loaded ? value : 0` | 1 with the manual gearbox (Alexis's recording); probably 0 with the automatic. Checked in Alexis's recording (8 November 2026). |
| `lampaction` | memory read, then `band(value, 31) != 0` | LampAction output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampstart` | memory read, then `band(value, 31) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectup` | memory read, then `value / 31 * 100` | LampSelectUp output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectdown` | memory read, then `value / 31 * 100` | LampSelectDown output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectleft` | memory read, then `value / 31 * 100` | LampSelectLeft output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectright` | memory read, then `value / 31 * 100` | LampSelectRight output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `force` | `in_menu == 0 ? clamp(ffb_main > 128 ? (257 - ffb_main) / 128 : (ffb_main > 0 && ffb_main < 128 ? -ffb_main / 127 : 0), -1, 1) : 0` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `vibration` | `in_menu == 0 ? band(ffb_vibration, 63) / 63 : 0` | The game's vibration, 0 to 1: landings 0.79, other cars 0.57, walls and kerbs 0.29 to 0.43, a full-stop crash 1, kerb rumble 0.17 to 0.46, each fading away. |
| `in_race` | `valid(race_state, 0) == 5 && finished == 0` | 1 while racing (race state 5, go race) until you cross the finish line: the game keeps state 5 and drives the car on its own for a while after the finish. Checked in Alexis's recording (8 November 2026). |
| `race_loaded` (not exported) | `valid(race_state, 0) >= 1 && valid(race_state, 0) <= 9` | 1 from the start camera to time up: the car values below read 0 outside this, because the game leaves its pointer to the player car stale between races. |
| `checkpoint` | `in_race && maxw(delta(time_left) > 0.01, 1) > 0` | 1 for a second from each time extension (the time left going up), for a lamp. |
| `hurry` | `in_race && time_left > 0 && time_left <= 10` | 1 in the last 10 seconds, where the game starts its warning. |
| `leader` | `in_race && position == 1` | 1 while you lead, for a lamp. |
| `final_lap` | `in_race && laps_total > 0 && laps_done == laps_total - 1` | 1 on the last lap. |
| `last_lap` | `(laps_done == 7 ? lap7 : (laps_done == 6 ? lap6 : (laps_done == 5 ? lap5 : (laps_done == 4 ? lap4 : (laps_done == 3 ? lap3 : (laps_done == 2 ? lap2 : (laps_done == 1 ? lap1 : 0))))))) / 1000` | Last completed lap time, seconds (0 on the first lap). |
| `kerb` | `in_race && true_speed > 5 ? ((band(surface1, 255) == 2 && band(surface1, 256) == 0) + (band(surface2, 255) == 2 && band(surface2, 256) == 0) + (band(surface3, 255) == 2 && band(surface3, 256) == 0) + (band(surface4, 255) == 2 && band(surface4, 256) == 0)) / 4 : 0` | Wheels on a kerb (surface code 2), 0 to 1 (a quarter per wheel), while moving. Checked in Alexis's recording (8 November 2026). |
| `rough_ground` | `in_race && true_speed > 5 ? ((band(surface1, 255) == 5 && band(surface1, 256) == 0) + (band(surface2, 255) == 5 && band(surface2, 256) == 0) + (band(surface3, 255) == 5 && band(surface3, 256) == 0) + (band(surface4, 255) == 5 && band(surface4, 256) == 0)) / 4 : 0` | Wheels on surface code 5, which the game also rumbles on, 0 to 1 (a quarter per wheel), while moving. Not seen in Alexis's recording: perhaps grass or gravel elsewhere. |
| `jolt` (not exported) | `in_race && ffb_other == 15 && delta(band(ffb_vibration, 63)) > 6 ? band(ffb_vibration, 63) : 0` | The level of each new jolt the game sends the vibration motor (pattern 15), 0 between them: 50 a landing, 36 another car, 63 a full-stop crash, 10 to 27 a wall or mounting a kerb. Checked in Alexis's recording (8 November 2026). |
| `landing` | `maxw(jolt == 50, 0.25) > 0` | 1 for 0.25 s from each landing after a jump (13 out of 13 in Alexis's recording). |
| `car_hit` | `maxw(jolt == 36, 0.3) > 0` | 1 for 0.3 s from each hit with another car, a rub or a head-on (14 in Alexis's recording). No side. |
| `wall_jolt` (not exported) | `jolt > 0 && jolt < 30 && maxw(kerb > 0, 0.1) == 0` | A jolt of 10 to 27 with no wheel on a kerb in the last 0.1 s: a wall (mounting a kerb gives the same jolt, with a wheel already on it). Checked in Alexis's recording (8 November 2026). |
| `wall_hit` | `in_race && (maxw(wall_jolt, 0.3) > 0 \|\| maxw(jolt > 0 && jolt < 30, 0.3) > 0 && maxw(true_speed, 0.3) - true_speed > 8)` | 1 from a wall hit, held 0.3 s: a jolt of 10 to 27 with no wheel on a kerb, or one that costs more than 8 km/h within 0.3 s (a wall hit while riding a kerb; this comes on up to 0.2 s after the jolt, as the speed falls). No side. |
| `crash` | `maxw(jolt == 63, 0.5) > 0` | 1 for 0.5 s from a full-stop crash (the game's strongest jolt). |
| `hit` | `crash ? 1 : (wall_hit \|\| car_hit ? clamp(0.5 + (maxw(true_speed, 0.3) - true_speed) / 60, 0.5, 1) : 0)` | Walls and other cars, 0.5 to 1 by the km/h lost in the last 0.3 s (0.5 + loss / 60), and 1 for a full-stop crash. Landings are separate (landing). |
| `accel_g` | `ema(slope(true_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from true_speed (km/h). + speeding up, - slowing down. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_in_race` (not exported) | `in_race != 0` | Common value Car_in_race: 1 while racing. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the speedo, even with the display in mph). Car_speed_mph is this / 1.609344. |
| `car_position` (not exported) | `position` | Common value Car_position: race position, 1 = first. |
| `car_lap` (not exported) | `in_race ? min(laps_done + 1, max(laps_total, 1)) : 0` | Common value Car_lap: the lap you are on, 1 = first (laps completed + 1); 0 outside a race. |
| `car_laps_total` (not exported) | `laps_total` | Common value Car_laps_total: laps in the race. |
| `car_time_left` (not exported) | `time_left` | Common value Car_time_left: time left (RT), seconds. |
| `car_lap_time` (not exported) | `lap_time` | Common value Car_lap_time: the current lap's time, seconds. |
| `car_impact` (not exported) | `hit` | Common value Car_impact: walls and other cars, 0.5 to 1 by the km/h lost, and 1 for a full-stop crash, from the jolts the game sends its vibration motor (landings go to Car_road_bump). No side: the wheel force gave none at the walls in the recording. |
| `car_road_bump` (not exported) | `landing` | Common value Car_road_bump: landings after a jump, 1 for 0.25 s, from the game's landing jolt (13 out of 13 in Alexis's recording, 8 November 2026). The wheel force is worked out from an angle (steering or slip), so the plugin must not read bumps from it. |
| `car_rumble_strip` (not exported) | `kerb` | Common value Car_rumble_strip: wheels on a kerb, 0 to 1 (a quarter per wheel). |
| `car_off_road` (not exported) | `rough_ground` | Common value Car_off_road: on rough ground. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_select_up` (not exported) | `lampselectup` | Common lamp Lamp_select_up: menu select up (the game's `lampselectup`). |
| `lamp_select_down` (not exported) | `lampselectdown` | Common lamp Lamp_select_down: menu select down (the game's `lampselectdown`). |
| `lamp_select_left` (not exported) | `lampselectleft` | Common lamp Lamp_select_left: menu select left (the game's `lampselectleft`). |
| `lamp_select_right` (not exported) | `lampselectright` | Common lamp Lamp_select_right: menu select right (the game's `lampselectright`). |
| `lamp_action` (not exported) | `lampaction` | Common lamp Lamp_action: the cabinet's extra button (the game's `lampaction`). |
| `lamp_leader` (not exported) | `leader` | Common lamp Lamp_leader: in the lead, made from the race values (`leader`). |
| `lamp_checkpoint` (not exported) | `checkpoint` | Common lamp Lamp_checkpoint: a checkpoint passed or time extended (`checkpoint`). |
| `lamp_final_lap` (not exported) | `final_lap` | Common lamp Lamp_final_lap: on the final lap. |

<a id="h2overdrive"></a>
## H2Overdrive

Prefix `H2OVERDRIVE` (properties `TPTelemetry.H2OVERDRIVE_<row>`), process `sdaemon.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speedo` | `out_Speedo` | Output from OutputBlaster: Speedo (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `spring` | memory read, then `clamp(value / 1.25, 0, 1)` | Centring spring, 0 to 1 (the FFB plugin scales stiffness by 1/1.25). Raw: Centring stiffness the game asks for. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `force` | memory read, then `clamp(-value, -1, 1)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). Raw: Force the game asks for: + pushes one way, - the other. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `intake_left` | memory read, then `value * 100` | Intake Left output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `intake_center` | memory read, then `value * 100` | Intake Center output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `intake_right` | memory read, then `value * 100` | Intake Right output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `base0_left` | memory read, then `value * 100` | Base0 Left output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `base1_left` | memory read, then `value * 100` | Base1 Left output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `base0_right` | memory read, then `value * 100` | Base0 Right output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `base1_right` | memory read, then `value * 100` | Base1 Right output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `seat_left` | memory read, then `value * 100` | Seat Left output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `seat_right` | memory read, then `value * 100` | Seat Right output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `infinity_1` | memory read, then `value * 100` | Infinity 1 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `infinity_2` | memory read, then `value * 100` | Infinity 2 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `infinity_3` | memory read, then `value * 100` | Infinity 3 output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampleader` | memory read, then `value * 100` | LampLeader output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `boost_lamp` | `out_Boost_Lamp` | Output from OutputBlaster: Boost Lamp (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `keypad` | `out_Keypad` | Output from OutputBlaster: Keypad (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `throttle1` | `out_Throttle1` | Output from OutputBlaster: Throttle1 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `throttle2` | `out_Throttle2` | Output from OutputBlaster: Throttle2 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `throttle3` | `out_Throttle3` | Output from OutputBlaster: Throttle3 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `digit1speed` | `out_Digit1Speed` | Output from OutputBlaster: Digit1Speed (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `digit2speed` | `out_Digit2Speed` | Output from OutputBlaster: Digit2Speed (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `digit3speed` | `out_Digit3Speed` | Output from OutputBlaster: Digit3Speed (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `digit4speed` | `out_Digit4Speed` | Output from OutputBlaster: Digit4Speed (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |
| `lamp_boost` (not exported) | `boost_lamp` | Common lamp Lamp_boost: the boost lamp. |

<a id="harley"></a>
## Harley-Davidson: King of the Road

Prefix `HARLEY` (properties `TPTelemetry.HARLEY_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampstart` | `band(ob_mylamp, 296) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampleader` | `band(ob_mylamp, 100) != 0` | LampLeader output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampleader2` | `band(ob_mylamp, 50) != 0` | LampLeader2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |

<a id="hummer"></a>
## Hummer

Prefix `HUMMER` (properties `TPTelemetry.HUMMER_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampstart` | `band(ob_mylamp, 128) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_mylamp, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | `band(ob_mylamp, 16) != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampwhite` | `band(ob_mylamp, 100) != 0` | LampWhite output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_white` (not exported) | `lampwhite` | Common lamp Lamp_white: the cabinet's white lamp (`lampwhite`). |

<a id="hummerextreme"></a>
## Hummer Extreme Edition

Prefix `HUMMEREXTREME` (properties `TPTelemetry.HUMMEREXTREME_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampstart` | `band(ob_mylamp, 128) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_mylamp, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | `band(ob_mylamp, 16) != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampwhite` | `band(ob_mylamp, 100) != 0` | LampWhite output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_white` (not exported) | `lampwhite` | Common lamp Lamp_white: the cabinet's white lamp (`lampwhite`). |

<a id="hydrothunder"></a>
## Hydro Thunder

Prefix `HYDROTHUNDER` (properties `TPTelemetry.HYDROTHUNDER_<row>`), process `HYDRO_x64.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `boost` | `maxw(delta(boost_level) < 0, 0.15)` | 1 while the boost is draining, that is, while boosting. |
| `car_time_left` (not exported) | `timer` | Common value Car_time_left: time left, seconds, from the cheat table's timer (not yet checked in a recording). |
| `car_boost` (not exported) | `boost` | Common value Car_boost: boost, 0 or 1. |

<a id="id4"></a>
## Initial D Arcade Stage 4 (export)

Prefix `ID4` (properties `TPTelemetry.ID4_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `byte(ffb_raw, 0)` | Command: 132 constant force, 134 spring, 133 vibration, 128 (with byte 2 = 1) full spring. |
| `ffb_v1` | `byte(ffb_raw, 1)` | Direction for command 132 (0 or 1), period for 133. |
| `force` | `valid(hold(clamp(ffb_cmd == 132 && ffb_str > 0 ? (ffb_v1 == 0 ? -(32767 - ffb_str) / 32767 : (ffb_v1 == 1 ? ffb_str / 32767 : 0)) : 0, -1, 1), ffb_cmd == 132), 0)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 32767 : 1, (ffb_cmd == 134 && ffb_str > 0) \|\| (ffb_cmd == 128 && byte(ffb_raw, 2) == 1)), 0)` | Centring spring strength, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && ffb_v1 > 0 && ffb_str > 0 ? ffb_str / 32767 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `vibration_period_ms` | `ffb_cmd == 133 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0` | Vibration period, roughly milliseconds. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(ob_outputdata1, 128) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_outputdata1, 64) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectup` | `band(ob_outputdata1, 2) != 0` | LampSelectUp output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectdown` | `band(ob_outputdata1, 1) != 0` | LampSelectDown output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectleft` | `band(ob_outputdata2, 128) != 0` | LampSelectLeft output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectright` | `band(ob_outputdata2, 64) != 0` | LampSelectRight output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_select_up` (not exported) | `lampselectup` | Common lamp Lamp_select_up: menu select up (the game's `lampselectup`). |
| `lamp_select_down` (not exported) | `lampselectdown` | Common lamp Lamp_select_down: menu select down (the game's `lampselectdown`). |
| `lamp_select_left` (not exported) | `lampselectleft` | Common lamp Lamp_select_left: menu select left (the game's `lampselectleft`). |
| `lamp_select_right` (not exported) | `lampselectright` | Common lamp Lamp_select_right: menu select right (the game's `lampselectright`). |

<a id="id4jp"></a>
## Initial D Arcade Stage 4 (Japan)

Prefix `ID4JP` (properties `TPTelemetry.ID4JP_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampstart` | `out_LampStart` | Output from OutputBlaster: LampStart (0 or 1, or 0-255). Needs OutputBlaster running: OutputBlaster only knows the export version of Initial D 4, so these outputs have no memory addresses for this one. |
| `lampview1` | `out_LampView1` | Output from OutputBlaster: LampView1 (0 or 1, or 0-255). Needs OutputBlaster running: OutputBlaster only knows the export version of Initial D 4, so these outputs have no memory addresses for this one. |
| `lampselectup` | `out_LampSelectUp` | Output from OutputBlaster: LampSelectUp (0 or 1, or 0-255). Needs OutputBlaster running: OutputBlaster only knows the export version of Initial D 4, so these outputs have no memory addresses for this one. |
| `lampselectdown` | `out_LampSelectDown` | Output from OutputBlaster: LampSelectDown (0 or 1, or 0-255). Needs OutputBlaster running: OutputBlaster only knows the export version of Initial D 4, so these outputs have no memory addresses for this one. |
| `lampselectleft` | `out_LampSelectLeft` | Output from OutputBlaster: LampSelectLeft (0 or 1, or 0-255). Needs OutputBlaster running: OutputBlaster only knows the export version of Initial D 4, so these outputs have no memory addresses for this one. |
| `lampselectright` | `out_LampSelectRight` | Output from OutputBlaster: LampSelectRight (0 or 1, or 0-255). Needs OutputBlaster running: OutputBlaster only knows the export version of Initial D 4, so these outputs have no memory addresses for this one. |
| `ob_ffb` | `out_FFB` | Output from OutputBlaster: FFB, the force feedback value it sends to the cabinet's wheel. Needs OutputBlaster running: OutputBlaster only knows the export version of Initial D 4, so these outputs have no memory addresses for this one. |
| `ffb_cmd` | `byte(ffb_raw, 0)` | Command: 132 constant force, 134 spring, 133 vibration, 128 (with byte 2 = 1) full spring. |
| `ffb_v1` | `byte(ffb_raw, 1)` | Direction for command 132 (0 or 1), period for 133. |
| `force` | `valid(hold(clamp(ffb_cmd == 132 && ffb_str > 0 ? (ffb_v1 == 0 ? -(32767 - ffb_str) / 32767 : (ffb_v1 == 1 ? ffb_str / 32767 : 0)) : 0, -1, 1), ffb_cmd == 132), 0)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 32767 : 1, (ffb_cmd == 134 && ffb_str > 0) \|\| (ffb_cmd == 128 && byte(ffb_raw, 2) == 1)), 0)` | Centring spring strength, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && ffb_v1 > 0 && ffb_str > 0 ? ffb_str / 32767 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `vibration_period_ms` | `ffb_cmd == 133 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0` | Vibration period, roughly milliseconds. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_select_up` (not exported) | `lampselectup` | Common lamp Lamp_select_up: menu select up (the game's `lampselectup`). |
| `lamp_select_down` (not exported) | `lampselectdown` | Common lamp Lamp_select_down: menu select down (the game's `lampselectdown`). |
| `lamp_select_left` (not exported) | `lampselectleft` | Common lamp Lamp_select_left: menu select left (the game's `lampselectleft`). |
| `lamp_select_right` (not exported) | `lampselectright` | Common lamp Lamp_select_right: menu select right (the game's `lampselectright`). |

<a id="id5"></a>
## Initial D Arcade Stage 5

Prefix `ID5` (properties `TPTelemetry.ID5_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `byte(ffb_raw, 0)` | Command: 132 constant force, 134 spring, 133 vibration, 128 (with byte 2 = 1) full spring. |
| `ffb_v1` | `byte(ffb_raw, 1)` | Direction for command 132 (0 or 1), period for 133. |
| `force` | `valid(hold(clamp(ffb_cmd == 132 && ffb_str > 0 ? (ffb_v1 == 0 ? -(32767 - ffb_str) / 32767 : (ffb_v1 == 1 ? ffb_str / 32767 : 0)) : 0, -1, 1), ffb_cmd == 132), 0)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 32767 : 1, (ffb_cmd == 134 && ffb_str > 0) \|\| (ffb_cmd == 128 && byte(ffb_raw, 2) == 1)), 0)` | Centring spring strength, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && ffb_v1 > 0 && ffb_str > 0 ? ffb_str / 32767 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `vibration_period_ms` | `ffb_cmd == 133 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0` | Vibration period, roughly milliseconds. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(ob_outputdata1, 128) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_outputdata1, 64) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectup` | `band(ob_outputdata1, 2) != 0` | LampSelectUp output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectdown` | `band(ob_outputdata1, 1) != 0` | LampSelectDown output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectleft` | `band(ob_outputdata2, 128) != 0` | LampSelectLeft output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectright` | `band(ob_outputdata2, 64) != 0` | LampSelectRight output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_select_up` (not exported) | `lampselectup` | Common lamp Lamp_select_up: menu select up (the game's `lampselectup`). |
| `lamp_select_down` (not exported) | `lampselectdown` | Common lamp Lamp_select_down: menu select down (the game's `lampselectdown`). |
| `lamp_select_left` (not exported) | `lampselectleft` | Common lamp Lamp_select_left: menu select left (the game's `lampselectleft`). |
| `lamp_select_right` (not exported) | `lampselectright` | Common lamp Lamp_select_right: menu select right (the game's `lampselectright`). |

<a id="id6"></a>
## Initial D Arcade Stage 6 AA

Prefix `ID6` (properties `TPTelemetry.ID6_<row>`), process `InitialD6_GLW_RE_SBUU_dump.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `tp_ok` | `tp_connected` | 1 while TeknoParrot's shared memory is available. |
| `ffb_raw` | `tp_jvs2` | Raw command from TeknoParrot (slot 2): byte 2 = command, bytes 0 and 1 = values. |
| `ffb_cmd` (not exported) | `byte(tp_jvs2, 2)` | Command: 4 constant force, 6 spring, 5 vibration, 0 (with value 1) full spring. |
| `ffb_v0` (not exported) | `byte(tp_jvs2, 0)` | First value byte. |
| `ffb_v1` (not exported) | `byte(tp_jvs2, 1)` | Second value byte (direction for command 4, period for 5). |
| `v12` (not exported) | memory read, then `value == 1313406292` | 1 on v1.2, the version these memory rows are for. (ID6 v1.2 code) Raw: The exe's build time stamp: 1313406292 for v1.2 (15 August 2011). The memory rows are for v1.2; on another version they read 0 (v1.0's addresses differ: only its lamps are known). From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `race_state` | memory read, then `v12 ? value : 0` | Race state: 2 set-up, 3 the rolling start and countdown (7 s in the story prologue), 4 racing (from the moment the race clock starts), 5 a car has reached the goal, 6 after. Not readable outside a race. From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `speed_0` (not exported) | memory read, then `v12 ? value : 0` | Slot 0 car: Speed, km/h: the speedo, to within 1 km/h at 30 of Alexis's readings (the game keeps m/s; the status block has km/h). From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `speed_1` (not exported) | memory read, then `v12 ? value : 0` | Slot 1 car: Speed, km/h: the speedo, to within 1 km/h at 30 of Alexis's readings (the game keeps m/s; the status block has km/h). From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `rpm_0` (not exported) | memory read, then `v12 ? value : 0` | Slot 0 car: Engine revs: the GT-R's on-screen revs within about 150 at 30 readings, and the Trueno's rev counter reads 8k at the limiter. Idles at 800; the R32 GT-R and AE86 Trueno both limit at 8140. From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `rpm_1` (not exported) | memory read, then `v12 ? value : 0` | Slot 1 car: Engine revs: the GT-R's on-screen revs within about 150 at 30 readings, and the Trueno's rev counter reads 8k at the limiter. Idles at 800; the R32 GT-R and AE86 Trueno both limit at 8140. From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `rpm_tacho_0` (not exported) | memory read, then `v12 ? value : 0` | Slot 0 car: Engine revs times a factor for each car (1.08 R32 GT-R, 1.23 AE86 Trueno, 1.035 Civic). Not what the screen shows in the GT-R or the Trueno (the Trueno's would read 10,000 on the limiter). From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `rpm_tacho_1` (not exported) | memory read, then `v12 ? value : 0` | Slot 1 car: Engine revs times a factor for each car (1.08 R32 GT-R, 1.23 AE86 Trueno, 1.035 Civic). Not what the screen shows in the GT-R or the Trueno (the Trueno's would read 10,000 on the limiter). From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `gear_0` (not exported) | memory read, then `v12 ? value : 0` | Slot 0 car: Gear, 1 up (the game keeps at least 1 here): every change in the recording. From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `gear_1` (not exported) | memory read, then `v12 ? value : 0` | Slot 1 car: Gear, 1 up (the game keeps at least 1 here): every change in the recording. From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `throttle_0` (not exported) | memory read, then `v12 ? value : 0` | Slot 0 car: Throttle, 0 to 1 (the game counts 5 s at 0 as the player gone idle). From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `throttle_1` (not exported) | memory read, then `v12 ? value : 0` | Slot 1 car: Throttle, 0 to 1 (the game counts 5 s at 0 as the player gone idle). From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `brake_0` (not exported) | memory read, then `v12 ? value : 0` | Slot 0 car: Brake, 0 to 1: read 1 with the throttle off and the car slowing hard. From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `brake_1` (not exported) | memory read, then `v12 ? value : 0` | Slot 1 car: Brake, 0 to 1: read 1 with the throttle off and the car slowing hard. From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `drift_angle_0` (not exported) | memory read, then `v12 ? value : 0` | Slot 0 car: Drift angle, degrees: between where the car points and where it is going (the physics' own: body yaw P+124 less the direction of travel P+148, wrapped to +-180, which the game turns into its sideways grip). + the car pointing right of its path (a right-hand drift), - left; 0 below 10 km/h. Under about 7 degrees in ordinary cornering, 15 to 20 in a gentle drift, 25 to 40 moderate, about 50 extreme. From the exe, and checked in two drifting recordings (9 November 2026). From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `drift_angle_1` (not exported) | memory read, then `v12 ? value : 0` | Slot 1 car: Drift angle, degrees: between where the car points and where it is going (the physics' own: body yaw P+124 less the direction of travel P+148, wrapped to +-180, which the game turns into its sideways grip). + the car pointing right of its path (a right-hand drift), - left; 0 below 10 km/h. Under about 7 degrees in ordinary cornering, 15 to 20 in a gentle drift, 25 to 40 moderate, about 50 extreme. From the exe, and checked in two drifting recordings (9 November 2026). From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `events_0` (not exported) | memory read, then `v12 ? value : 0` | Slot 0 car: The car's event flags from the last frame: the game plays its collision, gutter, landing and joint sounds from these. The rows after decode them. From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `events_1` (not exported) | memory read, then `v12 ? value : 0` | Slot 1 car: The car's event flags from the last frame: the game plays its collision, gutter, landing and joint sounds from these. The rows after decode them. From the game's code (v1.2 exe, read 8 November 2026). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `speed` | `race_loaded ? (valid(my_slot, 0) == 1 ? speed_1 : speed_0) / max_speed : 0` | Speed, km/h: the speedo, to within 1 km/h at 30 of Alexis's readings (the game keeps m/s; the status block has km/h). Your car, whichever slot it is in. (ID6 v1.2 code) |
| `rpm` | `race_loaded ? (valid(my_slot, 0) == 1 ? rpm_1 : rpm_0) / max_revs : 0` | Engine revs: the GT-R's on-screen revs within about 150 at 30 readings, and the Trueno's rev counter reads 8k at the limiter. Idles at 800; the R32 GT-R and AE86 Trueno both limit at 8140. Your car, whichever slot it is in. (ID6 v1.2 code) |
| `gear` | `race_loaded ? (valid(my_slot, 0) == 1 ? gear_1 : gear_0) : 0` | Gear, 1 up (the game keeps at least 1 here): every change in the recording. Your car, whichever slot it is in. (ID6 v1.2 code) |
| `force` | `hold(ffb_cmd == 4 && ffb_v0 > 0 && ffb_v0 < 128 ? (ffb_v1 == 0 ? -(128 - ffb_v0) / 127 : (ffb_v1 == 1 ? ffb_v0 / 127 : 0)) : 0, ffb_cmd == 4)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `hold(ffb_cmd == 6 ? ffb_v0 / 127 : 1, (ffb_cmd == 6 && ffb_v0 > 0 && ffb_v0 < 128) \|\| (ffb_cmd == 0 && ffb_v0 == 1))` | Centring spring strength, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 5 && ffb_v0 > 0 && ffb_v1 > 0 ? ffb_v0 / 127 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `vibration_period_ms` | `ffb_cmd == 5 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0` | Vibration period, roughly milliseconds. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `in_race` | `valid(race_state, 0) == 4` | 1 while racing: race state 4, from the start to the finish line (the event flags only count then). Checked in a recording, 9 November 2026: on at the start, off on the line. (ID6 v1.2 code) |
| `race_loaded` (not exported) | `valid(race_state, 0) >= 3 && valid(race_state, 0) <= 6` | 1 from the start to after the goal: the car rows read 0 outside this. (ID6 v1.2 code) |
| `countdown_live` | `valid(race_state, 0) == 3 && rpm * max_revs > 850` | 1 in the countdown once the engine runs: in the rolling start the car is driven at 170 to 185 km/h with live revs for the last 6 s before the race clock starts (recording, 9 November 2026). Car_in_race includes it, so the engine effects start with the engine. (ID6 v1.2 code) |
| `rpm_tacho` | `race_loaded ? (valid(my_slot, 0) == 1 ? rpm_tacho_1 : rpm_tacho_0) : 0` | Engine revs times a factor for each car (1.08 R32 GT-R, 1.23 AE86 Trueno, 1.035 Civic). Not what the screen shows in the GT-R or the Trueno (the Trueno's would read 10,000 on the limiter). Your car, whichever slot it is in. (ID6 v1.2 code) |
| `throttle` | `race_loaded ? (valid(my_slot, 0) == 1 ? throttle_1 : throttle_0) : 0` | Throttle, 0 to 1 (the game counts 5 s at 0 as the player gone idle). Your car, whichever slot it is in. (ID6 v1.2 code) |
| `brake` | `race_loaded ? (valid(my_slot, 0) == 1 ? brake_1 : brake_0) : 0` | Brake, 0 to 1: read 1 with the throttle off and the car slowing hard. Your car, whichever slot it is in. (ID6 v1.2 code) |
| `drift_angle` | `race_loaded && speed * max_speed > 10 ? -(valid(my_slot, 0) == 1 ? drift_angle_1 : drift_angle_0) * 57.29578 : 0` | Drift angle, degrees: between where the car points and where it is going (the physics' own: body yaw P+124 less the direction of travel P+148, wrapped to +-180, which the game turns into its sideways grip). + the car pointing right of its path (a right-hand drift), - left; 0 below 10 km/h. Under about 7 degrees in ordinary cornering, 15 to 20 in a gentle drift, 25 to 40 moderate, about 50 extreme. From the exe, and checked in two drifting recordings (9 November 2026). Your car, whichever slot it is in. (ID6 v1.2 code) |
| `events` | `race_loaded ? (valid(my_slot, 0) == 1 ? events_1 : events_0) : 0` | The car's event flags from the last frame: the game plays its collision, gutter, landing and joint sounds from these. The rows after decode them. Your car, whichever slot it is in. (ID6 v1.2 code) |
| `wall_left` | `in_race && band(events, 36864) != 0` | 1 while touching a wall (0x8000) or guard rail (0x1000) on the left (event bits 0x9000). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `wall_right` | `in_race && band(events, 147456) != 0` | 1 while touching a wall (0x20000) or guard rail (0x4000) on the right (event bits 0x24000). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `wall_front` | `in_race && band(events, 73728) != 0` | 1 while touching a wall or guard rail ahead (event bits 0x12000). Not seen yet (none in the 9 November 2026 recordings). (ID6 v1.2 code) |
| `car_contact` | `in_race && band(events, 524288) != 0` | 1 while touching the other car (while the cars grind it drops out for a frame or so every 0.2 s) (event bits 0x80000). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `gutter` | `in_race && band(events, 3) != 0` | 1 while a wheel is in the roadside gutter (0x1 left, 0x2 right). Wall hits mostly come with it, since the gutter runs along the wall; on its own it is the wheels running in the gutter (event bits 0x3). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `road_joint` | `in_race && band(events, 2048) != 0` | 1 while crossing a road joint (event bits 0x800). Not seen yet (none in the 9 November 2026 recordings). (ID6 v1.2 code) |
| `gutter_drop` | `in_race && band(events, 192) != 0` | 1 while the gutter technique sound ("mizootoshi"), left or right (event bits 0xc0). Not seen yet (none in the 9 November 2026 recordings). (ID6 v1.2 code) |
| `drain` | `in_race && band(events, 12) != 0` | 1 while running over a drain cover (event bits 0xc). Not seen yet (none in the 9 November 2026 recordings). (ID6 v1.2 code) |
| `oil` | `in_race && band(events, 48) != 0` | 1 while on oil (event bits 0x30). Not seen yet (none in the 9 November 2026 recordings). (ID6 v1.2 code) |
| `leaves` | `in_race && band(events, 1024) != 0` | 1 while a wheel in the leaves at the side of the road (Irohazaka) (event bits 0x400). Checked in Alexis's recordings of 9 November 2026. (ID6 v1.2 code) |
| `landing` | `in_race && maxw(band(events, 256) != 0 && prev(band(events, 256)) == 0, 0.25) > 0` | 1 for 0.25 s as the car lands (event bit 0x100 coming on). The game leaves the bit on until the car next leaves the ground, so only its start counts. Both landings in Alexis's Irohazaka recording of 9 November 2026 came through. (ID6 v1.2 code) |
| `rumble_strip` | `in_race && (band(events, 512) != 0 \|\| maxw(abs(vibration * 127 - 10) < 0.5, 0.3) > 0)` | On a rumble strip: the game's vibration command at level 10 (its period follows the speed), held 0.3 s. Every ripple strip Alexis marked on Irohazaka (9 November 2026) came through this way; the event bit 0x200 ("gensokutai") never came on. (ID6 v1.2 code) |
| `hit` | `in_race && maxw(((wall_left \|\| wall_right \|\| wall_front) && prev(maxw(wall_left \|\| wall_right \|\| wall_front, 0.15)) == 0) \|\| (car_contact && prev(maxw(car_contact, 0.15)) == 0), 0.3) > 0` | 1 for 0.3 s from the start of a contact with a wall, guard rail or the other car (where the game plays its collision sound). Touches less than 0.15 s apart count as one, so a grind along the other car is one hit, not one every 0.2 s. Checked in a recording, 9 November 2026. (ID6 v1.2 code) |
| `hit_side` | `valid(hold(wall_right - wall_left, wall_right != wall_left), 0)` | Side of the last wall contact, +1 right, -1 left. (ID6 v1.2 code) |
| `wall_contact` | `minw(wall_left \|\| wall_right, 0.3) ? (wall_right - wall_left) : 0` | Scraping along a wall or guard rail for 0.3 s or more: +1 right, -1 left. (ID6 v1.2 code) |
| `rough_ground` | `gutter \|\| drain \|\| leaves` | 1 with a wheel in the gutter, over a drain cover or on leaves. (ID6 v1.2 code) |
| `shift` | `in_race && maxw(delta(gear) != 0, 0.2) > 0` | 1 for 0.2 s after a gear change. (ID6 v1.2 code) |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed (km/h). + speeding up, - slowing down. (ID6 v1.2 code) |
| `lampstart` | `band(v12 ? lamps_a12 : lamps_a10, 128) != 0` | Lamp, 0 or 1, from game memory at the address OutputBlaster uses for this version (no OutputBlaster needed). (ID6 v1.2 code) |
| `lampview1` | `band(v12 ? lamps_a12 : lamps_a10, 64) != 0` | Lamp, 0 or 1, from game memory at the address OutputBlaster uses for this version (no OutputBlaster needed). (ID6 v1.2 code) |
| `lampselectup` | `band(v12 ? lamps_a12 : lamps_a10, 2) != 0` | Lamp, 0 or 1, from game memory at the address OutputBlaster uses for this version (no OutputBlaster needed). (ID6 v1.2 code) |
| `lampselectdown` | `band(v12 ? lamps_a12 : lamps_a10, 1) != 0` | Lamp, 0 or 1, from game memory at the address OutputBlaster uses for this version (no OutputBlaster needed). (ID6 v1.2 code) |
| `lampselectleft` | `band(v12 ? lamps_b12 : lamps_b10, 128) != 0` | Lamp, 0 or 1, from game memory at the address OutputBlaster uses for this version (no OutputBlaster needed). (ID6 v1.2 code) |
| `lampselectright` | `band(v12 ? lamps_b12 : lamps_b10, 64) != 0` | Lamp, 0 or 1, from game memory at the address OutputBlaster uses for this version (no OutputBlaster needed). (ID6 v1.2 code) |
| `car_in_race` (not exported) | `in_race \|\| countdown_live` | Common value Car_in_race: 1 while racing, and in the countdown once the engine runs (the rolling start drives the car at 170 to 185 km/h for 6 s before the race clock starts). |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the speedo). Car_speed_mph is this / 1.609344. |
| `car_brake` (not exported) | `brake` | Common value Car_brake: brake pedal, 0 to 1, as the game uses it. |
| `car_impact` (not exported) | `hit ? clamp(0.5 + (maxw(speed * max_speed, 0.3) - speed * max_speed) / 60, 0.5, 1) : 0` | Common value Car_impact: contact with a wall, guard rail or the other car, 0.5 to 1 by the km/h lost in the last 0.3 s (0.5 + loss / 60). Checked in a recording, 9 November 2026. |
| `car_impact_side` (not exported) | `hit ? sign(maxw(wall_right, 0.3) - maxw(wall_left, 0.3)) : 0` | Common value Car_impact_side: side of a wall or guard rail hit, -1 left, 1 right (0 for the other car, whose side the game doesn't give). |
| `car_wall_contact` (not exported) | `wall_contact` | Common value Car_wall_contact: scraping along a wall or guard rail, -1 left, 1 right. |
| `car_road_bump` (not exported) | `max(maxw(road_joint, 0.15) * 0.6, landing)` | Common value Car_road_bump: road joints (0.6, held 0.15 s) and landings (1 for 0.25 s), from the events the game plays their sounds from. |
| `car_rumble_strip` (not exported) | `rumble_strip` | Common value Car_rumble_strip: 1 on a ripple strip. |
| `car_off_road` (not exported) | `rough_ground` | Common value Car_off_road: on rough ground. |
| `car_drift` (not exported) | `(1 - pow(1 - clamp((abs(drift_angle) - 5) / 45, 0, 1), 2)) * sqrt(clamp((speed * max_speed - 20) / 80, 0, 1))` | Common value Car_drift: drifting, 0 to 1: the drift angle part (nothing under 5 degrees, as ordinary cornering stays under about 7; climbing fast through the mid angles to full at 50, Alexis's extreme drifts) times the speed part (nothing under 20 km/h, then a square root up to full at 100 km/h). Alexis, 10 November 2026: a gentle drift at 134 km/h reads about 0.5, a moderate hairpin at 73 km/h about 0.75, an extreme hairpin at 74 km/h about 0.8. With no slip value of its own, ID6's Car_grip_loss follows it. |
| `car_drift_angle` (not exported) | `drift_angle` | Common value Car_drift_angle: the drift angle in degrees, + pointing right of the car's path (a right-hand drift), - left. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `clamp(vibration / 0.15, 0, 1)` | Common value Car_vibration: the game's own vibration command, scaled: it sends 0.16 (20 of 127) as a wheel drops into or out of the gutter, 0.06 pulses while scraping a wall and 0.04 at contact with the other car, so 0.15 and over reads 1. |
| `car_throttle` (not exported) | `throttle` | Common value Car_throttle: throttle, 0 to 1: the engine effects run at 60% off the throttle, full at full throttle. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_select_up` (not exported) | `lampselectup` | Common lamp Lamp_select_up: menu select up (the game's `lampselectup`). |
| `lamp_select_down` (not exported) | `lampselectdown` | Common lamp Lamp_select_down: menu select down (the game's `lampselectdown`). |
| `lamp_select_left` (not exported) | `lampselectleft` | Common lamp Lamp_select_left: menu select left (the game's `lampselectleft`). |
| `lamp_select_right` (not exported) | `lampselectright` | Common lamp Lamp_select_right: menu select right (the game's `lampselectright`). |

<a id="id7"></a>
## Initial D Arcade Stage 7 AAX

Prefix `ID7` (properties `TPTelemetry.ID7_<row>`), process `InitialD7_GLW_RE_SBYD.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `tp_ok` | `tp_connected` | 1 while TeknoParrot's shared memory is available. |
| `ffb_raw` | `tp_jvs2` | Raw command from TeknoParrot (slot 2): byte 2 = command, bytes 0 and 1 = values. |
| `ffb_cmd` (not exported) | `byte(tp_jvs2, 2)` | Command: 4 constant force, 6 spring, 5 vibration, 0 (with value 1) full spring. |
| `ffb_v0` (not exported) | `byte(tp_jvs2, 0)` | First value byte. |
| `ffb_v1` (not exported) | `byte(tp_jvs2, 1)` | Second value byte (direction for command 4, period for 5). |
| `force` | `hold(ffb_cmd == 4 && ffb_v0 > 0 && ffb_v0 < 128 ? (ffb_v1 == 0 ? -(128 - ffb_v0) / 127 : (ffb_v1 == 1 ? ffb_v0 / 127 : 0)) : 0, ffb_cmd == 4)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `hold(ffb_cmd == 6 ? ffb_v0 / 127 : 1, (ffb_cmd == 6 && ffb_v0 > 0 && ffb_v0 < 128) \|\| (ffb_cmd == 0 && ffb_v0 == 1))` | Centring spring strength, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 5 && ffb_v0 > 0 && ffb_v1 > 0 ? ffb_v0 / 127 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `vibration_period_ms` | `ffb_cmd == 5 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0` | Vibration period, roughly milliseconds. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(ob_outputdata1, 128) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_outputdata1, 64) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectup` | `band(ob_outputdata1, 2) != 0` | LampSelectUp output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectdown` | `band(ob_outputdata1, 1) != 0` | LampSelectDown output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectleft` | `band(ob_outputdata2, 128) != 0` | LampSelectLeft output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectright` | `band(ob_outputdata2, 64) != 0` | LampSelectRight output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_select_up` (not exported) | `lampselectup` | Common lamp Lamp_select_up: menu select up (the game's `lampselectup`). |
| `lamp_select_down` (not exported) | `lampselectdown` | Common lamp Lamp_select_down: menu select down (the game's `lampselectdown`). |
| `lamp_select_left` (not exported) | `lampselectleft` | Common lamp Lamp_select_left: menu select left (the game's `lampselectleft`). |
| `lamp_select_right` (not exported) | `lampselectright` | Common lamp Lamp_select_right: menu select right (the game's `lampselectright`). |

<a id="id8"></a>
## Initial D Arcade Stage 8 Infinity

Prefix `ID8` (properties `TPTelemetry.ID8_<row>`), process `InitialD8_GLW_RE_SBZZ_redumped_.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `tp_ok` | `tp_connected` | 1 while TeknoParrot's shared memory is available. |
| `ffb_raw` | `tp_jvs2` | Raw command from TeknoParrot (slot 2): byte 2 = command, bytes 0 and 1 = values. |
| `ffb_cmd` (not exported) | `byte(tp_jvs2, 2)` | Command: 4 constant force, 6 spring, 5 vibration, 0 (with value 1) full spring. |
| `ffb_v0` (not exported) | `byte(tp_jvs2, 0)` | First value byte. |
| `ffb_v1` (not exported) | `byte(tp_jvs2, 1)` | Second value byte (direction for command 4, period for 5). |
| `force` | `hold(ffb_cmd == 4 && ffb_v0 > 0 && ffb_v0 < 128 ? (ffb_v1 == 0 ? -(128 - ffb_v0) / 127 : (ffb_v1 == 1 ? ffb_v0 / 127 : 0)) : 0, ffb_cmd == 4)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `hold(ffb_cmd == 6 ? ffb_v0 / 127 : 1, (ffb_cmd == 6 && ffb_v0 > 0 && ffb_v0 < 128) \|\| (ffb_cmd == 0 && ffb_v0 == 1))` | Centring spring strength, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 5 && ffb_v0 > 0 && ffb_v1 > 0 ? ffb_v0 / 127 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `vibration_period_ms` | `ffb_cmd == 5 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0` | Vibration period, roughly milliseconds. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(ob_outputdata1, 128) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_outputdata1, 64) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectup` | `band(ob_outputdata1, 2) != 0` | LampSelectUp output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectdown` | `band(ob_outputdata1, 1) != 0` | LampSelectDown output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectleft` | `band(ob_outputdata2, 128) != 0` | LampSelectLeft output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectright` | `band(ob_outputdata2, 64) != 0` | LampSelectRight output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_select_up` (not exported) | `lampselectup` | Common lamp Lamp_select_up: menu select up (the game's `lampselectup`). |
| `lamp_select_down` (not exported) | `lampselectdown` | Common lamp Lamp_select_down: menu select down (the game's `lampselectdown`). |
| `lamp_select_left` (not exported) | `lampselectleft` | Common lamp Lamp_select_left: menu select left (the game's `lampselectleft`). |
| `lamp_select_right` (not exported) | `lampselectright` | Common lamp Lamp_select_right: menu select right (the game's `lampselectright`). |

<a id="id0v131"></a>
## Initial D Arcade Stage Zero v1.31

Prefix `ID0V131` (properties `TPTelemetry.ID0V131_<row>`), process `InitialD0_DX11_Nu.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `byte(ffb_raw, 0)` | Command: 132 constant force, 134 spring, 133 vibration, 128 (with byte 2 = 1) full spring. |
| `ffb_v1` | `byte(ffb_raw, 1)` | Direction for command 132 (0 or 1), period for 133. |
| `force` | `valid(hold(clamp(ffb_cmd == 132 && ffb_str > 0 ? (ffb_v1 == 0 ? -(32767 - ffb_str) / 32767 : (ffb_v1 == 1 ? ffb_str / 32767 : 0)) : 0, -1, 1), ffb_cmd == 132), 0)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 32767 : 1, (ffb_cmd == 134 && ffb_str > 0) \|\| (ffb_cmd == 128 && byte(ffb_raw, 2) == 1)), 0)` | Centring spring strength, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && ffb_v1 > 0 && ffb_str > 0 ? ffb_str / 32767 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `vibration_period_ms` | `ffb_cmd == 133 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0` | Vibration period, roughly milliseconds. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(ob_outputdata1, 128) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_outputdata1, 64) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectup` | `band(ob_outputdata1, 2) != 0` | LampSelectUp output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectdown` | `band(ob_outputdata1, 1) != 0` | LampSelectDown output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectleft` | `band(ob_outputdata2, 128) != 0` | LampSelectLeft output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectright` | `band(ob_outputdata2, 64) != 0` | LampSelectRight output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_select_up` (not exported) | `lampselectup` | Common lamp Lamp_select_up: menu select up (the game's `lampselectup`). |
| `lamp_select_down` (not exported) | `lampselectdown` | Common lamp Lamp_select_down: menu select down (the game's `lampselectdown`). |
| `lamp_select_left` (not exported) | `lampselectleft` | Common lamp Lamp_select_left: menu select left (the game's `lampselectleft`). |
| `lamp_select_right` (not exported) | `lampselectright` | Common lamp Lamp_select_right: menu select right (the game's `lampselectright`). |

<a id="id0v211"></a>
## Initial D Arcade Stage Zero v2.11

Prefix `ID0V211` (properties `TPTelemetry.ID0V211_<row>`), process `InitialD0_DX11_Nu.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `byte(ffb_raw, 0)` | Command: 132 constant force, 134 spring, 133 vibration, 128 (with byte 2 = 1) full spring. |
| `ffb_v1` | `byte(ffb_raw, 1)` | Direction for command 132 (0 or 1), period for 133. |
| `force` | `valid(hold(clamp(ffb_cmd == 132 && ffb_str > 0 ? (ffb_v1 == 0 ? -(32767 - ffb_str) / 32767 : (ffb_v1 == 1 ? ffb_str / 32767 : 0)) : 0, -1, 1), ffb_cmd == 132), 0)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 32767 : 1, (ffb_cmd == 134 && ffb_str > 0) \|\| (ffb_cmd == 128 && byte(ffb_raw, 2) == 1)), 0)` | Centring spring strength, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && ffb_v1 > 0 && ffb_str > 0 ? ffb_str / 32767 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `vibration_period_ms` | `ffb_cmd == 133 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0` | Vibration period, roughly milliseconds. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(ob_outputdata1, 128) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_outputdata1, 64) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectup` | `band(ob_outputdata1, 2) != 0` | LampSelectUp output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectdown` | `band(ob_outputdata1, 1) != 0` | LampSelectDown output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectleft` | `band(ob_outputdata2, 128) != 0` | LampSelectLeft output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampselectright` | `band(ob_outputdata2, 64) != 0` | LampSelectRight output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_select_up` (not exported) | `lampselectup` | Common lamp Lamp_select_up: menu select up (the game's `lampselectup`). |
| `lamp_select_down` (not exported) | `lampselectdown` | Common lamp Lamp_select_down: menu select down (the game's `lampselectdown`). |
| `lamp_select_left` (not exported) | `lampselectleft` | Common lamp Lamp_select_left: menu select left (the game's `lampselectleft`). |
| `lamp_select_right` (not exported) | `lampselectright` | Common lamp Lamp_select_right: menu select right (the game's `lampselectright`). |

<a id="id0v230"></a>
## Initial D Arcade Stage Zero v2.30

Prefix `ID0V230` (properties `TPTelemetry.ID0V230_<row>`), process `InitialD0_DX11_Nu.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `game_mode` | memory read, then `band(value, 255)` | Game mode: 1 test, 2 time attack, 3 story, 4 in-store VS, 5 online battle, 7, 9 and 11 the attract demo's replays (9 is also the live race), 15 2-on-2 VS, 16 tutorial (the story's intro race for a course), 17 beginner online. Seen: 16 and 2. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `time_left` | memory read, then `race_loaded ? value / 1000 : 0` | Time left (RT, on screen in both the tutorial and time attack), seconds (the game keeps milliseconds: the cheat table's "Stage_Tmr"). 120 at GO in both recordings; each checkpoint's extension is added over a second or so (see time_extension); online battles can run 2 s past 0. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `gap` | memory read, then `race_loaded && rival_race ? value : 0` | Distance to the rival along the course, + you ahead, - behind (the game's units, probably metres: the game's own difference between the two cars' progress). Only against a rival (not time attack). In ID0-1 it changed sign at each of Alexis's passes (TT 0:38.86, 0:50.41, 0:59.95) and read 51 at the line. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `speed` | `race_loaded ? (valid(my_slot, 0) == 1 ? speed_1 : speed_0) / max_speed : 0` | Speed, km/h: the speedo (all five of Alexis's readings matched to the km/h: 160, 167 and 203 in the Trueno, 113 and 105 in the RX-7). Your car, whichever slot it is in. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `rpm` | `race_loaded ? ((valid(my_slot, 0) == 1 ? rpm_1 : rpm_0) > 0 ? (valid(my_slot, 0) == 1 ? rpm_1 : rpm_0) : rpm_auto * 0.885) / max_revs : 0` | The rev counter. With a manual gearbox the engine revs (the Trueno's bounce 7,940 to 8,140 on the limiter, where Alexis read 7.7k to 7.9k); with an automatic this value is 0, so it is rpm_auto x 0.885 (the Silvia's counter read 0.879 to 0.889 of it at five readings, 16 November 2026). Your car, whichever slot it is in. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `gear` | `race_loaded ? (valid(my_slot, 0) == 1 ? gear_1 : gear_0) : 0` | Gear, 1 up (at least 1): manual 1 to 5, automatic 1 to 4. Your car, whichever slot it is in. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `ffb_cmd` | `byte(ffb_raw, 0)` | Command: 132 constant force, 134 spring, 133 vibration, 128 (with byte 2 = 1) full spring. |
| `ffb_v1` | `byte(ffb_raw, 1)` | Direction for command 132 (0 or 1), period for 133. |
| `force` | `valid(hold(clamp(ffb_cmd == 132 && ffb_str > 0 ? (ffb_v1 == 0 ? -(32767 - ffb_str) / 32767 : (ffb_v1 == 1 ? ffb_str / 32767 : 0)) : 0, -1, 1), ffb_cmd == 132), 0)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 32767 : 1, (ffb_cmd == 134 && ffb_str > 0) \|\| (ffb_cmd == 128 && byte(ffb_raw, 2) == 1)), 0)` | Centring spring strength, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && ffb_v1 > 0 && ffb_str > 0 ? ffb_str / 32767 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `vibration_period_ms` | `ffb_cmd == 133 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0` | Vibration period, roughly milliseconds. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `replay` (not exported) | `valid(game_mode, 0) >= 7 && valid(game_mode, 0) <= 12` | 1 in the attract demo and replays (game modes 7 to 12, which the game itself treats as not played). From the game's own code (v2.30 exe, 16 November 2026). Not yet checked in a recording. |
| `race_loaded` (not exported) | `valid(race_state, 0) >= 3 && valid(race_state, 0) <= 6 && (valid(game_mode, 0) < 7 \|\| valid(game_mode, 0) > 12)` | 1 from the intro to after the goal in a race you play: the car rows read 0 outside this. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `live` (not exported) | `maxw(delta(race_ms) != 0, 0.2)` | 1 while the race clock moves: 0 while the game is paused (the tutorial's how-to demos stopped it twice in ID0-1, at TT 0:02.05 and 0:52.13). From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `rival_race` (not exported) | `valid(game_mode, 0) != 2 && valid(cars, 1) == 2` | 1 in a race against a rival: not time attack, whose second car is never seen (Alexis, 16 November 2026) and whose gap means nothing. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `state` | `race_loaded ? (valid(my_slot, 0) == 1 ? state_1 : state_0) : 0` | Car state: 4 racing (from GO), 5 over the finish line, 6 race over (the other car finished and the race ended). Your car, whichever slot it is in. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `rpm_auto` (not exported) | `race_loaded ? (valid(my_slot, 0) == 1 ? rpm_auto_1 : rpm_auto_0) : 0` | Engine revs as the game keeps them with an automatic gearbox (about the tacho value: the Silvia's factor 0.99). The rev counter shows 0.885 of it (Alexis's Silvia readings: 5.8k at 6,598, 5.45k at 6,133, 6.2k at 6,993, 6.075k at 6,872, 5.95k at 6,716). Your car, whichever slot it is in. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `rpm_tacho` (not exported) | `race_loaded ? (valid(my_slot, 0) == 1 ? rpm_tacho_1 : rpm_tacho_0) : 0` | Engine revs times a factor for each car (1.21 the Trueno, 1.14 the RX-7): not what the rev counter shows (the Trueno's reads 9,849 on the limiter, its counter under 8k). Your car, whichever slot it is in. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `throttle` | `race_loaded ? (valid(my_slot, 0) == 1 ? throttle_1 : throttle_0) : 0` | Throttle, 0 to 1, as the physics uses it (from the pedal). Your car, whichever slot it is in. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `brake` | `race_loaded ? (valid(my_slot, 0) == 1 ? brake_1 : brake_0) : 0` | Brake, 0 to 1, as the physics uses it (from the pedal). Your car, whichever slot it is in. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `steer` | `race_loaded ? -(valid(my_slot, 0) == 1 ? steer_1 : steer_0) : 0` | Steering as the physics uses it, + right, - left: the game's own value is + left, so this is turned round. It follows the wheel (USB, r -0.95 and -0.97 before turning) at about a quarter to a third of its turn: the game eases the steering the faster the car goes. Your car, whichever slot it is in. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `drift_angle` | `race_loaded && speed * max_speed > 10 ? -(valid(my_slot, 0) == 1 ? drift_angle_1 : drift_angle_0) * 57.29578 : 0` | Drift angle, degrees: between where the car points and where it is going (the physics' own, worked out as in ID6: body heading less the direction of travel, wrapped to +-180). + a right-hand drift, - left (Alexis: right at TT 0:16.10 and 0:28.46, left at 0:11.12 and 0:36.77). About 15 to 30 degrees in the Trueno's quick bends, up to 68 in the RX-7's hairpin drifts. 0 below 10 km/h. Your car, whichever slot it is in. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `events` | `race_loaded ? (valid(my_slot, 0) == 1 ? events_1 : events_0) : 0` | The car's event flags from the last frame: the game plays its collision, gutter, landing and joint sounds from these, with the same bits as ID6. The rows after decode them. Your car, whichever slot it is in. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `area` | `race_loaded ? (valid(my_slot, 0) == 1 ? area_1 : area_0) : 0` | The surface the game plays a looping sound for: 0 road, 1 leaves (surface 0x12 or 0x32), 2 striped surface (0x14 or 0x15: the ripple strips in ID0-1, and Irohazaka's painted strips, which the game doesn't shake for), 3 the sound named "glass area" (0x19 or 0x39: probably grass; not seen yet), 4 the road gutter (0x2X). Your car, whichever slot it is in. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `in_race` | `valid(race_state, 0) == 4 && state == 4 && !replay && live` | 1 while racing: from GO to your finish line, not in the attract demo or a replay, and not while paused (the race clock stands still: the tutorial's how-to demos). From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `race_clock` | `race_loaded && race_ms > -10000 ? race_ms / 1000 : 0` | The race time (TT), seconds from GO; negative in the countdown, 0 outside a race and through the intro. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `checkpoint` | `in_race && maxw(delta(time_extension) > 0, 2) > 0` | 1 for 2 s after a checkpoint that extends the time (Extended Time!): all six in the two recordings, Alexis's marks 0.1 to 0.2 s after. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `leader` | `in_race && rival_race && gap > 0` | 1 while ahead of the rival. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `lampleader` | `race_loaded && (rival_race ? gap > 0 : valid(race_state, 0) >= 4)` | Leader lamp, 0 or 1: lit while you lead the rival (first place), and from GO in time attack, where you run alone. It keeps the last standing past the line until the race is over. Made from the race values, as Alexis asked (OutputBlaster has no v2.30 entry). From the game's own code (v2.30 exe, 16 November 2026). Not yet checked in a recording. |
| `lampcheckpoint` | `maxw(delta(time_extension) > 0, 2) > 0` | Checkpoint lamp, 0 or 1: lit for 2 s as a checkpoint's time extension starts (Extended Time!), as `checkpoint`. Made from the race values, as Alexis asked. From the game's own code (v2.30 exe, 16 November 2026). Not yet checked in a recording. |
| `wall_left` | `in_race && band(events, 36864) != 0` | 1 while touching a wall (0x8000) or guard rail (0x1000) on the left (event bits 0x9000). The same bit as ID6's; seen in Alexis's Initial D Zero recordings of 16 November 2026 where she said it happened. |
| `wall_right` | `in_race && band(events, 147456) != 0` | 1 while touching a wall (0x20000) or guard rail (0x4000) on the right (event bits 0x24000). The same bit as ID6's; seen in Alexis's Initial D Zero recordings of 16 November 2026 where she said it happened. |
| `wall_front` | `in_race && band(events, 73728) != 0` | 1 while touching a wall or guard rail ahead (event bits 0x12000). The same bit as ID6's, whose meaning was checked in Alexis's ID6 recordings; not yet seen in Initial D Zero. |
| `car_contact` | `in_race && band(events, 524288) != 0` | 1 while touching the other car (while the cars grind it drops out for a frame or so every 0.2 s) (event bits 0x80000). The same bit as ID6's; seen in Alexis's Initial D Zero recordings of 16 November 2026 where she said it happened. |
| `gutter` | `in_race && band(events, 3) != 0` | 1 while a wheel is in the roadside gutter (0x1 left, 0x2 right). Wall hits mostly come with it, since the gutter runs along the wall; on its own it is the wheels running in the gutter (event bits 0x3). The same bit as ID6's; seen in Alexis's Initial D Zero recordings of 16 November 2026 where she said it happened. |
| `road_joint` | `in_race && band(events, 2048) != 0` | 1 while crossing a road joint (event bits 0x800). The same bit as ID6's, whose meaning was checked in Alexis's ID6 recordings; not yet seen in Initial D Zero. |
| `gutter_drop` | `in_race && band(events, 192) != 0` | 1 while the gutter technique sound ("mizootoshi"), left or right (event bits 0xc0). The same bit as ID6's, whose meaning was checked in Alexis's ID6 recordings; not yet seen in Initial D Zero. |
| `drain` | `in_race && band(events, 12) != 0` | 1 while running over a drain cover (event bits 0xc). The same bit as ID6's, whose meaning was checked in Alexis's ID6 recordings; not yet seen in Initial D Zero. |
| `oil` | `in_race && band(events, 48) != 0` | 1 while on oil (event bits 0x30). The same bit as ID6's, whose meaning was checked in Alexis's ID6 recordings; not yet seen in Initial D Zero. |
| `leaves` | `in_race && band(events, 1024) != 0` | 1 while a wheel in the leaves at the side of the road (Irohazaka) (event bits 0x400). The same bit as ID6's; seen in Alexis's Initial D Zero recordings of 16 November 2026 where she said it happened. |
| `landing` | `in_race && maxw(band(events, 256) != 0 && prev(band(events, 256)) == 0, 0.25) > 0` | 1 for 0.25 s as the car lands (event bit 0x100 coming on; the game leaves it on until the car next leaves the ground): both jumps in ID0-1 and both kerb drops in ID0-2. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `rumble_strip` | `in_race && (band(events, 512) != 0 \|\| maxw(ffb_cmd == 133 && ffb_v1 > 0 && byte(ffb_raw, 2) == 5, 0.3) > 0)` | On a ripple strip: the game's vibration at level 5 (its period follows the speed), held 0.3 s, as for ID6. All five ripple strips in ID0-1 came through; Irohazaka's painted strips (ID0-2) don't shake, so they don't count. The game's levels: 2 contact with the other car, 4 scraping a wall or guard rail, 5 a ripple strip. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `grass` | `in_race && area == 3` | On the surface whose sound the game calls "glass area" (probably grass; not seen yet). From the game's own code (v2.30 exe, 16 November 2026). Not yet checked in a recording. |
| `hit` | `in_race && maxw(((wall_left \|\| wall_right \|\| wall_front) && prev(maxw(wall_left \|\| wall_right \|\| wall_front, 0.15)) == 0) \|\| (car_contact && prev(maxw(car_contact, 0.15)) == 0), 0.3) > 0` | 1 for 0.3 s from the start of a contact with a wall, guard rail or the other car (where the game plays its collision sound). Touches less than 0.15 s apart count as one, as in ID6. Alexis confirmed the bumps with the other car in ID0-1 and the guard rail and wall touches she checked in ID0-2 (leaves alone never count). From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `hit_side` | `valid(hold(wall_right - wall_left, wall_right != wall_left), 0)` | Side of the last wall contact, +1 right, -1 left. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `wall_contact` | `minw(wall_left \|\| wall_right, 0.3) ? (wall_right - wall_left) : 0` | Scraping along a wall or guard rail for 0.3 s or more: +1 right, -1 left. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `rough_ground` | `gutter \|\| drain \|\| leaves \|\| grass` | 1 with a wheel in the gutter, over a drain cover, on leaves or grass. From the game's own code (v2.30 exe, 16 November 2026). Checked in Alexis's recordings of 16 November 2026 (ID0-1: story intro (tutorial) against the computer, AE86 Trueno, manual; ID0-2: Irohazaka downhill time attack, Savanna RX-7, automatic, USB capture on; claude/ID0V230-capture-20261116.md). |
| `shift` | `in_race && maxw(delta(gear) != 0, 0.2) > 0` | 1 for 0.2 s after a gear change. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed (km/h). + speeding up, - slowing down. |
| `car_in_race` (not exported) | `in_race` | Common value Car_in_race: 1 from GO to your finish line: the race and your car racing (state 4), not in the attract demo or a replay, and not while paused. |
| `car_speed` (not exported) | `in_race ? (speed * max_speed) : 0` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_rpm` (not exported) | `in_race ? (rpm * max_revs) : 0` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_gear` (not exported) | `in_race ? (gear) : 0` | Common value Car_gear: gear. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_accel_g` (not exported) | `in_race ? (accel_g) : 0` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_speed_kmh` (not exported) | `in_race ? (speed * max_speed) : 0` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the speedo). Car_speed_mph is this / 1.609344. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_time_left` (not exported) | `in_race ? (time_left) : 0` | Common value Car_time_left: time left (RT), seconds. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_race_time` (not exported) | `in_race ? (max(race_clock, 0)) : 0` | Common value Car_race_time: the race clock (TT), seconds from GO (0 in the countdown). 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_brake` (not exported) | `in_race ? (brake) : 0` | Common value Car_brake: brake pedal, 0 to 1, as the game uses it. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_steer` (not exported) | `in_race ? (steer) : 0` | Common value Car_steer: steering, -1 full left to 1 full right, as the game uses it. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_gap` (not exported) | `in_race ? (gap) : 0` | Common value Car_gap: distance to the rival, metres: + ahead, - behind (ADVANTAGE on screen); 0 with no rival. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_impact` (not exported) | `in_race ? (hit ? clamp(0.5 + (maxw(speed * max_speed, 0.3) - speed * max_speed) / 60, 0.5, 1) : 0) : 0` | Common value Car_impact: contact with a wall, guard rail or the other car, 0.5 to 1 by the km/h lost in the last 0.3 s (0.5 + loss / 60), as in ID6. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_impact_side` (not exported) | `in_race ? (hit ? sign(maxw(wall_right, 0.3) - maxw(wall_left, 0.3)) : 0) : 0` | Common value Car_impact_side: side of a wall or guard rail hit, -1 left, 1 right (0 for the other car, whose side the game doesn't give). 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_wall_contact` (not exported) | `in_race ? (wall_contact) : 0` | Common value Car_wall_contact: scraping along a wall or guard rail, -1 left, 1 right. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_road_bump` (not exported) | `in_race ? (max(maxw(road_joint, 0.15) * 0.6, landing)) : 0` | Common value Car_road_bump: road joints (0.6, held 0.15 s) and landings (1 for 0.25 s), from the events the game plays their sounds from. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_rumble_strip` (not exported) | `in_race ? (rumble_strip) : 0` | Common value Car_rumble_strip: 1 on a ripple strip. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_off_road` (not exported) | `in_race ? (rough_ground) : 0` | Common value Car_off_road: on rough ground. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_drift` (not exported) | `in_race ? ((1 - pow(1 - clamp((abs(drift_angle) - 5) / 45, 0, 1), 2)) * sqrt(clamp((speed * max_speed - 20) / 80, 0, 1))) : 0` | Common value Car_drift: drifting, 0 to 1: the drift angle with ID6's weighting (nothing under 5 degrees or 20 km/h; full at 50 degrees and 100 km/h). With no slip value of its own, Car_grip_loss follows it. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_drift_angle` (not exported) | `in_race ? (drift_angle) : 0` | Common value Car_drift_angle: the drift angle in degrees, + pointing right of the car's path (a right-hand drift), - left. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_cornering` (not exported) | `in_race ? (clamp(ema(steer, 0.1) / 0.3 * sqrt(clamp(speed * max_speed / 120, 0, 1)), -1, 1)) : 0` | Common value Car_cornering: cornering from the steering and speed, + turning right: the physics' steering (which the game already eases with speed; 0.3 reads full) times the square root of the speed (full from 120 km/h). Hard bends read 0.6 to 0.9 in Alexis's recordings of 16 November 2026, the game's own wheel force only about 0.3. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_vibration` (not exported) | `in_race ? (vibration) : 0` | Common value Car_vibration: the game's own vibration command, 0 to 1. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_throttle` (not exported) | `in_race ? (throttle) : 0` | Common value Car_throttle: throttle, 0 to 1: the engine effects run at 60% off the throttle, full at full throttle. 0 outside a race (attract demo, menus, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |
| `lamp_checkpoint` (not exported) | `lampcheckpoint` | Common lamp Lamp_checkpoint: a checkpoint passed or time extended (`lampcheckpoint`). |

<a id="idtas4"></a>
## Initial D The Arcade Season 4 v2.5

Prefix `IDTAS4` (properties `TPTelemetry.IDTAS4_<row>`), process `GameProject-Win64-Shipping.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `car_time_left` (not exported) | `timer` | Common value Car_time_left: time left, seconds, from the cheat table's timer (not yet checked in a recording). |

<a id="idtas5"></a>
## Initial D The Arcade Season 5 v3.10

Prefix `IDTAS5` (properties `TPTelemetry.IDTAS5_<row>`), process `GameProject-Win64-Shipping.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speed, from the table's "output pointers" (probably km/h, whole numbers). From MasterRaver's TeknoParrot cheat table (04.10.26 pack). Not yet checked in a recording. Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `rpm` | memory read, then `value / max_revs` | Engine RPM, from the table's "output pointers". From MasterRaver's TeknoParrot cheat table (04.10.26 pack). Not yet checked in a recording. Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed, assuming km/h (speed x Max speed undoes the division, so this stays in G). + speeding up, - slowing down. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: probably km/h (not yet checked). Car_speed_mph is this / 1.609344. |
| `car_time_left` (not exported) | `timer` | Common value Car_time_left: time left, seconds, from the cheat table's timer (not yet checked in a recording). |

<a id="idtas5v321"></a>
## Initial D The Arcade Season 5 v3.21 (ARCADEZONE.CN)

Prefix `IDTAS5V321` (properties `TPTelemetry.IDTAS5V321_<row>`), process `GameProject-Win64-Shipping.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `car_time_left` (not exported) | `timer` | Common value Car_time_left: time left, seconds, from the cheat table's timer (not yet checked in a recording). |

<a id="idta21"></a>
## Initial D The Arcade v2.1 (Season 3)

Prefix `IDTA21` (properties `TPTelemetry.IDTA21_<row>`), process `GameProject-Win64-Shipping.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `car_time_left` (not exported) | `timer` | Common value Car_time_left: time left, seconds, from the cheat table's timer (not yet checked in a recording). |

<a id="idta"></a>
## Initial D The Arcade v2.31

Prefix `IDTA` (properties `TPTelemetry.IDTA_<row>`), process `GameProject-Win64-Shipping.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speed, from the table's "output pointers" (probably km/h, whole numbers). From MasterRaver's TeknoParrot cheat table (04.10.26 pack). Not yet checked in a recording. Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `rpm` | memory read, then `value / max_revs` | Engine RPM, from the table's "output pointers". From MasterRaver's TeknoParrot cheat table (04.10.26 pack). Not yet checked in a recording. Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `ffb_cmd` | `byte(ffb_raw, 0)` | Command: 132 constant force, 134 spring, 133 vibration, 128 (with byte 2 = 1) full spring. |
| `ffb_v1` | `byte(ffb_raw, 1)` | Direction for command 132 (0 or 1), period for 133. |
| `force` | `valid(hold(clamp(ffb_cmd == 132 && ffb_str > 0 ? (ffb_v1 == 0 ? -(32767 - ffb_str) / 32767 : (ffb_v1 == 1 ? ffb_str / 32767 : 0)) : 0, -1, 1), ffb_cmd == 132), 0)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 32767 : 1, (ffb_cmd == 134 && ffb_str > 0) \|\| (ffb_cmd == 128 && byte(ffb_raw, 2) == 1)), 0)` | Centring spring strength, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && ffb_v1 > 0 && ffb_str > 0 ? ffb_str / 32767 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `vibration_period_ms` | `ffb_cmd == 133 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0` | Vibration period, roughly milliseconds. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed, assuming km/h (speed x Max speed undoes the division, so this stays in G). + speeding up, - slowing down. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: probably km/h (not yet checked). Car_speed_mph is this / 1.609344. |
| `car_time_left` (not exported) | `timer` | Common value Car_time_left: time left, seconds, from the cheat table's timer (not yet checked in a recording). |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="kodrive"></a>
## KO Drive

Prefix `KODRIVE` (properties `TPTelemetry.KODRIVE_<row>`), process `M-DriveR_RingWide.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `byte(ffb_raw, 0)` | Command: 132 constant force, 134 spring, 133 vibration, 128 (with byte 2 = 1) full spring. |
| `ffb_v1` | `byte(ffb_raw, 1)` | Direction for command 132 (0 or 1), period for 133. |
| `force` | `valid(hold(clamp(ffb_cmd == 132 && ffb_str > 0 ? (ffb_v1 == 0 ? -(32767 - ffb_str) / 32767 : (ffb_v1 == 1 ? ffb_str / 32767 : 0)) : 0, -1, 1), ffb_cmd == 132), 0)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 32767 : 1, (ffb_cmd == 134 && ffb_str > 0) \|\| (ffb_cmd == 128 && byte(ffb_raw, 2) == 1)), 0)` | Centring spring strength, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && ffb_v1 > 0 && ffb_str > 0 ? ffb_str / 32767 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `vibration_period_ms` | `ffb_cmd == 133 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0` | Vibration period, roughly milliseconds. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="mkgpdxusa"></a>
## Mario Kart Arcade GP DX (USA)

Prefix `MKGPDXUSA` (properties `TPTelemetry.MKGPDXUSA_<row>`), process `MK_AGP3_FINAL.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Kart speed in the game's own units (the value its engine sound follows; the sound caps it at 400). From the game's code (MK_AGP3_FINAL.exe, USA, read 11 November 2026); not yet checked in a recording. Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `rpm` | memory read, then `value / max_revs` | Engine revs the kart's engine sound plays (the sound caps them at 11000). From the game's code (MK_AGP3_FINAL.exe, USA, read 11 November 2026); not yet checked in a recording. Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). |
| `force` | memory read, then `clamp(-value, -1, 1)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). Raw: Force the game asks for: in this version the kart's sideways slide (the sine of drift_angle), which the FFB Arcade Plugin's Real mode sends to the wheel, so near 0 driving straight. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `drift_angle` | memory read, then `atan2(clamp(-value, -1, 1), sqrt(1 - pow(clamp(value, -1, 1), 2))) * 180 / pi` | Drift angle, degrees: between where the kart points and where it is going, from the sine the game works out (kart +2FC, the value the FFB Arcade Plugin sends as the force): about 0 driving straight, growing in a slide; + pointing right of its path (a right-hand drift), - left, as v1.18's same value read in Alexis's recording (11 November 2026). Past 90 degrees (a spin) it folds back. From the game's code (MK_AGP3_FINAL.exe, USA, read 11 November 2026); not yet checked in a recording. |
| `race_time` | memory read, then `value / 1000` | Race time, seconds: the race's clock, 16 ms a frame (about 4% slower than real time). From the game's code (MK_AGP3_FINAL.exe, USA, read 11 November 2026); not yet checked in a recording. |
| `speed_snd` (not exported) | memory read, then `value / max_speed` | The FFB Arcade Plugin's speed read (sound manager +558). Not a field the game's sound code fills (as +580 in v1.18), so probably not the speed; kept to compare with speed in a recording. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `steer` | memory read, then `(value - 127.5) / 127.5` | Steering, -1 to 1 (which side is + still to be confirmed). Raw: Steering, 0 to 255. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `hit` | memory read, then `value == 4194308` | 1 while the big shake plays (walls, karts, items). Raw: 4194308 while the game shakes the cabinet: hitting walls or karts, or hit by an item. Unverified: from the FFB Arcade Plugin's reading of this game. The same place in the I/O block as v1.18's shake word. Alexis's v1.18 recording: walls, karts and items, the kite launch and landing, and twice in the countdown (hit_race leaves those out). |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `racing` | `valid(race_state, 0) == 6 && maxw(in_race, 0.1) > 0` | 1 from GO to the finish line: race state 6 (race), with the FFB plugin's race flag (it drops for one sample at the lap line, so it is held 0.1 s). Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `hop` | `racing && kart_state == 1` | 1 for the hop into a drift (0.27 s). Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `gliding` | `racing && (kart_state == 18 \|\| band(kart_flags, 4) > 0)` | 1 while gliding on the kite (4.4 s at each kite ramp in Alexis's race). Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `spin` | `racing && (kart_state == 6 \|\| kart_state == 7 \|\| kart_state == 10 \|\| kart_state == 11)` | 1 while spun out by an item: about 1.5 s on the ground (state 10, a banana peel among them), 2.5 to 3 s thrown into the air spinning over and over (6 and 11 items, 7 a bomb blast). Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `knocked` | `racing && (kart_state == 3 \|\| kart_state == 5 \|\| kart_state == 6 \|\| kart_state == 7 \|\| kart_state == 10 \|\| kart_state == 11)` | 1 while knocked about by an item: bumped (state 3, about 0.5 s: an item from behind kicks the rear wheels up), flipped (5) or spun out (6, 7, 10, 11). Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `recovering` | `racing && band(kart_flags, 8388608) > 0` | 1 for about 3 s after being hit by an item. Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `airborne` | `racing && on_ground == 0 && kart_state != 1 && minw(on_ground == 0, 0.1) > 0` | 1 in the air for more than 0.1 s: the kite glides and jumps, not the drift hops or the logs of a ripple strip (where on_ground drops for a frame). Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `landed` | `maxw(prev(airborne) > 0 && airborne == 0, 0.25) > 0` | 1 for 0.25 s after landing from the air. Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `hop_landed` | `maxw(prev(hop) > 0 && hop == 0, 0.15) > 0` | 1 for 0.15 s as the kart lands from a drift hop. Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `rumble_strip` | `racing && (terrain == 2 \|\| avg(delta(terrain) != 0, 0.3) > 0.07)` | 1 on a ripple strip or metal grille: the logs of the Donkey Kong cup's ripple strips flick the ground type between two codes at every log (on 0.2 s into the strip; both strips in Alexis's race, nothing else), and the grille sections of the Bowser Jr cup read code 2. Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `off_road` | `racing && on_ground == 1 && !rumble_strip ? (terrain == 4 \|\| terrain == 11 \|\| terrain == 14 ? 1 : (terrain == 10 ? 0.5 : (terrain == 8 ? 0.3 : 0))) : 0` | Rough ground, 0 to 1: a verge (4 grass, 11 rebound-ace) or sand (14) 1, the planked bridge (10) 0.5, wood (8: floorboards, platforms) 0.3 (Alexis); roads, pavement, glass, jungle floor (13, which the glass on Mario Cup course 1 shares), checkerplate (5), carpet (9), cloud (15) and water 0, and not on a ripple strip or grille (the rumble strip has those). The game sends the wheel no texture of its own. Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `drift_strength` | `drift ? (1 - pow(1 - clamp((abs(drift_angle) - 5) / 45, 0, 1), 2)) : 0` | Drifting, 0 to 1, from the drift angle with ID6's weighting (nothing under 5 degrees, full at 50, eased), while the game's drift flag is on. Alexis's right-hand drifts read 0.8 to 0.95, left-hand 0.4 to 0.9, her "very slight" one 0.5. Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `item_held` | `racing && maxw(lampstart, 0.25) > 0` | 1 from an item box until the item is used or lost: the item button's lamp, held over its flashes (USA, 11 November). Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `item_got` | `maxw(item_held && !prev(item_held), 0.3) > 0` | 1 for 0.3 s after an item box. Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `item_gone` | `maxw(!item_held && prev(item_held) && racing, 0.3) > 0` | 1 for 0.3 s after an item is used (or knocked away). Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `hit_race` | `racing && hit` | The big shake while racing (walls, karts, items). |
| `slide_at_hit` | `valid(hold(avg(force, 0.3), hit_race && !prev(hit_race)), 0)` | The slide (force) over the 0.3 s before a hit (the game's shake comes a few hundredths after the knock). |
| `drift_at_hit` | `valid(hold(maxw(drift, 0.3), hit_race && !prev(hit_race)), 0)` | 1 if the kart was drifting in the 0.3 s before a hit (the slide is unwinding then, so the knock can't be read). |
| `slide_kick` | `hit_race && drift_at_hit == 0 ? force - slide_at_hit : 0` | How far a hit knocks the kart's slide while the hit lasts (0 for hits in or just after a drift): a hit on the left knocks it negative, on the right positive. |
| `hit_side` | `maxw(hit_race, 0.3) > 0 && drift_at_hit == 0 && drift == 0 && (kart_state == 0 \|\| kart_state == 3) && maxw(spin, 0.5) == 0 ? (maxw(slide_kick, 0.3) > 0.06 && maxw(slide_kick, 0.3) >= -minw(slide_kick, 0.3) ? 1 : (minw(slide_kick, 0.3) < -0.06 ? -1 : 0)) : 0` | Side of a hit, +1 right, -1 left, 0 not known: the way it knocks the kart sideways, about 0.1 s after the hit, outside drifts. Alexis's sides (11 November 2026): right for all five hits she named (96.05 and 248.64 s left, 120.2 and 134.77 s right, 231.75 s left), never the wrong way at her ten other marked hits, and 0 for gentle bumps and hits in or just after a drift. Worked out from Alexis's v1.18 recording (11 November 2026); the USA code matches, not yet recorded. |
| `lap` | `racing ? min(laps_done + 1, max(laps_total, 1)) : 0` | The lap the HUD shows (1 on the first lap). |
| `final_lap` | `racing && laps_total > 0 && laps_done == laps_total - 1` | 1 on the last lap. |
| `leader` | `racing && position == 1` | 1 while you lead, for a lamp. |
| `place_gained` | `racing && maxw(delta(position) < 0, 0.5) > 0` | 1 for 0.5 s after the HUD position goes up (you pass someone). |
| `place_lost` | `racing && maxw(delta(position) > 0, 0.5) > 0` | 1 for 0.5 s after the HUD position goes down (you are passed). |
| `coin_pickup` | `maxw(delta(coins) > 0, 0.2)` | 1 for 0.2 s after picking up a coin. |
| `rough_ground` | `on_ground == 1 && (terrain == 3 \|\| terrain == 4 \|\| terrain == 10 \|\| terrain == 11 \|\| terrain == 12 \|\| terrain == 14)` | 1 on dirt, grass, bumps, rough track, tiles or sand. |
| `in_water` | `on_ground == 1 && terrain == 7` | 1 driving through water. |
| `lampstart` | `band(ob_buttondata, 4) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_buttondata, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `billboard_red` | `band(ob_kanbansidelampdata, 240) != 0` | Billboard Red output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `billboard_green` | `band(ob_kanbansidelampdata, 15) != 0` | Billboard Green output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `billboard_blue` | `band(ob_kanbansidelampdata, 15728640) != 0` | Billboard Blue output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `billboard_white` | `band(ob_kanbansidelampdata, 15793920) != 0` | Billboard White output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `sideledred` | `band(ob_kanbansidelampdata, 4026531840) != 0` | SideLEDRed output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `sideledgreen` | `band(ob_kanbansidelampdata, 251658240) != 0` | SideLEDGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `sideledblue` | `band(ob_kanbansidelampdata, 251658240) != 0` | SideLEDBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `sideledwhite` | `band(ob_kanbansidelampdata, 68718428160) != 0` | SideLEDWhite output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `lampred` | `band(ob_underlampdata, 16711680) != 0` | LampRed output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `lampgreen` | `band(ob_underlampdata, 983040) != 0` | LampGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `lampblue` | `band(ob_underlampdata, 4026531840) != 0` | LampBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `lampwhite` | `band(ob_underlampdata, 4294901760) != 0` | LampWhite output, 0 or 1. From game memory, the same reads OutputBlaster makes for v1.18, moved to this version's I/O block (no OutputBlaster needed). Unverified. |
| `car_in_race` (not exported) | `racing` | Common value Car_in_race: 1 from GO to the finish line (race state 6, with the FFB plugin's race flag). |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: the game's own units, taken as km/h (a kart has no speedo). Car_speed_mph is this / 1.609344. |
| `car_position` (not exported) | `position` | Common value Car_position: race position, 1 = first. |
| `car_lap` (not exported) | `lap` | Common value Car_lap: the lap you are on, 1 = first. |
| `car_laps_total` (not exported) | `laps_total` | Common value Car_laps_total: laps in the race. |
| `car_race_time` (not exported) | `race_time` | Common value Car_race_time: the race clock (TT), seconds. |
| `car_impact` (not exported) | `max(hit_race, knocked)` | Common value Car_impact: walls, karts and items hitting you (the game's big shake), and being knocked about by an item (spun out, flipped or bumped up), 0 or 1. |
| `car_impact_side` (not exported) | `hit_side` | Common value Car_impact_side: side of a hit, -1 left, 1 right, 0 not known: the way it knocks the kart sideways (Alexis's v1.18 recording, 11 November 2026). |
| `car_road_bump` (not exported) | `max(landed, hop_landed * 0.5)` | Common value Car_road_bump: landing from the air (1) or from a drift hop (0.5). The wheel force is the kart's slide, so force kicks are no road bumps. |
| `car_rumble_strip` (not exported) | `rumble_strip` | Common value Car_rumble_strip: 1 on a ripple strip. |
| `car_off_road` (not exported) | `off_road` | Common value Car_off_road: off the road. |
| `car_grip_loss` (not exported) | `max(drift_strength, spin)` | Common value Car_grip_loss: sliding: the drift (0 to 1), or 1 in a spin-out. |
| `car_drift` (not exported) | `drift_strength` | Common value Car_drift: drifting, 0 to 1: the drift angle with ID6's weighting while the game's drift flag is on. |
| `car_drift_angle` (not exported) | `drift_angle` | Common value Car_drift_angle: the drift angle in degrees, + pointing right of the kart's path (a right-hand drift), - left. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_airborne` (not exported) | `airborne` | Common value Car_airborne: 1 in the air for more than 0.1 s (kite glides and jumps; not drift hops or ripple-strip logs). |
| `car_boost` (not exported) | `boost` | Common value Car_boost: boost, 0 or 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_leader` (not exported) | `leader` | Common lamp Lamp_leader: in the lead, made from the race values (`leader`). |
| `lamp_final_lap` (not exported) | `final_lap` | Common lamp Lamp_final_lap: on the final lap. |
| `lamp_red` (not exported) | `lampred` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_green` (not exported) | `lampgreen` | Common lamp Lamp_green: the cabinet's green lamp (`lampgreen`). |
| `lamp_blue` (not exported) | `lampblue` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |
| `lamp_white` (not exported) | `lampwhite` | Common lamp Lamp_white: the cabinet's white lamp (`lampwhite`). |
| `lamp_marquee` (not exported) | `max(billboard_red, billboard_green, billboard_blue, billboard_white)` | Common lamp Lamp_marquee: the billboard, any colour. |

<a id="mkgpdx110"></a>
## Mario Kart Arcade GP DX v1.10

Prefix `MKGPDX110` (properties `TPTelemetry.MKGPDX110_<row>`), process `MK_AGP3_FINAL.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Kart speed (units unknown). Unverified: from the FFB Arcade Plugin's reading of this game. Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `force` | memory read, then `clamp(-value, -1, 1)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). Raw: Force the game asks for. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `steer` | memory read, then `(value - 127.5) / 127.5` | Steering, -1 to 1 (which side is + still to be confirmed). Raw: Steering, 0 to 255. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `hit` | memory read, then `value == 4194308` | 1 while the big shake plays (walls, karts, items). Raw: 4194308 while the game shakes the cabinet: hitting walls or karts, or hit by an item. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `landed` | `maxw(delta(on_ground) > 0 && on_ground == 1, 0.2)` | 1 for 0.2 s after landing a jump. |
| `coin_pickup` | `maxw(delta(coins) != 0, 0.2)` | 1 for 0.2 s after picking up a coin. |
| `item_change` | `maxw(delta(item) != 0, 0.3)` | 1 for 0.3 s after an item box or item use. |
| `rough_ground` | `on_ground == 1 && (terrain == 3 \|\| terrain == 4 \|\| terrain == 10 \|\| terrain == 11 \|\| terrain == 12 \|\| terrain == 14)` | 1 on dirt, grass, bumps, rough track, tiles or sand. |
| `in_water` | `on_ground == 1 && terrain == 7` | 1 driving through water. |
| `item_button` | `band(item, 4) != 0` | Item Button output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `mario_button` | `band(item, 8) != 0` | Mario Button output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `billboard_red` | `band(ob_billboarddata, 240) != 0` | Billboard Red output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `billboard_green` | `band(ob_billboarddata, 15) != 0` | Billboard Green output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `billboard_blue` | `band(ob_billboarddata2, 240) != 0` | Billboard Blue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `billboard_white` | `band(ob_billboarddata2, 255) != 0` | Billboard White output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `sideledred` | `band(ob_monitorsidedata, 240) != 0` | SideLEDRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `sideledgreen` | `band(ob_monitorsidedata, 15) != 0` | SideLEDGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `sideledblue` | `band(ob_monitorsidedata2, 240) != 0` | SideLEDBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `sideledwhite` | `band(ob_monitorsidedata2, 255) != 0` | SideLEDWhite output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampred` | `band(ob_underlampdata, 240) != 0` | LampRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampgreen` | `band(ob_underlampdata, 15) != 0` | LampGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampblue` | `band(ob_underlampdata2, 240) != 0` | LampBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampwhite` | `band(ob_underlampdata2, 255) != 0` | LampWhite output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_in_race` (not exported) | `in_race != 0` | Common value Car_in_race: 1 while racing. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: the game's own units, taken as km/h (a kart has no speedo). Car_speed_mph is this / 1.609344. |
| `car_impact` (not exported) | `hit` | Common value Car_impact: walls, karts and items hitting you, 0 or 1. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_off_road` (not exported) | `rough_ground` | Common value Car_off_road: on rough ground. |
| `car_grip_loss` (not exported) | `drift` | Common value Car_grip_loss: drifting, 0 or 1. |
| `car_drift` (not exported) | `drift` | Common value Car_drift: drifting, 0 or 1 (the game's drift flag). |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_airborne` (not exported) | `on_ground == 0` | Common value Car_airborne: 1 with the kart off the ground. |
| `car_boost` (not exported) | `boost` | Common value Car_boost: boost, 0 or 1. |
| `lamp_red` (not exported) | `lampred` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_green` (not exported) | `lampgreen` | Common lamp Lamp_green: the cabinet's green lamp (`lampgreen`). |
| `lamp_blue` (not exported) | `lampblue` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |
| `lamp_white` (not exported) | `lampwhite` | Common lamp Lamp_white: the cabinet's white lamp (`lampwhite`). |
| `lamp_marquee` (not exported) | `max(billboard_red, billboard_green, billboard_blue, billboard_white)` | Common lamp Lamp_marquee: the billboard, any colour. |

<a id="mkgpdx118"></a>
## Mario Kart Arcade GP DX v1.18

Prefix `MKGPDX118` (properties `TPTelemetry.MKGPDX118_<row>`), process `MK_AGP3_FINAL.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Kart speed in the game's own units (the value its engine sound follows): about 140 to 150 racing at 100cc, up to 195 without a boost and 217 with one. From the game's code (v1.18), checked in Alexis's recording of 11 November 2026. Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `rpm` | memory read, then `value / max_revs` | Engine revs the kart's engine sound plays: 8000 to 9300 racing, 12360 at the most. From the game's code (v1.18), checked in Alexis's recording of 11 November 2026. Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). |
| `force` | memory read, then `clamp(-value, -1, 1)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). Raw: Force the game asks for. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `drift_angle` | memory read, then `atan2(clamp(-value, -1, 1), sqrt(1 - pow(clamp(value, -1, 1), 2))) * 180 / pi` | Drift angle, degrees: between where the kart points and where it is going, + pointing right of its path (a right-hand drift), - left. The game keeps the sine of it (kart +BC8, the value the FFB Arcade Plugin sends the wheel as force; the USA version's code works it out from the kart's sideways axis and its direction of travel). Alexis's drifts read 30 to 45 degrees right, 15 to 35 left; under 2 driving straight; a spin-out swings it round and round. Past 90 degrees it folds back. From the game's code (v1.18), checked in Alexis's recording of 11 November 2026. |
| `race_time` | memory read, then `value / 1000` | Race time, seconds: the race's clock, 16 ms a frame (so about 4% slower than real time), which the results show as minutes, seconds and milliseconds. Checked in two v1.18 and two USA races. From the game's code (MK_AGP3_FINAL.exe v1.18, read 9 November 2026); not yet checked in a recording. |
| `speed_snd` (not exported) | memory read, then `value / max_speed` | The FFB Arcade Plugin's speed read (sound manager +580): the sound's own copy of the speed, which follows speed a little behind (within 5 in Alexis's recording of 11 November 2026). speed is the kart's own. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `steer` | memory read, then `(value - 127.5) / 127.5` | Steering, -1 to 1, + right (right-hand drifts read about +0.8 in Alexis's recording, 11 November 2026). Raw: Steering, 0 to 255. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `hit` | memory read, then `value == 4194308` | 1 while the big shake plays (walls, karts, items). Raw: 4194308 while the game shakes the cabinet: hitting walls or karts, or hit by an item. Unverified: from the FFB Arcade Plugin's reading of this game. Alexis's v1.18 recording: walls, karts and items, the kite launch and landing, and twice in the countdown (hit_race leaves those out). |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `racing` | `valid(race_state, 0) == 6 && maxw(in_race, 0.1) > 0` | 1 from GO to the finish line: race state 6 (race), with the FFB plugin's race flag (it drops for one sample at the lap line, so it is held 0.1 s). Checked in Alexis's recording of 11 November 2026. |
| `hop` | `racing && kart_state == 1` | 1 for the hop into a drift (0.27 s). Checked in Alexis's recording of 11 November 2026. |
| `gliding` | `racing && (kart_state == 18 \|\| band(kart_flags, 4) > 0)` | 1 while gliding on the kite (4.4 s at each kite ramp in Alexis's race). Checked in Alexis's recording of 11 November 2026. |
| `spin` | `racing && (kart_state == 6 \|\| kart_state == 7 \|\| kart_state == 10 \|\| kart_state == 11)` | 1 while spun out by an item: about 1.5 s on the ground (state 10, a banana peel among them), 2.5 to 3 s thrown into the air spinning over and over (6 and 11 items, 7 a bomb blast). Checked in Alexis's recording of 11 November 2026. |
| `knocked` | `racing && (kart_state == 3 \|\| kart_state == 5 \|\| kart_state == 6 \|\| kart_state == 7 \|\| kart_state == 10 \|\| kart_state == 11)` | 1 while knocked about by an item: bumped (state 3, about 0.5 s: an item from behind kicks the rear wheels up), flipped (5) or spun out (6, 7, 10, 11). Checked in Alexis's recording of 11 November 2026. |
| `recovering` | `racing && band(kart_flags, 8388608) > 0` | 1 for about 3 s after being hit by an item. Checked in Alexis's recording of 11 November 2026. |
| `airborne` | `racing && on_ground == 0 && kart_state != 1 && minw(on_ground == 0, 0.1) > 0` | 1 in the air for more than 0.1 s: the kite glides and jumps, not the drift hops or the logs of a ripple strip (where on_ground drops for a frame). Checked in Alexis's recording of 11 November 2026. |
| `landed` | `maxw(prev(airborne) > 0 && airborne == 0, 0.25) > 0` | 1 for 0.25 s after landing from the air. Checked in Alexis's recording of 11 November 2026. |
| `hop_landed` | `maxw(prev(hop) > 0 && hop == 0, 0.15) > 0` | 1 for 0.15 s as the kart lands from a drift hop. Checked in Alexis's recording of 11 November 2026. |
| `rumble_strip` | `racing && (terrain == 2 \|\| avg(delta(terrain) != 0, 0.3) > 0.07)` | 1 on a ripple strip or metal grille: the logs of the Donkey Kong cup's ripple strips flick the ground type between two codes at every log (on 0.2 s into the strip; both strips in Alexis's race, nothing else), and the grille sections of the Bowser Jr cup read code 2. Checked in Alexis's recording of 11 November 2026. |
| `off_road` | `racing && on_ground == 1 && !rumble_strip ? (terrain == 4 \|\| terrain == 11 \|\| terrain == 14 ? 1 : (terrain == 10 ? 0.5 : (terrain == 8 ? 0.3 : 0))) : 0` | Rough ground, 0 to 1: a verge (4 grass, 11 rebound-ace) or sand (14) 1, the planked bridge (10) 0.5, wood (8: floorboards, platforms) 0.3 (Alexis); roads, pavement, glass, jungle floor (13, which the glass on Mario Cup course 1 shares), checkerplate (5), carpet (9), cloud (15) and water 0, and not on a ripple strip or grille (the rumble strip has those). The game sends the wheel no texture of its own. Checked in Alexis's recording of 11 November 2026. |
| `drift_strength` | `drift ? (1 - pow(1 - clamp((abs(drift_angle) - 5) / 45, 0, 1), 2)) : 0` | Drifting, 0 to 1, from the drift angle with ID6's weighting (nothing under 5 degrees, full at 50, eased), while the game's drift flag is on. Alexis's right-hand drifts read 0.8 to 0.95, left-hand 0.4 to 0.9, her "very slight" one 0.5. Checked in Alexis's recording of 11 November 2026. |
| `item_held` | `racing && maxw(lampstart, 0.25) > 0` | 1 from an item box until the item is used or lost: the item button's lamp, held over its flashes (USA, 11 November). Checked in Alexis's recording of 11 November 2026. |
| `item_got` | `maxw(item_held && !prev(item_held), 0.3) > 0` | 1 for 0.3 s after an item box. Checked in Alexis's recording of 11 November 2026. |
| `item_gone` | `maxw(!item_held && prev(item_held) && racing, 0.3) > 0` | 1 for 0.3 s after an item is used (or knocked away). Checked in Alexis's recording of 11 November 2026. |
| `hit_race` | `racing && hit` | The big shake while racing (walls, karts, items). |
| `slide_at_hit` | `valid(hold(avg(force, 0.3), hit_race && !prev(hit_race)), 0)` | The slide (force) over the 0.3 s before a hit (the game's shake comes a few hundredths after the knock). |
| `drift_at_hit` | `valid(hold(maxw(drift, 0.3), hit_race && !prev(hit_race)), 0)` | 1 if the kart was drifting in the 0.3 s before a hit (the slide is unwinding then, so the knock can't be read). |
| `slide_kick` | `hit_race && drift_at_hit == 0 ? force - slide_at_hit : 0` | How far a hit knocks the kart's slide while the hit lasts (0 for hits in or just after a drift): a hit on the left knocks it negative, on the right positive. |
| `hit_side` | `maxw(hit_race, 0.3) > 0 && drift_at_hit == 0 && drift == 0 && (kart_state == 0 \|\| kart_state == 3) && maxw(spin, 0.5) == 0 ? (maxw(slide_kick, 0.3) > 0.06 && maxw(slide_kick, 0.3) >= -minw(slide_kick, 0.3) ? 1 : (minw(slide_kick, 0.3) < -0.06 ? -1 : 0)) : 0` | Side of a hit, +1 right, -1 left, 0 not known: the way it knocks the kart sideways, about 0.1 s after the hit, outside drifts. Alexis's sides (11 November 2026): right for all five hits she named (96.05 and 248.64 s left, 120.2 and 134.77 s right, 231.75 s left), never the wrong way at her ten other marked hits, and 0 for gentle bumps and hits in or just after a drift. Checked in Alexis's recording of 11 November 2026. |
| `lap` | `racing ? min(laps_done + 1, max(laps_total, 1)) : 0` | The lap the HUD shows (1 on the first lap). |
| `final_lap` | `racing && laps_total > 0 && laps_done == laps_total - 1` | 1 on the last lap. |
| `leader` | `racing && position == 1` | 1 while you lead, for a lamp. |
| `place_gained` | `racing && maxw(delta(position) < 0, 0.5) > 0` | 1 for 0.5 s after the HUD position goes up (you pass someone). |
| `place_lost` | `racing && maxw(delta(position) > 0, 0.5) > 0` | 1 for 0.5 s after the HUD position goes down (you are passed). |
| `coin_pickup` | `maxw(delta(coins) > 0, 0.2)` | 1 for 0.2 s after picking up a coin. |
| `rough_ground` | `on_ground == 1 && (terrain == 3 \|\| terrain == 4 \|\| terrain == 10 \|\| terrain == 11 \|\| terrain == 12 \|\| terrain == 14)` | 1 on dirt, grass, bumps, rough track, tiles or sand. |
| `in_water` | `on_ground == 1 && terrain == 7` | 1 driving through water. |
| `lampstart` | `band(ob_buttondata, 4) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_buttondata, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `billboard_red` | `band(ob_kanbansidelampdata, 240) != 0` | Billboard Red output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `billboard_green` | `band(ob_kanbansidelampdata, 15) != 0` | Billboard Green output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `billboard_blue` | `band(ob_kanbansidelampdata, 15728640) != 0` | Billboard Blue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `billboard_white` | `band(ob_kanbansidelampdata, 15793920) != 0` | Billboard White output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `sideledred` | `band(ob_kanbansidelampdata, 4026531840) != 0` | SideLEDRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `sideledgreen` | `band(ob_kanbansidelampdata, 251658240) != 0` | SideLEDGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `sideledblue` | `band(ob_kanbansidelampdata, 251658240) != 0` | SideLEDBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `sideledwhite` | `band(ob_kanbansidelampdata, 68718428160) != 0` | SideLEDWhite output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampred` | `band(ob_underlampdata, 16711680) != 0` | LampRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampgreen` | `band(ob_underlampdata, 983040) != 0` | LampGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampblue` | `band(ob_underlampdata, 4026531840) != 0` | LampBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampwhite` | `band(ob_underlampdata, 4294901760) != 0` | LampWhite output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_in_race` (not exported) | `racing` | Common value Car_in_race: 1 from GO to the finish line (race state 6, with the FFB plugin's race flag). |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: the game's own units, taken as km/h (a kart has no speedo). Car_speed_mph is this / 1.609344. |
| `car_position` (not exported) | `position` | Common value Car_position: race position, 1 = first. |
| `car_lap` (not exported) | `lap` | Common value Car_lap: the lap you are on, 1 = first. |
| `car_laps_total` (not exported) | `laps_total` | Common value Car_laps_total: laps in the race. |
| `car_race_time` (not exported) | `race_time` | Common value Car_race_time: the race clock (TT), seconds. |
| `car_steer` (not exported) | `steer` | Common value Car_steer: steering, -1 full left to 1 full right, as the game uses it. |
| `car_impact` (not exported) | `max(hit_race, knocked)` | Common value Car_impact: walls, karts and items hitting you (the game's big shake), and being knocked about by an item (spun out, flipped or bumped up), 0 or 1. |
| `car_impact_side` (not exported) | `hit_side` | Common value Car_impact_side: side of a hit, -1 left, 1 right, 0 not known: the way it knocks the kart sideways (Alexis's v1.18 recording, 11 November 2026). |
| `car_road_bump` (not exported) | `max(landed, hop_landed * 0.5)` | Common value Car_road_bump: landing from the air (1) or from a drift hop (0.5). The wheel force is the kart's slide, so force kicks are no road bumps. |
| `car_rumble_strip` (not exported) | `rumble_strip` | Common value Car_rumble_strip: 1 on a ripple strip. |
| `car_off_road` (not exported) | `off_road` | Common value Car_off_road: off the road. |
| `car_grip_loss` (not exported) | `max(drift_strength, spin)` | Common value Car_grip_loss: sliding: the drift (0 to 1), or 1 in a spin-out. |
| `car_drift` (not exported) | `drift_strength` | Common value Car_drift: drifting, 0 to 1: the drift angle with ID6's weighting while the game's drift flag is on. |
| `car_drift_angle` (not exported) | `drift_angle` | Common value Car_drift_angle: the drift angle in degrees, + pointing right of the kart's path (a right-hand drift), - left. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_airborne` (not exported) | `airborne` | Common value Car_airborne: 1 in the air for more than 0.1 s (kite glides and jumps; not drift hops or ripple-strip logs). |
| `car_boost` (not exported) | `boost` | Common value Car_boost: boost, 0 or 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_leader` (not exported) | `leader` | Common lamp Lamp_leader: in the lead, made from the race values (`leader`). |
| `lamp_final_lap` (not exported) | `final_lap` | Common lamp Lamp_final_lap: on the final lap. |
| `lamp_red` (not exported) | `lampred` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_green` (not exported) | `lampgreen` | Common lamp Lamp_green: the cabinet's green lamp (`lampgreen`). |
| `lamp_blue` (not exported) | `lampblue` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |
| `lamp_white` (not exported) | `lampwhite` | Common lamp Lamp_white: the cabinet's white lamp (`lampwhite`). |
| `lamp_marquee` (not exported) | `max(billboard_red, billboard_green, billboard_blue, billboard_white)` | Common lamp Lamp_marquee: the billboard, any colour. |

<a id="motogp"></a>
## MotoGP (2015)

Prefix `MOTOGP` (properties `TPTelemetry.MOTOGP_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampstart` | memory read, then `value > 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampleader` | memory read, then `value > 0` | LampLeader output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | memory read, then `value > 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | memory read, then `value > 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview3` | memory read, then `value > 0` | LampView3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `1p_brake_lamp` | memory read, then `value > 0` | 1p Brake Lamp output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |
| `lamp_brake` (not exported) | `_1p_brake_lamp` | Common lamp Lamp_brake: the brake lamp. |

<a id="outrun2sp"></a>
## OutRun 2 SP SDX

Prefix `OUTRUN2SP` (properties `TPTelemetry.OUTRUN2SP_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value * 0.7 / max_speed` | Speed in the game's own units (car_work +330; the FFB Arcade Plugin calls it the speedo). Not km/h: it reads about 431 where the speedo shows about 300 km/h (Alexis, 2 November 2026), so one unit is 0.7 km/h, as used here; the speedo itself (speed_kmh) reads 1.8% more (11 November 2026). Times 0.7, over Max speed (280 km/h). |
| `rpm` | memory read, then `floor(value + 0.5) * 10 / max_revs` | Engine RPM, read from game memory as OutputBlaster does (no OutputBlaster needed). The game stores RPM / 10 (idle about 163, top about 930 in Alexis's recordings, 2 November 2026), so this multiplies by 10. Divided by Max revs. |
| `steer` | memory read, then `value < 127 ? -(127 - value) / 127 : (value - 127) / 128` | Steering, -1 to 1, + right (it follows the G25 read over USB, 3 November 2026). Raw: Steering, 0 to 255 with 127 in the middle. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `drift` | memory read, then `value > 0 && value < 128` | 1 while the game counts the car as drifting (car +DE6, HamIsDrift): a brake tap or a lift and re-press of the throttle starts a 40-frame window, which the slip angle keeps open. 15 drifts of 2 to 10 s in the recording, at 60 to 78 degrees. From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `drift_angle` | memory read, then `speed_kmh > 10 ? value * 360 / 65536 : 0` | Slip angle of the rear tyres, degrees (car +56: the average of the two rear tyres' angles, in 65536ths of a turn), + a right-hand drift (Alexis: right turns at 93 and 226 s read +66 and +72, left turns at 133 and 285 s -75 and -60, in her recording of 11 November 2026, 19:06). The game keeps a drift going above about 4 degrees. 0 under 10 km/h, where the angle of a car barely moving swings to 180. From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `front_slip` (not exported) | memory read, then `value * 360 / 65536` | Slip angle of the front tyres, degrees (car +54); the deluxe cabinet's wheel motor presets are chosen from it. From the game's own code (its `jennifer`, 11 November 2026). Not yet checked in a recording. |
| `rev_limit` (not exported) | memory read, then `value * 10` | Raw: this car's rev limit, RPM (car data +1068 through car +46C, kept in tens like the revs: CalcRearWheels compares the revs with it). To compare with the redline light (8,380 on Alexis's car) across cars. From the game's own code (its `jennifer`, 11 November 2026). Not yet checked in a recording. |
| `rev_1030` (not exported) | memory read, then `value * 10` | Raw: a second rev value from the car data (+1030, in tens), which AccelOperation compares with the revs. Meaning to find. From the game's own code (its `jennifer`, 11 November 2026). Not yet checked in a recording. |
| `stage` | memory read, then `value + 1` | Stage, 1 to 5: the stage gates passed (check_point_count) plus 1. From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `race_time` | memory read, then `value / 60` | Race clock, seconds (total_timer, 60 a second): 4:55.75 at the finish line. From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `stage_time` | memory read, then `value / 60` | This stage's time so far, seconds (now_lap_time; restarts at each stage gate). From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `last_stage_time` (not exported) | memory read, then `value / 60` | The last stage's time, seconds (prev_lap_time). From the game's own code (its `jennifer`, 11 November 2026). Not yet checked in a recording. |
| `hearts` | memory read, then `value / 10000` | Heart Attack: the hearts won so far (GetTrueHeartValue keeps them x 10,000). In Alexis's Heart Attack run of 12 November 2026 (10:09) it went 0, 172 and 397 as she finished two challenges (TT 0:34.05 and 0:46.73: 172 hearts, then 225 more); the display ticks up to it over a moment. From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `speed2` | `sqrt(vel_x * vel_x + vel_y * vel_y + vel_z * vel_z)` | Speed from the car's velocity, in the game's own units (not km/h; compare with the speedo row in a recording to find the scale). In Alexis's recordings of 2 November 2026 the velocity addresses read nonsense (not tied to speed), so this row doesn't work in her build. |
| `impact_side` | `maxw(delta(side_hit_count) != 0 ? (side_hit_dir == 2 ? 1 : (side_hit_dir == 1 ? -1 : 0)) : 0, 0.3) + minw(delta(side_hit_count) != 0 ? (side_hit_dir == 2 ? 1 : (side_hit_dir == 1 ? -1 : 0)) : 0, 0.3)` | Side hit, +1 right or -1 left, held for 0.3 s so SimHub sees it. |
| `crash` | `maxw(delta(crash_count) != 0, 0.3)` | 1 for 0.3 s after a crash. |
| `rough_ground` | `surface == 4 \|\| surface == 8 \|\| surface == 16` | 1 on rough ground. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed (speed x Max speed undoes the division, in km/h). + speeding up, - slowing down. |
| `lampleader` | `band(ob_raceleader, 1) != 0` | LampLeader output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampleader2` | `band(ob_raceleader, 0) != 0` | LampLeader2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampstart` | `band(ob_outputdata, 128) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_outputdata, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampdriverleft` | `band(ob_outputdata, 32) != 0` | LampDriverLeft output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampdriverright` | `band(ob_outputdata, 4) != 0` | LampDriverRight output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `time_left` | `stage_timer / 60` | Stage time left, seconds: the stage timer counts down 60 a second (frames). From Alexis's recordings of 2 November 2026. |
| `checkpoint` | `maxw(delta(stage_timer) > 60 && prev(stage_timer) > 0, 1)` | 1 for 1 s after a checkpoint: the stage timer jumps up when time is added. From Alexis's recordings of 2 November 2026. |
| `wall_hit` | `maxw(delta(side_hit_count) > 1000000, 0.3)` | 1 for 0.3 s when a wall hit starts. side_hit_count is really a countdown the game starts at each wall hit (about 1.1 s), so only its jump up counts: all ten walls in the two recordings, nothing else. From Alexis's recordings of 2 November 2026. |
| `wall_side` | `wall_hit * sign(maxw(side_hit_dir == 2, 0.4) - maxw(side_hit_dir == 1, 0.4))` | Side of the wall hit, +1 right, -1 left, 0 unknown. side_hit_dir reads 1 near a left-hand wall and 2 near a right-hand one, from up to 0.1 s before the hit to 0.4 s after; at one hit it came only 0.02 s after the start, and at one (a right-hand wall) not at all. So this takes the side seen in the last 0.4 s. The wheel force (USB capture) had the right side at all twelve walls. From Alexis's recordings of 2 November 2026. |
| `g_fast` | `ema(slope(speed * max_speed, 0.05), 0.02) / 3.6 / g` | Quick longitudinal G, for spotting hits (speed x Max speed is km/h, 0.7 a game unit). |
| `hard_hit` | `maxw(g_fast < -21 && speed * max_speed > 14, 0.3)` | 1 for 0.3 s when the car loses speed at more than 21 G: the bus, the semitrailer and the midsize car (24 to 46 G), which crash_count misses. Braking stays under 7 G, but the speed reading dips at 14 to 18 G as some drifts start, so the line sits above that. Wall hits are 9 to 17 G (wall_hit catches them). Not when the speed reads under 20 (14 km/h): after the flip the game puts the car back on the track at 0, which isn't a hit. From Alexis's recordings of 2 November 2026. |
| `off_road` | `surface == 4 \|\| surface == 8 \|\| surface == 16 \|\| surface == 8192` | On grass (4, with 8192 at its edge) or sand (8); 16 is the FFB plugin's third rough surface. From Alexis's recordings of 2 November 2026. |
| `rumble_strip` | `surface == 1024 \|\| surface == 2048` | On a striped verge (1024) or the edge of sand or a verge (2048). On the road surface reads 2. From Alexis's recordings of 2 November 2026. |
| `crash_motion` | `band(crash_flags, 3) != 0` | 1 while the game plays a crash motion on the car (a spin, flip or knock from traffic, a wall or a bomb): in the recording 1.5 s for two traffic crashes (kind 7) and 2.5 s for a wall crash (kind 1), with bit 1 set for a frame and bit 2 throughout. From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `crash_kind` | `crash_motion ? floor(band(crash_flags, 124) / 4) : 0` | Which crash motion, 0 to 19: 7 running into the back of a truck or bus with the rear wheels leaving the ground, 1 a big wall crash with the car flying and flipping (Alexis, recording of 11 November 2026, 19:06); 3 is the other car-hit motion in the code. From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `crash_air` | `crash_motion ? (crash_kind == 1 ? 1 : (crash_kind == 7 && minw(crash_motion, 0.6) == 0 ? 0.5 : 0)) : 0` | The car off the ground in a crash: 1 through a flipping crash (kind 1, about 2.5 s), 0.5 for the first 0.6 s of a rear-end crash that lifts the rear wheels (kind 7). Feeds Car_airborne. From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `fork_sign` | `maxw(band(observer_flag, 32) != 0, 3)` | 1 for 3 s from when the game brings up the fork's "easy" arrow, about 13 s before the end of each stage (observer_flag 32; Alexis matched it at 83.6 s in her recording of 11 November 2026, 19:06, and says 3 s is about how long it stays up). From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `shift_light` | `rpm * max_revs >= 8270` | The redline light on the rev dial: on from 8,270 RPM. From Alexis's video on four cars (11 and 12 November 2026): the 250 GTO, 512 BB and Enzo (2nd gear) lit at 8,260 to 8,270, the Testarossa at 8,370 (TT 0:07.375, 3rd), the Enzo in 1st 0.3 s after the revs passed it. The game draws a dial per car (ten dial designs, each to 10,000 RPM, from the car's dial type at car +0A and smoothed display revs at car +3C4), so the light may differ a little by car; good enough as an indication (Alexis). |
| `car_hit` | `maxw(valid(hit_box1, 0) \|\| valid(hit_box2, 0) \|\| valid(hit_box3, 0) \|\| valid(hit_box4, 0) \|\| (valid(hit_dir, 0) != valid(prev(hit_dir), 0) && valid(hit_dir, 0) != 0), 0.3)` | 1 for 0.3 s when another car hits: a contact word set, or the side code changing. In Alexis's recordings of 12 November 2026 it caught all 16 car hits, one (at 92.9 s in the 10:05 recording) that nothing else did. From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `car_side` | `maxw(valid(hit_box1, 0) \|\| valid(hit_box2, 0), 0.4) ? 1 : (maxw(valid(hit_box3, 0) \|\| valid(hit_box4, 0), 0.4) ? -1 : (car_hit ? (band(valid(hit_dir, 0), 4) != 0 ? 1 : (band(valid(hit_dir, 0), 8) != 0 ? -1 : 0)) : 0))` | Side of a hit by another car, +1 right, -1 left, without USB capture: the contact words, or else the side code. It matched the wheel force's side at every car hit that had one in Alexis's recordings of 12 November 2026. From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `goal` | `band(observer_flag, 4) != 0` | 1 from the moment the car crosses the finish line of the last stage (CheckGoal). From the game's own code (its `jennifer`, 11 November 2026). Not yet checked in a recording. |
| `time_up` | `band(observer_flag, 1) != 0` | 1 once the time has run out (CheckGameTimer). From the game's own code (its `jennifer`, 11 November 2026). Not yet checked in a recording. |
| `racing` | `main_mode == 15 && !goal && !time_up` | 1 from GO to the finish line or time up: the game's main sequence in GAME, with no goal or time up. Not in the attract mode (sequence 3). In the recording: GO at 34.18 s (after 13 s of the start sequence, 13), the finish line at 331.90 s (her mark 332.07). From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `challenge_won` | `maxw(delta(hearts) > 0, 1)` | Heart Attack: 1 for 1 s when a challenge is finished and its hearts are awarded (the hearts total jumps). From the game's own code (its `jennifer`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 19:06. |
| `car_in_race` (not exported) | `racing` | Common value Car_in_race: 1 from GO to the finish line or time up: the game's main sequence in GAME with no goal or time up (not in the attract mode). Checked in Alexis's recording of 11 November 2026 (19:06): GO to the finish line. |
| `car_speed` (not exported) | `racing ? valid(speed_kmh, speed * max_speed) : 0` | Common value Car_speed: speed in km/h as the speedo shows it (the game's own speedo value; the speed row, 0.7 km/h a unit, when it can't be read). 0 outside a race (attract mode, menus), as Alexis asked for this game. |
| `car_rpm` (not exported) | `racing ? rpm * max_revs : 0` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). 0 outside a race (attract mode, menus), as Alexis asked for this game. |
| `car_gear` (not exported) | `racing ? gear : 0` | Common value Car_gear: gear. 0 outside a race (attract mode, menus), as Alexis asked for this game. |
| `car_accel_g` (not exported) | `racing ? accel_g : 0` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). 0 outside a race (attract mode, menus), as Alexis asked for this game. |
| `car_speed_kmh` (not exported) | `racing ? valid(speed_kmh, speed * max_speed) : 0` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the speedo). Car_speed_mph is this / 1.609344. 0 outside a race (attract mode, menus), as Alexis asked for this game. |
| `car_rev_limit_rpm` (not exported) | `valid(rev_limit, 0)` | Common value Car_rev_limit_rpm: this car's rev limit, RPM, from the game's car data (not yet checked in a recording); the plugin gives Max revs when it reads 0. |
| `car_time_left` (not exported) | `time_left` | Common value Car_time_left: time left (RT), seconds (this stage's). |
| `car_race_time` (not exported) | `race_time` | Common value Car_race_time: the race clock (TT), seconds. |
| `car_lap_time` (not exported) | `stage_time` | Common value Car_lap_time: this stage's time so far, seconds. |
| `car_steer` (not exported) | `steer` | Common value Car_steer: steering, -1 full left to 1 full right, as the game uses it. |
| `car_impact` (not exported) | `maxw(crash_motion && !prev(crash_motion), 0.3) ? 1 : (max(crash, wall_hit, hard_hit, valid(car_hit, 0)) > 0 ? clamp(0.5 + (-minw(g_fast, 0.3) - 10) / 70, 0.5, 1) : 0)` | Common value Car_impact: traffic, wall and other hits, 0.5 to 1 by how hard the car slowed (checked on two recordings, 2 November 2026); 1 the moment the game starts a crash motion (a spin or flip), which comes 0.5 s before the speed row falls (11 November 2026); car hits from the game's own contact words too (12 November 2026). |
| `car_impact_side` (not exported) | `valid(car_side, 0) != 0 ? car_side : wall_side` | Common value Car_impact_side: side of a hit, -1 left, 1 right: a car hit's side from the game's contact words (no USB needed; checked against the wheel force, 12 November 2026), else the wall side. With USB capture on, the plugin still fills any 0 from the wheel force. |
| `car_rumble_strip` (not exported) | `rumble_strip` | Common value Car_rumble_strip: 1 on a ripple strip. |
| `car_off_road` (not exported) | `off_road` | Common value Car_off_road: off the road. |
| `car_drift` (not exported) | `(1 - pow(1 - clamp((abs(drift_angle) - 5) / 70, 0, 1), 2)) * sqrt(clamp((speed_kmh - 20) / 80, 0, 1))` | Common value Car_drift: drifting, 0 to 1: the rear tyres' slip angle with ID6's curve stretched for OutRun's deeper drifts (nothing under 5 degrees or 20 km/h; full at 75 degrees and 100 km/h; Alexis, 11 November 2026, for this game only). |
| `car_drift_angle` (not exported) | `drift_angle` | Common value Car_drift_angle: the rear tyres' slip angle in degrees, + a right-hand drift (confirmed 11 November 2026; 0 under 10 km/h). |
| `car_cornering` (not exported) | `0` | Common value Car_cornering: none: the FFB plugin's hook sends OutRun 2 no steering force, only hits, sand and rough ground, and a small sine at gear changes (a recording with USB capture, 3 November 2026). The 0 row also stops the plugin working it out from the USB force, which would read a hit as cornering. |
| `car_airborne` (not exported) | `crash_air` | Common value Car_airborne: 1 through a flipping crash, 0.5 as a rear-end crash lifts the rear wheels (the game's crash motions). |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |
| `lamp_checkpoint` (not exported) | `checkpoint` | Common lamp Lamp_checkpoint: a checkpoint passed or time extended (`checkpoint`). |
| `lamp_shift` (not exported) | `shift_light` | Common lamp Lamp_shift: shift or over-rev light (the game's `shift_light`). |
| `lamp_warning` (not exported) | `shift_warning` | Common lamp Lamp_warning: an on-screen warning: SHIFT UP. |

<a id="rtuned"></a>
## R-Tuned: Ultimate Street Racing

Prefix `RTUNED` (properties `TPTelemetry.RTUNED_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `crash` | `crash_spring == 255` | 1 during a crash. |
| `spring_on` | `crash_spring == 4` | 1 while the game wants the centring spring. |
| `boost` | `boosting == 127 ? boost_level / 400 : 0` | Boost rumble strength as the FFB plugin scales it, 0 to about 0.64. |
| `lampstart` | `band(ob_outputs1, 8) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_outputs1, 16) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampred` | `band(ob_outputs2, 2) != 0` | LampRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampred2` | `band(ob_outputs2, 8) != 0` | LampRed2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampblue` | `band(ob_outputs2, 1) != 0` | LampBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampblue2` | `band(ob_outputs2, 4) != 0` | LampBlue2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `boost_lamp_red` | `band(ob_outputs1, 32) != 0` | Boost Lamp Red output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `boost_lamp_green` | `band(ob_outputs1, 64) != 0` | Boost Lamp Green output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `boost_lamp_blue` | `band(ob_outputs1, 128) != 0` | Boost Lamp Blue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `crash` | Common value Car_impact: crashes, 0 or 1. |
| `car_boost` (not exported) | `clamp(boost / 0.64, 0, 1)` | Common value Car_boost: boost, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_boost` (not exported) | `max(boost_lamp_red, boost_lamp_green, boost_lamp_blue)` | Common lamp Lamp_boost: the boost lamp, any colour. |
| `lamp_red` (not exported) | `lampred` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_blue` (not exported) | `lampblue` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |

<a id="rf3d"></a>
## Road Fighters 3D

Prefix `RF3D` (properties `TPTelemetry.RF3D_<row>`), process `TeknoMacaw.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `active` | `ffb3 != 0 && ffb4 != 0` | 1 while force feedback is active. |
| `force` | `active ? (ffb1 > 0 && ffb1 < 8 ? -ffb1 / 7 : (ffb1 > 7 && ffb1 < 16 ? (16 - ffb1) / 8 : 0)) : 0` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `vibration` | `active && ffb2 > 0 && ffb2 < 64 ? ffb2 / 63 : 0` | Vibration, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `hit` | `maxw(delta(damage) > 0, 0.2)` | 1 for 0.2 s whenever the player's damage goes up (a guess: damage may count the other way). |
| `car_in_race` (not exported) | `menu == 0` | Common value Car_in_race: 1 outside the menus. |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_impact` (not exported) | `hit` | Common value Car_impact: walls, karts and items hitting you, 0 or 1. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="segaracetv"></a>
## Sega Race TV

Prefix `SEGARACETV` (properties `TPTelemetry.SEGARACETV_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `force` | memory read, then `value > 0 && value < 128 ? -(128 - value) / 127 : (value > 128 ? clamp((value - 128) / 127, 0, 1) : 0)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). Raw: Force value: 1 to 127 one way, 129 to 255 the other (absolute address). Unverified: from the FFB Arcade Plugin's reading of this game. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(ob_output1, 128) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_output1, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `boost_lamp` | `band(ob_output1, 16) != 0` | Boost Lamp output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampred` | `band(ob_output1, 1) != 0` | LampRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampred2` | `band(ob_output2, 64) != 0` | LampRed2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampblue` | `band(ob_output1, 2) != 0` | LampBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampblue2` | `band(ob_output2, 128) != 0` | LampBlue2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_boost` (not exported) | `boost_lamp` | Common lamp Lamp_boost: the boost lamp. |
| `lamp_red` (not exported) | `lampred` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_blue` (not exported) | `lampblue` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |

<a id="segaracingclassic"></a>
## Sega Racing Classic

Prefix `SEGARACINGCLASSIC` (properties `TPTelemetry.SEGARACINGCLASSIC_<row>`), process `d1a.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `rpm` | memory read, then `value / max_revs` | Engine RPM, read from game memory as OutputBlaster does (no OutputBlaster needed); OutputBlaster itself sends it divided by 100. Divided by Max revs (blank = 1, so RPM; set it to the redline to make this run 0 to 1). Unverified. |
| `force` | `valid(hold(ffb_cmd >= 168 && ffb_cmd <= 175 ? (176 - ffb_cmd) / 8 : (ffb_cmd >= 152 && ffb_cmd <= 159 ? -(160 - ffb_cmd) / 8 : 0), (ffb_cmd >= 168 && ffb_cmd <= 175) \|\| (ffb_cmd >= 152 && ffb_cmd <= 159)), 0)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `valid(hold(pow((200 - ffb_cmd) / 8, 0.1), ffb_cmd >= 192 && ffb_cmd <= 199), 0)` | Centring spring, 0 to 1, kept until changed. |
| `friction` | `valid(hold((224 - ffb_cmd) / 8, ffb_cmd >= 216 && ffb_cmd <= 223), 0)` | Friction, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd >= 184 && ffb_cmd <= 191 ? (192 - ffb_cmd) / 8 : 0` | Vibration while the game asks for it, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(rawlamps, 4) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampleader` | `band(rawlamps, 32) != 0` | LampLeader output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(rawlamps, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | `band(rawlamps, 64) != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview3` | `band(rawlamps, 16) != 0` | LampView3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview4` | `band(rawlamps, 128) != 0` | LampView4 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `wooferledred` | `band(ob_data2, 1) != 0` | WooferLEDRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `wooferledgreen` | `band(ob_data2, 2) != 0` | WooferLEDGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `wooferledblue` | `band(ob_data2, 4) != 0` | WooferLEDBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `rearledred` | `band(ob_data2, 8) != 0` | RearLEDRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `rearledgreen` | `band(ob_data2, 16) != 0` | RearLEDGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `rearledblue` | `band(ob_data2, 32) != 0` | RearLEDBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |

<a id="sr3"></a>
## Sega Rally 3

Prefix `SR3` (properties `TPTelemetry.SR3_<row>`), process `Rally.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speed in mph: the game stores mph even when the screen shows km/h. Checked in Alexis's recording of 2 November 2026 (19:22): mph x 1.609 matched the speedo at her marks (186, 196, 201 and 193 km/h); top 130 mph (210 km/h); it updates 30 times a second. From Alexis's Cheat Engine table (SR3.CT). Divided by Max speed (125 mph, about 201 km/h: Alexis's choice, a little under the top so the full effect comes in before it), so it reads 1 at 125 mph. |
| `rpm` | memory read, then `floor(value + 0.5) / max_revs` | Engine RPM, read from game memory as OutputBlaster does (no OutputBlaster needed); OutputBlaster itself sends it divided by 100. Divided by Max revs (blank = 1, so RPM; set it to the redline to make this run 0 to 1). Checked in Alexis's recording of 2 November 2026 (19:22): limiter about 6930 in neutral, 5th and 6th, 7397 when overrevved on a downshift, 0 on the grid until the throttle is pressed. |
| `gear` | memory read, then `value - 1` | Gear in play: -1 before the driver's view comes up, 0 neutral on the grid, 1 first up to 6. The game stores 0 (reverse, per Alexis; only seen before the driver's view), 1 neutral, 2 first up to 7 sixth; this subtracts 1. Checked in Alexis's recording of 2 November 2026 (19:22): neutral on the grid, the game drops it into 1st at the start, then 2 to 6 as she shifted. From Alexis's Cheat Engine table (SR3.CT): pointer at Rally.exe+30B324, then +F4. |
| `tp_ok` | `tp_connected` | 1 while TeknoParrot's shared memory is available. |
| `ffb_cmd` | `tp_jvs2` | Raw force feedback command from TeknoParrot (slot 2): 1-15 and 16-31 are the two directions. |
| `force` | `clamp(tp_jvs2 > 15 ? -(31 - tp_jvs2) / 15 : (tp_jvs2 > 0 ? (16 - tp_jvs2) / 15 : 0), -1, 1)` | Decoded force, -1 to 1, + = force from the right. Checked in Alexis's recording of 2 November 2026 (19:22) against the force her G25 received over USB: the same values, about 0.02 s earlier. The game sends 5 to 15 (+0.73 to +0.07) and 21 to 30 (-0.67 to -0.07), so it never passes 0.73. It mostly follows the steering (+ steering right) with road texture on top, and is 0 in the air. |
| `lampview1` | memory read, then `band(value, 1) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `time_left` | memory read, then `value / 1000` | Time given, seconds (the game keeps milliseconds): set at GO (70 s on Alexis's course) and added to at each checkpoint and lap line (+25 s, +30 s). In game mode 6 the game counts it down to GAME OVER; in Quick Race (game mode 5) it only goes up, and the screen shows it less the race time (see rt). From the game's own code (Rally.exe, 12 November 2026). Checked in Alexis's recording of 16 November 2026 (10:24, game mode 5, three laps; claude/SR3-capture-20261116.md). |
| `lap` | memory read, then `value + 1` | Lap number: 1 once over the start line (2.9 s after GO), then 2 and 3 at the lap lines; 0 on the grid (the game counts laps done; the HUD shows one more). From the game's own code (Rally.exe, 12 November 2026). Checked in Alexis's recording of 16 November 2026 (10:24, game mode 5, three laps; claude/SR3-capture-20261116.md). |
| `position` | memory read, then `valid(hold(value, maxw(value, 0.1) == minw(value, 0.1)), value)` | Position, 1 = first. The game's own value flicks between two places for a few hundredths of a second when cars run side by side, so this holds a new place only once it has stood for 0.1 s. From the game's own code (Rally.exe, 12 November 2026). Checked in Alexis's recording of 16 November 2026 (10:24, game mode 5, three laps; claude/SR3-capture-20261116.md). |
| `wrong_way` | memory read, then `racing && value != 0` | 1 while the WRONG WAY sign shows (car 0's car object +1CBC): on while Alexis turned round, and while she reversed with the car facing forward (her answer, 16 November 2026). The game leaves it set in the menus, so it only counts while racing. From the game's own code (Rally.exe, 12 November 2026). Checked in Alexis's recording of 16 November 2026 (10:24, game mode 5, three laps; claude/SR3-capture-20261116.md). |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on SR3 is steering right: checked in Alexis's recording of 2 November 2026 (19:22). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks with the slow force removed, 0 to 1. On SR3 this is mostly road texture and the force changing sides as the steering moves: it passed 0.5 a fifth of the time in Alexis's recording of 2 November 2026 (19:22). Hits come from the hit row instead. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) * 0.44704 / g` | Longitudinal G from speed in mph (speed x Max speed undoes the division; 1 mph = 0.44704 m/s). + speeding up, - slowing down. |
| `airborne` | `minw(force == 0, 0.4) && speed * max_speed > 60` | 1 in the air: the game sends no force (TeknoParrot slot 2 reads 0) for 0.4 s or more above 60 mph. Both jumps in Alexis's recording of 2 November 2026 (19:22): no force from 32.07 to 32.66 s and from 38.52 to 39.47 s, so 1 from 0.4 s in. Elsewhere no force lasted 0.27 s at most above 60 mph (wheel straight ahead). A guess from two jumps. |
| `hit` | `maxw(-delta(speed * max_speed) > 3 + 0.05 * max(0, -prev(slope(speed * max_speed, 0.2))) && speed * max_speed > 10 && !maxw(airborne, 0.7), 0.3)` | 1 for 0.3 s when the speed drops by more than 3 mph in one game frame (a thirtieth of a second: over 4 G) from a steady speed. Walls are a one-frame drop; when the car is already slowing hard (a big slide: 204 to 44 km/h in 0.8 s, which Alexis says was no hit) the drop it takes rises with the slowing (by 0.05 mph a frame for each mph a second), so a slide or the automatic's downshifts don't count. Not counted within 0.7 s of airborne, so a landing (and the speed jitter just after it) is Car_landed only. Every wall in Alexis's recording of 2 November 2026 and every wall she named in her 12 November quick race. |
| `hit_side` | `hit ? valid(hold(prev(sign(valid(hold(force, force != 0), 0))), -delta(speed * max_speed) > 3), 0) : 0` | Side of the hit, +1 right, -1 left: the direction of the wheel force (the last one that wasn't 0) just before the speed drops; the game kicks the wheel towards the side hit. Right at six of the seven walls in Alexis's recording of 2 November 2026 (19:22); a rear right-hand hit while drifting read left. |
| `lampstart` | `band(ob_startbutton, 1) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | `band(ob_startbutton, 2) != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `racing` | `valid(player_state, 3) == 3` | 1 from GO to the finish line: the player state is racing (3). If the state can't be read at all it counts as racing, so a failed read leaves the effects as they were before this row (it never failed in Alexis's recording). From the game's own code (Rally.exe, 12 November 2026). Checked in Alexis's recording of 16 November 2026 (10:24, game mode 5, three laps; claude/SR3-capture-20261116.md). |
| `finished` | `player_state >= 4 && player_state <= 5` | 1 from the finish line (the player state's race finished, then post race). From the game's own code (Rally.exe, 12 November 2026). Checked in Alexis's recording of 16 November 2026 (10:24, game mode 5, three laps; claude/SR3-capture-20261116.md). |
| `checkpoint` | `maxw(racing && ((delta(checkpoints) > 0 && checkpoints > 0) \|\| (delta(time_left) > 1 && prev(time_left) > 0)), 2)` | 1 for 2 s after a checkpoint or lap line: the line count goes up or the time jumps up (time extended); not at GO (the time is set then) or over the start line from the grid. Alexis's three checkpoint marks came 0.4 to 0.5 s after it. From the game's own code (Rally.exe, 12 November 2026). Checked in Alexis's recording of 16 November 2026 (10:24, game mode 5, three laps; claude/SR3-capture-20261116.md). |
| `final_lap` | `racing && laps_total > 1 && lap == laps_total` | 1 on the final lap. From the game's own code (Rally.exe, 12 November 2026). Checked in Alexis's recording of 16 November 2026 (10:24, game mode 5, three laps; claude/SR3-capture-20261116.md). |
| `leader` | `racing && position == 1` | 1 while in the lead. From the game's own code (Rally.exe, 12 November 2026). Not yet checked in a recording. |
| `race_time` | `racing ? t - valid(hold(t, racing && !prev(racing)), t) : 0` | The race time (TT), seconds from GO; 0 outside a race. Alexis's finish at TT 3:10.76 matched. From the game's own code (Rally.exe, 12 November 2026). Checked in Alexis's recording of 16 November 2026 (10:24, game mode 5, three laps; claude/SR3-capture-20261116.md). |
| `rt` | `racing ? max(0, valid(game_mode, 5) == 6 ? time_left : time_left - race_time) : 0` | The time left as the screen shows it (RT), seconds: the time given less the race time in Quick Race (game mode 5); in game mode 6 the game counts time_left down itself (from its code, not yet seen). The screen shows whole seconds, cut off, not rounded: Alexis read 33 at TT 0:36.43 (70 less TT: 33.57) and 56 at TT 0:38.73 (95 less TT: 56.27). The game adds an extension at once (TT 0:36.12 here) while the screen keeps the old time until its TIME EXTENSION message has flashed, so rt goes up about 2 s before the screen does. 0 outside a race. From the game's own code (Rally.exe, 12 November 2026). Checked in Alexis's recording of 16 November 2026 (10:24, game mode 5, three laps; claude/SR3-capture-20261116.md). |
| `car_in_race` (not exported) | `racing` | Common value Car_in_race: 1 from GO to the finish line: the game's player state is racing (3); 0 in the attract mode and menus (state 0), the intro and from the line. Checked in Alexis's recording of 16 November 2026 (10:24). |
| `car_speed` (not exported) | `racing ? (speed * max_speed) : 0` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_rpm` (not exported) | `racing ? (rpm * max_revs) : 0` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_gear` (not exported) | `racing ? (gear) : 0` | Common value Car_gear: gear. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_accel_g` (not exported) | `racing ? (accel_g) : 0` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_speed_kmh` (not exported) | `racing ? ((speed * max_speed) * 1.609344) : 0` | Common value Car_speed_kmh: speed in km/h for dashboards, from mph as the screen shows it. Car_speed_mph is this / 1.609344. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_position` (not exported) | `racing ? (position) : 0` | Common value Car_position: race position, 1 = first. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_lap` (not exported) | `racing ? (lap) : 0` | Common value Car_lap: the lap you are on, 1 = first. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_laps_total` (not exported) | `racing ? (laps_total) : 0` | Common value Car_laps_total: laps in the race. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_time_left` (not exported) | `racing ? (rt) : 0` | Common value Car_time_left: time left (RT) as the screen shows it, seconds. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_race_time` (not exported) | `racing ? (race_time) : 0` | Common value Car_race_time: the race clock (TT), seconds. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_impact` (not exported) | `racing ? (hit ? clamp(0.5 + (maxw(-delta(speed * max_speed), 0.3) - 3) / 40, 0.5, 1) : 0) : 0` | Common value Car_impact: wall hits, 0.5 to 1 by how many mph the car lost in one game frame (3 mph 0.5, 23 mph or more 1; checked on a recording, 2 November 2026). 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_impact_side` (not exported) | `racing ? (hit_side) : 0` | Common value Car_impact_side: side of the hit, -1 left, 1 right, from the wheel force at the hit (a rear hit read the other side once). 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_road_bump` (not exported) | `0` | Common value Car_road_bump: none: the wheel force is steering and road texture all the time (Sega Rally 3 recording, 2 November 2026). The 0 row also stops the plugin working it out from the USB force. |
| `car_cornering` (not exported) | `racing ? (clamp(force_smooth, -1, 1)) : 0` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `car_airborne` (not exported) | `racing ? (airborne) : 0` | Common value Car_airborne: 1 in the air (a guess so far). 0 outside a race (attract mode, menus, paused), as Alexis asked (16 November 2026). |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_leader` (not exported) | `leader` | Common lamp Lamp_leader: in the lead, made from the race values (`leader`). |
| `lamp_checkpoint` (not exported) | `checkpoint` | Common lamp Lamp_checkpoint: a checkpoint passed or time extended (`checkpoint`). |
| `lamp_final_lap` (not exported) | `final_lap` | Common lamp Lamp_final_lap: on the final lap. |
| `lamp_warning` (not exported) | `wrong_way` | Common lamp Lamp_warning: an on-screen warning: WRONG WAY. |

<a id="swdc"></a>
## Sega World Drivers Championship

Prefix `SWDC` (properties `TPTelemetry.SWDC_<row>`), process `Todoroki-Win64-Shipping.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed2` | memory read, then `in_race ? value / max_speed : 0` | Speed in the game's own units (the table's speed2, which Alexis prefers): about 87 at the speedo's 220 km/h, not in proportion (see speed_kmh). Rises and falls in straight lines (the game's speed changes at fixed rates). Divided by Max speed (87). 0 outside a race (see in_race): before then it reads nonsense. From Alexis's Cheat Engine table (SWDC.CT, 3 November 2026), version 2.30. Checked in Alexis's recordings of 3 November 2026 (17:59 to 18:06). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `speed1` (not exported) | memory read, then `in_race ? value / max_speed : 0` | The table's other speed (speed1). Read nonsense in all four recordings of 3 November 2026 (values up to 10^38), so use speed2. Divided by Max speed. 0 outside a race (see in_race): before then it reads nonsense. From Alexis's Cheat Engine table (SWDC.CT, 3 November 2026), version 2.30. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `revs` | memory read, then `in_race ? value : 0` | Engine RPM as the game stores it (the engine sound's feed): exactly 3000 when the session loads, frozen (about 9326) through the countdown to the rolling start, then 3000 to 12000 while driving (redline about 11800; it sits at 12000 on the limiter); it freezes at the finish line and keeps its last value in the menus and the attract mode, so this row reads 0 outside a race. Your car's record has no engine revs (revs_record). From Alexis's Cheat Engine table (SWDC.CT, 3 November 2026), version 2.30. Checked in Alexis's recordings of 3 November 2026 (17:59 to 18:06). Checked in Alexis's recording of 19 November 2026 (SWDC-11). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `gear2` | memory read, then `in_race ? value : 0` | Gear, 1 to 6 (the table's gears2, which Alexis prefers). The game has no neutral or reverse. 0 outside a race (see in_race): before then it reads nonsense. From Alexis's Cheat Engine table (SWDC.CT, 3 November 2026), version 2.30. Checked in Alexis's recordings of 3 November 2026 (17:59 to 18:06). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `gear1` (not exported) | memory read, then `in_race ? value : 0` | The table's other gear (gears1). Read nonsense in all four recordings of 3 November 2026 (values up to 2 billion), so use gear2. 0 outside a race (see in_race): before then it reads nonsense. From Alexis's Cheat Engine table (SWDC.CT, 3 November 2026), version 2.30. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `kmh` (not exported) | memory read, then `in_race ? value : 0` | Speed as the speedo shows it, whole km/h (GetKilosPerHour): within 3 km/h of the table's speed2 through her speedo fit, up to 224 km/h in her race. Checked in Alexis's recording of 19 November 2026 (SWDC-11). From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `revs_record` (not exported) | memory read, then `in_race ? value : 0` | The revs in your car's record (GetRevsPerMinute): not the engine revs for your car (0, 8000 and odd values in her race, while revs ran 6,900 to 12,000). Kept to look at. From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `shift` (not exported) | memory read, then `in_race ? value : 0` | Gear in your car's record (GetShiftPosition): the same as the table's gears2 throughout her race. Checked in Alexis's recording of 19 November 2026 (SWDC-11). From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `brake` | memory read, then `in_race ? value : 0` | Brake in your car's record (GetBrake), 0 to 1: follows the brake pedal (USB) mostly. From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `spark_l` (not exported) | memory read, then `in_race ? value : 0` | Sparks on the left (GetSparkLValue): 1 while the car throws sparks on its left side. In her race they came as she downshifted under braking (TT 0:54.05, 1:51.83), not at hits. Checked in Alexis's recording of 19 November 2026 (SWDC-11). From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `spark_r` (not exported) | memory read, then `in_race ? value : 0` | Sparks on the right (GetSparkRValue), as spark_l. From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `afterfire` (not exported) | memory read, then `in_race ? value : 0` | Flames from the exhaust (GetAfterFireValue): 127 as they start, then fading by 16 a frame, mostly on lifts and shifts. From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `overall` (not exported) | memory read, then `in_race ? value : 0` | Your place among every car (GetTotalRank): 35 to 16 in her GT300 race of 19 November 2026 (45 cars, GT500 and GT300 together). The screen shows your class place (`position`). From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `position` | memory read, then `in_race ? value : 0` | Your place in your class, GT500 or GT300, as the screen and the results show it (GetClassRank): 20 to 1 in her GT300 race, 1st at the line as her results showed. Checked in Alexis's recording of 19 November 2026 (SWDC-11). From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `lap` (not exported) | memory read, then `in_race ? value : 0` | Laps: 0 from the rolling start to the start line, then 1, 2, 3 and 4 at the finish (GetLap). From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `sector` (not exported) | memory read, then `in_race ? value : 0` | The course sector your car is in, 1 to 3 (GetSector). From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `course_point` (not exported) | memory read, then `in_race ? value : 0` | Your car's point along the course's centre line (GetCourseCenterPoint). From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `lane` (not exported) | memory read, then `in_race ? value : 0` | Your car's distance to the side of the course's centre line (GetLaneSideOffset). From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `race_secs` | memory read, then `in_race ? value : 0` | Seconds since the rolling start (GetElapseSeconds): the race clock (TT), 3:16.29 at her finish line. From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `pos_x` (not exported) | memory read, then `in_race ? value : 0` | Your car's position (GetLocation), X, centimetres. From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `pos_y` (not exported) | memory read, then `in_race ? value : 0` | Your car's position, Y. From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `pos_z` (not exported) | memory read, then `in_race ? value : 0` | Your car's position, Z (height). From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `yaw` (not exported) | memory read, then `in_race ? value : 0` | Your car's heading in degrees (GetRotation's yaw; + turns to the right). From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `pitch` (not exported) | memory read, then `in_race ? value : 0` | Your car's pitch in degrees. From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `roll` (not exported) | memory read, then `in_race ? value : 0` | Your car's roll in degrees. From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `rpm` | `revs / max_revs` | Engine RPM in a race (revs), 0 otherwise. Divided by Max revs (12200: the rev limiter effect, at 97%, starts about the 11800 redline). From Alexis's Cheat Engine table (SWDC.CT, 3 November 2026), version 2.30. |
| `version` | `ver103_tag == 1396982867 ? 103 : (ver230_tag == 1396982867 ? 230 : 0)` | Game version found: 103, 230, or 0 if neither. |
| `ffb_raw` | `version == 230 ? ffb_raw230 : ffb_raw103` | Command for the version found: byte 0 = command, byte 1 = direction or period, bytes 2-3 = strength. |
| `ffb_str` | `version == 230 ? ffb_str230 : ffb_str103` | Strength for the version found, 0 to 32767. |
| `ffb_cmd` | `byte(ffb_raw, 0)` | Command: 132 constant force, 134 spring, 133 vibration, 128 (with byte 2 = 1) full spring. |
| `ffb_v1` | `byte(ffb_raw, 1)` | Direction for command 132 (0 or 1), period for 133. |
| `force` | `valid(hold(clamp(ffb_cmd == 132 && ffb_str > 0 ? (ffb_v1 == 0 ? -(32767 - ffb_str) / 32767 : (ffb_v1 == 1 ? ffb_str / 32767 : 0)) : 0, -1, 1), ffb_cmd == 132), 0)` | Constant force, -1 to 1, kept until the next force command. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 32767 : 1, (ffb_cmd == 134 && ffb_str > 0) \|\| (ffb_cmd == 128 && byte(ffb_raw, 2) == 1)), 0)` | Centring spring strength, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && ffb_v1 > 0 && ffb_str > 0 ? ffb_str / 32767 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `vibration_period_ms` | `ffb_cmd == 133 && ffb_v1 > 0 ? ffb_v1 / 127 * 120 : 0` | Vibration period, roughly milliseconds. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `speed_kmh` | `speed2 * max_speed * (2.0625 + 0.005467 * speed2 * max_speed)` | Speed as the speedo shows it, km/h: fitted to 17 readings Alexis took off the speedo (0 to 220 km/h), within 2.5 km/h. The raw speed is not in proportion to the speedo (2.1 km/h a unit at low speed, 2.5 at the top). Read 183 where Alexis noted 183 km/h. From Alexis's Cheat Engine table (SWDC.CT, 3 November 2026), version 2.30. Checked in Alexis's recordings of 3 November 2026 (17:59 to 18:06). |
| `accel_g` | `minw(in_race, 0.3) ? ema(slope(speed_kmh, 0.1), 0.05) / 3.6 / g : 0` | Longitudinal G from speed_kmh (the speedo's km/h; the raw unit isn't one the G could be worked out from), 0 for the first 0.3 s of a race so the speed coming on doesn't read as a jolt. + speeding up, - slowing down. |
| `hit` | `maxw(in_race && slope(speed_kmh, 0.05) / 3.6 / g < (brake > 0.5 ? -5 : -4), 0.3)` | 1 for 0.3 s while the car loses speed at more than 4 G (5 G while braking): the game slows the car at a fixed 4.6 to 5.6 G for 0.1 to 0.4 s at wall hits and head-on car hits; hard braking reaches 4.0 G at 220 km/h (her 19 November race, TT 2:26.55), and grinding along a wall about 2 G. No side: car_contact gives the side of most hits. Checked in Alexis's recordings of 3 November 2026 (17:59 to 18:06). Checked in Alexis's recording of 19 November 2026 (SWDC-11). |
| `player_ok` (not exported) | `version != 103 && player_no >= 1 && player_no <= cars && grid_no == player_no` | 1 when your car's record can be read (your car number in range and the record carrying it): from car select to the results screen in her recording. |
| `finished` (not exported) | `valid(player_ok, 0) && car_state == 3` | 1 from your finish line (race state 3) to the results. |
| `in_race` | `valid(player_ok, 0) && car_state == 2` | In a race: your car's race state 2, from the rolling start (the car moving at about 100 km/h) to your finish line (or retiring, time out). Every game value here reads 0 outside it, and so do the SimHub effects. Checked in her recording of 19 November 2026: on as the car starts moving, off on the line. From the v2.30 exe (Todoroki-Win64-Shipping.exe, UCarLibrary), 18 November 2026. |
| `checkpoint` | `maxw(in_race && minw(in_race, 0.5) && (delta(sector) != 0 \|\| delta(lap) > 0), 1)` | 1 for a second as you cross a sector line or a lap line (three a lap; not at the rolling start): the game's checkpoints. It has no time extensions (the lap time limit it keeps isn't shown). Checked in her races of 19 November 2026. Checked in Alexis's recording of 19 November 2026 (SWDC-11). |
| `wall_side` (not exported) | `in_race ? (spark_r ? 1 : 0) - (spark_l ? 1 : 0) : 0` | Which side is throwing sparks, -1 left, 1 right (0 none or both). |
| `backfire` (not exported) | `in_race && afterfire > 0 ? afterfire / 127 : 0` | The exhaust's flames, 1 as they start and fading, in a race. |
| `speedo_fit` (not exported) | `in_race && speed2 > 0 ? kmh / (speed2 * max_speed) : 0` | km/h on the speedo per unit of the table's speed2: a check on Alexis's speedo fit (2.45 to 2.70 in her race). |
| `travel` (not exported) | `minw(in_race, 0.3) ? atan2(slope(pos_y, 0.1), slope(pos_x, 0.1)) * 180 / pi : 0` | The direction your car is moving, degrees, from its position. |
| `pos_kmh` (not exported) | `minw(in_race, 0.3) ? hypot(slope(pos_x, 0.1), slope(pos_y, 0.1)) * 0.036 : 0` | Speed from the position, km/h: 3% under the speedo in her race. |
| `vel_lat` (not exported) | `minw(in_race, 0.3) ? (cos(yaw * pi / 180) * slope(pos_y, 0.1) - sin(yaw * pi / 180) * slope(pos_x, 0.1)) / 100 : 0` | How fast the car moves sideways, m/s, + to the right (from its position and heading). |
| `jolt` (not exported) | `minw(in_race, 0.5) ? slope(vel_lat, 0.1) / g : 0` | Sideways jolt in G, + pushed to the right: at a car contact or a wall the game shoves the car sideways, 4.3 to 10 G over a game frame or two. In her race of 19 November 2026 every car contact and wall hit she named, apart from a head-on hit (TT 0:17.44) and a light one against the left wall (0:25.84, 3.4 G), went over 4.3 G, always pushed away from the side hit; slips and corrections stay under 3.8 G, and the slides' own swings (to 5.8 G) are left out by the drift angle. |
| `car_contact` (not exported) | `maxw(in_race && abs(jolt) > 4 && maxw(abs(drift_angle), 0.5) < 25, 0.3)` | 1 for 0.3 s at a car contact or wall hit: a sideways jolt over 4 G while not sliding (the drift itself swings the heading). Twelve in her race of 19 November 2026, all real, the side right every time. Checked in Alexis's recording of 19 November 2026 (SWDC-11). |
| `contact_side` (not exported) | `car_contact ? valid(hold(-sign(jolt), abs(jolt) > 4 && prev(maxw(abs(jolt), 0.25)) <= 4), 0) : 0` | Side of the car hit at a contact, -1 left, 1 right: the other way from the first shove over 4 G (a rebound the other way, sometimes as big, follows it). Checked against her answers: all twelve sides in her GT300 race, and eight of ten she could tell in her GT500 race (a car pushing her from the inside of a left-hander at TT 0:42.59 read the other side; at 0:12.96 the shove of a car hitting her front centre was taken, not the one on her front right 0.15 s later). Checked in Alexis's recording of 19 November 2026 (SWDC-11). |
| `contact_strength` (not exported) | `car_contact ? clamp(0.4 + (maxw(abs(jolt), 0.3) - 4) / 10, 0.4, 1) : 0` | How hard a contact was, 0.4 to 1 by the jolt (4 G 0.4, 10 G 1). |
| `verge` (not exported) | `maxw(in_race && vibration > 0 && vibration < 0.2 && vibration_period_ms < 20, 0.3)` | On the grass verge: the game's vibration command at under 0.2 strength with a short period (7 to 9 ms), which it sends in pulses while wheels are on the verge (her race of 19 November 2026: TT 0:25.29 to 0:28.26, 1:14.13 to 1:14.67, 1:15.95 on, 1:25.30). Painted kerbs send nothing. |
| `kerb` (not exported) | `maxw(in_race && vibration >= 0.37 && vibration_period_ms >= 25, 0.3)` | On a solid kerb: the game's vibration command at about 0.4 with a long period (34 to 43 ms): TT 1:16.93 to 1:17.45 in her race, as her right wheels crossed the kerb. |
| `drift_angle` (not exported) | `minw(in_race, 0.3) && pos_kmh > 30 ? wrap(yaw - travel, 360) : 0` | Drift angle in degrees: your heading against the direction you're moving, + pointing right of your path (a right-hand drift), - left; 0 under 30 km/h. + in right-hand turns in her race (it follows the turn and the steering); her slides reached 40 to 55 degrees. |
| `drift` (not exported) | `maxw(car_contact, 0.5) ? 0 : clamp(0.072 * pow(max(abs(drift_angle) - 10, 0), 0.6) * sqrt(min(kmh, 150) / 100), 0, 1)` | Drifting, 0 to 1: the angle past 10 degrees, eased (power 0.6), times the square root of the speed over 100 km/h (counted up to 150), fitted to Alexis's seven slide values of 19 November 2026 (her values in brackets): GT300 race TT 0:55.8 43 degrees at 121 km/h 0.64 (0.65), 1:04 31 at 141 0.53 (0.6), 1:06 35 at 134 0.57 (0.5 to 0.55), 1:36 50 at 95 0.64 (0.6), 1:54 40 at 118 0.60 (0.55), 2:28 55 at 96 0.69 (0.75); GT500 race 0:24.87 45 at 133 0.70 (0.7). Her small slides in the GT500 race (20 to 23 degrees at 140 to 190 km/h) read about 0.3. 0 for 0.5 s after a contact, whose shove swings the heading. |
| `car_in_race` (not exported) | `in_race != 0` | Common value Car_in_race: 1 while racing. |
| `car_speed` (not exported) | `in_race ? (kmh) : 0` | Common value Car_speed: speed in km/h as the speedo shows it, from your car's record (checked 19 November 2026). 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_rpm` (not exported) | `in_race ? (revs) : 0` | Common value Car_rpm: engine RPM, raw (the table's revs; 0 outside a race). 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_gear` (not exported) | `in_race ? (shift) : 0` | Common value Car_gear: gear, 1 to 6, from your car's record (the same as the table's gears2). 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_accel_g` (not exported) | `in_race ? (accel_g) : 0` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_speed_kmh` (not exported) | `in_race ? (kmh) : 0` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the speedo). Car_speed_mph is this / 1.609344. 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_position` (not exported) | `in_race ? (position) : 0` | Common value Car_position: race position, 1 = first (your class place, as the screen shows it). 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_lap` (not exported) | `in_race ? (max(lap, 1)) : 0` | Common value Car_lap: the lap you are on, 1 = first (the game counts 0 on the rolling start). 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_race_time` (not exported) | `in_race ? (race_secs) : 0` | Common value Car_race_time: the race clock (TT), seconds from the rolling start. 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_brake` (not exported) | `in_race ? (brake) : 0` | Common value Car_brake: brake pedal, 0 to 1, as the game uses it. 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_impact` (not exported) | `in_race ? (max(contact_strength, hit ? clamp(0.5 + (maxw(speed_kmh, 0.6) - speed_kmh) / 120, 0.5, 1) : 0)) : 0` | Common value Car_impact: car contacts and wall hits: the sideways jolt (0.4 to 1) or the speed falling at more than 4 G (0.5 + km/h lost / 120, up to 1), whichever is bigger. The game's wheel kicks are left out: they come at slips and for show too (Alexis, 19 November 2026). 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_impact_side` (not exported) | `in_race ? (contact_side) : 0` | Common value Car_impact_side: side of a car contact or wall hit, -1 left, 1 right, from the way the game shoves the car (right in all twelve in her race of 19 November 2026); 0 for a head-on hit. 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_road_bump` (not exported) | `in_race ? (force_kick <= 0.5 ? force_kick * 2 : 0) : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_rumble_strip` (not exported) | `in_race ? (kerb) : 0` | Common value Car_rumble_strip: on a solid kerb (the game's long-period vibration; painted kerbs give nothing). 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_off_road` (not exported) | `in_race ? (verge) : 0` | Common value Car_off_road: on the grass verge (the game's short-period vibration pulses). 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_grip_loss` (not exported) | `in_race ? (drift) : 0` | Common value Car_grip_loss: sliding: follows Car_drift (0 to 1), as the game gives no slip value of its own. 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_drift` (not exported) | `in_race ? (drift) : 0` | Common value Car_drift: drifting, 0 to 1: ID6's weighting to start with (nothing under 5 degrees or 20 km/h; full at 50 degrees and 100 km/h). With no slip value of its own, Car_grip_loss follows it. To tune by feel. 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_drift_angle` (not exported) | `in_race ? (drift_angle) : 0` | Common value Car_drift_angle: the drift angle in degrees, + pointing right of the car's path (a right-hand drift), - left. The sign is to check. 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_cornering` (not exported) | `in_race ? (clamp(force_smooth, -1, 1)) : 0` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `car_vibration` (not exported) | `in_race ? (clamp(vibration / 0.1, 0, 1)) : 0` | Common value Car_vibration: the game's own vibration command, scaled: it sends 0.016 to 0.11 on verges and grinding along walls (more the faster you go), so 0.1 reads 1. 0 outside a race (menus, attract mode, after the line), as Alexis asked (19 November 2026). |
| `lamp_checkpoint` (not exported) | `checkpoint` | Common lamp Lamp_checkpoint: a checkpoint passed or time extended (`checkpoint`). |

<a id="sonicasr"></a>
## Sonic & Sega All-Stars Racing

Prefix `SONICASR` (properties `TPTelemetry.SONICASR_<row>`), process `game.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `force` | memory read, then `value > 0 && value < 19 ? value / 18 : (value > 237 ? -(256 - value) / 18 : 0)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). Raw: Force byte: 1 to 18 one way, 238 to 255 the other. The FFB plugin also writes 3 to the byte 12 before this to switch the game's force feedback on; this plugin only reads, so if this stays 0, run the FFB plugin too. Unverified: from the FFB Arcade Plugin's reading of this game. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(ob_data, 128) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `lampleader` | `band(ob_data, 64) != 0` | LampLeader output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `lampred` | `band(ob_data2, 8) != 0` | LampRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `lampgreen` | `band(ob_data2, 4) != 0` | LampGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `lampblue` | `band(ob_data2, 2) != 0` | LampBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `sideledred` | `band(ob_data, 2) != 0` | SideLEDRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `sideledgreen` | `band(ob_data, 1) != 0` | SideLEDGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `sideledblue` | `band(ob_data2, 128) != 0` | SideLEDBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `wooferledred` | `band(ob_data2, 64) != 0` | WooferLEDRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `wooferledgreen` | `band(ob_data2, 32) != 0` | WooferLEDGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `wooferledblue` | `band(ob_data2, 16) != 0` | WooferLEDBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `itemledred` | `band(ob_data, 8) != 0` | ItemLEDRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `itemledgreen` | `band(ob_data, 32) != 0` | ItemLEDGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `itemledblue` | `band(ob_data, 4) != 0` | ItemLEDBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. OutputBlaster also writes a byte to switch this game's outputs on; if these stay 0, run OutputBlaster or the FFB Arcade Plugin as well. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |
| `lamp_red` (not exported) | `lampred` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_green` (not exported) | `lampgreen` | Common lamp Lamp_green: the cabinet's green lamp (`lampgreen`). |
| `lamp_blue` (not exported) | `lampblue` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |

<a id="srg"></a>
## Storm Racer G

Prefix `SRG` (properties `TPTelemetry.SRG_<row>`), process `racing.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speedometer. Needs the game's Process set. Unverified: from the FFB Arcade Plugin's reading of this game. Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `tp_ok` | `tp_connected` | 1 while TeknoParrot's shared memory is available. |
| `ffb_force_raw` | `tp_jvs6` | Raw force from TeknoParrot (slot 6). |
| `ffb_shake_raw` | `tp_jvs7` | Raw shake from TeknoParrot (slot 7). |
| `ffb_ground_raw` | `tp_jvs8` | Raw ground/surface value from TeknoParrot (slot 8). |
| `force` | `clamp(tp_jvs6 / 46000, -1, 1)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `shake` | `clamp(tp_jvs7 / 1500, 0, 1)` | Shake strength, 0 to 1. |
| `lampside` | memory read, then `band(value, 255) != 0` | LampSide output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampside2` | memory read, then `band(value, 255) != 0` | LampSide2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `dash` | `band(ob_lights1, 4) != 0` | Dash output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampstart` | `band(ob_lights1, 16) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ob_lights1, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `billboardlamp` | `band(ob_lights1, 1) != 0` | BillboardLamp output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed, assuming km/h (speed x Max speed undoes the division, so this stays in G). + speeding up, - slowing down. |
| `car_in_race` (not exported) | `racing != 0` | Common value Car_in_race: 1 while racing. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_marquee` (not exported) | `billboardlamp` | Common lamp Lamp_marquee: the billboard lamp. |

<a id="fnfdrift"></a>
## The Fast and the Furious Drift

Prefix `FNFDRIFT` (properties `TPTelemetry.FNFDRIFT_<row>`), process `sdaemon.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampview1` | `band(ob_lamps, 8388608) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | `band(ob_lamps, 4194304) != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview3` | `band(ob_lamps, 2097152) != 0` | LampView3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview4` | `band(ob_lamps, 1048576) != 0` | LampView4 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampstart` | `band(ob_lamps, 589824) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |

<a id="fnfsb2"></a>
## The Fast and the Furious Super Bikes 2

Prefix `FNFSB2` (properties `TPTelemetry.FNFSB2_<row>`), process `sdaemon.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampstart` | `out_LampStart` | Output from OutputBlaster: LampStart (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampview1` | `out_LampView1` | Output from OutputBlaster: LampView1 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampview2` | `out_LampView2` | Output from OutputBlaster: LampView2 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `lampleader` | `out_LampLeader` | Output from OutputBlaster: LampLeader (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `fog_light_1` | `out_Fog_Light_1` | Output from OutputBlaster: Fog Light 1 (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `ledrearcover` | `out_LEDRearCover` | Output from OutputBlaster: LEDRearCover (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `dash` | `out_Dash` | Output from OutputBlaster: Dash (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `wooferledblue` | `out_WooferLEDBlue` | Output from OutputBlaster: WooferLEDBlue (0 or 1, or 0-255). Needs OutputBlaster running: it works this one out with code hooks or values it keeps between updates, which can't be read from memory. |
| `boost` | `maxw(delta(boosts) < 0, 1.5)` | 1 for 1.5 s after a boost is used (the boost length is a guess). |
| `car_time_left` (not exported) | `timer` | Common value Car_time_left: time left, seconds, from the cheat table's timer (not yet checked in a recording). |
| `car_boost` (not exported) | `boost` | Common value Car_boost: boost, 0 or 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |

<a id="fnfsc"></a>
## The Fast and the Furious SuperCars

Prefix `FNFSC` (properties `TPTelemetry.FNFSC_<row>`), process `sdaemon.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `lampstart` | memory read, then `value >= 1166012416 != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | memory read, then `value >= 1166012416 != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | memory read, then `value >= 1166012416 != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview3` | memory read, then `value >= 1166012416 != 0` | LampView3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview4` | memory read, then `value >= 1166012416 != 0` | LampView4 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |

<a id="wackyraces"></a>
## Wacky Races

Prefix `WACKYRACES` (properties `TPTelemetry.WACKYRACES_<row>`), process `Launcher.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `seatlamp1` | memory read, then `band(value, 255) != 0` | SeatLamp1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `seatlamp2` | memory read, then `band(value, 255) != 0` | SeatLamp2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `seatlamp3` | memory read, then `band(value, 255) != 0` | SeatLamp3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `seatlamp4` | memory read, then `band(value, 255) != 0` | SeatLamp4 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `seatlamp5` | memory read, then `band(value, 255) != 0` | SeatLamp5 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `seatlamp6` | memory read, then `band(value, 255) != 0` | SeatLamp6 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `ffb_code` | `band(ffb_raw, 4294948967)` | ffb_raw with the lamp bits removed. |
| `ffb_level` | `(ffb_code == 4096 ? 30 : (ffb_code == 64 ? 29 : (ffb_code == 4160 ? 28 : (ffb_code == 2048 ? 27 : (ffb_code == 6144 ? 26 : (ffb_code == 2112 ? 25 : (ffb_code == 6208 ? 24 : (ffb_code == 32 ? 23 : (ffb_code == 4128 ? 22 : (ffb_code == 96 ? 21 : (ffb_code == 4192 ? 20 : (ffb_code == 2080 ? 19 : (ffb_code == 6176 ? 18 : (ffb_code == 2144 ? 17 : (ffb_code == 6240 ? 16 : (ffb_code == 12288 ? 15 : (ffb_code == 8256 ? 14 : (ffb_code == 12352 ? 13 : (ffb_code == 10240 ? 12 : (ffb_code == 14336 ? 11 : (ffb_code == 10304 ? 10 : (ffb_code == 14400 ? 9 : (ffb_code == 8224 ? 8 : (ffb_code == 12320 ? 7 : (ffb_code == 8288 ? 6 : (ffb_code == 12384 ? 5 : (ffb_code == 10272 ? 4 : (ffb_code == 14368 ? 3 : (ffb_code == 10336 ? 2 : (ffb_code == 14432 ? 1 : 0))))))))))))))))))))))))))))))` | Force level, 1 to 15 one way and 16 to 30 the other, from the FFB plugin's table. |
| `force` | `ffb_level > 15 ? (31 - ffb_level) / 15 : (ffb_level > 0 ? -(16 - ffb_level) / 15 : 0)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(ffb_raw, 128) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(ffb_raw, 256) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `panellamp` | `band(ffb_raw, 8) != 0` | PanelLamp output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `slotlamp1` | `band(ffb_raw, 1024) != 0` | SlotLamp1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `slotlamp2` | `band(ffb_raw, 16) != 0` | SlotLamp2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `slotlamp3` | `band(ffb_raw, 512) != 0` | SlotLamp3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `seatlamp7` | `band(ffb_raw, 16384) != 0` | SeatLamp7 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `ob_ffb` | `band(ffb_raw, 8192) != 0` | FFB output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `ob_ffb1` | `band(ffb_raw, 4096) != 0` | FFB1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `ob_ffb2` | `band(ffb_raw, 64) != 0` | FFB2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `ob_ffb3` | `band(ffb_raw, 2048) != 0` | FFB3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `ob_ffb4` | `band(ffb_raw, 32) != 0` | FFB4 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_marquee` (not exported) | `seatlamp1` | Common lamp Lamp_marquee: cabinet lighting (`seatlamp1`). |

<a id="wmmt3dxp"></a>
## Wangan Midnight Maximum Tune 3 DX+

Prefix `WMMT3DXP` (properties `TPTelemetry.WMMT3DXP_<row>`), process `BudgieLoader.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `seq_active ? value * 0.0036 / max_speed : 0` | Speed, km/h: the car's speed in mm per second times 0.0036, exactly as the game works out its speedo. Divided by Max speed (220). It matched the old cheat-table row (a copy of the meter) to 0.1 km/h through the race. From the game's own code (its `main`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 18:36 (story mode, C class, Hakone inbound, manual). |
| `rpm` | memory read, then `seq_active ? value * 60 / (2 * pi) / max_revs : 0` | Engine revs: the engine's speed in radians a second times 60 / 2 pi, the value the game's tacho and rev lamp work from (this car's limiter is 10,000). Divided by Max revs (10000). The dial shows less: see tacho. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `gear` | memory read, then `seq_active ? value : 0` | Gear in play: 1 = first, 0 = neutral, -1 reverse (the transmission's own gear; with a manual shifter it is the shifter's position, up to the car's top gear). It matched the old row apart from a frame's lag at each change, and held 5th where the old row (the meter) showed the shifter in 6th on this five-speed car. From the game's own code (its `main`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 18:36 (story mode, C class, Hakone inbound, manual). |
| `rev_limit` | memory read, then `seq_active ? value : 0` | This car's limiter, RPM, from its engine data (the game's tacho and rev lamp are worked out against it). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `turbo` | memory read, then `seq_active ? value : 0` | Turbo boost, bar: -0.5 off the throttle up to this car's full boost (turbo_max). The boost gauge reads it. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `turbo_max` | memory read, then `seq_active ? value : 0` | This car's full boost, bar, from its turbo table by tuning: 0.6 untuned, then 0.9, 1.2, and 1.5 fully tuned. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `blowoff` | memory read, then `seq_active ? value : 0` | 1 while the boost falls away fast (from over 0.2 bar, by more than 0.27 in a frame): the game plays the blow-off valve then. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `backfire` | memory read, then `seq_active ? (value > 0 && value <= 26) : 0` | 1 for about 0.4 s from the exhaust flame: lifting off sharply at high revs starts a count of 35 or 38 frames and the game shows the flame as it passes 26. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `drift_angle` | memory read, then `seq_active ? -value * 360 / 65536 : 0` | Slip angle, degrees: the angle between where the car points and where it is going, from its sideways and forward speed (the game keeps it in 65536ths of a turn), + a right-hand drift (confirmed by Alexis: a right-hander at 75 s and a left hairpin at 81 s in her recording of 11 November 2026, 18:36). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `wheel_slip` | memory read, then `seq_active ? value : 0` | Wheel slip, the game's own measure of the driven wheels against the car: about -0.1 cruising, more negative as the wheels spin up (-0.3 with the car in the air, -0.6 pulling away in first), a little above 0 under braking (Alexis's recording of 11 November 2026, 18:36). From the game's own code (its `main`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 18:36 (story mode, C class, Hakone inbound, manual). |
| `load` | memory read, then `seq_active ? value : 0` | Load on the tyres as a fraction of the car's weight: 1 on the flat, more in a dip or on landing, 0 in the air. The game works its wheel spring out from it (load x 1.6 - 0.6, so the spring is gone below 0.375). In Alexis's recording of 11 November 2026, 18:36 it went under that only over crests and at the jump (252.3 s). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `wall_touch` | memory read, then `seq_active ? value : 0` | 1 while the car touches a wall (the game's own contact flag, set each frame). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `wall_force` (not exported) | memory read, then `seq_active ? value : 0` | Strength of the wall contact, in the game's units (it shakes the camera by it). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `car_touch` | memory read, then `seq_active ? value : 0` | 1 while the car touches another car (the game's own contact flag, set each frame). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `car_force` (not exported) | memory read, then `seq_active ? value : 0` | Strength of contact with another car, in the game's units: about 1,000 for a nudge on the rival, 2,000 to 6,000 for a swipe on traffic, 15,000 to 19,000 running into the back of traffic at 200 km/h or a truck shunting the car (Alexis's recordings of 11 November 2026). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `odometer` | memory read, then `seq_active ? value / 1000 : 0` | Distance along the course, metres (the game keeps it in mm). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `rival_odometer` (not exported) | memory read, then `seq_active ? value / 1000 : 0` | The CPU rival's distance along the course, metres (the first rival car; none in time attack or linked play). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `race_state` | memory read, then `seq_active ? value : 0` | Race state (yt::CState::eState): 0 none, 1 countdown, 2 racing (Run), 3 retired (going the wrong way too long), 4 slowing down (the time ran out), 5 stop wait, 6 time up, 7 at the goal (GoalWait: from the moment the car crosses the finish line), 8 goal, 9 defeated, 10 suspended. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `time_left` | memory read, then `seq_active ? value : 0` | Time left, seconds (yt::CState::fTDec_Rest; the cheat table's "GTimer1", which was the race_timer row): counts down while racing; at 0 the race slows to a stop. 300 at GO, stopping at the finish line. From the game's own code (its `main`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 18:36 (story mode, C class, Hakone inbound, manual). |
| `countdown` (not exported) | memory read, then `seq_active ? value : 0` | The start countdown, seconds (yt::CState::fTDec_CountDown). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `race_time` | memory read, then `seq_active ? value : 0` | Race clock, seconds (the time keeper's, which the split times come from). 216.06 s at the line: the time from GO. From the game's own code (its `main`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 18:36 (story mode, C class, Hakone inbound, manual). |
| `sections` (not exported) | memory read, then `seq_active ? value : 0` | Sections in the race: the finish line is the last. Story mode read 2 throughout, and sections_passed 2 too, so checkpoint never fired there (the story race ends on the rival, not on sections). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `sections_passed` (not exported) | memory read, then `seq_active ? value : 0` | Section lines passed so far; the race is finished when it reaches sections. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `reversing` | memory read, then `seq_active ? (band(value, 16777215) != 0) : 0` | 1 while the game counts the car as going the wrong way (yt::CState::bReverseBuf; too long and the race state goes to 3, retired). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `throttle` | memory read, then `seq_active ? value : 0` | Throttle pedal, 0 to 1, as the game uses it. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `brake` | memory read, then `seq_active ? value : 0` | Brake pedal, 0 to 1, as the game uses it. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `steer` | memory read, then `seq_active ? -value : 0` | Steering, -1 to 1, + right (the game keeps it with the sign flipped; confirmed by Alexis, recording of 11 November 2026, 18:36). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `carhit_x` (not exported) | memory read, then `seq_active ? value : 0` | Raw, for working out the side of hits: the push the game gives the car on a car contact (carhit_), a wall contact (wallhit_), and the car's orientation matrix (mat_ row, column). Not used yet. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `carhit_y` (not exported) | memory read, then `seq_active ? value : 0` | Raw, for working out the side of hits: the push the game gives the car on a car contact (carhit_), a wall contact (wallhit_), and the car's orientation matrix (mat_ row, column). Not used yet. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `carhit_z` (not exported) | memory read, then `seq_active ? value : 0` | Raw, for working out the side of hits: the push the game gives the car on a car contact (carhit_), a wall contact (wallhit_), and the car's orientation matrix (mat_ row, column). Not used yet. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `wallhit_x` (not exported) | memory read, then `seq_active ? value : 0` | Raw, for working out the side of hits: the push the game gives the car on a car contact (carhit_), a wall contact (wallhit_), and the car's orientation matrix (mat_ row, column). Not used yet. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `wallhit_y` (not exported) | memory read, then `seq_active ? value : 0` | Raw, for working out the side of hits: the push the game gives the car on a car contact (carhit_), a wall contact (wallhit_), and the car's orientation matrix (mat_ row, column). Not used yet. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `wallhit_z` (not exported) | memory read, then `seq_active ? value : 0` | Raw, for working out the side of hits: the push the game gives the car on a car contact (carhit_), a wall contact (wallhit_), and the car's orientation matrix (mat_ row, column). Not used yet. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `mat_00` (not exported) | memory read, then `seq_active ? value : 0` | Raw, for working out the side of hits: the push the game gives the car on a car contact (carhit_), a wall contact (wallhit_), and the car's orientation matrix (mat_ row, column). Not used yet. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `mat_01` (not exported) | memory read, then `seq_active ? value : 0` | Raw, for working out the side of hits: the push the game gives the car on a car contact (carhit_), a wall contact (wallhit_), and the car's orientation matrix (mat_ row, column). Not used yet. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `mat_02` (not exported) | memory read, then `seq_active ? value : 0` | Raw, for working out the side of hits: the push the game gives the car on a car contact (carhit_), a wall contact (wallhit_), and the car's orientation matrix (mat_ row, column). Not used yet. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `mat_10` (not exported) | memory read, then `seq_active ? value : 0` | Raw, for working out the side of hits: the push the game gives the car on a car contact (carhit_), a wall contact (wallhit_), and the car's orientation matrix (mat_ row, column). Not used yet. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `mat_20` (not exported) | memory read, then `seq_active ? value : 0` | Raw, for working out the side of hits: the push the game gives the car on a car contact (carhit_), a wall contact (wallhit_), and the car's orientation matrix (mat_ row, column). Not used yet. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `tp_ok` | `tp_connected` | 1 while TeknoParrot's shared memory is available. |
| `tp_spring` | `tp_jvs6 / 63` | From TeknoParrot (slot 6): centring spring, 0 to 1. No USB capture needed. |
| `tp_friction` | `tp_jvs7 / 63` | From TeknoParrot (slot 7): friction (viscosity), 0 to 1. |
| `tp_center` | `tp_jvs8 / 63` | From TeknoParrot (slot 8): centre offset, -1 to 1. |
| `tp_reflect` | `tp_jvs9 / 63` | From TeknoParrot (slot 9): reflect, -1 to 1. |
| `reflect_held` (not exported) | `minw(abs(tp_jvs9) == 25, 0.1)` | 1 once the reflect slot has read exactly 25 for 0.1 s: the game holds 25 while the car is pushed along a wall (3 s after the big crash on 1 November at 15:49; 0.5 s at a time at 15:54). Only 25 counts: two joints running together can give 0.2 s of 30s and 32s with no gap (15:54 recording, 28.9 s). |
| `rpm_frac` | `rev_limit > 0 ? clamp(rpm * max_revs / rev_limit, 0, 1) : 0` | Revs as a fraction of this car's own limiter, 0 to 1, as the game works it out for the tacho. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `tacho` | `seq_active ? (rpm_frac > 0.1 ? 0.96 * rpm_frac + 0.04 : 5 * rpm_frac * rpm_frac + 0.05) * 8000 : 0` | Revs as the dial shows them, RPM: the game sets the needle to 0.96 x the rev rate + 0.04 (yt::CSeq::Get2DInfoMeter), and the needle's full travel ends at the 8,000 mark (the dial is printed to 9,000 on every car, and the needle never gets there: Alexis). Her readings of 7.6k, 6.8k and 7.5k against 7,560, 6,890 and 7,480 from this; the engine itself was at 9,430, 8,557 and 9,323. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `shift_light` | `rpm_frac > 0.86` | The meter's rev lamp: on above 86% of the limiter, where the game lights it (the game blinks it; this holds it on). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `light` | `maxw(seq_active && load < 0.5, 0.1)` | 1 while the car is light over a crest (load under half its weight; held 0.1 s, as the load jitters). Alexis: the car goes slightly light over the crests at 50.5 s and 218.9 s in Alexis's recording of 11 November 2026, 18:36, not airborne, and wants a light effect there. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `airborne` | `minw(seq_active && load < 0.375, 0.25)` | 1 once the car has had too little load to steer for 0.25 s: in the air. In Alexis's recording of 11 November 2026, 18:36 the wheel spring that follows the load read 0 for 0.48 s at the jump (252.34 s, the rear in the air as Alexis described) and 0.19 s and 0.08 s over the crests, which she says were light, not airborne. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `hit_car` | `maxw(car_touch ? clamp(sqrt(car_force / 15000), 0, 1) : 0, 0.15)` | Hits on other cars and traffic, 0 to 1, held 0.15 s: the square root of the contact strength over 15,000, so a nudge reads 0.25, a swipe 0.4 to 0.65, a crash 1. TeknoParrot's reflect slot misses these (it gives car hits 59 of 63, under the wall-hit threshold). In Alexis's recording of 11 November 2026, 20:15 it caught all 13 contacts with a strength (a 14th, with none, ran into a wall a frame later). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `car_side` | `maxw(maxw(car_touch, 0.1) && tp_reflect < -0.9 && tp_reflect > -0.97, 0.15) - maxw(maxw(car_touch, 0.1) && tp_reflect > 0.9 && tp_reflect < 0.97, 0.15)` | Side of a car or traffic hit, +1 right, -1 left, held 0.15 s: TeknoParrot's slot 9 gives car hits 59 of 63, signed the opposite way to wall hits (-59 for a hit on the right). Alexis's answers for 11 November 2026: her front right on the rival twice and on traffic twice read right, a truck along her left side read left. Straight-on hits get a side from whichever corner touched first; a hit from behind read left. From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `rival_gap` | `valid(odometer - rival_odometer, 0)` | Metres ahead of the CPU rival (+ ahead, - behind); 0 with no rival. The same distances the race display measures to the goal. Behind at the start, then ahead, passed and ahead again, as the race went. From the game's own code (its `main`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 18:36 (story mode, C class, Hakone inbound, manual). |
| `leader` | `rival_gap > 0` | 1 while ahead of the CPU rival. From the game's own code (its `main`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 18:36 (story mode, C class, Hakone inbound, manual). |
| `in_race` | `seq_active && maxw(race_time != prev(race_time) \|\| countdown != prev(countdown), 0.25) && (race_state == 2 \|\| race_state == 1 && countdown < 3.99)` | 1 from the start of the countdown (the driver's view) to the finish line: race state 1 with the countdown running, then 2. The game moves to 7 the moment the car crosses the line, and to 4 when the time runs out. Off while the clocks stand still (a pause). The story mode's opening shot before the race also sets state 1 for a moment, but with the countdown held at 4, so it stays off. Race state 2 from GO (47.68 s) to the finish line (263.76 s); the countdown from 43.6 s is the driver's view (Alexis: start there, not in the opening shot from 34 s). The attract mode (recording of 11 November 2026, 16:59) never ran the race code. Her pause in the first recording that day froze every clock for 3.4 s. From the game's own code (its `main`, 11 November 2026). Checked in Alexis's recording of 11 November 2026, 18:36 (story mode, C class, Hakone inbound, manual). |
| `checkpoint` | `maxw(sections_passed > prev(sections_passed) && sections_passed < sections, 2)` | 1 for 2 s after each section line before the finish (where any extra time is added). From the game's own code (its `main`, 11 November 2026). Not yet checked in a recording. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed (speed x Max speed undoes the division). + speeding up, - slowing down. |
| `tp_force` | `clamp(tp_jvs8 != 0 ? -tp_center : tp_reflect, -1, 1)` | From TeknoParrot: the constant force the wheel gets (centre offset when there is one, otherwise reflect). Matches the force the wheel gets over USB, sign and scale (checked 29 October 2026). + = force from the right: right-hand corners and right-side hits. |
| `grip_loss` | `clamp((1 - tp_spring) / 0.3, 0, 1)` | From TeknoParrot: 0 gripping, 1 sliding (WMMT3 eases the spring off in slides). No direction. Same formula as the USB version checked on a G25 capture. |
| `cornering` | `ema(tp_force, 0.15)` | From TeknoParrot: sustained pull in corners, -1 to 1, + = right-hand corner (if tp_force's sign matches the wheel's: confirm with a recording). |
| `cornering_abs` | `abs(cornering)` | From TeknoParrot: cornering load without direction, 0 to 1. |
| `road_bump` | `clamp(road_joint / 0.52, 0, 1)` | Expansion joints, 0 to 1 (1 at about 220 km/h), from road_joint. Before 1 November this came from short kicks in tp_force, which also caught crashes and missed joints while the game sent a centre force. |
| `impact_now` (not exported) | `abs(tp_reflect) > 0.95` | 1 while the reflect slot reads 63 (a hit on a wall or car). Joints never go above 39. Before 1 November this used the spring and tp_force, which missed a left-hand wall hit. |
| `impact_dir` (not exported) | `sign(tp_reflect)` | Side of the reflect kick: + right, - left. |
| `impact` | `maxw(impact_now, 0.15)` | From TeknoParrot: 1 for 0.15 s after a hit on any side. |
| `impact_side` | `maxw(impact_now && impact_dir > 0, 0.15) - maxw(impact_now && impact_dir < 0, 0.15)` | From TeknoParrot: +1 hit on the right, -1 on the left (if tp_force's sign matches the wheel's: confirm with a recording). |
| `wall_contact` | `minw(maxw(impact_now \|\| reflect_held, 0.35), 0.3) ? valid(hold(sign(tp_reflect), impact_now \|\| reflect_held), 0) : 0` | Scraping along a wall: +1 right, -1 left, 0 otherwise. On after 0.3 s of steady contact (63 kicks under 0.35 s apart, or 25 held). Checked on six walls in two recordings (1 November), three each side. The side comes from the hits and the held value only, so a joint pulse on the other side as you leave the wall doesn't flip it. |
| `road_joint` | `abs(tp_reflect) > 0.3 && abs(tp_reflect) < 0.75 && maxw(impact_now, 0.25) == 0 && reflect_held == 0 && wall_contact == 0 ? abs(tp_reflect) : 0` | Expansion joints: short reflect pulses of 26 to 33 (of 63), bigger the faster you go (26 at 100 km/h, 33 at 220). Pulses near a hit or held against a wall are excluded. Each joint is usually two pulses about 0.07 s apart (front then rear wheels). Two recordings on 1 November: every one of the 26 marked joints, nothing during the six crashes. |
| `long_g_fast` (not exported) | `ema(slope(speed * max_speed, 0.05), 0.02) / 3.6 / g` | From speed: fast-reacting forward/back G for spotting impacts. Not exported. |
| `impact_front` | `maxw(clamp((-long_g_fast - 1.5) / 2, 0, 1), 0.15)` | From speed: strength of a frontal hit, 0 to 1 (slowing faster than 1.5 G, more than brakes manage). Thresholds untested: tune them from a recording. |
| `impact_rear` | `maxw(clamp((long_g_fast - 1.2) / 2, 0, 1), 0.15)` | From speed: strength of a hit from behind, 0 to 1 (speeding up faster than 1.2 G). Thresholds untested: tune them from a recording. |
| `impact_long` | `impact_front - impact_rear` | From speed: + = frontal hit, - = hit from behind. |
| `impact_long_abs` | `max(impact_front, impact_rear)` | From speed: front or rear hit strength without direction, 0 to 1. |
| `car_in_race` (not exported) | `in_race` | Common value Car_in_race: 1 from the countdown (driver's view) to the finish line, off while paused: the game's race state (checked in Alexis's recording of 11 November 2026, 18:36). |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the game's own speed). Car_speed_mph is this / 1.609344. |
| `car_rev_limit_rpm` (not exported) | `rev_limit` | Common value Car_rev_limit_rpm: this car's rev limit, RPM (the rev_limit row), for a dashboard's redline. |
| `car_time_left` (not exported) | `time_left` | Common value Car_time_left: time left (RT), seconds. |
| `car_race_time` (not exported) | `race_time` | Common value Car_race_time: the race clock (TT), seconds. |
| `car_brake` (not exported) | `brake` | Common value Car_brake: brake pedal, 0 to 1, as the game uses it. |
| `car_steer` (not exported) | `steer` | Common value Car_steer: steering, -1 full left to 1 full right, as the game uses it. |
| `car_gap` (not exported) | `rival_gap` | Common value Car_gap: distance to the CPU rival, metres: + ahead, - behind; 0 with no rival. |
| `car_impact` (not exported) | `max(impact > 0 ? clamp(0.6 + (-long_g_fast - 1.5) / 20, 0.6, 1) : 0, valid(hit_car, 0))` | Common value Car_impact: wall hits, 0.6 for an ordinary hit, rising to 1 the harder the car slows; car and traffic hits by the game's contact strength (0.25 a nudge to 1 a crash). |
| `car_impact_side` (not exported) | `impact_side != 0 ? impact_side : valid(car_side, 0)` | Common value Car_impact_side: side of the hit, -1 left, 1 right: walls from TeknoParrot's slot 9, car hits from its sign on car hits (Alexis's answers, 11 November 2026). |
| `car_wall_contact` (not exported) | `wall_contact` | Common value Car_wall_contact: scraping along a wall, -1 left, 1 right. |
| `car_road_bump` (not exported) | `road_bump` | Common value Car_road_bump: expansion joints and bumps, 0 to 1. |
| `car_grip_loss` (not exported) | `grip_loss` | Common value Car_grip_loss: sliding, 0 to 1. |
| `car_drift` (not exported) | `(1 - pow(1 - clamp((abs(drift_angle) - 5) / 45, 0, 1), 2)) * sqrt(clamp((speed * max_speed - 20) / 80, 0, 1))` | Common value Car_drift: drifting, 0 to 1: the game's slip angle with ID6's weighting (nothing under 5 degrees or 20 km/h; full at 50 degrees and 100 km/h). WMMT's slides are shallower than Initial D's, so this may read low: to tune after a recording. |
| `car_drift_angle` (not exported) | `drift_angle` | Common value Car_drift_angle: the slip angle in degrees, + a right-hand drift (confirmed, 11 November 2026). |
| `car_cornering` (not exported) | `clamp(cornering, -1, 1)` | Common value Car_cornering: cornering load from the wheel force, + turning right. |
| `car_airborne` (not exported) | `airborne ? 1 : (light ? 0.3 : 0)` | Common value Car_airborne: 1 in the air (0.25 s with almost no load on the tyres), 0.3 while the car is light over a crest (Alexis: a light effect there, 11 November 2026). |
| `car_boost` (not exported) | `turbo_max > 0 ? clamp(turbo / turbo_max, 0, 1) : 0` | Common value Car_boost: turbo boost, 0 to 1: the boost over this car's full boost (0.6 to 1.5 bar by tuning), 0 off the throttle. Not yet checked in a recording. |
| `car_rpm_frac` (not exported) | `rpm_frac` | Common value Car_rpm_frac: revs as a fraction of this car's own limiter, as the game's tacho works it out: the rev limiter and engine effects follow every car (plugin 0.17.0; older plugins use revs / Max revs). Not yet checked in a recording. |
| `car_throttle` (not exported) | `clamp(throttle, 0, 1)` | Common value Car_throttle: throttle pedal, 0 to 1, as the game uses it: the engine effects run at 60% off the throttle, full at full throttle. Not yet checked in a recording. |
| `lamp_leader` (not exported) | `leader` | Common lamp Lamp_leader: in the lead, made from the race values (`leader`). |
| `lamp_checkpoint` (not exported) | `checkpoint` | Common lamp Lamp_checkpoint: a checkpoint passed or time extended (`checkpoint`). |
| `lamp_shift` (not exported) | `shift_light` | Common lamp Lamp_shift: shift or over-rev light (the game's `shift_light`). |

<a id="wmmt5"></a>
## Wangan Midnight Maximum Tune 5

Prefix `WMMT5` (properties `TPTelemetry.WMMT5_<row>`), process `wmn5r.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speed, km/h, in whole numbers. Unverified: from the FFB Arcade Plugin's reading of this game. The same value was checked on WMMT5DX+ (29 October and 1 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `rpm` | memory read, then `value / max_revs` | Engine RPM. The limiter is soft and depends on the car: revs creep up to about 8250 on one WMMT5DX+ car and 8500 on another. Before the race starts it can read nonsense (99999 seen). Unverified: from the FFB Arcade Plugin's reading of this game. The same value was checked on WMMT5DX+ (29 October and 1 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). |
| `in_race` | `race_time > 0 && maxw(delta(race_time) > 0, 0.1)` | 1 while the race clock is running: off before the start, after the finish line (results screen) and while the game is frozen. Checked on WMMT5DX+ (1 November 2026). |
| `road_joint` | `abs(collisions) > 0.001 && abs(collisions) < 0.35 && maxw(abs(collisions) >= 0.35, 0.25) == 0 && minw(abs(collisions) > 0.001, 0.1) == 0 ? abs(collisions) : 0` | Expansion joints and ripple strips, 0 to about 0.3, no direction: the game sends each as a kick under 0.1 s long, one per axle (front then rear, closer together the faster you go). Kicks just after a hit, or held 0.1 s or more, are wall contact instead. On WMMT5DX+ 0.21 from walking pace to 100 km/h, 0.31 at 240; caught at 15, 40, 60 and 80 km/h (1 November 2026). |
| `rumble_strip` | `maxw(avg(maxw(road_joint > 0, 0.07), 0.45) > 0.85, 0.3)` | 1 on a ripple strip: the game kicks every 0.07 to 0.13 s for as long as you are on it, where a joint is one kick per axle (two joints close together make 3 or 4). Needs about five kicks, so it comes on about 0.4 s into a strip (as a short strip ends) and stays on 0.3 s after. Checked on WMMT5DX+: long strips at 100 to 240 km/h, five short ones (5 or 6 kicks) and one crossed in a slide, confirmed from video (1 November 2026); on and off while drifting across one. |
| `impact` | `abs(collisions) >= 0.35 ? clamp(collisions, -1, 1) : 0` | Hits, -1 to 1: the game sends 0.5 for most hits and more in a big crash (0.78 seen). Sliding along a wall gives a run of 0.5 kicks. + = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, a left-hand wall hit -0.5). |
| `impact_side` | `maxw(impact, 0.3) + minw(impact, 0.3)` | Hit held for 0.3 s so SimHub sees it, -1 to 1. + = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, a left-hand wall hit -0.5). |
| `wall_contact` | `minw(maxw(abs(collisions) >= 0.35 \|\| minw(abs(collisions) > 0.001, 0.1), 0.15), 0.3) ? valid(hold(sign(collisions), abs(collisions) > 0.001), 0) : 0` | Scraping along a wall, +1 right, -1 left, 0 otherwise: on after 0.3 s of steady contact (hits under 0.15 s apart, or 0.2 held). Single hits show on impact instead. Checked on WMMT5DX+ (three walls, 29 October 2026). |
| `airborne` | `minw(in_race, 0.5) > 0 && maxw(spring, 0.05) < 0.01 && maxw(abs(collisions) >= 0.35 \|\| minw(abs(collisions) > 0.001, 0.1), 0.5) == 0` | 1 while the game holds the centring spring at 0 with no hit or wall contact in the last 0.5 s. On WMMT5DX+ that happens whenever the car goes light: jumps, and crests even where the wheels stay down. The revs jump as the driven wheels lose grip, and a joint-sized kick often comes as it lands. Checked from video: one jump (29 October 2026) and six crests (1 November 2026: two with the rear wheels off the road, revs up 1260 to 1700; four with the wheels down, revs up about 800). |
| `grip_loss` | `clamp(abs(tire_slip) / 0.1, 0, 1)` | Sliding, 0 gripping to 1: tire_slip reaches about 0.1 in slides (WMMT5DX+). No direction. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed (speed x Max speed undoes the division, so this stays in G). Speed is in whole km/h, so this jitters by about 0.1 G when cruising. + speeding up, - slowing down. |
| `lampview1` | `band(ob_outputdata, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampinterruptionbutton` | `band(ob_outputdata, 4) != 0` | LampInterruptionButton output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampred` | `band(ob_outputdata2, 128) != 0` | LampRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampgreen` | `band(ob_outputdata2, 64) != 0` | LampGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampblue` | `band(ob_outputdata2, 32) != 0` | LampBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampwhite` | `ob_outputdata2 >= 224 ? 1 : 0` | LampWhite output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampside` | `band(ob_outputdata2, 16) != 0` | LampSide output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_in_race` (not exported) | `in_race != 0` | Common value Car_in_race: 1 while racing. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the FFB Arcade Plugin's reading, checked on WMMT5DX+). Car_speed_mph is this / 1.609344. |
| `car_race_time` (not exported) | `race_time` | Common value Car_race_time: the race clock (TT), seconds. |
| `car_impact` (not exported) | `clamp(abs(impact) / 0.8, 0, 1)` | Common value Car_impact: hits, 0 to 1: an ordinary hit (0.5) reads about 0.6, a big crash 1. |
| `car_impact_side` (not exported) | `sign(impact_side)` | Common value Car_impact_side: side of the hit, -1 left, 1 right. |
| `car_wall_contact` (not exported) | `wall_contact` | Common value Car_wall_contact: scraping a wall, -1 left, 1 right. |
| `car_road_bump` (not exported) | `clamp(road_joint / 0.3, 0, 1)` | Common value Car_road_bump: expansion joints and bumps, 0 to 1. |
| `car_rumble_strip` (not exported) | `rumble_strip` | Common value Car_rumble_strip: 1 on a ripple strip. |
| `car_grip_loss` (not exported) | `grip_loss` | Common value Car_grip_loss: sliding, 0 to 1. |
| `car_cornering` (not exported) | `clamp(-tire_slip / 0.1, -1, 1)` | Common value Car_cornering: cornering from tyre slip, + turning right. Approximate: WMMT5/6 send no cornering force. |
| `car_airborne` (not exported) | `airborne` | Common value Car_airborne: 1 in the air (a guess so far). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_action` (not exported) | `lampinterruptionbutton` | Common lamp Lamp_action: the cabinet's extra button (the game's `lampinterruptionbutton`). |
| `lamp_red` (not exported) | `lampred` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_green` (not exported) | `lampgreen` | Common lamp Lamp_green: the cabinet's green lamp (`lampgreen`). |
| `lamp_blue` (not exported) | `lampblue` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |
| `lamp_white` (not exported) | `lampwhite` | Common lamp Lamp_white: the cabinet's white lamp (`lampwhite`). |
| `lamp_marquee` (not exported) | `lampside` | Common lamp Lamp_marquee: cabinet lighting (`lampside`). |

<a id="wmmt5dx"></a>
## Wangan Midnight Maximum Tune 5DX

Prefix `WMMT5DX` (properties `TPTelemetry.WMMT5DX_<row>`), process `wmn5r.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speed, km/h, in whole numbers. Unverified: from the FFB Arcade Plugin's reading of this game. The same value was checked on WMMT5DX+ (29 October and 1 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `rpm` | memory read, then `value / max_revs` | Engine RPM. The limiter is soft and depends on the car: revs creep up to about 8250 on one WMMT5DX+ car and 8500 on another. Before the race starts it can read nonsense (99999 seen). Unverified: from the FFB Arcade Plugin's reading of this game. The same value was checked on WMMT5DX+ (29 October and 1 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). |
| `in_race` | `race_time > 0 && maxw(delta(race_time) > 0, 0.1)` | 1 while the race clock is running: off before the start, after the finish line (results screen) and while the game is frozen. Checked on WMMT5DX+ (1 November 2026). |
| `road_joint` | `abs(collisions) > 0.001 && abs(collisions) < 0.35 && maxw(abs(collisions) >= 0.35, 0.25) == 0 && minw(abs(collisions) > 0.001, 0.1) == 0 ? abs(collisions) : 0` | Expansion joints and ripple strips, 0 to about 0.3, no direction: the game sends each as a kick under 0.1 s long, one per axle (front then rear, closer together the faster you go). Kicks just after a hit, or held 0.1 s or more, are wall contact instead. On WMMT5DX+ 0.21 from walking pace to 100 km/h, 0.31 at 240; caught at 15, 40, 60 and 80 km/h (1 November 2026). |
| `rumble_strip` | `maxw(avg(maxw(road_joint > 0, 0.07), 0.45) > 0.85, 0.3)` | 1 on a ripple strip: the game kicks every 0.07 to 0.13 s for as long as you are on it, where a joint is one kick per axle (two joints close together make 3 or 4). Needs about five kicks, so it comes on about 0.4 s into a strip (as a short strip ends) and stays on 0.3 s after. Checked on WMMT5DX+: long strips at 100 to 240 km/h, five short ones (5 or 6 kicks) and one crossed in a slide, confirmed from video (1 November 2026); on and off while drifting across one. |
| `impact` | `abs(collisions) >= 0.35 ? clamp(collisions, -1, 1) : 0` | Hits, -1 to 1: the game sends 0.5 for most hits and more in a big crash (0.78 seen). Sliding along a wall gives a run of 0.5 kicks. + = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, a left-hand wall hit -0.5). |
| `impact_side` | `maxw(impact, 0.3) + minw(impact, 0.3)` | Hit held for 0.3 s so SimHub sees it, -1 to 1. + = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, a left-hand wall hit -0.5). |
| `wall_contact` | `minw(maxw(abs(collisions) >= 0.35 \|\| minw(abs(collisions) > 0.001, 0.1), 0.15), 0.3) ? valid(hold(sign(collisions), abs(collisions) > 0.001), 0) : 0` | Scraping along a wall, +1 right, -1 left, 0 otherwise: on after 0.3 s of steady contact (hits under 0.15 s apart, or 0.2 held). Single hits show on impact instead. Checked on WMMT5DX+ (three walls, 29 October 2026). |
| `airborne` | `minw(in_race, 0.5) > 0 && maxw(spring, 0.05) < 0.01 && maxw(abs(collisions) >= 0.35 \|\| minw(abs(collisions) > 0.001, 0.1), 0.5) == 0` | 1 while the game holds the centring spring at 0 with no hit or wall contact in the last 0.5 s. On WMMT5DX+ that happens whenever the car goes light: jumps, and crests even where the wheels stay down. The revs jump as the driven wheels lose grip, and a joint-sized kick often comes as it lands. Checked from video: one jump (29 October 2026) and six crests (1 November 2026: two with the rear wheels off the road, revs up 1260 to 1700; four with the wheels down, revs up about 800). |
| `grip_loss` | `clamp(abs(tire_slip) / 0.1, 0, 1)` | Sliding, 0 gripping to 1: tire_slip reaches about 0.1 in slides (WMMT5DX+). No direction. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed (speed x Max speed undoes the division, so this stays in G). Speed is in whole km/h, so this jitters by about 0.1 G when cruising. + speeding up, - slowing down. |
| `lampview1` | `band(ob_outputdata, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampinterruptionbutton` | `band(ob_outputdata, 4) != 0` | LampInterruptionButton output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampred` | `band(ob_outputdata2, 128) != 0` | LampRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampgreen` | `band(ob_outputdata2, 64) != 0` | LampGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampblue` | `band(ob_outputdata2, 32) != 0` | LampBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampwhite` | `ob_outputdata2 >= 224 ? 1 : 0` | LampWhite output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampside` | `band(ob_outputdata2, 16) != 0` | LampSide output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_in_race` (not exported) | `in_race != 0` | Common value Car_in_race: 1 while racing. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (checked on WMMT5DX+). Car_speed_mph is this / 1.609344. |
| `car_race_time` (not exported) | `race_time` | Common value Car_race_time: the race clock (TT), seconds. |
| `car_impact` (not exported) | `clamp(abs(impact) / 0.8, 0, 1)` | Common value Car_impact: hits, 0 to 1: an ordinary hit (0.5) reads about 0.6, a big crash 1. |
| `car_impact_side` (not exported) | `sign(impact_side)` | Common value Car_impact_side: side of the hit, -1 left, 1 right. |
| `car_wall_contact` (not exported) | `wall_contact` | Common value Car_wall_contact: scraping a wall, -1 left, 1 right. |
| `car_road_bump` (not exported) | `clamp(road_joint / 0.3, 0, 1)` | Common value Car_road_bump: expansion joints and bumps, 0 to 1. |
| `car_rumble_strip` (not exported) | `rumble_strip` | Common value Car_rumble_strip: 1 on a ripple strip. |
| `car_grip_loss` (not exported) | `grip_loss` | Common value Car_grip_loss: sliding, 0 to 1. |
| `car_cornering` (not exported) | `clamp(-tire_slip / 0.1, -1, 1)` | Common value Car_cornering: cornering from tyre slip, + turning right. Approximate: WMMT5/6 send no cornering force. |
| `car_airborne` (not exported) | `airborne` | Common value Car_airborne: 1 in the air (a guess so far). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_action` (not exported) | `lampinterruptionbutton` | Common lamp Lamp_action: the cabinet's extra button (the game's `lampinterruptionbutton`). |
| `lamp_red` (not exported) | `lampred` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_green` (not exported) | `lampgreen` | Common lamp Lamp_green: the cabinet's green lamp (`lampgreen`). |
| `lamp_blue` (not exported) | `lampblue` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |
| `lamp_white` (not exported) | `lampwhite` | Common lamp Lamp_white: the cabinet's white lamp (`lampwhite`). |
| `lamp_marquee` (not exported) | `lampside` | Common lamp Lamp_marquee: cabinet lighting (`lampside`). |

<a id="wmmt5dxp"></a>
## Wangan Midnight Maximum Tune 5DX+

Prefix `WMMT5DXP` (properties `TPTelemetry.WMMT5DXP_<row>`), process `wmn5r.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speed, km/h, in whole numbers. From the FFB Arcade Plugin's reading of this game; checked in recordings (29 October and 1 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `speed2` | memory read, then `abs(value) * 0.0036 / max_speed` | Speed, km/h, to a fraction of a km/h: the game stores it in mm per second (the script multiplies by 0.0036). The speed row is the same speed in whole km/h (the speedo): this reads about 0.5 km/h above it and updates 60 times a second where the whole number changes only when it passes the next km/h. Feeds the common values (Car_speed, and Car_accel_g through accel_g). Divided by Max speed. From MasterRaver's Outputs script (a Cheat Engine script Alexis supplied, 2 November 2026); the pointer at wmn5r.exe+1FD11B0 is the one the checked gear row uses. Checked in Alexis's recording of 3 November 2026 (10:13). |
| `rpm` | memory read, then `value / max_revs` | Engine RPM. The limiter is soft and depends on the car: revs creep up to about 8250 on one WMMT5DX+ car and 8500 on another. Before the race starts it can read nonsense (99999 seen). From the FFB Arcade Plugin's reading of this game; checked in recordings (29 October and 1 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). |
| `rpm2` | memory read, then `value < 0 ? 0 : value / max_revs` | Engine RPM as a float. Not the same scale as the rpm row: it moves with rpm (same moments) but swings further, about 1.285 x rpm - 1920 (rpm2 8700 at the limiter in 2nd where rpm reads 8270; 4700 where rpm reads 5150). Feeds the common values (Car_rpm) since 3 November 2026 (Alexis's choice); the rpm row stays. Max revs 8900 suits this row: the limiter in 2nd, about 8700, is 97.8% of it. Divided by Max revs. From MasterRaver's Outputs script (a Cheat Engine script Alexis supplied, 2 November 2026); the pointer at wmn5r.exe+1FD11B0 is the one the checked gear row uses. Checked in Alexis's recording of 3 November 2026 (10:13). |
| `in_race` | `valid(race_time2, race_time) > 0 && maxw(delta(valid(race_time2, race_time)) > 0, 0.1)` | 1 while the race clock is running: off before the start, after the finish line (results screen) and while the game is frozen. Uses race_time2, or race_time when race_time2 can't be read (the two read the same in the 3 November 2026 recording). Checked on WMMT5DX+ with race_time (1 November 2026). |
| `road_joint` | `abs(collisions) > 0.001 && abs(collisions) < 0.35 && maxw(abs(collisions) >= 0.35, 0.25) == 0 && minw(abs(collisions) > 0.001, 0.1) == 0 ? abs(collisions) : 0` | Expansion joints and ripple strips, 0 to about 0.3, no direction: the game sends each as a kick under 0.1 s long, one per axle (front then rear, closer together the faster you go). Kicks just after a hit, or held 0.1 s or more, are wall contact instead. On WMMT5DX+ 0.21 from walking pace to 100 km/h, 0.31 at 240; caught at 15, 40, 60 and 80 km/h (1 November 2026). |
| `rumble_strip` | `maxw(avg(maxw(road_joint > 0, 0.07), 0.45) > 0.85, 0.3)` | 1 on a ripple strip: the game kicks every 0.07 to 0.13 s for as long as you are on it, where a joint is one kick per axle (two joints close together make 3 or 4). Needs about five kicks, so it comes on about 0.4 s into a strip (as a short strip ends) and stays on 0.3 s after. Checked on WMMT5DX+: long strips at 100 to 240 km/h, five short ones (5 or 6 kicks) and one crossed in a slide, confirmed from video (1 November 2026); on and off while drifting across one. |
| `impact` | `abs(collisions) >= 0.35 ? clamp(collisions, -1, 1) : 0` | Hits, -1 to 1: the game sends 0.5 for most hits and more in a big crash (0.78 seen). Sliding along a wall gives a run of 0.5 kicks. + = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, a left-hand wall hit -0.5). |
| `impact_side` | `maxw(impact, 0.3) + minw(impact, 0.3)` | Hit held for 0.3 s so SimHub sees it, -1 to 1. + = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, a left-hand wall hit -0.5). |
| `wall_contact` | `minw(maxw(abs(collisions) >= 0.35 \|\| minw(abs(collisions) > 0.001, 0.1), 0.15), 0.3) ? valid(hold(sign(collisions), abs(collisions) > 0.001), 0) : 0` | Scraping along a wall, +1 right, -1 left, 0 otherwise: on after 0.3 s of steady contact (hits under 0.15 s apart, or 0.2 held). Single hits show on impact instead. Checked on WMMT5DX+ (three walls, 29 October 2026). |
| `airborne` | `minw(in_race, 0.5) > 0 && maxw(spring, 0.05) < 0.01 && maxw(abs(collisions) >= 0.35 \|\| minw(abs(collisions) > 0.001, 0.1), 0.5) == 0` | 1 while the game holds the centring spring at 0 with no hit or wall contact in the last 0.5 s. On WMMT5DX+ that happens whenever the car goes light: jumps, and crests even where the wheels stay down. The revs jump as the driven wheels lose grip, and a joint-sized kick often comes as it lands. Checked from video: one jump (29 October 2026) and six crests (1 November 2026: two with the rear wheels off the road, revs up 1260 to 1700; four with the wheels down, revs up about 800). |
| `grip_loss` | `clamp(abs(tire_slip) / 0.1, 0, 1)` | Sliding, 0 gripping to 1: tire_slip reaches about 0.1 in slides (WMMT5DX+). No direction. |
| `accel_g` | `ema(slope(valid(speed2, speed) * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed2 (km/h to a fraction, 60 times a second), or from the speed row when speed2 can't be read; speed x Max speed undoes the division, so this stays in G. In the 3 November 2026 recording it jittered about 0.07 G when accelerating steadily, against 0.1 G from the whole-km/h speed row. + speeding up, - slowing down. |
| `lampview1` | `band(ob_outputdata, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampinterruptionbutton` | `band(ob_outputdata, 4) != 0` | LampInterruptionButton output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampred` | `band(ob_outputdata2, 128) != 0` | LampRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampgreen` | `band(ob_outputdata2, 64) != 0` | LampGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampblue` | `band(ob_outputdata2, 32) != 0` | LampBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampwhite` | `ob_outputdata2 >= 224 ? 1 : 0` | LampWhite output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampside` | `band(ob_outputdata2, 16) != 0` | LampSide output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `throttle` | `clamp(max(band(pedals_a, 255), band(pedals_b, 255)) / 85, 0, 1)` | Throttle, 0 to 1 (the game reads 0 to 85). Matched the G25's throttle over USB. From MasterRaver's Outputs script (a Cheat Engine script Alexis supplied, 2 November 2026); the pointer at wmn5r.exe+1FD11B0 is the one the checked gear row uses. Checked in Alexis's recording of 3 November 2026 (10:13). |
| `brake` | `clamp(max(bits(pedals_a, 16, 8), bits(pedals_b, 16, 8)) / 85, 0, 1)` | Brake, 0 to 1 (the game reads 0 to 85). From MasterRaver's Outputs script (a Cheat Engine script Alexis supplied, 2 November 2026); the pointer at wmn5r.exe+1FD11B0 is the one the checked gear row uses. Not yet checked in a recording. |
| `distance` | `max((progress - start_ref) / 1000, 0)` | Distance from the start line, metres: grew 1895 m in the recording, where the speed gives 1899 m. From MasterRaver's Outputs script (a Cheat Engine script Alexis supplied, 2 November 2026); the pointer at wmn5r.exe+1FD11B0 is the one the checked gear row uses. Checked in Alexis's recording of 3 November 2026 (10:13). |
| `place` | `order1 == 0 ? 1 : (order2 == 0 ? 2 : (order3 == 0 ? 3 : (order4 == 0 ? 4 : 0)))` | Race position, 1 to 4 (0 if the player isn't in the order). Outside a race the order may read all 0, which gives 1. Read 1 throughout the 3 November 2026 recording (order 0, 1, 2, 3): still to be checked in a race with rivals. From MasterRaver's Outputs script (a Cheat Engine script Alexis supplied, 2 November 2026); the pointer at wmn5r.exe+1FD11B0 is the one the checked gear row uses. Not yet checked in a recording. |
| `car_in_race` (not exported) | `in_race != 0` | Common value Car_in_race: 1 while racing. |
| `car_speed` (not exported) | `valid(speed2, speed) * max_speed` | Common value Car_speed: speed in km/h, raw, from speed2 (to a fraction, 60 times a second), or the speed row when speed2 can't be read. |
| `car_rpm` (not exported) | `valid(rpm2, rpm) * max_revs` | Common value Car_rpm: engine RPM, raw, from rpm2, or the rpm row when rpm2 can't be read. |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_speed_kmh` (not exported) | `valid(speed2, speed) * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (checked). Car_speed_mph is this / 1.609344. |
| `car_position` (not exported) | `in_race ? place : 0` | Common value Car_position: race position, 1 to 4, while racing (the place row reads 1 outside a race). |
| `car_race_time` (not exported) | `valid(race_time2, race_time)` | Common value Car_race_time: the race clock (TT), seconds. |
| `car_brake` (not exported) | `brake` | Common value Car_brake: brake pedal, 0 to 1, as the game uses it. |
| `car_impact` (not exported) | `abs(impact) > 0 ? clamp(max(abs(impact) / 0.8, 0.5 + (maxw(valid(speed2, speed) * max_speed, 0.3) - valid(speed2, speed) * max_speed) / 120), 0, 1) : 0` | Common value Car_impact: hits, 0 to 1: the game's hit (0.5 reads about 0.6), or more by the km/h lost in the last 0.3 s (0.5 + loss / 120: 68 km/h lost reads 1), whichever is bigger. |
| `car_impact_side` (not exported) | `sign(impact_side)` | Common value Car_impact_side: side of the hit, -1 left, 1 right. |
| `car_wall_contact` (not exported) | `wall_contact` | Common value Car_wall_contact: scraping a wall, -1 left, 1 right. |
| `car_road_bump` (not exported) | `clamp(road_joint / 0.3, 0, 1)` | Common value Car_road_bump: expansion joints and bumps, 0 to 1. |
| `car_rumble_strip` (not exported) | `rumble_strip` | Common value Car_rumble_strip: 1 on a ripple strip. |
| `car_grip_loss` (not exported) | `grip_loss` | Common value Car_grip_loss: sliding, 0 to 1. |
| `car_cornering` (not exported) | `clamp(-tire_slip / 0.1, -1, 1)` | Common value Car_cornering: cornering from tyre slip, + turning right. Approximate: WMMT5/6 send no cornering force. |
| `car_airborne` (not exported) | `airborne` | Common value Car_airborne: 1 in the air (a guess so far). |
| `car_boost` (not exported) | `clamp(turbo / 1.5, 0, 1)` | Common value Car_boost: turbo boost, 0 to 1: the gauge reads 1.5 at full boost (1), dips at each upshift and drops below 0 off the throttle (0). |
| `car_throttle` (not exported) | `throttle` | Common value Car_throttle: throttle pedal, 0 to 1 (checked against the G25 over USB): the engine effects run at 60% off the throttle, full at full throttle. |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_action` (not exported) | `lampinterruptionbutton` | Common lamp Lamp_action: the cabinet's extra button (the game's `lampinterruptionbutton`). |
| `lamp_red` (not exported) | `lampred` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_green` (not exported) | `lampgreen` | Common lamp Lamp_green: the cabinet's green lamp (`lampgreen`). |
| `lamp_blue` (not exported) | `lampblue` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |
| `lamp_white` (not exported) | `lampwhite` | Common lamp Lamp_white: the cabinet's white lamp (`lampwhite`). |
| `lamp_marquee` (not exported) | `lampside` | Common lamp Lamp_marquee: cabinet lighting (`lampside`). |

<a id="wmmt6"></a>
## Wangan Midnight Maximum Tune 6

Prefix `WMMT6` (properties `TPTelemetry.WMMT6_<row>`), process `wmn6r.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speed, km/h, in whole numbers. Unverified: from the FFB Arcade Plugin's reading of this game. The same value was checked on WMMT5DX+ (29 October and 1 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `rpm` | memory read, then `value / max_revs` | Engine RPM. The limiter is soft and depends on the car: revs creep up to about 8250 on one WMMT5DX+ car and 8500 on another. Before the race starts it can read nonsense (99999 seen). Unverified: from the FFB Arcade Plugin's reading of this game. The same value was checked on WMMT5DX+ (29 October and 1 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). |
| `in_race` | `race_time > 0 && maxw(delta(race_time) > 0, 0.1)` | 1 while the race clock is running: off before the start, after the finish line (results screen) and while the game is frozen. Checked on WMMT5DX+ (1 November 2026). |
| `road_joint` | `abs(collisions) > 0.001 && abs(collisions) < 0.35 && maxw(abs(collisions) >= 0.35, 0.25) == 0 && minw(abs(collisions) > 0.001, 0.1) == 0 ? abs(collisions) : 0` | Expansion joints and ripple strips, 0 to about 0.3, no direction: the game sends each as a kick under 0.1 s long, one per axle (front then rear, closer together the faster you go). Kicks just after a hit, or held 0.1 s or more, are wall contact instead. On WMMT5DX+ 0.21 from walking pace to 100 km/h, 0.31 at 240; caught at 15, 40, 60 and 80 km/h (1 November 2026). |
| `rumble_strip` | `maxw(avg(maxw(road_joint > 0, 0.07), 0.45) > 0.85, 0.3)` | 1 on a ripple strip: the game kicks every 0.07 to 0.13 s for as long as you are on it, where a joint is one kick per axle (two joints close together make 3 or 4). Needs about five kicks, so it comes on about 0.4 s into a strip (as a short strip ends) and stays on 0.3 s after. Checked on WMMT5DX+: long strips at 100 to 240 km/h, five short ones (5 or 6 kicks) and one crossed in a slide, confirmed from video (1 November 2026); on and off while drifting across one. |
| `impact` | `abs(collisions) >= 0.35 ? clamp(collisions, -1, 1) : 0` | Hits, -1 to 1: the game sends 0.5 for most hits and more in a big crash (0.78 seen). Sliding along a wall gives a run of 0.5 kicks. + = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, a left-hand wall hit -0.5). |
| `impact_side` | `maxw(impact, 0.3) + minw(impact, 0.3)` | Hit held for 0.3 s so SimHub sees it, -1 to 1. + = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, a left-hand wall hit -0.5). |
| `wall_contact` | `minw(maxw(abs(collisions) >= 0.35 \|\| minw(abs(collisions) > 0.001, 0.1), 0.15), 0.3) ? valid(hold(sign(collisions), abs(collisions) > 0.001), 0) : 0` | Scraping along a wall, +1 right, -1 left, 0 otherwise: on after 0.3 s of steady contact (hits under 0.15 s apart, or 0.2 held). Single hits show on impact instead. Checked on WMMT5DX+ (three walls, 29 October 2026). |
| `airborne` | `minw(in_race, 0.5) > 0 && maxw(spring, 0.05) < 0.01 && maxw(abs(collisions) >= 0.35 \|\| minw(abs(collisions) > 0.001, 0.1), 0.5) == 0` | 1 while the game holds the centring spring at 0 with no hit or wall contact in the last 0.5 s. On WMMT5DX+ that happens whenever the car goes light: jumps, and crests even where the wheels stay down. The revs jump as the driven wheels lose grip, and a joint-sized kick often comes as it lands. Checked from video: one jump (29 October 2026) and six crests (1 November 2026: two with the rear wheels off the road, revs up 1260 to 1700; four with the wheels down, revs up about 800). |
| `grip_loss` | `clamp(abs(tire_slip) / 0.1, 0, 1)` | Sliding, 0 gripping to 1: tire_slip reaches about 0.1 in slides (WMMT5DX+). No direction. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed (speed x Max speed undoes the division, so this stays in G). Speed is in whole km/h, so this jitters by about 0.1 G when cruising. + speeding up, - slowing down. |
| `lampview1` | `band(ob_outputdata, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampinterruptionbutton` | `band(ob_outputdata, 4) != 0` | LampInterruptionButton output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampred` | `band(ob_outputdata2, 128) != 0` | LampRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampgreen` | `band(ob_outputdata2, 64) != 0` | LampGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampblue` | `band(ob_outputdata2, 32) != 0` | LampBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampwhite` | `ob_outputdata2 >= 224 ? 1 : 0` | LampWhite output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampside` | `band(ob_outputdata2, 16) != 0` | LampSide output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_in_race` (not exported) | `in_race != 0` | Common value Car_in_race: 1 while racing. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (as WMMT5DX+; not yet checked). Car_speed_mph is this / 1.609344. |
| `car_race_time` (not exported) | `race_time` | Common value Car_race_time: the race clock (TT), seconds. |
| `car_impact` (not exported) | `clamp(abs(impact) / 0.8, 0, 1)` | Common value Car_impact: hits, 0 to 1: an ordinary hit (0.5) reads about 0.6, a big crash 1. |
| `car_impact_side` (not exported) | `sign(impact_side)` | Common value Car_impact_side: side of the hit, -1 left, 1 right. |
| `car_wall_contact` (not exported) | `wall_contact` | Common value Car_wall_contact: scraping a wall, -1 left, 1 right. |
| `car_road_bump` (not exported) | `clamp(road_joint / 0.3, 0, 1)` | Common value Car_road_bump: expansion joints and bumps, 0 to 1. |
| `car_rumble_strip` (not exported) | `rumble_strip` | Common value Car_rumble_strip: 1 on a ripple strip. |
| `car_grip_loss` (not exported) | `grip_loss` | Common value Car_grip_loss: sliding, 0 to 1. |
| `car_cornering` (not exported) | `clamp(-tire_slip / 0.1, -1, 1)` | Common value Car_cornering: cornering from tyre slip, + turning right. Approximate: WMMT5/6 send no cornering force. |
| `car_airborne` (not exported) | `airborne` | Common value Car_airborne: 1 in the air (a guess so far). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_action` (not exported) | `lampinterruptionbutton` | Common lamp Lamp_action: the cabinet's extra button (the game's `lampinterruptionbutton`). |
| `lamp_red` (not exported) | `lampred` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_green` (not exported) | `lampgreen` | Common lamp Lamp_green: the cabinet's green lamp (`lampgreen`). |
| `lamp_blue` (not exported) | `lampblue` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |
| `lamp_white` (not exported) | `lampwhite` | Common lamp Lamp_white: the cabinet's white lamp (`lampwhite`). |
| `lamp_marquee` (not exported) | `lampside` | Common lamp Lamp_marquee: cabinet lighting (`lampside`). |

<a id="wmmt6r"></a>
## Wangan Midnight Maximum Tune 6R

Prefix `WMMT6R` (properties `TPTelemetry.WMMT6R_<row>`), process `wmn6r.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speed, km/h, in whole numbers. Unverified: from the FFB Arcade Plugin's reading of this game. The same value was checked on WMMT5DX+ (29 October and 1 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `speed2` | memory read, then `value / max_speed` | Speed, km/h. From MasterRaver's TeknoParrot cheat table (04.10.26 pack). Not yet checked in a recording. The 6R table lists the same speed and RPM addresses as the 6RR table, so these may belong to 6RR only. Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `rpm` | memory read, then `value / max_revs` | Engine RPM. The limiter is soft and depends on the car: revs creep up to about 8250 on one WMMT5DX+ car and 8500 on another. Before the race starts it can read nonsense (99999 seen). Unverified: from the FFB Arcade Plugin's reading of this game. The same value was checked on WMMT5DX+ (29 October and 1 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). |
| `rpm2` | memory read, then `value / max_revs` | Engine RPM, from the game's Wg6Enma DLL. From MasterRaver's TeknoParrot cheat table (04.10.26 pack). Not yet checked in a recording. The 6R table lists the same speed and RPM addresses as the 6RR table, so these may belong to 6RR only. Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). |
| `in_race` | `race_time > 0 && maxw(delta(race_time) > 0, 0.1)` | 1 while the race clock is running: off before the start, after the finish line (results screen) and while the game is frozen. Checked on WMMT5DX+ (1 November 2026). |
| `road_joint` | `abs(collisions) > 0.001 && abs(collisions) < 0.35 && maxw(abs(collisions) >= 0.35, 0.25) == 0 && minw(abs(collisions) > 0.001, 0.1) == 0 ? abs(collisions) : 0` | Expansion joints and ripple strips, 0 to about 0.3, no direction: the game sends each as a kick under 0.1 s long, one per axle (front then rear, closer together the faster you go). Kicks just after a hit, or held 0.1 s or more, are wall contact instead. On WMMT5DX+ 0.21 from walking pace to 100 km/h, 0.31 at 240; caught at 15, 40, 60 and 80 km/h (1 November 2026). |
| `rumble_strip` | `maxw(avg(maxw(road_joint > 0, 0.07), 0.45) > 0.85, 0.3)` | 1 on a ripple strip: the game kicks every 0.07 to 0.13 s for as long as you are on it, where a joint is one kick per axle (two joints close together make 3 or 4). Needs about five kicks, so it comes on about 0.4 s into a strip (as a short strip ends) and stays on 0.3 s after. Checked on WMMT5DX+: long strips at 100 to 240 km/h, five short ones (5 or 6 kicks) and one crossed in a slide, confirmed from video (1 November 2026); on and off while drifting across one. |
| `impact` | `abs(collisions) >= 0.35 ? clamp(collisions, -1, 1) : 0` | Hits, -1 to 1: the game sends 0.5 for most hits and more in a big crash (0.78 seen). Sliding along a wall gives a run of 0.5 kicks. + = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, a left-hand wall hit -0.5). |
| `impact_side` | `maxw(impact, 0.3) + minw(impact, 0.3)` | Hit held for 0.3 s so SimHub sees it, -1 to 1. + = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, a left-hand wall hit -0.5). |
| `wall_contact` | `minw(maxw(abs(collisions) >= 0.35 \|\| minw(abs(collisions) > 0.001, 0.1), 0.15), 0.3) ? valid(hold(sign(collisions), abs(collisions) > 0.001), 0) : 0` | Scraping along a wall, +1 right, -1 left, 0 otherwise: on after 0.3 s of steady contact (hits under 0.15 s apart, or 0.2 held). Single hits show on impact instead. Checked on WMMT5DX+ (three walls, 29 October 2026). |
| `airborne` | `minw(in_race, 0.5) > 0 && maxw(spring, 0.05) < 0.01 && maxw(abs(collisions) >= 0.35 \|\| minw(abs(collisions) > 0.001, 0.1), 0.5) == 0` | 1 while the game holds the centring spring at 0 with no hit or wall contact in the last 0.5 s. On WMMT5DX+ that happens whenever the car goes light: jumps, and crests even where the wheels stay down. The revs jump as the driven wheels lose grip, and a joint-sized kick often comes as it lands. Checked from video: one jump (29 October 2026) and six crests (1 November 2026: two with the rear wheels off the road, revs up 1260 to 1700; four with the wheels down, revs up about 800). |
| `grip_loss` | `clamp(abs(tire_slip) / 0.1, 0, 1)` | Sliding, 0 gripping to 1: tire_slip reaches about 0.1 in slides (WMMT5DX+). No direction. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed (speed x Max speed undoes the division, so this stays in G). Speed is in whole km/h, so this jitters by about 0.1 G when cruising. + speeding up, - slowing down. |
| `lampview1` | `band(ob_outputdata, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampinterruptionbutton` | `band(ob_outputdata, 4) != 0` | LampInterruptionButton output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampred` | `band(ob_outputdata2, 128) != 0` | LampRed output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampgreen` | `band(ob_outputdata2, 64) != 0` | LampGreen output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampblue` | `band(ob_outputdata2, 32) != 0` | LampBlue output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampwhite` | `ob_outputdata2 >= 224 ? 1 : 0` | LampWhite output, the value OutputBlaster sends. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampside` | `band(ob_outputdata2, 16) != 0` | LampSide output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_in_race` (not exported) | `in_race != 0` | Common value Car_in_race: 1 while racing. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (as WMMT5DX+; not yet checked). Car_speed_mph is this / 1.609344. |
| `car_race_time` (not exported) | `race_time` | Common value Car_race_time: the race clock (TT), seconds. |
| `car_impact` (not exported) | `clamp(abs(impact) / 0.8, 0, 1)` | Common value Car_impact: hits, 0 to 1: an ordinary hit (0.5) reads about 0.6, a big crash 1. |
| `car_impact_side` (not exported) | `sign(impact_side)` | Common value Car_impact_side: side of the hit, -1 left, 1 right. |
| `car_wall_contact` (not exported) | `wall_contact` | Common value Car_wall_contact: scraping a wall, -1 left, 1 right. |
| `car_road_bump` (not exported) | `clamp(road_joint / 0.3, 0, 1)` | Common value Car_road_bump: expansion joints and bumps, 0 to 1. |
| `car_rumble_strip` (not exported) | `rumble_strip` | Common value Car_rumble_strip: 1 on a ripple strip. |
| `car_grip_loss` (not exported) | `grip_loss` | Common value Car_grip_loss: sliding, 0 to 1. |
| `car_cornering` (not exported) | `clamp(-tire_slip / 0.1, -1, 1)` | Common value Car_cornering: cornering from tyre slip, + turning right. Approximate: WMMT5/6 send no cornering force. |
| `car_airborne` (not exported) | `airborne` | Common value Car_airborne: 1 in the air (a guess so far). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_action` (not exported) | `lampinterruptionbutton` | Common lamp Lamp_action: the cabinet's extra button (the game's `lampinterruptionbutton`). |
| `lamp_red` (not exported) | `lampred` | Common lamp Lamp_red: the cabinet's red lamp (`lampred`). |
| `lamp_green` (not exported) | `lampgreen` | Common lamp Lamp_green: the cabinet's green lamp (`lampgreen`). |
| `lamp_blue` (not exported) | `lampblue` | Common lamp Lamp_blue: the cabinet's blue lamp (`lampblue`). |
| `lamp_white` (not exported) | `lampwhite` | Common lamp Lamp_white: the cabinet's white lamp (`lampwhite`). |
| `lamp_marquee` (not exported) | `lampside` | Common lamp Lamp_marquee: cabinet lighting (`lampside`). |

<a id="wmmt6rr"></a>
## Wangan Midnight Maximum Tune 6RR

Prefix `WMMT6RR` (properties `TPTelemetry.WMMT6RR_<row>`), process `wmn6r.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speed, km/h, in whole numbers. Unverified: from the FFB Arcade Plugin's reading of this game. The same value was checked on WMMT5DX+ (29 October and 1 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). The same address is in MasterRaver's TeknoParrot cheat table (04.10.26 pack). |
| `rpm` | memory read, then `value / max_revs` | Engine RPM. The limiter is soft and depends on the car: revs creep up to about 8250 on one WMMT5DX+ car and 8500 on another. Before the race starts it can read nonsense (99999 seen). Unverified: from the FFB Arcade Plugin's reading of this game. The same value was checked on WMMT5DX+ (29 October and 1 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). |
| `rpm2` | memory read, then `value / max_revs` | Engine RPM, from the game's Wg6Enma DLL. From MasterRaver's TeknoParrot cheat table (04.10.26 pack). Not yet checked in a recording. Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). |
| `in_race` | `race_time > 0 && maxw(delta(race_time) > 0, 0.1)` | 1 while the race clock is running: off before the start, after the finish line (results screen) and while the game is frozen. Checked on WMMT5DX+ (1 November 2026). |
| `road_joint` | `abs(collisions) > 0.001 && abs(collisions) < 0.35 && maxw(abs(collisions) >= 0.35, 0.25) == 0 && minw(abs(collisions) > 0.001, 0.1) == 0 ? abs(collisions) : 0` | Expansion joints and ripple strips, 0 to about 0.3, no direction: the game sends each as a kick under 0.1 s long, one per axle (front then rear, closer together the faster you go). Kicks just after a hit, or held 0.1 s or more, are wall contact instead. On WMMT5DX+ 0.21 from walking pace to 100 km/h, 0.31 at 240; caught at 15, 40, 60 and 80 km/h (1 November 2026). |
| `rumble_strip` | `maxw(avg(maxw(road_joint > 0, 0.07), 0.45) > 0.85, 0.3)` | 1 on a ripple strip: the game kicks every 0.07 to 0.13 s for as long as you are on it, where a joint is one kick per axle (two joints close together make 3 or 4). Needs about five kicks, so it comes on about 0.4 s into a strip (as a short strip ends) and stays on 0.3 s after. Checked on WMMT5DX+: long strips at 100 to 240 km/h, five short ones (5 or 6 kicks) and one crossed in a slide, confirmed from video (1 November 2026); on and off while drifting across one. |
| `impact` | `abs(collisions) >= 0.35 ? clamp(collisions, -1, 1) : 0` | Hits, -1 to 1: the game sends 0.5 for most hits and more in a big crash (0.78 seen). Sliding along a wall gives a run of 0.5 kicks. + = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, a left-hand wall hit -0.5). |
| `impact_side` | `maxw(impact, 0.3) + minw(impact, 0.3)` | Hit held for 0.3 s so SimHub sees it, -1 to 1. + = a hit on the right, - on the left: checked on WMMT5DX+ (right-hand wall hits read +0.5, a left-hand wall hit -0.5). |
| `wall_contact` | `minw(maxw(abs(collisions) >= 0.35 \|\| minw(abs(collisions) > 0.001, 0.1), 0.15), 0.3) ? valid(hold(sign(collisions), abs(collisions) > 0.001), 0) : 0` | Scraping along a wall, +1 right, -1 left, 0 otherwise: on after 0.3 s of steady contact (hits under 0.15 s apart, or 0.2 held). Single hits show on impact instead. Checked on WMMT5DX+ (three walls, 29 October 2026). |
| `airborne` | `minw(in_race, 0.5) > 0 && maxw(spring, 0.05) < 0.01 && maxw(abs(collisions) >= 0.35 \|\| minw(abs(collisions) > 0.001, 0.1), 0.5) == 0` | 1 while the game holds the centring spring at 0 with no hit or wall contact in the last 0.5 s. On WMMT5DX+ that happens whenever the car goes light: jumps, and crests even where the wheels stay down. The revs jump as the driven wheels lose grip, and a joint-sized kick often comes as it lands. Checked from video: one jump (29 October 2026) and six crests (1 November 2026: two with the rear wheels off the road, revs up 1260 to 1700; four with the wheels down, revs up about 800). |
| `grip_loss` | `clamp(abs(tire_slip) / 0.1, 0, 1)` | Sliding, 0 gripping to 1: tire_slip reaches about 0.1 in slides (WMMT5DX+). No direction. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed (speed x Max speed undoes the division, so this stays in G). Speed is in whole km/h, so this jitters by about 0.1 G when cruising. + speeding up, - slowing down. |
| `car_in_race` (not exported) | `in_race != 0` | Common value Car_in_race: 1 while racing. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_accel_g` (not exported) | `accel_g` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (as WMMT5DX+; not yet checked). Car_speed_mph is this / 1.609344. |
| `car_race_time` (not exported) | `race_time` | Common value Car_race_time: the race clock (TT), seconds. |
| `car_impact` (not exported) | `clamp(abs(impact) / 0.8, 0, 1)` | Common value Car_impact: hits, 0 to 1: an ordinary hit (0.5) reads about 0.6, a big crash 1. |
| `car_impact_side` (not exported) | `sign(impact_side)` | Common value Car_impact_side: side of the hit, -1 left, 1 right. |
| `car_wall_contact` (not exported) | `wall_contact` | Common value Car_wall_contact: scraping a wall, -1 left, 1 right. |
| `car_road_bump` (not exported) | `clamp(road_joint / 0.3, 0, 1)` | Common value Car_road_bump: expansion joints and bumps, 0 to 1. |
| `car_rumble_strip` (not exported) | `rumble_strip` | Common value Car_rumble_strip: 1 on a ripple strip. |
| `car_grip_loss` (not exported) | `grip_loss` | Common value Car_grip_loss: sliding, 0 to 1. |
| `car_cornering` (not exported) | `clamp(-tire_slip / 0.1, -1, 1)` | Common value Car_cornering: cornering from tyre slip, + turning right. Approximate: WMMT5/6 send no cornering force. |
| `car_airborne` (not exported) | `airborne` | Common value Car_airborne: 1 in the air (a guess so far). |

<a id="wmmt6rrp"></a>
## Wangan Midnight Maximum Tune 6RR Plus v4.00.13

Prefix `WMMT6RRP` (properties `TPTelemetry.WMMT6RRP_<row>`), process `wmn6r.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |

<a id="snocross"></a>
## Winter X Games SnoCross

Prefix `SNOCROSS` (properties `TPTelemetry.SNOCROSS_<row>`), process `sdaemon.exe`, folder `Teknoparrot`.

| Row | Formula | What it does |
|---|---|---|
| `force` | memory read, then `clamp(value / 1.2401, -1, 1)` | Decoded force, -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). Raw: Force the game asks for (absolute address). Unverified: from the FFB Arcade Plugin's reading of this game. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="fly18wheeler"></a>
## 18 Wheeler: American Pro Trucker (Flycast)

Prefix `FLY18WHEELER` (properties `TPTelemetry.FLY18WHEELER_<row>`), process `(none: reads no game memory)`, folder `Flycast`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_m3ffb, 0)` | The motor board command the game sends. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `force` | `valid(hold(clamp((ffb_cmd > 80 && ffb_cmd < 96) ? -(ffb_cmd - 80) / 15 : ((ffb_cmd > 96 && ffb_cmd < 112) ? (ffb_cmd - 96) / 15 : ((ffb_cmd > 128 && ffb_cmd < 144) ? (ffb_cmd - 128) / 15 : ((ffb_cmd > 144 && ffb_cmd < 160) ? -(ffb_cmd - 144) / 15 : ((ffb_cmd > 160 && ffb_cmd < 176) ? -(ffb_cmd - 160) / 15 : (ffb_cmd == 191 ? 1 : ((ffb_cmd > 224 && ffb_cmd < 233) ? -(ffb_cmd - 224) / 8 : ((ffb_cmd > 232 && ffb_cmd < 240) ? (ffb_cmd - 232) / 8 : 0))))))), -1, 1), (ffb_cmd > 80 && ffb_cmd < 96) \|\| ((ffb_cmd > 96 && ffb_cmd < 112) && (ffb_cmd < 104 \|\| ffb_cmd > 107)) \|\| (ffb_cmd > 128 && ffb_cmd < 176) \|\| ffb_cmd == 191 \|\| (ffb_cmd > 224 && ffb_cmd < 240) \|\| ffb_cmd == 192), 0)` | Force, -1 to 1, kept until the next force command (0xC0 stops everything). |
| `spring` | `valid(hold((ffb_cmd > 16 && ffb_cmd < 32) ? clamp((ffb_cmd - 10) / 15, 0, 1) : ((ffb_cmd > 64 && ffb_cmd < 80) ? (ffb_cmd - 64) / 15 : ((ffb_cmd > 192 && ffb_cmd < 208) ? (ffb_cmd - 192) / 15 : 0)), (ffb_cmd > 16 && ffb_cmd < 32) \|\| (ffb_cmd > 64 && ffb_cmd < 80) \|\| (ffb_cmd > 192 && ffb_cmd < 208) \|\| ffb_cmd == 192), 0)` | Centring spring, 0 to 1, kept until changed. |
| `friction` | `valid(hold((ffb_cmd > 32 && ffb_cmd < 48) ? (ffb_cmd - 32) / 15 : ((ffb_cmd > 208 && ffb_cmd < 224) ? (ffb_cmd - 208) / 15 : 0), (ffb_cmd > 32 && ffb_cmd < 48) \|\| (ffb_cmd > 208 && ffb_cmd < 224) \|\| ffb_cmd == 192), 0)` | Friction, 0 to 1, kept until changed. |
| `vibration` | `(ffb_cmd > 48 && ffb_cmd < 64) ? (ffb_cmd - 48) / 15 : ((ffb_cmd > 176 && ffb_cmd < 192) ? (ffb_cmd - 176) / 15 : 0)` | Vibration, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="flyclubkart"></a>
## Club Kart (Flycast)

Prefix `FLYCLUBKART` (properties `TPTelemetry.FLYCLUBKART_<row>`), process `(none: reads no game memory)`, folder `Flycast`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_raw` | `valid(out_midiffb, 0)` | The MIDI force feedback message: byte 2 = command, byte 1 = direction or period, byte 0 = strength. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `ffb_cmd` | `byte(ffb_raw, 2)` | Command: 0x84 (132) force, 0x85 (133) vibration, 0x86 (134) spring, 0x80 (128) full spring. |
| `ffb_str` | `byte(ffb_raw, 0)` | Strength, 0 to 127. |
| `force` | `valid(hold(byte(ffb_raw, 1) == 0 ? -(128 - ffb_str) / 127 : ffb_str / 127, ffb_cmd == 132 && ffb_str > 0 && ffb_str < 128), 0)` | Force, -1 to 1, kept until the next force command (direction 0 from the left, 1 from the right). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 127 : 1, (ffb_cmd == 134 && ffb_str > 0 && ffb_str < 128) \|\| (ffb_cmd == 128 && ffb_str == 1)), 0)` | Centring spring, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && byte(ffb_raw, 1) > 0 ? ffb_str / 127 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="flyftspeed"></a>
## Faster Than Speed (Flycast)

Prefix `FLYFTSPEED` (properties `TPTelemetry.FLYFTSPEED_<row>`), process `(none: reads no game memory)`, folder `Flycast`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_awffb, 0)` | The Atomiswave wheel output: bit 0 = direction, bits 1 to 4 = strength. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `force` | `ffb_cmd > 0 ? (band(ffb_cmd, 1) ? -(ffb_cmd + 1) / 32 : ffb_cmd / 32) : 0` | Force, -1 to 1: odd values from the left, even from the right, as the FFB plugin's table decodes them. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="flyf355"></a>
## Ferrari F355 Challenge (Flycast)

Prefix `FLYF355` (properties `TPTelemetry.FLYF355_<row>`), process `(none: reads no game memory)`, folder `Flycast`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_m3ffb, 0)` | The motor board command the game sends. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `force` | `valid(hold(clamp((ffb_cmd > 80 && ffb_cmd < 96) ? -(ffb_cmd - 80) / 15 : ((ffb_cmd > 96 && ffb_cmd < 112) ? (ffb_cmd - 96) / 15 : ((ffb_cmd > 128 && ffb_cmd < 144) ? (ffb_cmd - 128) / 15 : ((ffb_cmd > 144 && ffb_cmd < 160) ? -(ffb_cmd - 144) / 15 : ((ffb_cmd > 160 && ffb_cmd < 176) ? -(ffb_cmd - 160) / 15 : (ffb_cmd == 191 ? 1 : ((ffb_cmd > 224 && ffb_cmd < 233) ? -(ffb_cmd - 224) / 8 : ((ffb_cmd > 232 && ffb_cmd < 240) ? (ffb_cmd - 232) / 8 : 0))))))), -1, 1), (ffb_cmd > 80 && ffb_cmd < 96) \|\| ((ffb_cmd > 96 && ffb_cmd < 112) && (ffb_cmd < 104 \|\| ffb_cmd > 107)) \|\| (ffb_cmd > 128 && ffb_cmd < 176) \|\| ffb_cmd == 191 \|\| (ffb_cmd > 224 && ffb_cmd < 240) \|\| ffb_cmd == 192), 0)` | Force, -1 to 1, kept until the next force command (0xC0 stops everything). |
| `spring` | `valid(hold((ffb_cmd > 16 && ffb_cmd < 32) ? clamp((ffb_cmd - 10) / 15, 0, 1) : ((ffb_cmd > 64 && ffb_cmd < 80) ? (ffb_cmd - 64) / 15 : ((ffb_cmd > 192 && ffb_cmd < 208) ? (ffb_cmd - 192) / 15 : 0)), (ffb_cmd > 16 && ffb_cmd < 32) \|\| (ffb_cmd > 64 && ffb_cmd < 80) \|\| (ffb_cmd > 192 && ffb_cmd < 208) \|\| ffb_cmd == 192), 0)` | Centring spring, 0 to 1, kept until changed. |
| `friction` | `valid(hold((ffb_cmd > 32 && ffb_cmd < 48) ? (ffb_cmd - 32) / 15 : ((ffb_cmd > 208 && ffb_cmd < 224) ? (ffb_cmd - 208) / 15 : 0), (ffb_cmd > 32 && ffb_cmd < 48) \|\| (ffb_cmd > 208 && ffb_cmd < 224) \|\| ffb_cmd == 192), 0)` | Friction, 0 to 1, kept until changed. |
| `vibration` | `(ffb_cmd > 48 && ffb_cmd < 64) ? (ffb_cmd - 48) / 15 : ((ffb_cmd > 176 && ffb_cmd < 192) ? (ffb_cmd - 176) / 15 : 0)` | Vibration, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="flyinitd"></a>
## Initial D Arcade Stage (Flycast)

Prefix `FLYINITD` (properties `TPTelemetry.FLYINITD_<row>`), process `(none: reads no game memory)`, folder `Flycast`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_raw` | `valid(out_midiffb, 0)` | The MIDI force feedback message: byte 2 = command, byte 1 = direction or period, byte 0 = strength. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `ffb_cmd` | `byte(ffb_raw, 2)` | Command: 0x84 (132) force, 0x85 (133) vibration, 0x86 (134) spring, 0x80 (128) full spring. |
| `ffb_str` | `byte(ffb_raw, 0)` | Strength, 0 to 127. |
| `force` | `valid(hold(byte(ffb_raw, 1) == 0 ? -(128 - ffb_str) / 127 : ffb_str / 127, ffb_cmd == 132 && ffb_str > 0 && ffb_str < 128), 0)` | Force, -1 to 1, kept until the next force command (direction 0 from the left, 1 from the right). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 127 : 1, (ffb_cmd == 134 && ffb_str > 0 && ffb_str < 128) \|\| (ffb_cmd == 128 && ffb_str == 1)), 0)` | Centring spring, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && byte(ffb_raw, 1) > 0 ? ffb_str / 127 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="flyinitd2"></a>
## Initial D Arcade Stage Ver. 2 (Flycast)

Prefix `FLYINITD2` (properties `TPTelemetry.FLYINITD2_<row>`), process `(none: reads no game memory)`, folder `Flycast`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_raw` | `valid(out_midiffb, 0)` | The MIDI force feedback message: byte 2 = command, byte 1 = direction or period, byte 0 = strength. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `ffb_cmd` | `byte(ffb_raw, 2)` | Command: 0x84 (132) force, 0x85 (133) vibration, 0x86 (134) spring, 0x80 (128) full spring. |
| `ffb_str` | `byte(ffb_raw, 0)` | Strength, 0 to 127. |
| `force` | `valid(hold(byte(ffb_raw, 1) == 0 ? -(128 - ffb_str) / 127 : ffb_str / 127, ffb_cmd == 132 && ffb_str > 0 && ffb_str < 128), 0)` | Force, -1 to 1, kept until the next force command (direction 0 from the left, 1 from the right). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 127 : 1, (ffb_cmd == 134 && ffb_str > 0 && ffb_str < 128) \|\| (ffb_cmd == 128 && ffb_str == 1)), 0)` | Centring spring, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && byte(ffb_raw, 1) > 0 ? ffb_str / 127 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="flyinitd3"></a>
## Initial D Arcade Stage Ver. 3 (Flycast)

Prefix `FLYINITD3` (properties `TPTelemetry.FLYINITD3_<row>`), process `flycast.exe`, folder `Flycast`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value * 3.6 / max_speed` | Speed: the car's forward speed in m/s x 3.6, which is the km/h the speedo shows (it shows the whole number below). Matched the HUD in two save states (174 km/h, 4th, 9,300 and 202 km/h, 5th, 8,650; 17 November 2026). Divided by Max speed (blank = 1, so km/h). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `rpm` | memory read, then `value / max_revs` | Engine revs, RPM, as the rev counter shows them. Matched the HUD in two save states (174 km/h, 4th, 9,300 and 202 km/h, 5th, 8,650; 17 November 2026). Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `ffb_raw` | `valid(out_midiffb, 0)` | The MIDI force feedback message: byte 2 = command, byte 1 = direction or period, byte 0 = strength. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `lamp0` | `valid(out_lamp0, 0)` | The cabinet's output bit 0 (0 or 1), as Flycast sends it. Which lamp it is still needs a recording. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `lamp1` | `valid(out_lamp1, 0)` | The cabinet's output bit 1 (0 or 1), as Flycast sends it. Which lamp it is still needs a recording. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `lamp2` | `valid(out_lamp2, 0)` | The cabinet's output bit 2 (0 or 1), as Flycast sends it. Which lamp it is still needs a recording. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `lamp3` | `valid(out_lamp3, 0)` | The cabinet's output bit 3 (0 or 1), as Flycast sends it. Which lamp it is still needs a recording. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `lamp4` | `valid(out_lamp4, 0)` | The cabinet's output bit 4 (0 or 1), as Flycast sends it. Which lamp it is still needs a recording. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `lamp5` | `valid(out_lamp5, 0)` | The cabinet's output bit 5 (0 or 1), as Flycast sends it. Which lamp it is still needs a recording. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `lamp6` | `valid(out_lamp6, 0)` | The cabinet's output bit 6 (0 or 1), as Flycast sends it. Which lamp it is still needs a recording. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `lamp7` | `valid(out_lamp7, 0)` | The cabinet's output bit 7 (0 or 1), as Flycast sends it. Which lamp it is still needs a recording. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `lamp_bits` | `valid(out_lamp0, 0) * 1 + valid(out_lamp1, 0) * 2 + valid(out_lamp2, 0) * 4 + valid(out_lamp3, 0) * 8 + valid(out_lamp4, 0) * 16 + valid(out_lamp5, 0) * 32 + valid(out_lamp6, 0) * 64 + valid(out_lamp7, 0) * 128 + valid(out_lamp8, 0) * 256 + valid(out_lamp9, 0) * 512 + valid(out_lamp10, 0) * 1024 + valid(out_lamp11, 0) * 2048 + valid(out_lamp12, 0) * 4096 + valid(out_lamp13, 0) * 8192 + valid(out_lamp14, 0) * 16384 + valid(out_lamp15, 0) * 32768` | Output bits 0 to 15 in one number (bit 0 = 1, bit 1 = 2, ...), so a recording shows every lamp change in one column, including any bit above 7. In Alexis's recordings of 17 November 2026 bit 3 blinked once a second from the grid through the race (and stayed on for a few seconds in a menu), and bit 7 came on briefly once; no bit follows the lead. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `steer` | memory read, then `-value` | Steering as the game uses it, -1 full left to 1 full right (the game's own value is + left: turned round here). Follows the wheel over USB (correlation 0.98). Alexis's recordings of 17 November 2026 (Civic, automatic, Irohazaka time trial; RX-7, manual, Akagi story race). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `rt` | memory read, then `value / 6000` | Time left (RT), seconds: the race's countdown timer, which the game counts in 1/6000 s. Reached through the game's pointer to the race (0x0C8FF174), so it follows the race from one to the next; matched the screen in three save states (37, 48 and 27 s; GT-R story race and a time trial) and ran 90 s down with two extensions in a recording (17 November 2026, 16:57). Needs plugin 0.18.2. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `race_clock` | memory read, then `value / 6000` | Race clock (TT), seconds, in the same race object: matched the screen in three save states (1:52.18, 2:40.88, 2:30.83); starts at GO and stops at the line (3:09.83 in the recording of 17 November 2026, 16:57). Needs plugin 0.18.2. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `lap` | memory read, then `value + 1` | Lap or section, counting the first as 1 (2, 3 and 3 in the three save states, as the screen's list showed; 1, 2, 3 at the lap lines in a recording). Needs plugin 0.18.2. 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `ffb_cmd` | `byte(ffb_raw, 2)` | Command: 0x84 (132) force, 0x85 (133) vibration, 0x86 (134) spring, 0x80 (128) full spring. |
| `ffb_str` | `byte(ffb_raw, 0)` | Strength, 0 to 127. |
| `force` | `valid(hold(byte(ffb_raw, 1) == 0 ? -(128 - ffb_str) / 127 : ffb_str / 127, ffb_cmd == 132 && ffb_str > 0 && ffb_str < 128), 0)` | Force, -1 to 1, kept until the next force command (direction 0 from the left, 1 from the right). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 127 : 1, (ffb_cmd == 134 && ffb_str > 0 && ffb_str < 128) \|\| (ffb_cmd == 128 && ffb_str == 1)), 0)` | Centring spring, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && byte(ffb_raw, 1) > 0 ? ffb_str / 127 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed, assuming km/h (speed x Max speed undoes the division, so this stays in G). + speeding up, - slowing down. |
| `live` | `thr_revs > 0` | 1 while your car is on the road: from the grid (before the countdown ends) on. 0 in the menus and while a race loads. |
| `rev_limit` | `valid(hold(round(rpm * max_revs / rpm_top / 500) * 500 - 500, rpm_top > 0.3 && live), 0)` | This car's rev limit, RPM, worked out from the two rows above once the engine is past 30% of its scale (to the nearest 500: the two rows are read a moment apart). |
| `rpm_frac` | `rev_limit > 0 ? clamp(rpm * max_revs / rev_limit, 0, 1.1) : 0` | Revs as a fraction of this car's rev limit. |
| `throttle` | `live && rev_limit > 800 ? clamp((thr_revs - 800) / (rev_limit - 800), 0, 1) : 0` | Throttle, 0 to 1, from the revs the throttle asks for (800 = pedal up, the rev limit = pedal down). |
| `race_ok` | `valid(lap, 0) >= 1 && valid(lap, 0) <= 99 && valid(rt, -1) > 0 && valid(rt, -1) < 1000 && valid(race_clock, -1) >= 0 && valid(race_clock, -1) < 7200` | 1 while the race object reads sensibly (lap 1 to 99, time left above 0 and under 1000 s, race clock 0 to 2 hours), so 0 at time up. As a race is cleared away its memory holds rubbish for about half a second (Alexis's recording of 17 November 2026, 16:57), which this keeps out of the rows below. |
| `racing` | `live && gear > 0 && race_ok && maxw(valid(delta(race_clock), 0) > 0 && valid(delta(race_clock), 0) < 0.5, 0.3) > 0` | 1 from GO to the finish line or time up: the car is on the road and out of neutral (the game holds the gear at 0 through the countdown) and the race clock is moving, so it also drops while the game is paused. Checked in Alexis's recording of 17 November 2026 (16:57): on at GO, off at the line (TT 3:09.83), nothing in the menus. |
| `lampleader` | `live && race_ok && valid(race_clock, 0) > 0 && gap >= 0` | Leader lamp, made from the race values: 1 from GO while level with or ahead of the rival (ADVANTAGE 0 or more), so lit throughout a time trial, where there is no rival; it keeps its state after the finish line until the race is cleared away, as Initial D Zero's does (lamps aren't tied to racing). Not a cabinet output. |
| `lampcheckpoint` | `maxw(race_ok && valid(delta(rt), 0) > 0.5 && valid(delta(rt), 0) < 300, 2) > 0` | Checkpoint lamp, 0 or 1: lit for 2 s when the time left jumps up (time extended at a checkpoint or lap line). Made from the race values, as Alexis asked. Checked in her recording of 17 November 2026 (16:57): at both lap lines (17 s to 77 s, 18 s to 77 s), within 0.1 s of her marks. |
| `contact_side` | `valid(hold(sign(kick_x), contact && abs(kick_x) > 0.02), 0)` | Side of the latest contact, -1 left, 1 right, from the sideways knock, kept while the contact lasts. |
| `wall_contact` | `racing && contact ? contact_side : 0` | Touching or scraping a guard rail, wall or gutter edge: -1 on the left, 1 on the right, 0 otherwise. Alexis, 17 November 2026: treat these as guard rails rather than wall hits. |
| `hit` | `racing ? clamp((hypot(kick_x, kick_y) - 0.1) / 0.2, 0, 1) : 0` | A hard knock, 0 to 1: nothing for the light touches (a knock under 0.1), full at 0.3 (her hardest rail hits and the nose into the rival's tail). |
| `hit_side` | `hit > 0 ? sign(kick_x) : 0` | Side of a hard knock, -1 left, 1 right. |
| `gutter` | `racing && (wheel_a == 18 \|\| wheel_a == 32 \|\| wheel_a == 48 \|\| wheel_a == 49 \|\| wheel_b == 18 \|\| wheel_b == 32 \|\| wheel_b == 48 \|\| wheel_b == 49 \|\| wheel_c == 18 \|\| wheel_c == 32 \|\| wheel_c == 48 \|\| wheel_c == 49 \|\| wheel_d == 18 \|\| wheel_d == 32 \|\| wheel_d == 48 \|\| wheel_d == 49)` | 1 while a wheel is in a gutter or on a kerb: surface codes 48 (Akagi's gutter), 49 (Irohazaka's gutter, full of leaves), 18 (Irohazaka's kerb with leaves) and 32 (Myogi's right-hand kerb and gutter; also beside the rails on Akagi and Irohazaka), as Alexis named them (17 November 2026). Other courses may use other codes. |
| `grooved_road` | `racing && (wheel_a == 21 \|\| wheel_b == 21 \|\| wheel_c == 21 \|\| wheel_d == 21)` | 1 on grooved concrete (surface code 21, Myogi): lines pressed into the road along its length, as Alexis described it. The game doesn't shake the wheel for it. |
| `rumble_strip` | `racing && (wheel_a == 20 \|\| wheel_b == 20 \|\| wheel_c == 20 \|\| wheel_d == 20)` | 1 while a wheel is on a ripple strip: surface code 20, the only surface the game shakes the wheel hard for (vibration 0.22 against 0.01 on plain road): 48 spells in her three-lap race on Myogi (16:57), 16 in another (17:50). Alexis confirmed the one at TT 0:06.10 (17 November 2026). |
| `drift_angle` | `racing && speed * max_speed > 10 ? -wrap(yaw * 57.29578 - atan2(-move_x, -move_z) * 57.29578, 360) : 0` | Drift angle, degrees: between where the car points and where it is going, + pointing right of its path (a right-hand drift). 0 below 10 km/h and outside a race. Checked in Alexis's drift recording of 17 November 2026 (19:33, RX-7 on Akagi): + in every right-hand drift and - in every left (99% of samples over 15 degrees), her drifts peaking at 18 to 21 degrees. A rail contact can swing it (32 degrees against a rail there). |
| `drift_curve` | `(1 - pow(1 - clamp((abs(drift_angle) - 5) / 40, 0, 1), 2)) * sqrt(clamp((speed * max_speed - 20) / 80, 0, 1))` | Drifting, 0 to 1: ID6's curve (nothing under 5 degrees or 20 km/h, eased, full from 100 km/h) made full at 45 degrees instead of 50, so her hardest drifts read about 0.62, as Alexis asked (0.6 to 0.65, in line with the other Initial D games; 17 November 2026). |
| `drift` | `contact ? min(drift_curve, valid(hold(drift_curve, !contact), 0)) : drift_curve` | Drifting, 0 to 1 (Car_drift): drift_curve, but never more during a contact than just before it, so a rail knocking the car sideways doesn't read as a big drift (it read 0.93 for a moment in her recording; 0.62 is the top of her real drifts). |
| `car_in_race` (not exported) | `racing` | Common value Car_in_race: 1 from GO (the car on the road and out of neutral) until the race clock stops: the finish line, time up or a pause. Checked in Alexis's recording of 17 November 2026 (16:57). |
| `car_speed` (not exported) | `racing ? (speed * max_speed) : 0` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_rpm` (not exported) | `racing ? (rpm * max_revs) : 0` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_gear` (not exported) | `racing ? (gear) : 0` | Common value Car_gear: gear. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_accel_g` (not exported) | `racing ? (accel_g) : 0` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_speed_kmh` (not exported) | `racing ? (speed * max_speed) : 0` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the speedo). Car_speed_mph is this / 1.609344. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_rev_limit_rpm` (not exported) | `racing ? (rev_limit) : 0` | Common value Car_rev_limit_rpm: this car's rev limit, RPM (the rev_limit row), for a dashboard's redline. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_lap` (not exported) | `racing ? (lap) : 0` | Common value Car_lap: the lap you are on, 1 = first. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_time_left` (not exported) | `racing ? (rt) : 0` | Common value Car_time_left: time left (RT) as the screen shows it, seconds. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_race_time` (not exported) | `racing ? (race_clock) : 0` | Common value Car_race_time: the race clock (TT), seconds. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_steer` (not exported) | `racing ? (steer) : 0` | Common value Car_steer: steering, -1 full left to 1 full right, as the game uses it. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_gap` (not exported) | `racing ? (gap) : 0` | Common value Car_gap: distance to the rival, metres: + ahead, - behind (ADVANTAGE on screen); 0 with no rival. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_impact` (not exported) | `racing ? (hit) : 0` | Common value Car_impact: a hard knock against a rail, wall or the other car, 0 to 1 (light touches are Car_wall_contact only). 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_impact_side` (not exported) | `racing ? (hit_side) : 0` | Common value Car_impact_side: side of a hard knock, -1 left, 1 right. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_wall_contact` (not exported) | `racing ? (wall_contact) : 0` | Common value Car_wall_contact: scraping along a wall or guard rail, -1 left, 1 right. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_road_bump` (not exported) | `racing ? (force_kick <= 0.5 ? force_kick * 2 : 0) : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_rumble_strip` (not exported) | `racing ? (rumble_strip) : 0` | Common value Car_rumble_strip: 1 on a ripple strip. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_off_road` (not exported) | `racing ? (gutter) : 0` | Common value Car_off_road: a wheel in a gutter or on a kerb (surface codes 18, 32, 48, 49). 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_grip_loss` (not exported) | `racing ? (drift) : 0` | Common value Car_grip_loss: drifting, 0 or 1. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_drift` (not exported) | `racing ? (drift) : 0` | Common value Car_drift: drifting, 0 to 1: ID6's weighting made full at 45 degrees, so her hardest drifts read about 0.62 (Alexis: 0.6 to 0.65, in line with the other Initial D games); not raised by a rail contact. With no slip value of its own, Car_grip_loss follows it. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_drift_angle` (not exported) | `racing ? (drift_angle) : 0` | Common value Car_drift_angle: the drift angle in degrees, + pointing right of the car's path (a right-hand drift), - left. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_cornering` (not exported) | `racing ? (clamp(ema(steer, 0.1) / 0.8 * sqrt(clamp(speed * max_speed / 120, 0, 1)), -1, 1)) : 0` | Common value Car_cornering: cornering from the steering and speed, + turning right, as Initial D Zero: the steering (0.8 reads full) times the square root of the speed (full from 120 km/h). Hard bends read 0.6 to 1 in Alexis's recordings of 17 November 2026. Doesn't need Flycast's outputs; the game's own wheel force is weak. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_vibration` (not exported) | `racing ? (vibration) : 0` | Common value Car_vibration: the game's own vibration command, 0 to 1. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_rpm_frac` (not exported) | `racing ? (rpm_frac) : 0` | Common value Car_rpm_frac: revs as a fraction of this car's own rev limit (9000 Civic and GT-R, 7000 RX-7), so the rev limiter and engine effects follow every car. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_throttle` (not exported) | `racing ? (throttle) : 0` | Common value Car_throttle: throttle, 0 to 1 (follows the pedal over USB): the engine effects run at 60% off the throttle, full at full throttle. 0 outside a race (menus, after the line, paused), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |
| `lamp_checkpoint` (not exported) | `lampcheckpoint` | Common lamp Lamp_checkpoint: a checkpoint passed or time extended (`lampcheckpoint`). |

<a id="flyinitdcy"></a>
## Initial D Arcade Stage Ver. 3 Cycraft (Flycast)

Prefix `FLYINITDCY` (properties `TPTelemetry.FLYINITDCY_<row>`), process `(none: reads no game memory)`, folder `Flycast`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_raw` | `valid(out_midiffb, 0)` | The MIDI force feedback message: byte 2 = command, byte 1 = direction or period, byte 0 = strength. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `ffb_cmd` | `byte(ffb_raw, 2)` | Command: 0x84 (132) force, 0x85 (133) vibration, 0x86 (134) spring, 0x80 (128) full spring. |
| `ffb_str` | `byte(ffb_raw, 0)` | Strength, 0 to 127. |
| `force` | `valid(hold(byte(ffb_raw, 1) == 0 ? -(128 - ffb_str) / 127 : ffb_str / 127, ffb_cmd == 132 && ffb_str > 0 && ffb_str < 128), 0)` | Force, -1 to 1, kept until the next force command (direction 0 from the left, 1 from the right). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 127 : 1, (ffb_cmd == 134 && ffb_str > 0 && ffb_str < 128) \|\| (ffb_cmd == 128 && ffb_str == 1)), 0)` | Centring spring, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && byte(ffb_raw, 1) > 0 ? ffb_str / 127 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="flymaxspeed"></a>
## Maximum Speed (Flycast)

Prefix `FLYMAXSPEED` (properties `TPTelemetry.FLYMAXSPEED_<row>`), process `(none: reads no game memory)`, folder `Flycast`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_awffb, 0)` | The Atomiswave wheel output: bit 0 = direction, bits 1 to 4 = strength. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `force` | `ffb_cmd > 0 ? (band(ffb_cmd, 1) ? -(ffb_cmd + 1) / 32 : ffb_cmd / 32) : 0` | Force, -1 to 1: odd values from the left, even from the right, as the FFB plugin's table decodes them. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="flysgdrvsim"></a>
## Sega Driving Simulator (Flycast)

Prefix `FLYSGDRVSIM` (properties `TPTelemetry.FLYSGDRVSIM_<row>`), process `(none: reads no game memory)`, folder `Flycast`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | `valid(out_speedometer, 0) / max_speed` | Speed, from the driving simulator's speedometer output (units still to be checked). Divided by Max speed. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `rpm` | `valid(out_tachometer, 0) / max_revs` | Engine RPM, from the driving simulator's tachometer output (whole hundreds). Divided by Max revs. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `ffb_raw` | `valid(out_midiffb, 0)` | The MIDI force feedback message: byte 2 = command, byte 1 = direction or period, byte 0 = strength. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `ffb_cmd` | `byte(ffb_raw, 2)` | Command: 0x84 (132) force, 0x85 (133) vibration, 0x86 (134) spring, 0x80 (128) full spring. |
| `ffb_str` | `byte(ffb_raw, 0)` | Strength, 0 to 127. |
| `force` | `valid(hold(byte(ffb_raw, 1) == 0 ? -(128 - ffb_str) / 127 : ffb_str / 127, ffb_cmd == 132 && ffb_str > 0 && ffb_str < 128), 0)` | Force, -1 to 1, kept until the next force command (direction 0 from the left, 1 from the right). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 127 : 1, (ffb_cmd == 134 && ffb_str > 0 && ffb_str < 128) \|\| (ffb_cmd == 128 && ffb_str == 1)), 0)` | Centring spring, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && byte(ffb_raw, 1) > 0 ? ffb_str / 127 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="flykingrt66"></a>
## The King of Route 66 (Flycast)

Prefix `FLYKINGRT66` (properties `TPTelemetry.FLYKINGRT66_<row>`), process `(none: reads no game memory)`, folder `Flycast`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_raw` | `valid(out_midiffb, 0)` | The MIDI force feedback message: byte 2 = command, byte 1 = direction or period, byte 0 = strength. From Flycast's network outputs (Settings, Network, "Broadcast Digital Outputs"), as the FFB Arcade Plugin reads them; Flycast sends hexadecimal values, which TP Telemetry reads from plugin 0.13.3. TeknoParrot's NAOMI emulator may not send them. |
| `ffb_cmd` | `byte(ffb_raw, 2)` | Command: 0x84 (132) force, 0x85 (133) vibration, 0x86 (134) spring, 0x80 (128) full spring. |
| `ffb_str` | `byte(ffb_raw, 0)` | Strength, 0 to 127. |
| `force` | `valid(hold(byte(ffb_raw, 1) == 0 ? -(128 - ffb_str) / 127 : ffb_str / 127, ffb_cmd == 132 && ffb_str > 0 && ffb_str < 128), 0)` | Force, -1 to 1, kept until the next force command (direction 0 from the left, 1 from the right). |
| `spring` | `valid(hold(ffb_cmd == 134 ? ffb_str / 127 : 1, (ffb_cmd == 134 && ffb_str > 0 && ffb_str < 128) \|\| (ffb_cmd == 128 && ffb_str == 1)), 0)` | Centring spring, 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd == 133 && byte(ffb_raw, 1) > 0 ? ffb_str / 127 : 0` | Vibration strength while the game asks for it, 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="mamecbombers"></a>
## Cadash Bombers / Chase Bombers (MAME)

Prefix `MAMECBOMBERS` (properties `TPTelemetry.MAMECBOMBERS_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `vibration` | `valid(out_MA_Steering_Wheel_motor, 0) == 1 \|\| valid(out_upright_wheel_motor, 0) == 1 \|\| valid(out_Vibration_motor, 0) == 1 \|\| valid(out_Wheel_vibration, 0) == 1 \|\| valid(out_Wheel_Vibration, 0) == 1` | 1 while the game runs its wheel shaker motor (the only force these games send). From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="mamecalspeed"></a>
## California Speed (MAME)

Prefix `MAMECALSPEED` (properties `TPTelemetry.MAMECALSPEED_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_wheel, valid(out_wheel_motor, 0))` | The wheel motor value the game sends, 0 to 255. From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `force` | `ffb_cmd > 128 && ffb_cmd < 256 ? -(256 - ffb_cmd) / 126 : (ffb_cmd > 0 && ffb_cmd < 128 ? ffb_cmd / 126 : 0)` | Force, -1 to 1 (above 128 one way, below the other), as the FFB plugin decodes it. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="mamecischeat"></a>
## Cisco Heat (MAME)

Prefix `MAMECISCHEAT` (properties `TPTelemetry.MAMECISCHEAT_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `vibration` | `valid(out_led2, 0) == 1` | 1 while the game runs its wheel shaker (output led2). From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="mamecrusnusa"></a>
## Cruis'n USA (MAME)

Prefix `MAMECRUSNUSA` (properties `TPTelemetry.MAMECRUSNUSA_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_wheel, 0)` | The wheel motor value the game sends, 0 to 255. From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `force` | `ffb_cmd > 128 && ffb_cmd < 256 ? (256 - ffb_cmd) / 126 : (ffb_cmd > 0 && ffb_cmd < 128 ? -ffb_cmd / 126 : 0)` | Force, -1 to 1 (above 128 one way, below the other), as the FFB plugin decodes it. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="mamecrusnwld"></a>
## Cruis'n World (MAME)

Prefix `MAMECRUSNWLD` (properties `TPTelemetry.MAMECRUSNWLD_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_wheel, 0)` | The wheel motor value the game sends, 0 to 255. From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `force` | `ffb_cmd > 128 && ffb_cmd < 256 ? (256 - ffb_cmd) / 126 : (ffb_cmd > 0 && ffb_cmd < 128 ? -ffb_cmd / 126 : 0)` | Force, -1 to 1 (above 128 one way, below the other), as the FFB plugin decodes it. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="mamedblaxle"></a>
## Double Axle (MAME)

Prefix `MAMEDBLAXLE` (properties `TPTelemetry.MAMEDBLAXLE_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `vibration` | `valid(out_MA_Steering_Wheel_motor, 0) == 1 \|\| valid(out_upright_wheel_motor, 0) == 1 \|\| valid(out_Vibration_motor, 0) == 1 \|\| valid(out_Wheel_vibration, 0) == 1 \|\| valid(out_Wheel_Vibration, 0) == 1` | 1 while the game runs its wheel shaker motor (the only force these games send). From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="mamef1gpstar"></a>
## F1 Grand Prix Star (MAME)

Prefix `MAMEF1GPSTAR` (properties `TPTelemetry.MAMEF1GPSTAR_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `vibration` | `valid(out_led2, 0) == 1` | 1 while the game runs its wheel shaker (output led2). From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="mamehyprdriv"></a>
## Hyperdrive (MAME)

Prefix `MAMEHYPRDRIV` (properties `TPTelemetry.MAMEHYPRDRIV_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_wheel, valid(out_wheel_motor, 0))` | The wheel motor value the game sends, 0 to 255. From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `force` | `ffb_cmd > 128 && ffb_cmd < 256 ? -(256 - ffb_cmd) / 126 : (ffb_cmd > 0 && ffb_cmd < 128 ? ffb_cmd / 126 : 0)` | Force, -1 to 1 (above 128 one way, below the other), as the FFB plugin decodes it. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="mameoffroadc"></a>
## Off Road Challenge (MAME)

Prefix `MAMEOFFROADC` (properties `TPTelemetry.MAMEOFFROADC_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_wheel, 0)` | The wheel motor value the game sends, 0 to 255. From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `force` | `ffb_cmd > 128 && ffb_cmd < 256 ? (256 - ffb_cmd) / 126 : (ffb_cmd > 0 && ffb_cmd < 128 ? -ffb_cmd / 126 : 0)` | Force, -1 to 1 (above 128 one way, below the other), as the FFB plugin decodes it. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="mameoutrun"></a>
## Out Run (MAME)

Prefix `MAMEOUTRUN` (properties `TPTelemetry.MAMEOUTRUN_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `bank_dir` | `valid(out_Bank_Motor_Direction, 0)` | Deluxe cabinet bank motor direction: 1 one way, 2 the other. From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `bank_speed` | `valid(out_Bank_Motor_Speed, 0)` | Bank motor speed, 0 to 7. From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `vibration` | `valid(out_Vibration_motor, 0) == 1` | 1 while the shaker motor runs. From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `force` | `bank_dir == 1 ? -(1 + bank_speed) / 8 : (bank_dir == 2 ? (1 + bank_speed) / 8 : 0)` | Force from the bank motor, -1 to 1, as the FFB plugin plays it. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="mameorunners"></a>
## OutRunners (MAME)

Prefix `MAMEORUNNERS` (properties `TPTelemetry.MAMEORUNNERS_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `vibration` | `valid(out_MA_Steering_Wheel_motor, 0) == 1 \|\| valid(out_upright_wheel_motor, 0) == 1 \|\| valid(out_Vibration_motor, 0) == 1 \|\| valid(out_Wheel_vibration, 0) == 1 \|\| valid(out_Wheel_Vibration, 0) == 1` | 1 while the game runs its wheel shaker motor (the only force these games send). From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="mamepdrift"></a>
## Power Drift (MAME)

Prefix `MAMEPDRIFT` (properties `TPTelemetry.MAMEPDRIFT_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `bank_pos` | `valid(out_bank_motor_position, 4)` | Bank motor position, 1 to 7 (4 = centre). From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `vibration` | `max(valid(out_vibration_motor, 0) / 7, valid(out_upright_wheel_motor, 0) == 1)` | Vibration, 0 to 1 (deluxe shaker level, or the upright shaker on). From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `force` | `bank_pos > 0 && bank_pos < 4 ? -(4 - bank_pos) / 3 : (bank_pos > 4 && bank_pos < 8 ? (bank_pos - 4) / 3 : 0)` | Force from the bank motor, -1 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="mamesfrush"></a>
## San Francisco Rush (MAME)

Prefix `MAMESFRUSH` (properties `TPTelemetry.MAMESFRUSH_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_wheel, 0)` | The wheel motor value the game sends, 0 to 255. From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `force` | `ffb_cmd > 128 && ffb_cmd < 256 ? (256 - ffb_cmd) / 126 : (ffb_cmd > 0 && ffb_cmd < 128 ? -ffb_cmd / 126 : 0)` | Force, -1 to 1 (above 128 one way, below the other), as the FFB plugin decodes it. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="mamesf2049"></a>
## San Francisco Rush 2049 (MAME)

Prefix `MAMESF2049` (properties `TPTelemetry.MAMESF2049_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_wheel, valid(out_wheel_motor, 0))` | The wheel motor value the game sends, 0 to 255. From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `force` | `ffb_cmd > 128 && ffb_cmd < 256 ? -(256 - ffb_cmd) / 126 : (ffb_cmd > 0 && ffb_cmd < 128 ? ffb_cmd / 126 : 0)` | Force, -1 to 1 (above 128 one way, below the other), as the FFB plugin decodes it. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="mamesfrushrk"></a>
## San Francisco Rush: The Rock (MAME)

Prefix `MAMESFRUSHRK` (properties `TPTelemetry.MAMESFRUSHRK_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_wheel, 0)` | The wheel motor value the game sends, 0 to 255. From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `force` | `ffb_cmd > 128 && ffb_cmd < 256 ? (256 - ffb_cmd) / 126 : (ffb_cmd > 0 && ffb_cmd < 128 ? -ffb_cmd / 126 : 0)` | Force, -1 to 1 (above 128 one way, below the other), as the FFB plugin decodes it. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="mametoutrun"></a>
## Turbo Out Run (MAME)

Prefix `MAMETOUTRUN` (properties `TPTelemetry.MAMETOUTRUN_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `vibration` | `valid(out_MA_Steering_Wheel_motor, 0) == 1 \|\| valid(out_upright_wheel_motor, 0) == 1 \|\| valid(out_Vibration_motor, 0) == 1 \|\| valid(out_Wheel_vibration, 0) == 1 \|\| valid(out_Wheel_Vibration, 0) == 1` | 1 while the game runs its wheel shaker motor (the only force these games send). From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="mamevaportrx"></a>
## Vapor TRX (MAME)

Prefix `MAMEVAPORTRX` (properties `TPTelemetry.MAMEVAPORTRX_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_wheel, valid(out_wheel_motor, 0))` | The wheel motor value the game sends, 0 to 255. From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `force` | `ffb_cmd > 128 && ffb_cmd < 256 ? -(256 - ffb_cmd) / 126 : (ffb_cmd > 0 && ffb_cmd < 128 ? ffb_cmd / 126 : 0)` | Force, -1 to 1 (above 128 one way, below the other), as the FFB plugin decodes it. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="mamevr"></a>
## Virtua Racing (MAME)

Prefix `MAMEVR` (properties `TPTelemetry.MAMEVR_<row>`), process `(none: reads no game memory)`, folder `MAME`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_digit0, 0)` | The force feedback command (output digit0). From MAME's network outputs (output network in mame.ini), as the FFB Arcade Plugin reads them; TeknoParrot's own builds may not send them. |
| `force` | `valid(hold(ffb_cmd == 80 \|\| ffb_cmd == 95 ? 0.5 : -0.5, ffb_cmd == 80 \|\| ffb_cmd == 95 \|\| ffb_cmd == 96 \|\| ffb_cmd == 111), 0)` | Force, +0.5 or -0.5 ("roll left" from the right, "roll right" from the left), kept until the next. |
| `spring` | `valid(hold(ffb_cmd >= 48 && ffb_cmd <= 63 ? clamp((ffb_cmd - 47) / 11, 0, 1) : 0.8, ffb_cmd == 3 \|\| ffb_cmd == 7 \|\| ffb_cmd == 9 \|\| ffb_cmd == 16 \|\| (ffb_cmd >= 48 && ffb_cmd <= 63)), 0)` | Centring spring, 0 to 1. |
| `vibration` | `ffb_cmd == 64 \|\| ffb_cmd == 70 \|\| ffb_cmd == 74 ? 0.4 : 0` | Vibration (0.4, as the FFB plugin plays it). |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="m2daytona"></a>
## Daytona USA (Model 2 Emulator)

Prefix `M2DAYTONA` (properties `TPTelemetry.M2DAYTONA_<row>`), process `emulator_multicpu.exe`, folder `Model 2 Emulator`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | The speedo's km/h, whole numbers (320 at the rolling start's GO, 330 flat out in a slipstream). Found in Alexis's RAM log of 8 November 2026 against her readings from video (three laps of the Beginner course, manual gears); the time extensions also match her TP Telemetry recordings of that day. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `rpm` | memory read, then `value / max_revs` | Engine revs as the tacho shows them (7400 at GO, 8500 on the limiter). Found in Alexis's RAM log of 8 November 2026 against her readings from video (three laps of the Beginner course, manual gears); the time extensions also match her TP Telemetry recordings of that day. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `gear` | memory read, then `value + 1` | Gear, stored 0 to 3 (1 added here, so 1 to 4), for manual and automatic: it matched every shift in the manual log and every marked upshift in the automatic one (8 November 2026, 15:29). Keeps the last gear through neutral. (0x5FE122 has the H pattern's switches, manual only.) Found in Alexis's RAM log of 8 November 2026 against her readings from video (three laps of the Beginner course, manual gears); the time extensions also match her TP Telemetry recordings of that day. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `time_left` | memory read, then `value / 64` | Time left on the race clock in 1/64 s; its "Infinite Time" cheat holds it at 50 x 64. From the Model 2 Emulator's own SCRIPTS\daytona.lua (sent by Alexis, 4 November 2026). Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `race_time` | memory read, then `value / 64` | Elapsed race time in seconds (frames from GO, 64 to the second). Found in Alexis's RAM log of 8 November 2026 against her readings from video (three laps of the Beginner course, manual gears); the time extensions also match her TP Telemetry recordings of that day. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `last_lap` | memory read, then `value / 64` | Last lap time in seconds (a best lap time sits in the other half of the word; both were the same in the log, so which is which isn't certain). Found in Alexis's RAM log of 8 November 2026 against her readings from video (three laps of the Beginner course, manual gears); the time extensions also match her TP Telemetry recordings of that day. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `checkpoint` | memory read, then `value > 0 && value <= 128` | 1 while TIME EXTENSION shows after crossing the line (2 s). Raw: a countdown the game starts at 128 and lowers by 1 a frame (255 ignored: Sega Rally's timer reads 255 mid-frame once it has run out, and this may too). Found in Alexis's RAM log of 8 November 2026 against her readings from video (three laps of the Beginner course, manual gears); the time extensions also match her TP Telemetry recordings of that day. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `surface_rumble` | memory read, then `clamp(value / 47, 0, 1)` | Rumble from the surface, 0 to 1: the game sets 47 on grass and kerbs and lets it die away. Found in Alexis's RAM log of 8 November 2026 against her readings from video (three laps of the Beginner course, manual gears); the time extensions also match her TP Telemetry recordings of that day. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `grip_loss` | memory read, then `clamp(value / 21, 0, 1)` | Sliding, 0 to 1, from the tyre squeal. Raw: Tyre squeal, raw 0 to 21: up through each slide in the log (0x05 to 0x15), 0 with grip. Found in Alexis's RAM log of 8 November 2026 against her readings from video (three laps of the Beginner course, manual gears); the time extensions also match her TP Telemetry recordings of that day. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `force` | `valid(hold(ffb_cmd >= 80 && ffb_cmd <= 87 ? (ffb_cmd - 79) / 8 : (ffb_cmd >= 96 && ffb_cmd <= 103 ? -(ffb_cmd - 95) / 8 : 0), (ffb_cmd >= 80 && ffb_cmd <= 87) \|\| (ffb_cmd >= 96 && ffb_cmd <= 103)), 0)` | Force, -1 to 1, kept until the next force command ("roll left" + from the right, "roll right" -). |
| `spring` | `valid(hold(ffb_cmd >= 10 && ffb_cmd <= 23 ? clamp((ffb_cmd - 15) / 8, 0, 1) : clamp((ffb_cmd - 47) / 13, 0, 1), (ffb_cmd >= 10 && ffb_cmd <= 23) \|\| (ffb_cmd >= 48 && ffb_cmd <= 60)), 0)` | Centring spring, 0 to 1, kept until changed. |
| `friction` | `valid(hold(clamp((ffb_cmd - 31) / 8, 0, 1), ffb_cmd >= 32 && ffb_cmd <= 39), 0)` | Friction ("clutch"), 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd >= 64 && ffb_cmd <= 71 ? (ffb_cmd - 63) / 8 : 0` | Vibration ("uncentering"), 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `position` | `game_state == 22 ? cars_in_front + 1 : 0` | Race position, 1 = leading (cars ahead + 1); 0 outside a race (the count is 0 in attract mode and the menus). |
| `lap_time` | `max(race_time - lap_start / 64, 0)` | Current lap time in seconds (race time less the time at the last crossing): matched the 24.12, 22.54 and 20.90 laps on screen. |
| `rumble_strip` | `speed * max_speed > 5 ? ((band(bits(wheels_front, 16, 16), 256) != 0) + (band(bits(wheels_front, 0, 16), 256) != 0) + (band(bits(wheels_rear, 16, 16), 256) != 0) + (band(bits(wheels_rear, 0, 16), 256) != 0)) / 4 : 0` | Wheels on a kerb, 0 to 1 (a quarter per wheel), while moving. |
| `off_road` | `speed * max_speed > 5 ? ((band(bits(wheels_front, 16, 16), 15) == 4) + (band(bits(wheels_front, 0, 16), 15) == 4) + (band(bits(wheels_rear, 16, 16), 15) == 4) + (band(bits(wheels_rear, 0, 16), 15) == 4)) / 4 : 0` | Wheels on grass, 0 to 1 (a quarter per wheel), while moving. |
| `lampstart` | `band(rawlamps, 4) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampleader` | `band(rawlamps, 128) != 0` | LampLeader output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(rawlamps, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | `band(rawlamps, 16) != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview3` | `band(rawlamps, 32) != 0` | LampView3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview4` | `band(rawlamps, 64) != 0` | LampView4 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_in_race` (not exported) | `game_state == 22` | Common value Car_in_race: 1 while racing (game state 22, as the FFB plugin uses it). |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the speedo). Car_speed_mph is this / 1.609344. |
| `car_position` (not exported) | `position` | Common value Car_position: race position, 1 = first. |
| `car_lap` (not exported) | `game_state == 22 ? laps_done + 1 : 0` | Common value Car_lap: the lap you are on, 1 = first (laps completed + 1); 0 outside a race. |
| `car_time_left` (not exported) | `time_left` | Common value Car_time_left: time left (RT), seconds. |
| `car_race_time` (not exported) | `race_time` | Common value Car_race_time: the race clock (TT), seconds. |
| `car_lap_time` (not exported) | `lap_time` | Common value Car_lap_time: the current lap's time, seconds. |
| `car_impact` (not exported) | `max(maxw(delta(hit) > 0 ? hit / 15 : 0, 0.2), force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0)` | Common value Car_impact: wall hits and side-on contact, 0 to 1 by the game's own strength (held 0.2 s), or a big kick in the wheel force (rear-end bumps). |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big force kick (+ = from the right); the game's hit value has no side. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_rumble_strip` (not exported) | `rumble_strip` | Common value Car_rumble_strip: 1 on a ripple strip. |
| `car_off_road` (not exported) | `off_road` | Common value Car_off_road: off the road. |
| `car_grip_loss` (not exported) | `grip_loss` | Common value Car_grip_loss: sliding, 0 to 1. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |
| `lamp_checkpoint` (not exported) | `checkpoint` | Common lamp Lamp_checkpoint: a checkpoint passed or time extended (`checkpoint`). |

<a id="m2indy500"></a>
## Indianapolis 500 (Model 2 Emulator)

Prefix `M2INDY500` (properties `TPTelemetry.M2INDY500_<row>`), process `emulator_multicpu.exe`, folder `Model 2 Emulator`.

| Row | Formula | What it does |
|---|---|---|
| `force` | `valid(hold(ffb_cmd >= 80 && ffb_cmd <= 87 ? (ffb_cmd - 79) / 8 : (ffb_cmd >= 96 && ffb_cmd <= 103 ? -(ffb_cmd - 95) / 8 : 0), (ffb_cmd >= 80 && ffb_cmd <= 87) \|\| (ffb_cmd >= 96 && ffb_cmd <= 103)), 0)` | Force, -1 to 1, kept until the next force command ("roll left" + from the right, "roll right" -). |
| `spring` | `valid(hold(ffb_cmd >= 10 && ffb_cmd <= 23 ? clamp((ffb_cmd - 15) / 8, 0, 1) : clamp((ffb_cmd - 47) / 13, 0, 1), (ffb_cmd >= 10 && ffb_cmd <= 23) \|\| (ffb_cmd >= 48 && ffb_cmd <= 60)), 0)` | Centring spring, 0 to 1, kept until changed. |
| `friction` | `valid(hold(clamp((ffb_cmd - 31) / 8, 0, 1), ffb_cmd >= 32 && ffb_cmd <= 39), 0)` | Friction ("clutch"), 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd >= 64 && ffb_cmd <= 71 ? (ffb_cmd - 63) / 8 : 0` | Vibration ("uncentering"), 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(rawlamps, 4) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampleader` | `band(rawlamps, 128) != 0` | LampLeader output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(rawlamps, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | `band(rawlamps, 16) != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview3` | `band(rawlamps, 32) != 0` | LampView3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview4` | `band(rawlamps, 64) != 0` | LampView4 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |

<a id="m2overrev"></a>
## Over Rev (Model 2 Emulator)

Prefix `M2OVERREV` (properties `TPTelemetry.M2OVERREV_<row>`), process `emulator_multicpu.exe`, folder `Model 2 Emulator`.

| Row | Formula | What it does |
|---|---|---|
| `force` | `valid(hold(ffb_cmd >= 80 && ffb_cmd <= 87 ? (ffb_cmd - 79) / 8 : (ffb_cmd >= 96 && ffb_cmd <= 103 ? -(ffb_cmd - 95) / 8 : 0), (ffb_cmd >= 80 && ffb_cmd <= 87) \|\| (ffb_cmd >= 96 && ffb_cmd <= 103)), 0)` | Force, -1 to 1, kept until the next force command ("roll left" + from the right, "roll right" -). |
| `spring` | `valid(hold(ffb_cmd >= 10 && ffb_cmd <= 23 ? clamp((ffb_cmd - 15) / 8, 0, 1) : clamp((ffb_cmd - 47) / 13, 0, 1), (ffb_cmd >= 10 && ffb_cmd <= 23) \|\| (ffb_cmd >= 48 && ffb_cmd <= 60)), 0)` | Centring spring, 0 to 1, kept until changed. |
| `friction` | `valid(hold(clamp((ffb_cmd - 31) / 8, 0, 1), ffb_cmd >= 32 && ffb_cmd <= 39), 0)` | Friction ("clutch"), 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd >= 64 && ffb_cmd <= 71 ? (ffb_cmd - 63) / 8 : 0` | Vibration ("uncentering"), 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(rawlamps, 4) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampleader` | `band(rawlamps, 128) != 0` | LampLeader output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(rawlamps, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | `band(rawlamps, 16) != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview3` | `band(rawlamps, 32) != 0` | LampView3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview4` | `band(rawlamps, 64) != 0` | LampView4 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |

<a id="m2srally"></a>
## Sega Rally Championship (Model 2 Emulator)

Prefix `M2SRALLY` (properties `TPTelemetry.M2SRALLY_<row>`), process `emulator_multicpu.exe`, folder `Model 2 Emulator`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value * 64 / max_speed` | Car speed, x 64 = km/h (about 1% under the speedo: 216.8 for 220, 206.9 for 207). In the player car's block, set up at coin-up. Found in Alexis's RAM logs of 8 November 2026 (srallyc) against her readings from video, and checked in her TP Telemetry recording of that day where it has the value. For the srallyc romset; others may keep it elsewhere. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `rpm` | memory read, then `value / max_revs` | Engine revs: 8800 on the limiter, where the tacho reads 8k (the tacho shows revs / 1.1). Found in Alexis's RAM logs of 8 November 2026 (srallyc) against her readings from video, and checked in her TP Telemetry recording of that day where it has the value. For the srallyc romset; others may keep it elsewhere. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `total_time` | memory read, then `value / 60` | Total time in seconds, for the whole game (it carries on into the next stage). Found in Alexis's RAM logs of 8 November 2026 (srallyc) against her readings from video, and checked in her TP Telemetry recording of that day where it has the value. For the srallyc romset; others may keep it elsewhere. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `stage_time` | memory read, then `value / 60` | This stage's time in seconds (the LT on screen). Found in Alexis's RAM logs of 8 November 2026 (srallyc) against her readings from video, and checked in her TP Telemetry recording of that day where it has the value. For the srallyc romset; others may keep it elsewhere. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `time_left` | memory read, then `value / 60` | Time left in seconds (stored in frames; +20 s at the Desert checkpoint). The emulator's srallyc.lua reads it to stop the time going up in link play. Reads oddly for a moment while the next stage loads. Found in Alexis's RAM logs of 8 November 2026 (srallyc) against her readings from video, and checked in her TP Telemetry recording of that day where it has the value. For the srallyc romset; others may keep it elsewhere. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `grip_loss` | memory read, then `clamp((abs(value) - 0.2) / 0.4, 0, 1)` | Sliding, 0 to 1, from the rear slip (as STCC). Raw: Rear left tyre slip, as slip_front: 0.5 to 0.85 through the long drifts. 0x21388C is the rear right. Found in Alexis's RAM logs of 8 November 2026 (srallyc) against her readings from video, and checked in her TP Telemetry recording of that day where it has the value. For the srallyc romset; others may keep it elsewhere. Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `force` | `valid(hold(ffb_cmd >= 192 && ffb_cmd <= 223 ? (ffb_cmd - 191) / 32 : (ffb_cmd >= 128 && ffb_cmd <= 159 ? -(ffb_cmd - 127) / 32 : 0), (ffb_cmd >= 128 && ffb_cmd <= 159) \|\| (ffb_cmd >= 192 && ffb_cmd <= 223)), 0)` | Force, -1 to 1, kept until the next force command (0xC0 up = from the right, 0x80 up = from the left). |
| `vibration` | `valid(hold(ffb_cmd > 16 && ffb_cmd <= 31 ? 1 : 0, ffb_cmd >= 16 && ffb_cmd <= 31), 0)` | Rumble on (1) or off (0), kept until changed: the game sends 0x15 on the grass verge, scraping walls and at some landings, and 0x10 to stop. The FFB Arcade Plugin ignores these. |
| `in_race` | `race_state == 1` | 1 from GO to the finish line or time up. |
| `rpm_tacho` | `rpm * max_revs / 1.1` | Revs as the tacho shows them (8000 on the limiter). |
| `checkpoint` | `race_state == 1 && maxw(delta(time_left) > 1, 1) > 0` | 1 for a second from each time extension, for a lamp: when the time left jumps up during a race. The game's own message timer (0x20AEA0, counting down from 60) reads 255 partway through a frame once it has run out, so TP Telemetry caught it stuck on; the time left doesn't have that problem. |
| `leader` | `in_race == 1 && position == 1` | 1 while you lead, for a lamp (the game's own lamps haven't lit one for the lead in any log). |
| `off_road` | `speed * max_speed > 5 ? ((surface_fl == 6) + (surface_fr == 6) + (surface_rl == 6) + (surface_rr == 6)) / 4 : 0` | Wheels on the grass verge, 0 to 1 (a quarter per wheel), while moving. |
| `airborne` | `race_state == 1 && wheels_down == 0` | 1 with all four wheels off the ground (every jump in Alexis's notes). |
| `hit_now` | `delta(hit) != 0 ? abs(hit) : 0` | The strength of a hit in the moment it happens (0 otherwise). |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(rawlamps, 4) != 0` | LampStart output, 0 or 1. From the emulator's lamp-port value (see rawlamps); no OutputBlaster needed. |
| `lampleader` | `band(rawlamps, 128) != 0` | LampLeader output, 0 or 1. From the emulator's lamp-port value (see rawlamps); no OutputBlaster needed. |
| `lampview1` | `band(rawlamps, 8) != 0` | LampView1 output, 0 or 1. From the emulator's lamp-port value (see rawlamps); no OutputBlaster needed. |
| `lampview2` | `band(rawlamps, 16) != 0` | LampView2 output, 0 or 1. From the emulator's lamp-port value (see rawlamps); no OutputBlaster needed. |
| `lampview3` | `band(rawlamps, 32) != 0` | LampView3 output, 0 or 1. From the emulator's lamp-port value (see rawlamps); no OutputBlaster needed. |
| `lampview4` | `band(rawlamps, 64) != 0` | LampView4 output, 0 or 1. From the emulator's lamp-port value (see rawlamps); no OutputBlaster needed. |
| `car_in_race` (not exported) | `in_race != 0` | Common value Car_in_race: 1 while racing. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (about 1% under the speedo). Car_speed_mph is this / 1.609344. |
| `car_position` (not exported) | `position` | Common value Car_position: race position, 1 = first. |
| `car_time_left` (not exported) | `time_left` | Common value Car_time_left: time left (RT), seconds. |
| `car_lap_time` (not exported) | `stage_time` | Common value Car_lap_time: this stage's time so far, seconds. |
| `car_impact` (not exported) | `max(maxw(hit_now, 0.2) > 0 ? clamp(0.4 + maxw(hit_now, 0.2) / 200, 0.4, 1) : 0, force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0)` | Common value Car_impact: wall and car hits, 0.4 to 1 by the game's own strength (24 reads 0.5, 120 or more 1), held 0.2 s, or a big kick in the wheel force. |
| `car_impact_side` (not exported) | `maxw(hit_now, 0.2) > 0 ? valid(hold(sign(hit), delta(hit) != 0 && hit != 0), 0) : 0` | Common value Car_impact_side: side of the hit, -1 left, 1 right (the game's own sign; the wheel force agreed at every wall hit in the recordings). |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_off_road` (not exported) | `off_road` | Common value Car_off_road: off the road. |
| `car_grip_loss` (not exported) | `grip_loss` | Common value Car_grip_loss: sliding, 0 to 1. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_airborne` (not exported) | `airborne` | Common value Car_airborne: 1 in the air (a guess so far). |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |
| `lamp_leader` (not exported) | `leader` | Common lamp Lamp_leader: in the lead, made from the race values (`leader`). |
| `lamp_checkpoint` (not exported) | `checkpoint` | Common lamp Lamp_checkpoint: a checkpoint passed or time extended (`checkpoint`). |

<a id="m2stcc"></a>
## Sega Touring Car Championship (Model 2 Emulator)

Prefix `M2STCC` (properties `TPTelemetry.M2STCC_<row>`), process `emulator_multicpu.exe`, folder `Model 2 Emulator`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value * 64 / max_speed` | Car speed, x 64 = km/h (126, 157 and 208 at the 2nd, 3rd and 4th gear limits, 274 flat out in 5th). Keeps reading after the finish as the car slows. Found in Alexis's RAM logs of 5 and 6 November 2026 against her readings from video, and checked in her TP Telemetry recording of 6 November 2026 (12:07). Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `rpm` | memory read, then `value / max_revs` | The engine's own revs (Alexis's choice, 8 November 2026): 12190 revving on the grid, 13130 launching in 1st, about 12800 on the limiter (both cars seen), and they stay up when the wheels spin, so the tacho reads lower in skids. Found in Alexis's RAM logs of 5 and 6 November 2026 against her readings from video, and checked in her TP Telemetry recording of 6 November 2026 (12:07). Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `rpm_tacho` | memory read, then `value * 1.078` | Revs as the tacho bar shows them, raw (x 1.078: the bar read 12.5k to 12.8k at the gear limits, 9.8k to 11.4k in skids). Keeps reading after the finish. Found in Alexis's RAM logs of 5 and 6 November 2026 against her readings from video, and checked in her TP Telemetry recording of 6 November 2026 (12:07). Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `checkpoint` | memory read, then `value > 0` | 1 while "TIME EXTENDED" is on screen (about 2.7 s) after crossing the line or a checkpoint. Raw: a countdown the game starts at 158 and lowers by 1 a frame. Found in Alexis's RAM logs of 5 and 6 November 2026 against her readings from video, and checked in her TP Telemetry recording of 6 November 2026 (12:07). Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `time_left` | memory read, then `value / 64` | Race time left (the countdown), stored in 1/64 s like Daytona's. Found in Alexis's RAM logs of 5 and 6 November 2026 against her readings from video, and checked in her TP Telemetry recording of 6 November 2026 (12:07). Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `grip_loss` | memory read, then `clamp((abs(value) - 0.2) / 0.4, 0, 1)` | Sliding, 0 to 1, from the rear slip angle: about 0.3 in a slight skid, 0.5 to 0.6 in a moderate one, 1 in a big one, 0 on the straight. Raw: Rear tyre slip angle (radians, + in right-hand turns): under 0.25 cornering, 0.3 to 0.45 in slight skids, 0.6 to 0.65 in big ones. 0x208968 is the other rear tyre. Found in Alexis's RAM logs of 5 and 6 November 2026 against her readings from video, and checked in her TP Telemetry recording of 6 November 2026 (12:07). Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `airborne` | memory read, then `value > 0` | 1 with wheels off the ground (the front or the back thrown up counts). Raw: Frames with wheels off the ground, counting up (19 over the dip, 23 after a hard wall hit), 0 on the ground. Found in Alexis's RAM logs of 5 and 6 November 2026 against her readings from video, and checked in her TP Telemetry recording of 6 November 2026 (12:07). Model 2 Emulator (emulator_multicpu.exe, the build the FFB Arcade Plugin and OutputBlaster know). TeknoParrot's own Model 2 emulator may differ. |
| `force` | `valid(hold(ffb_cmd >= 80 && ffb_cmd <= 87 ? (ffb_cmd - 79) / 8 : (ffb_cmd >= 96 && ffb_cmd <= 103 ? -(ffb_cmd - 95) / 8 : 0), (ffb_cmd >= 80 && ffb_cmd <= 87) \|\| (ffb_cmd >= 96 && ffb_cmd <= 103)), 0)` | Force, -1 to 1, kept until the next force command ("roll left" + from the right, "roll right" -). |
| `spring` | `valid(hold(ffb_cmd >= 10 && ffb_cmd <= 23 ? clamp((ffb_cmd - 15) / 8, 0, 1) : clamp((ffb_cmd - 47) / 13, 0, 1), (ffb_cmd >= 10 && ffb_cmd <= 23) \|\| (ffb_cmd >= 48 && ffb_cmd <= 60)), 0)` | Centring spring, 0 to 1, kept until changed. |
| `friction` | `valid(hold(clamp((ffb_cmd - 31) / 8, 0, 1), ffb_cmd >= 32 && ffb_cmd <= 39), 0)` | Friction ("clutch"), 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd >= 64 && ffb_cmd <= 71 ? (ffb_cmd - 63) / 8 : 0` | Vibration ("uncentering"), 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `in_race` | `maxw(delta(race_time) > 0, 1)` | 1 while the race clock runs (from GO to the finish line), held 1 s. |
| `rumble_strip` | `speed * max_speed > 5 ? ((bits(surfaces, 12, 4) == 3) + (bits(surfaces, 8, 4) == 3) + (bits(surfaces, 4, 4) == 3) + (bits(surfaces, 0, 4) == 3)) / 4 : 0` | Wheels on a kerb, 0 to 1 (a quarter per wheel), while moving. |
| `off_road` | `speed * max_speed > 5 ? ((bits(surfaces, 12, 4) == 4) + (bits(surfaces, 8, 4) == 4) + (bits(surfaces, 4, 4) == 4) + (bits(surfaces, 0, 4) == 4)) / 4 : 0` | Wheels on grass, 0 to 1 (a quarter per wheel), while moving. |
| `lampstart` | `band(rawlamps, 4) != 0` | LampStart output, 0 or 1. From the emulator's lamp-port value (see rawlamps); no OutputBlaster needed. |
| `lampleader` | `band(rawlamps, 128) != 0` | LampLeader output, 0 or 1. From the emulator's lamp-port value (see rawlamps); no OutputBlaster needed. |
| `lampview1` | `band(rawlamps, 8) != 0` | LampView1 output, 0 or 1. From the emulator's lamp-port value (see rawlamps); no OutputBlaster needed. |
| `lampview2` | `band(rawlamps, 16) != 0` | LampView2 output, 0 or 1. From the emulator's lamp-port value (see rawlamps); no OutputBlaster needed. |
| `lampview3` | `band(rawlamps, 32) != 0` | LampView3 output, 0 or 1. From the emulator's lamp-port value (see rawlamps); no OutputBlaster needed. |
| `lampview4` | `band(rawlamps, 64) != 0` | LampView4 output, 0 or 1. From the emulator's lamp-port value (see rawlamps); no OutputBlaster needed. |
| `car_in_race` (not exported) | `in_race != 0` | Common value Car_in_race: 1 while racing. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_rpm` (not exported) | `rpm * max_revs` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). |
| `car_gear` (not exported) | `gear` | Common value Car_gear: gear. |
| `car_speed_kmh` (not exported) | `speed * max_speed` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h. Car_speed_mph is this / 1.609344. |
| `car_lap` (not exported) | `in_race ? laps_done + 1 : 0` | Common value Car_lap: the lap you are on, 1 = first (laps completed + 1); 0 outside a race. |
| `car_time_left` (not exported) | `time_left` | Common value Car_time_left: time left (RT), seconds. |
| `car_race_time` (not exported) | `race_time` | Common value Car_race_time: the race clock (TT), seconds. |
| `car_impact` (not exported) | `max(maxw(wall_hit, 0.2), force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0)` | Common value Car_impact: wall contacts (held 0.2 s), or a big kick in the wheel force (other hits), 0 to 1. |
| `car_impact_side` (not exported) | `0` | Common value Car_impact_side: not known: the wheel force pushed the same way for left and right wall hits, so it gives no side. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_rumble_strip` (not exported) | `rumble_strip` | Common value Car_rumble_strip: 1 on a ripple strip. |
| `car_off_road` (not exported) | `off_road` | Common value Car_off_road: off the road. |
| `car_grip_loss` (not exported) | `grip_loss` | Common value Car_grip_loss: sliding, 0 to 1. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_airborne` (not exported) | `airborne` | Common value Car_airborne: 1 in the air (a guess so far). |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |
| `lamp_checkpoint` (not exported) | `checkpoint` | Common lamp Lamp_checkpoint: a checkpoint passed or time extended (`checkpoint`). |

<a id="m2sgt24h"></a>
## Super GT 24h (Model 2 Emulator)

Prefix `M2SGT24H` (properties `TPTelemetry.M2SGT24H_<row>`), process `emulator_multicpu.exe`, folder `Model 2 Emulator`.

| Row | Formula | What it does |
|---|---|---|
| `force` | `valid(hold(ffb_cmd >= 80 && ffb_cmd <= 87 ? (ffb_cmd - 79) / 8 : (ffb_cmd >= 96 && ffb_cmd <= 103 ? -(ffb_cmd - 95) / 8 : 0), (ffb_cmd >= 80 && ffb_cmd <= 87) \|\| (ffb_cmd >= 96 && ffb_cmd <= 103)), 0)` | Force, -1 to 1, kept until the next force command ("roll left" + from the right, "roll right" -). |
| `spring` | `valid(hold(ffb_cmd >= 10 && ffb_cmd <= 23 ? clamp((ffb_cmd - 15) / 8, 0, 1) : clamp((ffb_cmd - 47) / 13, 0, 1), (ffb_cmd >= 10 && ffb_cmd <= 23) \|\| (ffb_cmd >= 48 && ffb_cmd <= 60)), 0)` | Centring spring, 0 to 1, kept until changed. |
| `friction` | `valid(hold(clamp((ffb_cmd - 31) / 8, 0, 1), ffb_cmd >= 32 && ffb_cmd <= 39), 0)` | Friction ("clutch"), 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd >= 64 && ffb_cmd <= 71 ? (ffb_cmd - 63) / 8 : 0` | Vibration ("uncentering"), 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `lampstart` | `band(rawlamps, 4) != 0` | LampStart output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampleader` | `band(rawlamps, 128) != 0` | LampLeader output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview1` | `band(rawlamps, 8) != 0` | LampView1 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview2` | `band(rawlamps, 16) != 0` | LampView2 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview3` | `band(rawlamps, 32) != 0` | LampView3 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `lampview4` | `band(rawlamps, 64) != 0` | LampView4 output, 0 or 1. From game memory, the same reads OutputBlaster makes (no OutputBlaster needed). Unverified. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |

<a id="smdaytona2"></a>
## Daytona USA 2 (Supermodel)

Prefix `SMDAYTONA2` (properties `TPTelemetry.SMDAYTONA2_<row>`), process `(none: reads no game memory)`, folder `Supermodel`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_RawDrive, 0)` | The force feedback command the game sends. From Supermodel's network outputs (-outputs=net), as the FFB Arcade Plugin reads them; TeknoParrot's Model 3 emulator may not send them. |
| `force` | `valid(hold(ffb_cmd >= 80 && ffb_cmd <= 95 ? -(ffb_cmd - 79) / 16 : (ffb_cmd >= 96 && ffb_cmd <= 111 ? (ffb_cmd - 95) / 16 : 0), (ffb_cmd >= 80 && ffb_cmd <= 111) \|\| ffb_cmd == 128), 0)` | Force, -1 to 1, kept until the next force command ("roll right" -, "roll left" +, 0x80 stops it). |
| `spring` | `valid(hold(ffb_cmd >= 10 && ffb_cmd <= 31 ? clamp((ffb_cmd - 9) / 16, 0, 1) : 0, (ffb_cmd >= 10 && ffb_cmd <= 31) \|\| (ffb_cmd >= 64 && ffb_cmd <= 79)), 0)` | Centring spring, 0 to 1, kept until changed (0 while "uncentering"). |
| `friction` | `valid(hold(clamp((ffb_cmd - 31) / 16, 0, 1), ffb_cmd >= 32 && ffb_cmd <= 47), 0)` | Friction ("clutch"), 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd >= 48 && ffb_cmd <= 63 ? (ffb_cmd - 47) / 16 : 0` | Vibration ("centering"), 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="smdayto2pe"></a>
## Daytona USA 2 Power Edition (Supermodel)

Prefix `SMDAYTO2PE` (properties `TPTelemetry.SMDAYTO2PE_<row>`), process `supermodel.exe`, folder `Supermodel`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speed, km/h, as the screen shows it (14 readings, 93 to 275 km/h). Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `rpm` | memory read, then `value / max_revs` | Engine revs, RPM, as the rev counter shows them: like `rpm_wheels` while the clutch is in, but it races ahead when the wheels spin or the clutch slips at a standing start (8,500, the limiter, at 42 to 50 km/h in first, where Alexis saw the dial stuck at 8.2k with the limiter light on; her SPECIAL recording of 18:57, 18 November 2026) and lags a moment across a gear change. Limiters: NORMAL and HARD 8,500 (8.2k on the dial), EASY about 7,650, SPECIAL 7,000 to 7,800 (7.4k on the dial); 10000 is a ceiling, changing down too fast (8.8k on the dial). Max revs 8500. Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `ffb_cmd` | `valid(out_RawDrive, 0)` | The force feedback command the game sends. From Supermodel's network outputs (-outputs=net), as the FFB Arcade Plugin reads them; TeknoParrot's Model 3 emulator may not send them. |
| `lampstart` | `valid(out_LampStart, 0)` | Start button lamp (0 or 1). From Supermodel's network outputs (-outputs=net). |
| `lampview1` | `valid(out_LampView1, 0)` | VR1 view button lamp. From Supermodel's network outputs (-outputs=net). |
| `lampview2` | `valid(out_LampView2, 0)` | VR2 view button lamp. From Supermodel's network outputs (-outputs=net). |
| `lampview3` | `valid(out_LampView3, 0)` | VR3 view button lamp. From Supermodel's network outputs (-outputs=net). |
| `lampview4` | `valid(out_LampView4, 0)` | VR4 view button lamp. From Supermodel's network outputs (-outputs=net). |
| `lampleader` | `valid(out_LampLeader, 0)` | Leader lamp. From Supermodel's network outputs (-outputs=net). |
| `lamp_bits` | `valid(out_RawLamps, 0)` | The lamp port as one number (4 start, 8/16/32/64 the four view buttons, 128 leader), so a recording shows every lamp in one column. From Supermodel's network outputs (-outputs=net). |
| `playing` | memory read, then `value == 255` | 255 from the course select to the moment the race clock stops (finish line or time up), 0 in the attract mode, the results and name entry. Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `rt` | memory read, then `max(value, 0) / 57` | Time left (RT), seconds: frames, 57 to the game's second (60 s is 3420); extended at the lap lines; held after the finish line; -1 frame at time up, read as 0. Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `race_clock` | memory read, then `value / 57` | Race clock (TT), seconds: frames from GO, 57 to the second (7914 frames was TOTAL TIME 02'18"835 on the result screen, which counts thousandths its own way, so this is within about 0.01 s). Stops at the finish line and time up; the attract mode sets it to replay times. Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `lap` | memory read, then `value + 1` | Lap, counting the first as 1 (laps completed + 1; 9 once past the eighth line on Beginner). Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `lap_start` | memory read, then `value / 57` | The race clock at the last lap line, seconds. Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `best_lap` | memory read, then `value / 57` | Best lap so far, seconds. Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `last_lap` | memory read, then `value / 57` | The last lap, seconds (the list on screen: 18"626, 19"085, 20"841...). Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `position` | memory read, then `value + 1` | Race position, 1 = leading, as POSITION shows it (15 screenshots, 34th to 20th). Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `throttle` | memory read, then `value / 255` | Throttle as the game uses it, 0 to 1 (0 to 255). Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `brake` | memory read, then `value / 255` | Brake, 0 to 1. Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `steer` | memory read, then `value / 32766` | Steering input, -1 full left to 1 full right (the game holds -32766 to 32766). Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `near_car` | memory read, then `bits(value, 4, 1)` | Another car within about 5 m (bit 4, value 16), as in Scud Race. Found by running the game in the same Supermodel build, then read right in Alexis's three recordings of 18 November 2026 (16:41 Advanced, NORMAL, manual; 16:47 Expert, HARD, manual; 16:50 Beginner, SPECIAL, automatic, with a pit stop). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `force` | `maxw((ffb_cmd >= 80 && ffb_cmd <= 111), 0.1) > 0 ? valid(hold(ffb_cmd >= 80 && ffb_cmd <= 95 ? -(ffb_cmd - 79) / 16 : (ffb_cmd - 95) / 16, ffb_cmd >= 80 && ffb_cmd <= 111), 0) : 0` | Force, -1 to 1 ("roll right" -, "roll left" +), for 0.1 s after each roll command. Kept until the next command (as SMDAYTONA2 and SMLEMANS24 still do), it matched the wheel force over USB poorly in Alexis's Scud Race and Daytona 2 recordings (correlation 0 to 0.4); like this 0.15 to 0.8 (18 November 2026). |
| `spring` | `valid(hold(ffb_cmd >= 10 && ffb_cmd <= 31 ? clamp((ffb_cmd - 9) / 16, 0, 1) : 0, (ffb_cmd >= 10 && ffb_cmd <= 31) \|\| (ffb_cmd >= 64 && ffb_cmd <= 79)), 0)` | Centring spring, 0 to 1, kept until changed (0 while "uncentering"). |
| `friction` | `valid(hold(clamp((ffb_cmd - 31) / 16, 0, 1), ffb_cmd >= 32 && ffb_cmd <= 47), 0)` | Friction ("clutch"), 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd >= 48 && ffb_cmd <= 63 ? (ffb_cmd - 47) / 16 : 0` | Vibration ("centering"), 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `countdown` | `playing && race_clock == 0 && rt > 0` | The start: from the time set to 60 s to GO. On Beginner the rolling start (the game drives; effects on there, as Alexis asked); on Advanced and Expert the grid (5.4 s, revs up to about 9,100). |
| `racing` | `playing && valid(rt, 0) > 0 && maxw(valid(delta(race_clock), 0) > 0 && valid(delta(race_clock), 0) < 0.1, 0.1) > 0` | 1 from GO to the finish line or time up: in a game (`playing`) with the race clock moving a frame at a time. 0 in the attract mode, whose replays set the clock. |
| `finished` | `!playing && rt > 0 && race_clock > 0` | 1 after crossing the finish line (the clock stopped with time left); kept into the attract mode until the next race. |
| `time_extended` | `maxw(race_clock > 0 && valid(delta(rt), 0) > 1 && valid(delta(rt), 0) < 120, 2) > 0` | Time extended: 1 for 2 s when the time left jumps up (the lap lines on Beginner). Not at the start. |
| `lap_time` | `race_clock - lap_start` | The current lap's time, seconds: the lap clock on screen. |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed, assuming km/h (speed x Max speed undoes the division, so this stays in G). + speeding up, - slowing down. |
| `rev_limit` | `car_class == 0 \|\| car_class == 3 ? 7650 : 8500` | This car's rev limit, where the revs sit in Alexis's recordings (18 November 2026): NORMAL and HARD 8,500 (8.2k on the dial); EASY 7,650 (first 7,880, second 7,640, third 7,610); SPECIAL 7,650, the same place on the dial as 8,500 is to 8.2k, for her 7.4k (second and third sat at 6,990 in one recording and 7,800 in the next; the automatic changes up at about 7,400). First gear's 8,500 reads full on every car. |
| `rpm_frac` | `car_class >= 0 && car_class <= 3 ? clamp(rpm * max_revs / rev_limit, 0, 1.1) : rpm * max_revs / 8500` | Revs as a fraction of this car's rev limit, so the rev limiter and engine effects reach full on every car. |
| `drift_angle` | `racing && speed * max_speed > 10 ? atan2(-(move_x * head_z + move_z * head_x), move_x * head_x - move_z * head_z) * 57.29578 : 0` | Drift angle, degrees: between where the car points and where it is going, + pointing right of its path (worked out as for Scud Race, whose sign Alexis confirmed); over 120 the car is going backwards. 0 under 10 km/h and outside a race. |
| `drift` | `abs(drift_angle) > 120 ? 0 : pow(clamp((abs(drift_angle) - 10) / 72, 0, 1), 0.6) * sqrt(clamp((speed * max_speed - 20) / 80, 0, 1))` | Drifting, 0 to 1: from 10 degrees, eased, full at 82, set from Alexis's three points (18 November 2026): 26 to 30 degrees about 0.45 (Advanced, lap 2 0:33.26), 64 degrees about 0.8 (Beginner, lap 4 0:13.54), 82 degrees 1 (Expert, lap 1 2:14.81); times the speed part (full from 100 km/h; her drifts were all at 260 to 295 km/h); 0 going backwards. |
| `edge_left` | `racing && (abs(seg_fl - seg) > 300 \|\| abs(seg_rl - seg) > 300) && !(abs(seg_fr - seg) > 300 \|\| abs(seg_rr - seg) > 300)` | 1 while a left wheel is off the road's strip (against a wall, or on the edge) and no right wheel is: both sides at once is the lap line or a fork, where the strips are numbered afresh. |
| `edge_right` | `racing && (abs(seg_fr - seg) > 300 \|\| abs(seg_rr - seg) > 300) && !(abs(seg_fl - seg) > 300 \|\| abs(seg_rl - seg) > 300)` | The same for the right wheels. |
| `wall_contact` | `edge_left ? -1 : (edge_right ? 1 : 0)` | Touching or scraping a wall on the left (-1) or right (1). As in Scud Race, a verge lane can read as the far wall. |
| `car_touch` | `maxw(car_contact, 0.2) > 0` | 1 while touching another car (held 0.2 s; the value flickers). |
| `pit_stop` | `racing && rt > 0 && maxw(rt, 0.3) == minw(rt, 0.3)` | 1 in a pit stop: the time left stands still while the race clock runs (Alexis's Beginner recording: from just after the lap line to the end of the stop, then the game drives out of the pit lane with the time running). |
| `hit` | `racing && !pit_stop ? max(maxw(valid(delta(crash), 0) > 10, 0.3) > 0 ? 1 : 0, maxw(car_contact > 0 ? clamp(0.4 + car_contact * 1.2, 0.4, 1) : 0, 0.2), maxw(wall_contact != 0 \|\| car_touch, 0.3) > 0 ? clamp(0.4 + (maxw(speed * max_speed, 0.25) - speed * max_speed - 10) / 60, 0, 1) * (maxw(speed * max_speed, 0.25) - speed * max_speed > 10) : 0) : 0` | A hit, 0 to 1: 1 for a big crash (the game's crash timer); touching another car 0.4 to 1 by how hard, for 0.2 s; losing speed while touching a wall or a car, 0.4 at 10 km/h lost in 0.25 s up to 1 at 46 km/h. Not in a pit stop (the game brakes into the pit lane). |
| `hit_side` | `hit > 0 ? (maxw(car_touch, 0.3) > 0 && maxw(abs(force), 0.3) > 0 ? sign(valid(hold(force, force != 0), 0)) : sign(maxw(edge_right, 0.3) - maxw(edge_left, 0.3))) : 0` | Side of a hit, -1 left, 1 right. A car hit takes the side of the game's roll command sent with it (`force`, so -outputs=net is needed): her left-rear, left-rear, right-rear and right-side hits got roll right, roll right, roll left, roll left (18 November 2026). Hits on the front corners send another command (175), so no side; nor without the outputs. A wall hit takes the side of the wheels against it (her crashes: left, right, left then right, all as she saw them). |
| `car_in_race` (not exported) | `racing \|\| countdown` | Common value Car_in_race: 1 from the start (the rolling start on Beginner, kept as Alexis asked; the grid on Advanced and Expert) to the finish line or time up; not in the attract mode. Checked in her three recordings of 18 November 2026. |
| `car_speed` (not exported) | `racing \|\| countdown ? (speed * max_speed) : 0` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_rpm` (not exported) | `racing \|\| countdown ? (rpm * max_revs) : 0` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_gear` (not exported) | `racing \|\| countdown ? (gear) : 0` | Common value Car_gear: gear. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_accel_g` (not exported) | `racing \|\| countdown ? (accel_g) : 0` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_speed_kmh` (not exported) | `racing \|\| countdown ? (speed * max_speed) : 0` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the screen). Car_speed_mph is this / 1.609344. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_rev_limit_rpm` (not exported) | `racing \|\| countdown ? (rev_limit) : 0` | Common value Car_rev_limit_rpm: this car's rev limit, RPM (the rev_limit row), for a dashboard's redline. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_position` (not exported) | `racing \|\| countdown ? (position) : 0` | Common value Car_position: race position, 1 = first. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_lap` (not exported) | `racing \|\| countdown ? (lap) : 0` | Common value Car_lap: the lap you are on, 1 = first. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_time_left` (not exported) | `racing \|\| countdown ? (rt) : 0` | Common value Car_time_left: time left (RT) as the screen shows it, seconds. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_race_time` (not exported) | `racing \|\| countdown ? (race_clock) : 0` | Common value Car_race_time: the race clock (TT), seconds. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_lap_time` (not exported) | `racing \|\| countdown ? (lap_time) : 0` | Common value Car_lap_time: the current lap's time, seconds. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_brake` (not exported) | `racing \|\| countdown ? (brake) : 0` | Common value Car_brake: brake pedal, 0 to 1, as the game uses it. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_steer` (not exported) | `racing \|\| countdown ? (steer) : 0` | Common value Car_steer: steering, -1 full left to 1 full right, as the game uses it. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_impact` (not exported) | `racing \|\| countdown ? (hit) : 0` | Common value Car_impact: hits, 0 to 1: 1 for a big crash (the game's crash timer), 0.4 to 1 touching another car, otherwise by the km/h lost touching a wall; not in a pit stop. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_impact_side` (not exported) | `racing \|\| countdown ? (hit_side) : 0` | Common value Car_impact_side: side of a hit, -1 left, 1 right: walls from the wheels, car hits from the game's roll command (outputs on); front-corner car hits none. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_wall_contact` (not exported) | `racing \|\| countdown ? (wall_contact) : 0` | Common value Car_wall_contact: touching or scraping a wall, -1 left, 1 right: the wheels on that side are off the road's strip. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_road_bump` (not exported) | `racing \|\| countdown ? (force_kick <= 0.5 ? force_kick * 2 : 0) : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_grip_loss` (not exported) | `racing \|\| countdown ? (drift) : 0` | Common value Car_grip_loss: sliding: follows Car_drift (0 to 1), as the game gives no slip value of its own. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_drift` (not exported) | `racing \|\| countdown ? (drift) : 0` | Common value Car_drift: drifting, 0 to 1: from 10 degrees, eased, full at 82 (her three points: about 0.45 at 26 to 30, 0.8 at 64, 1 at 82), times the speed part. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_drift_angle` (not exported) | `racing \|\| countdown ? (drift_angle) : 0` | Common value Car_drift_angle: the drift angle in degrees, + pointing right of the car's path (a right-hand drift), - left. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_cornering` (not exported) | `racing \|\| countdown ? (clamp(ema(steer, 0.1) / 0.8 * sqrt(clamp(speed * max_speed / 120, 0, 1)), -1, 1)) : 0` | Common value Car_cornering: cornering from the steering and speed, + turning right, as Scud Race. A starting point. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_vibration` (not exported) | `racing \|\| countdown ? (vibration) : 0` | Common value Car_vibration: the game's own vibration command, 0 to 1. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_rpm_frac` (not exported) | `racing \|\| countdown ? (rpm_frac) : 0` | Common value Car_rpm_frac: revs as the rev counter shows them, as a fraction of this car's rev limit (EASY and SPECIAL 7650, NORMAL and HARD 8500), so the rev limiter and engine effects reach full on every car. 0 outside a race (attract mode, menus, after the line); on through the grid or rolling start. |
| `car_throttle` (not exported) | `racing ? (throttle) : (countdown ? 1 : 0)` | Common value Car_throttle: throttle, 0 to 1, as the game uses it: the engine effects run at 60% off the throttle, full at full throttle. 0 outside a race; 1 on the grid and in the rolling start, so the engine effects follow the revs alone there (Alexis, 18 November 2026). |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |

<a id="smdirtdevils"></a>
## Dirt Devils (Supermodel)

Prefix `SMDIRTDEVILS` (properties `TPTelemetry.SMDIRTDEVILS_<row>`), process `(none: reads no game memory)`, folder `Supermodel`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_RawDrive, 0)` | The force feedback command the game sends. From Supermodel's network outputs (-outputs=net), as the FFB Arcade Plugin reads them; TeknoParrot's Model 3 emulator may not send them. |
| `spring` | `valid(hold(0.7, ffb_cmd == 16), 0)` | Centring spring: the FFB plugin sets 0.7 for command 0x10. |
| `vibration` | `ffb_cmd == 47 ? 1 : 0` | Vibration (command 0x2F). |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="smeca"></a>
## Emergency Call Ambulance (Supermodel)

Prefix `SMECA` (properties `TPTelemetry.SMECA_<row>`), process `(none: reads no game memory)`, folder `Supermodel`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_RawDrive, 0)` | The force feedback command the game sends. From Supermodel's network outputs (-outputs=net), as the FFB Arcade Plugin reads them; TeknoParrot's Model 3 emulator may not send them. |
| `force` | `valid(hold(ffb_cmd > 0 && ffb_cmd <= 63 ? ffb_cmd / 64 : -(ffb_cmd - 64) / 64, ffb_cmd > 0 && ffb_cmd <= 127), 0)` | Force, -1 to 1, kept until the next command (1 to 63 from the right, 64 to 127 from the left). |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="smlemans24"></a>
## Le Mans 24 (Supermodel)

Prefix `SMLEMANS24` (properties `TPTelemetry.SMLEMANS24_<row>`), process `(none: reads no game memory)`, folder `Supermodel`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_RawDrive, 0)` | The force feedback command the game sends. From Supermodel's network outputs (-outputs=net), as the FFB Arcade Plugin reads them; TeknoParrot's Model 3 emulator may not send them. |
| `force` | `valid(hold(ffb_cmd >= 80 && ffb_cmd <= 95 ? -(ffb_cmd - 79) / 16 : (ffb_cmd >= 96 && ffb_cmd <= 111 ? (ffb_cmd - 95) / 16 : 0), (ffb_cmd >= 80 && ffb_cmd <= 111) \|\| ffb_cmd == 128), 0)` | Force, -1 to 1, kept until the next force command ("roll right" -, "roll left" +, 0x80 stops it). |
| `spring` | `valid(hold(ffb_cmd >= 10 && ffb_cmd <= 31 ? clamp((ffb_cmd - 9) / 16, 0, 1) : 0, (ffb_cmd >= 10 && ffb_cmd <= 31) \|\| (ffb_cmd >= 64 && ffb_cmd <= 79)), 0)` | Centring spring, 0 to 1, kept until changed (0 while "uncentering"). |
| `friction` | `valid(hold(clamp((ffb_cmd - 31) / 16, 0, 1), ffb_cmd >= 32 && ffb_cmd <= 47), 0)` | Friction ("clutch"), 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd >= 48 && ffb_cmd <= 63 ? (ffb_cmd - 47) / 16 : 0` | Vibration ("centering"), 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_vibration` (not exported) | `vibration` | Common value Car_vibration: the game's own vibration command, 0 to 1. |

<a id="smscud"></a>
## Scud Race (Supermodel)

Prefix `SMSCUD` (properties `TPTelemetry.SMSCUD_<row>`), process `supermodel.exe`, folder `Supermodel`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speed, km/h, as the screen shows it (matched at 34 readings, 103 to 328 km/h). In the attract mode it is the demo car's speed. Checked in Alexis's four recordings of 18 November 2026 (Porsche manual and Viper manual on Beginner night, McLaren manual on Medium, F40 automatic on Expert). Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `rpm` | memory read, then `value / max_revs` | Engine revs, RPM, as the rev counter's needle shows them. Each car's limiter: 7200 the Porsche and the Viper, 8500 the McLaren (Alexis's recordings); the F40's automatic reached 9370. Checked in Alexis's four recordings of 18 November 2026 (Porsche manual and Viper manual on Beginner night, McLaren manual on Medium, F40 automatic on Expert). Divided by Max revs (blank = 1, so the raw value; set it to the redline to make this run 0 to 1). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `ffb_cmd` | `valid(out_RawDrive, 0)` | The force feedback command the game sends. From Supermodel's network outputs (-outputs=net), as the FFB Arcade Plugin reads them; TeknoParrot's Model 3 emulator may not send them. |
| `lampstart` | `valid(out_LampStart, 0)` | Start button lamp (0 or 1). From Supermodel's network outputs (-outputs=net). |
| `lampview1` | `valid(out_LampView1, 0)` | VR1 view button lamp. From Supermodel's network outputs (-outputs=net). |
| `lampview2` | `valid(out_LampView2, 0)` | VR2 view button lamp. From Supermodel's network outputs (-outputs=net). |
| `lampview3` | `valid(out_LampView3, 0)` | VR3 view button lamp. From Supermodel's network outputs (-outputs=net). |
| `lampview4` | `valid(out_LampView4, 0)` | VR4 view button lamp. From Supermodel's network outputs (-outputs=net). |
| `lampleader` | `valid(out_LampLeader, 0)` | Leader lamp. From Supermodel's network outputs (-outputs=net). |
| `lamp_bits` | `valid(out_RawLamps, 0)` | The lamp port as one number (4 start, 8/16/32/64 the four view buttons, 128 leader), so a recording shows every lamp in one column. From Supermodel's network outputs (-outputs=net). |
| `rt` | memory read, then `max(value, 0) / 57` | Time left (RT), seconds: the game counts it in frames, 57 to its second (60 s is 3420). Extended at each lap line on Beginner (26.67 s at night) and at each checkpoint on Medium and Expert (14.23 s); frozen while the pit crew works (Expert); held after the finish line; -1 frame at time up, read as 0. Checked in Alexis's four recordings of 18 November 2026 (Porsche manual and Viper manual on Beginner night, McLaren manual on Medium, F40 automatic on Expert). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `race_clock` | memory read, then `value / 57` | Race clock (TT), seconds: frames from GO, 57 to the second, as the result screen's TOTAL TIME shows it (5092 frames was 1'29"33). Stops at the finish line and at time up and holds until the next race. Checked in Alexis's four recordings of 18 November 2026 (Porsche manual and Viper manual on Beginner night, McLaren manual on Medium, F40 automatic on Expert). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `lap` | memory read, then `value + 1` | Lap, counting the first as 1 (the car's completed laps + 1; 5 once past Beginner's fourth lap line). Checked in Alexis's four recordings of 18 November 2026 (Porsche manual and Viper manual on Beginner night, McLaren manual on Medium, F40 automatic on Expert). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `lap_start` | memory read, then `value / 57` | The race clock at the last lap line, seconds (0 in the first lap). Found by running the game in the same Supermodel build (18 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `best_lap` | memory read, then `value / 57` | Best lap so far, seconds (0 until the first lap line): BEST LAP on screen. Found by running the game in the same Supermodel build (18 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `last_lap` | memory read, then `value / 57` | The last lap, seconds. Found by running the game in the same Supermodel build (18 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `position` | memory read, then `value + 1` | Race position, 1 = leading, as POSITION shows it (40th at the start of a 40-car race on Beginner). Found by running the game in the same Supermodel build (18 November 2026). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `throttle` | memory read, then `value / 255` | Throttle as the game uses it, 0 to 1 (0 to 255): follows the pedal over USB (correlation 0.85 to 0.97). Checked in Alexis's four recordings of 18 November 2026 (Porsche manual and Viper manual on Beginner night, McLaren manual on Medium, F40 automatic on Expert). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `brake` | memory read, then `value / 255` | Brake as the game uses it, 0 to 1: nothing until the pedal is about half way down (over USB). Checked in Alexis's four recordings of 18 November 2026 (Porsche manual and Viper manual on Beginner night, McLaren manual on Medium, F40 automatic on Expert). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `steer` | memory read, then `value / 32766` | Steering input, -1 full left to 1 full right (the game holds -32766 to 32766): follows the wheel over USB (correlation 0.96 to 0.98). Checked in Alexis's four recordings of 18 November 2026 (Porsche manual and Viper manual on Beginner night, McLaren manual on Medium, F40 automatic on Expert). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `near_car` | memory read, then `bits(value, 4, 1)` | Another car within about 5 m (bit 4, value 16; the byte is 128 or 144). Found in the emulator (18 November 2026, after her recordings, so not yet in one). 64-bit game: read through TPTelemetryHelper64.exe (plugin 0.9.0 or later). |
| `force` | `maxw((ffb_cmd >= 80 && ffb_cmd <= 111), 0.1) > 0 ? valid(hold(ffb_cmd >= 80 && ffb_cmd <= 95 ? -(ffb_cmd - 79) / 16 : (ffb_cmd - 95) / 16, ffb_cmd >= 80 && ffb_cmd <= 111), 0) : 0` | Force, -1 to 1 ("roll right" -, "roll left" +), for 0.1 s after each roll command. Kept until the next command (as SMDAYTONA2 and SMLEMANS24 still do), it matched the wheel force over USB poorly in Alexis's Scud Race and Daytona 2 recordings (correlation 0 to 0.4); like this 0.15 to 0.8 (18 November 2026). |
| `spring` | `valid(hold(ffb_cmd >= 10 && ffb_cmd <= 31 ? clamp((ffb_cmd - 9) / 16, 0, 1) : 0, (ffb_cmd >= 10 && ffb_cmd <= 31) \|\| (ffb_cmd >= 64 && ffb_cmd <= 79)), 0)` | Centring spring, 0 to 1, kept until changed (0 while "uncentering"). |
| `friction` | `valid(hold(clamp((ffb_cmd - 31) / 16, 0, 1), ffb_cmd >= 32 && ffb_cmd <= 47), 0)` | Friction ("clutch"), 0 to 1, kept until changed. |
| `vibration` | `ffb_cmd >= 48 && ffb_cmd <= 63 ? (ffb_cmd - 47) / 16 : 0` | Vibration ("centering"), 0 to 1. |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `phase` | `bits(state, 8, 8)` | Race phase from `state`: 2 loading, 3 the rolling start's camera shots, 4 the driver's view (countdown and race); it stays 4 after the race. |
| `countdown` | `phase == 4 && bits(state, 16, 8) == 1` | 1 in the Beginner course's rolling start 3-2-1 (the driver's view, with the game driving the car at about 300 km/h), 0 from GO. The standing starts on Medium and Expert don't use it. |
| `final_position` | `bits(state, 24, 8) + 1` | Your place when the last race ended (finish line or time up), as the result screen gives it: 21st and 33rd, 29th and 20th in the four recordings. Kept until the next race ends. |
| `racing` | `phase == 4 && bits(state, 24, 8) == valid(hold(bits(state, 24, 8), race_clock == 0), bits(state, 24, 8)) && (countdown ? race_clock == 0 && rt > 0 : maxw(valid(delta(race_clock), 0) > 0, 0.1) > 0)` | 1 from GO (on Beginner from the rolling start's 3-2-1) to the finish line or time up: the race phase, the race clock moving, and the finishing place not yet set (the game sets it the moment the clock stops). 0 in the attract mode (whose demo race drives the same car), the menus and the rolling start's camera shots. In Alexis's four recordings of 18 November 2026 it ended within 0.04 s of the clock stopping (two time ups, one finish line). |
| `finished` | `phase == 4 && !racing && race_clock > 0 && rt > 0` | 1 after crossing the finish line (the clock stopped with time left), 0 after time up; kept into the attract mode until the next race. |
| `grid` | `phase == 4 && !countdown && race_clock == 0 && rt > 0` | 1 on the grid before GO on Medium and Expert (the standing starts), once the time left is set: Car_in_race, Car_rpm, Car_rpm_frac and Car_gear run then, the rest from GO (Alexis, 18 November 2026). |
| `pit_stop` | `racing && race_clock > 0 && rt > 0 && maxw(valid(delta(rt), 0) < 0, 0.25) == 0` | 1 while the time left stands still in a race: in the pits on Expert, where the game takes the wheel and the time stops (Alexis's F40 recording, 18 November 2026: from TT 1:07.74 in the pit lane until 1:24.42). |
| `lap_time` | `race_clock - lap_start` | The current lap's time, seconds: the lap clock on screen. |
| `time_extended` | `maxw(race_clock > 0 && valid(delta(rt), 0) > 1 && valid(delta(rt), 0) < 120, 2) > 0` | TIME EXTENSION!: 1 for 2 s when the time left jumps up (lap lines on Beginner, checkpoints on Medium and Expert). Not at the start, where the time is first set. |
| `rev_limit` | `car == 7 ? 8500 : (car == 6 ? 9040 : 7200)` | This car's rev limit: 7200 the Porsche and the Viper, 8500 the McLaren, 9040 the F40 (where each sat on the limiter in Alexis's recordings; the F40 at TT 0:15.30 in her 13:30 recording, about 9k on its 10k dial). |
| `rpm_frac` | `car >= 4 && car <= 7 ? clamp(rpm * max_revs / rev_limit, 0, 1.1) : rpm * max_revs / 7200` | Revs as a fraction of this car's rev limit (the Porsche's 7200 for a car number not seen). |
| `accel_g` | `ema(slope(speed * max_speed, 0.1), 0.05) / 3.6 / g` | Longitudinal G from speed, assuming km/h (speed x Max speed undoes the division, so this stays in G). + speeding up, - slowing down. |
| `light` | `racing && minw(slope(move_y, 0.15) < -0.12, 0.1) > 0` | The car going light over a crest (or in the air): falling at 0.7 g or more for 0.1 s. Alexis's Porsche at TT 1:03.0 to 1:04.2, where only the front wheels leave the ground ("pronounced, if not so much as a jump"), reads 1 for 0.9 s. |
| `airborne` | `racing && minw(abs(slope(move_y, 0.15) + 0.165) < 0.03, 0.1) > 0` | 1 in the air: the car falling freely (its downward speed growing by the game's gravity, 0.165 m a frame each second) for 0.1 s. Alexis's jump marks in three recordings (Beginner night, Medium) all read 1 within 0.4 s; smaller hops read too. |
| `drift_angle` | `racing && speed * max_speed > 10 ? atan2(-(move_x * head_z + move_z * head_x), move_x * head_x - move_z * head_z) * 57.29578 : 0` | Drift angle, degrees: between where the car points and where it is going, + pointing right of its path (a right-hand drift), - left. Over 120 is the car going backwards (reversing or spun round). 0 under 10 km/h and outside a race. Her slides reached 40 to 77 degrees. |
| `drift` | `abs(drift_angle) > 120 ? 0 : clamp((abs(drift_angle) - 14) / 44, 0, 1) * sqrt(clamp((speed * max_speed - 20) / 80, 0, 1))` | Drifting, 0 to 1: straight from 14 to 58 degrees, set by Alexis's two F40 drifts (18 November 2026: 53.5 degrees at TT 0:39.33 to read 0.9, 42.5 degrees at 1:40.30 to read 0.65), times the speed part (nothing under 20 km/h, full from 100); 0 going backwards. |
| `edge_left` | `racing && (abs(seg_fl - seg) > 300 \|\| abs(seg_rl - seg) > 300)` | 1 while a left wheel is off the road's strip: against a wall or barrier on the left (sparks on the left in the emulator), or the edge. Both sides at once at the lap line and in the air. |
| `edge_right` | `racing && (abs(seg_fr - seg) > 300 \|\| abs(seg_rr - seg) > 300)` | The same for the right wheels. |
| `wall_contact` | `edge_left && !edge_right ? -1 : (edge_right && !edge_left ? 1 : 0)` | Touching or scraping a wall on the left (-1) or right (1), from which wheels are off the road's strip; 0 when neither or both. To check against Alexis's video. |
| `car_side` | `racing ? (car_contact == 0 ? -1 : (car_contact == 2 ? 1 : 0)) : 0` | Side of a touching car, -1 left, 1 right, 0 none or nose to tail. |
| `car_touch` | `racing && car_contact >= 0 && car_contact <= 3` | 1 while touching another car on any side. |
| `hit` | `racing ? max(maxw(valid(delta(crash), 0) > 10, 0.3) > 0 ? 1 : 0, maxw(car_touch && !prev(car_touch), 0.2) > 0 ? 0.5 : 0, maxw(wall_contact != 0 \|\| car_touch, 0.3) > 0 ? clamp(0.4 + (maxw(speed * max_speed, 0.25) - speed * max_speed - 10) / 60, 0, 1) * (maxw(speed * max_speed, 0.25) - speed * max_speed > 10) : 0) : 0` | A hit, 0 to 1: 1 for a big crash (the game's crash timer); 0.5 for 0.2 s as another car first touches; touching a wall or another car while losing speed, 0.4 at 10 km/h lost in 0.25 s up to 1 at 46 km/h. Braking alone doesn't count. Alexis's F40 recording (18 November 2026): her nose into a car's tail read 0.97, the big crash 1, the wall hits 0.6 to 0.8. |
| `hit_side` | `hit > 0 ? (maxw(car_side != 0, 0.3) > 0 ? valid(hold(car_side, car_side != 0), 0) : sign(maxw(edge_right, 0.3) - maxw(edge_left, 0.3))) : 0` | Side of a hit, -1 left, 1 right: the touching car's side, or the wheels against the wall; 0 when not known (nose to tail, both sides). |
| `wrong_way` | `racing && speed * max_speed > 20 && ema(clamp(valid(delta(seg), 0), -5, 5), 1) < -0.03` | 1 while driving the wrong way: the road strip numbers running backwards. Read 1 in Alexis's Porsche recording at 1:35.14 after a spin; also at the Expert pit lane, whose strips are numbered differently. To check with REVERSE! on screen. |
| `car_in_race` (not exported) | `racing \|\| valid(grid, 0)` | Common value Car_in_race: 1 from GO to the finish line or time up, from the rolling start's 3-2-1 on the Beginner courses, and on the grid before GO on Medium and Expert (where only revs and gear run: Alexis, 18 November 2026). Not in the attract mode's demo race or the rolling start's camera shots. Checked in five recordings. |
| `car_speed` (not exported) | `racing ? (speed * max_speed) : 0` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_rpm` (not exported) | `racing \|\| valid(grid, 0) ? (rpm * max_revs) : 0` | Common value Car_rpm: engine RPM, raw (the rpm row divides by Max revs; this undoes it). 0 outside a race (attract mode, menus, after the line), but running on the grid before GO. |
| `car_gear` (not exported) | `racing \|\| valid(grid, 0) ? (gear) : 0` | Common value Car_gear: gear. 0 outside a race (attract mode, menus, after the line), but running on the grid before GO. |
| `car_accel_g` (not exported) | `racing ? (accel_g) : 0` | Common value Car_accel_g: forward G (+ speeding up, - slowing down). 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_speed_kmh` (not exported) | `racing ? (speed * max_speed) : 0` | Common value Car_speed_kmh: speed in km/h for dashboards: km/h (the screen). Car_speed_mph is this / 1.609344. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_rev_limit_rpm` (not exported) | `racing \|\| valid(grid, 0) ? (rev_limit) : 0` | Common value Car_rev_limit_rpm: this car's rev limit, RPM (the rev_limit row), for a dashboard's redline. 0 outside a race (attract mode, menus, after the line), but running on the grid before GO. |
| `car_position` (not exported) | `racing ? (position) : 0` | Common value Car_position: race position, 1 = first. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_lap` (not exported) | `racing ? (lap) : 0` | Common value Car_lap: the lap you are on, 1 = first. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_time_left` (not exported) | `racing ? (rt) : 0` | Common value Car_time_left: time left (RT) as the screen shows it, seconds. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_race_time` (not exported) | `racing ? (race_clock) : 0` | Common value Car_race_time: the race clock (TT), seconds. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_lap_time` (not exported) | `racing ? (lap_time) : 0` | Common value Car_lap_time: the current lap's time, seconds. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_brake` (not exported) | `racing ? (brake) : 0` | Common value Car_brake: brake pedal, 0 to 1, as the game uses it. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_steer` (not exported) | `racing ? (steer) : 0` | Common value Car_steer: steering, -1 full left to 1 full right, as the game uses it. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_impact` (not exported) | `racing ? (hit) : 0` | Common value Car_impact: hits, 0 to 1: 1 for a big crash (the game's crash timer), otherwise by the km/h lost while touching a wall or another car. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_impact_side` (not exported) | `racing ? (hit_side) : 0` | Common value Car_impact_side: side of a hit, -1 left, 1 right, from the touching car or the wheels against the wall (0 when not known). 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_wall_contact` (not exported) | `racing ? (wall_contact) : 0` | Common value Car_wall_contact: touching or scraping a wall, -1 left, 1 right: the wheels on that side are off the road's strip. To check against Alexis's video. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_road_bump` (not exported) | `racing ? (force_kick <= 0.5 ? force_kick * 2 : 0) : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_grip_loss` (not exported) | `racing ? (drift) : 0` | Common value Car_grip_loss: sliding: follows Car_drift (0 to 1), as the game gives no slip value of its own. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_drift` (not exported) | `racing ? (drift) : 0` | Common value Car_drift: drifting, 0 to 1: straight from 14 to 58 degrees (Alexis's two F40 drifts: 0.9 at 53.5 degrees, 0.65 at 42.5), times the speed part; 0 going backwards. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_drift_angle` (not exported) | `racing ? (drift_angle) : 0` | Common value Car_drift_angle: the drift angle in degrees, + pointing right of the car's path (a right-hand drift), - left. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_cornering` (not exported) | `racing ? (clamp(ema(steer, 0.1) / 0.8 * sqrt(clamp(speed * max_speed / 120, 0, 1)), -1, 1)) : 0` | Common value Car_cornering: cornering from the steering and speed, + turning right, as Initial D 3: the steering (0.8 reads full) times the square root of the speed (full from 120 km/h). Doesn't need Supermodel's outputs. A starting point. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_airborne` (not exported) | `racing ? (airborne ? 1 : (valid(light, 0) ? 0.5 : 0)) : 0` | Common value Car_airborne: 1 in the air (the car falling freely: Alexis's jump marks in three recordings, 18 November 2026), 0.5 going light over a crest (the front wheels lifting). 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_vibration` (not exported) | `racing ? (vibration) : 0` | Common value Car_vibration: the game's own vibration command, 0 to 1. 0 outside a race (attract mode, menus, after the line), as Alexis asked for Sega Rally 3 and GRID (16 November 2026). |
| `car_rpm_frac` (not exported) | `racing \|\| valid(grid, 0) ? (rpm_frac) : 0` | Common value Car_rpm_frac: revs as a fraction of this car's rev limit (7200 Porsche and Viper, 8500 McLaren, 9000 F40), so the rev limiter and engine effects follow every car. 0 outside a race (attract mode, menus, after the line), but running on the grid before GO. |
| `car_throttle` (not exported) | `racing ? (throttle) : (valid(grid, 0) ? 1 : 0)` | Common value Car_throttle: throttle, 0 to 1, as the game uses it: the engine effects run at 60% off the throttle, full at full throttle. 0 outside a race; 1 on the grid, so the engine effects follow the revs alone there (Alexis, 18 November 2026). |
| `lamp_start` (not exported) | `lampstart` | Common lamp Lamp_start: the Start button lamp (the game's `lampstart`). |
| `lamp_view1` (not exported) | `lampview1` | Common lamp Lamp_view1: view button 1 (the game's `lampview1`). |
| `lamp_view2` (not exported) | `lampview2` | Common lamp Lamp_view2: view button 2 (the game's `lampview2`). |
| `lamp_view3` (not exported) | `lampview3` | Common lamp Lamp_view3: view button 3 (the game's `lampview3`). |
| `lamp_view4` (not exported) | `lampview4` | Common lamp Lamp_view4: view button 4 (the game's `lampview4`). |
| `lamp_leader` (not exported) | `lampleader` | Common lamp Lamp_leader: in the lead (the game's own leader lamp). |
| `lamp_warning` (not exported) | `wrong_way` | Common lamp Lamp_warning: an on-screen warning: WRONG WAY. |

<a id="smsrally2"></a>
## Sega Rally 2 (Supermodel)

Prefix `SMSRALLY2` (properties `TPTelemetry.SMSRALLY2_<row>`), process `(none: reads no game memory)`, folder `Supermodel`.

| Row | Formula | What it does |
|---|---|---|
| `ffb_cmd` | `valid(out_RawDrive, 0)` | The force feedback command the game sends. From Supermodel's network outputs (-outputs=net), as the FFB Arcade Plugin reads them; TeknoParrot's Model 3 emulator may not send them. |
| `force` | `valid(hold(ffb_cmd > 0 && ffb_cmd <= 63 ? ffb_cmd / 64 : -(ffb_cmd - 64) / 64, ffb_cmd > 0 && ffb_cmd <= 127), 0)` | Force, -1 to 1, kept until the next command (1 to 63 from the right, 64 to 127 from the left). |
| `force_abs` | `abs(force)` | Force without direction, 0 to 1. |
| `force_smooth` | `ema(force, 0.15)` | Sustained force (cornering-like load), -1 to 1. + = force from the right, which on WMMT3 matched right-hand corners and right-side hits (to be confirmed per game). |
| `force_kick` | `clamp(abs(force - ema(force, 0.15)) * 2, 0, 1)` | Short kicks (bumps, joints, hits) with the slow force removed, 0 to 1. |
| `car_impact` (not exported) | `force_kick > 0.5 ? (force_kick - 0.5) * 2 : 0` | Common value Car_impact: the biggest force kicks, 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_impact_side` (not exported) | `force_kick > 0.5 ? sign(force) : 0` | Common value Car_impact_side: side of a big kick, from the force direction (+ = from the right). Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_road_bump` (not exported) | `force_kick <= 0.5 ? force_kick * 2 : 0` | Common value Car_road_bump: small force kicks (bumps, joints), 0 to 1. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |
| `car_cornering` (not exported) | `clamp(force_smooth, -1, 1)` | Common value Car_cornering: sustained wheel force, + turning right. Approximate: worked out from the force the game sends the wheel, so treat it as a stand-in until something better is found. |

<a id="crazytaxi"></a>
## Crazy Taxi

Prefix `CRAZYTAXI` (properties `TPTelemetry.CRAZYTAXI_<row>`), process `(none: reads no game memory)`, folder `PC`.

| Row | Formula | What it does |
|---|---|---|
| `speed` | memory read, then `value / max_speed` | Speed (units unknown; the FFB plugin treats 10 as full strength). Unverified: from the FFB Arcade Plugin's reading of this game. Divided by Max speed (blank = 1, so the raw value; set it to the top speed to make this run 0 to 1). |
| `playing` | `ingame_flag == 0 && timer != 0` | 1 during play. |
| `impact_side` | `surface == 255 ? (wall_right > 0 ? 1 : (wall_left > 0 ? -1 : 0)) : 0` | Hitting a wall: +1 right, -1 left. |
| `collision` | `maxw(surface == 255 && wall_right <= 0 && wall_left <= 0, 0.3)` | 1 for 0.3 s after hitting something that isn't a wall (cars, objects). |
| `crazy_move` | `band(crazy_moves1, 16) > 0 \|\| crazy_moves2 != 0` | 1 during a crazy move. |
| `off_road` | `surface == 3 \|\| surface == 5 \|\| surface == 9 \|\| surface == 14` | 1 on grass, shoreline, sand or underwater. |
| `stairs` | `surface >= 17 && surface <= 20` | 1 on stairs. |
| `car_in_race` (not exported) | `playing` | Common value Car_in_race: 1 during play. |
| `car_speed` (not exported) | `speed * max_speed` | Common value Car_speed: speed in the game's units, raw (the speed row divides by Max speed; this undoes it). |
| `car_impact` (not exported) | `max(abs(impact_side), collision)` | Common value Car_impact: wall hits and other collisions, 0 or 1. |
| `car_impact_side` (not exported) | `impact_side` | Common value Car_impact_side: side of a wall hit, -1 left, 1 right. |
| `car_wall_contact` (not exported) | `wall_right > 0 ? 1 : (wall_left > 0 ? -1 : 0)` | Common value Car_wall_contact: touching a wall, -1 left, 1 right. |
| `car_off_road` (not exported) | `off_road` | Common value Car_off_road: off the road. |
